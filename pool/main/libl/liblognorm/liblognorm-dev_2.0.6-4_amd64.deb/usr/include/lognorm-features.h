#if 0
#define LOGNORM_REGEX_SUPPORTED 1
#endif
