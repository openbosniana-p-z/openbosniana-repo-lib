%DBIx::FullTextSearch::TestConfig::Config = (
                                              'dsn' => 'dbi:mysql:test',
                                              'password' => undef,
                                              'user' => undef
                                            );
1;
