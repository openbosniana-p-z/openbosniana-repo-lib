var searchData=
[
  ['createmenu',['createMenu',['../classDBusMenuImporter.html#aa5f30a98aa06849f1cac8379d29b797f',1,'DBusMenuImporter']]]
];
