var searchData=
[
  ['iconforname',['iconForName',['../classDBusMenuImporter.html#ab07ca6e49021c07d1be0f7c631663e58',1,'DBusMenuImporter']]],
  ['iconnameforaction',['iconNameForAction',['../classDBusMenuExporter.html#a8f0ea09b0f28429ebb03023d6a69948a',1,'DBusMenuExporter']]]
];
