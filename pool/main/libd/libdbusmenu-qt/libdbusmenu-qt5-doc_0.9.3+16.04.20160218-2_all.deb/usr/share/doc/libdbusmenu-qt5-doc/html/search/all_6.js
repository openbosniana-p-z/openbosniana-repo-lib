var searchData=
[
  ['updatemenu',['updateMenu',['../classDBusMenuImporter.html#a4c76c54f283e7f100c02669d0e79d990',1,'DBusMenuImporter']]]
];
