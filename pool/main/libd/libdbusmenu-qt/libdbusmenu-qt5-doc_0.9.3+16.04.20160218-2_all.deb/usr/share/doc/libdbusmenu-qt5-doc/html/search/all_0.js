var searchData=
[
  ['actionactivationrequested',['actionActivationRequested',['../classDBusMenuImporter.html#a0a5f1113b4043c14bc2470913bb68fb5',1,'DBusMenuImporter']]],
  ['activateaction',['activateAction',['../classDBusMenuExporter.html#a1f46461c1cc4d4231cc98ad345dcfd5b',1,'DBusMenuExporter']]]
];
