var searchData=
[
  ['setstatus',['setStatus',['../classDBusMenuExporter.html#a349fd1889de0f954c5cde0747acee025',1,'DBusMenuExporter']]],
  ['status',['status',['../classDBusMenuExporter.html#a3b197bbd9bd0bfb2f2bc914a81032bb7',1,'DBusMenuExporter']]]
];
