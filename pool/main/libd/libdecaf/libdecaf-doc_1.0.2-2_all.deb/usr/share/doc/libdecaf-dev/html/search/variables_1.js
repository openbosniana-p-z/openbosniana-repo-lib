var searchData=
[
  ['eddsa_5fbytes_0',['EDDSA_BYTES',['../classdecaf_1_1_ristretto_1_1_point.html#a1382ca4cb27e60bd11957b8dda91ff4e',1,'decaf::Ristretto::Point::EDDSA_BYTES()'],['../classdecaf_1_1_ed448_goldilocks_1_1_point.html#ac2059d6628ffad08f1b1c94d335dfff8',1,'decaf::Ed448Goldilocks::Point::EDDSA_BYTES()']]],
  ['eddsa_5fdecode_5fratio_1',['EDDSA_DECODE_RATIO',['../classdecaf_1_1_ristretto_1_1_point.html#a47a4400e15532d323e389620f51ec6fb',1,'decaf::Ristretto::Point::EDDSA_DECODE_RATIO()'],['../classdecaf_1_1_ed448_goldilocks_1_1_point.html#adb91c5c9461d72fea143be55bc274732',1,'decaf::Ed448Goldilocks::Point::EDDSA_DECODE_RATIO()']]],
  ['eddsa_5fencode_5fratio_2',['EDDSA_ENCODE_RATIO',['../classdecaf_1_1_ristretto_1_1_point.html#a59c7521583e84df44f5e68925a8b3a65',1,'decaf::Ristretto::Point::EDDSA_ENCODE_RATIO()'],['../classdecaf_1_1_ed448_goldilocks_1_1_point.html#a7b45ccb5d80c1ea29dac1fe7ad160ed5',1,'decaf::Ed448Goldilocks::Point::EDDSA_ENCODE_RATIO()']]],
  ['err_5fcode_3',['err_code',['../classdecaf_1_1_sponge_rng_1_1_rng_exception.html#a89dec20a9a28686d6dc8d19cc1d35d64',1,'decaf::SpongeRng::RngException']]]
];
