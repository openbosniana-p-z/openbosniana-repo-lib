var searchData=
[
  ['times_5ftwo_0',['times_two',['../classdecaf_1_1_ristretto_1_1_point.html#a5d7196e6e785be5452c0be8a650cf66e',1,'decaf::Ristretto::Point::times_two()'],['../classdecaf_1_1_ed448_goldilocks_1_1_point.html#a78f25711714b2b0b6f7e6571306bff2f',1,'decaf::Ed448Goldilocks::Point::times_two()']]]
];
