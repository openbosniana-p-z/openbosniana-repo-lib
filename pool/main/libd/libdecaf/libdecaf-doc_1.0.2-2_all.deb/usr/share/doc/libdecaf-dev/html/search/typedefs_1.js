var searchData=
[
  ['group_0',['Group',['../classdecaf_1_1_ed_d_s_a_3_01_ristretto_01_4_1_1_private_key_base.html#a01cbfd00c12d9e60ac8f07dd73038593',1,'decaf::EdDSA&lt; Ristretto &gt;::PrivateKeyBase::Group()'],['../classdecaf_1_1_ed_d_s_a_3_01_ristretto_01_4_1_1_public_key_base.html#a68d0f2aa7cfa1e8cdb92cd4189f12148',1,'decaf::EdDSA&lt; Ristretto &gt;::PublicKeyBase::Group()'],['../classdecaf_1_1_ed_d_s_a_3_01_ed448_goldilocks_01_4_1_1_private_key_base.html#aa0ca2f51ef041094d55359521c6ee87b',1,'decaf::EdDSA&lt; Ed448Goldilocks &gt;::PrivateKeyBase::Group()'],['../classdecaf_1_1_ed_d_s_a_3_01_ed448_goldilocks_01_4_1_1_public_key_base.html#a8126126630f5143c9db3d2bfe036abce',1,'decaf::EdDSA&lt; Ed448Goldilocks &gt;::PublicKeyBase::Group()']]]
];
