var searchData=
[
  ['removed_5fcofactor_0',['REMOVED_COFACTOR',['../structdecaf_1_1_ristretto.html#a87378adc7224347171cb323829cab6a9',1,'decaf::Ristretto::REMOVED_COFACTOR()'],['../structdecaf_1_1_ed448_goldilocks.html#a51533120f83ddb647df780c64a8dc05a',1,'decaf::Ed448Goldilocks::REMOVED_COFACTOR()']]]
];
