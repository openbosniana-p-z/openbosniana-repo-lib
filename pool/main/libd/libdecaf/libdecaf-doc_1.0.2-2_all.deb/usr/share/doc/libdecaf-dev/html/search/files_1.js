var searchData=
[
  ['decaf_2ec_0',['decaf.c',['../curve25519_2decaf_8c.html',1,'(Global Namespace)'],['../ed448goldilocks_2decaf_8c.html',1,'(Global Namespace)']]],
  ['decaf_2eh_1',['decaf.h',['../decaf_8h.html',1,'']]],
  ['decaf_2ehxx_2',['decaf.hxx',['../decaf_8hxx.html',1,'']]]
];
