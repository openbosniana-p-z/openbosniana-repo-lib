var searchData=
[
  ['decaf_5ferror_5ft_0',['decaf_error_t',['../common_8h.html#af9a5dd6af1ce6349e2b8f2cb632a0909',1,'common.h']]],
  ['deterministic_1',['Deterministic',['../classdecaf_1_1_sponge_rng.html#aeeb7b005bad3134ef77f07473fd01725',1,'decaf::SpongeRng']]]
];
