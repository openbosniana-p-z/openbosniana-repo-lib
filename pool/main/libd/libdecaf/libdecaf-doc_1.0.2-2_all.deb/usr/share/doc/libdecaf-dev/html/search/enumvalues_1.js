var searchData=
[
  ['prehashed_0',['PREHASHED',['../namespacedecaf.html#ab85adaec7be4434f74a380eb727b7f00a4d4b0ccf7c2146dafa97473e4e4f7be5',1,'decaf']]],
  ['pure_1',['PURE',['../namespacedecaf.html#ab85adaec7be4434f74a380eb727b7f00a164bc8ddd97db6d5e64c0c376861c8a3',1,'decaf']]]
];
