var searchData=
[
  ['name_0',['name',['../structdecaf_1_1_ristretto.html#a5aa45ea40bb9b6cf5d30adcbef552f93',1,'decaf::Ristretto::name()'],['../structdecaf_1_1_ed448_goldilocks.html#af5dbf2414b69ef51e054aa50d971d3df',1,'decaf::Ed448Goldilocks::name()']]],
  ['no_5fcontext_1',['NO_CONTEXT',['../structdecaf_1_1_ed_d_s_a_3_01_ristretto_01_4.html#a7447622aca00d9d33275c83d182b0542',1,'decaf::EdDSA&lt; Ristretto &gt;::NO_CONTEXT()'],['../structdecaf_1_1_ed_d_s_a_3_01_ed448_goldilocks_01_4.html#acf4acd0679115175b7cf2f53d1caa516',1,'decaf::EdDSA&lt; Ed448Goldilocks &gt;::NO_CONTEXT()']]],
  ['non_5fsecret_5fcombo_5fwith_5fbase_2',['non_secret_combo_with_base',['../classdecaf_1_1_ristretto_1_1_point.html#a57a00bed940e78619d8f9c0b30d2af03',1,'decaf::Ristretto::Point::non_secret_combo_with_base()'],['../classdecaf_1_1_ed448_goldilocks_1_1_point.html#a8cf8dc47d71d6b1e11a69b8862115779',1,'decaf::Ed448Goldilocks::Point::non_secret_combo_with_base()']]]
];
