var searchData=
[
  ['decaf_0',['decaf',['../namespacedecaf.html',1,'']]]
];
