var searchData=
[
  ['invert_5felligator_5fwhich_5fbits_0',['INVERT_ELLIGATOR_WHICH_BITS',['../classdecaf_1_1_ristretto_1_1_point.html#a1b2d92b4de7a0a4e04a92047ba3df039',1,'decaf::Ristretto::Point::INVERT_ELLIGATOR_WHICH_BITS()'],['../classdecaf_1_1_ed448_goldilocks_1_1_point.html#a09c9bcc2bacca3be8816ea917ff18c4f',1,'decaf::Ed448Goldilocks::Point::INVERT_ELLIGATOR_WHICH_BITS()']]]
];
