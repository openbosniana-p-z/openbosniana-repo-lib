var searchData=
[
  ['block_0',['Block',['../classdecaf_1_1_block.html',1,'decaf']]],
  ['buffer_1',['Buffer',['../classdecaf_1_1_buffer.html',1,'decaf']]]
];
