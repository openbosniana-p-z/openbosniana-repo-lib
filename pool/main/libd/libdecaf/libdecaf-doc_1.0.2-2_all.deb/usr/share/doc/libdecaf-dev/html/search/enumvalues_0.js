var searchData=
[
  ['decaf_5ffailure_0',['DECAF_FAILURE',['../common_8h.html#af9a5dd6af1ce6349e2b8f2cb632a0909a5b73cdd72c7426a6b3459433f9267ba2',1,'common.h']]],
  ['decaf_5fsuccess_1',['DECAF_SUCCESS',['../common_8h.html#af9a5dd6af1ce6349e2b8f2cb632a0909ab017b6e16314443ee4d0885f24b440e7',1,'common.h']]]
];
