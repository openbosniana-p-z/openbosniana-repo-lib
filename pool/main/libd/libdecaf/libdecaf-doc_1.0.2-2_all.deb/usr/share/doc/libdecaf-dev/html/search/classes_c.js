var searchData=
[
  ['vector_5faligned_0',['VECTOR_ALIGNED',['../struct_v_e_c_t_o_r___a_l_i_g_n_e_d.html',1,'']]],
  ['verification_3c_20crtp_2c_20prehashed_20_3e_1',['Verification&lt; CRTP, PREHASHED &gt;',['../classdecaf_1_1_ed_d_s_a_3_01_ed448_goldilocks_01_4_1_1_verification_3_01_c_r_t_p_00_01_p_r_e_h_a_s_h_e_d_01_4.html',1,'decaf::EdDSA&lt; Ed448Goldilocks &gt;::Verification&lt; CRTP, PREHASHED &gt;'],['../classdecaf_1_1_ed_d_s_a_3_01_ristretto_01_4_1_1_verification_3_01_c_r_t_p_00_01_p_r_e_h_a_s_h_e_d_01_4.html',1,'decaf::EdDSA&lt; Ristretto &gt;::Verification&lt; CRTP, PREHASHED &gt;']]],
  ['verification_3c_20crtp_2c_20pure_20_3e_2',['Verification&lt; CRTP, PURE &gt;',['../classdecaf_1_1_ed_d_s_a_3_01_ed448_goldilocks_01_4_1_1_verification_3_01_c_r_t_p_00_01_p_u_r_e_01_4.html',1,'decaf::EdDSA&lt; Ed448Goldilocks &gt;::Verification&lt; CRTP, PURE &gt;'],['../classdecaf_1_1_ed_d_s_a_3_01_ristretto_01_4_1_1_verification_3_01_c_r_t_p_00_01_p_u_r_e_01_4.html',1,'decaf::EdDSA&lt; Ristretto &gt;::Verification&lt; CRTP, PURE &gt;']]]
];
