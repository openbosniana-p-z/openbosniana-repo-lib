var searchData=
[
  ['decaf_5f255_5fpoint_5fbase_0',['decaf_255_point_base',['../point__255_8h.html#aae535e9ee480a8e2239a50e9498878f7',1,'point_255.h']]],
  ['decaf_5f255_5fpoint_5fidentity_1',['decaf_255_point_identity',['../point__255_8h.html#ad47e392174215196365d906140e18d51',1,'point_255.h']]],
  ['decaf_5f255_5fprecomputed_5fbase_2',['decaf_255_precomputed_base',['../point__255_8h.html#a449e4d25e8c72b4b68487a0c211f4dd7',1,'point_255.h']]],
  ['decaf_5f255_5fscalar_5fone_3',['decaf_255_scalar_one',['../point__255_8h.html#ac4e7f1e196e8eda8743c2b7fd9efb40f',1,'point_255.h']]],
  ['decaf_5f255_5fscalar_5fzero_4',['decaf_255_scalar_zero',['../point__255_8h.html#afa85d54f723ae18a8d7edbfa2290c8fc',1,'point_255.h']]],
  ['decaf_5f255_5fsizeof_5fprecomputed_5fs_5',['decaf_255_sizeof_precomputed_s',['../point__255_8h.html#adf3b582eeb8c2148e1d405b0784ec7e8',1,'point_255.h']]],
  ['decaf_5f448_5fpoint_5fbase_6',['decaf_448_point_base',['../point__448_8h.html#ac94b4d387967eb22ee12b032cc568a3f',1,'point_448.h']]],
  ['decaf_5f448_5fpoint_5fidentity_7',['decaf_448_point_identity',['../point__448_8h.html#ac4185e968fc363185cbd1066fe0ecf30',1,'point_448.h']]],
  ['decaf_5f448_5fprecomputed_5fbase_8',['decaf_448_precomputed_base',['../point__448_8h.html#ada9fc6acbbd0b942f360d2a41b8de8c2',1,'point_448.h']]],
  ['decaf_5f448_5fscalar_5fone_9',['decaf_448_scalar_one',['../point__448_8h.html#a841f32a6264ba871aaf48e5b673a8e4f',1,'point_448.h']]],
  ['decaf_5f448_5fscalar_5fzero_10',['decaf_448_scalar_zero',['../point__448_8h.html#ade7547013faa333a9290554913636097',1,'point_448.h']]],
  ['decaf_5f448_5fsizeof_5fprecomputed_5fs_11',['decaf_448_sizeof_precomputed_s',['../point__448_8h.html#afec38de085a8d1525f9ca6d1b8124b80',1,'point_448.h']]],
  ['decaf_5fx25519_5fbase_5fpoint_12',['decaf_x25519_base_point',['../point__255_8h.html#a3089c5e92ea2464b4577234b0660a735',1,'decaf_x25519_base_point():&#160;decaf.c'],['../curve25519_2decaf_8c.html#a0ce8fca56e231f711d69042202206b60',1,'decaf_x25519_base_point():&#160;decaf.c']]],
  ['decaf_5fx448_5fbase_5fpoint_13',['decaf_x448_base_point',['../point__448_8h.html#a90c825bb3afb91e90c13e426729a571a',1,'decaf_x448_base_point():&#160;decaf.c'],['../ed448goldilocks_2decaf_8c.html#a47ad0ac6dbaf903175759e37309483af',1,'decaf_x448_base_point():&#160;decaf.c']]],
  ['default_5foutput_5fbytes_14',['DEFAULT_OUTPUT_BYTES',['../classdecaf_1_1_s_h_a_k_e.html#a47b5078ab1a012acf500b29516dff473',1,'decaf::SHAKE::DEFAULT_OUTPUT_BYTES()'],['../classdecaf_1_1_s_h_a3.html#aa537d1af9058edc9075d0bdf3efee79f',1,'decaf::SHA3::DEFAULT_OUTPUT_BYTES()'],['../classdecaf_1_1_s_h_a512.html#a71ce1cb11fa648a12a6677e89c041cb4',1,'decaf::SHA512::DEFAULT_OUTPUT_BYTES()']]]
];
