var searchData=
[
  ['wrapped_0',['Wrapped',['../classdecaf_1_1_ristretto_1_1_scalar.html#a13269fb2e82cb9193de4f659c9afb7d1',1,'decaf::Ristretto::Scalar::Wrapped()'],['../classdecaf_1_1_ristretto_1_1_point.html#a3845e8e203bfa6de70b6e2ebdafb9929',1,'decaf::Ristretto::Point::Wrapped()'],['../classdecaf_1_1_ed448_goldilocks_1_1_scalar.html#ad3e0c0fdc8cdfa161017327454328ac7',1,'decaf::Ed448Goldilocks::Scalar::Wrapped()'],['../classdecaf_1_1_ed448_goldilocks_1_1_point.html#a2ae363956d75dd2cffa55f1f2e2c0b59',1,'decaf::Ed448Goldilocks::Point::Wrapped()']]]
];
