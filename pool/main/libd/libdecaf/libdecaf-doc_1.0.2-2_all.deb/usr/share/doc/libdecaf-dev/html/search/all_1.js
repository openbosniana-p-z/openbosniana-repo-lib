var searchData=
[
  ['api_5fns_0',['API_NS',['../curve25519_2decaf_8c.html#ac76cf2c5e2b7e74dafda618e3598c27d',1,'API_NS(point_identity):&#160;decaf.c'],['../ed448goldilocks_2decaf_8c.html#ac76cf2c5e2b7e74dafda618e3598c27d',1,'API_NS(point_identity):&#160;decaf.c']]],
  ['assign_1',['assign',['../classdecaf_1_1_buffer.html#aceabf9dd004f3f9a0cc76e04ef69e992',1,'decaf::Buffer']]]
];
