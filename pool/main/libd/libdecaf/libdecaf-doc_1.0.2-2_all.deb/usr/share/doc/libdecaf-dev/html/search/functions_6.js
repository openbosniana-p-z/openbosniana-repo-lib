var searchData=
[
  ['half_0',['half',['../classdecaf_1_1_ristretto_1_1_scalar.html#aa0aaedb747f43edb5e11ce98dfa9ab3e',1,'decaf::Ristretto::Scalar::half()'],['../classdecaf_1_1_ed448_goldilocks_1_1_scalar.html#a222bcae1e70b5a87c1502c6a4765a787',1,'decaf::Ed448Goldilocks::Scalar::half()']]],
  ['hash_1',['hash',['../classdecaf_1_1_s_h_a512.html#a15d94eeaddf0565bd4ed28592f734690',1,'decaf::SHA512::hash()'],['../classdecaf_1_1_s_h_a3.html#a8b6b01a999f1c5212eb294ee562e0141',1,'decaf::SHA3::hash()'],['../classdecaf_1_1_s_h_a_k_e.html#a24fb3ee363ba7ba1c41240134780ac51',1,'decaf::SHAKE::hash()']]]
];
