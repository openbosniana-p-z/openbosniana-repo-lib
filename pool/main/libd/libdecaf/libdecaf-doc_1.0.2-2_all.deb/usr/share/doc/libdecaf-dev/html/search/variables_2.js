var searchData=
[
  ['field_5fmodulus_5ftype_0',['FIELD_MODULUS_TYPE',['../structdecaf_1_1_ristretto.html#a94e4af1d35ab756140ee7adfd651ef51',1,'decaf::Ristretto::FIELD_MODULUS_TYPE()'],['../structdecaf_1_1_ed448_goldilocks.html#a5f69ae791b7c0466c8c56cc92bd9c6db',1,'decaf::Ed448Goldilocks::FIELD_MODULUS_TYPE()']]]
];
