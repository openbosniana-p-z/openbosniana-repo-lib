var searchData=
[
  ['lengthexception_0',['LengthException',['../classdecaf_1_1_length_exception.html',1,'decaf']]]
];
