var searchData=
[
  ['hash_5fbytes_0',['HASH_BYTES',['../classdecaf_1_1_ristretto_1_1_point.html#a0dd8544a45e7b38c3467bdc8bedbfd4c',1,'decaf::Ristretto::Point::HASH_BYTES()'],['../classdecaf_1_1_ed448_goldilocks_1_1_point.html#af05947529589e5ad8fa9f48bd30d9175',1,'decaf::Ed448Goldilocks::Point::HASH_BYTES()']]]
];
