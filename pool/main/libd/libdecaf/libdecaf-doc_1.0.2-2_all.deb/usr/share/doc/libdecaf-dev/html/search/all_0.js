var searchData=
[
  ['_5fxopen_5fsource_0',['_XOPEN_SOURCE',['../point__255_8hxx.html#a78c99ffd76a7bb3c8c74db76207e9ab4',1,'_XOPEN_SOURCE():&#160;point_255.hxx'],['../point__448_8hxx.html#a78c99ffd76a7bb3c8c74db76207e9ab4',1,'_XOPEN_SOURCE():&#160;point_448.hxx']]]
];
