var searchData=
[
  ['what_0',['what',['../classdecaf_1_1_crypto_exception.html#a22e9ac11f875325dd8a05e1d888c1839',1,'decaf::CryptoException::what()'],['../classdecaf_1_1_length_exception.html#ab2d538b83a605b86a15662c835d42e59',1,'decaf::LengthException::what()'],['../classdecaf_1_1_sponge_rng_1_1_rng_exception.html#ac4b4abaacbc0173799314c69a3574ccb',1,'decaf::SpongeRng::RngException::what()']]]
];
