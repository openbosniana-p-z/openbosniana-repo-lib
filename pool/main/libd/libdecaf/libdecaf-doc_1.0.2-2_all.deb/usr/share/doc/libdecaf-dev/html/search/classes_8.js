var searchData=
[
  ['niels_5fs_0',['niels_s',['../structniels__s.html',1,'']]],
  ['noinit_1',['NOINIT',['../structdecaf_1_1_n_o_i_n_i_t.html',1,'decaf']]]
];
