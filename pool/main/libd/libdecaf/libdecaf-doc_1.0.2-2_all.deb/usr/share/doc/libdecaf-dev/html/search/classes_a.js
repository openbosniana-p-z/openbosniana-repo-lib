var searchData=
[
  ['ristretto_0',['Ristretto',['../structdecaf_1_1_ristretto.html',1,'decaf']]],
  ['rng_1',['Rng',['../classdecaf_1_1_rng.html',1,'decaf']]],
  ['rngexception_2',['RngException',['../classdecaf_1_1_sponge_rng_1_1_rng_exception.html',1,'decaf::SpongeRng']]]
];
