var searchData=
[
  ['discid_5ffeature_5flength',['DISCID_FEATURE_LENGTH',['../discid_8h.html#a0019c8fa418d4196c5206301d71f686f',1,'discid.h']]],
  ['discid_5ffeature_5fstr_5fisrc',['DISCID_FEATURE_STR_ISRC',['../discid_8h.html#a55e5783cd08f22349b145c4ba7cccc53',1,'discid.h']]],
  ['discid_5ffeature_5fstr_5fmcn',['DISCID_FEATURE_STR_MCN',['../discid_8h.html#ac4fbcba568f1ec815274a0811cb22cfb',1,'discid.h']]],
  ['discid_5ffeature_5fstr_5fread',['DISCID_FEATURE_STR_READ',['../discid_8h.html#a0f9c8e474f60d72cc0b0c07c56e39eb9',1,'discid.h']]],
  ['discid_5fhave_5fsparse_5fread',['DISCID_HAVE_SPARSE_READ',['../discid_8h.html#a49890154062d019d3684c3ae2329acb6',1,'discid.h']]],
  ['discid_5fversion_5fmajor',['DISCID_VERSION_MAJOR',['../discid_8h.html#a3e62007202186ea549cd717e559307c3',1,'discid.h']]],
  ['discid_5fversion_5fminor',['DISCID_VERSION_MINOR',['../discid_8h.html#acf4c651ef2488365e9f6f1feb9af7ff0',1,'discid.h']]],
  ['discid_5fversion_5fnum',['DISCID_VERSION_NUM',['../discid_8h.html#ad2dc4d638ba809b8eeed0a0c2c280165',1,'discid.h']]],
  ['discid_5fversion_5fpatch',['DISCID_VERSION_PATCH',['../discid_8h.html#a5064a4af48f757aeb3313b83e3686655',1,'discid.h']]]
];
