var searchData=
[
  ['libdiscid_5fapi',['LIBDISCID_API',['../discid_8h.html#a3febad6285be3ab22c9f65e6d68236ae',1,'discid.h']]],
  ['libdiscid_5fdeprecated',['LIBDISCID_DEPRECATED',['../discid_8h.html#a73e09333ed2d7a60b65115110c532e84',1,'discid.h']]],
  ['libdiscid_5finternal',['LIBDISCID_INTERNAL',['../discid_8h.html#ae74679160ace07380f95a899d21f660c',1,'discid.h']]]
];
