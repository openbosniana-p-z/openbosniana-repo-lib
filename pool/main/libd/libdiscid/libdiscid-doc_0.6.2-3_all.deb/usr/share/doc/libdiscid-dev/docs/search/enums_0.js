var searchData=
[
  ['discid_5ffeature',['discid_feature',['../discid_8h.html#a3846137f36bef0a30da8952236636840',1,'discid.h']]]
];
