var searchData=
[
  ['xmlelemdef_5fst_62',['XmlElemDef_st',['../struct_xml_elem_def__st.html',1,'']]],
  ['xmleleminfo_5fst_63',['XmlElemInfo_st',['../struct_xml_elem_info__st.html',1,'']]]
];
