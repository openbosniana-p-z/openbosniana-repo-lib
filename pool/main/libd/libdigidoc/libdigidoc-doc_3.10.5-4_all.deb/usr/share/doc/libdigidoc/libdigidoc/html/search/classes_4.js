var searchData=
[
  ['notaryinfo_5fsk_118',['NotaryInfo_sk',['../struct_notary_info__sk.html',1,'']]]
];
