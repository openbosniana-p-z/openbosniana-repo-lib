var searchData=
[
  ['notaryinfo_5fsk_54',['NotaryInfo_sk',['../struct_notary_info__sk.html',1,'']]]
];
