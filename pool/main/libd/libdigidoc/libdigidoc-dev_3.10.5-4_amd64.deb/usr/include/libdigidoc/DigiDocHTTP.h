#include <libdigidoc/DigiDocMem.h>

int ddocGetHttpResponseCode(DigiDocMemBuf* pBuf);
int ddocGetHttpPayload(DigiDocMemBuf* pInBuf, DigiDocMemBuf* pOutBuf);
