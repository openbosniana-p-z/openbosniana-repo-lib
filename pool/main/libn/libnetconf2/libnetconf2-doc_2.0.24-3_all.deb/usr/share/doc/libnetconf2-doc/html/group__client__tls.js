var group__client__tls =
[
    [ "nc_client_tls_get_cert_key_paths", "group__client__tls.html#ga3169b1db61d04bc293e85a38469197e2", null ],
    [ "nc_client_tls_get_crl_paths", "group__client__tls.html#gae941da5a2540e5853fa2484467739c99", null ],
    [ "nc_client_tls_get_trusted_ca_paths", "group__client__tls.html#ga99a14909021769a53d8ccf94ee36f822", null ],
    [ "nc_client_tls_set_cert_key_paths", "group__client__tls.html#ga0761a5c4f0210956efce54e4ad3bddc0", null ],
    [ "nc_client_tls_set_crl_paths", "group__client__tls.html#gaaed486058a97a2d00fd96ed0758823be", null ],
    [ "nc_client_tls_set_trusted_ca_paths", "group__client__tls.html#ga3b38720437af9effce749007c144a0dd", null ],
    [ "nc_connect_libssl", "group__client__tls.html#gaaf63c97e1987d06f77bee5fe7fdae261", null ],
    [ "nc_connect_tls", "group__client__tls.html#ga5229189fd66b02088400c9b96e49e492", null ]
];