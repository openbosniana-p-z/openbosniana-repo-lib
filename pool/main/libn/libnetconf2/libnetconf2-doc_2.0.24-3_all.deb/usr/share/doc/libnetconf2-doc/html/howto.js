var howto =
[
    [ "Init and Thread-safety Information", "howtoinit.html", null ],
    [ "Client sessions", "howtoclient.html", [
      [ "SSH", "howtoclient.html#autotoc_md3", [
        [ "Client", "howtoinit.html#autotoc_md0", null ],
        [ "Server", "howtoinit.html#autotoc_md1", null ],
        [ "Functions List", "howtoinit.html#autotoc_md2", null ],
        [ "Functions List", "howtoclient.html#autotoc_md4", null ]
      ] ],
      [ "TLS", "howtoclient.html#autotoc_md5", [
        [ "Functions List", "howtoclient.html#autotoc_md6", null ]
      ] ],
      [ "FD and UNIX socket", "howtoclient.html#autotoc_md7", [
        [ "Funtions List", "howtoclient.html#autotoc_md8", null ]
      ] ],
      [ "Call Home", "howtoclient.html#autotoc_md9", [
        [ "Functions List", "howtoclient.html#autotoc_md10", null ]
      ] ],
      [ "Cleanup", "howtoclient.html#autotoc_md11", null ]
    ] ],
    [ "Server sessions", "howtoserver.html", [
      [ "Init", "howtoserver.html#autotoc_md12", [
        [ "Functions List", "howtoserver.html#autotoc_md13", null ]
      ] ],
      [ "SSH", "howtoserver.html#autotoc_md14", [
        [ "Functions List", "howtoserver.html#autotoc_md15", null ]
      ] ],
      [ "TLS", "howtoserver.html#autotoc_md16", [
        [ "Functions List", "howtoserver.html#autotoc_md17", null ]
      ] ],
      [ "FD", "howtoserver.html#autotoc_md18", [
        [ "Functions List", "howtoserver.html#autotoc_md19", null ]
      ] ],
      [ "Call Home", "howtoserver.html#autotoc_md20", [
        [ "Functions List", "howtoserver.html#autotoc_md21", null ]
      ] ],
      [ "Connecting And Cleanup", "howtoserver.html#autotoc_md22", [
        [ "Functions List", "howtoserver.html#autotoc_md23", null ]
      ] ]
    ] ],
    [ "Client communication", "howtoclientcomm.html", null ],
    [ "Server communication", "howtoservercomm.html", null ],
    [ "Timeouts", "howtotimeouts.html", null ]
];