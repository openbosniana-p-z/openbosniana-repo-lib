var group__client__ch__tls =
[
    [ "nc_client_tls_ch_add_bind_listen", "group__client__ch__tls.html#ga29527f80f008276ac74b2ae5dc5eaf59", null ],
    [ "nc_client_tls_ch_del_bind", "group__client__ch__tls.html#ga536cf5121a54bcb05794f30eb50ce491", null ],
    [ "nc_client_tls_ch_get_cert_key_paths", "group__client__ch__tls.html#ga7b1d6b51fc108054c9c621a5d1d86b4d", null ],
    [ "nc_client_tls_ch_get_crl_paths", "group__client__ch__tls.html#ga32e88481a822b1b33f867f770c0cf500", null ],
    [ "nc_client_tls_ch_get_trusted_ca_paths", "group__client__ch__tls.html#gaed325530c650ad348c7a6e89498ab56b", null ],
    [ "nc_client_tls_ch_set_cert_key_paths", "group__client__ch__tls.html#gaf50a58fc9d7a782de1b9ba8b5d7a3aad", null ],
    [ "nc_client_tls_ch_set_crl_paths", "group__client__ch__tls.html#ga37a34af46065868b525a944cdb4cd840", null ],
    [ "nc_client_tls_ch_set_trusted_ca_paths", "group__client__ch__tls.html#ga9c8ac17727290365c36bdd6c3a536a26", null ]
];