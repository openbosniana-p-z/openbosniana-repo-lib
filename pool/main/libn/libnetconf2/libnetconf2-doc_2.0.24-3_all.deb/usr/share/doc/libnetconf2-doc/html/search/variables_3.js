var searchData=
[
  ['nc_5fmsgtype2str_746',['nc_msgtype2str',['../group__misc.html#gab3b21a93e938387afe93bf5bf7b531a8',1,'netconf.h']]],
  ['ns_747',['ns',['../group__client__msg.html#a55c20ea9357df8a9e7317cc7fad3c6a9',1,'nc_err']]],
  ['ns_5fcount_748',['ns_count',['../group__client__msg.html#a7b6ee00e84a51cf2a41e245b6a97488d',1,'nc_err']]]
];
