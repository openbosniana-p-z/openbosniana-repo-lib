var searchData=
[
  ['severity_752',['severity',['../group__client__msg.html#a9cec66dea993be374034fbe84d5d99af',1,'nc_err']]],
  ['sid_753',['sid',['../group__client__msg.html#a3a1583f7c8c1666379f00fce6cfabd0c',1,'nc_err']]]
];
