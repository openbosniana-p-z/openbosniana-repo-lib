var group__client__msg_structnc__err =
[
    [ "apptag", "group__client__msg.html#a73e2fb626d3113524295d137ae0f06ea", null ],
    [ "attr", "group__client__msg.html#a2b41c832df914741015ae02ef2f4a3d1", null ],
    [ "attr_count", "group__client__msg.html#aa942b1e5edc1f3bbcd1b86052cf935bf", null ],
    [ "elem", "group__client__msg.html#aed838e5105592d8dce2aee2c787ea2ee", null ],
    [ "elem_count", "group__client__msg.html#a063221ae4a72c4ac22bb62dad5447279", null ],
    [ "message", "group__client__msg.html#a385cc559c6d8a6e13501f1d658916bab", null ],
    [ "message_lang", "group__client__msg.html#a57c7371883c647ac8b2b201123cf4b6f", null ],
    [ "ns", "group__client__msg.html#a55c20ea9357df8a9e7317cc7fad3c6a9", null ],
    [ "ns_count", "group__client__msg.html#a7b6ee00e84a51cf2a41e245b6a97488d", null ],
    [ "other", "group__client__msg.html#a61ebe050951364ee8c7406ec57627968", null ],
    [ "other_count", "group__client__msg.html#a5623a8ed49fe0012807cddaaba21730b", null ],
    [ "path", "group__client__msg.html#a5551546b07caf0f6935e95f7540d59b1", null ],
    [ "severity", "group__client__msg.html#a9cec66dea993be374034fbe84d5d99af", null ],
    [ "sid", "group__client__msg.html#a3a1583f7c8c1666379f00fce6cfabd0c", null ],
    [ "tag", "group__client__msg.html#a1478bebf9caa7e0716ac6d51574c22ab", null ],
    [ "type", "group__client__msg.html#abdccf61b8eef7e2febbe8d8c3bcd5f32", null ]
];