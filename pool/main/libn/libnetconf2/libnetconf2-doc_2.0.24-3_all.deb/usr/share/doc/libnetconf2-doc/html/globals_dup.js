var globals_dup =
[
    [ "n", "globals.html", null ],
    [ "s", "globals_s.html", null ]
];