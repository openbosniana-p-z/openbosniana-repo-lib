var globals_func =
[
    [ "n", "globals_func.html", null ]
];