var annotated_dup =
[
    [ "nc_err", "group__client__msg.html#structnc__err", "group__client__msg_structnc__err" ],
    [ "nc_rpc", "group__client__msg.html#structnc__rpc", null ]
];