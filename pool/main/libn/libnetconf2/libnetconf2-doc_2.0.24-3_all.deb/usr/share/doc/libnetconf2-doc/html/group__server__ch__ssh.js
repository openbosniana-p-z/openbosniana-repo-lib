var group__server__ch__ssh =
[
    [ "nc_server_ssh_ch_client_endpt_add_hostkey", "group__server__ch__ssh.html#gaf051361a2d9f810b3c2f987be09b2fb7", null ],
    [ "nc_server_ssh_ch_client_endpt_del_hostkey", "group__server__ch__ssh.html#gac653a8695d2824455c2e12add01ba11c", null ],
    [ "nc_server_ssh_ch_client_endpt_get_auth_methods", "group__server__ch__ssh.html#gaed3dab943f4dbc8048bf019e7d27e1c7", null ],
    [ "nc_server_ssh_ch_client_endpt_mov_hostkey", "group__server__ch__ssh.html#gac8b07f287aa0c0fbb5214ec9cc8c97b7", null ],
    [ "nc_server_ssh_ch_client_endpt_set_auth_attempts", "group__server__ch__ssh.html#ga9a4608f99ea510622f03814aa8e7fe87", null ],
    [ "nc_server_ssh_ch_client_endpt_set_auth_methods", "group__server__ch__ssh.html#ga0947ccfecebac6dc5db18897c6df8cff", null ],
    [ "nc_server_ssh_ch_client_endpt_set_auth_timeout", "group__server__ch__ssh.html#ga476298c27820821a645ce754b9c3842f", null ]
];