var group__server__tls =
[
    [ "nc_server_tls_endpt_add_ctn", "group__server__tls.html#ga894700b977a25fdd8851dd594c914acf", null ],
    [ "nc_server_tls_endpt_add_trusted_cert_list", "group__server__tls.html#ga5038b707ff6023dc5d05db7173e0ce64", null ],
    [ "nc_server_tls_endpt_clear_crls", "group__server__tls.html#gac91091901d0fc8b34f928b7572fc3e3e", null ],
    [ "nc_server_tls_endpt_del_ctn", "group__server__tls.html#ga5c47c1573f72c32d7b89a930eb0da770", null ],
    [ "nc_server_tls_endpt_del_trusted_cert_list", "group__server__tls.html#gad773dae9b98a2cdc926443816732e5cf", null ],
    [ "nc_server_tls_endpt_get_ctn", "group__server__tls.html#gabf0533583b414df95b3cd4bbc313dd53", null ],
    [ "nc_server_tls_endpt_set_crl_paths", "group__server__tls.html#ga72707a6357e24be959fb770c2fae7494", null ],
    [ "nc_server_tls_endpt_set_server_cert", "group__server__tls.html#ga39cd1d17dd7e7dd4d62e1793ec142307", null ],
    [ "nc_server_tls_endpt_set_trusted_ca_paths", "group__server__tls.html#gaec87982fbeb2d1ead706316034220559", null ],
    [ "nc_server_tls_set_server_cert_chain_clb", "group__server__tls.html#gafc56337c7c8a114e09cc37475df59c6d", null ],
    [ "nc_server_tls_set_server_cert_clb", "group__server__tls.html#ga6a6df2abd5e313974b4ac3ae472c4efe", null ],
    [ "nc_server_tls_set_trusted_cert_list_clb", "group__server__tls.html#ga3e39c3f93c472d1c2006a74ac4acd99a", null ],
    [ "nc_server_tls_set_verify_clb", "group__server__tls.html#ga00437ff0d5ffc5e6ceda43ed53aa04fb", null ],
    [ "nc_session_get_client_cert", "group__server__tls.html#ga1869da4fff74fd944da75a787458a638", null ]
];