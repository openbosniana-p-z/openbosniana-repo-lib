var searchData=
[
  ['path_456',['path',['../group__client__msg.html#a5551546b07caf0f6935e95f7540d59b1',1,'nc_err']]]
];
