var group__server__ch__tls =
[
    [ "nc_server_tls_ch_client_endpt_add_ctn", "group__server__ch__tls.html#ga40afab05795acb744668ee805c3987e2", null ],
    [ "nc_server_tls_ch_client_endpt_add_trusted_cert_list", "group__server__ch__tls.html#ga938ac3af5dff0feb7bd0418a2a8ccf39", null ],
    [ "nc_server_tls_ch_client_endpt_clear_crls", "group__server__ch__tls.html#gaf8b312b22ab77ca351462cfac59c854f", null ],
    [ "nc_server_tls_ch_client_endpt_del_ctn", "group__server__ch__tls.html#ga8a03181e0b49bb408e71ab375106309f", null ],
    [ "nc_server_tls_ch_client_endpt_del_trusted_cert_list", "group__server__ch__tls.html#ga523e2465fc47810a0dca1e8a6f0a9dcb", null ],
    [ "nc_server_tls_ch_client_endpt_get_ctn", "group__server__ch__tls.html#gab609eb65773b533eb6db5f80ebdf8496", null ],
    [ "nc_server_tls_ch_client_endpt_set_crl_paths", "group__server__ch__tls.html#ga0c461367b11ed267cea60e77e32f9910", null ],
    [ "nc_server_tls_ch_client_endpt_set_server_cert", "group__server__ch__tls.html#ga0ccf49774dde79e3a80cadf812fa91e1", null ],
    [ "nc_server_tls_ch_client_endpt_set_trusted_ca_paths", "group__server__ch__tls.html#ga2b5fbc6522f38ccfd3a239e083881aa0", null ]
];