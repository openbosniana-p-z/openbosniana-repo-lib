var searchData=
[
  ['nc_5ferr_479',['nc_err',['../group__client__msg.html#structnc__err',1,'']]],
  ['nc_5frpc_480',['nc_rpc',['../group__client__msg.html#structnc__rpc',1,'']]]
];
