var searchData=
[
  ['messages_5fclient_2eh_483',['messages_client.h',['../messages__client_8h.html',1,'']]],
  ['messages_5fserver_2eh_484',['messages_server.h',['../messages__server_8h.html',1,'']]]
];
