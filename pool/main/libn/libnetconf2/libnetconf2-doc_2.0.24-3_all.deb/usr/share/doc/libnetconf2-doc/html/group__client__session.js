var group__client__session =
[
    [ "nc_client_session_set_not_strict", "group__client__session.html#ga964147343483e599e380a13bb516ba92", null ],
    [ "nc_connect_inout", "group__client__session.html#ga55ff3e00ccd759e52ac8d47fd22a142f", null ],
    [ "nc_connect_unix", "group__client__session.html#gaaa62a2e58a6adfe7b9248b82db5e9db3", null ],
    [ "nc_recv_notif", "group__client__session.html#ga0c554afd7a93b3eb5d69d1ab5fef4c00", null ],
    [ "nc_recv_notif_dispatch", "group__client__session.html#gab0e8a0e2e4a9a5a49f58bad373638c11", null ],
    [ "nc_recv_reply", "group__client__session.html#ga3cfe333eeb6dea6fa85d0a9794ab7d7a", null ],
    [ "nc_send_rpc", "group__client__session.html#gaeac0805b9a2f6538244c52eead088612", null ],
    [ "nc_session_cpblt", "group__client__session.html#ga33f60a29dd978a1597343838892e14ab", null ],
    [ "nc_session_get_cpblts", "group__client__session.html#ga260de4221f7640ecc16726147b0e83bd", null ],
    [ "nc_session_ntf_thread_running", "group__client__session.html#ga12c8430f6e926475b3415bd6ea820030", null ]
];