var modules =
[
    [ "Client", "group__client.html", "group__client" ],
    [ "Miscellaneous", "group__misc.html", "group__misc" ],
    [ "Server", "group__server.html", "group__server" ]
];