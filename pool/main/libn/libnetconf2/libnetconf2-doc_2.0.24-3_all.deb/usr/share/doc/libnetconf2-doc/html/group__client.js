var group__client =
[
    [ "Client Messages", "group__client__msg.html", "group__client__msg" ],
    [ "Client SSH", "group__client__ssh.html", "group__client__ssh" ],
    [ "Client Session", "group__client__session.html", "group__client__session" ],
    [ "Client TLS", "group__client__tls.html", "group__client__tls" ],
    [ "Client-side Call Home", "group__client__ch.html", "group__client__ch" ],
    [ "nc_client_destroy", "group__client.html#ga67c9122420e67cc7a19d595392c3bc46", null ],
    [ "nc_client_get_schema_callback", "group__client.html#gabbd7f5f1130befac0c01d6e66a02130d", null ],
    [ "nc_client_get_schema_searchpath", "group__client.html#ga6cc801e8b6960626cc53d961a3c44a49", null ],
    [ "nc_client_get_thread_context", "group__client.html#gafe213d16f2d871916b5f28612c18942e", null ],
    [ "nc_client_init", "group__client.html#ga079a86d8e195364863c7e73edf53fab3", null ],
    [ "nc_client_set_schema_callback", "group__client.html#gab0b9289a6c1ffda6b9e67045cf91a963", null ],
    [ "nc_client_set_schema_searchpath", "group__client.html#ga4fb8b91a9bd992e1fe3008245302edda", null ],
    [ "nc_client_set_thread_context", "group__client.html#gadf94877987fb872f6fa56ec1a4e1010f", null ]
];