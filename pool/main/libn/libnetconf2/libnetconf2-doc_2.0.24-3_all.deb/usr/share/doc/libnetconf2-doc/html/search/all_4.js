var searchData=
[
  ['init_20and_20thread_2dsafety_20information_17',['Init and Thread-safety Information',['../howtoinit.html',1,'howto']]]
];
