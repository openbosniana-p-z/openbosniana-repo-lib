var group__client__ssh =
[
    [ "nc_client_ssh_add_keypair", "group__client__ssh.html#ga676977cabea600fa524cff1ef9aeb951", null ],
    [ "nc_client_ssh_del_keypair", "group__client__ssh.html#gae28cec314b42004cbc64279bde4a9dad", null ],
    [ "nc_client_ssh_get_auth_hostkey_check_clb", "group__client__ssh.html#gaac5d596105699eac6147562ff8da8bd0", null ],
    [ "nc_client_ssh_get_auth_interactive_clb", "group__client__ssh.html#ga6e0912657dc05edd4521554678e35394", null ],
    [ "nc_client_ssh_get_auth_password_clb", "group__client__ssh.html#gaf260a13664e20243fd66e96a4d97a0de", null ],
    [ "nc_client_ssh_get_auth_pref", "group__client__ssh.html#ga30df0b3372b956b430318683b6c4c27c", null ],
    [ "nc_client_ssh_get_auth_privkey_passphrase_clb", "group__client__ssh.html#gafaee1da571a6a0d1a257b2c723525809", null ],
    [ "nc_client_ssh_get_keypair", "group__client__ssh.html#gafafd71069800ff71b3cbb3958b8c46ee", null ],
    [ "nc_client_ssh_get_keypair_count", "group__client__ssh.html#gaf81236894c0a7e826d627674f86618ab", null ],
    [ "nc_client_ssh_get_username", "group__client__ssh.html#gae62c896ec0ac431dc65af5fbe816ba29", null ],
    [ "nc_client_ssh_set_auth_hostkey_check_clb", "group__client__ssh.html#ga5ae08201dc77968e070bfcf2a38c6577", null ],
    [ "nc_client_ssh_set_auth_interactive_clb", "group__client__ssh.html#ga8cdc998a93eeebd411c523fcdb2a1b80", null ],
    [ "nc_client_ssh_set_auth_password_clb", "group__client__ssh.html#gaeaa72b5c11147878014b764e06b8a84b", null ],
    [ "nc_client_ssh_set_auth_pref", "group__client__ssh.html#gab503461385ccb144c2d56942bca004a8", null ],
    [ "nc_client_ssh_set_auth_privkey_passphrase_clb", "group__client__ssh.html#ga2ebe8b3af12505b95d3deb705e1a5fa7", null ],
    [ "nc_client_ssh_set_username", "group__client__ssh.html#ga8062fd4f6c2ccc0d97233452fcc14880", null ],
    [ "nc_connect_libssh", "group__client__ssh.html#ga1bbe7a77d2e457faa47ace14fafb5518", null ],
    [ "nc_connect_ssh", "group__client__ssh.html#ga3518cae8e29dc63affafe8b943470620", null ],
    [ "nc_connect_ssh_channel", "group__client__ssh.html#ga7883c8335f4cb2f48947e8aa656b93c4", null ]
];