var group__server__ssh =
[
    [ "nc_server_ssh_add_authkey", "group__server__ssh.html#gaa75ef2594b0482daa1220a22de2076de", null ],
    [ "nc_server_ssh_add_authkey_path", "group__server__ssh.html#ga401ad78bcefafc68072d98cd212ef4a2", null ],
    [ "nc_server_ssh_del_authkey", "group__server__ssh.html#ga982388e2d98ab5e5c4ff45760dad9a8a", null ],
    [ "nc_server_ssh_endpt_add_hostkey", "group__server__ssh.html#gacf18429cdd8eead88855fc67ddbda50f", null ],
    [ "nc_server_ssh_endpt_del_hostkey", "group__server__ssh.html#ga133a80ca2ca7211022d9a2a92d07571d", null ],
    [ "nc_server_ssh_endpt_get_auth_methods", "group__server__ssh.html#ga7331d0c8e580bdaebe6006b7b1e1f9a7", null ],
    [ "nc_server_ssh_endpt_mod_hostkey", "group__server__ssh.html#gad78e5a830ff3a10107a6d9879577a066", null ],
    [ "nc_server_ssh_endpt_mov_hostkey", "group__server__ssh.html#gaae72bffd6eae50824888c2a5e97c3aac", null ],
    [ "nc_server_ssh_endpt_set_auth_attempts", "group__server__ssh.html#ga1d095f4d473c5d1f4eaa23f4bd2d1e1a", null ],
    [ "nc_server_ssh_endpt_set_auth_methods", "group__server__ssh.html#ga53dd8a70aece6485bb390363106d5479", null ],
    [ "nc_server_ssh_endpt_set_auth_timeout", "group__server__ssh.html#gaece6a012a6c36ee31ad40b6cbb9bafe5", null ],
    [ "nc_server_ssh_set_hostkey_clb", "group__server__ssh.html#ga2a9fb8a9da8d7705f4dc3c4b885fb3e4", null ],
    [ "nc_server_ssh_set_interactive_auth_clb", "group__server__ssh.html#ga8c818afd2c61fa6c7b6e471aec4dfc57", null ],
    [ "nc_server_ssh_set_passwd_auth_clb", "group__server__ssh.html#gafa6fefe02e56b3b881b75f0388fc95f9", null ],
    [ "nc_server_ssh_set_pubkey_auth_clb", "group__server__ssh.html#ga278a8b8164229d5550a9ffc7f4f6d33c", null ]
];