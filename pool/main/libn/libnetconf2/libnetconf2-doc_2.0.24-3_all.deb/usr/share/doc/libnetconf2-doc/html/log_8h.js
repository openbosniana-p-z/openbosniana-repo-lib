var log_8h =
[
    [ "NC_VERB_LEVEL", "group__misc.html#ga24cfbe0a23493bf9e0da67104523743d", null ],
    [ "NC_VERB_LEVEL", "group__misc.html#ga921d994eb69a9efd93ef85cf4a6cd060", [
      [ "NC_VERB_ERROR", "group__misc.html#gga921d994eb69a9efd93ef85cf4a6cd060a908c5d51b81e0ab37d2c57e569446d9b", null ],
      [ "NC_VERB_WARNING", "group__misc.html#gga921d994eb69a9efd93ef85cf4a6cd060a4a0cbb6bc660d3a50c3dff6028185abf", null ],
      [ "NC_VERB_VERBOSE", "group__misc.html#gga921d994eb69a9efd93ef85cf4a6cd060ae023b386220c2337dc9a556f5c669172", null ],
      [ "NC_VERB_DEBUG", "group__misc.html#gga921d994eb69a9efd93ef85cf4a6cd060a1ddf66190b3b38c4de213321e3ae6491", null ],
      [ "NC_VERB_DEBUG_LOWLVL", "group__misc.html#gga921d994eb69a9efd93ef85cf4a6cd060a298efbf60bbbd99808496bfc3005eda0", null ]
    ] ],
    [ "nc_libssh_thread_verbosity", "group__misc.html#ga7e40ae2cc4541132768700fa6f4a0133", null ],
    [ "nc_set_print_clb", "group__misc.html#gab629207387c036006b8c617634daa34a", null ],
    [ "nc_set_print_clb_session", "group__misc.html#gac18d3d43c983b578fb7a1b96f9dd691c", null ],
    [ "nc_verbosity", "group__misc.html#gadd8fd7b3bb2e7cba580c9a4229fe02d7", null ]
];