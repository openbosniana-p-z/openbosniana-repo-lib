var searchData=
[
  ['message_20',['message',['../group__client__msg.html#a385cc559c6d8a6e13501f1d658916bab',1,'nc_err']]],
  ['message_5flang_21',['message_lang',['../group__client__msg.html#a57c7371883c647ac8b2b201123cf4b6f',1,'nc_err']]],
  ['messages_5fclient_2eh_22',['messages_client.h',['../messages__client_8h.html',1,'']]],
  ['messages_5fserver_2eh_23',['messages_server.h',['../messages__server_8h.html',1,'']]],
  ['miscellaneous_24',['Miscellaneous',['../group__misc.html',1,'']]]
];
