package Net::FastCGI;

use strict;
use warnings;

our $VERSION = '0.14';

use Net::FastCGI::Constant;
use Net::FastCGI::Protocol;

1;

