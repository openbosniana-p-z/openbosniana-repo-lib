package Net::FreeDBConnection;

use parent qw/Net::Cmd IO::Socket::INET/;
our $VERSION = '0.01';

1;
