# -*- encoding: UTF-8 -*-
r"""
^0 μηδέν
1 ένα
2 δύο
3 τρία
4 τέσσερα
5 πέντε
6 έξι
7 επτά
8 οκτώ
9 εννέα
10 δέκα
11 έντεκα
12 δώδεκα
1(\d) δεκα$1
2(\d) είκοσι[ $1]
3(\d) τριάντα[ $1]
4(\d) σαράντα[ $1]
5(\d) πενήντα[ $1]
6(\d) εξήντα$1
7(\d) εβδομήντα[ $1]
8(\d) ογδόντα[ $1]
9(\d) ενενήντα[ $1]
1(\d\d) εκατό[v $1]
2(\d\d) διακόσια[ $1]
3(\d\d) τριακόσια[ $1]
4(\d\d) τετρακόσια[ $1]
5(\d\d) πεντακόσια[ $1]
6(\d\d) εξακόσια[ $1]
7(\d\d) επτακόσια[ $1]
8(\d\d) οκτακόσια[ $1]
9(\d\d) εννιακόσια[ $1]
1(\d{3}) χίλια[ $1]
(\d{1,3})(\d{3}) $(cardinal-feminine \1) χιλιάδες[ $2]
1(\d{6}) ένα εκατομμύριο[ $1]
(\d{1,3})(\d{6}) $1 εκατομμύρια[ $2]
1(\d{9}) ένα δισεκατομμύριο[ $1]
(\d{1,3})(\d{9}) $1 δισεκατομμύρια[ $2]
1(\d{12}) ένα τρισεκατομμύριο[ $1]
(\d{1,3})(\d{12}) $1 τρισεκατομμύρια[ $2]
1(\d{15}) ένα τετράκις εκατομμύριο[ $1]
(\d{1,3})(\d{15}) $1 τετράκις εκατομμύρια[ $2]
1(\d{18}) ένα πεντάκις εκατομμύριο[ $1]
(\d{1,3})(\d{18}) $1 πεντάκις εκατομμύρια[ $2]
1(\d{21}) ένα εξάκις εκατομμύριο[ $1]
(\d{1,3})(\d{21}) $1 εξάκις εκατομμύρια[ $2]
1(\d{24}) ένα επτάκις εκατομμύριο[ $1]
(\d{1,3})(\d{24}) $1 επτάκις εκατομμύρια[ $2]

# negative number

[-−](\d+) μείον |$1

# decimals

"([-−]?\d+)[.,]" "$1| κόμμα"
"([-−]?\d+[.,]\d*)(\d)" $1| |$2

# currency

# unit/subunit singular/plural

us:([^,]*),([^,]*),([^,]*),([^,]*) \1
up:([^,]*),([^,]*),([^,]*),([^,]*) \2
ss:([^,]*),([^,]*),([^,]*),([^,]*) \3
sp:([^,]*),([^,]*),([^,]*),([^,]*) \4

CHF:(\D+) $(\1: ελβετικό φράγκο, ελβετικό φράγκο, σαντίμ, σαντίμ)
GBP:(\D+) $(\1: λίρα στερλίνα, λίρα στερλίνα, πέννα, πένες)
JPY:(\D+) $(\1: γιεν, γιεν, σεν, σεν)
EUR:(\D+) $(\1: ευρώ, ευρώ, λεπτό, λεπτά)
USD:(\D+) $(\1: δολάριο ΗΠΑ, δολαρίων ΗΠΑ, σεντ, σεντς)

"([A-Z]{3}) ([-−]?1)([.,]00?)?" $2$(\1:us)
"([A-Z]{3}) ([-−]?\d+)([.,]00?)?" $2$(\1:up)
"(([A-Z]{3}) [-−]?\d+)[.,](01)" $1 και |$(1)$(\2:ss)
"(([A-Z]{3}) [-−]?\d+)[.,](\d)" $1 και |$(\30)$(\2:sp)
"(([A-Z]{3}) [-−]?\d+)[.,](\d\d)" $1 και |$3$(\2:sp)

== cardinal-neuter ==

(\d+) $1

== cardinal-feminine ==

1 μια
3 τρεις
4 τέσσερις
(\d) $1
1([34]) $(10)$(cardinal-feminine \2)
(\d)([34]) $(\10) $(cardinal-feminine \2)
(\d\d) $1
1(\d\d) $(100)[ $(cardinal-feminine \1)]
2(\d\d) διακόσιες[ $(cardinal-feminine \1)]
3(\d\d) τριακόσιες[ $(cardinal-feminine \1)]
4(\d\d) τετρακόσιες[ $(cardinal-feminine \1)]
5(\d\d) πεντακόσιες[ $(cardinal-feminine \1)]
6(\d\d) εξακόσιες[ $(cardinal-feminine \1)]
7(\d\d) επτακόσιες[ $(cardinal-feminine \1)]
8(\d\d) οκτακόσιες[ $(cardinal-feminine \1)]
9(\d\d) εννιακόσιες[ $(cardinal-feminine \1)]
1(\d{3}) χίλιες[ $(cardinal-feminine \1)]
(\d{1,3})(\d{3}) $(cardinal-feminine \1) χίλιάδες[ $(cardinal-feminine \2)]
(\d+000)(\d{3}) $(\1000)[ $(cardinal-feminine \2)]
(\d+)(\d{6}) $(\1000000)[ $(cardinal-feminine \2)]

== cardinal-masculine ==

1 ένας
3 τρεις
4 τέσσερα
(\d) $1
1([34]) $(10)$(cardinal-masculine \2)
(\d)([34]) $(\10) $(cardinal-masculine \2)
(\d\d) $1
1(\d\d) εκατό[ν $(cardinal-masculine \1)]
2(\d\d) διακόσιοι[ $(cardinal-masculine \1)]
3(\d\d) τριακόσιοι[ $(cardinal-masculine \1)]
4(\d\d) τετρακόσιοι[ $(cardinal-masculine \1)]
5(\d\d) πεντακόσιοι[ $(cardinal-masculine \1)]
6(\d\d) εξακόσιοι[ $(cardinal-masculine \1)]
7(\d\d) επτακόσιοι[ $(cardinal-masculine \1)]
8(\d\d) οκτακόσιοι[ $(cardinal-masculine \1)]
9(\d\d) εννιακόσιοι[ $(cardinal-masculine \1)]
1(\d{3}) χίλιοι[ $(cardinal-masculine \1)]
(\d{1,3})(\d{3}) $(cardinal-feminine \1000)[ $(cardinal-masculine \2)]
(\d+000)(\d{3}) $(\1000)[ $(cardinal-masculine \2)]
(\d+)(\d{6}) $(\1000000)[ $(cardinal-masculine \2)]

== to-feminine ==

(.*)ος(.*)	$(to-feminine \1η\2)
(.*)ός(.*)	$(to-feminine \1ή\2)
(.*)		\1

== to-neuter ==

(.*)ος(.*)	$(to-neuter \1ο\2)
(.*)ός(.*)	$(to-neuter \1ό\2)
(.*)		\1

== ordinal(-masculine)? ==

^0 μηδενικός
1 πρώτος
2 δεύτερος
3 τρίτος
4 τέταρτος
5 πέμπτος
6 έκτος
7 έβδομος
8 όγδοος
9 ένατος
10 δέκατος
11 ενδέκατος
12 δωδέκατος
1(\d) δέκατος $(ordinal \2)
2(\d) εικοστός[ $(ordinal \2)]
3(\d) τριακοστός[ $(ordinal \2)]
4(\d) τεσσαρακοστός[ $(ordinal \2)]
5(\d) πεντηκοστός[ $(ordinal \2)]
6(\d) εξηκοστός[ $(ordinal \2)]
7(\d) εβδομηκοστός[ $(ordinal \2)]
8(\d) ογδοηκοστός[ $(ordinal \2)]
9(\d) εννενηκοστός[ $(ordinal \2)]
1(\d\d) εκατοστός[ $(ordinal \2)]
2(\d\d) διακοσιοστός[ $(ordinal \2)]
3(\d\d) τριακοσιοστός[ $(ordinal \2)]
4(\d\d) τετρακοσιοστός[ $(ordinal \2)]
5(\d\d) πεντακοσιοστός[ $(ordinal \2)]
6(\d\d) εξακοσιοστός[ $(ordinal \2)]
7(\d\d) επτακοσιοστός[ $(ordinal \2)]
8(\d\d) οκτακοσιοστός[ $(ordinal \2)]
9(\d\d) εννεακοσιοστός[ $(ordinal \2)]
1(\d{3}) χιλιοστός[ $(ordinal \2)]
2(\d{3}) δισχιλιοστός[ $(ordinal \2)]
3(\d{3}) τρισχιλιοστός[ $(ordinal \2)]
4(\d{3}) τετράκις χιλιοστός[ $(ordinal \2)]
5(\d{3}) πεντάκις χιλιοστός[ $(ordinal \2)]
6(\d{3}) εξάκις χιλιοστός[ $(ordinal \2)]
7(\d{3}) επτάκις χιλιοστός[ $(ordinal \2)]
8(\d{3}) οκτάκις χιλιοστός[ $(ordinal \2)]
9(\d{3}) εννεάκις χιλιοστός[ $(ordinal \2)]
(\d)?10(\d{3}) [$(\200) ]δεκάκις χιλιοστός[ $(ordinal \3)]
(\d{1,3})(\d{3}) $2 χιλιοστός[ $(ordinal \3)]
(\d{1,3})(\d{6}) $2 εκατομμυριοστός[ $(ordinal \3)]
(\d{1,3})(\d{9}) $2 δισεκατομμυριοστός[ $(ordinal \3)]
(\d{1,3})(\d{12}) $2 τρισεκατομμυριοστός[ $(ordinal \3)]
(\d{1,3})(\d{15}) $2 τετράκις εκατομμυριοστός[ $(ordinal \3)]
(\d{1,3})(\d{18}) $2 πεντάκις εκατομμυριοστός[ $(ordinal \3)]
(\d{1,3})(\d{21}) $2 εξάκις εκατομμυριοστός[ $(ordinal \3)]
(\d{1,3})(\d{24}) $2 επτάκις εκατομμυριοστός[ $(ordinal \3)]

== ordinal-feminine ==

(\d+)	$(to-feminine $(ordinal \1))

== ordinal-neuter ==

(\d+)	$(to-neuter $(ordinal \1))

== ordinal-number(-masculine)? ==

(\d*10)	\2ος
(\d*0)	\2ός
(\d+)	\2ος

== ordinal-number-feminine ==

(\d+)	$(to-feminine $(ordinal-number \1))

== ordinal-number-neuter ==

(\d+)	$(to-neuter $(ordinal-number \1))

== help ==

"" |$(1)|, |$(2)|, |$(3)|\n$(help cardinal-neuter)$(help cardinal-feminine)$(help cardinal-masculine)$(help ordinal)$(help ordinal-neuter)$(help ordinal-feminine)$(help ordinal-masculine)$(help ordinal-number)$(help ordinal-number-neuter)$(help ordinal-number-feminine)$(help ordinal-number-masculine)
(.*) \1: |$(\1 1)|, |$(\1 2)|, |$(\1 3)|\n
"""
from __future__ import unicode_literals
