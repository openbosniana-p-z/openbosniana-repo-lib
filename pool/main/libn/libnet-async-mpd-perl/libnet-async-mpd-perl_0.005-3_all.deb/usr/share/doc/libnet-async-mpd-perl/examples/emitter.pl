#!/usr/bin/perl

use strict;
use warnings;

use Net::Async::MPD;

# use Log::Any::Adapter;
# Log::Any::Adapter->set( 'Stderr', log_level => 'trace' );

my $mpd = Net::Async::MPD->new(
  $ARGV[0] ? ( host => $ARGV[0] ) : (),
  auto_connect => 1,
);

$mpd->on( close => sub { $mpd->noidle });

foreach my $event (qw(
    database update stored_playlist playlist player
    mixer output sticker subscription message
  )) {

  $mpd->on( $event => sub { print "$event changed\n" });
}

$mpd->idle->get;
