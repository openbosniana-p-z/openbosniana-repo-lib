#!/usr/bin/perl
use strict;
use warnings;

use Net::Libdnet6;

print addr_net6("fe80::213:a9ff:fe2c:5ba3/64")."\n";
