
# Globals for Ace::Browser::SiteDefs
# these get loaded into whatever package requires them (old style)
package Ace::Browser::LocalSiteDefs;
require Exporter;
@ISA = qw(Exporter);
@EXPORT   = qw();
@EXPORT_OK = qw($SITE_DEFS $CGI_PATH $HTML_PATH);
$SITE_DEFS = '/build/libace-perl-o7n1qY/libace-perl-1.92/debian/libace-perl/etc/libace-perl';
$CGI_PATH  = '/build/libace-perl-o7n1qY/libace-perl-1.92/debian/libace-perl/usr/lib/cgi-bin';
$HTML_PATH = '/build/libace-perl-o7n1qY/libace-perl-1.92/debian/libace-perl/usr/share/libace-perl';
1;
__END__
=head1 NAME

Ace::Browser::LocalSiteDefs - Master Configuration file for AceBrowser

=head1 SYNOPSIS

 use Ace::Browser::LocalSiteDefs qw(  );

=head1 DESCRIPTION

This file, which is created at install time, defines three exportable
variables:

    Location of the directory that hold's AceBrowser's database-specific
              configuration files, e.g. /usr/local/apache/conf/ace/

    Location of AceBrowser's HTML files and images, e.g. ~www/htdocs/ace/

     Location of AceBrowser's CGI scripts, e.g. ~www/cgi-bin/ace/

=head1 SEE ALSO

L<Ace>

=head1 AUTHOR

Lincoln Stein <lstein@cshl.org>

Copyright (c) 1997-1998 Cold Spring Harbor Laboratory

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.  See DISCLAIMER.txt for
disclaimers of warranty.

=cut


