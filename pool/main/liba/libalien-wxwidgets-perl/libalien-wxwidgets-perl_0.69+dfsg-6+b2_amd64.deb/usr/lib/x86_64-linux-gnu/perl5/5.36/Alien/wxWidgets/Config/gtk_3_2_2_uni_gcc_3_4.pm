package Alien::wxWidgets::Config::gtk_3_2_2_uni_gcc_3_4;

use strict;

our %VALUES;

{
    no strict 'vars';
    %VALUES = %{
$VAR1 = {
          '_libraries' => {
                            'aui' => {
                                       'dll' => 'libwx_gtk3u_aui-3.2.so',
                                       'link' => '-lwx_gtk3u_aui-3.2'
                                     },
                            'base' => {
                                        'dll' => 'libwx_baseu-3.2.so',
                                        'link' => '-lwx_baseu-3.2'
                                      },
                            'core' => {
                                        'dll' => 'libwx_gtk3u_core-3.2.so',
                                        'link' => '-lwx_gtk3u_core-3.2'
                                      },
                            'gl' => {
                                      'dll' => 'libwx_gtk3u_gl-3.2.so',
                                      'link' => '-lwx_gtk3u_gl-3.2'
                                    },
                            'html' => {
                                        'dll' => 'libwx_gtk3u_html-3.2.so',
                                        'link' => '-lwx_gtk3u_html-3.2'
                                      },
                            'media' => {
                                         'dll' => 'libwx_gtk3u_media-3.2.so',
                                         'link' => '-lwx_gtk3u_media-3.2'
                                       },
                            'net' => {
                                       'dll' => 'libwx_baseu_net-3.2.so',
                                       'link' => '-lwx_baseu_net-3.2'
                                     },
                            'propgrid' => {
                                            'dll' => 'libwx_gtk3u_propgrid-3.2.so',
                                            'link' => '-lwx_gtk3u_propgrid-3.2'
                                          },
                            'qa' => {
                                      'dll' => 'libwx_gtk3u_qa-3.2.so',
                                      'link' => '-lwx_gtk3u_qa-3.2'
                                    },
                            'ribbon' => {
                                          'dll' => 'libwx_gtk3u_ribbon-3.2.so',
                                          'link' => '-lwx_gtk3u_ribbon-3.2'
                                        },
                            'richtext' => {
                                            'dll' => 'libwx_gtk3u_richtext-3.2.so',
                                            'link' => '-lwx_gtk3u_richtext-3.2'
                                          },
                            'stc' => {
                                       'dll' => 'libwx_gtk3u_stc-3.2.so',
                                       'link' => '-lwx_gtk3u_stc-3.2'
                                     },
                            'xml' => {
                                       'dll' => 'libwx_baseu_xml-3.2.so',
                                       'link' => '-lwx_baseu_xml-3.2'
                                     },
                            'xrc' => {
                                       'dll' => 'libwx_gtk3u_xrc-3.2.so',
                                       'link' => '-lwx_gtk3u_xrc-3.2'
                                     }
                          },
          'alien_base' => 'gtk_3_2_2_uni_gcc_3_4',
          'alien_package' => 'Alien::wxWidgets::Config::gtk_3_2_2_uni_gcc_3_4',
          'c_flags' => '-pthread ',
          'compiler' => 'g++',
          'config' => {
                        'build' => 'multi',
                        'compiler_kind' => 'gcc',
                        'compiler_version' => '3.4',
                        'debug' => 0,
                        'mslu' => 0,
                        'toolkit' => 'gtk',
                        'unicode' => 1
                      },
          'defines' => '-D_FILE_OFFSET_BITS=64 -DWXUSINGDLL -D__WXGTK__ ',
          'include_path' => '-I/usr/lib/x86_64-linux-gnu/wx/include/gtk3-unicode-3.2 -I/usr/include/wx-3.2 ',
          'link_flags' => '',
          'link_libraries' => ' -L/usr/lib/x86_64-linux-gnu -lpthread',
          'linker' => 'g++  ',
          'prefix' => '/usr',
          'version' => '3.002002'
        };
    };
}

my $key = substr __PACKAGE__, 1 + rindex __PACKAGE__, ':';

sub values { %VALUES, key => $key }

sub config {
   +{ %{$VALUES{config}},
      package       => __PACKAGE__,
      key           => $key,
      version       => $VALUES{version},
      }
}

1;
