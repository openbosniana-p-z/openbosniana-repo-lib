% run this in octave : install octave
load -force fa.pow
load -force thresh.dat
whos
semilogx(1:length(fa), fa, 1:length(thresh), thresh)
legend('power spec.','masking threshold')
xlabel('Fourier Bin')
ylabel('Energy')
title('Typical masking example - vary the threshold up and down to change audio quality')
print -depsc masking.example.eps
print -djpg -r75 masking.example.jpg
