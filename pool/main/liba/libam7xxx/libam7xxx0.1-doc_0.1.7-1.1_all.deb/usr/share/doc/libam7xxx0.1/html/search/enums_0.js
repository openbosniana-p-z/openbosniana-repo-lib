var searchData=
[
  ['am7xxx_5fimage_5fformat_57',['am7xxx_image_format',['../am7xxx_8h.html#a90521fd9cb6d505c4e9986add6704666',1,'am7xxx.h']]],
  ['am7xxx_5flog_5flevel_58',['am7xxx_log_level',['../am7xxx_8h.html#a154dfda799522125d141f887abaef28e',1,'am7xxx.h']]],
  ['am7xxx_5fpower_5fmode_59',['am7xxx_power_mode',['../am7xxx_8h.html#a375a066756224242fd149b6033978c3d',1,'am7xxx.h']]],
  ['am7xxx_5fzoom_5fmode_60',['am7xxx_zoom_mode',['../am7xxx_8h.html#a0eacd32021fabde44795cadc8516484d',1,'am7xxx.h']]]
];
