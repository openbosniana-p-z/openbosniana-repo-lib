var searchData=
[
  ['am7xxx_5fdevice_5finfo_40',['am7xxx_device_info',['../structam7xxx__device__info.html',1,'']]]
];
