var searchData=
[
  ['am7xxx_5fcalc_5fscaled_5fimage_5fdimensions_42',['am7xxx_calc_scaled_image_dimensions',['../am7xxx_8h.html#a363c58723307786ed52321d67d89fb8f',1,'am7xxx.c']]],
  ['am7xxx_5fclose_5fdevice_43',['am7xxx_close_device',['../am7xxx_8h.html#ad51afd0b1a06a37241149db80c8dc160',1,'am7xxx.c']]],
  ['am7xxx_5fget_5fdevice_5finfo_44',['am7xxx_get_device_info',['../am7xxx_8h.html#a5836d32c142f9180e6d842328c336e75',1,'am7xxx.c']]],
  ['am7xxx_5finit_45',['am7xxx_init',['../am7xxx_8h.html#aeb9e4eb5565eb4b1f1d1902a33a9b0da',1,'am7xxx.c']]],
  ['am7xxx_5fopen_5fdevice_46',['am7xxx_open_device',['../am7xxx_8h.html#afd17ab536e61cc5ce20dd347c79d7b61',1,'am7xxx.c']]],
  ['am7xxx_5fsend_5fimage_47',['am7xxx_send_image',['../am7xxx_8h.html#afb43de8de1110e9c57c5336a6823c1f2',1,'am7xxx.h']]],
  ['am7xxx_5fsend_5fimage_5fasync_48',['am7xxx_send_image_async',['../am7xxx_8h.html#a5e5f5e0b9445efaa73c38e5286ad1779',1,'am7xxx.h']]],
  ['am7xxx_5fset_5flog_5flevel_49',['am7xxx_set_log_level',['../am7xxx_8h.html#aa7577dc9e6a764a2a5a1f2d36f8d2dd5',1,'am7xxx.c']]],
  ['am7xxx_5fset_5fpower_5fmode_50',['am7xxx_set_power_mode',['../am7xxx_8h.html#acbb3e41c945293fdcdbaf6f3e2a8ac19',1,'am7xxx.c']]],
  ['am7xxx_5fset_5fzoom_5fmode_51',['am7xxx_set_zoom_mode',['../am7xxx_8h.html#ad647a8647aebd0666ea88d584a20aa39',1,'am7xxx.c']]],
  ['am7xxx_5fshutdown_52',['am7xxx_shutdown',['../am7xxx_8h.html#aa539d7d85384e14272ef6087599a5046',1,'am7xxx.c']]]
];
