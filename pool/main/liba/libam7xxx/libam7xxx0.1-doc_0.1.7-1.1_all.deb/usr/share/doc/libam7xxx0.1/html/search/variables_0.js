var searchData=
[
  ['native_5fheight_53',['native_height',['../structam7xxx__device__info.html#a5462f9fbf94c7025cb64abd04058d08b',1,'am7xxx_device_info']]],
  ['native_5fwidth_54',['native_width',['../structam7xxx__device__info.html#a984c25ec5afc9aeec6b8b45be8088a37',1,'am7xxx_device_info']]]
];
