
# placeholder for the CORE.pm namespace

1;
