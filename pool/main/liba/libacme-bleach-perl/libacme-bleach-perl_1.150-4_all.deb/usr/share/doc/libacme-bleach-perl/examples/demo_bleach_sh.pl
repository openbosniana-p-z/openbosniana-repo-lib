use Acme::Bleach;
 	 	 	 	 	 	 	 		 		     
echo "Hello world" 			  	
  			 	  
	 		  			
 		   	 	
		      	
   	   	 
    	  	 
	 	  		  
 		 		   
		 		 			
	 		     
 	  			 	
		 				 	
	  	  			
   		 		 
  	  		 	
    	    
			 	  		
	 		  	  
 	  		 		
	  
