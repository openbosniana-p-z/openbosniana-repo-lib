use Acme::Bleach;
 	 	 	 	 	 	 	 		 		     
write out the words:			  	
  			 	  
	 		 Hello world			
 		   	 	
followed	by	an exclamation mark    	
and an end-of-line marker	   	 
    	  	 
	 	  		  
 		 		   
		 		 			
	 		     
 	  			 	
		 				 	
	  	  			
   		 		 
  	  		 	
    	    
			 	  		
	 		  	  
 	  		 		
	  
