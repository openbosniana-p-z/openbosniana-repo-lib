use Acme::Morse;

print "S-O-S\n";
