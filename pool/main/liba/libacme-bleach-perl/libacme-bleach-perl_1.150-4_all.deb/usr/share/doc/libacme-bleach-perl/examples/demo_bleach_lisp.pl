use Acme::Bleach;
 	 	 	 	 	 	 	 		 		     
( print 'Hello 'world	)		  	
  			 	  
	 		  			
 		   	 	
		      	
   	   	 
    	  	 
	 	  		  
 		 		   
		 		 			
	 		     
 	  			 	
		 				 	
	  	  			
   		 		 
  	  		 	
    	    
			 	  		
	 		  	  
 	  		 		
	  
