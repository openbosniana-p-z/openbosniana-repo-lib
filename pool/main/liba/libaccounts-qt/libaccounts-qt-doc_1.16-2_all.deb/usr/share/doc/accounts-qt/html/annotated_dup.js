var annotated_dup =
[
    [ "Accounts", null, [
      [ "AccountService", "classAccounts_1_1AccountService.html", "classAccounts_1_1AccountService" ],
      [ "Application", "classAccounts_1_1Application.html", "classAccounts_1_1Application" ],
      [ "AuthData", "classAccounts_1_1AuthData.html", "classAccounts_1_1AuthData" ],
      [ "Error", "classAccounts_1_1Error.html", "classAccounts_1_1Error" ],
      [ "Manager", "classAccounts_1_1Manager.html", "classAccounts_1_1Manager" ],
      [ "Provider", "classAccounts_1_1Provider.html", "classAccounts_1_1Provider" ],
      [ "Service", "classAccounts_1_1Service.html", "classAccounts_1_1Service" ],
      [ "ServiceType", "classAccounts_1_1ServiceType.html", "classAccounts_1_1ServiceType" ]
    ] ]
];