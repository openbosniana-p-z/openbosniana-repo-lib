carton exec "RDF_LINKEDDATA_CONFIG=test.json TEST_VERBOSE=1 plackup test.psgi --host localhost --port 8000"
