package Alzabo::Runtime::Index;

use strict;
use vars qw($VERSION);

use Alzabo::Runtime;

use base qw(Alzabo::Index);

$VERSION = 2.0;

1;

__END__

=head1 NAME

Alzabo::Runtime::Index - Index objects

=head1 SYNOPSIS

  use Alzabo::Runtime::Index;

=head1 DESCRIPTION

This object represents an index on a table.  Indexes consist of
columns and optional prefixes for each column.  The prefix specifies
how many characters of the columns should be indexes (the first X
chars).  Some RDBMS's do not have a concept of index prefixes.  Not
all column types are likely to allow prefixes though this depends on
the RDBMS.  The order of the columns is significant.

=head1 INHERITS FROM

C<Alzabo::Index>


Note: all relevant documentation from the superclass has been merged into this document.

=head1 METHODS

=head2 columns

Returns an ordered list of the L<C<Alzabo::Runtime::Column>|Alzabo::Runtime::Column>
objects that are being indexed.

=head2 prefix (C<Alzabo::Runtime::Column> object)

A column prefix is, to the best of my knowledge, a MySQL specific
concept, and as such cannot be set when using an RDBMSRules module for
a different RDBMS.  However, it is important enough for MySQL to have
the functionality be present.  It allows you to specify that the index
should only look at a certain portion of a field (the first N
characters).  This prefix is required to index any sort of BLOB column
in MySQL.

This method returns the prefix for the column in the index.  If there
is no prefix for this column in the index, then it returns undef.

=head2 unique

Returns a boolean value indicating whether the index is a unique
index.

=head2 fulltext

Returns a boolean value indicating whether the index is a fulltext
index.

=head2 function

For function indexes, this returns the function being indexed.

=head2 id

The id is generated from the table, column and prefix information for
the index.  This is useful as a canonical name for a hash key, for
example.

Returns a string that is the id which uniquely identifies the index in
this schema.

=head2 table

Returns the L<C<Alzabo::Runtime::Table>|Alzabo::Runtime::Table> object to which the
index belongs.

=head1 AUTHOR

Dave Rolsky, <autarch@urth.org>

=cut
