package Alzabo::Runtime::ColumnDefinition;

use strict;
use vars qw($VERSION);

use Alzabo::Runtime;

use base qw(Alzabo::ColumnDefinition);

$VERSION = 2.0;

1;

__END__

=head1 NAME

Alzabo::Runtime::ColumnDefinition - Column definition objects

=head1 SYNOPSIS

  use Alzabo::Runtime::ColumnDefinition;

=head1 DESCRIPTION

This object holds information on a column that might need to be shared
with another column.  The reason for this is that if a column is a key
in two or more tables, then some of the information related to that
column should change automatically for all tables (and all columns)
whenever it is changed anywhere.  Right now this is only type
('VARCHAR', 'NUMBER', etc) information.  This object also has an
'owner', which is the column which created it.

=head1 INHERITS FROM

C<Alzabo::ColumnDefinition>


Note: all relevant documentation from the superclass has been merged into this document.

=for pod_merge METHODS

Dave Rolsky, <autarch@urth.org>

=cut
