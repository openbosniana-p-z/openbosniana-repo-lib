use v5.14;
use warnings;

=head1 NAME

Attean::Blank - RDF blank nodes

=head1 VERSION

This document describes Attean::Blank version 0.033

=head1 SYNOPSIS

  use v5.14;
  use Attean;
  my $term = Attean::Blank->new('b1');
  $term->ntriples_string; # _:b1

=head1 DESCRIPTION

The Attean::Blank class represents RDF blank nodes.
It conforms to the L<Attean::API::Blank|Attean::API::Term> role.

=head1 ROLES

This role consumes L<Attean::API::Blank>, which provides the following methods:

=over 4

=item C<< value >>

=back

=cut

package Attean::Blank 0.033 {
	use Moo;
	use Types::Standard qw(Str);
	use UUID::Tiny ':std';
	use namespace::clean;
	
	has 'value' => (is => 'ro', isa => Str, required => 1);
	has 'ntriples_string'	=> (is => 'ro', isa => Str, lazy => 1, builder => '_ntriples_string');
	
	with 'Attean::API::Blank';

	around BUILDARGS => sub {
		my $orig 	= shift;
		my $class	= shift;
		
		if (scalar(@_) == 0) {
			my $uuid	= unpack('H*', create_uuid());
			return $class->$orig(value => 'b' . $uuid);
		} elsif (scalar(@_) == 1) {
			my $value	= shift // '';
			return $class->$orig(value => $value);
		}
		return $class->$orig(@_);
	};
	
	sub _ntriples_string {
		my $self	= shift;
		return '_:' . $self->value;
	}
}

1;

__END__

=head1 BUGS

Please report any bugs or feature requests to through the GitHub web interface
at L<https://github.com/kasei/attean/issues>.

=head1 SEE ALSO



=head1 AUTHOR

Gregory Todd Williams  C<< <gwilliams@cpan.org> >>

=head1 COPYRIGHT

Copyright (c) 2014--2022 Gregory Todd Williams.
This program is free software; you can redistribute it and/or modify it under
the same terms as Perl itself.

=cut
