package Test::Attean::StoreCleanup;

use v5.14;
use warnings;
use Test::Roo::Role;
use Test::Moose;
use Attean;
use Attean::RDF;

sub cleanup_store {}			# cleanup_store( $store )

1;
