--
-- Drop session management SQL tables
--
-- $Id$
--
--

drop table rivet_session_cache;
drop table rivet_session;

