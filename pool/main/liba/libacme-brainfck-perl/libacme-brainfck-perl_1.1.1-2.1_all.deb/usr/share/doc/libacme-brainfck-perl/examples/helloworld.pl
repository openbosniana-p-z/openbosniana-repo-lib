#!/usr/bin/env perl
use Acme::Brainfuck;
print "Hello world!", chr ++++++++++ ;
