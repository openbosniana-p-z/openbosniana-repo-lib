#!/usr/bin/env perl
use Acme::Brainfuck qw/verbose/;
print "Countdown commencing...\n";
++++++++++[>+>+<<-]
>>+++++++++++++++++++++++++++++++++++++++++++++++<<
++++++++++[>>.-<.<-]
print "We have liftoff!\n";
