#!/usr/bin/env perl
use Acme::Brainfuck;
use strict;
use warnings;

my $answer = +++[>++++++<-]> ;

print "3 * 6 = $answer \n";  

