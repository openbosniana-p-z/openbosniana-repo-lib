// [The "BSD licence"]
// Copyright (c) 2018 Fabian Wolff <fabi.wolff@arcor.de>
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
// 3. The name of the author may not be used to endorse or promote products
//    derived from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
// IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
// IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
// THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#ifndef	_ANTLR3_CONVERTUTF_H
#define	_ANTLR3_CONVERTUTF_H

/* This file is Debian-specific, since the upstream implementation
 * could not be used due to licensing issues (see Debian bug #900601).
 * A reimplementation for the ConvertUTF16toUTF8() function has been
 * provided in src/antlr3convertutf.cc because it is used in
 * src/antlr3string.c. However, ConvertUTF16toUTF8() _MUST NOT_ be
 * considered part of the public API of this library.
 */

#include <antlr3defs.h>

#ifdef __cplusplus
extern "C"
{
#endif

typedef ANTLR3_UINT32 UTF32;
typedef ANTLR3_UINT16 UTF16;
typedef ANTLR3_UINT8  UTF8;

#define UNI_SUR_HIGH_START  (UTF32)0xD800
#define UNI_SUR_HIGH_END    (UTF32)0xDBFF
#define UNI_SUR_LOW_START   (UTF32)0xDC00
#define UNI_SUR_LOW_END     (UTF32)0xDFFF
#define halfShift           ((UTF32)10)
#define halfBase            ((UTF32)0x0010000UL)

#ifdef __cplusplus
}
#endif

#endif // _ANTLR3_CONVERTUTF_H
