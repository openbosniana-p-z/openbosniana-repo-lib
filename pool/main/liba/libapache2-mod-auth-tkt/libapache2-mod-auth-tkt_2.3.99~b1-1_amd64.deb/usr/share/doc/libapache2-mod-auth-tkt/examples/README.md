This directory contains ticket generation code in PHP and Python
contributed by members of the community. Please see the code for
author and license details.

In addition, the following libraries are available elsewhere on
the Net:

- ruby: http://www.meso.net/auth_tkt_rails


