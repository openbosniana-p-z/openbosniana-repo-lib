/* Copyright (C) 2001, 2002, 2003 by Hans Reiser, licensing governed by
   libaal/COPYING.
   
   file.h -- standard file device. */

#ifndef AAL_FILE_H
#define AAL_FILE_H

#ifndef ENABLE_MINIMAL

#include <aal/types.h>
extern struct aal_device_ops file_ops;

#endif

#endif

