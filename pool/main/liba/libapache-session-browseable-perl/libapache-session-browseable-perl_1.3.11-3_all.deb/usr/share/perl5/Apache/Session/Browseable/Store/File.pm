package Apache::Session::Browseable::Store::File;

use strict;
use Apache::Session::Store::File;
our @ISA     = qw(Apache::Session::Store::File);
our $VERSION = 1.2.2;

1;

