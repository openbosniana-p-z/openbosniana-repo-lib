var indexSectionsWithContent =
{
  0: "celow",
  1: "o",
  2: "cw",
  3: "ce",
  4: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables",
  3: "groups",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Variables",
  3: "Modules",
  4: "Pages"
};

