var searchData=
[
  ['callback_20functions_0',['Callback Functions',['../group__callbacks.html',1,'']]],
  ['close_1',['close',['../structOpusEncCallbacks.html#ac83f7ef40af496800b8c54e0046ee465',1,'OpusEncCallbacks']]],
  ['comments_20handling_2',['Comments Handling',['../group__comments.html',1,'']]]
];
