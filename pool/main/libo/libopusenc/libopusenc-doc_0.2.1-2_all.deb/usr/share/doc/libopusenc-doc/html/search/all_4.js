var searchData=
[
  ['write_0',['write',['../structOpusEncCallbacks.html#a9dea7f30faf0d111c3c74165d2815bd4',1,'OpusEncCallbacks']]]
];
