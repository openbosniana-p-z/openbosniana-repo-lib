var searchData=
[
  ['close_0',['close',['../structOpusEncCallbacks.html#ac83f7ef40af496800b8c54e0046ee465',1,'OpusEncCallbacks']]]
];
