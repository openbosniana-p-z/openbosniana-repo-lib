var ss7__internal_8h =
[
    [ "ss7_as_ctr", "ss7__internal_8h.html#ac6bc66087e1e1f143797c66201b2b67a", [
      [ "SS7_AS_CTR_RX_MSU_TOTAL", "ss7__internal_8h.html#ac6bc66087e1e1f143797c66201b2b67aa26abc32054e575ee149c045750f8cfda", null ],
      [ "SS7_AS_CTR_TX_MSU_TOTAL", "ss7__internal_8h.html#ac6bc66087e1e1f143797c66201b2b67aa9006faf07587c92ebe18200be163e248", null ]
    ] ],
    [ "osmo_ss7_asp_set_default_peer_hosts", "ss7__internal_8h.html#a93ec7c275e46107fc203fe84c90a1b79", null ],
    [ "osmo_ss7_xua_server_set_default_local_hosts", "ss7__internal_8h.html#a2229461a3780bcbed7484aba74b6dcbd", null ]
];