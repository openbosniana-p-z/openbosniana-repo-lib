var indexSectionsWithContent =
{
  0: "_acdefghiklmnopqrstuvwx",
  1: "ilmopsux",
  2: "imosx",
  3: "_acdefghilmnoprstuvwx",
  4: "_acdefghiklmnopqrstuvwx",
  5: "o",
  6: "cilmosx",
  7: "_cilmostx",
  8: "_acegilmnoprstx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

