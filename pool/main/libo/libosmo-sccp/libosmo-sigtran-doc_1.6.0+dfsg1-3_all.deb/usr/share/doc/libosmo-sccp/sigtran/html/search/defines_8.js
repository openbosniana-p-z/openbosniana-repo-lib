var searchData=
[
  ['notify_5fpar_5fp_5fasp_5fid_0',['NOTIFY_PAR_P_ASP_ID',['../sigtran__sap_8h.html#a07305cbec6524c70533615f50d34ee5c',1,'sigtran_sap.h']]],
  ['notify_5fpar_5fp_5froute_5fctx_1',['NOTIFY_PAR_P_ROUTE_CTX',['../sigtran__sap_8h.html#aefbb4c250fdafa183369b5d7d6847b78',1,'sigtran_sap.h']]],
  ['num_5fsccp_5fmsgt_2',['NUM_SCCP_MSGT',['../sccp2sua_8c.html#a5578a4d0611ff53d0c6d2652f3ec7424',1,'sccp2sua.c']]]
];
