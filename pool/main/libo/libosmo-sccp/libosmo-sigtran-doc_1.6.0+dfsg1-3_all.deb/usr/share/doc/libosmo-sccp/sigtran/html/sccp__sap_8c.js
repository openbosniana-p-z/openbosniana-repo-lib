var sccp__sap_8c =
[
    [ "osmo_scu_prim_name", "sccp__sap_8c.html#aa29dd40552719849646e88fc1c4cee00", null ],
    [ "osmo_xlm_prim_name", "sccp__sap_8c.html#aaef9ad4e08afbfa5ec5604d748e0c7d4", null ],
    [ "osmo_sccp_gti_names", "sccp__sap_8c.html#ae1bde590c466d405e70b9b804527c1ad", null ],
    [ "osmo_sccp_routing_ind_names", "sccp__sap_8c.html#a7d2dbcc6dbd2e8f75fb6e75ba2bfe28b", null ],
    [ "osmo_sccp_ssn_names", "sccp__sap_8c.html#a5fed5e157ab1a93095318b73beb22813", null ],
    [ "osmo_scu_prim_names", "sccp__sap_8c.html#a3b8d62f238da526659a1a22d50db91f9", null ],
    [ "osmo_xlm_prim_names", "sccp__sap_8c.html#a15c567cc2103dd74ca32374590b7574f", null ],
    [ "prim_name_buf", "sccp__sap_8c.html#ade03488aec056a43cb6713c56c331c04", null ]
];