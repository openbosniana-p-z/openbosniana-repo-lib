var structosmo__mtp__resume__param =
[
    [ "affected_dpc", "structosmo__mtp__resume__param.html#aa135777137e7c13209515a18979d4da8", null ]
];