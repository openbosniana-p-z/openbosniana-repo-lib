var structosmo__scu__data__param =
[
    [ "conn_id", "structosmo__scu__data__param.html#afef6dcd4df457e1099a4d9c9c14bdb4f", null ],
    [ "importance", "structosmo__scu__data__param.html#a32ee1895a8adc09b5ef797b046dabbf5", null ]
];