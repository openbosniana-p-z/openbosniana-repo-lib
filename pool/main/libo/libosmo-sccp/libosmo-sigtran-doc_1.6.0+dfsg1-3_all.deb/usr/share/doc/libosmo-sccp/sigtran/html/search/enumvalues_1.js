var searchData=
[
  ['cs7_5frole_5fasp_0',['CS7_ROLE_ASP',['../osmo__ss7__vty_8c.html#aa6181aded5492004a6442972bb31c15ba2a7a9a010cf4c267e4b996a0661bc5ec',1,'osmo_ss7_vty.c']]],
  ['cs7_5frole_5fsg_1',['CS7_ROLE_SG',['../osmo__ss7__vty_8c.html#aa6181aded5492004a6442972bb31c15ba6251043fc6df5347b66432be2da06d62',1,'osmo_ss7_vty.c']]]
];
