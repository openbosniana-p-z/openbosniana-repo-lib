var structosmo__mtp__pause__param =
[
    [ "affected_dpc", "structosmo__mtp__pause__param.html#a3c95fd6562612449571bf557828b5c90", null ]
];