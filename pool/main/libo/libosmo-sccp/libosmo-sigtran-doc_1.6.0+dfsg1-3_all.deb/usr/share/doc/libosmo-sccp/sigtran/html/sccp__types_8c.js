var sccp__types_8c =
[
    [ "osmo_sccp_msg_type_names", "sccp__types_8c.html#aa065260a9ecdfc8d8af109ba3286dc56", null ],
    [ "osmo_sccp_pnc_names", "sccp__types_8c.html#a63e026a90389b6b55a4c34f708ae0b14", null ]
];