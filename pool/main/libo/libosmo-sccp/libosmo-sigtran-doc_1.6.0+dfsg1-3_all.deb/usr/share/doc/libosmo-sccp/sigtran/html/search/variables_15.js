var searchData=
[
  ['write_5fcontext_0',['write_context',['../structsccp__system.html#a1f25bcaae85e0b7f3e81d1e41146cfa6',1,'sccp_system']]],
  ['write_5fdata_1',['write_data',['../structsccp__system.html#aaf7289fecc917b03b12f6b2b985f59fa',1,'sccp_system']]]
];
