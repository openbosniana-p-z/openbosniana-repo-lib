var mtp__sap_8h =
[
    [ "osmo_mtp_transfer_param", "structosmo__mtp__transfer__param.html", "structosmo__mtp__transfer__param" ],
    [ "osmo_mtp_pause_param", "structosmo__mtp__pause__param.html", "structosmo__mtp__pause__param" ],
    [ "osmo_mtp_resume_param", "structosmo__mtp__resume__param.html", "structosmo__mtp__resume__param" ],
    [ "osmo_mtp_status_param", "structosmo__mtp__status__param.html", "structosmo__mtp__status__param" ],
    [ "osmo_mtp_prim", "structosmo__mtp__prim.html", "structosmo__mtp__prim" ],
    [ "msgb_mtp_prim", "mtp__sap_8h.html#a463c0a286464fef0cdeb0e29b3c1cf18", null ],
    [ "MTP_SIO", "mtp__sap_8h.html#a955b021ad7245dc7ada3779bfd1c6d62", null ],
    [ "osmo_mtp_prim_type", "mtp__sap_8h.html#ac292c93d961c40235b9771772a327f80", [
      [ "OSMO_MTP_PRIM_TRANSFER", "mtp__sap_8h.html#ac292c93d961c40235b9771772a327f80a85539b3d6cb98c30acb29daf4d5e1acc", null ],
      [ "OSMO_MTP_PRIM_PAUSE", "mtp__sap_8h.html#ac292c93d961c40235b9771772a327f80a93bb547c492a35dac5a47396a920cd65", null ],
      [ "OSMO_MTP_PRIM_RESUME", "mtp__sap_8h.html#ac292c93d961c40235b9771772a327f80a7ba9a90fbdc8edcf206aeae92e56ac1c", null ],
      [ "OSMO_MTP_PRIM_STATUS", "mtp__sap_8h.html#ac292c93d961c40235b9771772a327f80af3c2b7a95643d9f6b408c2b305b88307", null ]
    ] ],
    [ "osmo_mtp_prim_name", "mtp__sap_8h.html#a4c7731ca07b811d131418ab5521db225", null ]
];