var sccp__lbcs_8c =
[
    [ "sccp_lbcs_local_bcast_pcstate", "sccp__lbcs_8c.html#ab1db96d27a773af541638dc93fdace21", null ],
    [ "sccp_lbcs_local_bcast_state", "sccp__lbcs_8c.html#aabfd5fec32f2a90b0e50d028b39b1291", null ]
];