var searchData=
[
  ['tx_5finact_5ftimer_0',['TX_INACT_TIMER',['../sua_8c.html#a3d2a940817b70daf372c591ca924af0a',1,'sua.c']]]
];
