var sccp__scmg_8c =
[
    [ "sccp_scmg_init", "sccp__scmg_8c.html#a78005d521d9f14a1a8504b2d18691539", null ],
    [ "sccp_scmg_rx_mtp_pause", "sccp__scmg_8c.html#a6e1de1fdffab62084b3e51db5a09b7c4", null ],
    [ "sccp_scmg_rx_mtp_resume", "sccp__scmg_8c.html#a9b395f6f66a9d5cd22fec3841738d6ca", null ],
    [ "sccp_scmg_rx_mtp_status", "sccp__scmg_8c.html#a52ebba6e3b52df06bb6b8e21ea937dda", null ],
    [ "sccp_scmg_rx_ssn_allowed", "sccp__scmg_8c.html#a112a6f006b73b2b5dc475c6ccd33337d", null ],
    [ "sccp_scmg_rx_ssn_prohibited", "sccp__scmg_8c.html#a6790766deb21c57560ab062d8a7ee0be", null ],
    [ "sccp_scmg_tx", "sccp__scmg_8c.html#ab62f2db95b4ad197732d6cc6cfbb9281", null ],
    [ "scmg_prim_cb", "sccp__scmg_8c.html#a1d014dedd003fe64f1d63154a0bae72d", null ],
    [ "scmg_rx", "sccp__scmg_8c.html#a0e3a3cdc35df69b38f7f37eb4d359d9b", null ],
    [ "scmg_rx_ssa", "sccp__scmg_8c.html#ac0ac40d9fd1003fe9e40f8681bb49c3f", null ],
    [ "scmg_rx_ssp", "sccp__scmg_8c.html#af5d62e1daa9a2ad529c6efa6f4356b74", null ],
    [ "scmg_rx_sst", "sccp__scmg_8c.html#aa49df1828fb01829cef1912faa0d3999", null ],
    [ "sccp_scmg_msgt_names", "sccp__scmg_8c.html#a19984f8b6a5a4a9d11eb79090088649a", null ]
];