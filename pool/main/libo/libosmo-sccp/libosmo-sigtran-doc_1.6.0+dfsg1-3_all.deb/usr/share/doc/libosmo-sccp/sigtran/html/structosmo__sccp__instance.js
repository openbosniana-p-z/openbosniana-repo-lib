var structosmo__sccp__instance =
[
    [ "connections", "structosmo__sccp__instance.html#a09865284d107aa16445eadcf5f19f3c4", null ],
    [ "list", "structosmo__sccp__instance.html#a3c16c2124bd10128d2894348783bb5df", null ],
    [ "next_id", "structosmo__sccp__instance.html#a052a407c54d9b116bb355b7d1f5589b2", null ],
    [ "priv", "structosmo__sccp__instance.html#a9eb8afc487b7255b57a3fc1c64984718", null ],
    [ "route_ctx", "structosmo__sccp__instance.html#a128f6b3e66eedb77e576f009efdcc20f", null ],
    [ "ss7", "structosmo__sccp__instance.html#a3c065fc49cb0617c9b7d7f0b5c01c6b9", null ],
    [ "ss7_user", "structosmo__sccp__instance.html#aba449483a0ab1ec8a6674735d215c7c8", null ],
    [ "timers", "structosmo__sccp__instance.html#a433533654d1919c1a63a24f39f892761", null ],
    [ "users", "structosmo__sccp__instance.html#ad699d0e360f777f69c41f83660d8d46d", null ]
];