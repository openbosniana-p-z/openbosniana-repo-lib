var structosmo__scu__unitdata__param =
[
    [ "called_addr", "structosmo__scu__unitdata__param.html#a8d987c9839b469aa0ff361e9983db0aa", null ],
    [ "calling_addr", "structosmo__scu__unitdata__param.html#a9314985386db550ba06a9b82fdb5d992", null ],
    [ "importance", "structosmo__scu__unitdata__param.html#ab9f3efef78e6da8a000f944ca912a1af", null ],
    [ "in_sequence_control", "structosmo__scu__unitdata__param.html#a26c81d2cc83cb643767081fadc4c89a4", null ],
    [ "return_option", "structosmo__scu__unitdata__param.html#a199a05d3b270edac1a725a4fa4d04b01", null ]
];