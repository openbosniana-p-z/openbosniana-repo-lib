var structosmo__scu__pcstate__param =
[
    [ "affected_pc", "structosmo__scu__pcstate__param.html#ab6a782dab085d5c59aeb70c9a2de80f2", null ],
    [ "remote_sccp_status", "structosmo__scu__pcstate__param.html#a45dbf21d669a82abaa80b29d666a9bbc", null ],
    [ "restricted_importance_level", "structosmo__scu__pcstate__param.html#a14809862270e5418596ddba9cbfe8dc7", null ],
    [ "sp_status", "structosmo__scu__pcstate__param.html#ac897bc8d41ca75c3f4e4173804c7576c", null ]
];