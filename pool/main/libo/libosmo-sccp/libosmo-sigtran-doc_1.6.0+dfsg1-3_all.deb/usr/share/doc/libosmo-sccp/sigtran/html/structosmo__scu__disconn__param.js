var structosmo__scu__disconn__param =
[
    [ "cause", "structosmo__scu__disconn__param.html#af5af7c5768eb0584d58b482f50c5fe81", null ],
    [ "conn_id", "structosmo__scu__disconn__param.html#a1488574c4d52fe293ae6f709c0eccb75", null ],
    [ "importance", "structosmo__scu__disconn__param.html#a7c06c83ba961c721bba70a43339fb3c9", null ],
    [ "originator", "structosmo__scu__disconn__param.html#a376d310d66d3a6366241fa5c88ee83ce", null ],
    [ "responding_addr", "structosmo__scu__disconn__param.html#abee9d68124404184bbaf88efc4d94174", null ]
];