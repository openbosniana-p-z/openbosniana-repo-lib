var structosmo__sccp__timer__val =
[
    [ "s", "structosmo__sccp__timer__val.html#ae9a5feee07108a506b16a7b3c730152c", null ],
    [ "us", "structosmo__sccp__timer__val.html#a9c3e9aef9f871ecf35bd44d1c8755075", null ]
];