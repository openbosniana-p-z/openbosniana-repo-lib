var searchData=
[
  ['connection_5ftimer_0',['CONNECTION_TIMER',['../sua_8c.html#a9e72c94571fc7c5a79889d5fab333a64',1,'sua.c']]],
  ['cs7_5fstr_1',['CS7_STR',['../xua__internal_8h.html#ad788266d373ac76d807afcb62fbbe19d',1,'xua_internal.h']]]
];
