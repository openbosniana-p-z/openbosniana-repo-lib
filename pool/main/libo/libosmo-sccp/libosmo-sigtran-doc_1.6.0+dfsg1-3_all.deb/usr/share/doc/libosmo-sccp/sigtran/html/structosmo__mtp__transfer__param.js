var structosmo__mtp__transfer__param =
[
    [ "dpc", "structosmo__mtp__transfer__param.html#a33af7172cd176c790cbbdc8baa0d6374", null ],
    [ "opc", "structosmo__mtp__transfer__param.html#a79496201ac3dd69528dc41cafc82eaa3", null ],
    [ "sio", "structosmo__mtp__transfer__param.html#aa99084a9d797fbd281f25840be2dad35", null ],
    [ "sls", "structosmo__mtp__transfer__param.html#a8150b3aa1e200a76663636660f570569", null ]
];