var structosmo__sccp__addr =
[
    [ "gt", "structosmo__sccp__addr.html#a9db5ad9cb9b30be37687ce5452dcdfe5", null ],
    [ "ip", "structosmo__sccp__addr.html#a6711bc3bfcc0d9e77d36f03c2a586947", null ],
    [ "pc", "structosmo__sccp__addr.html#a06b7f9d5c79fc812b02523b23d6b85b9", null ],
    [ "presence", "structosmo__sccp__addr.html#acd24f97487b7e3beb2f7da2619919ac6", null ],
    [ "ri", "structosmo__sccp__addr.html#a8847f7f8d8318cfa70db65670edb6182", null ],
    [ "ssn", "structosmo__sccp__addr.html#a7862f57faa882bb3e69cc88fdacb98a0", null ],
    [ "v4", "structosmo__sccp__addr.html#a0f8e855dab0a6d9f058fc54d7584086e", null ],
    [ "v6", "structosmo__sccp__addr.html#af7e421df8b698ac40887acc885bec730", null ]
];