var structosmo__scu__notice__param =
[
    [ "called_addr", "structosmo__scu__notice__param.html#a0bb9f46ab4edfbbad658da82e993a39f", null ],
    [ "calling_addr", "structosmo__scu__notice__param.html#a80090a325627f1c6be0a42aeb2e186e6", null ],
    [ "cause", "structosmo__scu__notice__param.html#a2cd31c16112b585c7b821ae7893c9813", null ],
    [ "importance", "structosmo__scu__notice__param.html#a3783102398c81e62900273368f906bc6", null ]
];