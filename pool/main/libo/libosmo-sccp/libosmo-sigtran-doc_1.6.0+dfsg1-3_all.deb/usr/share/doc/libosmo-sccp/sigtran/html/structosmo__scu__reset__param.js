var structosmo__scu__reset__param =
[
    [ "cause", "structosmo__scu__reset__param.html#a54fa420388d5218c325c963ea6237cba", null ],
    [ "conn_id", "structosmo__scu__reset__param.html#a037985439605c864d9e9c2a99356b2c8", null ],
    [ "originator", "structosmo__scu__reset__param.html#ae1a1b23126ae9280b4ded660f8a40935", null ]
];