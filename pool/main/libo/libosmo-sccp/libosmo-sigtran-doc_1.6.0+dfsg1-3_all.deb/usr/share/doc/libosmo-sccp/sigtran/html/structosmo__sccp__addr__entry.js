var structosmo__sccp__addr__entry =
[
    [ "addr", "structosmo__sccp__addr__entry.html#aa2a11e5fb586cae8c2c292a62b46f756", null ],
    [ "inst", "structosmo__sccp__addr__entry.html#a11eb820b2bbe24eba88b11d923f4a973", null ],
    [ "list", "structosmo__sccp__addr__entry.html#a4b37e6e3479ec01f69d9ad791005f8da", null ],
    [ "list_global", "structosmo__sccp__addr__entry.html#a8dd093adb27bd599d2b7578aa2c1d615", null ],
    [ "name", "structosmo__sccp__addr__entry.html#a20e9fdcbe86f2a18f2a5daabe08f03ff", null ]
];