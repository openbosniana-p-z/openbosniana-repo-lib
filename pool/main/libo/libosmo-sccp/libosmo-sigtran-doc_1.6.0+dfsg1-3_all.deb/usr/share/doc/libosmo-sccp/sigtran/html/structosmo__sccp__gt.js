var structosmo__sccp__gt =
[
    [ "digits", "structosmo__sccp__gt.html#ae743b1eaa2e0a149dda7a80c21483ed4", null ],
    [ "gti", "structosmo__sccp__gt.html#a15c958806a049ba12993188e9a1b7ca9", null ],
    [ "nai", "structosmo__sccp__gt.html#a3d7aaff6d2058351094db70729d07344", null ],
    [ "npi", "structosmo__sccp__gt.html#a530106080a18196622c9324dc1b0ad9d", null ],
    [ "tt", "structosmo__sccp__gt.html#aed1b40905e70d510dd438469b724eb25", null ]
];