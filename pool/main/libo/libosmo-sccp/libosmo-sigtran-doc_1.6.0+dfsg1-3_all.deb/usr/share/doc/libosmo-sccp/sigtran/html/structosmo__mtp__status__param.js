var structosmo__mtp__status__param =
[
    [ "affected_dpc", "structosmo__mtp__status__param.html#a6151089dfb6e797c80c34c47e611d5e7", null ],
    [ "cause", "structosmo__mtp__status__param.html#a13483ca74feb301920e246f02b563cec", null ]
];