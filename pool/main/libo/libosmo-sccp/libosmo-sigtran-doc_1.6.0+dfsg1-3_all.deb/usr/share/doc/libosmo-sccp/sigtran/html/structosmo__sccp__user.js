var structosmo__sccp__user =
[
    [ "as_fi", "structosmo__sccp__user.html#a28ad7b7289c898db019be6f3dad74ee6", null ],
    [ "inst", "structosmo__sccp__user.html#a37fdb1a4f629f2b028e38584c22216ba", null ],
    [ "links", "structosmo__sccp__user.html#a5cba22699c6057725380fe721b21eeb7", null ],
    [ "list", "structosmo__sccp__user.html#afce7749961ce5e8d6b083b7ee42d1e27", null ],
    [ "name", "structosmo__sccp__user.html#a9b1d575ae24f502ec1334c05fc0f1c1c", null ],
    [ "pc", "structosmo__sccp__user.html#a53eed6648070b73d553f3020ba8e7b25", null ],
    [ "prim_cb", "structosmo__sccp__user.html#af51492c8bd34bd61a06db2665a261bb9", null ],
    [ "priv", "structosmo__sccp__user.html#a77e0cd1bb01ab1bd2bff5de9bfe5a333", null ],
    [ "ssn", "structosmo__sccp__user.html#a85356af5d3622a4f6ee912322cd8148d", null ]
];