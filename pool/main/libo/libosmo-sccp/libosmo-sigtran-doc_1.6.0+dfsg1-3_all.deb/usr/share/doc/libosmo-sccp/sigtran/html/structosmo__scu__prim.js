var structosmo__scu__prim =
[
    [ "connect", "structosmo__scu__prim.html#a906d0ffd0b404f75076123db2ba80f97", null ],
    [ "data", "structosmo__scu__prim.html#abb32a8ee3f60be2c851a8248264d580a", null ],
    [ "disconnect", "structosmo__scu__prim.html#a7faff854a507bb7fa3b676c928e8f89e", null ],
    [ "notice", "structosmo__scu__prim.html#a4aa1b5f7b529cf68723b6f7c8facc078", null ],
    [ "oph", "structosmo__scu__prim.html#a0bf42a60284d6fae886b610b868b7d52", null ],
    [ "pcstate", "structosmo__scu__prim.html#ac2db1fe9e143cf08e9acf696fb1a9b3b", null ],
    [ "reset", "structosmo__scu__prim.html#ae5b5437ca1a507c684dc1c8a84ea72e0", null ],
    [ "state", "structosmo__scu__prim.html#aea9b0215a57922aae7b14766a77875fd", null ],
    [ "u", "structosmo__scu__prim.html#af17309f1ee63e8027af6b71216ad7a4a", null ],
    [ "unitdata", "structosmo__scu__prim.html#a79602dc9720157f71fdf70581ead993a", null ]
];