var structosmo__scu__connect__param =
[
    [ "called_addr", "structosmo__scu__connect__param.html#a8f9c1dd5cfe8d47e1f19bf8203806917", null ],
    [ "calling_addr", "structosmo__scu__connect__param.html#a2bc67750f26eac6fc530ea037585b0a0", null ],
    [ "conn_id", "structosmo__scu__connect__param.html#adbf1e55da179ee4d15187d619a211c9a", null ],
    [ "importance", "structosmo__scu__connect__param.html#a5b498b0b05a5cb3fbf57168abf3706a0", null ],
    [ "responding_addr", "structosmo__scu__connect__param.html#a3a6464e72eea4b043fee4d7cb0e5ccec", null ],
    [ "sccp_class", "structosmo__scu__connect__param.html#a3f8e22756f5007e12d1265a0f8d352dd", null ]
];