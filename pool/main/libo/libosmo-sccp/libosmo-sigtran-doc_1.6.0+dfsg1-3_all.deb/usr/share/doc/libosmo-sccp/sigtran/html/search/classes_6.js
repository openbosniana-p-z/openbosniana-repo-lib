var searchData=
[
  ['udt_5foffsets_0',['udt_offsets',['../structudt__offsets.html',1,'']]]
];
