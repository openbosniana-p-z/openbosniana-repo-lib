var structm3ua__data__hdr =
[
    [ "dpc", "structm3ua__data__hdr.html#a4a4ac12a471df8bd0fe10ec2f0682af5", null ],
    [ "mp", "structm3ua__data__hdr.html#a688c80327990370fd86331a1140ec75e", null ],
    [ "ni", "structm3ua__data__hdr.html#afa2de08d9503ecd4d48d5c8b79b0463f", null ],
    [ "opc", "structm3ua__data__hdr.html#aab73749d4369382a869156642ee334f6", null ],
    [ "si", "structm3ua__data__hdr.html#af7534d21af3bc4be0d772616a29a26de", null ],
    [ "sls", "structm3ua__data__hdr.html#a2b8d675621b54d9fad0101191b1c26dc", null ]
];