var structosmo__mtp__prim =
[
    [ "oph", "structosmo__mtp__prim.html#acf303b6294b887c076a71c563e7d6fe7", null ],
    [ "pause", "structosmo__mtp__prim.html#abe354714a09a9468b4ca559de1c2fb25", null ],
    [ "resume", "structosmo__mtp__prim.html#a612e191f10b9f1395c11deeafd0479db", null ],
    [ "status", "structosmo__mtp__prim.html#a252ffe68ce38f38f281264b1731b7702", null ],
    [ "transfer", "structosmo__mtp__prim.html#aa50cfd1e1d3c48f01c62d4c793d26db8", null ],
    [ "u", "structosmo__mtp__prim.html#a87f10163aca46d9f5119de96fd4796db", null ]
];