var structipa__asp__fsm__priv =
[
    [ "asp", "structipa__asp__fsm__priv.html#a6ba515632b7d52ba567489882f3c6414", null ],
    [ "ipa_id_ack_rcvd", "structipa__asp__fsm__priv.html#ac76187e66872e53394715c57a01f8b2c", null ],
    [ "ipa_unit", "structipa__asp__fsm__priv.html#a710e544a75b3c16db14380cfcbf518cb", null ],
    [ "pong_timer", "structipa__asp__fsm__priv.html#af87f780b0d004f3887c4ea86fcc14071", null ],
    [ "role", "structipa__asp__fsm__priv.html#a8a8dc625e85ac4394b35b5815ee3d2ae", null ]
];