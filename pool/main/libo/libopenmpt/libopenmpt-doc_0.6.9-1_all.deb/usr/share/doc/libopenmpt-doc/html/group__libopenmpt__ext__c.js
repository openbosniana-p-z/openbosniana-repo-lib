var group__libopenmpt__ext__c =
[
    [ "openmpt_module_ext_interface_pattern_vis", "structopenmpt__module__ext__interface__pattern__vis.html", [
      [ "get_pattern_row_channel_effect_type", "structopenmpt__module__ext__interface__pattern__vis.html#a569ec008874900f6fdcf80182acca0a7", null ],
      [ "get_pattern_row_channel_volume_effect_type", "structopenmpt__module__ext__interface__pattern__vis.html#a8b10b33ba524a9009ac7ee1cf7f301d5", null ]
    ] ],
    [ "openmpt_module_ext_interface_interactive", "structopenmpt__module__ext__interface__interactive.html", [
      [ "get_channel_mute_status", "structopenmpt__module__ext__interface__interactive.html#a38cd9b94eec065ceded80648f08954f0", null ],
      [ "get_channel_volume", "structopenmpt__module__ext__interface__interactive.html#adeef160945c3aa3ec2ff742d62903ab7", null ],
      [ "get_global_volume", "structopenmpt__module__ext__interface__interactive.html#a7fcb9a9bd98e5cef8b0640260d987393", null ],
      [ "get_instrument_mute_status", "structopenmpt__module__ext__interface__interactive.html#a0e45095bd57287edc06d531e4c78af6e", null ],
      [ "get_pitch_factor", "structopenmpt__module__ext__interface__interactive.html#a428c6b3008de8ae66737051ac7ec9e0e", null ],
      [ "get_tempo_factor", "structopenmpt__module__ext__interface__interactive.html#a8552ced3c66bc465b15eb487d45ce5e0", null ],
      [ "play_note", "structopenmpt__module__ext__interface__interactive.html#ac6a7f16d2eb3649052cc0fa3cc179e89", null ],
      [ "set_channel_mute_status", "structopenmpt__module__ext__interface__interactive.html#ae32d5c4232f49c67ea5dcbdd361321d4", null ],
      [ "set_channel_volume", "structopenmpt__module__ext__interface__interactive.html#a66eddfdb348bc527af10af4c3edcee88", null ],
      [ "set_current_speed", "structopenmpt__module__ext__interface__interactive.html#afa6f6853912bda3593d97eaf2364ff97", null ],
      [ "set_current_tempo", "structopenmpt__module__ext__interface__interactive.html#aeb06413a75c07ebe775f9c0dfa220eaf", null ],
      [ "set_global_volume", "structopenmpt__module__ext__interface__interactive.html#ad138ae50c9dcbebb61fee64458ccfa5e", null ],
      [ "set_instrument_mute_status", "structopenmpt__module__ext__interface__interactive.html#a9dd00cb45f792644feb8da86c3bc86c7", null ],
      [ "set_pitch_factor", "structopenmpt__module__ext__interface__interactive.html#a092101167a15ae04f4d77972e9c1469c", null ],
      [ "set_tempo_factor", "structopenmpt__module__ext__interface__interactive.html#a0223477cf25e9db1a84863055cf864c6", null ],
      [ "stop_note", "structopenmpt__module__ext__interface__interactive.html#a384ddf068bbedc363f0406c24f26c603", null ]
    ] ],
    [ "openmpt_module_ext_interface_interactive2", "structopenmpt__module__ext__interface__interactive2.html", [
      [ "get_channel_panning", "structopenmpt__module__ext__interface__interactive2.html#a60b85b0cea576dda3584243192629a98", null ],
      [ "get_note_finetune", "structopenmpt__module__ext__interface__interactive2.html#ab192eb294337d4df7e269c268cb47764", null ],
      [ "note_fade", "structopenmpt__module__ext__interface__interactive2.html#a61f72b1d1a47539ebda45d03c2e60576", null ],
      [ "note_off", "structopenmpt__module__ext__interface__interactive2.html#a0b1f3033a889a502033dfdec80e5121c", null ],
      [ "set_channel_panning", "structopenmpt__module__ext__interface__interactive2.html#aba900e2b424c37b16eacde8c094ea59c", null ],
      [ "set_note_finetune", "structopenmpt__module__ext__interface__interactive2.html#af917dccde88f42db7c6c618c06419432", null ]
    ] ],
    [ "LIBOPENMPT_EXT_C_INTERFACE_INTERACTIVE", "group__libopenmpt__ext__c.html#gacb3881b0a801d57c3e127f6b05173340", null ],
    [ "LIBOPENMPT_EXT_C_INTERFACE_INTERACTIVE2", "group__libopenmpt__ext__c.html#ga6980beb4ff16a77f66362108d8677490", null ],
    [ "LIBOPENMPT_EXT_C_INTERFACE_PATTERN_VIS", "group__libopenmpt__ext__c.html#gac4ca910407ed5fc38164ffc61b470fab", null ],
    [ "OPENMPT_MODULE_EXT_INTERFACE_PATTERN_VIS_EFFECT_TYPE_GENERAL", "group__libopenmpt__ext__c.html#ga8d0952a39ada51bca93cc146a2581257", null ],
    [ "OPENMPT_MODULE_EXT_INTERFACE_PATTERN_VIS_EFFECT_TYPE_GLOBAL", "group__libopenmpt__ext__c.html#ga39268c4e1b39dbd711015dcf7803d0d1", null ],
    [ "OPENMPT_MODULE_EXT_INTERFACE_PATTERN_VIS_EFFECT_TYPE_PANNING", "group__libopenmpt__ext__c.html#ga30263b9490271ef742baea628d9914a7", null ],
    [ "OPENMPT_MODULE_EXT_INTERFACE_PATTERN_VIS_EFFECT_TYPE_PITCH", "group__libopenmpt__ext__c.html#ga57bcab6825fa9ea66372d886bd33b6ad", null ],
    [ "OPENMPT_MODULE_EXT_INTERFACE_PATTERN_VIS_EFFECT_TYPE_UNKNOWN", "group__libopenmpt__ext__c.html#ga4a28a223d6b8f5b3edc3f9cc74c520ea", null ],
    [ "OPENMPT_MODULE_EXT_INTERFACE_PATTERN_VIS_EFFECT_TYPE_VOLUME", "group__libopenmpt__ext__c.html#ga60d6664046f2de67ab3fc88cabf0089f", null ],
    [ "openmpt_module_ext", "group__libopenmpt__ext__c.html#gaefd83333cf6e40a0d4d3f62e34dfca5c", null ],
    [ "openmpt_module_ext_interface_interactive", "group__libopenmpt__ext__c.html#gafabf3ff72796b98b8e249ffee40ce38b", null ],
    [ "openmpt_module_ext_interface_interactive2", "group__libopenmpt__ext__c.html#ga356d304bf5ab293359f16a400fe8290e", null ],
    [ "openmpt_module_ext_interface_pattern_vis", "group__libopenmpt__ext__c.html#ga026116db72e4091a41919cd78a388c7d", null ],
    [ "openmpt_module_ext_create", "group__libopenmpt__ext__c.html#gaa18a77fd25586c0aa8e97c1ea875cb92", null ],
    [ "openmpt_module_ext_create_from_memory", "group__libopenmpt__ext__c.html#ga24a9656811eae2761a0ceaf32a93992b", null ],
    [ "openmpt_module_ext_destroy", "group__libopenmpt__ext__c.html#ga737466596e917bd196c7b30496aad1b8", null ],
    [ "openmpt_module_ext_get_interface", "group__libopenmpt__ext__c.html#ga0275a35da407cd092232a20d3535c9e4", null ],
    [ "openmpt_module_ext_get_module", "group__libopenmpt__ext__c.html#ga764b107b07d54ed211f7d8b761d5fd90", null ]
];