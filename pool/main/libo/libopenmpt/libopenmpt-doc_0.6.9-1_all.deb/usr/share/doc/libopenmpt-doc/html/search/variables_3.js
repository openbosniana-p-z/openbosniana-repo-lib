var searchData=
[
  ['interactive2_5fid_0',['interactive2_id',['../group__libopenmpt__ext__cpp.html#ga191dfc4c2f85a215e41213b706ab5840',1,'openmpt::ext']]],
  ['interactive_5fid_1',['interactive_id',['../group__libopenmpt__ext__cpp.html#gad512c56795b5db030926f0f4b1cbce7a',1,'openmpt::ext']]]
];
