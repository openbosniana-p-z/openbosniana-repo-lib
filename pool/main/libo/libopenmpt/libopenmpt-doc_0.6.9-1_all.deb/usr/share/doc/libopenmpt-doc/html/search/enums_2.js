var searchData=
[
  ['probe_5ffile_5fheader_5fflags_0',['probe_file_header_flags',['../group__libopenmpt__cpp.html#ga1d723b4fa39dd65db926736f04cea77e',1,'openmpt']]],
  ['probe_5ffile_5fheader_5fresult_1',['probe_file_header_result',['../group__libopenmpt__cpp.html#ga2bfab5a4d171e48c0de55806174552b1',1,'openmpt']]]
];
