var searchData=
[
  ['dependencies_2emd_0',['dependencies.md',['../dependencies_8md.html',1,'']]]
];
