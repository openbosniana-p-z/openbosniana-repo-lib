var searchData=
[
  ['exception_0',['exception',['../classopenmpt_1_1exception.html#aee4e972c2304c567fedd39157bc687e8',1,'openmpt::exception::exception(const std::string &amp;text) noexcept'],['../classopenmpt_1_1exception.html#af9cd2a6ead1462f4d7ba7d205fc071b6',1,'openmpt::exception::exception(const exception &amp;other) noexcept'],['../classopenmpt_1_1exception.html#a2d9cf98929191df23ef6a439f01d42d8',1,'openmpt::exception::exception(exception &amp;&amp;other) noexcept']]]
];
