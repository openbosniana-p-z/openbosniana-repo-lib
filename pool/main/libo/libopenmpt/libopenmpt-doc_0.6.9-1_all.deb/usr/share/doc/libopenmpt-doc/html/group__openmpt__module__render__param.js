var group__openmpt__module__render__param =
[
    [ "OPENMPT_MODULE_RENDER_INTERPOLATIONFILTER_LENGTH", "group__openmpt__module__render__param.html#gadd195a06bd55f85b205cf78276cf119f", null ],
    [ "OPENMPT_MODULE_RENDER_MASTERGAIN_MILLIBEL", "group__openmpt__module__render__param.html#ga3bf1d3428ae71694f7c11955410eb489", null ],
    [ "OPENMPT_MODULE_RENDER_STEREOSEPARATION_PERCENT", "group__openmpt__module__render__param.html#gaa79567e9dd0461401f669017b2740346", null ],
    [ "OPENMPT_MODULE_RENDER_VOLUMERAMPING_STRENGTH", "group__openmpt__module__render__param.html#ga618219f4a086d3360b007bdaefd9831f", null ]
];