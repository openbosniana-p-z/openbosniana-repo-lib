var hierarchy =
[
    [ "std::exception", null, [
      [ "openmpt::exception", "classopenmpt_1_1exception.html", null ]
    ] ],
    [ "openmpt::ext::interactive", "classopenmpt_1_1ext_1_1interactive.html", null ],
    [ "openmpt::ext::interactive2", "classopenmpt_1_1ext_1_1interactive2.html", null ],
    [ "openmpt::module", "classopenmpt_1_1module.html", [
      [ "openmpt::module_ext", "classopenmpt_1_1module__ext.html", null ]
    ] ],
    [ "openmpt_module_ext_interface_interactive", "structopenmpt__module__ext__interface__interactive.html", null ],
    [ "openmpt_module_ext_interface_interactive2", "structopenmpt__module__ext__interface__interactive2.html", null ],
    [ "openmpt_module_ext_interface_pattern_vis", "structopenmpt__module__ext__interface__pattern__vis.html", null ],
    [ "openmpt_module_initial_ctl", "structopenmpt__module__initial__ctl.html", null ],
    [ "openmpt_stream_buffer", "structopenmpt__stream__buffer.html", null ],
    [ "openmpt_stream_callbacks", "structopenmpt__stream__callbacks.html", null ],
    [ "openmpt::ext::pattern_vis", "classopenmpt_1_1ext_1_1pattern__vis.html", null ]
];