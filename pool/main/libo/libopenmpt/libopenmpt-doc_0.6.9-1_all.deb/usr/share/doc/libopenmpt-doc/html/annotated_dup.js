var annotated_dup =
[
    [ "openmpt", "namespaceopenmpt.html", [
      [ "ext", "namespaceopenmpt_1_1ext.html", [
        [ "interactive", "classopenmpt_1_1ext_1_1interactive.html", "classopenmpt_1_1ext_1_1interactive" ],
        [ "interactive2", "classopenmpt_1_1ext_1_1interactive2.html", "classopenmpt_1_1ext_1_1interactive2" ],
        [ "pattern_vis", "classopenmpt_1_1ext_1_1pattern__vis.html", "classopenmpt_1_1ext_1_1pattern__vis" ]
      ] ],
      [ "exception", "classopenmpt_1_1exception.html", "classopenmpt_1_1exception" ],
      [ "module", "classopenmpt_1_1module.html", "classopenmpt_1_1module" ],
      [ "module_ext", "classopenmpt_1_1module__ext.html", "classopenmpt_1_1module__ext" ]
    ] ],
    [ "openmpt_module_ext_interface_interactive", "structopenmpt__module__ext__interface__interactive.html", "structopenmpt__module__ext__interface__interactive" ],
    [ "openmpt_module_ext_interface_interactive2", "structopenmpt__module__ext__interface__interactive2.html", "structopenmpt__module__ext__interface__interactive2" ],
    [ "openmpt_module_ext_interface_pattern_vis", "structopenmpt__module__ext__interface__pattern__vis.html", "structopenmpt__module__ext__interface__pattern__vis" ],
    [ "openmpt_module_initial_ctl", "structopenmpt__module__initial__ctl.html", "structopenmpt__module__initial__ctl" ],
    [ "openmpt_stream_buffer", "structopenmpt__stream__buffer.html", "structopenmpt__stream__buffer" ],
    [ "openmpt_stream_callbacks", "structopenmpt__stream__callbacks.html", "structopenmpt__stream__callbacks" ]
];