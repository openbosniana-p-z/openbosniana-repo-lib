var namespaceopenmpt =
[
    [ "ext", "namespaceopenmpt_1_1ext.html", "namespaceopenmpt_1_1ext" ],
    [ "string", "namespaceopenmpt_1_1string.html", [
      [ "get", "namespaceopenmpt_1_1string.html#a5c14a09cfc6d93e26bd717c4b2cfd716", null ],
      [ "LIBOPENMPT_ATTR_DEPRECATED", "namespaceopenmpt_1_1string.html#ab357d2a4b0fcc92eb1a45bb34ee214f5", null ]
    ] ],
    [ "exception", "classopenmpt_1_1exception.html", "classopenmpt_1_1exception" ],
    [ "module", "classopenmpt_1_1module.html", "classopenmpt_1_1module" ],
    [ "module_ext", "classopenmpt_1_1module__ext.html", "classopenmpt_1_1module__ext" ],
    [ "probe_file_header_flags", "group__libopenmpt__cpp.html#ga1d723b4fa39dd65db926736f04cea77e", [
      [ "probe_file_header_flags_modules2", "group__libopenmpt__cpp.html#gga1d723b4fa39dd65db926736f04cea77eadd907cd3abbac2d828efb7146d4185d2", null ],
      [ "probe_file_header_flags_containers2", "group__libopenmpt__cpp.html#gga1d723b4fa39dd65db926736f04cea77eaabb810fe476bd08cd839f4899c580902", null ],
      [ "probe_file_header_flags_default2", "group__libopenmpt__cpp.html#gga1d723b4fa39dd65db926736f04cea77ea9429374c9cf2b759acef9fa8858f3e8e", null ],
      [ "probe_file_header_flags_none2", "group__libopenmpt__cpp.html#gga1d723b4fa39dd65db926736f04cea77ea6fa2dbd5c74702e96a3342ec010d1104", null ]
    ] ],
    [ "probe_file_header_result", "group__libopenmpt__cpp.html#ga2bfab5a4d171e48c0de55806174552b1", [
      [ "probe_file_header_result_success", "group__libopenmpt__cpp.html#gga2bfab5a4d171e48c0de55806174552b1a30801347bba0cd61e700605a10d108b7", null ],
      [ "probe_file_header_result_failure", "group__libopenmpt__cpp.html#gga2bfab5a4d171e48c0de55806174552b1a31d073e7dc36b213618f635ec90f5d2b", null ],
      [ "probe_file_header_result_wantmoredata", "group__libopenmpt__cpp.html#gga2bfab5a4d171e48c0de55806174552b1acf3e6c33d72266e9c0d34da84fb7ec1f", null ]
    ] ],
    [ "could_open_probability", "group__libopenmpt__cpp.html#ga95fd9b6781cd291b48a1c3e12a3c85e1", null ],
    [ "could_open_propability", "group__libopenmpt__cpp.html#gaad5e4ff0e24869d7a9808ac4262283f2", null ],
    [ "get_core_version", "group__libopenmpt__cpp.html#gac37146367d4849a17a297d388cfb4811", null ],
    [ "get_library_version", "group__libopenmpt__cpp.html#gaeece2f6ce1045a5f519c93ce19e6eef3", null ],
    [ "get_supported_extensions", "group__libopenmpt__cpp.html#ga2368fb6c61e2d6304d9d8f4f1bb3ffa1", null ],
    [ "is_extension_supported", "group__libopenmpt__cpp.html#ga499346669636c80f8df0d65145d3fed0", null ],
    [ "is_extension_supported2", "group__libopenmpt__cpp.html#ga2377657c477285d9e47462247a755bc7", null ],
    [ "probe_file_header", "group__libopenmpt__cpp.html#gaa3b9b7a7d0d3d791c8154bf330d96b01", null ],
    [ "probe_file_header", "group__libopenmpt__cpp.html#gaeb1b17a8535ac1407999a849340d7ef6", null ],
    [ "probe_file_header", "group__libopenmpt__cpp.html#ga77facf516dd9b626847f91ac26047336", null ],
    [ "probe_file_header", "group__libopenmpt__cpp.html#gad77e7cf2361d664fda8ae8461c1dc7a0", null ],
    [ "probe_file_header", "group__libopenmpt__cpp.html#ga6412e44030e40ca67aaa187691ad8e9c", null ],
    [ "probe_file_header_get_recommended_size", "group__libopenmpt__cpp.html#gaf70a8d33fdceca5a821755106e840dcb", null ],
    [ "LIBOPENMPT_ATTR_DEPRECATED", "group__libopenmpt__cpp.html#ga80db80ac87f76b79e2a924f62041d1e4", null ]
];