var searchData=
[
  ['changelog_2emd_0',['changelog.md',['../changelog_8md.html',1,'']]],
  ['contributing_2emd_1',['contributing.md',['../contributing_8md.html',1,'']]]
];
