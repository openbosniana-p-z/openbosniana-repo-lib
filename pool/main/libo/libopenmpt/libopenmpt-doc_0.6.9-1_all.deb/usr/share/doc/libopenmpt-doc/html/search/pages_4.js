var searchData=
[
  ['libopenmpt_20style_20guide_0',['libopenmpt Style Guide',['../md_doc_libopenmpt_styleguide.html',1,'']]],
  ['libopenmpt_5fext_20c_20api_1',['libopenmpt_ext C API',['../libopenmpt_ext_c_overview.html',1,'']]],
  ['libopenmpt_5fext_20c_2b_2b_20api_2',['libopenmpt_ext C++ API',['../libopenmpt_ext_cpp_overview.html',1,'']]]
];
