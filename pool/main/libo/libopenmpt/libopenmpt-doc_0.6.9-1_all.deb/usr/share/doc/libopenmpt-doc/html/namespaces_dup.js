var namespaces_dup =
[
    [ "openmpt", "namespaceopenmpt.html", "namespaceopenmpt" ]
];