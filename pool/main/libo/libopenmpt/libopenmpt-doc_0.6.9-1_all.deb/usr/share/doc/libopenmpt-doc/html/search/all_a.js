var searchData=
[
  ['note_5ffade_0',['note_fade',['../structopenmpt__module__ext__interface__interactive2.html#a61f72b1d1a47539ebda45d03c2e60576',1,'openmpt_module_ext_interface_interactive2::note_fade()'],['../classopenmpt_1_1ext_1_1interactive2.html#ae8000602d9c3fceff0c19e3139a0131c',1,'openmpt::ext::interactive2::note_fade()']]],
  ['note_5foff_1',['note_off',['../structopenmpt__module__ext__interface__interactive2.html#a0b1f3033a889a502033dfdec80e5121c',1,'openmpt_module_ext_interface_interactive2::note_off()'],['../classopenmpt_1_1ext_1_1interactive2.html#aca83382556c4f51e95583756fc97988b',1,'openmpt::ext::interactive2::note_off()']]]
];
