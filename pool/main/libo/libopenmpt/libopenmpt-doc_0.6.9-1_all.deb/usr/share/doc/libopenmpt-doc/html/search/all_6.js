var searchData=
[
  ['highlight_5fpattern_5frow_5fchannel_0',['highlight_pattern_row_channel',['../classopenmpt_1_1module.html#afd6430b4062b970456779eaca81159b8',1,'openmpt::module']]],
  ['highlight_5fpattern_5frow_5fchannel_5fcommand_1',['highlight_pattern_row_channel_command',['../classopenmpt_1_1module.html#a2f972d8720ac1a172922f1d64278d880',1,'openmpt::module']]]
];
