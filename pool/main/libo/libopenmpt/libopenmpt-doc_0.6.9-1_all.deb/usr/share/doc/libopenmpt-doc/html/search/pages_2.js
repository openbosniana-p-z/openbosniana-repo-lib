var searchData=
[
  ['dependencies_0',['Dependencies',['../dependencies.html',1,'']]],
  ['deprecated_20list_1',['Deprecated List',['../deprecated.html',1,'']]]
];
