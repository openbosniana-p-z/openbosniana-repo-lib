var searchData=
[
  ['c_20api_0',['C API',['../libopenmpt_c_overview.html',1,'']]],
  ['c_2b_2b_20api_1',['C++ API',['../libopenmpt_cpp_overview.html',1,'']]],
  ['changelog_2',['Changelog',['../changelog.html',1,'']]],
  ['contents_3',['Contents',['../index.html',1,'']]],
  ['contributing_4',['Contributing',['../md_doc_contributing.html',1,'']]]
];
