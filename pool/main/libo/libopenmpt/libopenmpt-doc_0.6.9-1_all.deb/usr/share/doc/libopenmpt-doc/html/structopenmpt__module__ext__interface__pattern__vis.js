var structopenmpt__module__ext__interface__pattern__vis =
[
    [ "get_pattern_row_channel_effect_type", "structopenmpt__module__ext__interface__pattern__vis.html#a569ec008874900f6fdcf80182acca0a7", null ],
    [ "get_pattern_row_channel_volume_effect_type", "structopenmpt__module__ext__interface__pattern__vis.html#a8b10b33ba524a9009ac7ee1cf7f301d5", null ]
];