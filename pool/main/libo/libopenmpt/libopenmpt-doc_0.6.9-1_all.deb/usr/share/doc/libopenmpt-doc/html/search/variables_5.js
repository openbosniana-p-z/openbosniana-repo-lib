var searchData=
[
  ['note_5ffade_0',['note_fade',['../structopenmpt__module__ext__interface__interactive2.html#a61f72b1d1a47539ebda45d03c2e60576',1,'openmpt_module_ext_interface_interactive2']]],
  ['note_5foff_1',['note_off',['../structopenmpt__module__ext__interface__interactive2.html#a0b1f3033a889a502033dfdec80e5121c',1,'openmpt_module_ext_interface_interactive2']]]
];
