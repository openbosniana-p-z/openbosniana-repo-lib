var structopenmpt__stream__buffer =
[
    [ "file_data", "structopenmpt__stream__buffer.html#ae3e4597d5b13ded13241786e231fbd8d", null ],
    [ "file_pos", "structopenmpt__stream__buffer.html#a65ad826a7f9401ded375bdba8fd19b94", null ],
    [ "file_size", "structopenmpt__stream__buffer.html#a1293c6a2af000f1ba1709775969b5fc8", null ],
    [ "overflow", "structopenmpt__stream__buffer.html#a2a71b5fe812cbb7ee52d6daaf2b606ac", null ],
    [ "prefix_size", "structopenmpt__stream__buffer.html#a062bba0e60c5766852bc22d1f5e4f148", null ]
];