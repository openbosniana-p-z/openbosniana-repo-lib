var structopenmpt__stream__callbacks =
[
    [ "read", "structopenmpt__stream__callbacks.html#a1ebf210f90c37ea1bb3ff0342039d8ae", null ],
    [ "seek", "structopenmpt__stream__callbacks.html#ac5e9f267a786ab8f4334e4e2663af6e9", null ],
    [ "tell", "structopenmpt__stream__callbacks.html#aff46dc3277047eafb6b3b04fbcdd85c5", null ]
];