var searchData=
[
  ['gettingstarted_2emd_0',['gettingstarted.md',['../gettingstarted_8md.html',1,'']]]
];
