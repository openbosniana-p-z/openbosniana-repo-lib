var files_dup =
[
    [ "doc", "dir_e68e8157741866f444e17edd764ebbae.html", null ],
    [ "libopenmpt", "dir_906ed1d2e1cfef5183f8ef8c105e91b2.html", "dir_906ed1d2e1cfef5183f8ef8c105e91b2" ]
];