var searchData=
[
  ['libopenmpt_5fattr_5fdeprecated_0',['LIBOPENMPT_ATTR_DEPRECATED',['../namespaceopenmpt_1_1string.html#ab357d2a4b0fcc92eb1a45bb34ee214f5',1,'openmpt::string::LIBOPENMPT_ATTR_DEPRECATED()'],['../group__libopenmpt__cpp.html#ga80db80ac87f76b79e2a924f62041d1e4',1,'openmpt::LIBOPENMPT_ATTR_DEPRECATED()']]],
  ['libopenmpt_5fdeprecated_5fstring_5fconstant_1',['LIBOPENMPT_DEPRECATED_STRING_CONSTANT',['../libopenmpt__config_8h.html#aa3c5870a3f551fc8e6d02a61bb735661',1,'libopenmpt_config.h']]]
];
