var searchData=
[
  ['note_5ffade_0',['note_fade',['../classopenmpt_1_1ext_1_1interactive2.html#ae8000602d9c3fceff0c19e3139a0131c',1,'openmpt::ext::interactive2']]],
  ['note_5foff_1',['note_off',['../classopenmpt_1_1ext_1_1interactive2.html#aca83382556c4f51e95583756fc97988b',1,'openmpt::ext::interactive2']]]
];
