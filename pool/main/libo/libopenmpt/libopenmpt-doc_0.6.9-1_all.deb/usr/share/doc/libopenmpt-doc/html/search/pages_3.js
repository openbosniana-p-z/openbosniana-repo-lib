var searchData=
[
  ['getting_20started_0',['Getting Started',['../gettingstarted.html',1,'']]]
];
