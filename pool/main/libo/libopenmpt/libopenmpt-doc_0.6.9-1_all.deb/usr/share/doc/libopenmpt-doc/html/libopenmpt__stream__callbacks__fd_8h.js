var libopenmpt__stream__callbacks__fd_8h =
[
    [ "openmpt_stream_fd_read_func", "group__libopenmpt__c.html#ga534305a50c22c68f4eb4735ac6e271db", null ],
    [ "openmpt_stream_get_fd_callbacks", "group__libopenmpt__c.html#ga9b222cad5195de39b84503c089eca611", null ]
];