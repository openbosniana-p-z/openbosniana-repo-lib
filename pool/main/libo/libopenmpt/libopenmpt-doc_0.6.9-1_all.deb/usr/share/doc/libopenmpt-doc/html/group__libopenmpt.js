var group__libopenmpt =
[
    [ "OPENMPT_API_VERSION", "group__libopenmpt.html#gaf1d146e1fe0a48865ddd61b911d81804", null ],
    [ "OPENMPT_API_VERSION_AT_LEAST", "group__libopenmpt.html#gaa0ac5281fa2d8957ac72c52a579b4568", null ],
    [ "OPENMPT_API_VERSION_BEFORE", "group__libopenmpt.html#ga44e80f23bf662276bff9d8f7bc11476b", null ],
    [ "OPENMPT_API_VERSION_IS_PREREL", "group__libopenmpt.html#gae44461b3ae0cfaf93d8446730b63f0cf", null ],
    [ "OPENMPT_API_VERSION_MAJOR", "group__libopenmpt.html#ga606ec2ed5b519cd7d2a9d1a035975995", null ],
    [ "OPENMPT_API_VERSION_MAKE", "group__libopenmpt.html#gad94a4f7fed87b485199b0e665d25695e", null ],
    [ "OPENMPT_API_VERSION_MINOR", "group__libopenmpt.html#ga64df542ebca546797047106263a40d1d", null ],
    [ "OPENMPT_API_VERSION_PATCH", "group__libopenmpt.html#ga992f8bd4aa62e443327743c69dba0e2c", null ],
    [ "OPENMPT_API_VERSION_PREREL", "group__libopenmpt.html#ga844f1540877a2d18055dcb301904fd7a", null ],
    [ "OPENMPT_API_VERSION_STRING", "group__libopenmpt.html#gad5b5529fa0ae48c75bb735d5e5e19243", null ]
];