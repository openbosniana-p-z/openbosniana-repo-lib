var searchData=
[
  ['file_5fdata_0',['file_data',['../structopenmpt__stream__buffer.html#ae3e4597d5b13ded13241786e231fbd8d',1,'openmpt_stream_buffer']]],
  ['file_5fpos_1',['file_pos',['../structopenmpt__stream__buffer.html#a65ad826a7f9401ded375bdba8fd19b94',1,'openmpt_stream_buffer']]],
  ['file_5fsize_2',['file_size',['../structopenmpt__stream__buffer.html#a1293c6a2af000f1ba1709775969b5fc8',1,'openmpt_stream_buffer']]]
];
