var libopenmpt__stream__callbacks__buffer_8h =
[
    [ "openmpt_stream_buffer_init_prefix_only", "group__libopenmpt__c.html#gaa74ca2c46b5f904f38adb928ca654173", null ],
    [ "openmpt_stream_buffer_overflowed", "group__libopenmpt__c.html#ga7b9523114368368950872b6235fe184c", null ],
    [ "openmpt_stream_buffer", "group__libopenmpt__c.html#ga7299bdb1270ac987339a5bab822a3973", null ],
    [ "openmpt_stream_buffer_init", "group__libopenmpt__c.html#ga527b70571e44f6c4f0066d4a10670da4", null ],
    [ "openmpt_stream_buffer_read_func", "group__libopenmpt__c.html#gae95f26d25828cd5c46e7a3b7d556b9f4", null ],
    [ "openmpt_stream_buffer_seek_func", "group__libopenmpt__c.html#gacc76d42781b233ba4717dcf0dc415eec", null ],
    [ "openmpt_stream_buffer_tell_func", "group__libopenmpt__c.html#ga9101861fab39cd6993b206dc0270e6c5", null ],
    [ "openmpt_stream_get_buffer_callbacks", "group__libopenmpt__c.html#gaacc6e056e2161e64184079e0f23d34b0", null ]
];