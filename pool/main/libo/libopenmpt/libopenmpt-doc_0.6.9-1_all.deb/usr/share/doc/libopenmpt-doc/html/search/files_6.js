var searchData=
[
  ['openmpt_5fstyleguide_2emd_0',['openmpt_styleguide.md',['../openmpt__styleguide_8md.html',1,'']]]
];
