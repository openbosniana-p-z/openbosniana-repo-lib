var searchData=
[
  ['dependencies_0',['Dependencies',['../dependencies.html',1,'']]],
  ['dependencies_2emd_1',['dependencies.md',['../dependencies_8md.html',1,'']]],
  ['deprecated_20list_2',['Deprecated List',['../deprecated.html',1,'']]]
];
