var dir_906ed1d2e1cfef5183f8ef8c105e91b2 =
[
    [ "dox", "dir_bada576b7e67d9d921bfc7fdb238634f.html", null ],
    [ "libopenmpt.h", "libopenmpt_8h.html", "libopenmpt_8h" ],
    [ "libopenmpt.hpp", "libopenmpt_8hpp.html", "libopenmpt_8hpp" ],
    [ "libopenmpt_config.h", "libopenmpt__config_8h.html", "libopenmpt__config_8h" ],
    [ "libopenmpt_ext.h", "libopenmpt__ext_8h.html", "libopenmpt__ext_8h" ],
    [ "libopenmpt_ext.hpp", "libopenmpt__ext_8hpp.html", "libopenmpt__ext_8hpp" ],
    [ "libopenmpt_stream_callbacks_buffer.h", "libopenmpt__stream__callbacks__buffer_8h.html", "libopenmpt__stream__callbacks__buffer_8h" ],
    [ "libopenmpt_stream_callbacks_fd.h", "libopenmpt__stream__callbacks__fd_8h.html", "libopenmpt__stream__callbacks__fd_8h" ],
    [ "libopenmpt_stream_callbacks_file.h", "libopenmpt__stream__callbacks__file_8h.html", "libopenmpt__stream__callbacks__file_8h" ],
    [ "libopenmpt_version.h", "libopenmpt__version_8h.html", "libopenmpt__version_8h" ]
];