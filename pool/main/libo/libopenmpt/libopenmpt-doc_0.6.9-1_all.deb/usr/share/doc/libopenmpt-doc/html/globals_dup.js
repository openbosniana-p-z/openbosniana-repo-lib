var globals_dup =
[
    [ "l", "globals.html", null ],
    [ "o", "globals_o.html", null ]
];