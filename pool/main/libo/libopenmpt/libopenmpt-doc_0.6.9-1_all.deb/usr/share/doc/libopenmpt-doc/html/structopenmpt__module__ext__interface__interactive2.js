var structopenmpt__module__ext__interface__interactive2 =
[
    [ "get_channel_panning", "structopenmpt__module__ext__interface__interactive2.html#a60b85b0cea576dda3584243192629a98", null ],
    [ "get_note_finetune", "structopenmpt__module__ext__interface__interactive2.html#ab192eb294337d4df7e269c268cb47764", null ],
    [ "note_fade", "structopenmpt__module__ext__interface__interactive2.html#a61f72b1d1a47539ebda45d03c2e60576", null ],
    [ "note_off", "structopenmpt__module__ext__interface__interactive2.html#a0b1f3033a889a502033dfdec80e5121c", null ],
    [ "set_channel_panning", "structopenmpt__module__ext__interface__interactive2.html#aba900e2b424c37b16eacde8c094ea59c", null ],
    [ "set_note_finetune", "structopenmpt__module__ext__interface__interactive2.html#af917dccde88f42db7c6c618c06419432", null ]
];