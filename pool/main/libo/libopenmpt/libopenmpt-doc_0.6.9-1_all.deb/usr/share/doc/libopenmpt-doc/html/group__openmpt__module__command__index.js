var group__openmpt__module__command__index =
[
    [ "OPENMPT_MODULE_COMMAND_EFFECT", "group__openmpt__module__command__index.html#ga6b6ad94ec42f39ef3a34914bf107dce2", null ],
    [ "OPENMPT_MODULE_COMMAND_INSTRUMENT", "group__openmpt__module__command__index.html#ga721ed1fd50f9d91d080a45c28efb1c07", null ],
    [ "OPENMPT_MODULE_COMMAND_NOTE", "group__openmpt__module__command__index.html#ga9bb889726807bf9746b605909ea4e328", null ],
    [ "OPENMPT_MODULE_COMMAND_PARAMETER", "group__openmpt__module__command__index.html#ga1dcd81f5dcb0f84e80acdfde4bff321d", null ],
    [ "OPENMPT_MODULE_COMMAND_VOLUME", "group__openmpt__module__command__index.html#ga37025421b194ce3e439c6e7a3c3f892d", null ],
    [ "OPENMPT_MODULE_COMMAND_VOLUMEEFFECT", "group__openmpt__module__command__index.html#gae5e5f9ff56fa5426db5c8290bdd26d31", null ]
];