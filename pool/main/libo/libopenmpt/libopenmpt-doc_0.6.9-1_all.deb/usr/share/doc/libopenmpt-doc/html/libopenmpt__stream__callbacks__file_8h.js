var libopenmpt__stream__callbacks__file_8h =
[
    [ "openmpt_stream_file_read_func", "group__libopenmpt__c.html#gab35f4ca3b71e20cabdc2febb5d48db87", null ],
    [ "openmpt_stream_file_seek_func", "group__libopenmpt__c.html#ga53dd106d28a4b68eea86fba6bfdd1b9a", null ],
    [ "openmpt_stream_file_tell_func", "group__libopenmpt__c.html#gaecc775ac3096e1a1060941e0ef8ee0ec", null ],
    [ "openmpt_stream_get_file_callbacks", "group__libopenmpt__c.html#gac89b0366fe1f3686bcff1be86b69c79a", null ]
];