var searchData=
[
  ['tell_0',['tell',['../structopenmpt__stream__callbacks.html#aff46dc3277047eafb6b3b04fbcdd85c5',1,'openmpt_stream_callbacks']]]
];
