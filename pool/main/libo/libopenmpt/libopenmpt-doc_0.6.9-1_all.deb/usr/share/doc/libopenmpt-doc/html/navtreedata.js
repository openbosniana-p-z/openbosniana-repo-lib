/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "libopenmpt", "index.html", [
    [ "Contents", "index.html", [
      [ "Contents", "index.html#toc", [
        [ "APIs", "index.html#toc_apis", null ]
      ] ],
      [ "Website", "index.html#toc_website", null ],
      [ "License", "index.html#toc_license", null ]
    ] ],
    [ "README", "md_README.html", null ],
    [ "Dependencies", "dependencies.html", null ],
    [ "Getting Started", "gettingstarted.html", null ],
    [ "Packaging", "packaging.html", null ],
    [ "Contributing", "md_doc_contributing.html", null ],
    [ "libopenmpt Style Guide", "md_doc_libopenmpt_styleguide.html", null ],
    [ "OpenMPT Style Guide", "md_doc_openmpt_styleguide.html", null ],
    [ "Tests", "tests.html", null ],
    [ "Changelog", "changelog.html", null ],
    [ "Adding support for new module formats", "md_doc_module_formats.html", null ],
    [ "C++ API", "libopenmpt_cpp_overview.html", [
      [ "Error Handling", "libopenmpt_cpp_overview.html#libopenmpt_cpp_error", null ],
      [ "Strings", "libopenmpt_cpp_overview.html#libopenmpt_cpp_strings", null ],
      [ "File I/O", "libopenmpt_cpp_overview.html#libopenmpt_cpp_fileio", null ],
      [ "Output Format", "libopenmpt_cpp_overview.html#libopenmpt_cpp_outputformat", null ],
      [ "libopenmpt in multi-threaded environments", "libopenmpt_cpp_overview.html#libopenmpt_cpp_threads", null ],
      [ "Windows support", "libopenmpt_cpp_overview.html#libopenmpt-cpp-windows", null ],
      [ "Detailed documentation", "libopenmpt_cpp_overview.html#libopenmpt-cpp-detailed", null ],
      [ "Example", "libopenmpt_cpp_overview.html#libopenmpt_cpp_examples", null ]
    ] ],
    [ "C API", "libopenmpt_c_overview.html", [
      [ "Error Handling", "libopenmpt_c_overview.html#libopenmpt_c_error", null ],
      [ "Strings", "libopenmpt_c_overview.html#libopenmpt_c_strings", null ],
      [ "File I/O", "libopenmpt_c_overview.html#libopenmpt_c_fileio", null ],
      [ "Output Format", "libopenmpt_c_overview.html#libopenmpt_c_outputformat", null ],
      [ "libopenmpt in multi-threaded environments", "libopenmpt_c_overview.html#libopenmpt_c_threads", null ],
      [ "Statically linking to libopenmpt", "libopenmpt_c_overview.html#libopenmpt_c_staticlinking", null ],
      [ "Detailed documentation", "libopenmpt_c_overview.html#libopenmpt_c_detailed", null ],
      [ "Examples", "libopenmpt_c_overview.html#libopenmpt_c_examples", [
        [ "Unsafe, simplified example without any error checking to get a first idea of the API", "libopenmpt_c_overview.html#libopenmpt_c_example_unsafe", null ],
        [ "FILE*", "libopenmpt_c_overview.html#libopenmpt_c_example_file", null ],
        [ "in memory", "libopenmpt_c_overview.html#libopenmpt_c_example_inmemory", null ],
        [ "reading FILE* and writing PCM data to STDOUT (usable without PortAudio)", "libopenmpt_c_overview.html#libopenmpt_c_example_stdout", null ]
      ] ]
    ] ],
    [ "libopenmpt_ext C++ API", "libopenmpt_ext_cpp_overview.html", [
      [ "Detailed documentation", "libopenmpt_ext_cpp_overview.html#libopenmpt-ext-cpp-detailed", null ]
    ] ],
    [ "libopenmpt_ext C API", "libopenmpt_ext_c_overview.html", [
      [ "Detailed documentation", "libopenmpt_ext_c_overview.html#libopenmpt-ext-c-detailed", null ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"group__libopenmpt__c.html#ga789b4493a0ee3a3a6d145561bbbc2b97",
"structopenmpt__module__ext__interface__interactive2.html#a0b1f3033a889a502033dfdec80e5121c"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';