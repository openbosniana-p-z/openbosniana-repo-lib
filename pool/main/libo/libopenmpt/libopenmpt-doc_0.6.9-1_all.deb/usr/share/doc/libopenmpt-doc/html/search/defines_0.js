var searchData=
[
  ['libopenmpt_5fdeprecated_0',['LIBOPENMPT_DEPRECATED',['../libopenmpt__config_8h.html#a5c103073ee00995ffb7e1316c90d9f1c',1,'libopenmpt_config.h']]],
  ['libopenmpt_5fdeprecated_5fstring_1',['LIBOPENMPT_DEPRECATED_STRING',['../libopenmpt__config_8h.html#ac5bc96313b3c556c123c9fec7ee95f22',1,'libopenmpt_config.h']]]
];
