var indexSectionsWithContent =
{
  0: "acdefghilmnoprstvw~",
  1: "eimop",
  2: "o",
  3: "cdgilmoprt",
  4: "cefghimnoprsw~",
  5: "cfgilnoprstv",
  6: "o",
  7: "cepr",
  8: "cepr",
  9: "m",
  10: "l",
  11: "lpr",
  12: "acdgloprt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "groups",
  12: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Modules",
  12: "Pages"
};

