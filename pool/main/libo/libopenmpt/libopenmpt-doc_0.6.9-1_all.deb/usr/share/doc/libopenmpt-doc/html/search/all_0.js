var searchData=
[
  ['adding_20support_20for_20new_20module_20formats_0',['Adding support for new module formats',['../md_doc_module_formats.html',1,'']]]
];
