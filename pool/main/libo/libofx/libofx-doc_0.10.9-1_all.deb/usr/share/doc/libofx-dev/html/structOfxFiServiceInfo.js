var structOfxFiServiceInfo =
[
    [ "accountlist", "structOfxFiServiceInfo.html#aaecf3ea65f7ccd118d1264739da3f915", null ],
    [ "billpay", "structOfxFiServiceInfo.html#a40a3cf5456923865ec22cc3bb2e3b07c", null ],
    [ "investments", "structOfxFiServiceInfo.html#a37b1522705817d12494f524658d7633b", null ],
    [ "statements", "structOfxFiServiceInfo.html#a49e460457156291004eed7c1841c9efe", null ]
];