var structOfxPositionData =
[
    [ "HeldInAccountType", "structOfxPositionData.html#a3809b9f2512933e12c49c6f2129b51ed", [
      [ "OFX_HELDINACCT_CASH", "structOfxPositionData.html#a3809b9f2512933e12c49c6f2129b51eda0cb9c78d9427ac63d5f04e2ea962712c", null ],
      [ "OFX_HELDINACCT_MARGIN", "structOfxPositionData.html#a3809b9f2512933e12c49c6f2129b51eda8527a9965c8f601a3e9604332ea8b0f9", null ],
      [ "OFX_HELDINACCT_SHORT", "structOfxPositionData.html#a3809b9f2512933e12c49c6f2129b51edad0f73cbe90a0e5691d7717f70299f365", null ],
      [ "OFX_HELDINACCT_OTHER", "structOfxPositionData.html#a3809b9f2512933e12c49c6f2129b51eda05dde2bfaacbedaf10d6398fa5b2ca70", null ]
    ] ],
    [ "Inv401kPosnSource", "structOfxPositionData.html#af14475128e0483b33f7d481e0fd7d908", [
      [ "OFX_401K_POSN_SOURCE_PRETAX", "structOfxPositionData.html#af14475128e0483b33f7d481e0fd7d908a78a72360be0ffce0f2c88d5b554bed5d", null ],
      [ "OFX_401K_POSN_SOURCE_AFTERTAX", "structOfxPositionData.html#af14475128e0483b33f7d481e0fd7d908adf75144046fc7203059e621fd0dd7ed0", null ],
      [ "OFX_401K_POSN_SOURCE_MATCH", "structOfxPositionData.html#af14475128e0483b33f7d481e0fd7d908aa4906ffe63d3edc8bfb5a97900599667", null ],
      [ "OFX_401K_POSN_SOURCE_PROFITSHARING", "structOfxPositionData.html#af14475128e0483b33f7d481e0fd7d908aed2b758ceef3866984a181c4ae8365b2", null ],
      [ "OFX_401K_POSN_SOURCE_ROLLOVER", "structOfxPositionData.html#af14475128e0483b33f7d481e0fd7d908a503b8ef06886dacf33f2d7cc02c96762", null ],
      [ "OFX_401K_POSN_SOURCE_OTHERVEST", "structOfxPositionData.html#af14475128e0483b33f7d481e0fd7d908a815ccee2fde25aaea6aacac9e583a507", null ],
      [ "OFX_401K_POSN_SOURCE_OTHERNONVEST", "structOfxPositionData.html#af14475128e0483b33f7d481e0fd7d908a8f025792924220a355276cea2945e9a2", null ]
    ] ],
    [ "PositionType", "structOfxPositionData.html#a6d30af9660308d59ff61f336b8a526cd", [
      [ "OFX_POSITION_SHORT", "structOfxPositionData.html#a6d30af9660308d59ff61f336b8a526cda2cdff53ab93d648e0136ba3c54873c99", null ],
      [ "OFX_POSITION_LONG", "structOfxPositionData.html#a6d30af9660308d59ff61f336b8a526cda33d2329fa895f4528bcd03703f462fb3", null ]
    ] ],
    [ "account_id", "structOfxPositionData.html#a8bb52c2c6ab3ec906cb47de6bd4e4555", null ],
    [ "account_ptr", "structOfxPositionData.html#a6fda609c6a18f0e1756bad2bcbe78156", null ],
    [ "amounts_are_foreign_currency", "structOfxPositionData.html#a824afa539479725afbcd442acfc69df6", null ],
    [ "currency", "structOfxPositionData.html#a006045cf8d595fa033917fbf7d210cca", null ],
    [ "currency_ratio", "structOfxPositionData.html#a8c190c7f25db1d6c60cccf69004ad9af", null ],
    [ "date_unit_price", "structOfxPositionData.html#a94c3555b62cc34886572754b19874802", null ],
    [ "market_value", "structOfxPositionData.html#ae5b96d6a946cb466c1e3657082b09b0a", null ],
    [ "memo", "structOfxPositionData.html#a06fabd17e464a64b3adeff5b42779a92", null ],
    [ "security_data_ptr", "structOfxPositionData.html#a4cc488c7c36f42431f02438e2f24ed2f", null ],
    [ "unique_id", "structOfxPositionData.html#a9b0d41d9144cf145d630e4414f2be3ad", null ],
    [ "unique_id_type", "structOfxPositionData.html#a7e284b893d9f0cc8a53d29ee2c4e65c6", null ],
    [ "unit_price", "structOfxPositionData.html#ade46ad784d7ebc0cde2cc1cd12121d67", null ],
    [ "units", "structOfxPositionData.html#a69fb79dd667d52c801e98a6899609079", null ]
];