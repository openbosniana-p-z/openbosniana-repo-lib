var ofx__aggregate_8hh =
[
    [ "OfxAggregate", "classOfxAggregate.html", "classOfxAggregate" ]
];