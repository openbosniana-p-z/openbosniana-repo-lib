var ofx__request_8hh =
[
    [ "OfxRequest", "classOfxRequest.html", "classOfxRequest" ]
];