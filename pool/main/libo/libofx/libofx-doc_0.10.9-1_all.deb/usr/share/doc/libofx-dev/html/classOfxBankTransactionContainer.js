var classOfxBankTransactionContainer =
[
    [ "add_attribute", "classOfxBankTransactionContainer.html#a48fdbe6c2c77bc35371494fc030a1bd7", null ]
];