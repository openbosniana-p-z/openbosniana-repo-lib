var classOfxPaymentRequest =
[
    [ "OfxPaymentRequest", "classOfxPaymentRequest.html#ace1a35797c9b4d7a81f6cc43870bc909", null ]
];