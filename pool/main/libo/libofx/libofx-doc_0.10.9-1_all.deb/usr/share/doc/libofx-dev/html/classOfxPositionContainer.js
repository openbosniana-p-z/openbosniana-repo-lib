var classOfxPositionContainer =
[
    [ "add_attribute", "classOfxPositionContainer.html#a7829645604b106ff2019e78366f211bc", null ],
    [ "add_to_main_tree", "classOfxPositionContainer.html#a1ab50f7a3c5dca422336628c4e1a6611", null ],
    [ "gen_event", "classOfxPositionContainer.html#a635d4ef86cf302d84554ccf3f8146262", null ]
];