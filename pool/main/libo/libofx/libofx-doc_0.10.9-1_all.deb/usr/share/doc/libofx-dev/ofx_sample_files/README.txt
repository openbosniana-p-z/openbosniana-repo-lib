
# How to generate fake OFX files

git clone https://github.com/wesabe/fixofx

fixofx/fakeofx.py > fake.ofx

