var classOfxStatementContainer =
[
    [ "add_attribute", "classOfxStatementContainer.html#ade7f47fc3e4b073aaee5b8f3b14e52ef", null ],
    [ "add_to_main_tree", "classOfxStatementContainer.html#a4adfcf202dce4a8bfea9a05c7a137c1d", null ],
    [ "gen_event", "classOfxStatementContainer.html#a0b0b76db66caad13b369e59604f14fc7", null ]
];