var classtree_1_1iterator__base =
[
    [ "number_of_children", "classtree_1_1iterator__base.html#ae6f2ec470dac0149858add00617f51a7", null ],
    [ "skip_children", "classtree_1_1iterator__base.html#aa0be7989b9dd4c5bcdcc0d47a56d11fb", null ]
];