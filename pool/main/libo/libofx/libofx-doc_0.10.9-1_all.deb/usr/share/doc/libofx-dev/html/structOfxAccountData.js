var structOfxAccountData =
[
    [ "AccountType", "structOfxAccountData.html#a3835390f3072fc32736780f44ab10284", [
      [ "OFX_CHECKING", "structOfxAccountData.html#a3835390f3072fc32736780f44ab10284ad9b76c9857665ad41ee5ff9bdf60e9a1", null ],
      [ "OFX_SAVINGS", "structOfxAccountData.html#a3835390f3072fc32736780f44ab10284a41c3f182f0f117582f67c3e8ebaefc34", null ],
      [ "OFX_MONEYMRKT", "structOfxAccountData.html#a3835390f3072fc32736780f44ab10284a9355488b6f4c0830e893e21d9dc8238e", null ],
      [ "OFX_CREDITLINE", "structOfxAccountData.html#a3835390f3072fc32736780f44ab10284a52a9748e2314d66809486b13f044adbe", null ],
      [ "OFX_CMA", "structOfxAccountData.html#a3835390f3072fc32736780f44ab10284ac17a15b38a5d1b6301784f4f305c3a84", null ],
      [ "OFX_CREDITCARD", "structOfxAccountData.html#a3835390f3072fc32736780f44ab10284a50d60a1de463ff67520ae166b2e4621b", null ],
      [ "OFX_INVESTMENT", "structOfxAccountData.html#a3835390f3072fc32736780f44ab10284a94e2fcdfda54caf2bfad239ec15d30d1", null ],
      [ "OFX_401K", "structOfxAccountData.html#a3835390f3072fc32736780f44ab10284ad2a5bc7c5d6db2b016162b7bf95cb66a", null ]
    ] ],
    [ "account_id", "structOfxAccountData.html#ae08597870770f93cf90482e5c8181584", null ],
    [ "account_name", "structOfxAccountData.html#a34c9dc218ada74340388adcd81ef250c", null ],
    [ "account_number", "structOfxAccountData.html#a46ee3629517746b7074f6d7cc6732152", null ],
    [ "bank_id", "structOfxAccountData.html#a1a5b2b22d725ae3dab3da7f1ffae1963", null ],
    [ "currency", "structOfxAccountData.html#ae29db6c6b878188d600b16cd5084d808", null ]
];