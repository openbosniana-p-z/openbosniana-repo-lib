var ofc__sgml_8cpp =
[
    [ "OFCApplication", "classOFCApplication.html", "classOFCApplication" ],
    [ "ofc_proc_sgml", "ofc__sgml_8cpp.html#ac917eca177be8a01174db7d80716689a", null ],
    [ "entity_ptr", "ofc__sgml_8cpp.html#aadaa870f35b4a4fb6b268ae8ea872ccf", null ],
    [ "position", "ofc__sgml_8cpp.html#a4da8008b6f110050513003edf67a2495", null ]
];