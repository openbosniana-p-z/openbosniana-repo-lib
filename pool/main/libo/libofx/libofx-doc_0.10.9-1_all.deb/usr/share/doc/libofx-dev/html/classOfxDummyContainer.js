var classOfxDummyContainer =
[
    [ "add_attribute", "classOfxDummyContainer.html#a2b24c7544c70f32ed46e2e673bd03cbe", null ]
];