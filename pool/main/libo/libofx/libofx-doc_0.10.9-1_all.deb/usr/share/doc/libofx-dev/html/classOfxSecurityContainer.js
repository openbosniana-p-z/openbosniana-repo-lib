var classOfxSecurityContainer =
[
    [ "add_attribute", "classOfxSecurityContainer.html#a440b8135e73e72ec44663ed149be76e3", null ],
    [ "add_to_main_tree", "classOfxSecurityContainer.html#acbaa6366a60d903ee3b3748c9874157f", null ],
    [ "gen_event", "classOfxSecurityContainer.html#a22357ade2036de78947ac0cc0ce01f2d", null ]
];