var classOfxTransactionContainer =
[
    [ "add_attribute", "classOfxTransactionContainer.html#aaa8214545b69d0acdd982cf79e0ec5ea", null ],
    [ "add_to_main_tree", "classOfxTransactionContainer.html#af3e7ffa3a55d3c0c67229c436875ed1d", null ],
    [ "gen_event", "classOfxTransactionContainer.html#a733ee231fef8e72248cd9ab78b169a99", null ]
];