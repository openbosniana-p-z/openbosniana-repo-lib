var structLibofxFileFormatInfo =
[
    [ "description", "structLibofxFileFormatInfo.html#a6951dcf0a992fc8a03b721fa0f39670e", null ],
    [ "format", "structLibofxFileFormatInfo.html#ae4b1aa0050ffdc43ce68f07e6330d2f7", null ],
    [ "format_name", "structLibofxFileFormatInfo.html#a18c4db6bd435fd877ae2eb24d93553e6", null ]
];