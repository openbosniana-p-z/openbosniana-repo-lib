var classOfxBalanceContainer =
[
    [ "add_attribute", "classOfxBalanceContainer.html#a10c7f394a79443afaf49455b9a3fa629", null ],
    [ "amount", "classOfxBalanceContainer.html#afff1080e7dc3a6f6e09f1c0d9c1dc68f", null ],
    [ "date", "classOfxBalanceContainer.html#a63069560ec9ee3524688452b00f0a39d", null ],
    [ "date_valid", "classOfxBalanceContainer.html#a6db99feb3a273a0de86d96cb2e619eec", null ],
    [ "margin_balance_valid", "classOfxBalanceContainer.html#a5862922c29e3fc26d2d5adc396a61770", null ],
    [ "short_balance_valid", "classOfxBalanceContainer.html#ad2413af7247d7681ef7a244c2fefeb85", null ]
];