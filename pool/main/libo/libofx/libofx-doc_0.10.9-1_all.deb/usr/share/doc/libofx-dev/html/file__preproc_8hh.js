var file__preproc_8hh =
[
    [ "libofx_detect_file_type", "file__preproc_8hh.html#a34e14069654b16390599d24154b1f8d0", null ]
];