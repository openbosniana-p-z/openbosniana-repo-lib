var classOfxRequest =
[
    [ "OfxRequest", "classOfxRequest.html#aedf28b52122ebc61fab21bda14e611ea", null ],
    [ "RequestMessage", "classOfxRequest.html#aa9cc97521b37498dd2e428470eea39a9", null ],
    [ "SignOnRequest", "classOfxRequest.html#aa72d77df77692683e34cb688fb076bc8", null ]
];