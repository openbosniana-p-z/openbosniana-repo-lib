var ofx__sgml_8cpp =
[
    [ "OFXApplication", "classOFXApplication.html", "classOFXApplication" ],
    [ "ofx_proc_sgml", "ofx__sgml_8cpp.html#a43d6f8c7f5989494627bf2eda6c8e066", null ],
    [ "entity_ptr", "ofx__sgml_8cpp.html#aadaa870f35b4a4fb6b268ae8ea872ccf", null ],
    [ "position", "ofx__sgml_8cpp.html#a4da8008b6f110050513003edf67a2495", null ]
];