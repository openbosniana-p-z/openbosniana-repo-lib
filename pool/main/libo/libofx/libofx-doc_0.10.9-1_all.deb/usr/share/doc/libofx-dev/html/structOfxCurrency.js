var structOfxCurrency =
[
    [ "currency", "structOfxCurrency.html#abe60e32bf41551c8cc4f3e35d1a0992d", null ],
    [ "exchange_rate", "structOfxCurrency.html#a42189e2f5c6b57cf09cb75689a6c1b88", null ],
    [ "must_convert", "structOfxCurrency.html#a19eb1ccd12664af9dfdb55d67641f32d", null ]
];