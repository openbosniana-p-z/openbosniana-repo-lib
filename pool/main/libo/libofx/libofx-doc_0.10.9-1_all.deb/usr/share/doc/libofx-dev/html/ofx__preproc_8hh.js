var ofx__preproc_8hh =
[
    [ "find_dtd", "ofx__preproc_8hh.html#ad3b2254621c5a5edc71df97ac5e345a7", null ],
    [ "ofx_proc_file", "ofx__preproc_8hh.html#a29dde40aaa5c2439a0799ebfc8f7a802", null ],
    [ "sanitize_proprietary_tags", "ofx__preproc_8hh.html#a23de02f6adf8ed88b3398626313755ef", null ]
];