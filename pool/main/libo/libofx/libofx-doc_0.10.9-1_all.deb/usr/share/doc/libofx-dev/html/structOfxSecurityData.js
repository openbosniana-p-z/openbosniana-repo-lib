var structOfxSecurityData =
[
    [ "AssetClass", "structOfxSecurityData.html#ac424aa82c5f954c2c600b9421ec088ac", [
      [ "OFX_ASSET_CLASS_DOMESTICBOND", "structOfxSecurityData.html#ac424aa82c5f954c2c600b9421ec088acafec6fb386e1cad95903075921d8af296", null ],
      [ "OFX_ASSET_CLASS_INTLBOND", "structOfxSecurityData.html#ac424aa82c5f954c2c600b9421ec088acaaf3edb2ac8515ff4206b99f632f011b2", null ],
      [ "OFX_ASSET_CLASS_LARGESTOCK", "structOfxSecurityData.html#ac424aa82c5f954c2c600b9421ec088acaf6e18c9742199b8382d3248a31f425c0", null ],
      [ "OFX_ASSET_CLASS_SMALLSTOCK", "structOfxSecurityData.html#ac424aa82c5f954c2c600b9421ec088acab1e92f5cbe79385b81fe64cd25ecbc22", null ],
      [ "OFX_ASSET_CLASS_INTLSTOCK", "structOfxSecurityData.html#ac424aa82c5f954c2c600b9421ec088aca5226934066896487c8009b6ef0be12d9", null ],
      [ "OFX_ASSET_CLASS_MONEYMRKT", "structOfxSecurityData.html#ac424aa82c5f954c2c600b9421ec088acae21ec660a98e75300932897415099565", null ],
      [ "OFX_ASSET_CLASS_OTHER", "structOfxSecurityData.html#ac424aa82c5f954c2c600b9421ec088aca932c3e0bec21cafcca2b614be1a74c90", null ]
    ] ],
    [ "CallType", "structOfxSecurityData.html#a8cd53b8ab8bf07d8b19d17f3c5511469", [
      [ "OFX_CALL_TYPE_CALL", "structOfxSecurityData.html#a8cd53b8ab8bf07d8b19d17f3c5511469a1f897c793b72a430bd7d0899a33283be", null ],
      [ "OFX_CALL_TYPE_PUT", "structOfxSecurityData.html#a8cd53b8ab8bf07d8b19d17f3c5511469a421f71fc3f4a1379c4ffa4189f0cb6de", null ],
      [ "OFX_CALL_TYPE_PREFUND", "structOfxSecurityData.html#a8cd53b8ab8bf07d8b19d17f3c5511469adc18573a2918ad6bbef0702dc8a41b86", null ],
      [ "OFX_CALL_TYPE_MATURITY", "structOfxSecurityData.html#a8cd53b8ab8bf07d8b19d17f3c5511469a67968c2cf593ec3f32210b1123ce1a92", null ]
    ] ],
    [ "CouponFreq", "structOfxSecurityData.html#a6c0a2b4494ef8db5c16ba482daf53860", [
      [ "OFX_COUPON_FREQ_MONTHLY", "structOfxSecurityData.html#a6c0a2b4494ef8db5c16ba482daf53860af0f4d65f4aceb2972dd7511f3f50dc2e", null ],
      [ "OFX_COUPON_FREQ_QUARTERLY", "structOfxSecurityData.html#a6c0a2b4494ef8db5c16ba482daf53860ae16037bcf84566a64b8adae5c2fae82e", null ],
      [ "OFX_COUPON_FREQ_SEMIANNUAL", "structOfxSecurityData.html#a6c0a2b4494ef8db5c16ba482daf53860a7d8026fb322a0a45d71057d88b3c2807", null ],
      [ "OFX_COUPON_FREQ_ANNUAL", "structOfxSecurityData.html#a6c0a2b4494ef8db5c16ba482daf53860aac5a554852c77d53297d5f44aa9aa6da", null ],
      [ "OFX_COUPON_FREQ_OTHER", "structOfxSecurityData.html#a6c0a2b4494ef8db5c16ba482daf53860a85464b981e991dcdfa07ac619ce6596a", null ]
    ] ],
    [ "DebtClass", "structOfxSecurityData.html#a74119b866bb85336de40e5585054c809", [
      [ "OFX_DEBTCLASS_TREASURY", "structOfxSecurityData.html#a74119b866bb85336de40e5585054c809a1114c65ebd9033bb60b80df50277270c", null ],
      [ "OFX_DEBTCLASS_MUNICIPAL", "structOfxSecurityData.html#a74119b866bb85336de40e5585054c809a90fc7c198b9d8ab9f1c6a68271e70cc3", null ],
      [ "OFX_DEBTCLASS_CORPORATE", "structOfxSecurityData.html#a74119b866bb85336de40e5585054c809a6f42df06a8b0335f7055632ee11097f2", null ],
      [ "OFX_DEBTCLASS_OTHER", "structOfxSecurityData.html#a74119b866bb85336de40e5585054c809ae9d38d60093cff3af117d04edbd3e99a", null ]
    ] ],
    [ "DebtType", "structOfxSecurityData.html#a8227d84d7ed786ad4cc2e9c68bae7d80", [
      [ "OFX_DEBT_TYPE_COUPON", "structOfxSecurityData.html#a8227d84d7ed786ad4cc2e9c68bae7d80affc274d9a5e1f3d80e30af264c963d4b", null ],
      [ "OFX_DEBT_TYPE_ZERO", "structOfxSecurityData.html#a8227d84d7ed786ad4cc2e9c68bae7d80a8ef6206c09a3cd8e1b08d594788b4478", null ]
    ] ],
    [ "MutalFundType", "structOfxSecurityData.html#a3ca3fda08840038de92b4ed0ce4d8992", [
      [ "OFX_MFTYPE_OPENEND", "structOfxSecurityData.html#a3ca3fda08840038de92b4ed0ce4d8992af1621668699716d9c8c879414e7e8647", null ],
      [ "OFX_MFTYPE_CLOSEEND", "structOfxSecurityData.html#a3ca3fda08840038de92b4ed0ce4d8992ae8e7179007b4a083057d1a2f3511f875", null ],
      [ "OFX_MFTYPE_OTHER", "structOfxSecurityData.html#a3ca3fda08840038de92b4ed0ce4d8992a687fce6a9f47d50f5229a0d3a95f0624", null ]
    ] ],
    [ "OptionType", "structOfxSecurityData.html#acf7dc4e22d4dc423bb994d9c91d0b37f", [
      [ "OFX_OPTION_TYPE_CALL", "structOfxSecurityData.html#acf7dc4e22d4dc423bb994d9c91d0b37fa7279f46f2b860ac52106511e296bc940", null ],
      [ "OFX_OPTION_TYPE_PUT", "structOfxSecurityData.html#acf7dc4e22d4dc423bb994d9c91d0b37fa6d4c7661cc8f36a271ba8c23d80008d9", null ]
    ] ],
    [ "SecurityType", "structOfxSecurityData.html#a79dcf4b41ec95dd1543594ac6e9f7d39", [
      [ "OFX_DEBT_SECURITY", "structOfxSecurityData.html#a79dcf4b41ec95dd1543594ac6e9f7d39ae82bbb6c860dcfe2a309afb14829ebc4", null ],
      [ "OFX_FUND_SECURITY", "structOfxSecurityData.html#a79dcf4b41ec95dd1543594ac6e9f7d39aef4a0e4dd79900f7ceb9a325421c9ba4", null ],
      [ "OFX_OPTION_SECURITY", "structOfxSecurityData.html#a79dcf4b41ec95dd1543594ac6e9f7d39aeaf80ae5fc3c94e5afcd63f7cb1c817a", null ],
      [ "OFX_STOCK_SECURITY", "structOfxSecurityData.html#a79dcf4b41ec95dd1543594ac6e9f7d39ae3f63a8afc27fd92f0184701b35facea", null ],
      [ "OFX_OTHER_SECURITY", "structOfxSecurityData.html#a79dcf4b41ec95dd1543594ac6e9f7d39a097cc2801491a733c3f62a4e55e69d43", null ]
    ] ],
    [ "StockType", "structOfxSecurityData.html#a9058e02bc22cf8561f3a322a4490734d", [
      [ "OFX_STOCKTYPE_COMMON", "structOfxSecurityData.html#a9058e02bc22cf8561f3a322a4490734dadfd5f188751b164e6cb7312c412a3821", null ],
      [ "OFX_STOCKTYPE_PREFERRED", "structOfxSecurityData.html#a9058e02bc22cf8561f3a322a4490734dafa817487aa72d0df1b396ea0e89384cd", null ],
      [ "OFX_STOCKTYPE_CONVERTIBLE", "structOfxSecurityData.html#a9058e02bc22cf8561f3a322a4490734da4cc6c20a223d72e558e1cfd358240d28", null ],
      [ "OFX_STOCKTYPE_OTHER", "structOfxSecurityData.html#a9058e02bc22cf8561f3a322a4490734da811749ed6732e017d61a6a194b2a0020", null ]
    ] ],
    [ "amounts_are_foreign_currency", "structOfxSecurityData.html#a615385b0c0b7b765a89b5f43e6309aba", null ],
    [ "call_date", "structOfxSecurityData.html#a3567e0c9eb1434caa985ce4ec4f7486a", null ],
    [ "call_price", "structOfxSecurityData.html#a6f66f766632a18f6b26805ac333097c2", null ],
    [ "coupon_rate", "structOfxSecurityData.html#acf641ad3d513d03e8c393196f0662196", null ],
    [ "currency", "structOfxSecurityData.html#a57f148fe703f73ea110e24c5470a9242", null ],
    [ "currency_ratio", "structOfxSecurityData.html#a0d64d0154fdc4f212e989ad4ce25833f", null ],
    [ "date_coupon", "structOfxSecurityData.html#a78c51cc45a75ddefffd23246e52c6b7f", null ],
    [ "date_expire", "structOfxSecurityData.html#a9210a0da7a19639040e8cfbee00da324", null ],
    [ "date_unitprice", "structOfxSecurityData.html#a39f70a97d1390f293a9726a014ed5736", null ],
    [ "fiasset_class", "structOfxSecurityData.html#a5e5e9e2888a219fa2830ac735af9a68a", null ],
    [ "fiid", "structOfxSecurityData.html#a09833d3d62eebdc026bf0aa2df01f789", null ],
    [ "maturity_date", "structOfxSecurityData.html#a050713fce76ddf5c38e123eb8b26ada7", null ],
    [ "memo", "structOfxSecurityData.html#ac29fe2ecb97aefb8eb18471045fdfedf", null ],
    [ "par_value", "structOfxSecurityData.html#a93edcd332d0a2f9b0246d8a54160b996", null ],
    [ "rating", "structOfxSecurityData.html#a6b49bc2d32cd199b048b5be52bc7f56a", null ],
    [ "secname", "structOfxSecurityData.html#a6040f74d90d7e379069668e9377f05a7", null ],
    [ "shares_per_cont", "structOfxSecurityData.html#ac232455c5459636cbe28435584a2cfc1", null ],
    [ "strike_price", "structOfxSecurityData.html#a3a0258620dfe854661057a687831f2ac", null ],
    [ "ticker", "structOfxSecurityData.html#afe1b8fb89161e47a1252bf6e6b13d624", null ],
    [ "unique_id", "structOfxSecurityData.html#a074c29532d07fe5dc782f50a5ce0bce5", null ],
    [ "unique_id2", "structOfxSecurityData.html#a1a2568a73549da1143ac587758f96972", null ],
    [ "unique_id2_type", "structOfxSecurityData.html#a714015495e7aba11f01c1edf41b03a03", null ],
    [ "unique_id_type", "structOfxSecurityData.html#aaa852fc186b988a50d48b7b72b35d97b", null ],
    [ "unitprice", "structOfxSecurityData.html#ab7e970b0d2efb4afd77e5140f6377eea", null ],
    [ "yield", "structOfxSecurityData.html#a63123544c38b153f30e681f7cfb3bb13", null ],
    [ "yield_asof_date", "structOfxSecurityData.html#a05c3ee892efe5f737a5ee40ed7983611", null ],
    [ "yield_to_call", "structOfxSecurityData.html#a5fd499d4dd76e1846a2d650307d1d7be", null ],
    [ "yield_to_maturity", "structOfxSecurityData.html#a7d0cb049ab1bed655073c0560509024e", null ]
];