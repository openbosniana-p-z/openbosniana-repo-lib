var structOfxStatusData =
[
    [ "Severity", "structOfxStatusData.html#a9e9ac7b5db3c10f2f42cc0225a016187", [
      [ "INFO", "structOfxStatusData.html#a9e9ac7b5db3c10f2f42cc0225a016187aceb914234629c4ac1b1eee5c0f3b749a", null ],
      [ "WARN", "structOfxStatusData.html#a9e9ac7b5db3c10f2f42cc0225a016187a211f66989688dab19596b9fa877b26de", null ],
      [ "ERROR", "structOfxStatusData.html#a9e9ac7b5db3c10f2f42cc0225a016187a90d5678c4bd538a2cd875cb4f06b63e5", null ]
    ] ],
    [ "code", "structOfxStatusData.html#a7c331e4729b921be2eaf234498ffe19c", null ],
    [ "code_valid", "structOfxStatusData.html#aea08b7a14fa90d26ef192fab683e09d1", null ],
    [ "description", "structOfxStatusData.html#abed5e1b74714010d7d6c313ef04e5961", null ],
    [ "name", "structOfxStatusData.html#ae68c2b035377d22d01f89179fc14fdbe", null ],
    [ "ofx_element_name_valid", "structOfxStatusData.html#a011f73b45f88aac63ec44727ed6b306d", null ],
    [ "server_message", "structOfxStatusData.html#a87b34b7c11d62409761aa24a5f43e393", null ]
];