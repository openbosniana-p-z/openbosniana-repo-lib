var classOfxAggregate =
[
    [ "OfxAggregate", "classOfxAggregate.html#ac3f642e485903c146e1b7b2b5a4415c1", null ],
    [ "Add", "classOfxAggregate.html#a2b729bb656f47efcf2bcfffaa22814e9", null ],
    [ "Add", "classOfxAggregate.html#a9058d93eddf246656fedb6f8f7241606", null ],
    [ "AddXml", "classOfxAggregate.html#a9ac02630c36d8426cad4a3357ba3b48b", null ],
    [ "Output", "classOfxAggregate.html#a5335efe380c2d7241ddc9ebaba523184", null ]
];