var namespaces_dup =
[
    [ "kp", "namespacekp.html", null ]
];