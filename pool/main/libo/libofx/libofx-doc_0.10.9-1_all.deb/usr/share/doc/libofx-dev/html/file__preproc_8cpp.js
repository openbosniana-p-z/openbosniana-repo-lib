var file__preproc_8cpp =
[
    [ "libofx_detect_file_type", "file__preproc_8cpp.html#a34e14069654b16390599d24154b1f8d0", null ],
    [ "libofx_get_file_format_description", "file__preproc_8cpp.html#a4b53751d83fc9da8b051c55e8b764ecd", null ],
    [ "libofx_get_file_format_from_str", "file__preproc_8cpp.html#a3bf84ecbf6ca512ea73d204c64972dbc", null ],
    [ "libofx_proc_file", "file__preproc_8cpp.html#a7d14db73e2f828250874b6311c3d85ed", null ]
];