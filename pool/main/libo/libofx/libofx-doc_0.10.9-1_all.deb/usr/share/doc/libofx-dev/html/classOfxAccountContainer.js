var classOfxAccountContainer =
[
    [ "add_attribute", "classOfxAccountContainer.html#a438f2fb939edfc9456b16c7f43f7b811", null ],
    [ "add_to_main_tree", "classOfxAccountContainer.html#a995f1933b2ecb3e33f991c092fbf3af4", null ],
    [ "gen_event", "classOfxAccountContainer.html#a20381080f3bdd19af2b2c364f208cdf4", null ]
];