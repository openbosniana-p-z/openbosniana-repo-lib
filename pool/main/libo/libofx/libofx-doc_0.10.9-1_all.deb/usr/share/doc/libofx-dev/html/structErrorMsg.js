var structErrorMsg =
[
    [ "code", "structErrorMsg.html#a1308f8c77806e8c2a78f59ea17a6401d", null ],
    [ "description", "structErrorMsg.html#af79b973bc93afa2d85bdebe7db18155f", null ],
    [ "name", "structErrorMsg.html#ac1eea419b5ed61d97b8ec5f03a9bd7b8", null ]
];