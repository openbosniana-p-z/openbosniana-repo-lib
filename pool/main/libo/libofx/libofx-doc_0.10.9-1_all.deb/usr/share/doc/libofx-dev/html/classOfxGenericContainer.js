var classOfxGenericContainer =
[
    [ "add_attribute", "classOfxGenericContainer.html#ae6bd885ab10dffb4aea0b8957ff1137d", null ],
    [ "add_to_main_tree", "classOfxGenericContainer.html#ae9ddc283e5d9a2853d7e02b4d9584036", null ],
    [ "gen_event", "classOfxGenericContainer.html#aa8ffd0a68bcea4f0048b392af5078105", null ],
    [ "getparent", "classOfxGenericContainer.html#a3d6e18d61e9e8f43a956e50cc5f90597", null ],
    [ "tag_identifier", "classOfxGenericContainer.html#a08c34f6c6e89d381811dcba3261d9ea9", null ],
    [ "type", "classOfxGenericContainer.html#afe76199bde4bc07bc33b09ed403e8ab4", null ]
];