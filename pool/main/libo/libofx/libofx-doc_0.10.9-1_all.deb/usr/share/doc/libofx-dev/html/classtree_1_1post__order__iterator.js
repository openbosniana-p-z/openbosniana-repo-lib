var classtree_1_1post__order__iterator =
[
    [ "descend_all", "classtree_1_1post__order__iterator.html#aca4676b4986854521cfa2c7d84f62204", null ]
];