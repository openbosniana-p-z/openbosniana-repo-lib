var structOfxStatementData =
[
    [ "account_id", "structOfxStatementData.html#ab70e47f59a47fc7c10a769ed762abc7f", null ],
    [ "account_ptr", "structOfxStatementData.html#a66b74dfa48ca2b9e606ba408c30fa0aa", null ],
    [ "available_balance", "structOfxStatementData.html#acf7c63320e41ced7f5d44beb2f791118", null ],
    [ "available_balance_date", "structOfxStatementData.html#a5062a88aaae023cd5506db8991187c1c", null ],
    [ "buying_power", "structOfxStatementData.html#a230097f0ddbf0e92c6397305be224104", null ],
    [ "currency", "structOfxStatementData.html#a3d36bcd5a15690df75a84514c93e0375", null ],
    [ "date_asof", "structOfxStatementData.html#a216cce0f70d93e56c4d710736ca6de91", null ],
    [ "date_end", "structOfxStatementData.html#ab6d37c27b538fb2f3915c678b97a6cad", null ],
    [ "date_start", "structOfxStatementData.html#acd1d926a3a78af15f635a9fd1849dbc0", null ],
    [ "ledger_balance", "structOfxStatementData.html#a0827aef2ae2cd523320ea479dfae5cdc", null ],
    [ "ledger_balance_date", "structOfxStatementData.html#a57f9892d09da4a6d69c44b7f9af45fc0", null ],
    [ "margin_balance", "structOfxStatementData.html#a0106930e7238f19464be8d98d08ce47a", null ],
    [ "marketing_info", "structOfxStatementData.html#af694d67a70fe782a155cbbb425a5e96c", null ],
    [ "short_balance", "structOfxStatementData.html#a897bdff9e42476ef058b40ac21c12944", null ]
];