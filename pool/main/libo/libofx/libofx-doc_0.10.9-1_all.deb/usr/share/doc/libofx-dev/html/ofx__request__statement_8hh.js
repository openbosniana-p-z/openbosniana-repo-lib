var ofx__request__statement_8hh =
[
    [ "OfxStatementRequest", "classOfxStatementRequest.html", "classOfxStatementRequest" ],
    [ "OfxPaymentRequest", "classOfxPaymentRequest.html", "classOfxPaymentRequest" ]
];