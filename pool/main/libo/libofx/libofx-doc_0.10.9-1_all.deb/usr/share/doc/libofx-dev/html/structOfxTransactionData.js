var structOfxTransactionData =
[
    [ "BuyType", "structOfxTransactionData.html#ab300cf2ec67d87494e90eb02a9755289", [
      [ "OFX_BUY_TYPE_BUY", "structOfxTransactionData.html#ab300cf2ec67d87494e90eb02a9755289a29780e8e4bf9ed41a6066a80bfe0f8f7", null ],
      [ "OFX_BUY_TYPE_BUYTOCOVER", "structOfxTransactionData.html#ab300cf2ec67d87494e90eb02a9755289a5c778845f1b2c0efd0064be97545b761", null ],
      [ "OFX_BUY_TYPE_BUYTOOPEN", "structOfxTransactionData.html#ab300cf2ec67d87494e90eb02a9755289a3e77e3bf835221fdea7d213cc1443b41", null ],
      [ "OFX_BUY_TYPE_BUYTOCLOSE", "structOfxTransactionData.html#ab300cf2ec67d87494e90eb02a9755289a8e5e8c14b36335346f87369d9940137b", null ]
    ] ],
    [ "IncomeType", "structOfxTransactionData.html#a9c1ba992cfc543444b3f380d4ea0dd5c", [
      [ "OFX_CGLONG", "structOfxTransactionData.html#a9c1ba992cfc543444b3f380d4ea0dd5cadf9ddc37943f423d7caca2b99c546611", null ],
      [ "OFX_CGSHORT", "structOfxTransactionData.html#a9c1ba992cfc543444b3f380d4ea0dd5ca99ebd01fe1ae46705ac516bc7ed8b8d9", null ],
      [ "OFX_DIVIDEND", "structOfxTransactionData.html#a9c1ba992cfc543444b3f380d4ea0dd5caebb12515e9e4ce7442e5a35885f6103a", null ],
      [ "OFX_INTEREST", "structOfxTransactionData.html#a9c1ba992cfc543444b3f380d4ea0dd5ca0232ac0182d702a3e666602f15d2c09c", null ],
      [ "OFX_MISC", "structOfxTransactionData.html#a9c1ba992cfc543444b3f380d4ea0dd5ca274b77616f61c96bb1b8d77075bb6bc0", null ]
    ] ],
    [ "Inv401kSource", "structOfxTransactionData.html#a199385c8b6e22115435232fee5c6c343", [
      [ "OFX_401K_SOURCE_PRETAX", "structOfxTransactionData.html#a199385c8b6e22115435232fee5c6c343ae8afe56e00bade3100ff7a091ca86e45", null ],
      [ "OFX_401K_SOURCE_AFTERTAX", "structOfxTransactionData.html#a199385c8b6e22115435232fee5c6c343a2216782019ed9b2a21ce4e95266e0fe8", null ],
      [ "OFX_401K_SOURCE_MATCH", "structOfxTransactionData.html#a199385c8b6e22115435232fee5c6c343a33a6b33622ea8d59a06142d14018f657", null ],
      [ "OFX_401K_SOURCE_PROFITSHARING", "structOfxTransactionData.html#a199385c8b6e22115435232fee5c6c343ae68f9aa950acbdfd47a27859cb86478f", null ],
      [ "OFX_401K_SOURCE_ROLLOVER", "structOfxTransactionData.html#a199385c8b6e22115435232fee5c6c343a151ebf18ceff6b4d8bf2da73bc76a596", null ],
      [ "OFX_401K_SOURCE_OTHERVEST", "structOfxTransactionData.html#a199385c8b6e22115435232fee5c6c343a2b291114906a9e886300388a7315e8d6", null ],
      [ "OFX_401K_SOURCE_OTHERNONVEST", "structOfxTransactionData.html#a199385c8b6e22115435232fee5c6c343acf0e2ea94f1d078fb6966bde1f4a7682", null ]
    ] ],
    [ "OptAction", "structOfxTransactionData.html#a6a2dcdc985104ddb1055796f2d04baa2", [
      [ "OFX_OPTACTION_EXERCISE", "structOfxTransactionData.html#a6a2dcdc985104ddb1055796f2d04baa2a069cf0242d123aa822479fa93118da48", null ],
      [ "OFX_OPTACTION_ASSIGN", "structOfxTransactionData.html#a6a2dcdc985104ddb1055796f2d04baa2a2b00cabfe70276c89df1a94489f3db43", null ],
      [ "OFX_OPTACTION_EXPIRE", "structOfxTransactionData.html#a6a2dcdc985104ddb1055796f2d04baa2ac7cb51f7b5a8df23c9db115a79ac1b84", null ]
    ] ],
    [ "OptionSecured", "structOfxTransactionData.html#ad025e4f56cf75830276316ed3282362f", [
      [ "OFX_SECURED_NAKED", "structOfxTransactionData.html#ad025e4f56cf75830276316ed3282362fa52e8de1a1b68ce39cf12d578d8684ff0", null ],
      [ "OFX_SECURED_COVERED", "structOfxTransactionData.html#ad025e4f56cf75830276316ed3282362fac5a553e2347a80cd42338e72b6952a42", null ]
    ] ],
    [ "PosType", "structOfxTransactionData.html#a8112fe5184e279a200abc584b91c1c6a", [
      [ "OFX_POSTYPE_LONG", "structOfxTransactionData.html#a8112fe5184e279a200abc584b91c1c6aa5d04494793c2a6b65e4ac754efecb3e8", null ],
      [ "OFX_POSTYPE_SHORT", "structOfxTransactionData.html#a8112fe5184e279a200abc584b91c1c6aa296c77a9d7c912360189bffede37a312", null ]
    ] ],
    [ "RelatedType", "structOfxTransactionData.html#ae10d82d1a666569c99cd03ac6a3fd4cc", [
      [ "OFX_RELTYPE_SPREAD", "structOfxTransactionData.html#ae10d82d1a666569c99cd03ac6a3fd4cca260e6c54d7397f0f437a69943bf852be", null ],
      [ "OFX_RELTYPE_STRADDLE", "structOfxTransactionData.html#ae10d82d1a666569c99cd03ac6a3fd4cca7d0982c15b4a3079a33f8d4123b5b5e5", null ],
      [ "OFX_RELTYPE_NONE", "structOfxTransactionData.html#ae10d82d1a666569c99cd03ac6a3fd4ccaee4a12721c407a5a87d5c6bf64644a31", null ],
      [ "OFX_RELTYPE_OTHER", "structOfxTransactionData.html#ae10d82d1a666569c99cd03ac6a3fd4cca4d2341bbb12e763f28eb14bfd90a946b", null ]
    ] ],
    [ "SellReason", "structOfxTransactionData.html#a1f74cc7743543200238b475cd1a222f8", [
      [ "OFX_SELLREASON_CALL", "structOfxTransactionData.html#a1f74cc7743543200238b475cd1a222f8a8d405fc325d62c3a4f8fc0e314022627", null ],
      [ "OFX_SELLREASON_SELL", "structOfxTransactionData.html#a1f74cc7743543200238b475cd1a222f8a1476f09e728d409033d2eb505756ad6d", null ],
      [ "OFX_SELLREASON_MATURITY", "structOfxTransactionData.html#a1f74cc7743543200238b475cd1a222f8af1480b30013ed8fe71afc9cb05a7f0b2", null ]
    ] ],
    [ "SellType", "structOfxTransactionData.html#af3bf68343137fadf7521fffa1193c26c", [
      [ "OFX_SELL_TYPE_SELL", "structOfxTransactionData.html#af3bf68343137fadf7521fffa1193c26ca8f39944c51dcad72a838893415f77dd6", null ],
      [ "OFX_SELL_TYPE_SELLSHORT", "structOfxTransactionData.html#af3bf68343137fadf7521fffa1193c26cabfe8eaa2ff51747e37e27da2e0326c2d", null ],
      [ "OFX_SELL_TYPE_SELLTOOPEN", "structOfxTransactionData.html#af3bf68343137fadf7521fffa1193c26cac2d140c1e9405cfcfd71949a9296bb3e", null ],
      [ "OFX_SELL_TYPE_SELLTOCLOSE", "structOfxTransactionData.html#af3bf68343137fadf7521fffa1193c26ca626e6eeb1640613ee5deb0e03dacba2b", null ]
    ] ],
    [ "SubAcctType", "structOfxTransactionData.html#a457e0a5a7b0c42c8eff4abbd369af00e", [
      [ "OFX_SUBACCT_CASH", "structOfxTransactionData.html#a457e0a5a7b0c42c8eff4abbd369af00eaaf309fafa84290a1f076ce5a1aeb9388", null ],
      [ "OFX_SUBACCT_MARGIN", "structOfxTransactionData.html#a457e0a5a7b0c42c8eff4abbd369af00ea810702a682d625a1e40c1af8b7e9e1f6", null ],
      [ "OFX_SUBACCT_SHORT", "structOfxTransactionData.html#a457e0a5a7b0c42c8eff4abbd369af00ea8eeb3d138750846f3558c930eadc858d", null ],
      [ "OFX_SUBACCT_OTHER", "structOfxTransactionData.html#a457e0a5a7b0c42c8eff4abbd369af00ea0a393365b5a24dc13da82c80c2157a70", null ]
    ] ],
    [ "TransferAction", "structOfxTransactionData.html#a76ad4c0cfb5ddb91beb58cb7d2e44a0d", [
      [ "OFX_TFERACTION_IN", "structOfxTransactionData.html#a76ad4c0cfb5ddb91beb58cb7d2e44a0da31ac9990cba452b2dfedadabdc5529e2", null ],
      [ "OFX_TFERACTION_OUT", "structOfxTransactionData.html#a76ad4c0cfb5ddb91beb58cb7d2e44a0daac9b583ac71c0deca95962c5df767500", null ]
    ] ],
    [ "UnitType", "structOfxTransactionData.html#adb3ccf9bed37fcf6d020e2b0ed48c284", [
      [ "OFX_UNITTYPE_SHARES", "structOfxTransactionData.html#adb3ccf9bed37fcf6d020e2b0ed48c284ae0fe13662b7b65dccffc27d0ee363e8d", null ],
      [ "OFX_UNITTYPE_CURRENCY", "structOfxTransactionData.html#adb3ccf9bed37fcf6d020e2b0ed48c284a85e0bbba89da44c51c9f5565583a1855", null ]
    ] ],
    [ "account_id", "structOfxTransactionData.html#a43b272f44d3f6d23b3af12dd0d373f4b", null ],
    [ "account_ptr", "structOfxTransactionData.html#afbc7820c3edd9a07c87e345ef7d726ee", null ],
    [ "accrued_interest", "structOfxTransactionData.html#ad69199c961e93c6eb8e840ccc5196668", null ],
    [ "amount", "structOfxTransactionData.html#a8d89643cfcc66560d20d6ae857641671", null ],
    [ "amounts_are_foreign_currency", "structOfxTransactionData.html#a39d8928690f5bfabb63ec5e5e77b719a", null ],
    [ "avg_cost_basis", "structOfxTransactionData.html#afb74f9be914eca5a6ba69b72af374b00", null ],
    [ "cash_for_fractional", "structOfxTransactionData.html#a88c2ee2cd8d1d47135fb239b976259a4", null ],
    [ "check_number", "structOfxTransactionData.html#af8393a0e457b1887a3989edcc09977cf", null ],
    [ "commission", "structOfxTransactionData.html#a4f963ca359ff5e49829815803332bf87", null ],
    [ "currency", "structOfxTransactionData.html#a2334020b7fb653b830bfcbaa310a3d2b", null ],
    [ "currency_ratio", "structOfxTransactionData.html#a69b433e2aabd2409284dd20abd778ecb", null ],
    [ "date_funds_available", "structOfxTransactionData.html#a1464e7c8ded265329fc931dbeee2cf93", null ],
    [ "date_initiated", "structOfxTransactionData.html#a85f2410d51ce72baa88c8bd18c8b7c6c", null ],
    [ "date_payroll", "structOfxTransactionData.html#a735f4da706b132fec76576d4bf5eac1b", null ],
    [ "date_posted", "structOfxTransactionData.html#a64ea65411d601e81ed3ea6d60b5067b9", null ],
    [ "date_purchase", "structOfxTransactionData.html#a44a7a011c870042b000d18e3efec33e6", null ],
    [ "denominator", "structOfxTransactionData.html#a41e9b699c14cc91989fb4fab6ec02482", null ],
    [ "fees", "structOfxTransactionData.html#ac259b91b8d9c8bfa54ffb90a68ed3191", null ],
    [ "fi_id", "structOfxTransactionData.html#a0e2b2ff8f22b32577a79ba95eeb2960a", null ],
    [ "fi_id_corrected", "structOfxTransactionData.html#a80661009fe7f51cefb42e6465efbb830", null ],
    [ "fi_id_correction_action", "structOfxTransactionData.html#a1628da9f1d066d1eb1e7a5bfeb865407", null ],
    [ "gain", "structOfxTransactionData.html#a9bcddf360a906f96356f1ab2946dec4b", null ],
    [ "load", "structOfxTransactionData.html#a4e4070aa23fecacf46d732b5adab5bd4", null ],
    [ "loan_id", "structOfxTransactionData.html#a8ef79b93237391c91634f27e5621e62a", null ],
    [ "loan_interest", "structOfxTransactionData.html#af178eee310e8eafdb37735bba10f738a", null ],
    [ "loan_principal", "structOfxTransactionData.html#a97761dcfd1bfe4526a73cb3ebc0381c5", null ],
    [ "markdown", "structOfxTransactionData.html#aead4abf9ae6f5d76c615ca65bb67a21c", null ],
    [ "market_value", "structOfxTransactionData.html#a079ce1ce214f8daf69cc069796a0db45", null ],
    [ "markup", "structOfxTransactionData.html#ac68c3f3dc1ace3a36cb573aece149eb4", null ],
    [ "memo", "structOfxTransactionData.html#a27f1c4eeccf674ba21cedc4decb37986", null ],
    [ "name", "structOfxTransactionData.html#a5b7f115b77987d35c027c33c31f26c9f", null ],
    [ "newunits", "structOfxTransactionData.html#a59d7afb738694ccadfecfc5f8823f3c9", null ],
    [ "numerator", "structOfxTransactionData.html#a5970f11beeed2f39a00fb657cc46993e", null ],
    [ "oldunits", "structOfxTransactionData.html#a45bbba0df631c87b6171a45c0fd4c8f7", null ],
    [ "payee_id", "structOfxTransactionData.html#aa4558dd764fd6601e6f488cef67fc6ee", null ],
    [ "penalty", "structOfxTransactionData.html#a670afa2cf3878266d215adf5b6bef22b", null ],
    [ "prior_year_contrib", "structOfxTransactionData.html#a4ff4a8cbef308163c2ae5e108408c9cd", null ],
    [ "reference_number", "structOfxTransactionData.html#afab38f644cd5c7ee65f9973d3b7f86a7", null ],
    [ "related_fi_tid", "structOfxTransactionData.html#a3f46fabd4faaf2e33961ad802d616d7f", null ],
    [ "security_data_valid", "structOfxTransactionData.html#a38f78abebdefc22ae4d991dc83a55288", null ],
    [ "server_transaction_id", "structOfxTransactionData.html#aca1ff80c7cf0b8a86f82d1d0c9ec8d1e", null ],
    [ "shares_per_cont", "structOfxTransactionData.html#ad8cde2a28a05defc9debdc9621e86399", null ],
    [ "standard_industrial_code", "structOfxTransactionData.html#a1883d5fa0f381b90779f794b1366c234", null ],
    [ "state_withholding", "structOfxTransactionData.html#a4558e8151df767ae5996676376abc0d0", null ],
    [ "subacct_from_valid", "structOfxTransactionData.html#a4f35fae40db04ba7fa67942b04bf59d3", null ],
    [ "subacct_funding_valid", "structOfxTransactionData.html#a4c40840e679004bd52631da940a4e3d9", null ],
    [ "subacct_security_valid", "structOfxTransactionData.html#a14f0256362618d1db41bc8648f498ab0", null ],
    [ "subacct_to_valid", "structOfxTransactionData.html#a4cdfd396ae562b168d5ff555b86d6111", null ],
    [ "tax_exempt", "structOfxTransactionData.html#a37c264c6df16ccb39642abe391a18167", null ],
    [ "taxes", "structOfxTransactionData.html#a6661b67c6115a8c3463768cb3957f064", null ],
    [ "transactiontype_valid", "structOfxTransactionData.html#a73290dc395cf8342d136dbcd243ce695", null ],
    [ "unique_id", "structOfxTransactionData.html#a24977f94311e4443312362481977f5eb", null ],
    [ "unique_id_type", "structOfxTransactionData.html#a1021b33498bdc86ac9fa2aebf903afc2", null ],
    [ "unitprice", "structOfxTransactionData.html#ab330c2e874b125d0c2a6970d181271b5", null ],
    [ "units", "structOfxTransactionData.html#a3d6cd5df47d2282549e30a29454a9f15", null ],
    [ "withholding", "structOfxTransactionData.html#a4d7e12ac565817ae4ed0ddd45bf5c7c7", null ]
];