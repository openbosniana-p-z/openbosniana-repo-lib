var ofx__error__msg_8hh =
[
    [ "ErrorMsg", "structErrorMsg.html", "structErrorMsg" ],
    [ "find_error_msg", "ofx__error__msg_8hh.html#adac162b52803cc0814b829813ad3a5aa", null ],
    [ "error_msgs_list", "ofx__error__msg_8hh.html#a55330fe48f8c210038dfaae0ed8dd608", null ]
];