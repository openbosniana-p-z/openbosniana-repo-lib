var classOfxStatementRequest =
[
    [ "OfxStatementRequest", "classOfxStatementRequest.html#a26f2cb4111c3965436129c2bdfbf678b", null ],
    [ "BankStatementRequest", "classOfxStatementRequest.html#ad2db93d6d0ebb4837036128ceeaeb9a0", null ],
    [ "CreditCardStatementRequest", "classOfxStatementRequest.html#a321c4d59a5c97ca33a9401d134b6a7e0", null ],
    [ "InvestmentStatementRequest", "classOfxStatementRequest.html#a439b0cff11e3b1f6f2c7b85366f0ae60", null ]
];