var files_dup =
[
    [ "getopt", "dir_cff7075e3bbda4d1bbf59b295d9a6bfb.html", "dir_cff7075e3bbda4d1bbf59b295d9a6bfb" ],
    [ "inc", "dir_bfccd401955b95cf8c75461437045ac0.html", "dir_bfccd401955b95cf8c75461437045ac0" ],
    [ "lib", "dir_97aefd0d527b934f1d99a682da8fe6a9.html", "dir_97aefd0d527b934f1d99a682da8fe6a9" ],
    [ "ofx2qif", "dir_bf4898affd6e7e04729ac6594da627dd.html", "dir_bf4898affd6e7e04729ac6594da627dd" ],
    [ "ofxconnect", "dir_7432f7aab7cc7990d1d80266d4aef759.html", "dir_7432f7aab7cc7990d1d80266d4aef759" ],
    [ "ofxdump", "dir_83ea686f5db7f8dcb7127eea149218de.html", "dir_83ea686f5db7f8dcb7127eea149218de" ],
    [ "config.h", "config_8h_source.html", null ],
    [ "main_doc.c", "main__doc_8c_source.html", null ]
];