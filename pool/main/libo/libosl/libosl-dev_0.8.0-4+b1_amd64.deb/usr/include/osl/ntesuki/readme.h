/* readme.h
 */
#ifndef _README_H
#define _README_H

namespace osl
{
  /**
   * ntesuki
   */
  namespace ntesuki
  {
  }
}
#endif /* _README_H */
// ;;; Local Variables:
// ;;; mode:c++
// ;;; c-basic-offset:2
// ;;; End:
