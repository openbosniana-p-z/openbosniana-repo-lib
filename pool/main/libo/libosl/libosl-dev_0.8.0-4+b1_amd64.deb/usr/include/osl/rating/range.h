/* range.h
 */
#ifndef _RANGE_H
#define _RANGE_H
#include <utility>
namespace osl
{
  namespace rating
  {
    typedef std::pair<int,int> range_t;
  }
}

#endif /* _RANGE_H */
// ;;; Local Variables:
// ;;; mode:c++
// ;;; c-basic-offset:2
// ;;; End:
