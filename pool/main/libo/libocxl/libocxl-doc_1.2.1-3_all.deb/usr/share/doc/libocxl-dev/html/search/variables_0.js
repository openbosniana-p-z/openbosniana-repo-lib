var searchData=
[
  ['addr_146',['addr',['../libocxl_8h.html#ae5bd6c22dbf0f6b5b0ae0233f8eb3704',1,'ocxl_event_translation_fault']]],
  ['afu_5findex_147',['afu_index',['../libocxl_8h.html#ad4f510b2dad77561367b439a53c18d4b',1,'ocxl_identifier']]],
  ['afu_5fname_148',['afu_name',['../libocxl_8h.html#add6fd7c0d6dbc2f1e425c7e4381d06a9',1,'ocxl_identifier']]]
];
