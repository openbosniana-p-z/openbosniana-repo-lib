var searchData=
[
  ['dsisr_7',['dsisr',['../libocxl_8h.html#aedb3022ed5cd220da35e64db048afff2',1,'ocxl_event_translation_fault']]]
];
