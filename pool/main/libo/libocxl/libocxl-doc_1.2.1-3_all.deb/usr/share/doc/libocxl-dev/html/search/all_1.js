var searchData=
[
  ['addr_1',['addr',['../libocxl_8h.html#ae5bd6c22dbf0f6b5b0ae0233f8eb3704',1,'ocxl_event_translation_fault']]],
  ['afu_2ec_2',['afu.c',['../afu_8c.html',1,'']]],
  ['afu_5findex_3',['afu_index',['../libocxl_8h.html#ad4f510b2dad77561367b439a53c18d4b',1,'ocxl_identifier']]],
  ['afu_5fname_4',['afu_name',['../libocxl_8h.html#add6fd7c0d6dbc2f1e425c7e4381d06a9',1,'ocxl_identifier']]],
  ['afu_5fname_5fmax_5',['AFU_NAME_MAX',['../libocxl_8h.html#a9e0ab593ab522873769dcd96092719ae',1,'libocxl.h']]]
];
