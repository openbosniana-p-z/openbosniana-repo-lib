var searchData=
[
  ['setup_2ec_96',['setup.c',['../setup_8c.html',1,'']]]
];
