var searchData=
[
  ['ocxl_5fevent_98',['ocxl_event',['../libocxl_8h.html#structocxl__event',1,'']]],
  ['ocxl_5fevent_2e_5f_5funnamed1_5f_5f_99',['ocxl_event.__unnamed1__',['../libocxl_8h.html#unionocxl__event_8____unnamed1____',1,'']]],
  ['ocxl_5fevent_5firq_100',['ocxl_event_irq',['../libocxl_8h.html#structocxl__event__irq',1,'']]],
  ['ocxl_5fevent_5ftranslation_5ffault_101',['ocxl_event_translation_fault',['../libocxl_8h.html#structocxl__event__translation__fault',1,'']]],
  ['ocxl_5fidentifier_102',['ocxl_identifier',['../libocxl_8h.html#structocxl__identifier',1,'']]]
];
