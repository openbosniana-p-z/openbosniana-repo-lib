var searchData=
[
  ['count_6',['count',['../libocxl_8h.html#afcc68e9eec57ce069fcdc37815837d6d',1,'ocxl_event_irq::count()'],['../libocxl_8h.html#afcc68e9eec57ce069fcdc37815837d6d',1,'ocxl_event_translation_fault::count()']]]
];
