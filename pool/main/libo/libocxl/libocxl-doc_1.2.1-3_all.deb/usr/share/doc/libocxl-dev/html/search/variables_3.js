var searchData=
[
  ['handle_151',['handle',['../libocxl_8h.html#a8ad356832e07a5534fc8725d83b547a6',1,'ocxl_event_irq']]]
];
