var searchData=
[
  ['info_10',['info',['../libocxl_8h.html#acb1df3a0f703b05bc4971f79cabe2597',1,'ocxl_event_irq']]],
  ['introduction_11',['Introduction',['../index.html',1,'']]],
  ['irq_12',['irq',['../libocxl_8h.html#a788268e18842744cc0a7e06cc734582a',1,'ocxl_event_irq']]],
  ['irq_2ec_13',['irq.c',['../irq_8c.html',1,'']]],
  ['irq_5fdealloc_14',['irq_dealloc',['../irq_8c.html#ad6218ccd0d019958409bd575f9f3e326',1,'irq.c']]]
];
