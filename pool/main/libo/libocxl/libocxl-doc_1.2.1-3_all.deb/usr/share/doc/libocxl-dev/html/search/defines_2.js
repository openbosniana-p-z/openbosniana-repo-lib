var searchData=
[
  ['max_5fevent_5fsize_183',['MAX_EVENT_SIZE',['../irq_8c.html#a05d5acc365e3342523d84bc4540adc09',1,'irq.c']]]
];
