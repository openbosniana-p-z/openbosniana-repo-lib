var searchData=
[
  ['opencapi_20afu_20getters_189',['OpenCAPI AFU Getters',['../group__ocxl__afu__getters.html',1,'']]],
  ['opencapi_20afu_20management_190',['OpenCAPI AFU Management',['../group__ocxl__afu.html',1,'']]],
  ['opencapi_20irq_2c_20event_20_26_20wake_20functions_191',['OpenCAPI IRQ, Event &amp; Wake Functions',['../group__ocxl__irq.html',1,'']]],
  ['opencapi_20messages_192',['OpenCAPI Messages',['../group__ocxl__messages.html',1,'']]],
  ['opencapi_20mmio_20functions_193',['OpenCAPI MMIO Functions',['../group__ocxl__mmio.html',1,'']]],
  ['opencapi_20powerpc_20specific_20functions_194',['OpenCAPI PowerPC specific functions',['../group__ocxl__ppc.html',1,'']]]
];
