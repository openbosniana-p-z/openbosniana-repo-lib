var searchData=
[
  ['afu_5fname_5fmax_182',['AFU_NAME_MAX',['../libocxl_8h.html#a9e0ab593ab522873769dcd96092719ae',1,'libocxl.h']]]
];
