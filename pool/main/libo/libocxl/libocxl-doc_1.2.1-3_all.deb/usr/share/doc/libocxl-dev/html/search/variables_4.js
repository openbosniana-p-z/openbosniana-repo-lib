var searchData=
[
  ['info_152',['info',['../libocxl_8h.html#acb1df3a0f703b05bc4971f79cabe2597',1,'ocxl_event_irq']]],
  ['irq_153',['irq',['../libocxl_8h.html#a788268e18842744cc0a7e06cc734582a',1,'ocxl_event_irq']]]
];
