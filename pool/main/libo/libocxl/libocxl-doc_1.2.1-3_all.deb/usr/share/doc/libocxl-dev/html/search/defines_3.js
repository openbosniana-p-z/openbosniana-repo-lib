var searchData=
[
  ['ocxl_5fattach_5fflags_5fnone_184',['OCXL_ATTACH_FLAGS_NONE',['../libocxl_8h.html#a75b79df268eb3b1bbc508be5370b26f6',1,'libocxl.h']]],
  ['ocxl_5ferrors_185',['OCXL_ERRORS',['../libocxl_8h.html#ab59f1f76c1cd43b82212f3dfaba84b53',1,'libocxl.h']]],
  ['ocxl_5finvalid_5fafu_186',['OCXL_INVALID_AFU',['../libocxl_8h.html#a2c36a5e9df5ed81d7b755cdefc72304e',1,'libocxl.h']]],
  ['ocxl_5fno_5fmessages_187',['OCXL_NO_MESSAGES',['../libocxl_8h.html#abbca178f863d0a05570940c65db75030',1,'libocxl.h']]],
  ['ocxl_5ftracing_188',['OCXL_TRACING',['../libocxl_8h.html#a80ddc0a22495af1e4a7bc721e46a4e9d',1,'libocxl.h']]]
];
