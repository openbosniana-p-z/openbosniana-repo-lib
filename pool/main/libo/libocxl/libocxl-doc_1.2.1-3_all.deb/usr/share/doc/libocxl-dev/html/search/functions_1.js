var searchData=
[
  ['irq_5fdealloc_110',['irq_dealloc',['../irq_8c.html#ad6218ccd0d019958409bd575f9f3e326',1,'irq.c']]]
];
