var searchData=
[
  ['type_154',['type',['../libocxl_8h.html#a2bffb73229c4652f7b147b35268508e1',1,'ocxl_event']]]
];
