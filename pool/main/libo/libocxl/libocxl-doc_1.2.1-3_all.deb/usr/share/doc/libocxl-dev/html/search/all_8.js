var searchData=
[
  ['max_5fevent_5fsize_16',['MAX_EVENT_SIZE',['../irq_8c.html#a05d5acc365e3342523d84bc4540adc09',1,'irq.c']]],
  ['mmio_2ec_17',['mmio.c',['../mmio_8c.html',1,'']]]
];
