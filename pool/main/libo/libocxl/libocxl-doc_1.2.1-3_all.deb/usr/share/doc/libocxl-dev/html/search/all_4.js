var searchData=
[
  ['global_5fmmio_5fopen_8',['global_mmio_open',['../group__ocxl__mmio.html#gaae2d0f92be910df16975af7a74f97a21',1,'mmio.c']]]
];
