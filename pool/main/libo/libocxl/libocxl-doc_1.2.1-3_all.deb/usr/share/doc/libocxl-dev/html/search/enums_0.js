var searchData=
[
  ['ocxl_5fendian_160',['ocxl_endian',['../libocxl_8h.html#a99182fe49c19594a04b05aae43342d4f',1,'libocxl.h']]],
  ['ocxl_5ferr_161',['ocxl_err',['../libocxl_8h.html#a0a18f33ce24edf75b02184395bb6ea55',1,'libocxl.h']]],
  ['ocxl_5fevent_5ftype_162',['ocxl_event_type',['../libocxl_8h.html#a8c4680beca9b9461f160b59d5c569d0c',1,'libocxl.h']]],
  ['ocxl_5fmmio_5ftype_163',['ocxl_mmio_type',['../libocxl_8h.html#a1eebb9cf864a4fa0a8f4e54c56494b1a',1,'libocxl.h']]]
];
