var classjuce_1_1JUCEApplicationBase =
[
    [ "MultipleInstanceHandler", "classjuce_1_1JUCEApplicationBase.html#structjuce_1_1JUCEApplicationBase_1_1MultipleInstanceHandler", null ],
    [ "JUCEApplicationBase", "classjuce_1_1JUCEApplicationBase.html#aa042f23227e80c180013501a027ab941", null ],
    [ "~JUCEApplicationBase", "classjuce_1_1JUCEApplicationBase.html#a25f78db43b4301dc016df17d79a18481", null ],
    [ "getApplicationName", "classjuce_1_1JUCEApplicationBase.html#a528b678bed5bb42b91bced35d19c4665", null ],
    [ "getApplicationVersion", "classjuce_1_1JUCEApplicationBase.html#ad7269020c06fd6772e64059ad6402522", null ],
    [ "moreThanOneInstanceAllowed", "classjuce_1_1JUCEApplicationBase.html#ae0c6c491b621bd548cebb36047dd1828", null ],
    [ "initialise", "classjuce_1_1JUCEApplicationBase.html#a2fb0e7fd4ab86c32c8e0ff663428ae1f", null ],
    [ "shutdown", "classjuce_1_1JUCEApplicationBase.html#a506cf94ff70285f6c6f76e5e45eaafed", null ],
    [ "anotherInstanceStarted", "classjuce_1_1JUCEApplicationBase.html#aa7ec7405480684eb465c68e93d5ba0db", null ],
    [ "systemRequestedQuit", "classjuce_1_1JUCEApplicationBase.html#a07fe1f21a6f6226a85da12b979a8d53a", null ],
    [ "suspended", "classjuce_1_1JUCEApplicationBase.html#a637b1117ebc82518f510384c56671288", null ],
    [ "resumed", "classjuce_1_1JUCEApplicationBase.html#a81adcd47029b431f40718cb1204f3d41", null ],
    [ "unhandledException", "classjuce_1_1JUCEApplicationBase.html#adda8cfe8a8023ac4019d1728c7526169", null ],
    [ "memoryWarningReceived", "classjuce_1_1JUCEApplicationBase.html#a605565242eccd51d45d6bc3e6097dc9c", null ],
    [ "backButtonPressed", "classjuce_1_1JUCEApplicationBase.html#ac535f3e5c5a6c783efed6e8e86b341f8", null ],
    [ "setApplicationReturnValue", "classjuce_1_1JUCEApplicationBase.html#aa718d56bbc1c7d7271aedbc378eeaffe", null ],
    [ "getApplicationReturnValue", "classjuce_1_1JUCEApplicationBase.html#af331db63560821279c1e44baebe9a5e6", null ],
    [ "isInitialising", "classjuce_1_1JUCEApplicationBase.html#a025180bd29ffeee88c2acf03bd48b4d8", null ]
];