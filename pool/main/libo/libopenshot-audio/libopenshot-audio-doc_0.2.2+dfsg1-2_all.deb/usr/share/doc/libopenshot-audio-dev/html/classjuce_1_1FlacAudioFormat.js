var classjuce_1_1FlacAudioFormat =
[
    [ "FlacAudioFormat", "classjuce_1_1FlacAudioFormat.html#a1324eba21d8d26469710566d4a583d30", null ],
    [ "~FlacAudioFormat", "classjuce_1_1FlacAudioFormat.html#af591d933aa156338357edab46c1a6af5", null ],
    [ "getPossibleSampleRates", "classjuce_1_1FlacAudioFormat.html#a3916cc9c892e4a5326f8b14fdf1a5426", null ],
    [ "getPossibleBitDepths", "classjuce_1_1FlacAudioFormat.html#a52079647d935bb06911b8f08ce707661", null ],
    [ "canDoStereo", "classjuce_1_1FlacAudioFormat.html#a6e87c263978b7d0df3dedbaf863b2cb5", null ],
    [ "canDoMono", "classjuce_1_1FlacAudioFormat.html#ab7e6198627bb918da3ea3b766cea0b25", null ],
    [ "isCompressed", "classjuce_1_1FlacAudioFormat.html#a4985472691900e7cf9539278056ae1cb", null ],
    [ "getQualityOptions", "classjuce_1_1FlacAudioFormat.html#ae5ada208de8555ce2b4f09d13280ec99", null ],
    [ "createReaderFor", "classjuce_1_1FlacAudioFormat.html#af91aa443ef2f886fcb472fe0273b5538", null ],
    [ "createWriterFor", "classjuce_1_1FlacAudioFormat.html#a41d3be8e5875b0c21f70e1846e9cb4a1", null ],
    [ "createWriterFor", "classjuce_1_1FlacAudioFormat.html#a9e6e1d78c5ef9e3c81fcf000ef4ca01b", null ],
    [ "createWriterFor", "classjuce_1_1FlacAudioFormat.html#abc557f6f759552ec6b4302629739a788", null ]
];