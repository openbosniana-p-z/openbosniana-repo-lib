var classjuce_1_1AudioFormat =
[
    [ "~AudioFormat", "classjuce_1_1AudioFormat.html#ac26068d182e4d6f7c03a8140d551599f", null ],
    [ "AudioFormat", "classjuce_1_1AudioFormat.html#a8bc6e9fcbcce13ff10e268f5172dc293", null ],
    [ "AudioFormat", "classjuce_1_1AudioFormat.html#ad17f97cb256bcfebc4786bfb7ffff72e", null ],
    [ "getFormatName", "classjuce_1_1AudioFormat.html#acad46991985ef6215d352ffebe062644", null ],
    [ "getFileExtensions", "classjuce_1_1AudioFormat.html#a04bdf0ff1b200c1b2557911f265467fa", null ],
    [ "canHandleFile", "classjuce_1_1AudioFormat.html#a82d857789d7cd8b55b48ee5916eb1931", null ],
    [ "getPossibleSampleRates", "classjuce_1_1AudioFormat.html#aa1c60966dd65949a89f18620c8631e34", null ],
    [ "getPossibleBitDepths", "classjuce_1_1AudioFormat.html#a154970f3a715b3c6ceb8be76b085c37c", null ],
    [ "canDoStereo", "classjuce_1_1AudioFormat.html#a51997277df2763b724b39e50f6156c3c", null ],
    [ "canDoMono", "classjuce_1_1AudioFormat.html#a72fcbb618f3aef30f12aa4ad8705f35a", null ],
    [ "isCompressed", "classjuce_1_1AudioFormat.html#afb1a592d5ae18b004f60616dfe63b5e6", null ],
    [ "isChannelLayoutSupported", "classjuce_1_1AudioFormat.html#a1301c9f5bcdcaec7e04aa226044a88ed", null ],
    [ "getQualityOptions", "classjuce_1_1AudioFormat.html#a720d61eaa701c4dd32c95cd4ccd0abf1", null ],
    [ "createReaderFor", "classjuce_1_1AudioFormat.html#ac77c3c3375132d9ce1533619755ab642", null ],
    [ "createMemoryMappedReader", "classjuce_1_1AudioFormat.html#a1f31d0747ef134c8e488f5e9dfce1e9b", null ],
    [ "createMemoryMappedReader", "classjuce_1_1AudioFormat.html#a619eae077b705e0abdb8d299385c1e26", null ],
    [ "createWriterFor", "classjuce_1_1AudioFormat.html#a9e6e1d78c5ef9e3c81fcf000ef4ca01b", null ],
    [ "createWriterFor", "classjuce_1_1AudioFormat.html#abc557f6f759552ec6b4302629739a788", null ]
];