var classjuce_1_1AsyncFunctionCallback =
[
    [ "AsyncFunctionCallback", "classjuce_1_1AsyncFunctionCallback.html#aa8235bf4624204100a289ef3b40bc3bf", null ],
    [ "messageCallback", "classjuce_1_1AsyncFunctionCallback.html#afc80b47ba300bd02b1d255c055b08e01", null ],
    [ "finished", "classjuce_1_1AsyncFunctionCallback.html#a7b6830eb333edff1fb562f9419bac638", null ],
    [ "result", "classjuce_1_1AsyncFunctionCallback.html#ac24d9ee692b06892599dd6e358f2821a", null ]
];