var classjuce_1_1MemoryMappedAudioFormatReader =
[
    [ "MemoryMappedAudioFormatReader", "classjuce_1_1MemoryMappedAudioFormatReader.html#a089e8769b85ae454f6915042f7259473", null ],
    [ "getFile", "classjuce_1_1MemoryMappedAudioFormatReader.html#a75a1b3b10c0ba287eeb6f4d14387b79f", null ],
    [ "mapEntireFile", "classjuce_1_1MemoryMappedAudioFormatReader.html#a8e5ec9509eabe7b7ecaf94f867c4c7ef", null ],
    [ "mapSectionOfFile", "classjuce_1_1MemoryMappedAudioFormatReader.html#ac0b90022c30136acfd77752831cbe6bc", null ],
    [ "getMappedSection", "classjuce_1_1MemoryMappedAudioFormatReader.html#ae5f5d405a30b269d21653f4f5d7186ed", null ],
    [ "touchSample", "classjuce_1_1MemoryMappedAudioFormatReader.html#a4edb1ff8d296bae97f15d6d56f911d05", null ],
    [ "getSample", "classjuce_1_1MemoryMappedAudioFormatReader.html#a455239d10cd1129620cf53e55b47f522", null ],
    [ "getNumBytesUsed", "classjuce_1_1MemoryMappedAudioFormatReader.html#aa284c9600a12276f7372d6cc44017204", null ],
    [ "sampleToFilePos", "classjuce_1_1MemoryMappedAudioFormatReader.html#ab2f40749b8a663a6bda4130f9c8dd03f", null ],
    [ "filePosToSample", "classjuce_1_1MemoryMappedAudioFormatReader.html#acf709b512830afce5d89049df3e309fd", null ],
    [ "sampleToPointer", "classjuce_1_1MemoryMappedAudioFormatReader.html#ac3e559df6e265b3b6a63b4ea0805f802", null ],
    [ "scanMinAndMaxInterleaved", "classjuce_1_1MemoryMappedAudioFormatReader.html#a8b35dd82a7a1a9bddd7d9fe79cd4418a", null ],
    [ "file", "classjuce_1_1MemoryMappedAudioFormatReader.html#a611aebbf134fce3600630c8ec78416be", null ],
    [ "mappedSection", "classjuce_1_1MemoryMappedAudioFormatReader.html#a0b72656c12e6a45097fc09ad901e1272", null ],
    [ "map", "classjuce_1_1MemoryMappedAudioFormatReader.html#a33bd28f581b89bd827c1bae6328b58df", null ],
    [ "dataChunkStart", "classjuce_1_1MemoryMappedAudioFormatReader.html#a3ca27592e3411646c2bdda0909f4668d", null ],
    [ "dataLength", "classjuce_1_1MemoryMappedAudioFormatReader.html#a0b25c3a3898fb086a7822900ff66cd0c", null ],
    [ "bytesPerFrame", "classjuce_1_1MemoryMappedAudioFormatReader.html#a90c2a24dcc6c080f256d422b06fc8d16", null ]
];