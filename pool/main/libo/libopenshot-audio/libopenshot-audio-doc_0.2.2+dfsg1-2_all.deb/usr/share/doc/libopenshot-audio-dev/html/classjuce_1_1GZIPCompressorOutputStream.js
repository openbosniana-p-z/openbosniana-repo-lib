var classjuce_1_1GZIPCompressorOutputStream =
[
    [ "GZIPCompressorHelper", "classjuce_1_1GZIPCompressorOutputStream_1_1GZIPCompressorHelper.html", "classjuce_1_1GZIPCompressorOutputStream_1_1GZIPCompressorHelper" ],
    [ "WindowBitsValues", "classjuce_1_1GZIPCompressorOutputStream.html#a4903d665e66217250134e6bf84f8e618", [
      [ "windowBitsRaw", "classjuce_1_1GZIPCompressorOutputStream.html#a4903d665e66217250134e6bf84f8e618aa6c094be6355abb60676941336510738", null ],
      [ "windowBitsGZIP", "classjuce_1_1GZIPCompressorOutputStream.html#a4903d665e66217250134e6bf84f8e618a49208445e1e0475f45f29d5016252a90", null ]
    ] ],
    [ "GZIPCompressorOutputStream", "classjuce_1_1GZIPCompressorOutputStream.html#a0f8a71cccb6810df655945c529ab75c7", null ],
    [ "GZIPCompressorOutputStream", "classjuce_1_1GZIPCompressorOutputStream.html#a12de5cce372b8c71460acbda5e29dc02", null ],
    [ "~GZIPCompressorOutputStream", "classjuce_1_1GZIPCompressorOutputStream.html#a641c213a1998c1cc60fa6efe08c2bb32", null ],
    [ "flush", "classjuce_1_1GZIPCompressorOutputStream.html#ae42d4222a825800a9e5b3568a6a75f55", null ],
    [ "getPosition", "classjuce_1_1GZIPCompressorOutputStream.html#ae4dcb70056cfbf654d864c8ac3327407", null ],
    [ "setPosition", "classjuce_1_1GZIPCompressorOutputStream.html#a3cd92bbde62121c2721c6baf15209bee", null ],
    [ "write", "classjuce_1_1GZIPCompressorOutputStream.html#a49a2c500ef8307398df2c0f180414fe9", null ]
];