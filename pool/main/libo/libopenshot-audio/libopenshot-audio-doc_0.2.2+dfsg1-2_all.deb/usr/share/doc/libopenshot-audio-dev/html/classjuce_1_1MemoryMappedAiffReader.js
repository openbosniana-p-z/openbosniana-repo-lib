var classjuce_1_1MemoryMappedAiffReader =
[
    [ "MemoryMappedAiffReader", "classjuce_1_1MemoryMappedAiffReader.html#a08786bb506708d3f160c608b84d1bbe5", null ],
    [ "readSamples", "classjuce_1_1MemoryMappedAiffReader.html#abd07d8071fdc1a302385095e88eb266a", null ],
    [ "getSample", "classjuce_1_1MemoryMappedAiffReader.html#af042e76251b9662f30691537157ddcef", null ],
    [ "readMaxLevels", "classjuce_1_1MemoryMappedAiffReader.html#a8f248d214a2d4e667d4292850b45fae6", null ],
    [ "readMaxLevels", "classjuce_1_1MemoryMappedAiffReader.html#ad0159b2b47a152f37d488320ed591a01", null ],
    [ "readMaxLevels", "classjuce_1_1MemoryMappedAiffReader.html#aa271efceec031566548af063dd372ca3", null ]
];