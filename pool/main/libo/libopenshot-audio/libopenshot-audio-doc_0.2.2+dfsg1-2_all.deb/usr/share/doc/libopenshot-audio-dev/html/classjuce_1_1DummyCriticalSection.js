var classjuce_1_1DummyCriticalSection =
[
    [ "ScopedLockType", "structjuce_1_1DummyCriticalSection_1_1ScopedLockType.html", "structjuce_1_1DummyCriticalSection_1_1ScopedLockType" ],
    [ "ScopedUnlockType", "classjuce_1_1DummyCriticalSection.html#aaeaa65c8b1351d104474fbda4f5b7968", null ],
    [ "DummyCriticalSection", "classjuce_1_1DummyCriticalSection.html#a4fb724efe1596a6da10c6371ee98bdfa", null ],
    [ "~DummyCriticalSection", "classjuce_1_1DummyCriticalSection.html#a180114c653641439fe196509797f88e5", null ],
    [ "enter", "classjuce_1_1DummyCriticalSection.html#a2aeb20d40a2d393451b2058c32b9e732", null ],
    [ "tryEnter", "classjuce_1_1DummyCriticalSection.html#a5207c89360c8bd5a193b6a3b58274214", null ],
    [ "exit", "classjuce_1_1DummyCriticalSection.html#a068fb3886b151b7bd3ec8dfea23c5b94", null ]
];