var classjuce_1_1MidiInput =
[
    [ "~MidiInput", "classjuce_1_1MidiInput.html#a285773c05e3058ad565a4915d952a298", null ],
    [ "start", "classjuce_1_1MidiInput.html#ae4e9c8fe41e4a74a8bf89454c3af0ca8", null ],
    [ "stop", "classjuce_1_1MidiInput.html#a5032c114a0fd8b2b58d8c2a5d7dd099e", null ],
    [ "getDeviceInfo", "classjuce_1_1MidiInput.html#a991e8752bc38ef521720b96a99d4cd13", null ],
    [ "getIdentifier", "classjuce_1_1MidiInput.html#afcf9dbec573e8ade2748811fb9994706", null ],
    [ "getName", "classjuce_1_1MidiInput.html#a783579e44cbb26a3f1e1c68f3876f906", null ],
    [ "setName", "classjuce_1_1MidiInput.html#a06a35a2183f1e39d04aab9650e4dc125", null ]
];