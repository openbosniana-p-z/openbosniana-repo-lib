var classjuce_1_1AudioProcessLoadMeasurer =
[
    [ "ScopedTimer", "structjuce_1_1AudioProcessLoadMeasurer_1_1ScopedTimer.html", "structjuce_1_1AudioProcessLoadMeasurer_1_1ScopedTimer" ],
    [ "AudioProcessLoadMeasurer", "classjuce_1_1AudioProcessLoadMeasurer.html#a5451d487c21b9b97b518589d937e6775", null ],
    [ "~AudioProcessLoadMeasurer", "classjuce_1_1AudioProcessLoadMeasurer.html#a0e9d2e2be5168a8ce8438dd82b4a2efc", null ],
    [ "reset", "classjuce_1_1AudioProcessLoadMeasurer.html#ad70d203df4615d5f95ec0f9defae4509", null ],
    [ "reset", "classjuce_1_1AudioProcessLoadMeasurer.html#ad9565502ab5af261a272e086e273d74b", null ],
    [ "getLoadAsProportion", "classjuce_1_1AudioProcessLoadMeasurer.html#ae80e41d40046352ee6924560af77c35c", null ],
    [ "getLoadAsPercentage", "classjuce_1_1AudioProcessLoadMeasurer.html#a2a9a340b4255a16b443070330b3ec3f3", null ],
    [ "getXRunCount", "classjuce_1_1AudioProcessLoadMeasurer.html#a88d9677c944f15469d0ac25be0389df2", null ],
    [ "registerBlockRenderTime", "classjuce_1_1AudioProcessLoadMeasurer.html#a4b5e7a6a434d59ed9b139ec362ff4b6c", null ]
];