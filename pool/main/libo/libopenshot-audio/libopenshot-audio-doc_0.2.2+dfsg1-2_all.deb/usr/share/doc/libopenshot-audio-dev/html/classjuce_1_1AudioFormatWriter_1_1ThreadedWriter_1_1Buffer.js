var classjuce_1_1AudioFormatWriter_1_1ThreadedWriter_1_1Buffer =
[
    [ "Buffer", "classjuce_1_1AudioFormatWriter_1_1ThreadedWriter_1_1Buffer.html#afe1dc5529192cb92a4424b48b816d459", null ],
    [ "~Buffer", "classjuce_1_1AudioFormatWriter_1_1ThreadedWriter_1_1Buffer.html#a37034b82f3913e1ca964681f653a72b3", null ],
    [ "write", "classjuce_1_1AudioFormatWriter_1_1ThreadedWriter_1_1Buffer.html#a01a423893a622cb53f252876c3c525c3", null ],
    [ "useTimeSlice", "classjuce_1_1AudioFormatWriter_1_1ThreadedWriter_1_1Buffer.html#a3b4208262967cde0d91e18295ee6e503", null ],
    [ "writePendingData", "classjuce_1_1AudioFormatWriter_1_1ThreadedWriter_1_1Buffer.html#a7332e0ceca933caca7d59d15aba550e4", null ],
    [ "setDataReceiver", "classjuce_1_1AudioFormatWriter_1_1ThreadedWriter_1_1Buffer.html#a953e49b797cd99bd19a9a21fdb4c5df0", null ],
    [ "setFlushInterval", "classjuce_1_1AudioFormatWriter_1_1ThreadedWriter_1_1Buffer.html#aa73e7e330379abe12f761190f8fc34a9", null ]
];