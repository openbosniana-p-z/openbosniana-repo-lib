var classjuce_1_1IIRCoefficients =
[
    [ "IIRCoefficients", "classjuce_1_1IIRCoefficients.html#a307af61e259b32e47d76f345ab3ed98b", null ],
    [ "IIRCoefficients", "classjuce_1_1IIRCoefficients.html#a51b02e663afb5ee0faa1ad005c695446", null ],
    [ "IIRCoefficients", "classjuce_1_1IIRCoefficients.html#a75b79549a0f516e54f74190a0b2536fd", null ],
    [ "~IIRCoefficients", "classjuce_1_1IIRCoefficients.html#a78aa55a656686eb4809006a680b90b1a", null ],
    [ "operator=", "classjuce_1_1IIRCoefficients.html#a293f13f8e653a57db6cf83199802e7ba", null ],
    [ "coefficients", "classjuce_1_1IIRCoefficients.html#a2fb0d935a2eca3302963b2eddbd49443", null ]
];