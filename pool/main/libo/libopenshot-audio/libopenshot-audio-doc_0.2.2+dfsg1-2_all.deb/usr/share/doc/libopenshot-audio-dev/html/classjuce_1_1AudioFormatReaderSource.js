var classjuce_1_1AudioFormatReaderSource =
[
    [ "AudioFormatReaderSource", "classjuce_1_1AudioFormatReaderSource.html#aa7ba3763b0a81742ff141a60c821baac", null ],
    [ "~AudioFormatReaderSource", "classjuce_1_1AudioFormatReaderSource.html#a8baa979e2d74f15cab8611de0ef0b4e7", null ],
    [ "setLooping", "classjuce_1_1AudioFormatReaderSource.html#ac1dd704b8a5b86ac7c7b43a00a2f34d1", null ],
    [ "isLooping", "classjuce_1_1AudioFormatReaderSource.html#a6409ceea1636dc1c901039b1cb12a4de", null ],
    [ "getAudioFormatReader", "classjuce_1_1AudioFormatReaderSource.html#ac3212e3a781d7f99336ce882d07d999b", null ],
    [ "prepareToPlay", "classjuce_1_1AudioFormatReaderSource.html#a446bee4dc6bec624d71b8f39a2dda70b", null ],
    [ "releaseResources", "classjuce_1_1AudioFormatReaderSource.html#a57a05b37b28bbf8c18a20cfaaccddaea", null ],
    [ "getNextAudioBlock", "classjuce_1_1AudioFormatReaderSource.html#afe3b5ee4fb7ef988ad5dfa2090537298", null ],
    [ "setNextReadPosition", "classjuce_1_1AudioFormatReaderSource.html#acd31f1235c074d85c2aca3cd6daa3426", null ],
    [ "getNextReadPosition", "classjuce_1_1AudioFormatReaderSource.html#a24fef87a173e35edae72d4241cc81031", null ],
    [ "getTotalLength", "classjuce_1_1AudioFormatReaderSource.html#ae3cfa666df3392af641b4ff4d777a77b", null ]
];