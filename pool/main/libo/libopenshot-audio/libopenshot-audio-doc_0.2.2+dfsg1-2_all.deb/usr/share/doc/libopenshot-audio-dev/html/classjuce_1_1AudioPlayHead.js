var classjuce_1_1AudioPlayHead =
[
    [ "CurrentPositionInfo", "structjuce_1_1AudioPlayHead_1_1CurrentPositionInfo.html", "structjuce_1_1AudioPlayHead_1_1CurrentPositionInfo" ],
    [ "FrameRateType", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1b", [
      [ "fps23976", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1ba631ff0bdc9186df5aaa421eb09b5474c", null ],
      [ "fps24", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1ba40cffd9d669e26ef0d5c9cd669e772e9", null ],
      [ "fps25", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1bac5f6907a1bb84db2425e5457bd272f4b", null ],
      [ "fps2997", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1ba7f19b161b8412d81cee7b547ea52181e", null ],
      [ "fps30", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1bad98effe976262c7e30e22dcf52a789f6", null ],
      [ "fps2997drop", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1bad2ff09a2a100060a3af839b5c6816c11", null ],
      [ "fps30drop", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1bacb70bb7c764cda37fe634ba4b2ae2be0", null ],
      [ "fps60", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1baf1875a0abcc18427e321f682a27ee13b", null ],
      [ "fps60drop", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1ba5e774cbe4490ccef4c0c9127b34b12b4", null ],
      [ "fpsUnknown", "classjuce_1_1AudioPlayHead.html#a504188341046155d2a43cd6f53806e1ba9f8e1d4c15566ebd8406051194f12f51", null ]
    ] ],
    [ "AudioPlayHead", "classjuce_1_1AudioPlayHead.html#a9ab109d35055ef6c45f684802e11565c", null ],
    [ "~AudioPlayHead", "classjuce_1_1AudioPlayHead.html#acb05f429a7ab201bbf8233ca176d9082", null ],
    [ "getCurrentPosition", "classjuce_1_1AudioPlayHead.html#ad5b9b0311b232d642f3f44da298dd941", null ],
    [ "canControlTransport", "classjuce_1_1AudioPlayHead.html#a29fa1945bf49374ea06bdd571c59c8c4", null ],
    [ "transportPlay", "classjuce_1_1AudioPlayHead.html#a8c987311a6d6f8f8115ea3e095609164", null ],
    [ "transportRecord", "classjuce_1_1AudioPlayHead.html#ab69d646fae85d35b26a05a26d4cd12b1", null ],
    [ "transportRewind", "classjuce_1_1AudioPlayHead.html#add34dd486320eeb3b84378f76d73944c", null ]
];