var classjuce_1_1LAMEEncoderAudioFormat =
[
    [ "LAMEEncoderAudioFormat", "classjuce_1_1LAMEEncoderAudioFormat.html#a0f519841dc0ee4ef735c332a3e84e565", null ],
    [ "~LAMEEncoderAudioFormat", "classjuce_1_1LAMEEncoderAudioFormat.html#aecc0fc774a9eb78753df0118c3e89af2", null ],
    [ "canHandleFile", "classjuce_1_1LAMEEncoderAudioFormat.html#ac3b2e7797e608f2e22ab19a3f2831df5", null ],
    [ "getPossibleSampleRates", "classjuce_1_1LAMEEncoderAudioFormat.html#a7e9e1a01aba9b6c328bdcb9b3f50d092", null ],
    [ "getPossibleBitDepths", "classjuce_1_1LAMEEncoderAudioFormat.html#a7afe21b547ec23e538d612de0af3cca1", null ],
    [ "canDoStereo", "classjuce_1_1LAMEEncoderAudioFormat.html#ad123c091991aad7e7745328948914c6b", null ],
    [ "canDoMono", "classjuce_1_1LAMEEncoderAudioFormat.html#a53b5e0f1028401423262a0018e5a1ca1", null ],
    [ "isCompressed", "classjuce_1_1LAMEEncoderAudioFormat.html#a5c3bb4f6458600ea381d10869773e5f5", null ],
    [ "getQualityOptions", "classjuce_1_1LAMEEncoderAudioFormat.html#ad2b14b7a36943b07ac8650f0d3e23855", null ],
    [ "createReaderFor", "classjuce_1_1LAMEEncoderAudioFormat.html#a8a95506a3af2a21ac9a9675a21365a64", null ],
    [ "createWriterFor", "classjuce_1_1LAMEEncoderAudioFormat.html#ae794147dd55023c7c3fa5938f7a513c1", null ],
    [ "createWriterFor", "classjuce_1_1LAMEEncoderAudioFormat.html#a9e6e1d78c5ef9e3c81fcf000ef4ca01b", null ],
    [ "createWriterFor", "classjuce_1_1LAMEEncoderAudioFormat.html#abc557f6f759552ec6b4302629739a788", null ]
];