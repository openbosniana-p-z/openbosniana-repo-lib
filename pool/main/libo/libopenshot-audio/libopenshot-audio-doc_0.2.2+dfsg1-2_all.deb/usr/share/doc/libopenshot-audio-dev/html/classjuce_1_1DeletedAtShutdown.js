var classjuce_1_1DeletedAtShutdown =
[
    [ "DeletedAtShutdown", "classjuce_1_1DeletedAtShutdown.html#a54b2d265044e9993bbea0975ff321a55", null ],
    [ "~DeletedAtShutdown", "classjuce_1_1DeletedAtShutdown.html#a305afe19e2d871603127a56abafd4c7b", null ]
];