var classjuce_1_1LinkedListPointer_1_1Appender =
[
    [ "Appender", "classjuce_1_1LinkedListPointer_1_1Appender.html#a549d6af90f8480f9e2bb1a3c349e018b", null ],
    [ "append", "classjuce_1_1LinkedListPointer_1_1Appender.html#a7182ff193183d863a51d87e0033b5fa5", null ]
];