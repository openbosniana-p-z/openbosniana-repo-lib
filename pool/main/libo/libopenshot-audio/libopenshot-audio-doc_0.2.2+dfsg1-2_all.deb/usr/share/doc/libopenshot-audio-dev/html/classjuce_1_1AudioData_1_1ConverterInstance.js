var classjuce_1_1AudioData_1_1ConverterInstance =
[
    [ "ConverterInstance", "classjuce_1_1AudioData_1_1ConverterInstance.html#abd8615101015e194d7d43fc5d58933f3", null ],
    [ "convertSamples", "classjuce_1_1AudioData_1_1ConverterInstance.html#a28f1dfc9117be5886c406353c3feeb61", null ],
    [ "convertSamples", "classjuce_1_1AudioData_1_1ConverterInstance.html#a61e8005f677643a90dd6d24ee83e128d", null ]
];