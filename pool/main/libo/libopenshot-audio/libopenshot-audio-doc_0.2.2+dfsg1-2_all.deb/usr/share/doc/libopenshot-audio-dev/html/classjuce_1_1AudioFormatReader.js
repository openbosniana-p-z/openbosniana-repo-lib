var classjuce_1_1AudioFormatReader =
[
    [ "ReadHelper", "structjuce_1_1AudioFormatReader_1_1ReadHelper.html", "structjuce_1_1AudioFormatReader_1_1ReadHelper" ],
    [ "AudioFormatReader", "classjuce_1_1AudioFormatReader.html#ac0eaf7e9c914bf328e56ae555d9a2b5b", null ],
    [ "~AudioFormatReader", "classjuce_1_1AudioFormatReader.html#a5800d18718a0d08e2b1741e75d52a936", null ],
    [ "getFormatName", "classjuce_1_1AudioFormatReader.html#a33cf0a275104f92c0a574c440f940ea6", null ],
    [ "read", "classjuce_1_1AudioFormatReader.html#a1074117e31f342d5c762c70ca0c27055", null ],
    [ "read", "classjuce_1_1AudioFormatReader.html#a449491d4dd020ed4e0dbba5472f96350", null ],
    [ "read", "classjuce_1_1AudioFormatReader.html#ae87402fca0dd9f9384477b7cf50ed434", null ],
    [ "readMaxLevels", "classjuce_1_1AudioFormatReader.html#ad0159b2b47a152f37d488320ed591a01", null ],
    [ "readMaxLevels", "classjuce_1_1AudioFormatReader.html#aa271efceec031566548af063dd372ca3", null ],
    [ "searchForLevel", "classjuce_1_1AudioFormatReader.html#a13c21cf265aa8406367a1e16f4dc13a8", null ],
    [ "getChannelLayout", "classjuce_1_1AudioFormatReader.html#aadad832018a5e6b38aad72355d06a216", null ],
    [ "readSamples", "classjuce_1_1AudioFormatReader.html#ad1456ab2e1f7c0566bdd864d77a659d3", null ],
    [ "sampleRate", "classjuce_1_1AudioFormatReader.html#a9822c603b0f609efea25fed57176b26c", null ],
    [ "bitsPerSample", "classjuce_1_1AudioFormatReader.html#acc3c8af71a17b9ad06c0e44a47fcee5c", null ],
    [ "lengthInSamples", "classjuce_1_1AudioFormatReader.html#a925b645c42ec1c79463b2f565331891a", null ],
    [ "numChannels", "classjuce_1_1AudioFormatReader.html#aea7134d9c4bfc905dcc508c4fe880e9a", null ],
    [ "usesFloatingPointData", "classjuce_1_1AudioFormatReader.html#a07b44f6fb2aa02226943244ffc36b0ed", null ],
    [ "metadataValues", "classjuce_1_1AudioFormatReader.html#a3ebac272495ec4e61abbb6e7f20a6b04", null ],
    [ "input", "classjuce_1_1AudioFormatReader.html#a06f90bc088c17a8468a14b5725baea4a", null ]
];