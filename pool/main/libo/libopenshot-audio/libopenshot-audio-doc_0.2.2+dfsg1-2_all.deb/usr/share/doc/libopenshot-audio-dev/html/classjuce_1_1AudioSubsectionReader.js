var classjuce_1_1AudioSubsectionReader =
[
    [ "AudioSubsectionReader", "classjuce_1_1AudioSubsectionReader.html#a04b18267bd3f00de866594b559b25339", null ],
    [ "~AudioSubsectionReader", "classjuce_1_1AudioSubsectionReader.html#a15ef0f428cc519bef55e5580e6e104d7", null ],
    [ "readSamples", "classjuce_1_1AudioSubsectionReader.html#ae4e44c909d60677877c333513cb2df61", null ],
    [ "readMaxLevels", "classjuce_1_1AudioSubsectionReader.html#a4cea22cc17c300bbba75c3260fefd4d9", null ],
    [ "readMaxLevels", "classjuce_1_1AudioSubsectionReader.html#ad0159b2b47a152f37d488320ed591a01", null ],
    [ "readMaxLevels", "classjuce_1_1AudioSubsectionReader.html#aa271efceec031566548af063dd372ca3", null ]
];