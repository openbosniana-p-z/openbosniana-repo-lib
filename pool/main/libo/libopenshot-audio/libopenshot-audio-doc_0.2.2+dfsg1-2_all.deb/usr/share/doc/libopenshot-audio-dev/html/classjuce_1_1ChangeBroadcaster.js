var classjuce_1_1ChangeBroadcaster =
[
    [ "ChangeBroadcaster", "classjuce_1_1ChangeBroadcaster.html#a366130832abce0283b9c74679e418027", null ],
    [ "~ChangeBroadcaster", "classjuce_1_1ChangeBroadcaster.html#a2e41c596ff84319568b5cf4112e800ca", null ],
    [ "addChangeListener", "classjuce_1_1ChangeBroadcaster.html#a6bc2637cd9de277aac088b7ca850d9eb", null ],
    [ "removeChangeListener", "classjuce_1_1ChangeBroadcaster.html#aca84697672ed0a02c92b1c427fe1cd95", null ],
    [ "removeAllChangeListeners", "classjuce_1_1ChangeBroadcaster.html#ae49e5048907fc6e693c812a4b9bf4752", null ],
    [ "sendChangeMessage", "classjuce_1_1ChangeBroadcaster.html#a1903f8dec57627997bbbf3d042d3b670", null ],
    [ "sendSynchronousChangeMessage", "classjuce_1_1ChangeBroadcaster.html#ae99cb471a790d49657be51413e521d37", null ],
    [ "dispatchPendingMessages", "classjuce_1_1ChangeBroadcaster.html#afd8b6d0110f62dbb49c3c7b425284210", null ],
    [ "ChangeBroadcasterCallback", "classjuce_1_1ChangeBroadcaster.html#a1f76649eae8591a4c51cd969d9be60bf", null ]
];