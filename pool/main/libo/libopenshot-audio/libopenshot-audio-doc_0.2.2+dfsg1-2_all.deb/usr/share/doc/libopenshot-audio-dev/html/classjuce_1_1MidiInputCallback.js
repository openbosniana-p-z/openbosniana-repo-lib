var classjuce_1_1MidiInputCallback =
[
    [ "~MidiInputCallback", "classjuce_1_1MidiInputCallback.html#a508810623fc52e122bd2896ff40c1fbb", null ],
    [ "handleIncomingMidiMessage", "classjuce_1_1MidiInputCallback.html#a9a183a476fa55e72cba8274699c3b618", null ],
    [ "handlePartialSysexMessage", "classjuce_1_1MidiInputCallback.html#a9764a24c581fedd4acc85397440f2f60", null ]
];