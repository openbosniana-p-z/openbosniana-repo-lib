var classjuce_1_1MessageManager_1_1MessageBase =
[
    [ "Ptr", "classjuce_1_1MessageManager_1_1MessageBase.html#a53b969f9cb6e170c41ef7329e503dc96", null ],
    [ "MessageBase", "classjuce_1_1MessageManager_1_1MessageBase.html#a5553d439c5ab16d5f6f64a778bc333d7", null ],
    [ "~MessageBase", "classjuce_1_1MessageManager_1_1MessageBase.html#ae0cd74ad557eb08c02a514c4f2592c9c", null ],
    [ "messageCallback", "classjuce_1_1MessageManager_1_1MessageBase.html#ab4115dfaf186f747d3415e7e318cb46d", null ],
    [ "post", "classjuce_1_1MessageManager_1_1MessageBase.html#a6c8de4965391d60d860747641f024da2", null ]
];