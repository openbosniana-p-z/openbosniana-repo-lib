var classjuce_1_1AiffAudioFormatWriter =
[
    [ "AiffAudioFormatWriter", "classjuce_1_1AiffAudioFormatWriter.html#ad07fc67bac2f3b20771a1effbfead711", null ],
    [ "~AiffAudioFormatWriter", "classjuce_1_1AiffAudioFormatWriter.html#a826020e6ae11cf565ba5ec3525377265", null ],
    [ "write", "classjuce_1_1AiffAudioFormatWriter.html#af717d320d9a1fdb78dbccf7ebfa57fe5", null ]
];