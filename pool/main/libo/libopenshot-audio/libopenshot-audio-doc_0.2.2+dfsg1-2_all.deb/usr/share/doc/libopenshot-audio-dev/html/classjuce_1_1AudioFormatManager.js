var classjuce_1_1AudioFormatManager =
[
    [ "AudioFormatManager", "classjuce_1_1AudioFormatManager.html#a5957f3b844ac5345acc798a1188a3a00", null ],
    [ "~AudioFormatManager", "classjuce_1_1AudioFormatManager.html#a9ff87d2e901be3fdcae1f2efc914d848", null ],
    [ "registerFormat", "classjuce_1_1AudioFormatManager.html#a89eb4a779e7cd17a9e53868db0f52ea7", null ],
    [ "registerBasicFormats", "classjuce_1_1AudioFormatManager.html#aecbd7fe2265f9651129dd75c2b46c35c", null ],
    [ "clearFormats", "classjuce_1_1AudioFormatManager.html#ae47c718db639b7682fd9a4b03644ef3f", null ],
    [ "getNumKnownFormats", "classjuce_1_1AudioFormatManager.html#add03c2f2be7199482343663201b1789d", null ],
    [ "getKnownFormat", "classjuce_1_1AudioFormatManager.html#a5efe08a209b08281f67c1a43f415440c", null ],
    [ "begin", "classjuce_1_1AudioFormatManager.html#af64532b1d322ea39dd1110bb72c0e475", null ],
    [ "begin", "classjuce_1_1AudioFormatManager.html#ad0cfa5348fbd0c1061b477c4156bc5fd", null ],
    [ "end", "classjuce_1_1AudioFormatManager.html#a6f5527e68e87d964d3b56a723a59e3f3", null ],
    [ "end", "classjuce_1_1AudioFormatManager.html#a476f72797052dacc28f83bd38260b0db", null ],
    [ "findFormatForFileExtension", "classjuce_1_1AudioFormatManager.html#adc2e79bce883c7879dc7a8579332d2b2", null ],
    [ "getDefaultFormat", "classjuce_1_1AudioFormatManager.html#ac79a6c0afa8190484249cfe0f73238d6", null ],
    [ "getWildcardForAllFormats", "classjuce_1_1AudioFormatManager.html#ae0679b99183c4e2f40c091de15407816", null ],
    [ "createReaderFor", "classjuce_1_1AudioFormatManager.html#a329d2f9b5739d22dd94a0a0599eb3521", null ],
    [ "createReaderFor", "classjuce_1_1AudioFormatManager.html#a4d08bc8e889a14ab71908531e8e1302f", null ]
];