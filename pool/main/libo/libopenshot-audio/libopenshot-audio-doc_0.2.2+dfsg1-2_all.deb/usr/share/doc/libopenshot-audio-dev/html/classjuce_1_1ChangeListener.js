var classjuce_1_1ChangeListener =
[
    [ "~ChangeListener", "classjuce_1_1ChangeListener.html#a2e707bb97e383b6c27f6e64f246de0f0", null ],
    [ "changeListenerCallback", "classjuce_1_1ChangeListener.html#a7555db6fce37e0416d3d360c64719eff", null ]
];