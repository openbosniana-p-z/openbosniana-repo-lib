var classjuce_1_1AudioTransportSource =
[
    [ "AudioTransportSource", "classjuce_1_1AudioTransportSource.html#aae0f08c9d0ff88c425b7c048b0783392", null ],
    [ "~AudioTransportSource", "classjuce_1_1AudioTransportSource.html#a8cd632bf9fc884975e2e9810401fe516", null ],
    [ "setSource", "classjuce_1_1AudioTransportSource.html#aab7c5b8c21979b69f30dee5ec6eb2b18", null ],
    [ "setPosition", "classjuce_1_1AudioTransportSource.html#a9bb0ca80cd5f506da34a8ba2b0c64f55", null ],
    [ "getCurrentPosition", "classjuce_1_1AudioTransportSource.html#a12cd972470a1f398866121748273fc5b", null ],
    [ "getLengthInSeconds", "classjuce_1_1AudioTransportSource.html#a9bdcb35d0886aa68c085e3ba9b8ea799", null ],
    [ "hasStreamFinished", "classjuce_1_1AudioTransportSource.html#a03d4a81ce953f692c5e26b1df45f05ec", null ],
    [ "start", "classjuce_1_1AudioTransportSource.html#acc2d195becc88ac34ee9894d1c98db35", null ],
    [ "stop", "classjuce_1_1AudioTransportSource.html#a03938aadcc3c6f250b98c54184595f60", null ],
    [ "isPlaying", "classjuce_1_1AudioTransportSource.html#a856217ebf5eeb59b5563e3e9f612da47", null ],
    [ "setGain", "classjuce_1_1AudioTransportSource.html#aa6cbf7f4575bb85ad3dde1417b7dd921", null ],
    [ "getGain", "classjuce_1_1AudioTransportSource.html#a23e58ca8dded0ddc543d366f734b7058", null ],
    [ "prepareToPlay", "classjuce_1_1AudioTransportSource.html#a07f66675bd2cb3b9e4a947379740da0a", null ],
    [ "releaseResources", "classjuce_1_1AudioTransportSource.html#a383c8c7f121d8fa13e8b22afd55d0482", null ],
    [ "getNextAudioBlock", "classjuce_1_1AudioTransportSource.html#a59191384e555ac018a6f504bd39661ee", null ],
    [ "setNextReadPosition", "classjuce_1_1AudioTransportSource.html#ad5c2f63bdcb1ab4c113338d65b93bbd0", null ],
    [ "getNextReadPosition", "classjuce_1_1AudioTransportSource.html#a127479c748ef77d4a499b4f1ee7678be", null ],
    [ "getTotalLength", "classjuce_1_1AudioTransportSource.html#a7c3ce635c69a8a40388590440184b112", null ],
    [ "isLooping", "classjuce_1_1AudioTransportSource.html#aad4c344c658fc84917963033203053a6", null ]
];