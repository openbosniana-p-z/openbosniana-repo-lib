var classjuce_1_1CoreAudioFormat =
[
    [ "CoreAudioFormat", "classjuce_1_1CoreAudioFormat.html#a55b5c5e5d31335d1d1742fbb42bb7918", null ],
    [ "~CoreAudioFormat", "classjuce_1_1CoreAudioFormat.html#a58a8dc0a8c6949382e6b485e85c0b430", null ],
    [ "getPossibleSampleRates", "classjuce_1_1CoreAudioFormat.html#ab6e638b6ef7abb0e191c3a10151a553e", null ],
    [ "getPossibleBitDepths", "classjuce_1_1CoreAudioFormat.html#af8ead5b07b597a62136f3f53604a15ec", null ],
    [ "canDoStereo", "classjuce_1_1CoreAudioFormat.html#a892b405624ce4cbd458b6bf07485f271", null ],
    [ "canDoMono", "classjuce_1_1CoreAudioFormat.html#a367ba9808536378e26f55f90aa980f5b", null ],
    [ "createReaderFor", "classjuce_1_1CoreAudioFormat.html#a90b1bffc0c4dd3bf5631f97715e6e14b", null ],
    [ "createWriterFor", "classjuce_1_1CoreAudioFormat.html#ae85da2aa6dc7fb178b69ac71e65533e7", null ],
    [ "createWriterFor", "classjuce_1_1CoreAudioFormat.html#a9e6e1d78c5ef9e3c81fcf000ef4ca01b", null ],
    [ "createWriterFor", "classjuce_1_1CoreAudioFormat.html#abc557f6f759552ec6b4302629739a788", null ]
];