var classjuce_1_1MPEChannelAssigner =
[
    [ "MPEChannelAssigner", "classjuce_1_1MPEChannelAssigner.html#ad54c889470211422f6a053ddf68cb3bb", null ],
    [ "MPEChannelAssigner", "classjuce_1_1MPEChannelAssigner.html#a0546e9c347dfaef8a8b89f19bb9c5870", null ],
    [ "findMidiChannelForNewNote", "classjuce_1_1MPEChannelAssigner.html#aed63e3a5b1d9d0d8ffb41c1f597d5b09", null ],
    [ "noteOff", "classjuce_1_1MPEChannelAssigner.html#af911127362d352dc2a6b7571ce0526d7", null ],
    [ "allNotesOff", "classjuce_1_1MPEChannelAssigner.html#afbfeacc20013bb572638f409b2f92dfa", null ]
];