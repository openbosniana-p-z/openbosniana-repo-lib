var classjuce_1_1Expression_1_1Scope_1_1Visitor =
[
    [ "~Visitor", "classjuce_1_1Expression_1_1Scope_1_1Visitor.html#aa3c2adf9ade46c82f49d8fd9bb8a9451", null ],
    [ "visit", "classjuce_1_1Expression_1_1Scope_1_1Visitor.html#a8d7737ac9566d0c486ee6e398b95b854", null ]
];