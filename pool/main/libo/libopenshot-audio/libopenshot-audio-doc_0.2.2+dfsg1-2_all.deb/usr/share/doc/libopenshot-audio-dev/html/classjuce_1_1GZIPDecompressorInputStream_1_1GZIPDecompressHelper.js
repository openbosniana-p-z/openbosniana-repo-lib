var classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper =
[
    [ "GZIPDecompressHelper", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper.html#a59ed5b741266b3850b494ecdbf78d00b", null ],
    [ "~GZIPDecompressHelper", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper.html#ab8fd23b719c7eb00ef52e9bde5e623fa", null ],
    [ "needsInput", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper.html#aecbe95cf0629c9168943786e888aabad", null ],
    [ "setInput", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper.html#af06617e89760941ee2f54eb396e342d8", null ],
    [ "doNextBlock", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper.html#a7e575c3232ed1dea9c21bd19a16bbebb", null ],
    [ "finished", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper.html#aea4033907884b9596b6b5b7eb0b3fde7", null ],
    [ "needsDictionary", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper.html#a5080e1c3fb734737ef81eca1ad6a2336", null ],
    [ "error", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper.html#a1f253ed40868bc5b12eec0527067e886", null ],
    [ "streamIsValid", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper.html#aaa9683e823511638654ec8c6432e85c0", null ]
];