var classjuce_1_1ChildProcessMaster =
[
    [ "Connection", "structjuce_1_1ChildProcessMaster_1_1Connection.html", "structjuce_1_1ChildProcessMaster_1_1Connection" ],
    [ "ChildProcessMaster", "classjuce_1_1ChildProcessMaster.html#a75af6cb205e051751a7a369af022d25c", null ],
    [ "~ChildProcessMaster", "classjuce_1_1ChildProcessMaster.html#a3d452e6d9c8352a02dda45ad1b033ee7", null ],
    [ "launchSlaveProcess", "classjuce_1_1ChildProcessMaster.html#ae958e651147091662dac3bea3dff9a08", null ],
    [ "killSlaveProcess", "classjuce_1_1ChildProcessMaster.html#a64dcd715d4cec742d147cb79a0493e9b", null ],
    [ "handleMessageFromSlave", "classjuce_1_1ChildProcessMaster.html#a310fe90158d5914c5b466b7d629a2859", null ],
    [ "handleConnectionLost", "classjuce_1_1ChildProcessMaster.html#aecbaefb969a3d245c5265672dedb4757", null ],
    [ "sendMessageToSlave", "classjuce_1_1ChildProcessMaster.html#a006af77f649198a0472ba1ce3b59c2aa", null ]
];