var classjuce_1_1BufferingAudioSource =
[
    [ "BufferingAudioSource", "classjuce_1_1BufferingAudioSource.html#a748c56ffe0812a020876b8b7db0cbb96", null ],
    [ "~BufferingAudioSource", "classjuce_1_1BufferingAudioSource.html#a66a3911b128284527d3b3f3829961874", null ],
    [ "prepareToPlay", "classjuce_1_1BufferingAudioSource.html#af233e5c28e871e87e6ed9fae6e57b991", null ],
    [ "releaseResources", "classjuce_1_1BufferingAudioSource.html#ae6b6084c0fe7ac9dfffe599ae7ceab2e", null ],
    [ "getNextAudioBlock", "classjuce_1_1BufferingAudioSource.html#a135a967ceede57c3eb7c01e8e4e7d7be", null ],
    [ "setNextReadPosition", "classjuce_1_1BufferingAudioSource.html#a2a5b82249c15d449b625a6f7c39b2d55", null ],
    [ "getNextReadPosition", "classjuce_1_1BufferingAudioSource.html#aeaf93e4ec9f761a1b8b5aaeb6ffcbdf3", null ],
    [ "getTotalLength", "classjuce_1_1BufferingAudioSource.html#a65f661362f37dca6873d77f031a17521", null ],
    [ "isLooping", "classjuce_1_1BufferingAudioSource.html#a7eb7d477a81ddda912dfa1efc53fa553", null ],
    [ "waitForNextAudioBlockReady", "classjuce_1_1BufferingAudioSource.html#ae7c106ac10579af319b9ea931cd75907", null ]
];