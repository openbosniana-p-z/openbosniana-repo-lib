var classjuce_1_1MemoryMappedFile =
[
    [ "AccessMode", "classjuce_1_1MemoryMappedFile.html#acb17e1ac2c4919de6cca24e6d92b13f7", [
      [ "readOnly", "classjuce_1_1MemoryMappedFile.html#acb17e1ac2c4919de6cca24e6d92b13f7a9db38fcd6341ddc8e94f020f41e3fa5d", null ],
      [ "readWrite", "classjuce_1_1MemoryMappedFile.html#acb17e1ac2c4919de6cca24e6d92b13f7a4a81afa4940edffee38cb72ac7cf8288", null ]
    ] ],
    [ "MemoryMappedFile", "classjuce_1_1MemoryMappedFile.html#a5ee188facfb2f6a347268ba18211a324", null ],
    [ "MemoryMappedFile", "classjuce_1_1MemoryMappedFile.html#accd56ba406e8d1db6ad71707b02af278", null ],
    [ "~MemoryMappedFile", "classjuce_1_1MemoryMappedFile.html#a2a481e9a8067f20f9edd56884fc20236", null ],
    [ "getData", "classjuce_1_1MemoryMappedFile.html#aff8b64137388127cbbc68b042f6902f7", null ],
    [ "getSize", "classjuce_1_1MemoryMappedFile.html#a82218b9347cf7bf8ac8192b59ea35fdd", null ],
    [ "getRange", "classjuce_1_1MemoryMappedFile.html#a936891d69e9dbdebbbc66b1438a56747", null ]
];