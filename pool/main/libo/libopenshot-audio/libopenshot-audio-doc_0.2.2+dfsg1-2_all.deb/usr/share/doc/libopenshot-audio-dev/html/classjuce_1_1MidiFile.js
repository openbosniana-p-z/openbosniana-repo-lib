var classjuce_1_1MidiFile =
[
    [ "MidiFile", "classjuce_1_1MidiFile.html#aaccdf3403843ce42bd9c54faeaed8232", null ],
    [ "~MidiFile", "classjuce_1_1MidiFile.html#aa411a5e0dae1c09180524e2a48f9e7e6", null ],
    [ "MidiFile", "classjuce_1_1MidiFile.html#a104aede5d05d2b7acbdee14058148dda", null ],
    [ "MidiFile", "classjuce_1_1MidiFile.html#a4c53cda8e3e9cb4a6ba3288d4bcc58c3", null ],
    [ "operator=", "classjuce_1_1MidiFile.html#a96f07df3c0fd480865b101de83ae1633", null ],
    [ "operator=", "classjuce_1_1MidiFile.html#ad37e9712ac46d9cca04c31f32b0b8b20", null ],
    [ "getNumTracks", "classjuce_1_1MidiFile.html#a32a43362581f9e9059d2064e2dcc6c4c", null ],
    [ "getTrack", "classjuce_1_1MidiFile.html#ac8d26f1b81f9e5bdd21361f89e9ee4ca", null ],
    [ "addTrack", "classjuce_1_1MidiFile.html#a227e2edcdb92091495de8b545c054f08", null ],
    [ "clear", "classjuce_1_1MidiFile.html#abcd73aaf5265a152ce27da1a10e32433", null ],
    [ "getTimeFormat", "classjuce_1_1MidiFile.html#a53785ff4de6301879360a7d06ed01439", null ],
    [ "setTicksPerQuarterNote", "classjuce_1_1MidiFile.html#a268f311766c447c23b50c964daf25207", null ],
    [ "setSmpteTimeFormat", "classjuce_1_1MidiFile.html#a68bcc521fcc580f2956158c1d9609588", null ],
    [ "findAllTempoEvents", "classjuce_1_1MidiFile.html#ab15cde3d9424503e9ba875d7f367b297", null ],
    [ "findAllTimeSigEvents", "classjuce_1_1MidiFile.html#aafaf65e44addd00fdc4f5dcfc3cc42b6", null ],
    [ "findAllKeySigEvents", "classjuce_1_1MidiFile.html#aafe6d1bab3d7de5227cc6163210db3d3", null ],
    [ "getLastTimestamp", "classjuce_1_1MidiFile.html#a86ca8799fbc575f68ea10b26f974e0f1", null ],
    [ "readFrom", "classjuce_1_1MidiFile.html#a9683f7bee63f4bba4b57eee9f40f5a59", null ],
    [ "writeTo", "classjuce_1_1MidiFile.html#aee9dcc166feea5a8d6e2b40d66189ce8", null ],
    [ "convertTimestampTicksToSeconds", "classjuce_1_1MidiFile.html#a10758042527b3ce6454e499d1f182c27", null ]
];