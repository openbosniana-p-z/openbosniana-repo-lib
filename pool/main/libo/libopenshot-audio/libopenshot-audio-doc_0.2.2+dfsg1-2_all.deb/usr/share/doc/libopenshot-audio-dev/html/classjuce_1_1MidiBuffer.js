var classjuce_1_1MidiBuffer =
[
    [ "Iterator", "classjuce_1_1MidiBuffer_1_1Iterator.html", "classjuce_1_1MidiBuffer_1_1Iterator" ],
    [ "MidiBuffer", "classjuce_1_1MidiBuffer.html#a537480a723765b273e950c4b7bcc0704", null ],
    [ "MidiBuffer", "classjuce_1_1MidiBuffer.html#acc861b77fc4d3caf8c124790e93203a7", null ],
    [ "MidiBuffer", "classjuce_1_1MidiBuffer.html#af964706592abb799c9fef1c885cf5921", null ],
    [ "~MidiBuffer", "classjuce_1_1MidiBuffer.html#ac1fa694bab035f13855c0f4255f1e6c7", null ],
    [ "operator=", "classjuce_1_1MidiBuffer.html#a019bf3216e23d58f27186470a5d846c9", null ],
    [ "clear", "classjuce_1_1MidiBuffer.html#ad2dcf7d6edb7860b432d247f0efcccca", null ],
    [ "clear", "classjuce_1_1MidiBuffer.html#ade4e9d5b4ca396e94c03d3370972b77c", null ],
    [ "isEmpty", "classjuce_1_1MidiBuffer.html#a720c48382729df3f4a5c0cfd0ff5c7fe", null ],
    [ "getNumEvents", "classjuce_1_1MidiBuffer.html#a5380365aa8f9caf0481ea37266232114", null ],
    [ "addEvent", "classjuce_1_1MidiBuffer.html#a41aa0005ca7b671420d78ada7d82fc35", null ],
    [ "addEvent", "classjuce_1_1MidiBuffer.html#a2a0195a9d99fe096438ed77afe97735b", null ],
    [ "addEvents", "classjuce_1_1MidiBuffer.html#ad6c842cb85ef82b1c1f26379d21e3717", null ],
    [ "getFirstEventTime", "classjuce_1_1MidiBuffer.html#a0132459c4adc186205092bde20d6b2b0", null ],
    [ "getLastEventTime", "classjuce_1_1MidiBuffer.html#a427b8f5ed899a218de7fb1e8d2da4ed0", null ],
    [ "swapWith", "classjuce_1_1MidiBuffer.html#a88adf819e6f8d6277dff10dd7d7b2edd", null ],
    [ "ensureSize", "classjuce_1_1MidiBuffer.html#a522ba870516b6ab1b8e369befe3a9808", null ],
    [ "data", "classjuce_1_1MidiBuffer.html#ae0467191657f0d393cb915ca88ba1944", null ]
];