var classjuce_1_1MemoryMappedWavReader =
[
    [ "MemoryMappedWavReader", "classjuce_1_1MemoryMappedWavReader.html#a90986dde605076aea56dcbfe54e700eb", null ],
    [ "readSamples", "classjuce_1_1MemoryMappedWavReader.html#ace215b4e626ea86413898408e1bb7f3d", null ],
    [ "getSample", "classjuce_1_1MemoryMappedWavReader.html#a7ade1a4d2df1050823932681adba5856", null ],
    [ "readMaxLevels", "classjuce_1_1MemoryMappedWavReader.html#a683e9c93a50ab9b53d1cbc43c3d41413", null ],
    [ "readMaxLevels", "classjuce_1_1MemoryMappedWavReader.html#ad0159b2b47a152f37d488320ed591a01", null ],
    [ "readMaxLevels", "classjuce_1_1MemoryMappedWavReader.html#aa271efceec031566548af063dd372ca3", null ]
];