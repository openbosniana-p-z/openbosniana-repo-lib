var classjuce_1_1ArrayAllocationBase =
[
    [ "ArrayAllocationBase", "classjuce_1_1ArrayAllocationBase.html#a9b64af32d88c9deff9c9a3b9b2801930", null ],
    [ "~ArrayAllocationBase", "classjuce_1_1ArrayAllocationBase.html#aa77ac08909ce472863405f44a9edb890", null ],
    [ "ArrayAllocationBase", "classjuce_1_1ArrayAllocationBase.html#a7bc8ee16f548f61cdba32042f2175fdd", null ],
    [ "operator=", "classjuce_1_1ArrayAllocationBase.html#a288f18f976061a24597ffafaf51d8266", null ],
    [ "setAllocatedSize", "classjuce_1_1ArrayAllocationBase.html#aaf7d1717cc1ca241aa097889b11ee4af", null ],
    [ "ensureAllocatedSize", "classjuce_1_1ArrayAllocationBase.html#aabe8e823015d37c5d3c04537fa8ac75f", null ],
    [ "shrinkToNoMoreThan", "classjuce_1_1ArrayAllocationBase.html#a753ad64b20f7b5749f58c05a9f8b5d46", null ],
    [ "swapWith", "classjuce_1_1ArrayAllocationBase.html#ac4eedb15aa02f43c3e983ffe667259c7", null ],
    [ "elements", "classjuce_1_1ArrayAllocationBase.html#a04bfdfbf34273936fe27d17e4c9644f9", null ],
    [ "numAllocated", "classjuce_1_1ArrayAllocationBase.html#ae622d6f1105ce4691164cee048d7b4ba", null ]
];