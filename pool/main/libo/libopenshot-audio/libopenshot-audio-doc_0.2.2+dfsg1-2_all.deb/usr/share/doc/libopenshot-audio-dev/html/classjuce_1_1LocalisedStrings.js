var classjuce_1_1LocalisedStrings =
[
    [ "LocalisedStrings", "classjuce_1_1LocalisedStrings.html#aea1956ca66893d69a9c3225c5e6fc52d", null ],
    [ "LocalisedStrings", "classjuce_1_1LocalisedStrings.html#af74074d29eef9ffa085708b4d4e39c43", null ],
    [ "LocalisedStrings", "classjuce_1_1LocalisedStrings.html#a2fbce11cc7a45b271b2730259d66fdaf", null ],
    [ "~LocalisedStrings", "classjuce_1_1LocalisedStrings.html#ad10131014a7ce39b28060bcf09a790eb", null ],
    [ "operator=", "classjuce_1_1LocalisedStrings.html#a66b3931f8c8200dc72bc49c7230b79b3", null ],
    [ "translate", "classjuce_1_1LocalisedStrings.html#a9aaa41fa160c9d135822f1fe10640e7b", null ],
    [ "translate", "classjuce_1_1LocalisedStrings.html#a26324c3a00a64f2c7d6e135a447ca83a", null ],
    [ "getLanguageName", "classjuce_1_1LocalisedStrings.html#af6f02100017099ef04499ca8e14c2f22", null ],
    [ "getCountryCodes", "classjuce_1_1LocalisedStrings.html#a65df80db02afe94e4cd1a73ce4c4b028", null ],
    [ "getMappings", "classjuce_1_1LocalisedStrings.html#a172066f50308192036cb12151a7bc65d", null ],
    [ "addStrings", "classjuce_1_1LocalisedStrings.html#ada978a7978a16f632a4dc78cbd97099f", null ],
    [ "setFallback", "classjuce_1_1LocalisedStrings.html#af40197b58bae7b32513eb1cde5392a8b", null ]
];