var classjuce_1_1CoreAudioReader =
[
    [ "CoreAudioReader", "classjuce_1_1CoreAudioReader.html#a3b400971b1c27433f50dc8e7f7d94393", null ],
    [ "~CoreAudioReader", "classjuce_1_1CoreAudioReader.html#ac7e7e52e4be70982cf30e87c3abdb0fc", null ],
    [ "readSamples", "classjuce_1_1CoreAudioReader.html#a841d34a509952aa26635071766a5cfc6", null ],
    [ "getChannelLayout", "classjuce_1_1CoreAudioReader.html#a337a235e57605dd787d007e2c770b8db", null ],
    [ "ok", "classjuce_1_1CoreAudioReader.html#aa4379a96a22c9cab3bf8baa36b7e7ff4", null ]
];