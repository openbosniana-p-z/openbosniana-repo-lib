var classjuce_1_1Message =
[
    [ "Ptr", "classjuce_1_1Message.html#a713002a056e0467f37fdeb24e6867b3f", null ],
    [ "Message", "classjuce_1_1Message.html#a2e6d11664783ed81718fba19e6eac484", null ],
    [ "~Message", "classjuce_1_1Message.html#abe6ae56ff418b6dce026e93fc06a0ea1", null ],
    [ "MessageListener", "classjuce_1_1Message.html#a4055050aa3e39d53355773b9cbc49d31", null ]
];