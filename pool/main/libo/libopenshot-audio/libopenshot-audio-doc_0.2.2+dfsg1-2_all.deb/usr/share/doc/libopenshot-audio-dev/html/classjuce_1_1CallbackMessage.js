var classjuce_1_1CallbackMessage =
[
    [ "CallbackMessage", "classjuce_1_1CallbackMessage.html#a66f893c18a65240d46aec8244cffec87", null ],
    [ "~CallbackMessage", "classjuce_1_1CallbackMessage.html#ad7bf7223659c7d759ef1afa66af910ea", null ],
    [ "messageCallback", "classjuce_1_1CallbackMessage.html#a5c0e7f4b91121a2f599da364a1af453a", null ]
];