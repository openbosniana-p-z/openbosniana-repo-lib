var classjuce_1_1ADSR =
[
    [ "Parameters", "classjuce_1_1ADSR.html#structjuce_1_1ADSR_1_1Parameters", [
      [ "attack", "classjuce_1_1ADSR.html#a7f9440cfa583ce07ab7d438c72da99fe", null ],
      [ "decay", "classjuce_1_1ADSR.html#aecc55d6dac6476356c20919a29bd1b4e", null ],
      [ "sustain", "classjuce_1_1ADSR.html#aac669a150f0841cbf68e3563d7f08c86", null ],
      [ "release", "classjuce_1_1ADSR.html#ab7b7b31db69e33476d2a032b49e3a88e", null ]
    ] ],
    [ "ADSR", "classjuce_1_1ADSR.html#afa6c85d507c64f33372f7f5eb4baa810", null ],
    [ "setParameters", "classjuce_1_1ADSR.html#a4c46d7d12f594059a1177905ccde95c9", null ],
    [ "getParameters", "classjuce_1_1ADSR.html#a108a604e8484bc0313f3e21d9c110c2e", null ],
    [ "isActive", "classjuce_1_1ADSR.html#a35b5a6c4fcac39eee35ebaf3d1d3973e", null ],
    [ "setSampleRate", "classjuce_1_1ADSR.html#a1da57b3cb1f2828d2aee27dcd19a2a3f", null ],
    [ "reset", "classjuce_1_1ADSR.html#ab53a8e8a7a8f216d06c7b74db5949347", null ],
    [ "noteOn", "classjuce_1_1ADSR.html#ab0174b065b81405e296f73063e0990fa", null ],
    [ "noteOff", "classjuce_1_1ADSR.html#a6f90b13036a324633f86c2edf16c8c00", null ],
    [ "getNextSample", "classjuce_1_1ADSR.html#a9103ff0f34ca8e9c93e3cce7c50a5deb", null ],
    [ "applyEnvelopeToBuffer", "classjuce_1_1ADSR.html#ae929532a0f6f8d5e891e6cadc923c665", null ]
];