var classjuce_1_1MP3AudioFormat =
[
    [ "MP3AudioFormat", "classjuce_1_1MP3AudioFormat.html#ae28634c0fc96a69f44067ab3f83b8110", null ],
    [ "~MP3AudioFormat", "classjuce_1_1MP3AudioFormat.html#a201ad5736ee7806f43fddda6d864ed57", null ],
    [ "getPossibleSampleRates", "classjuce_1_1MP3AudioFormat.html#aae66c934ce72274c064996bfa376e53e", null ],
    [ "getPossibleBitDepths", "classjuce_1_1MP3AudioFormat.html#a7d6c7543bbc6425644fcbf3ded911eca", null ],
    [ "canDoStereo", "classjuce_1_1MP3AudioFormat.html#a1231462be18e700b43308b50d23ffbf8", null ],
    [ "canDoMono", "classjuce_1_1MP3AudioFormat.html#afce4646e82d12ea3ba25268512f85aa2", null ],
    [ "isCompressed", "classjuce_1_1MP3AudioFormat.html#adba8c3289dd7a365095e939cac8aff72", null ],
    [ "getQualityOptions", "classjuce_1_1MP3AudioFormat.html#a639fb918e74c171b6ec603239284cdab", null ],
    [ "createReaderFor", "classjuce_1_1MP3AudioFormat.html#a65a5f8278cd5a9562c4fead0090232f2", null ],
    [ "createWriterFor", "classjuce_1_1MP3AudioFormat.html#aed52a483bf1589f28cb8bc7e8b901c1c", null ],
    [ "createWriterFor", "classjuce_1_1MP3AudioFormat.html#a9e6e1d78c5ef9e3c81fcf000ef4ca01b", null ],
    [ "createWriterFor", "classjuce_1_1MP3AudioFormat.html#abc557f6f759552ec6b4302629739a788", null ]
];