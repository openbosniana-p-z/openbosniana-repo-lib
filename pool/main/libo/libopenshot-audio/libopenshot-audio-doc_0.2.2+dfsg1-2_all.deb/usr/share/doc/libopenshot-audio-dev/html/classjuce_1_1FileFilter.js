var classjuce_1_1FileFilter =
[
    [ "FileFilter", "classjuce_1_1FileFilter.html#ad317ae255e0151101481672c68e1b56b", null ],
    [ "~FileFilter", "classjuce_1_1FileFilter.html#a2f1b4146a242522027f1f9c4d6ce8439", null ],
    [ "getDescription", "classjuce_1_1FileFilter.html#aaba6ac5d0963168cc2aaa5e5cd2c558e", null ],
    [ "isFileSuitable", "classjuce_1_1FileFilter.html#a8de839ca919a94484b922231eea74449", null ],
    [ "isDirectorySuitable", "classjuce_1_1FileFilter.html#aa7cc0eb6f36d2e41be6233df8d091b1b", null ],
    [ "description", "classjuce_1_1FileFilter.html#ab2f33535ba92ef086117c01a252470ca", null ]
];