var classjuce_1_1AiffAudioFormatReader =
[
    [ "AiffAudioFormatReader", "classjuce_1_1AiffAudioFormatReader.html#a44ced4381f88e8545d07f15897aaadbc", null ],
    [ "readSamples", "classjuce_1_1AiffAudioFormatReader.html#ad583b88c6e32d4e0cd004b16b724385a", null ],
    [ "bytesPerFrame", "classjuce_1_1AiffAudioFormatReader.html#a8fdfd010e268df98157963737ba85c73", null ],
    [ "dataChunkStart", "classjuce_1_1AiffAudioFormatReader.html#ac78a7006baaffb95fb8415666664a41e", null ],
    [ "littleEndian", "classjuce_1_1AiffAudioFormatReader.html#ae847d30426485545b618a95772c275af", null ]
];