var classjuce_1_1AudioDataConverters =
[
    [ "DataFormat", "classjuce_1_1AudioDataConverters.html#a53bcd8cefec9620f4cb904d84b223c7d", [
      [ "int16LE", "classjuce_1_1AudioDataConverters.html#a53bcd8cefec9620f4cb904d84b223c7dab25ed77cb9d6fd04720e796847c62aa6", null ],
      [ "int16BE", "classjuce_1_1AudioDataConverters.html#a53bcd8cefec9620f4cb904d84b223c7da78920c812a015dca23f13eaf407f32cd", null ],
      [ "int24LE", "classjuce_1_1AudioDataConverters.html#a53bcd8cefec9620f4cb904d84b223c7da70708a5e00527b7057daacd4f9bcc0f5", null ],
      [ "int24BE", "classjuce_1_1AudioDataConverters.html#a53bcd8cefec9620f4cb904d84b223c7da4de57a3af6303d7ec0352d1ea8c12a10", null ],
      [ "int32LE", "classjuce_1_1AudioDataConverters.html#a53bcd8cefec9620f4cb904d84b223c7daf96ab08a7558bf73af786cfc1aa1d6e1", null ],
      [ "int32BE", "classjuce_1_1AudioDataConverters.html#a53bcd8cefec9620f4cb904d84b223c7dafde80ec312fdb08513673b7c866c9c47", null ],
      [ "float32LE", "classjuce_1_1AudioDataConverters.html#a53bcd8cefec9620f4cb904d84b223c7da00961c4f79c3fa38efba5f893aa36be9", null ],
      [ "float32BE", "classjuce_1_1AudioDataConverters.html#a53bcd8cefec9620f4cb904d84b223c7daaa808bce25c67980f659c20f9c31a959", null ]
    ] ]
];