var classjuce_1_1ApplicationProperties =
[
    [ "ApplicationProperties", "classjuce_1_1ApplicationProperties.html#a4e7193d99e1263f0e39620e97b12f360", null ],
    [ "~ApplicationProperties", "classjuce_1_1ApplicationProperties.html#ad37918841ea45185b18a4057ebfa93be", null ],
    [ "setStorageParameters", "classjuce_1_1ApplicationProperties.html#adf82bea360322c0d2b1b77a40562a780", null ],
    [ "getStorageParameters", "classjuce_1_1ApplicationProperties.html#ae79679d06b7edfce7bca7cb5aecc54f7", null ],
    [ "getUserSettings", "classjuce_1_1ApplicationProperties.html#a36594d8656910895b0925594fa03b96c", null ],
    [ "getCommonSettings", "classjuce_1_1ApplicationProperties.html#a60a53f89b9ee73345004235705fed04a", null ],
    [ "saveIfNeeded", "classjuce_1_1ApplicationProperties.html#a6aa63da6b1da5b907bd44403745ecc86", null ],
    [ "closeFiles", "classjuce_1_1ApplicationProperties.html#a074f5a023b5268a7b39f6896c3e2ca42", null ]
];