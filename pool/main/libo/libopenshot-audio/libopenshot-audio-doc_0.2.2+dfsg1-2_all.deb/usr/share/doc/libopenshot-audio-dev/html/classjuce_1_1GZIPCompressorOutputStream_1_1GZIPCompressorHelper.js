var classjuce_1_1GZIPCompressorOutputStream_1_1GZIPCompressorHelper =
[
    [ "GZIPCompressorHelper", "classjuce_1_1GZIPCompressorOutputStream_1_1GZIPCompressorHelper.html#a8a9579325875faa3b8b88be7e83043eb", null ],
    [ "~GZIPCompressorHelper", "classjuce_1_1GZIPCompressorOutputStream_1_1GZIPCompressorHelper.html#a67bc91ed6b2f605e7ee0ac418bd80b43", null ],
    [ "write", "classjuce_1_1GZIPCompressorOutputStream_1_1GZIPCompressorHelper.html#a45bdf4bb28894e3b89ba7cdb9c759657", null ],
    [ "finish", "classjuce_1_1GZIPCompressorOutputStream_1_1GZIPCompressorHelper.html#a2c183976804cc793c791c428c4369084", null ]
];