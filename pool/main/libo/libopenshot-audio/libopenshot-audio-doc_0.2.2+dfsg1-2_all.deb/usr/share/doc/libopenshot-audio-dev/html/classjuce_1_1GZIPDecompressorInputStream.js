var classjuce_1_1GZIPDecompressorInputStream =
[
    [ "GZIPDecompressHelper", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper.html", "classjuce_1_1GZIPDecompressorInputStream_1_1GZIPDecompressHelper" ],
    [ "Format", "classjuce_1_1GZIPDecompressorInputStream.html#a625c61dffe17f8d32239ab59ad351bee", [
      [ "zlibFormat", "classjuce_1_1GZIPDecompressorInputStream.html#a625c61dffe17f8d32239ab59ad351beea2372aaa59dbeba91a5075fddbc7f5501", null ],
      [ "deflateFormat", "classjuce_1_1GZIPDecompressorInputStream.html#a625c61dffe17f8d32239ab59ad351beeac890236e903f5e2d6a366633ac088093", null ],
      [ "gzipFormat", "classjuce_1_1GZIPDecompressorInputStream.html#a625c61dffe17f8d32239ab59ad351beeac7d94066b13b3f58882e8222e3ae7b30", null ]
    ] ],
    [ "GZIPDecompressorInputStream", "classjuce_1_1GZIPDecompressorInputStream.html#aa84a89a523fb9a2b32eace0c4818aa45", null ],
    [ "GZIPDecompressorInputStream", "classjuce_1_1GZIPDecompressorInputStream.html#af6981f53bacf2a6e6e78a603e219dccb", null ],
    [ "~GZIPDecompressorInputStream", "classjuce_1_1GZIPDecompressorInputStream.html#a37084add99bebb77258fb8898836e93e", null ],
    [ "getPosition", "classjuce_1_1GZIPDecompressorInputStream.html#a465ec84a34427e773f85588fdd215779", null ],
    [ "setPosition", "classjuce_1_1GZIPDecompressorInputStream.html#a1d39d26b6cdd5a9181cb7f336603f699", null ],
    [ "getTotalLength", "classjuce_1_1GZIPDecompressorInputStream.html#a61621ddc54421c1dc2d58505f8b24bf6", null ],
    [ "isExhausted", "classjuce_1_1GZIPDecompressorInputStream.html#a808b2b98828a95e19a28968d002fa2ca", null ],
    [ "read", "classjuce_1_1GZIPDecompressorInputStream.html#a965c7fe4348dea97747d029a1052c8fa", null ]
];