var classjuce_1_1BufferingAudioReader =
[
    [ "BufferingAudioReader", "classjuce_1_1BufferingAudioReader.html#a1517be16c4e9604c909582549321d01f", null ],
    [ "~BufferingAudioReader", "classjuce_1_1BufferingAudioReader.html#af50c8a22d9311739d2e59009208cbff7", null ],
    [ "setReadTimeout", "classjuce_1_1BufferingAudioReader.html#abdaae838bb5853d1e700d5550151a24b", null ],
    [ "readSamples", "classjuce_1_1BufferingAudioReader.html#a05bf956e166a22b038e5348409a660f4", null ]
];