var classjuce_1_1AiffAudioFormat =
[
    [ "AiffAudioFormat", "classjuce_1_1AiffAudioFormat.html#a1a5819760286bb6c28fbd53958b935b0", null ],
    [ "~AiffAudioFormat", "classjuce_1_1AiffAudioFormat.html#af11064ff8800c30e04719bf2a852918c", null ],
    [ "getPossibleSampleRates", "classjuce_1_1AiffAudioFormat.html#ab3f9e4548e59ce6d450470ebfd5b8609", null ],
    [ "getPossibleBitDepths", "classjuce_1_1AiffAudioFormat.html#a467fd34c5a40fff7db62eb0c09237222", null ],
    [ "canDoStereo", "classjuce_1_1AiffAudioFormat.html#a2d39bd74960c253331a32fcb75e98499", null ],
    [ "canDoMono", "classjuce_1_1AiffAudioFormat.html#aaab3a7d5bf88e702f4305d8167ccedff", null ],
    [ "canHandleFile", "classjuce_1_1AiffAudioFormat.html#a79c88302a5f59833d88085a34fba8c7a", null ],
    [ "createReaderFor", "classjuce_1_1AiffAudioFormat.html#a344e0d6ee053bd563770fab3b14a54f4", null ],
    [ "createMemoryMappedReader", "classjuce_1_1AiffAudioFormat.html#abd080162169034e072ed773887ba4a34", null ],
    [ "createMemoryMappedReader", "classjuce_1_1AiffAudioFormat.html#a788802ce2a45536496aee77726248bec", null ],
    [ "createWriterFor", "classjuce_1_1AiffAudioFormat.html#abf910f9b06934a9c4871512a660df33c", null ],
    [ "createWriterFor", "classjuce_1_1AiffAudioFormat.html#a9e6e1d78c5ef9e3c81fcf000ef4ca01b", null ],
    [ "createWriterFor", "classjuce_1_1AiffAudioFormat.html#abc557f6f759552ec6b4302629739a788", null ]
];