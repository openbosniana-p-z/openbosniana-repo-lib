var classjuce_1_1InterprocessConnection =
[
    [ "ConnectionThread", "structjuce_1_1InterprocessConnection_1_1ConnectionThread.html", "structjuce_1_1InterprocessConnection_1_1ConnectionThread" ],
    [ "InterprocessConnection", "classjuce_1_1InterprocessConnection.html#a67bc4b0faef59efedb2f417afd231f88", null ],
    [ "~InterprocessConnection", "classjuce_1_1InterprocessConnection.html#a981801d72c566c14c832128f2e7f0e90", null ],
    [ "connectToSocket", "classjuce_1_1InterprocessConnection.html#afed3ed47a1ddac4428a7a637fb3074c6", null ],
    [ "connectToPipe", "classjuce_1_1InterprocessConnection.html#a86e304165972be6d5c82a36f8d068673", null ],
    [ "createPipe", "classjuce_1_1InterprocessConnection.html#a6afb122b0e9d65dead9aba005937c054", null ],
    [ "disconnect", "classjuce_1_1InterprocessConnection.html#a895af8f0eaeab3b9ea4202117afc244e", null ],
    [ "isConnected", "classjuce_1_1InterprocessConnection.html#a9159f2606dbc6fb0f971bd12c824fec0", null ],
    [ "getSocket", "classjuce_1_1InterprocessConnection.html#a8d93581fd5a291e31ef1365c6062b196", null ],
    [ "getPipe", "classjuce_1_1InterprocessConnection.html#ae8eafa4bb9711bf7b6518d8c6db92877", null ],
    [ "getConnectedHostName", "classjuce_1_1InterprocessConnection.html#a3ebcc9ad9ba014c75b924e671f21fb08", null ],
    [ "sendMessage", "classjuce_1_1InterprocessConnection.html#ae6ebaa49463c41df97fc81573608e9fb", null ],
    [ "connectionMade", "classjuce_1_1InterprocessConnection.html#a0075c756270e686efa5ede9d8e8871ed", null ],
    [ "connectionLost", "classjuce_1_1InterprocessConnection.html#ada0907dccbc892e525e15c76dc52a22e", null ],
    [ "messageReceived", "classjuce_1_1InterprocessConnection.html#a028fab1c8d1e18d216a00162dec65686", null ],
    [ "InterprocessConnectionServer", "classjuce_1_1InterprocessConnection.html#a4abd5c93a576aa06d7091bfa1062d572", null ]
];