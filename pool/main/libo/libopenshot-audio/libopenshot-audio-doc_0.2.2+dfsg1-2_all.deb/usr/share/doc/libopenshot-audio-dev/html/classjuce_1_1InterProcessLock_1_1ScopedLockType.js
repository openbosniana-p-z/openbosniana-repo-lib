var classjuce_1_1InterProcessLock_1_1ScopedLockType =
[
    [ "ScopedLockType", "classjuce_1_1InterProcessLock_1_1ScopedLockType.html#a51d661e7111a29dd24cf2729e0d1a0fd", null ],
    [ "~ScopedLockType", "classjuce_1_1InterProcessLock_1_1ScopedLockType.html#a7db945df2569b15abd7350ffa724c40f", null ],
    [ "isLocked", "classjuce_1_1InterProcessLock_1_1ScopedLockType.html#a45b312b414bea928a25b89b44d7ac5ed", null ]
];