var classjuce_1_1HighResolutionTimer =
[
    [ "HighResolutionTimer", "classjuce_1_1HighResolutionTimer.html#a8d746b2083189b0cfa0b4ee52cca2c6a", null ],
    [ "~HighResolutionTimer", "classjuce_1_1HighResolutionTimer.html#a08d5bf4a3ed9e6935cb1c482b3f8298e", null ],
    [ "hiResTimerCallback", "classjuce_1_1HighResolutionTimer.html#a08da0cd2cc410c8d21339b9e61ddb42a", null ],
    [ "startTimer", "classjuce_1_1HighResolutionTimer.html#aecbc2a0e7bb7774c294103dd5e068d5e", null ],
    [ "stopTimer", "classjuce_1_1HighResolutionTimer.html#aeb243f08a259aa828bedc328f561441b", null ],
    [ "isTimerRunning", "classjuce_1_1HighResolutionTimer.html#ac7d03580c6f9858c552341b79412325f", null ],
    [ "getTimerInterval", "classjuce_1_1HighResolutionTimer.html#a119d710f430f8c2d62fb650af42bbaaf", null ]
];