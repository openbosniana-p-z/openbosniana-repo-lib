/*
    Legacy include file, provided for backwards-compatibility purposes
    only. You should update your code to include <OpenShotAudio.h>
    instead of this file.

    (This comment may become a build-time warning message at some
    future date.)
*/

#pragma once
#include "./OpenShotAudio.h"

