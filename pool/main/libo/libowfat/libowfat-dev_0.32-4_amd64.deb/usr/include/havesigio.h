#define HAVE_SIGIO
