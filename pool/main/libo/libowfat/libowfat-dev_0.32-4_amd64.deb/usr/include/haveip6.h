#define LIBC_HAS_IP6
