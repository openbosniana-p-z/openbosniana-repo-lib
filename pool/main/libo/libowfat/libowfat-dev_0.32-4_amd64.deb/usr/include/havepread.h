#define HAVE_PREAD
