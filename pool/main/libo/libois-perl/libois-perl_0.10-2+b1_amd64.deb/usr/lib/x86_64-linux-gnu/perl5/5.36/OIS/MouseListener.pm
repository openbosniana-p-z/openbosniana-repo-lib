package OIS::MouseListener;

use strict;
use warnings;


1;
