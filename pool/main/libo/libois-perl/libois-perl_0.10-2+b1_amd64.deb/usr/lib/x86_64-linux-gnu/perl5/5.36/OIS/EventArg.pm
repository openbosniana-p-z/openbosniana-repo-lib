package OIS::EventArg;

use strict;
use warnings;


1;
