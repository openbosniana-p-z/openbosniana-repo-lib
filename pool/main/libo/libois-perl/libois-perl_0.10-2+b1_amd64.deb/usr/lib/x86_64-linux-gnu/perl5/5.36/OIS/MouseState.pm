package OIS::MouseState;

use strict;
use warnings;


1;
