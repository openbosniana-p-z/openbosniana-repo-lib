package OIS::JoyStickState;

use strict;
use warnings;


1;
