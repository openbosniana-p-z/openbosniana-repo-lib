package OIS::JoyStick;

use strict;
use warnings;

use OIS::Object;
our @ISA = qw(OIS::Object);


1;
