package OIS::Object;

use strict;
use warnings;


1;
