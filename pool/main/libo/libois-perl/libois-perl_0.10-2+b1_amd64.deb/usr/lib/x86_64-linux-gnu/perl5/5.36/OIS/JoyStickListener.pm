package OIS::JoyStickListener;

use strict;
use warnings;


1;
