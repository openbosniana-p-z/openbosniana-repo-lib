package OIS::JoyStickEvent;

use strict;
use warnings;

use OIS::EventArg;
our @ISA = qw(OIS::EventArg);


1;
