package OIS::Axis;

use strict;
use warnings;


1;
