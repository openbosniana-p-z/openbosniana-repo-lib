var auth_8h =
[
    [ "OSMO_A5_MAX_KEY_LEN_BYTES", "group__auth.html#ga920ad9bc59d5f523d231a30ab44c9d05", null ],
    [ "OSMO_MILENAGE_IND_BITLEN_MAX", "group__auth.html#gafd8f1d573f8d8cd5e92d75208746179d", null ],
    [ "osmo_auth_algo", "group__auth.html#ga6b9985150a3302a8a87bcf8b0a4a50d6", [
      [ "OSMO_AUTH_ALG_NONE", "group__auth.html#gga6b9985150a3302a8a87bcf8b0a4a50d6a4a5e403ae8da719772d1f7360509ffb4", null ],
      [ "OSMO_AUTH_ALG_COMP128v1", "group__auth.html#gga6b9985150a3302a8a87bcf8b0a4a50d6a590d6404406268a363252b292e8d3175", null ],
      [ "OSMO_AUTH_ALG_COMP128v2", "group__auth.html#gga6b9985150a3302a8a87bcf8b0a4a50d6a174a7ca4699743fc8a4a120f15415e45", null ],
      [ "OSMO_AUTH_ALG_COMP128v3", "group__auth.html#gga6b9985150a3302a8a87bcf8b0a4a50d6abceafcf91631fe47a55c0c1f0e18b0e6", null ],
      [ "OSMO_AUTH_ALG_XOR", "group__auth.html#gga6b9985150a3302a8a87bcf8b0a4a50d6a0dcf652a0f23ffbfe53748a5af2a93f3", null ],
      [ "OSMO_AUTH_ALG_MILENAGE", "group__auth.html#gga6b9985150a3302a8a87bcf8b0a4a50d6af5b18c6ef6b3603c4765c69242d3f254", null ],
      [ "_OSMO_AUTH_ALG_NUM", "group__auth.html#gga6b9985150a3302a8a87bcf8b0a4a50d6af14ebc6a77122a1daaf26d2c80fb61dc", null ]
    ] ],
    [ "osmo_sub_auth_type", "group__auth.html#gaaa361da6317c3adf1e53fb6a0325d0ff", [
      [ "OSMO_AUTH_TYPE_NONE", "group__auth.html#ggaaa361da6317c3adf1e53fb6a0325d0ffabff665a821365f0bd09cf607bb82e052", null ],
      [ "OSMO_AUTH_TYPE_GSM", "group__auth.html#ggaaa361da6317c3adf1e53fb6a0325d0ffa57327f1d68fc641f0e59d2332dd1c79a", null ],
      [ "OSMO_AUTH_TYPE_UMTS", "group__auth.html#ggaaa361da6317c3adf1e53fb6a0325d0ffa03c804f89981374b573a0719536cdd09", null ]
    ] ],
    [ "osmo_auth_alg_name", "group__auth.html#ga994867cd1aa5e9a614ee2f41a3607791", null ],
    [ "osmo_auth_alg_parse", "group__auth.html#ga5ba41b4cabb7b1bad0a8a1d8425a07ea", null ],
    [ "osmo_auth_c3", "group__auth.html#ga5cc1d918b10f6b7dd52360f2a1910dba", null ],
    [ "osmo_auth_gen_vec", "group__auth.html#ga0ec223fc54378e524c919349a7386a01", null ],
    [ "osmo_auth_gen_vec_auts", "group__auth.html#gaad42c206b8d9ba81752aee3aae5d6d5f", null ],
    [ "osmo_auth_load", "group__auth.html#ga83e136ee2ee55df7fcb4bc2721c83aa0", null ],
    [ "osmo_auth_register", "group__auth.html#ga03ac5ccce18a8af0c4d0fc524f52033e", null ],
    [ "osmo_auth_supported", "group__auth.html#ga0a0f74a4d32f663db22b58b6de75a9ac", null ],
    [ "osmo_c4", "group__auth.html#gaa651ab6eb7e2a9a83c6e0810f05edc88", null ],
    [ "osmo_sub_auth_type_name", "group__auth.html#ga0db36ada5479c06f370184fe331032f0", null ],
    [ "osmo_sub_auth_type_names", "group__auth.html#ga96657fe49eca98e1ae04cbf9aceea3d0", null ]
];