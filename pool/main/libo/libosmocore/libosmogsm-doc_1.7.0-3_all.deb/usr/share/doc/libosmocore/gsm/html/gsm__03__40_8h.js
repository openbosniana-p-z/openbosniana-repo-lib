var gsm__03__40_8h =
[
    [ "GSM340_UDL_OCT_MAX", "gsm__03__40_8h.html#a1dd42def7ecd073814a846671619fd7c", null ],
    [ "GSM340_UDL_SPT_MAX", "gsm__03__40_8h.html#abc17ece3b24fddd066aaf054f2debdad", null ]
];