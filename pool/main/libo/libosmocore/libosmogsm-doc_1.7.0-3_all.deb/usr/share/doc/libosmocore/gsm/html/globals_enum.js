var globals_enum =
[
    [ "a", "globals_enum.html", null ],
    [ "b", "globals_enum_b.html", null ],
    [ "c", "globals_enum_c.html", null ],
    [ "g", "globals_enum_g.html", null ],
    [ "i", "globals_enum_i.html", null ],
    [ "l", "globals_enum_l.html", null ],
    [ "m", "globals_enum_m.html", null ],
    [ "o", "globals_enum_o.html", null ],
    [ "p", "globals_enum_p.html", null ],
    [ "r", "globals_enum_r.html", null ],
    [ "s", "globals_enum_s.html", null ],
    [ "t", "globals_enum_t.html", null ]
];