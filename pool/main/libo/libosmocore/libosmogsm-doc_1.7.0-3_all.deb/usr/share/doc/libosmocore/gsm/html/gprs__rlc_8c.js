var gprs__rlc_8c =
[
    [ "gprs_cs_desc", "structgprs__cs__desc.html", "structgprs__cs__desc" ],
    [ "EGPRS_CPS_TYPE1_TBL_SZ", "gprs__rlc_8c.html#add140e6799e7eb2f0f66324a5175a9a2", null ],
    [ "EGPRS_CPS_TYPE2_TBL_SZ", "gprs__rlc_8c.html#ae5b9d53b1334245ec638f86fbc6abf20", null ],
    [ "EGPRS_CPS_TYPE3_TBL_SZ", "gprs__rlc_8c.html#a5fb1586488873cc8df03d4beacd43005", null ],
    [ "egprs_get_cps", "gprs__rlc_8c.html#a04590cac736a29f76fea4b9503bbf1fe", null ],
    [ "osmo_gprs_dl_block_size_bits", "gprs__rlc_8c.html#ac0b2f3a41e9874e5074b4f29ae987caf", null ],
    [ "osmo_gprs_dl_block_size_bytes", "gprs__rlc_8c.html#af055f7f89f53cb054f9b6c3433642ca6", null ],
    [ "osmo_gprs_dl_cs_by_block_bytes", "gprs__rlc_8c.html#a8133c5f5101a21ca5debc0fb7534b750", null ],
    [ "osmo_gprs_ul_block_size_bits", "gprs__rlc_8c.html#a0580dc84205412e51e93c765544acc78", null ],
    [ "osmo_gprs_ul_block_size_bytes", "gprs__rlc_8c.html#a71e7c0cb4eee33bc7e4565f4471de3f5", null ],
    [ "osmo_gprs_ul_cs_by_block_bytes", "gprs__rlc_8c.html#a89d80e4e90cc4a074f90b9c0cbc15008", null ],
    [ "egprs_cps_table_type1", "gprs__rlc_8c.html#ab6f7ad9afc32155a67f970ad03bdd4fd", null ],
    [ "egprs_cps_table_type2", "gprs__rlc_8c.html#a7652091c7ebea2eb3e2ee2aa51f73ade", null ],
    [ "egprs_cps_table_type3", "gprs__rlc_8c.html#a1fc61b915c3313bf87eb4a4adcaf43df", null ],
    [ "gprs_cs_desc", "gprs__rlc_8c.html#a2568894b71f6a618df6d91ba2311be15", null ]
];