var gsm48__arfcn__range__encode_8h =
[
    [ "OSMO_GSM48_RANGE_ENC_MAX_ARFCNS", "gsm48__arfcn__range__encode_8h.html#a3bfd46424e2704131defc952272301d7", null ],
    [ "osmo_gsm48_range", "gsm48__arfcn__range__encode_8h.html#a1bf10bb9d7e8ba79767bf141ca420777", [
      [ "OSMO_GSM48_ARFCN_RANGE_INVALID", "gsm48__arfcn__range__encode_8h.html#a1bf10bb9d7e8ba79767bf141ca420777a107d57aa19c69ac977be705043baf33e", null ],
      [ "OSMO_GSM48_ARFCN_RANGE_128", "gsm48__arfcn__range__encode_8h.html#a1bf10bb9d7e8ba79767bf141ca420777a3f7fcda0f3a4248b06087a5a571a9d15", null ],
      [ "OSMO_GSM48_ARFCN_RANGE_256", "gsm48__arfcn__range__encode_8h.html#a1bf10bb9d7e8ba79767bf141ca420777a5c24e4741c92bd79b858ded98e9d43f4", null ],
      [ "OSMO_GSM48_ARFCN_RANGE_512", "gsm48__arfcn__range__encode_8h.html#a1bf10bb9d7e8ba79767bf141ca420777ac94ac2253cd3b058daf3d32c8b99bd09", null ],
      [ "OSMO_GSM48_ARFCN_RANGE_1024", "gsm48__arfcn__range__encode_8h.html#a1bf10bb9d7e8ba79767bf141ca420777a092688ac8ee914a2a312417195b9eb16", null ]
    ] ],
    [ "osmo_gsm48_range_enc_1024", "gsm48__arfcn__range__encode_8h.html#a2673dcfead831fd420d5bbc5f0b3b3b8", null ],
    [ "osmo_gsm48_range_enc_128", "gsm48__arfcn__range__encode_8h.html#a6d9a7c982386b4ee5c6d35a7024f190c", null ],
    [ "osmo_gsm48_range_enc_256", "gsm48__arfcn__range__encode_8h.html#aed2cdbc388075b6ccb28a621d18b9a3c", null ],
    [ "osmo_gsm48_range_enc_512", "gsm48__arfcn__range__encode_8h.html#a4f830c03682612b8245be84fb1e11832", null ],
    [ "osmo_gsm48_range_enc_arfcns", "gsm48__arfcn__range__encode_8h.html#a55063b8daa287ef3d93e7ed674028d20", null ],
    [ "osmo_gsm48_range_enc_determine_range", "gsm48__arfcn__range__encode_8h.html#ae599d5450ead96df515efce6ade5dda2", null ],
    [ "osmo_gsm48_range_enc_filter_arfcns", "gsm48__arfcn__range__encode_8h.html#ae3d9290d7db3d20151d6ab751089fd3e", null ],
    [ "osmo_gsm48_range_enc_find_index", "gsm48__arfcn__range__encode_8h.html#ad05f36203e4c9891781263fec923e8c3", null ]
];