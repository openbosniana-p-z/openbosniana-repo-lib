var auth__xor_8c =
[
    [ "__attribute__", "auth__xor_8c.html#ga9ed16867a9394d9ccf1132194edae298", null ],
    [ "xor", "group__auth.html#gadb81629f87414226ac80a55cfc52f0a1", null ],
    [ "xor_gen_vec", "group__auth.html#gab6e4f202062b217a0c19ef8cab9de142", null ],
    [ "xor_gen_vec_auts", "group__auth.html#ga178be8d2925e97b918c5c56085c436d9", null ],
    [ "xor_alg", "group__auth.html#gadcedd117ca6eb4785411f43b74a81933", null ]
];