var group__prim =
[
    [ "osmo_prim_cb", "../../core/html/group__prim.html#gab56d32c84797be881ccafdebe4b78b2a", null ],
    [ "osmo_prim_operation", "../../core/html/group__prim.html#ga5bd3196233677c8e9ab66b6fb97060d3", null ],
    [ "osmo_event_for_prim", "../../core/html/group__prim.html#ga65cffc8b84a2c3d2f200560096810695", null ],
    [ "osmo_prim_init", "../../core/html/group__prim.html#gaf826713c118d129aff1a700a742552c4", null ],
    [ "osmo_prim_op_names", "../../core/html/group__prim.html#ga886b7582fd2947d0582cd8c9acd30cc9", null ],
    [ "osmo_prim_op_names", "../../core/html/group__prim.html#ga886b7582fd2947d0582cd8c9acd30cc9", null ],
    [ "PRIM_OP_CONFIRM", "../../core/html/group__prim.html#gga5bd3196233677c8e9ab66b6fb97060d3aee86a39134232ad0417a13ef1f8e53bf", null ],
    [ "PRIM_OP_INDICATION", "../../core/html/group__prim.html#gga5bd3196233677c8e9ab66b6fb97060d3a6987bf8560df352ada9979b4457f9f0d", null ],
    [ "PRIM_OP_REQUEST", "../../core/html/group__prim.html#gga5bd3196233677c8e9ab66b6fb97060d3aef3a9ebe139f54ca2c1dae8b65c6880e", null ],
    [ "PRIM_OP_RESPONSE", "../../core/html/group__prim.html#gga5bd3196233677c8e9ab66b6fb97060d3af62503bb7df5fde38f9359b591028dc1", null ]
];