var gsm23236_8h =
[
    [ "osmo_nri_range", "structosmo__nri__range.html", "structosmo__nri__range" ],
    [ "osmo_nri_ranges", "structosmo__nri__ranges.html", "structosmo__nri__ranges" ],
    [ "OSMO_NRI_BITLEN_DEFAULT", "gsm23236_8h.html#a0dc1ab9d89f5d484d595a1aa4da5d825", null ],
    [ "OSMO_NRI_BITLEN_MAX", "gsm23236_8h.html#a55d55f0d24b5274fa14a32358bc301a1", null ],
    [ "OSMO_NRI_BITLEN_MIN", "gsm23236_8h.html#a7ba0d3eaaa6f3eaff64b9f2a8ee60ddb", null ],
    [ "osmo_nri_range_overlaps_ranges", "gsm23236_8h.html#ab6dd4caf3147f415ddb072b6f412c226", null ],
    [ "osmo_nri_range_validate", "gsm23236_8h.html#a4524a76b894d3129cf94ef016cc13e6d", null ],
    [ "osmo_nri_ranges_add", "gsm23236_8h.html#a605dcaa480dba2b8135bff334819d453", null ],
    [ "osmo_nri_ranges_alloc", "gsm23236_8h.html#a25fc6a315a7c0479c71b19328f6698d3", null ],
    [ "osmo_nri_ranges_del", "gsm23236_8h.html#a433f2867aba1e9f03dd407e30d7f0b65", null ],
    [ "osmo_nri_ranges_free", "gsm23236_8h.html#a0177e18f2ed4b792210c59333f55af2e", null ],
    [ "osmo_nri_ranges_to_str_buf", "gsm23236_8h.html#aeb03020d6d17390122c1b913e86053c4", null ],
    [ "osmo_nri_ranges_to_str_c", "gsm23236_8h.html#a06560b8d90d3904eabfdb5e1ca1a0ff2", null ],
    [ "osmo_nri_ranges_vty_add", "gsm23236_8h.html#a4e0174de83a9cf340571419c755c339a", null ],
    [ "osmo_nri_ranges_vty_del", "gsm23236_8h.html#a86c40de8e3ec5064b89c54f147c2b398", null ],
    [ "osmo_nri_v_limit_by_ranges", "gsm23236_8h.html#a58aa2e811837ad9fb904cdd4e223a8c7", null ],
    [ "osmo_nri_v_matches_ranges", "gsm23236_8h.html#a1ff484c82f1ed8ee84d796ad9d7fd004", null ],
    [ "osmo_nri_v_validate", "gsm23236_8h.html#a1df8435960195ebaaa8b67ad1d610a4a", null ],
    [ "osmo_tmsi_nri_v_get", "gsm23236_8h.html#a4de786786e11c95ff0a44264caf4a390", null ],
    [ "osmo_tmsi_nri_v_limit_by_ranges", "gsm23236_8h.html#a2e354a0d091dd1836ab3243cf577bf9e", null ],
    [ "osmo_tmsi_nri_v_set", "gsm23236_8h.html#ac3a197fdc119b7011edaa1dc04f0056f", null ]
];