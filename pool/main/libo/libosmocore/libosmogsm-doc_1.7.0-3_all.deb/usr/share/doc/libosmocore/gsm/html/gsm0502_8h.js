var gsm0502_8h =
[
    [ "GSM_TDMA_FN_DEC", "gsm0502_8h.html#acecae8d917ab65897e3ce56eb9eaa081", null ],
    [ "GSM_TDMA_FN_DIFF", "gsm0502_8h.html#ae547fa7a74c56e2419e67d17fbec9d33", null ],
    [ "GSM_TDMA_FN_DURATION_nS", "gsm0502_8h.html#ac887542d15833e0c32b7c32c0fbf1ba4", null ],
    [ "GSM_TDMA_FN_DURATION_uS", "gsm0502_8h.html#ab5e2c3e9f3b7b9b1a83caa886300442b", null ],
    [ "GSM_TDMA_FN_INC", "gsm0502_8h.html#a777e5c9d1dac944756f4ac0bfe2fa788", null ],
    [ "GSM_TDMA_FN_SUB", "gsm0502_8h.html#aeddaa54dbb6da8bad80f3216f97ebff6", null ],
    [ "GSM_TDMA_FN_SUM", "gsm0502_8h.html#a6bd355ae619d158d7ba5b94220451c88", null ],
    [ "GSM_TDMA_HYPERFRAME", "gsm0502_8h.html#a4bb537489c920031aa68b900fc6c22b6", null ],
    [ "GSM_TDMA_SUPERFRAME", "gsm0502_8h.html#a7620502184bdcf66991b48d35d7caa5b", null ],
    [ "gsm0502_fn_remap_channel", "gsm0502_8h.html#afc789b32e825ea46f9f64b26a27d69d0", [
      [ "FN_REMAP_TCH_F", "gsm0502_8h.html#afc789b32e825ea46f9f64b26a27d69d0af44d065cadcf8019451d4019f7e5b5fa", null ],
      [ "FN_REMAP_TCH_H0", "gsm0502_8h.html#afc789b32e825ea46f9f64b26a27d69d0a34678c8c9b52a86d81a24fa91ab9f45e", null ],
      [ "FN_REMAP_TCH_H1", "gsm0502_8h.html#afc789b32e825ea46f9f64b26a27d69d0a62ee275e8cda45534c6a7f1489971f0b", null ],
      [ "FN_REMAP_FACCH_F", "gsm0502_8h.html#afc789b32e825ea46f9f64b26a27d69d0a8d35c98a8c8628c3e726b0c647602a85", null ],
      [ "FN_REMAP_FACCH_H0", "gsm0502_8h.html#afc789b32e825ea46f9f64b26a27d69d0afad0049a2d8eb2275ec4de82b400400a", null ],
      [ "FN_REMAP_FACCH_H1", "gsm0502_8h.html#afc789b32e825ea46f9f64b26a27d69d0ab1d4b8cd2494ed0c99eebf58be43fb63", null ],
      [ "FN_REMAP_MAX", "gsm0502_8h.html#afc789b32e825ea46f9f64b26a27d69d0a8cf036be4db56e738771b93182f09c1d", null ]
    ] ],
    [ "gsm0502_calc_paging_group", "gsm0502_8h.html#ad7e70717786ddec5819e92ab79092a46", null ],
    [ "gsm0502_fn_remap", "gsm0502_8h.html#a24c46c3885d7d2b9bc677d881253c7b7", null ],
    [ "gsm0502_get_ccch_group", "gsm0502_8h.html#a040a01460e71074c26c74d43b6f9c6b8", null ],
    [ "gsm0502_get_n_pag_blocks", "gsm0502_8h.html#afca12b3b6dcc08594b9692f92cdb5a8b", null ],
    [ "gsm0502_get_paging_group", "gsm0502_8h.html#a52ba9a45e51cfacb5276338f5c315e6b", null ],
    [ "gsm0502_hop_seq_gen", "gsm0502_8h.html#a8697893506f494bd492fe71b8a7e5ab3", null ]
];