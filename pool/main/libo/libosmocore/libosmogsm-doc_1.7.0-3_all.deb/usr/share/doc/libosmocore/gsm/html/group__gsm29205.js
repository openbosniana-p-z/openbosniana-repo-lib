var group__gsm29205 =
[
    [ "gsm29205.h", "gsm29205_8h.html", null ],
    [ "gsm29205.c", "gsm29205_8c.html", null ],
    [ "osmo_gcr_parsed", "structosmo__gcr__parsed.html", [
      [ "cr", "group__gsm29205.html#ga198d8498401b81d3a8403ae618502a9f", null ],
      [ "net", "group__gsm29205.html#gaf8cc803881155e730cd3dee0e03395b1", null ],
      [ "net_len", "group__gsm29205.html#gaaee6729627e9f5a416f8129de6430d43", null ],
      [ "node", "group__gsm29205.html#gac2362d86dddc8167f66fac38eec3247a", null ]
    ] ],
    [ "OSMO_GCR_MIN_LEN", "group__gsm29205.html#gaca9fada0867882e65ce3165e5d463cd1", null ],
    [ "osmo_dec_gcr", "group__gsm29205.html#ga41e5de0228f66e7ea43b253af26efef0", null ],
    [ "osmo_enc_gcr", "group__gsm29205.html#ga1387d926bea7cb69ca41814bf20f6b29", null ],
    [ "osmo_gcr_eq", "group__gsm29205.html#ga9a29f24e0da01e4894097fef93c0c6d9", null ],
    [ "osmo_gcr_parsed::cr", "group__gsm29205.html#ga198d8498401b81d3a8403ae618502a9f", null ],
    [ "osmo_gcr_parsed::net", "group__gsm29205.html#gaf8cc803881155e730cd3dee0e03395b1", null ],
    [ "osmo_gcr_parsed::net_len", "group__gsm29205.html#gaaee6729627e9f5a416f8129de6430d43", null ],
    [ "osmo_gcr_parsed::node", "group__gsm29205.html#gac2362d86dddc8167f66fac38eec3247a", null ]
];