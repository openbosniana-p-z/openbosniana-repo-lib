var group__Tdef =
[
    [ "osmo_tdef_unit", "../../core/html/group__Tdef.html#gaab870deed1871d59911bcd465b410f6a", null ],
    [ "_osmo_tdef_fsm_inst_state_chg", "../../core/html/group__Tdef.html#ga0f528b78c3b8875971f0fcbbaa52e1c6", null ],
    [ "_osmo_tdef_fsm_inst_state_chg", "../../core/html/group__Tdef.html#ga0949811a3638747d3ba5fc2eeba9b94c", null ],
    [ "osmo_tdef_factor", "../../core/html/group__Tdef.html#gae2c06fad8c067d3ae2d6ebbaa133e070", null ],
    [ "osmo_tdef_get", "../../core/html/group__Tdef.html#ga1902036c8ce361a6ba043b90f3026ae7", null ],
    [ "osmo_tdef_get_entry", "../../core/html/group__Tdef.html#ga165520a7b18876662703753759941e00", null ],
    [ "osmo_tdef_get_state_timeout", "../../core/html/group__Tdef.html#ga5a7532bad13a88526390b8f3c6db3374", null ],
    [ "osmo_tdef_range_str_buf", "../../core/html/group__Tdef.html#ga88e3725d03ea8ab0edf8013333dfedad", null ],
    [ "osmo_tdef_round", "../../core/html/group__Tdef.html#ga95e55c67fc577ce73009b70f1a3c432b", null ],
    [ "osmo_tdef_set", "../../core/html/group__Tdef.html#gab2f59867f10a781019db1d52c991ce95", null ],
    [ "osmo_tdef_unit_name", "../../core/html/group__Tdef.html#ga0625620798fea884f7a63efbc58defd1", null ],
    [ "osmo_tdef_val_in_range", "../../core/html/group__Tdef.html#ga4b9908c0c45f1226f4fae760141d54b4", null ],
    [ "osmo_tdefs_reset", "../../core/html/group__Tdef.html#ga0a2cda1d30e23023cc179b68b8c624e6", null ],
    [ "OSMO_TDEF_CUSTOM", "../../core/html/group__Tdef.html#ggaab870deed1871d59911bcd465b410f6aa12615b1124e5e25e0a0ad4e5b13adef5", null ],
    [ "OSMO_TDEF_M", "../../core/html/group__Tdef.html#ggaab870deed1871d59911bcd465b410f6aa757bb613b8f209d4d9e0c2d6622e06bc", null ],
    [ "OSMO_TDEF_MS", "../../core/html/group__Tdef.html#ggaab870deed1871d59911bcd465b410f6aae9571204a5e1dc1b575f94c11bc47474", null ],
    [ "OSMO_TDEF_S", "../../core/html/group__Tdef.html#ggaab870deed1871d59911bcd465b410f6aacd7acf38bfb806b297369d3967b8151d", null ],
    [ "osmo_tdef_unit_names", "../../core/html/group__Tdef.html#ga4ad5be5f9d49274b4bce18320cf251b5", null ],
    [ "osmo_tdef_unit_names", "../../core/html/group__Tdef.html#ga4ad5be5f9d49274b4bce18320cf251b5", null ],
    [ "OSMO_TDEF_US", "../../core/html/group__Tdef.html#ggaab870deed1871d59911bcd465b410f6aa4cf1495f9310e61a17527be25486e4cc", null ]
];