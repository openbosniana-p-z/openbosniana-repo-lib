var group__write__queue =
[
    [ "osmo_wqueue_bfd_cb", "../../core/html/group__write__queue.html#ga56bb1b9d13a946be09fdbf400545d7ad", null ],
    [ "osmo_wqueue_clear", "../../core/html/group__write__queue.html#ga833b4f5244c00c775260a83e9918073c", null ],
    [ "osmo_wqueue_enqueue", "../../core/html/group__write__queue.html#ga9855de966a4f01d6df3a747422b02824", null ],
    [ "osmo_wqueue_enqueue_quiet", "../../core/html/group__write__queue.html#ga7d4207497c2a2852f98ecf805424a504", null ],
    [ "osmo_wqueue_init", "../../core/html/group__write__queue.html#gacca6343dd66b8cac8a5055b2a16eb990", null ]
];