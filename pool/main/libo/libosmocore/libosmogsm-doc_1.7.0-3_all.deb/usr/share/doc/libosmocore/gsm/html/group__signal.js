var group__signal =
[
    [ "osmo_signal_cbfn", "../../core/html/group__signal.html#gae1e33b4b31b9aa6d224de68053dcb1ce", null ],
    [ "LLIST_HEAD", "../../core/html/group__signal.html#gaa46f0e38b6dcdd49627b6d171d51e9c5", null ],
    [ "osmo_signal_dispatch", "../../core/html/group__signal.html#ga8eb0fdf74d9ae54383b10cb88792a008", null ],
    [ "osmo_signal_register_handler", "../../core/html/group__signal.html#ga34e5e27e85ffdaa63744cf9e97468807", null ],
    [ "osmo_signal_talloc_ctx_init", "../../core/html/group__signal.html#gacbbc59427aa2fd838becc61d3443ca44", null ],
    [ "osmo_signal_unregister_handler", "../../core/html/group__signal.html#ga62da9d737e40883ac0d15b7b3bc049fb", null ],
    [ "S_L_GLOBAL_SHUTDOWN", "../../core/html/group__signal.html#ggaae05225933a42f81e7c4a9fb286596f9a4332cdc80e697a91f1f95b89b59216be", null ],
    [ "SS_L_GLOBAL", "../../core/html/group__signal.html#ggadb49720dc49f7d4e4cf9adbf2948e409a1c16e247915ba903f0b15dd21f33f924", null ],
    [ "SS_L_INPUT", "../../core/html/group__signal.html#ggadb49720dc49f7d4e4cf9adbf2948e409a0f74e71436faadd50e466563f7f5fabd", null ],
    [ "SS_L_NS", "../../core/html/group__signal.html#ggadb49720dc49f7d4e4cf9adbf2948e409aea1b3aaafcf5689c71b9db0e2db8ab7d", null ],
    [ "SS_L_VTY", "../../core/html/group__signal.html#ggadb49720dc49f7d4e4cf9adbf2948e409a3b46c605181dbc6523c86e9e66b76004", null ],
    [ "tall_sigh_ctx", "../../core/html/group__signal.html#ga2dd2b6ac5a7a35b5c834ccf82361e39b", null ]
];