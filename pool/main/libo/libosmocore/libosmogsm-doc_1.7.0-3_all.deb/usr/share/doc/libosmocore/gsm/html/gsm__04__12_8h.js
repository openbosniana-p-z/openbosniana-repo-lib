var gsm__04__12_8h =
[
    [ "gsm412_block_type", "structgsm412__block__type.html", null ],
    [ "gsm412_sched_msg", "structgsm412__sched__msg.html", null ],
    [ "GSM412_BLOCK_LEN", "gsm__04__12_8h.html#a3bb7f25d9feba1de275e4682a2cd1e5c", null ],
    [ "GSM412_MSG_LEN", "gsm__04__12_8h.html#ac8c17102e0b83e64cd3cd7fac522ae03", null ],
    [ "GSM412_SEQ_FST_BLOCK", "gsm__04__12_8h.html#ae105487a5689e15be1eff50cff8e967f", null ],
    [ "GSM412_SEQ_FST_SCHED_BLOCK", "gsm__04__12_8h.html#a004d5a28da23b304875a8e4721ffe252", null ],
    [ "GSM412_SEQ_FTH_BLOCK", "gsm__04__12_8h.html#a0303a9c6a9c5560868f718bfa4d98c66", null ],
    [ "GSM412_SEQ_NULL_MSG", "gsm__04__12_8h.html#a898992c2ef60fe374aa080373ab2cd84", null ],
    [ "GSM412_SEQ_SND_BLOCK", "gsm__04__12_8h.html#a20e85a794005fc5cf592bfc3fc299f3c", null ],
    [ "GSM412_SEQ_TRD_BLOCK", "gsm__04__12_8h.html#a6a3957b8c1305be9daafd17bf18a24dd", null ]
];