var group__oap =
[
    [ "oap.h", "oap_8h.html", null ],
    [ "oap.c", "oap_8c.html", null ],
    [ "osmo_oap_message", "structosmo__oap__message.html", [
      [ "autn", "structosmo__oap__message.html#adab4ffa7c3fc663943068d3d91b17e76", null ],
      [ "autn_present", "structosmo__oap__message.html#a097b7789b7db17a0cf7c94f92e591af1", null ],
      [ "auts", "structosmo__oap__message.html#a40ba43fbbccdbd0cfdd5aceb21a775cf", null ],
      [ "auts_present", "structosmo__oap__message.html#a0c0714762493271f246163cce39b39dc", null ],
      [ "cause", "structosmo__oap__message.html#a6f7f7696422936deed1474a4cd40e837", null ],
      [ "client_id", "structosmo__oap__message.html#a3b440d55a5d1a425e35fc5f7dce8138d", null ],
      [ "message_type", "structosmo__oap__message.html#a49b9fb494e5302813e850f338d6b6b10", null ],
      [ "rand", "structosmo__oap__message.html#a465ab121f5eed63839dcefe411266831", null ],
      [ "rand_present", "structosmo__oap__message.html#a3255202340ad70a65a00d1343b8b895e", null ],
      [ "xres", "structosmo__oap__message.html#a5774a3ca9b5e56dcc3806c4d6699e8ab", null ],
      [ "xres_present", "structosmo__oap__message.html#aad054c448d92be21651a581368fbe416", null ]
    ] ],
    [ "osmo_oap_iei", "group__oap.html#ga199836e7d38fdcdcb8bbe2cfd1e75f34", [
      [ "OAP_CAUSE_IE", "group__oap.html#gga199836e7d38fdcdcb8bbe2cfd1e75f34adb489e66c55e9a116b4f55b764d4f0d4", null ],
      [ "OAP_RAND_IE", "group__oap.html#gga199836e7d38fdcdcb8bbe2cfd1e75f34a37700bdd7a0493cc55e594511b477b05", null ],
      [ "OAP_AUTN_IE", "group__oap.html#gga199836e7d38fdcdcb8bbe2cfd1e75f34abed0f5656e0c26e77bf2ffc7e2b0830a", null ],
      [ "OAP_XRES_IE", "group__oap.html#gga199836e7d38fdcdcb8bbe2cfd1e75f34a6fa1b12bad14f2038a5099e77824c1b1", null ],
      [ "OAP_AUTS_IE", "group__oap.html#gga199836e7d38fdcdcb8bbe2cfd1e75f34ada5bdbb9960314d29e8989754e5d42f3", null ],
      [ "OAP_CLIENT_ID_IE", "group__oap.html#gga199836e7d38fdcdcb8bbe2cfd1e75f34ab72885a73db5b74f48681a28e47e1362", null ]
    ] ],
    [ "osmo_oap_message_type", "group__oap.html#ga833e8a5b20c7cfe0d598919cab5f306c", [
      [ "OAP_MSGT_REGISTER_REQUEST", "group__oap.html#gga833e8a5b20c7cfe0d598919cab5f306ca461cb5ec879eb717e5022cdf005d6101", null ],
      [ "OAP_MSGT_REGISTER_ERROR", "group__oap.html#gga833e8a5b20c7cfe0d598919cab5f306ca1d9713fd62b55feae58f65c9a691ba88", null ],
      [ "OAP_MSGT_REGISTER_RESULT", "group__oap.html#gga833e8a5b20c7cfe0d598919cab5f306ca65ba13da2b8e25df21936877f7752e04", null ],
      [ "OAP_MSGT_CHALLENGE_REQUEST", "group__oap.html#gga833e8a5b20c7cfe0d598919cab5f306ca73f09c47880fc2ed5817fe6e7b829a1c", null ],
      [ "OAP_MSGT_CHALLENGE_ERROR", "group__oap.html#gga833e8a5b20c7cfe0d598919cab5f306ca6965ad01cf797e51273f7ce508009c3b", null ],
      [ "OAP_MSGT_CHALLENGE_RESULT", "group__oap.html#gga833e8a5b20c7cfe0d598919cab5f306ca928cbc2658fb690880fdc0a42196f344", null ],
      [ "OAP_MSGT_SYNC_REQUEST", "group__oap.html#gga833e8a5b20c7cfe0d598919cab5f306ca583404fe32d0b48e97bfd2fd04fa3899", null ],
      [ "OAP_MSGT_SYNC_ERROR", "group__oap.html#gga833e8a5b20c7cfe0d598919cab5f306ca4ff868f2b357649cf95cbd655b8a7735", null ],
      [ "OAP_MSGT_SYNC_RESULT", "group__oap.html#gga833e8a5b20c7cfe0d598919cab5f306ca606577dd37ee117f8022baf1fd94a00d", null ]
    ] ],
    [ "osmo_oap_decode", "group__oap.html#gac188809245237da8d619cfe9df98ff0b", null ],
    [ "osmo_oap_encode", "group__oap.html#ga949f5c2430f44f354d09c3387e61046a", null ]
];