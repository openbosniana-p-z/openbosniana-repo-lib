var gan_8c =
[
    [ "gan_msgt_vals", "gan_8c.html#ae494ce45c5092c6e2de7bc0898ad401f", null ],
    [ "gan_pdisc_vals", "gan_8c.html#a8c618c1d65c4c1974dfa0a0706501680", null ]
];