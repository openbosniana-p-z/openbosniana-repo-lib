var group__gad =
[
    [ "gad.h", "gad_8h.html", null ],
    [ "gsm_23_032.h", "gsm__23__032_8h.html", null ],
    [ "gad.c", "gad_8c.html", null ],
    [ "osmo_gad_ell_point", "structosmo__gad__ell__point.html", [
      [ "lat", "structosmo__gad__ell__point.html#a8075ba44d422a864e91130838aae53df", null ],
      [ "lon", "structosmo__gad__ell__point.html#a2e3c406f48c2d47cf5e7b3beb4bd85f0", null ]
    ] ],
    [ "osmo_gad_ell_point_unc_circle", "structosmo__gad__ell__point__unc__circle.html", [
      [ "lat", "structosmo__gad__ell__point__unc__circle.html#aa7b0a6d9609e64ad04b88d0ce6aadd46", null ],
      [ "lon", "structosmo__gad__ell__point__unc__circle.html#a58431e41aa1bbba308084f29688977ae", null ],
      [ "unc", "structosmo__gad__ell__point__unc__circle.html#a73dae7f92cc51d67b71c7d054201635f", null ]
    ] ],
    [ "osmo_gad_ell_point_unc_ellipse", "structosmo__gad__ell__point__unc__ellipse.html", [
      [ "confidence", "structosmo__gad__ell__point__unc__ellipse.html#afe96fe4e37acefb68704c0331e46fe0a", null ],
      [ "lat", "structosmo__gad__ell__point__unc__ellipse.html#aabac9313bd4e313a82d0bf1593eb758c", null ],
      [ "lon", "structosmo__gad__ell__point__unc__ellipse.html#a403b85314c4e723105e2042ec7b93149", null ],
      [ "major_ori", "structosmo__gad__ell__point__unc__ellipse.html#ac1d5d66789a962b80c5be665fbccde68", null ],
      [ "unc_semi_major", "structosmo__gad__ell__point__unc__ellipse.html#ac7c922116de7c1ec294c0394201628fb", null ],
      [ "unc_semi_minor", "structosmo__gad__ell__point__unc__ellipse.html#aad7c9fb8bd51e2dac2918e94bcdd87ac", null ]
    ] ],
    [ "osmo_gad_polygon", "structosmo__gad__polygon.html", [
      [ "num_points", "structosmo__gad__polygon.html#a6eac03df155c50b30ae0d02fa716c8d7", null ],
      [ "point", "structosmo__gad__polygon.html#a30051f9e1ead24b18c29233da62d4218", null ]
    ] ],
    [ "osmo_gad_ell_point_alt", "structosmo__gad__ell__point__alt.html", [
      [ "alt", "structosmo__gad__ell__point__alt.html#aa77520c5451e9c13c2b65e015ffda116", null ],
      [ "lat", "structosmo__gad__ell__point__alt.html#a7be7a58498a718870825fec0bc4d6910", null ],
      [ "lon", "structosmo__gad__ell__point__alt.html#ad62f433d8252ebcf781cbd5311d4c753", null ]
    ] ],
    [ "osmo_gad_ell_point_alt_unc_ell", "structosmo__gad__ell__point__alt__unc__ell.html", [
      [ "alt", "structosmo__gad__ell__point__alt__unc__ell.html#a4326890f7ba07490956c97fe983f48ba", null ],
      [ "confidence", "structosmo__gad__ell__point__alt__unc__ell.html#a7a328687377293d410002733e734823c", null ],
      [ "lat", "structosmo__gad__ell__point__alt__unc__ell.html#a6562636907736107ecc23a991c2a07ce", null ],
      [ "lon", "structosmo__gad__ell__point__alt__unc__ell.html#a543d8016e530b64d81f159a13f68dcba", null ],
      [ "major_ori", "structosmo__gad__ell__point__alt__unc__ell.html#a1bbfe3d75b2f6f0012501c7cf2d6d7cf", null ],
      [ "unc_alt", "structosmo__gad__ell__point__alt__unc__ell.html#ad20972e3630346dddf38416436258416", null ],
      [ "unc_semi_major", "structosmo__gad__ell__point__alt__unc__ell.html#a36aae49c7c81eb766e9590b3ca543ca9", null ],
      [ "unc_semi_minor", "structosmo__gad__ell__point__alt__unc__ell.html#a84f00edf1f9897871e2f5ea4d653e69a", null ]
    ] ],
    [ "osmo_gad_ell_arc", "structosmo__gad__ell__arc.html", [
      [ "confidence", "structosmo__gad__ell__arc.html#a6b9b3b296a1578ab925c7fb0fac68058", null ],
      [ "incl_angle", "structosmo__gad__ell__arc.html#ae95e89e6838bc2153ba8efbc45ab7e02", null ],
      [ "inner_r", "structosmo__gad__ell__arc.html#adbbf330d68a6ba15a74f686781d19fdc", null ],
      [ "lat", "structosmo__gad__ell__arc.html#a843e657d989852f18863fc3a56729641", null ],
      [ "lon", "structosmo__gad__ell__arc.html#abb328722fff32bf55d8f84596e086da8", null ],
      [ "ofs_angle", "structosmo__gad__ell__arc.html#a48994910e4f32080f72c6e778a560f67", null ],
      [ "unc_r", "structosmo__gad__ell__arc.html#a2f0540dfa7201d423fb2d6a3d6569c6e", null ]
    ] ],
    [ "osmo_gad_ha_ell_point_alt_unc_ell", "structosmo__gad__ha__ell__point__alt__unc__ell.html", [
      [ "alt", "structosmo__gad__ha__ell__point__alt__unc__ell.html#a2e4c84e2faa53c9a3901c8c18cad8478", null ],
      [ "h_confidence", "structosmo__gad__ha__ell__point__alt__unc__ell.html#a59fb213d7ec4f08c9f3f0e1d2c71c02c", null ],
      [ "lat", "structosmo__gad__ha__ell__point__alt__unc__ell.html#a21b4ced31b4dbe4ed40c62f6a13794da", null ],
      [ "lon", "structosmo__gad__ha__ell__point__alt__unc__ell.html#ae63d5e27b6e312bc8f970be2c79dfe43", null ],
      [ "major_ori", "structosmo__gad__ha__ell__point__alt__unc__ell.html#a64e66689fab05a8cb47e8e6fd79bd259", null ],
      [ "unc_alt", "structosmo__gad__ha__ell__point__alt__unc__ell.html#ad55eec31625badcd4fb0010c541aae15", null ],
      [ "unc_semi_major", "structosmo__gad__ha__ell__point__alt__unc__ell.html#a257b74b2b148d833f8d928631bfc1594", null ],
      [ "unc_semi_minor", "structosmo__gad__ha__ell__point__alt__unc__ell.html#a6998691839c5b5977d5880534aea2335", null ],
      [ "v_confidence", "structosmo__gad__ha__ell__point__alt__unc__ell.html#a2f08ce5636d28d5a1648d00b6282e704", null ]
    ] ],
    [ "osmo_gad", "structosmo__gad.html", [
      [ "ell_arc", "structosmo__gad.html#a422b323d5a93322f4af5647a15852910", null ],
      [ "ell_point", "structosmo__gad.html#a2118e994732e748dcd6c6205c5c348c4", null ],
      [ "ell_point_alt", "structosmo__gad.html#ab9bd9fdc2284f14b0dc6d43dc3b7826b", null ],
      [ "ell_point_alt_unc_ell", "structosmo__gad.html#a39b865d00614b6bd3024434ac428940f", null ],
      [ "ell_point_unc_circle", "structosmo__gad.html#a87734386ea03e677ba7be75d45546a03", null ],
      [ "ell_point_unc_ellipse", "structosmo__gad.html#a20e65a03c4b70e3239363a4c488c19fa", null ],
      [ "ha_ell_point_alt_unc_ell", "structosmo__gad.html#a57758ffaf657c1d75d1ec255a373743a", null ],
      [ "ha_ell_point_unc_ellipse", "structosmo__gad.html#a2d98b3a1d838aa5570c82b6cb22382ab", null ],
      [ "polygon", "structosmo__gad.html#a5e6a45d09b1cdee9179f19c6be9a8647", null ],
      [ "type", "structosmo__gad.html#a16f1c7fd689502f7575b540902d3710c", null ]
    ] ],
    [ "osmo_gad_err", "structosmo__gad__err.html", [
      [ "logmsg", "structosmo__gad__err.html#a74e10fd339f7bd0e5da3c20830df5b81", null ],
      [ "rc", "structosmo__gad__err.html#a256cb1618b83a21aefd2c5218d4e8489", null ],
      [ "type", "structosmo__gad__err.html#a3e155f7c1f64a58f55b35bbbc36c45d5", null ]
    ] ],
    [ "gad_raw_head", "structgad__raw__head.html", null ],
    [ "gad_raw_ell_point", "structgad__raw__ell__point.html", [
      [ "h", "structgad__raw__ell__point.html#a89d2b8df2360e642197387c741b8a9b4", null ],
      [ "lat", "structgad__raw__ell__point.html#a5d128be0857f7d97119e6c1a2b46c26e", null ],
      [ "lon", "structgad__raw__ell__point.html#addbd1e43a3bfbfffbc3413f435b6570f", null ]
    ] ],
    [ "gad_raw_ell_point_unc_circle", "structgad__raw__ell__point__unc__circle.html", null ],
    [ "gad_raw_ell_point_unc_ellipse", "structgad__raw__ell__point__unc__ellipse.html", null ],
    [ "gad_raw_polygon", "structgad__raw__polygon.html", [
      [ "h", "structgad__raw__polygon.html#aacfe1633c43e96c213bb3950ce0f2a66", null ],
      [ "lat", "structgad__raw__polygon.html#acffcb6b1b61a3b15f904d302e0c49bc9", null ],
      [ "lon", "structgad__raw__polygon.html#af99cba2e6596bf16c8f755dd5af0199b", null ],
      [ "point", "structgad__raw__polygon.html#a85c9c0745d963e9c05aa09e2883060c9", null ]
    ] ],
    [ "gad_raw_ell_point_alt", "structgad__raw__ell__point__alt.html", [
      [ "alt", "structgad__raw__ell__point__alt.html#a49004950a1e76040b329082817ed7727", null ],
      [ "h", "structgad__raw__ell__point__alt.html#ab457eb0c3e1804c367c2e7637e573ffb", null ],
      [ "lat", "structgad__raw__ell__point__alt.html#aa9fc32c3d56467286d81d5837a1a4baa", null ],
      [ "lon", "structgad__raw__ell__point__alt.html#a196d51a9ac4a9da247d67066c04627a7", null ]
    ] ],
    [ "gad_raw_ell_point_alt_unc_ell", "structgad__raw__ell__point__alt__unc__ell.html", null ],
    [ "gad_raw_ell_arc", "structgad__raw__ell__arc.html", null ],
    [ "gad_raw_ha_ell_point_unc_ell", "structgad__raw__ha__ell__point__unc__ell.html", null ],
    [ "gad_raw_ha_ell_point_alt_unc_ell", "structgad__raw__ha__ell__point__alt__unc__ell.html", null ],
    [ "gad_raw", "uniongad__raw.html", [
      [ "ell_arc", "uniongad__raw.html#aa303aa8a51039ac8484c4ee57dd8ce2a", null ],
      [ "ell_point", "uniongad__raw.html#aa2d9a518992a2349411bdcefd3df91db", null ],
      [ "ell_point_alt", "uniongad__raw.html#adbc1b67dbafa7ffc0ed59e802a0b0634", null ],
      [ "ell_point_alt_unc_ell", "uniongad__raw.html#a49a6bc8d3bfaca6009949c2bf4582b1a", null ],
      [ "ell_point_unc_circle", "uniongad__raw.html#ab5cd1f99d7afe4d1107f0ce3add96495", null ],
      [ "ell_point_unc_ellipse", "uniongad__raw.html#a71ea66dbd33e8e65a7921f544e78763e", null ],
      [ "h", "uniongad__raw.html#af2f4ffdb7ce9cc81786dfd1eeeda7d4f", null ],
      [ "ha_ell_point_alt_unc_ell", "uniongad__raw.html#af38132d7bc46791f65a42a14e3f1b531", null ],
      [ "ha_ell_point_unc_ell", "uniongad__raw.html#a1aa8ebc47c59664f621bc216bf73d75e", null ],
      [ "polygon", "uniongad__raw.html#a95387aa466a4c71bf6932e083bbe96ca", null ]
    ] ],
    [ "DEC_ERR", "group__gad.html#ga4ddac5cb2b43d106cd8c94d9afeb3acc", null ],
    [ "gad_type", "group__gad.html#ga724072483a2effebff9f40c4fd5b88a8", [
      [ "GAD_TYPE_ELL_POINT", "group__gad.html#gga724072483a2effebff9f40c4fd5b88a8a2cb39492a02a4e0df89150c6685ac59e", null ],
      [ "GAD_TYPE_ELL_POINT_UNC_CIRCLE", "group__gad.html#gga724072483a2effebff9f40c4fd5b88a8a8742f079b7f515aaaa2f9df8ffb2719a", null ],
      [ "GAD_TYPE_ELL_POINT_UNC_ELLIPSE", "group__gad.html#gga724072483a2effebff9f40c4fd5b88a8adf622ab954489f975f7de7e174373e7e", null ],
      [ "GAD_TYPE_POLYGON", "group__gad.html#gga724072483a2effebff9f40c4fd5b88a8a1c130fdc6f41f71d91e24c2aaf4dd680", null ],
      [ "GAD_TYPE_ELL_POINT_ALT", "group__gad.html#gga724072483a2effebff9f40c4fd5b88a8a2212d85decf26e565c582ec22d760137", null ],
      [ "GAD_TYPE_ELL_POINT_ALT_UNC_ELL", "group__gad.html#gga724072483a2effebff9f40c4fd5b88a8a742e2400c4d694a02e5c8966c816c1ab", null ],
      [ "GAD_TYPE_ELL_ARC", "group__gad.html#gga724072483a2effebff9f40c4fd5b88a8af491a2df66762e4d30e338a54b881d3b", null ],
      [ "GAD_TYPE_HA_ELL_POINT_UNC_ELLIPSE", "group__gad.html#gga724072483a2effebff9f40c4fd5b88a8a2719b602e9994a385e525ae3f2c646d9", null ],
      [ "GAD_TYPE_HA_ELL_POINT_ALT_UNC_ELL", "group__gad.html#gga724072483a2effebff9f40c4fd5b88a8acc3691f23c54d4a712f546f210777178", null ]
    ] ],
    [ "__attribute__", "group__gad.html#gae00f0709009b8f66029ea6594a862fe6", null ],
    [ "osmo_gad_dec", "group__gad.html#ga686bb6365093dd503b0b9a7f4466b47a", null ],
    [ "osmo_gad_dec_ell_point_unc_circle", "group__gad.html#ga52b9373ff6f1ce71a088094d49f252fa", null ],
    [ "osmo_gad_dec_lat", "group__gad.html#gaac3dce106167891a6fbee115f1e2361b", null ],
    [ "osmo_gad_dec_lon", "group__gad.html#ga1758a7bfe8ae598c526a12bd8de00cf1", null ],
    [ "osmo_gad_dec_unc", "group__gad.html#ga29e58d3bbd52a7688bd3b4be4c516e0a", null ],
    [ "osmo_gad_enc", "group__gad.html#ga1fa7c132fedbc2750d2dc8e8efcee97b", null ],
    [ "osmo_gad_enc_ell_point_unc_circle", "group__gad.html#ga1556c8b17c3abbbddb0f0975c4f737b3", null ],
    [ "osmo_gad_enc_lat", "group__gad.html#ga0f17993e638716d8f3837c004302b4a7", null ],
    [ "osmo_gad_enc_lon", "group__gad.html#gaa26b905a22d6e0cb4bde8aaf0fd8d2c0", null ],
    [ "osmo_gad_enc_unc", "group__gad.html#ga985256af8e39b55f74ecae46f7cec120", null ],
    [ "osmo_gad_raw_len", "group__gad.html#ga7be8ec6eb0e09665907bca2c8d54c97c", null ],
    [ "osmo_gad_raw_read", "group__gad.html#ga7a8fcfeca1ed42d611ed16acda7fa337", null ],
    [ "osmo_gad_raw_to_str_buf", "group__gad.html#ga7a5e93dc799c5243d3deb3b9ca5cfccc", null ],
    [ "osmo_gad_raw_to_str_c", "group__gad.html#ga9ea8aeeda73e9259735dc24855b0c320", null ],
    [ "osmo_gad_raw_write", "group__gad.html#gaeceb8523f03a150296244463444f73a2", null ],
    [ "osmo_gad_to_str_buf", "group__gad.html#gafba7be63d8f3f677ca51eb021dfac63e", null ],
    [ "osmo_gad_to_str_c", "group__gad.html#gaf162470afdd796be9084ddad25f67cc3", null ],
    [ "osmo_gad_type_name", "group__gad.html#gaf25259c4be18d6d03a28f46cf26d810a", null ],
    [ "__attribute__", "../../core/html/group__sercomm.html#ga8c1dfc1ccf00a08192611433ee7f17b4", null ],
    [ "osmo_gad_type_names", "group__gad.html#gae02bf39f68ae57e2bc44458feb80d14b", null ],
    [ "osmo_gad_type_names", "group__gad.html#gae02bf39f68ae57e2bc44458feb80d14b", null ],
    [ "table_uncertainty_1e3", "group__gad.html#ga27653fcc2e81df69254e5d71b375936f", null ]
];