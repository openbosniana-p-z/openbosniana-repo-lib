/*! \file stats.h */

#pragma once

void osmo_stats_vty_add_cmds();
