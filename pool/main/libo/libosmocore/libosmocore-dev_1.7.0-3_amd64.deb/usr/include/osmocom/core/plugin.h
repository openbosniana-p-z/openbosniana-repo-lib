/*! \file plugin.h */

#pragma once

int osmo_plugin_load_all(const char *directory);
