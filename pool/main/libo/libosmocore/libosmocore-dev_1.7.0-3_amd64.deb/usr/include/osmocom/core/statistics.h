/* wrapper for legacy code, when counter.h was called statistics.h */
#include <osmocom/core/counter.h>
