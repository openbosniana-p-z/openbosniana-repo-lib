var searchData=
[
  ['zero_0',['ZERO',['../../../core/html/group__bitvec.html#gga9f16b701956714c5f84b0a6120d131eaae117e3533122c80b262257b49b21cddf',1,]]]
];
