var searchData=
[
  ['base_5fcmd_5fdescr_0',['BASE_CMD_DESCR',['../talloc__ctx__vty_8c.html#a546dd73432493b70737676687cd669f4',1,'talloc_ctx_vty.c']]],
  ['base_5fcmd_5fstr_1',['BASE_CMD_STR',['../talloc__ctx__vty_8c.html#afb91b81840cf4b99ca5a89840f1afdbb',1,'talloc_ctx_vty.c']]],
  ['buffer_5fdata_5ffree_2',['BUFFER_DATA_FREE',['../buffer_8c.html#a1a2b87a6bddffd1ff50c2e32cc432dcc',1,'buffer.c']]],
  ['buffer_5fsize_5fdefault_3',['BUFFER_SIZE_DEFAULT',['../buffer_8c.html#aba02eec807073b2458c435aa56d7f939',1,'buffer.c']]]
];
