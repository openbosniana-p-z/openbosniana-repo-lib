var searchData=
[
  ['ipac_5fbcch_5finfo_5ftype_0',['ipac_bcch_info_type',['../../../gsm/html/group__oml.html#ga520514f63887d7cf5c9fce287508c549',1,]]],
  ['ipac_5feie_1',['ipac_eie',['../../../gsm/html/group__oml.html#ga349b08ab60008c0ab0541b11eceac217',1,]]]
];
