var searchData=
[
  ['lapd_20implementation_20common_20part_0',['LAPD implementation common part',['../../../gsm/html/group__lapd.html',1,'']]],
  ['lapdm_20implementation_20according_20to_20gsm_20ts_2004_2e06_1',['LAPDm implementation according to GSM TS 04.06',['../../../gsm/html/group__lapdm.html',1,'']]],
  ['libgb_2',['Libgb',['../../../gb/html/group__libgb.html',1,'']]]
];
