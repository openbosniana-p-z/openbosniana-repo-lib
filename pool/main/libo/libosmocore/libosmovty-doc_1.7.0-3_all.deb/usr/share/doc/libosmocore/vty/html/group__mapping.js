var group__mapping =
[
    [ "gsm0503_mcs5_burst_swap", "../../coding/html/group__mapping.html#gab5823b934dd78b6820ea5daf51d1bf6d", null ],
    [ "gsm0503_mcs5_dl_burst_map", "../../coding/html/group__mapping.html#gae362f53abe19876581692706f69180b6", null ],
    [ "gsm0503_mcs5_dl_burst_unmap", "../../coding/html/group__mapping.html#gafbbac46b4ac74b97552b278234e98cc2", null ],
    [ "gsm0503_mcs5_ul_burst_map", "../../coding/html/group__mapping.html#ga007a2022eb27717e7f38f0db99776840", null ],
    [ "gsm0503_mcs5_ul_burst_unmap", "../../coding/html/group__mapping.html#gaa64a4425b6e96f401d6b792ec4fda7c4", null ],
    [ "gsm0503_mcs7_dl_burst_map", "../../coding/html/group__mapping.html#ga556b3b5376d054cd26637b3f720bebec", null ],
    [ "gsm0503_mcs7_dl_burst_unmap", "../../coding/html/group__mapping.html#gacfb25af5a7f2d6d061da61b5513a6cf2", null ],
    [ "gsm0503_mcs7_ul_burst_map", "../../coding/html/group__mapping.html#ga1de7461faf55f2f5479fa49d992cb73f", null ],
    [ "gsm0503_mcs7_ul_burst_unmap", "../../coding/html/group__mapping.html#ga81e36c06ae9fda4217acd2a341a81f91", null ],
    [ "gsm0503_tch_burst_map", "../../coding/html/group__mapping.html#ga9fc223c0a4f6db6d62e993df2a324bdb", null ],
    [ "gsm0503_tch_burst_unmap", "../../coding/html/group__mapping.html#ga564cd3ffe90787d62837aeab810f544b", null ],
    [ "gsm0503_xcch_burst_map", "../../coding/html/group__mapping.html#gad0d9e26e74ed5523083bbdc66e32a0d5", null ],
    [ "gsm0503_xcch_burst_unmap", "../../coding/html/group__mapping.html#ga9c717eaa058f6cdf9909b7454bf68ff7", null ]
];