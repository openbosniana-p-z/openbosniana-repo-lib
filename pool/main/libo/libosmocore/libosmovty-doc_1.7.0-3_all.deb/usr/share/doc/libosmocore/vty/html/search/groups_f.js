var searchData=
[
  ['use_20counter_0',['Use Counter',['../../../core/html/group__use__count.html',1,'']]],
  ['utility_20functions_20to_20deal_20with_20serial_20ports_1',['Utility functions to deal with serial ports',['../../../core/html/group__serial.html',1,'']]]
];
