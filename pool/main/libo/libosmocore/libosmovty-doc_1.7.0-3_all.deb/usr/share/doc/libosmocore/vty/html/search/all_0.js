var searchData=
[
  ['3gpp_20ts_2023_2e032_20gad_3a_20universal_20geographical_20area_20description_2e_0',['3GPP TS 23.032 GAD: Universal Geographical Area Description.',['../../../gsm/html/group__gad.html',1,'']]],
  ['3gpp_20ts_2029_2e205_1',['3GPP TS 29.205',['../../../gsm/html/group__gsm29205.html',1,'']]],
  ['3gpp_20ts_2048_2e071_20bss_20lcs_20assistance_20protocol_20_28bsslap_29_2e_2',['3GPP TS 48.071 BSS LCS Assistance Protocol (BSSLAP).',['../../../gsm/html/group__bsslap.html',1,'']]],
  ['3gpp_20ts_2049_2e031_20bssmap_2dle_2e_3',['3GPP TS 49.031 BSSMAP-LE.',['../../../gsm/html/group__bssmap__le.html',1,'']]]
];
