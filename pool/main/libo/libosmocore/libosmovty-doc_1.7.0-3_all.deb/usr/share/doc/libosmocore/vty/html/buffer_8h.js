var buffer_8h =
[
    [ "buffer_status_t", "buffer_8h.html#a11b72623a9601834584c5ecf08dd6e27", [
      [ "BUFFER_ERROR", "buffer_8h.html#a11b72623a9601834584c5ecf08dd6e27a6185688e62ce527910fd779f2093c6f1", null ],
      [ "BUFFER_EMPTY", "buffer_8h.html#a11b72623a9601834584c5ecf08dd6e27a78d7168c875c46a0fbb5835cd160e2ba", null ],
      [ "BUFFER_PENDING", "buffer_8h.html#a11b72623a9601834584c5ecf08dd6e27a6a5c775497aad93877d86b6a334de110", null ]
    ] ],
    [ "buffer_empty", "buffer_8h.html#a52b607c4b58938a160938b5a4ed7382e", null ],
    [ "buffer_flush_all", "buffer_8h.html#a760a7d10d8c3a02e0c4ebc5f776f9cc3", null ],
    [ "buffer_flush_available", "buffer_8h.html#a342361ac4584b5612bfc8848144ed59b", null ],
    [ "buffer_flush_window", "buffer_8h.html#afcb12bf93399b19962893c0e16caa705", null ],
    [ "buffer_free", "buffer_8h.html#a1e0559eaa1a32cd36154b90ab0eb910f", null ],
    [ "buffer_getstr", "buffer_8h.html#a0eaa56cbd76766aa69adf91177ecad82", null ],
    [ "buffer_new", "buffer_8h.html#a6dd416196ef14875b303b628b7e9ce31", null ],
    [ "buffer_put", "buffer_8h.html#a4ed00ae1d2325b0af2c079acb6299d07", null ],
    [ "buffer_putc", "buffer_8h.html#ae0f9b1e7e87fe076ec4951f79702c7fa", null ],
    [ "buffer_putstr", "buffer_8h.html#ae444912a8f8038846d7b732d747579af", null ],
    [ "buffer_reset", "buffer_8h.html#ac9fc6d7543026d750a2a1006988b4928", null ],
    [ "buffer_write", "buffer_8h.html#a617308d4628c6f30da50679a6a008cb1", null ]
];