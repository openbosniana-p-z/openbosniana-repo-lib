var searchData=
[
  ['vector_5factive_0',['vector_active',['../vector_8h.html#ac96b7beddf251a81df131543d06d63c7',1,'vector.h']]],
  ['vector_5fmin_5fsize_1',['VECTOR_MIN_SIZE',['../vector_8h.html#ac45f1c13e55842e7dc958c379b0efcf4',1,'vector.h']]],
  ['vector_5fslot_2',['vector_slot',['../vector_8h.html#a34cb4a77fbd6ab6cb23707cdd1c4c0d2',1,'vector.h']]],
  ['vty_5fbind_5faddr_5fdefault_3',['VTY_BIND_ADDR_DEFAULT',['../vty_8c.html#a0412ed130a5f389177d0f0725aba3978',1,'vty.c']]],
  ['vty_5fdo_5flower_4',['VTY_DO_LOWER',['../misc_8h.html#ad11aa2532b0ac9f5ea24c1e398f746da',1,'misc.h']]],
  ['vty_5fescape_5',['VTY_ESCAPE',['../vty_8c.html#adee5f2176eb8e53a301dd8d0f377251b',1,'vty.c']]],
  ['vty_5fnormal_6',['VTY_NORMAL',['../vty_8c.html#acf239d95250577af6d34d80d70aac760',1,'vty.c']]],
  ['vty_5fpre_5fescape_7',['VTY_PRE_ESCAPE',['../vty_8c.html#a3aac53820dc12306e1c0d140f1f7bb56',1,'vty.c']]]
];
