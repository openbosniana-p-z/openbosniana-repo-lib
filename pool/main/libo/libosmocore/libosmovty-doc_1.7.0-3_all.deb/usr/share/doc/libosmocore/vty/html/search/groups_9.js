var searchData=
[
  ['mapping_0',['Mapping',['../../../coding/html/group__mapping.html',1,'']]],
  ['message_20buffers_1',['Message buffers',['../../../core/html/group__msgb.html',1,'']]]
];
