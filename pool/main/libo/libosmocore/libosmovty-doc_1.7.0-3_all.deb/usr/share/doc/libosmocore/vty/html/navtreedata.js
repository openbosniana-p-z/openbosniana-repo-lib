/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "libosmovty", "index.html", [
    [ "libosmovty Documentation", "index.html", [
      [ "Introduction", "index.html#sec_intro", null ],
      [ "Copyright and License", "index.html#sec_copyright", null ],
      [ "Homepage + Issue Tracker", "index.html#sec_tracker", null ],
      [ "Contact and Support", "index.html#sec_contact", null ]
    ] ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerator", "functions_eval.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"group__auth.html#ga771d057de5d3433914defbb315d4c056",
"group__bssmap__le.html#gacd1107be5f764c00869476fd401053bd",
"group__command.html#ga2f9003bb1ff253678002c611a49f6657",
"group__command.html#gga6a276b85e2da28c5f9c3dbce61c55682aaf854ce244cb3da385cffe562cbf4b6c",
"group__gsm0408.html#gab0699960d0d7babf1f38532ab2af3a44",
"group__gsup.html#gga422f48c3d3879addcf50b1300bfbc521aea8d527014c1802548f78f249ceb0757",
"group__lapd.html#ggafc677d9832c64e4d5f2adcae81838c24a8bb08cd1c71d1439ab8e24ae9a410218",
"group__libgb.html#gae5257e82b4a770b091d9b042dec1d65c",
"group__logging.html#gga1dc8e73ef848a7dda9388a78342c72afa5e7df050860657ceae54c6d8d53daaa6",
"group__oml.html#gga349b08ab60008c0ab0541b11eceac217a2f7a8482094ab30f6e6f8c446fbf2318",
"group__oml.html#ggab81aa2e7f9b48e22abfec0ae73e4b7a2a27df753602c8e0b21c18667d071118af",
"group__oml.html#ggafe94a91d664eb69f7d9aba1082d3e691a39bfde35bfd0a37478671a5ed86209ba",
"group__rsl.html#gga3311798953086607584abed72b0b53dcada9d4ef3961a478b68abf58db2e14116",
"group__sercomm.html#ga8c1dfc1ccf00a08192611433ee7f17b4",
"group__stats.html#gaeda411f2f93765207bc551afc71844f2",
"group__tlv.html#ggac52a869a7ca04d56070304e97f751dffa01408f7ddf897a14c6ab0ac42f675bf8",
"logging__vty_8c.html#ad3e901c9dce43004710a246d0759a3d1",
"telnet__interface_8c.html#a82a6023d981d4e08120a124b4703deb7"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';