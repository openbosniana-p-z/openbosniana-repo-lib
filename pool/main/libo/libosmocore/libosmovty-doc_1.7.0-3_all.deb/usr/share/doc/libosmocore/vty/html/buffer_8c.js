var buffer_8c =
[
    [ "buffer", "structbuffer.html", "structbuffer" ],
    [ "buffer_data", "structbuffer__data.html", "structbuffer__data" ],
    [ "BUFFER_DATA_FREE", "buffer_8c.html#a1a2b87a6bddffd1ff50c2e32cc432dcc", null ],
    [ "BUFFER_SIZE_DEFAULT", "buffer_8c.html#aba02eec807073b2458c435aa56d7f939", null ],
    [ "MAX_CHUNKS", "buffer_8c.html#a9e879c11aa15653382faa681060e6179", null ],
    [ "MAX_FLUSH", "buffer_8c.html#aaa4f5f66c653ca3963cdda9359d8bdde", null ],
    [ "buffer_add", "buffer_8c.html#a5a33738cadc18e781925f00a76eac240", null ],
    [ "buffer_empty", "buffer_8c.html#a5f2ba1147c2f9b7fee1a90ac2e76d0b7", null ],
    [ "buffer_flush_all", "buffer_8c.html#a191ab7385104a44e13f385e0e6ca1b5d", null ],
    [ "buffer_flush_available", "buffer_8c.html#a3df3e577fcbeec460e3ddab6bc6f59ec", null ],
    [ "buffer_free", "buffer_8c.html#a33630b21db5f9cda080c24c3175bde5a", null ],
    [ "buffer_getstr", "buffer_8c.html#a432bb12021ea78fb50af8b0298ecdfb0", null ],
    [ "buffer_new", "buffer_8c.html#afa3fd5e9fc60dcd1e4cc36ac9cb19722", null ],
    [ "buffer_put", "buffer_8c.html#a6150096c2eaae19e636d2742c3df5b75", null ],
    [ "buffer_putc", "buffer_8c.html#a36699f394f36624f8c1739ef0758db9f", null ],
    [ "buffer_putstr", "buffer_8c.html#a23f67bdda323e69158b6e4587ad19649", null ],
    [ "buffer_reset", "buffer_8c.html#a91ad0ff694ccef1876a3e8d8a3b05ffa", null ],
    [ "buffer_write", "buffer_8c.html#a426b697edda52bb07fdf222e8b982e9d", null ]
];