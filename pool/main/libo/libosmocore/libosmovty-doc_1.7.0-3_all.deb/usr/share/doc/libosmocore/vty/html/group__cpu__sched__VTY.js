var group__cpu__sched__VTY =
[
    [ "cpu_sched_vty.h", "cpu__sched__vty_8h.html", null ],
    [ "osmo_cpu_sched_vty_apply_localthread", "group__cpu__sched__VTY.html#ga5eb944998ac87f1fed307eefdaa25a00", null ],
    [ "osmo_cpu_sched_vty_init", "group__cpu__sched__VTY.html#ga74c34e2c9306decb850569691ab60361", null ]
];