var searchData=
[
  ['desc_0',['desc',['../structdesc.html',1,'']]],
  ['dl_5frel_5freq_5fparam_1',['dl_rel_req_param',['../../../gsm/html/structdl__rel__req__param.html',1,'']]],
  ['dtap_5fheader_2',['dtap_header',['../../../gsm/html/structdtap__header.html',1,'']]]
];
