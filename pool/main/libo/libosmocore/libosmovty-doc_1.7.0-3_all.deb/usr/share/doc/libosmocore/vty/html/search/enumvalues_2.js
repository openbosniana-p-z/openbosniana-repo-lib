var searchData=
[
  ['buffer_5fempty_0',['BUFFER_EMPTY',['../buffer_8h.html#a11b72623a9601834584c5ecf08dd6e27a78d7168c875c46a0fbb5835cd160e2ba',1,'buffer.h']]],
  ['buffer_5ferror_1',['BUFFER_ERROR',['../buffer_8h.html#a11b72623a9601834584c5ecf08dd6e27a6185688e62ce527910fd779f2093c6f1',1,'buffer.h']]],
  ['buffer_5fpending_2',['BUFFER_PENDING',['../buffer_8h.html#a11b72623a9601834584c5ecf08dd6e27a6a5c775497aad93877d86b6a334de110',1,'buffer.h']]]
];
