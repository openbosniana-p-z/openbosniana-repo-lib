var searchData=
[
  ['init_5fmatchvec_5fsize_0',['INIT_MATCHVEC_SIZE',['../command_8c.html#a504ad7bffac6543fa988ae8bbd4f04a3',1,'INIT_MATCHVEC_SIZE():&#160;command.c'],['../command_8c.html#a504ad7bffac6543fa988ae8bbd4f04a3',1,'INIT_MATCHVEC_SIZE():&#160;command.c']]]
];
