var annotated_dup =
[
    [ "_vector", "struct__vector.html", "struct__vector" ],
    [ "buffer", "structbuffer.html", "structbuffer" ],
    [ "buffer_data", "structbuffer__data.html", "structbuffer__data" ],
    [ "cmd_element", "structcmd__element.html", "structcmd__element" ],
    [ "cmd_node", "structcmd__node.html", "structcmd__node" ],
    [ "cpu_affinity_it", "structcpu__affinity__it.html", "structcpu__affinity__it" ],
    [ "desc", "structdesc.html", "structdesc" ],
    [ "host", "structhost.html", "structhost" ],
    [ "rctr_vty_ctx", "structrctr__vty__ctx.html", "structrctr__vty__ctx" ],
    [ "sched_vty_opts", "structsched__vty__opts.html", "structsched__vty__opts" ],
    [ "telnet_connection", "structtelnet__connection.html", "structtelnet__connection" ],
    [ "vty", "structvty.html", "structvty" ],
    [ "vty_app_info", "structvty__app__info.html", "structvty__app__info" ],
    [ "vty_out_context", "structvty__out__context.html", "structvty__out__context" ],
    [ "vty_parent_node", "structvty__parent__node.html", "structvty__parent__node" ],
    [ "vty_signal_data", "structvty__signal__data.html", "structvty__signal__data" ],
    [ "walk_cb_params", "structwalk__cb__params.html", "structwalk__cb__params" ]
];