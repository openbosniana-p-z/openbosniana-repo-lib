var globals_func =
[
    [ "_", "globals_func.html", null ],
    [ "a", "globals_func_a.html", null ],
    [ "b", "globals_func_b.html", null ],
    [ "c", "globals_func_c.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "f", "globals_func_f.html", null ],
    [ "g", "globals_func_g.html", null ],
    [ "h", "globals_func_h.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "l", "globals_func_l.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "n", "globals_func_n.html", null ],
    [ "o", "globals_func_o.html", null ],
    [ "p", "globals_func_p.html", null ],
    [ "r", "globals_func_r.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "t", "globals_func_t.html", null ],
    [ "v", "globals_func_v.html", null ],
    [ "w", "globals_func_w.html", null ],
    [ "x", "globals_func_x.html", null ]
];