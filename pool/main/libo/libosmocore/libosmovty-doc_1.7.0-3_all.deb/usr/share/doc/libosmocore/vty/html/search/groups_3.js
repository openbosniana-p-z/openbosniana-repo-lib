var searchData=
[
  ['coding_0',['Coding',['../../../coding/html/group__coding.html',1,'']]],
  ['configuration_1',['Configuration',['../group__cpu__sched__VTY.html',1,'']]],
  ['convolutional_20encoding_20and_20decoding_20routines_2',['Convolutional encoding and decoding routines',['../../../core/html/group__conv.html',1,'']]],
  ['crypto_3',['Crypto',['../../../gsm/html/group__crypto.html',1,'']]],
  ['cumulative_20counter_20of_20time_20as_20rate_20counter_2e_4',['Cumulative counter of time as rate counter.',['../../../core/html/group__time__cc.html',1,'']]]
];
