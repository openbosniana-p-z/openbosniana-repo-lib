var searchData=
[
  ['match_5ftype_0',['match_type',['../group__command.html#ga34b622da6948a0685ea1e99ac4a2b82c',1,'command.c']]]
];
