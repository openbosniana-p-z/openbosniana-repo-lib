var ecu_8h =
[
    [ "osmo_ecu_fr_state", "structosmo__ecu__fr__state.html", "structosmo__ecu__fr__state" ],
    [ "osmo_ecu_state", "structosmo__ecu__state.html", "structosmo__ecu__state" ],
    [ "osmo_ecu_ops", "structosmo__ecu__ops.html", "structosmo__ecu__ops" ],
    [ "osmo_ecu_codec", "ecu_8h.html#abebbc186f0f363b217b82411ea0e60eb", [
      [ "OSMO_ECU_CODEC_HR", "ecu_8h.html#abebbc186f0f363b217b82411ea0e60eba56a7a473bd4700e2aefe828867163656", null ],
      [ "OSMO_ECU_CODEC_FR", "ecu_8h.html#abebbc186f0f363b217b82411ea0e60eba51cc17e4d4a236d5ff9311a1c18b545a", null ],
      [ "OSMO_ECU_CODEC_EFR", "ecu_8h.html#abebbc186f0f363b217b82411ea0e60ebaa9916d57fab398ee04552168fd94d228", null ],
      [ "OSMO_ECU_CODEC_AMR", "ecu_8h.html#abebbc186f0f363b217b82411ea0e60ebafd16d3c0c800bd7838ce2903b6d9d98d", null ],
      [ "_NUM_OSMO_ECU_CODECS", "ecu_8h.html#abebbc186f0f363b217b82411ea0e60ebaa006a88f0eaad31948dd95c11c998de9", null ]
    ] ],
    [ "osmo_ecu_destroy", "ecu_8h.html#aee251e8219d7922452d261a3c7d5329a", null ],
    [ "osmo_ecu_fr_conceal", "ecu_8h.html#adadd2749e99870a1dc55c5a612dc7bd1", null ],
    [ "osmo_ecu_fr_reset", "ecu_8h.html#aad51dc9a3775141c5e55273cf832a93f", null ],
    [ "osmo_ecu_frame_in", "ecu_8h.html#a111ce1d991c8bc5f175521cb9d16ea1b", null ],
    [ "osmo_ecu_frame_out", "ecu_8h.html#a7ca732e6dd9ed449697ba24847609d79", null ],
    [ "osmo_ecu_init", "ecu_8h.html#a9b62d65c3a20761dd0430df7fc090adf", null ],
    [ "osmo_ecu_register", "ecu_8h.html#adae3370086c32ba775ce711bf5a5162c", null ]
];