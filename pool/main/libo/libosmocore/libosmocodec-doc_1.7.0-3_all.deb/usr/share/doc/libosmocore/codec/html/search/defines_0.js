var searchData=
[
  ['gsm610_5fxmaxc_5flen_0',['GSM610_XMAXC_LEN',['../ecu__fr_8c.html#a58b276a2088990247d6257708780e94a',1,'ecu_fr.c']]],
  ['gsm610_5fxmaxc_5freduce_1',['GSM610_XMAXC_REDUCE',['../ecu__fr_8c.html#a43d9349be340f4739bf3ca9515791c36',1,'ecu_fr.c']]],
  ['gsm_5fefr_5fbytes_2',['GSM_EFR_BYTES',['../codec_8h.html#a1408201e76008d9e45eb7d9662bcbadb',1,'codec.h']]],
  ['gsm_5ffr_5fbytes_3',['GSM_FR_BYTES',['../codec_8h.html#a8142bfeed988eaca0bd616928348a601',1,'codec.h']]],
  ['gsm_5fhr_5fbytes_4',['GSM_HR_BYTES',['../codec_8h.html#a609c2f68d173e81830bd5ada4684fdf1',1,'codec.h']]]
];
