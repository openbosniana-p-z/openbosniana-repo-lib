var gsm620_8c =
[
    [ "osmo_hr_check_sid", "gsm620_8c.html#ad9b2ad0ca9540027568e398ca070f645", null ],
    [ "gsm620_unvoiced_bitorder", "gsm620_8c.html#a16456fc7f3ab196a607f56c3fbaf044e", null ],
    [ "gsm620_voiced_bitorder", "gsm620_8c.html#a94918e4bdfdd28d502b03e8328ce9f00", null ]
];