var structosmo__ecu__ops =
[
    [ "destroy", "structosmo__ecu__ops.html#a34b0dfdc2154bf3f347e15bc00ad491c", null ],
    [ "frame_in", "structosmo__ecu__ops.html#aae8e7085da894c44c7f22e413d19efeb", null ],
    [ "frame_out", "structosmo__ecu__ops.html#a11b7bd51a318a5de9797754f1c83a96c", null ],
    [ "init", "structosmo__ecu__ops.html#a786a9a1ed56031507929e2c3b1df98bf", null ]
];