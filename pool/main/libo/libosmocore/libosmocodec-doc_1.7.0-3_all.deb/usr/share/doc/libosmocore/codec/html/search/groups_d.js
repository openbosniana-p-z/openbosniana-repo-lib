var searchData=
[
  ['select_20loop_20abstraction_0',['Select loop abstraction',['../../../core/html/group__select.html',1,'']]],
  ['seriall_20communications_20_28hdlc_29_1',['Seriall Communications (HDLC)',['../../../core/html/group__sercomm.html',1,'']]],
  ['short_20message_20service_20_28sms_29_2',['Short Message Service (SMS)',['../../../gsm/html/group__sms.html',1,'']]],
  ['simple_20doubly_20linked_20list_20implementation_3',['Simple doubly linked list implementation',['../../../core/html/group__linuxlist.html',1,'']]],
  ['socket_20convenience_20functions_4',['Socket convenience functions',['../../../core/html/group__socket.html',1,'']]],
  ['soft_2c_20unpacked_20and_20packed_20bits_5',['soft, unpacked and packed bits',['../../../core/html/group__bits.html',1,'']]],
  ['statistics_20reporting_6',['Statistics reporting',['../../../core/html/group__stats.html',1,'']]],
  ['statistics_20value_20item_7',['Statistics value item',['../../../core/html/group__osmo__stat__item.html',1,'']]]
];
