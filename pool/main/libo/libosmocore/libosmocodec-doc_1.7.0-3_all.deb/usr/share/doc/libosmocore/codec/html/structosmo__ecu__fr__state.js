var structosmo__ecu__fr__state =
[
    [ "frame_backup", "structosmo__ecu__fr__state.html#a2b3e0ed3b4635c4ffea700edf743d8f5", null ],
    [ "subsequent_lost_frame", "structosmo__ecu__fr__state.html#add84cab547c1d36c1ef99171804bd77d", null ]
];