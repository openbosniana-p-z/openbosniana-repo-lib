var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "a", "globals_a.html", null ],
    [ "c", "globals_c.html", null ],
    [ "e", "globals_e.html", null ],
    [ "g", "globals_g.html", null ],
    [ "o", "globals_o.html", null ],
    [ "r", "globals_r.html", null ],
    [ "t", "globals_t.html", null ]
];