var searchData=
[
  ['amr_5f10_5f2_0',['AMR_10_2',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802a9099ffcdfa8f63214f8778eccff996f6',1,'codec.h']]],
  ['amr_5f12_5f2_1',['AMR_12_2',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802a2823f5ffd0553b9e8b3de24de07081d1',1,'codec.h']]],
  ['amr_5f4_5f75_2',['AMR_4_75',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802a0b1f2017de8f7f61a91b94d1416cb589',1,'codec.h']]],
  ['amr_5f5_5f15_3',['AMR_5_15',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802ae683245a4d66e84d4faa660026cd10b5',1,'codec.h']]],
  ['amr_5f5_5f90_4',['AMR_5_90',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802ad15c62abdb1f24538497ac1b66fc7084',1,'codec.h']]],
  ['amr_5f6_5f70_5',['AMR_6_70',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802aae17c5669ff3a19c3f1658f54a81392f',1,'codec.h']]],
  ['amr_5f7_5f40_6',['AMR_7_40',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802a88cc0dc18ca13740ae24d0db4b1cfe8b',1,'codec.h']]],
  ['amr_5f7_5f95_7',['AMR_7_95',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802af72dbc8b33dd396b7094f15ec293aed0',1,'codec.h']]],
  ['amr_5fbad_8',['AMR_BAD',['../codec_8h.html#ad8fe0f6cdeeb90780bc5d5457234cfa6a6707d26771cc8327db67af28d8e74451',1,'codec.h']]],
  ['amr_5fgood_9',['AMR_GOOD',['../codec_8h.html#ad8fe0f6cdeeb90780bc5d5457234cfa6a6ed387877388c0c01c7819a13f5f68ac',1,'codec.h']]],
  ['amr_5fgsm_5fefr_5fsid_10',['AMR_GSM_EFR_SID',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802abf434964f2363b746e93bb986ee869d8',1,'codec.h']]],
  ['amr_5fno_5fdata_11',['AMR_NO_DATA',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802a009720fb877b08458a901d3b1ff38104',1,'codec.h']]],
  ['amr_5fpdc_5fefr_5fsid_12',['AMR_PDC_EFR_SID',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802abfd9cd1a65cdfe99ded3d5c48618b9da',1,'codec.h']]],
  ['amr_5fsid_13',['AMR_SID',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802ac141867c27854f5a1ced1b809faed2f7',1,'codec.h']]],
  ['amr_5ftdma_5fefr_5fsid_14',['AMR_TDMA_EFR_SID',['../codec_8h.html#aa3bfef13bd38e839f85fdcd2a11c8802aff538b6244088e5d64381ccf90d155f9',1,'codec.h']]]
];
