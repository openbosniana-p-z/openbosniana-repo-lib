var gsm690_8c =
[
    [ "ts26101_reorder_table", "structts26101__reorder__table.html", "structts26101__reorder__table" ],
    [ "osmo_amr_d_to_s", "gsm690_8c.html#a899b52a70d03f8f4a8d79a9ed1a0103d", null ],
    [ "osmo_amr_rtp_dec", "gsm690_8c.html#adf373a4285e5f3941f1b4ab5ec2b6da6", null ],
    [ "osmo_amr_rtp_enc", "gsm690_8c.html#a9a65632c3a42a46bb5b1145750a80c77", null ],
    [ "osmo_amr_s_to_d", "gsm690_8c.html#aba0ae5e40e01a1d075d952fbd15c320c", null ],
    [ "amr_len_by_ft", "gsm690_8c.html#a7c56043196e2a23a3c576a05088934f6", null ],
    [ "gsm690_10_2_bitorder", "gsm690_8c.html#a408c2c1c588053b000fc116e7e7b09ec", null ],
    [ "gsm690_12_2_bitorder", "gsm690_8c.html#a656bf75d3e99e62f257f63df6715e9b0", null ],
    [ "gsm690_4_75_bitorder", "gsm690_8c.html#a71f310d2639cf7ab6fa046cafec86c91", null ],
    [ "gsm690_5_15_bitorder", "gsm690_8c.html#a83f5d8f4ddf2a256861eb767ddd50d3b", null ],
    [ "gsm690_5_9_bitorder", "gsm690_8c.html#a748d659729f20fb11795363bf4cb5870", null ],
    [ "gsm690_6_7_bitorder", "gsm690_8c.html#aae55bb6034d7cb0751093828a28c74ca", null ],
    [ "gsm690_7_4_bitorder", "gsm690_8c.html#a393ce3d88ca28c971e7e988548dbfc23", null ],
    [ "gsm690_7_95_bitorder", "gsm690_8c.html#a82473ec0074d65f92d6049e2e7ac37b6", null ],
    [ "gsm690_bitlength", "gsm690_8c.html#a5a49793e7754e061231c628446330bf9", null ],
    [ "osmo_amr_type_names", "gsm690_8c.html#ab84c9b2bc757b3902acd04009593fd0c", null ],
    [ "ts26101_reorder_tables", "gsm690_8c.html#a63ea2edffffe43bfc2e98dcb54825ea7", null ]
];