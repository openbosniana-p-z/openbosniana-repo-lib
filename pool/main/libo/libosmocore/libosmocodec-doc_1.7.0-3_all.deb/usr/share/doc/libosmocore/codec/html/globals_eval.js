var globals_eval =
[
    [ "_", "globals_eval.html", null ],
    [ "a", "globals_eval_a.html", null ],
    [ "g", "globals_eval_g.html", null ],
    [ "o", "globals_eval_o.html", null ]
];