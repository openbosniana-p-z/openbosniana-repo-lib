var searchData=
[
  ['_5fnum_5fosmo_5fecu_5fcodecs_0',['_NUM_OSMO_ECU_CODECS',['../ecu_8h.html#abebbc186f0f363b217b82411ea0e60ebaa006a88f0eaad31948dd95c11c998de9',1,'ecu.h']]]
];
