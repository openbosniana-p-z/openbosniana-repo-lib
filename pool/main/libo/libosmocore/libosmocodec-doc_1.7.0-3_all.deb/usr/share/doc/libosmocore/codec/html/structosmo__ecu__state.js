var structosmo__ecu__state =
[
    [ "codec", "structosmo__ecu__state.html#a6994442879221579dd5611e696bf299f", null ],
    [ "data", "structosmo__ecu__state.html#a8171cb8c2dbddcbd0eebf89a2f6c69ae", null ]
];