var structctrl__cmd__struct =
[
    [ "command", "structctrl__cmd__struct.html#ac9c0167515fb2146dcf3b6b8076a3142", null ],
    [ "nr_commands", "structctrl__cmd__struct.html#adcf7cab63c8dc12e6b1577754bdcf78b", null ]
];