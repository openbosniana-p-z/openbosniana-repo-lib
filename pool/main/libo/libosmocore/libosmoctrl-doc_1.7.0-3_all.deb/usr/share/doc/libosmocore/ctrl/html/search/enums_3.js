var searchData=
[
  ['event_0',['event',['../../../vty/html/group__vty.html#ga3b65133bb9997cd1ccf311af0927fc9e',1,]]]
];
