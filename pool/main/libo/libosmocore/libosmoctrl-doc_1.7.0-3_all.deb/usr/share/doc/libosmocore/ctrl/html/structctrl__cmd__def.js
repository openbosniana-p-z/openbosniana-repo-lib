var structctrl__cmd__def =
[
    [ "cmd", "structctrl__cmd__def.html#ae0b09f794d2ff17b394c25070582eac7", null ],
    [ "data", "structctrl__cmd__def.html#a4f4e9a60fe99b1dd12780ff1c0c7b2b7", null ],
    [ "list", "structctrl__cmd__def.html#ad681ae88c34dcee57e676bc6cff1e30f", null ]
];