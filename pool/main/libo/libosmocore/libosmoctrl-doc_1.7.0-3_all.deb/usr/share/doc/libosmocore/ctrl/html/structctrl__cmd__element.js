var structctrl__cmd__element =
[
    [ "get", "structctrl__cmd__element.html#a5c8303fc4d5923f8c7b1476d9932725f", null ],
    [ "name", "structctrl__cmd__element.html#a46735b67b6fd5f143bfcc9a2d1bb6221", null ],
    [ "set", "structctrl__cmd__element.html#a15ff26e609a25378d43e40ba0a1ab918", null ],
    [ "strcmd", "structctrl__cmd__element.html#a1ddbd944b534f06dabaac92bd0478538", null ],
    [ "verify", "structctrl__cmd__element.html#ab3d96650b77e70edc57c7e95fc3a5a08", null ]
];