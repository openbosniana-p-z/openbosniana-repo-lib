var ports_8h =
[
    [ "OSMO_CTRL_PORT_BSC_NAT", "ports_8h.html#ae7c964ae0e90b48705c3ee0c3ff83623", null ],
    [ "OSMO_CTRL_PORT_BSC_NEIGH", "ports_8h.html#ab107c3f764249358d51fa0c2107a5693", null ],
    [ "OSMO_CTRL_PORT_BTS", "ports_8h.html#a684457d3292d8c64a100ba052e29dc7a", null ],
    [ "OSMO_CTRL_PORT_CBC", "ports_8h.html#a248fb9440a8dad3ed2dd3c3162e3629e", null ],
    [ "OSMO_CTRL_PORT_GBPROXY", "ports_8h.html#ab05f5b17fd05415b2643b97b4faa7aa3", null ],
    [ "OSMO_CTRL_PORT_GGSN", "ports_8h.html#a0eaa01fd8efbdaded3f9c713c261d660", null ],
    [ "OSMO_CTRL_PORT_HLR", "ports_8h.html#a8b7a83010aada97694ebaddb9d5cd444", null ],
    [ "OSMO_CTRL_PORT_HNBGW", "ports_8h.html#adb90a284b3bc27debed1143d6be6174e", null ],
    [ "OSMO_CTRL_PORT_HNODEB", "ports_8h.html#a076fd3c2df9f46f919068a58f65f6cbc", null ],
    [ "OSMO_CTRL_PORT_MGW", "ports_8h.html#a04d48781cbc38fcca6f7659025969ef5", null ],
    [ "OSMO_CTRL_PORT_MSC", "ports_8h.html#a954b3515a97838c5a14a9f9aa74f0255", null ],
    [ "OSMO_CTRL_PORT_NITB_BSC", "ports_8h.html#a67f70150e2614089ae13c2cde8d5f2b3", null ],
    [ "OSMO_CTRL_PORT_PFCP_TOOL", "ports_8h.html#aee41f1ec8c5db96da353fabf6d593690", null ],
    [ "OSMO_CTRL_PORT_SGSN", "ports_8h.html#a2f6bef54ae428b1c49644c825cc70993", null ],
    [ "OSMO_CTRL_PORT_SMLC", "ports_8h.html#ad97c7c74d4d32d240bfe473cf99db42d", null ],
    [ "OSMO_CTRL_PORT_TRX", "ports_8h.html#ae261d099d96c2adaef72f8b8bbf7ac1e", null ],
    [ "OSMO_CTRL_PORT_UPF", "ports_8h.html#a05b882d5a362432e3552cb13ae2245d1", null ]
];