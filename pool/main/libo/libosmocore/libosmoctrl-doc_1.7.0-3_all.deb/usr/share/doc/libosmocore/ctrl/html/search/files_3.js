var searchData=
[
  ['defs_2eh_0',['defs.h',['../../../core/html/defs_8h.html',1,'']]]
];
