var control__if_8h =
[
    [ "ctrl_handle", "structctrl__handle.html", "structctrl__handle" ],
    [ "ctrl_cmd_lookup", "control__if_8h.html#a9cf93dcc7af6485216ff332966dd9c09", null ],
    [ "ctrl_cmd_reply_cb", "control__if_8h.html#a06303a3dfb5debef99ecb539079e6db0", null ],
    [ "ctrl_cmd_exec_from_string", "control__if_8h.html#affafcd805595604f1e164f5f7b96cfc5", null ],
    [ "ctrl_cmd_handle", "control__if_8h.html#a8879414ec4d516079cedc58b39d2c990", null ],
    [ "ctrl_cmd_send", "control__if_8h.html#ac556c96fd7df0ee6a5ea3c3826bd037e", null ],
    [ "ctrl_cmd_send_trap", "control__if_8h.html#ad0e8f381fedade3a380010189d574243", null ],
    [ "ctrl_handle_alloc", "control__if_8h.html#a9c07f83fe1a90d038d3a0e65e2820880", null ],
    [ "ctrl_handle_alloc2", "control__if_8h.html#aaf1128fc2d419f0cefe229c71ebf6781", null ],
    [ "ctrl_handle_msg", "control__if_8h.html#abebb5f7b19121559a493b6822036fe82", null ],
    [ "ctrl_interface_setup", "control__if_8h.html#ab887e2f076614ba799229a404f872d85", null ],
    [ "ctrl_interface_setup_dynip", "control__if_8h.html#a057647aadb0580d25c6e8ce2f9714031", null ],
    [ "ctrl_interface_setup_dynip2", "control__if_8h.html#a35786d463b20f1100beaa6a0bdd9d73e", null ],
    [ "ctrl_lookup_register", "control__if_8h.html#a1247f66c7e761c0a4fd3dedf11f84e40", null ],
    [ "ctrl_parse_get_num", "control__if_8h.html#a525af25e0b2344b8b1286c388f721679", null ],
    [ "osmo_ctrl_conn_alloc", "control__if_8h.html#a7b2022943b045830f488d101c9253e80", null ]
];