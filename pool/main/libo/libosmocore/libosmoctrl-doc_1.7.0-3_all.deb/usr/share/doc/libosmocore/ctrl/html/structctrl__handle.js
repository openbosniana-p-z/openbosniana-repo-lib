var structctrl__handle =
[
    [ "ccon_list", "structctrl__handle.html#a6f3a08b1cdb06684e888b82a55b122f9", null ],
    [ "data", "structctrl__handle.html#a6b883d554826b9b40fb8179ce0b1182a", null ],
    [ "listen_fd", "structctrl__handle.html#ad6bd2940c2192419b6f4fc5b60fbbbf2", null ],
    [ "lookup", "structctrl__handle.html#a2b5be7fb390a8e0b0e0b613bde25be3c", null ],
    [ "reply_cb", "structctrl__handle.html#a703e755996d78ae80e4cb405b50f0a80", null ]
];