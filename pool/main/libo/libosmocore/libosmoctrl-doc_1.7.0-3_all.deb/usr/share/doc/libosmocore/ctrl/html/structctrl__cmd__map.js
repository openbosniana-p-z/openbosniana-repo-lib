var structctrl__cmd__map =
[
    [ "cmd", "structctrl__cmd__map.html#a3597dc0ea72c7da8ef3afc9c9b880032", null ],
    [ "type", "structctrl__cmd__map.html#af98f7c2f6c7df06c1de7d709e417f707", null ]
];