var structctrl__connection =
[
    [ "closed_cb", "structctrl__connection.html#a15919ffbf19d2a79a93993a96f6e21f0", null ],
    [ "cmds", "structctrl__connection.html#aebe6d7f7547f16364455865865037937", null ],
    [ "def_cmds", "structctrl__connection.html#aac52a01bfc2f1c7989b53f8ac32148d3", null ],
    [ "list_entry", "structctrl__connection.html#a38af9e10f2a47d50295996d0c9de71a5", null ],
    [ "pending_msg", "structctrl__connection.html#a8576663940810ca0327e2a1888aa7bf1", null ],
    [ "write_queue", "structctrl__connection.html#a39c0cbb6e0f6e96f76c28f64d2c92481", null ]
];