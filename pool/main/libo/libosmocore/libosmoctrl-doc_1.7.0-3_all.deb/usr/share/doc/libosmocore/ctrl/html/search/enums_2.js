var searchData=
[
  ['ctrl_5fnode_5ftype_0',['ctrl_node_type',['../control__cmd_8h.html#aacfd6242d4c8eb9d70354cb2d57d5262',1,'control_cmd.h']]],
  ['ctrl_5ftype_1',['ctrl_type',['../control__cmd_8h.html#a009b994cda9bda0f88e892ba1234794c',1,'control_cmd.h']]]
];
