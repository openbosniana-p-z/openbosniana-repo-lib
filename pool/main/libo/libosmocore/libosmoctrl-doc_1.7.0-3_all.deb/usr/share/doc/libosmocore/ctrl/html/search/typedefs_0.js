var searchData=
[
  ['ctrl_5fcmd_5flookup_0',['ctrl_cmd_lookup',['../control__if_8h.html#a9cf93dcc7af6485216ff332966dd9c09',1,'control_if.h']]],
  ['ctrl_5fcmd_5freply_5fcb_1',['ctrl_cmd_reply_cb',['../control__if_8h.html#a06303a3dfb5debef99ecb539079e6db0',1,'control_if.h']]]
];
