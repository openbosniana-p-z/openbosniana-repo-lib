var structctrl__cmd =
[
    [ "ccon", "structctrl__cmd.html#a24d327008cf70aad8ef9ce9cc290831b", null ],
    [ "defer", "structctrl__cmd.html#a0c972446cd7a87cffe84914387b9330b", null ],
    [ "id", "structctrl__cmd.html#a732ab2240bbe7d86013d73c2414c1f0a", null ],
    [ "node", "structctrl__cmd.html#ad909727d72b92bebb3c428a3a9fc1f12", null ],
    [ "reply", "structctrl__cmd.html#aea483634e22f6a5ae57bd8958d6f4f73", null ],
    [ "type", "structctrl__cmd.html#a6945f0e7005ad890c94eff6f8e7538a0", null ],
    [ "value", "structctrl__cmd.html#a3140bed63114f292dfb49cc5393e2812", null ],
    [ "variable", "structctrl__cmd.html#a2919ce12c1d2083f13e20ffbc4b5983a", null ]
];