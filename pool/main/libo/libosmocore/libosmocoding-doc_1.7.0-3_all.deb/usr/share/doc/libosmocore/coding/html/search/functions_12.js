var searchData=
[
  ['update_5fname_0',['update_name',['../../../core/html/group__fsm.html#ga1380b8cda91ee170848d1e9646135b93',1,]]],
  ['update_5fnearest_1',['update_nearest',['../../../core/html/group__timer.html#ga0c625e3072119d895980fefcd207c14d',1,]]],
  ['update_5fpending_5fframes_2',['update_pending_frames',['../../../gsm/html/group__lapdm.html#ga496ffcc3aaffc6b25df8c077c843209b',1,]]],
  ['update_5fsrep_5fconfig_3',['update_srep_config',['../../../core/html/group__stats.html#gab7df28b2e32b2437bfc88185a1a5c06f',1,]]]
];
