var searchData=
[
  ['libosmocoding_20documentation_0',['libosmocoding Documentation',['../index.html',1,'']]]
];
