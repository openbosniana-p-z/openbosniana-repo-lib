var searchData=
[
  ['gad_5ftype_0',['gad_type',['../../../gsm/html/group__gad.html#ga724072483a2effebff9f40c4fd5b88a8',1,]]],
  ['gsm0503_5famr_5fdtx_5fframes_1',['gsm0503_amr_dtx_frames',['../group__coding.html#gadca0cb6bbe4f321f8b7e3c14dc9007d8',1,'gsm0503_amr_dtx.h']]],
  ['gsm0503_5fegprs_5fmcs_2',['gsm0503_egprs_mcs',['../group__coding.html#gaadce72fa9aeafadf3b1884e4d817248d',1,'gsm0503_coding.h']]]
];
