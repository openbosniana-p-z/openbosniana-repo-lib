var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "a", "globals_a.html", null ],
    [ "c", "globals_c.html", null ],
    [ "d", "globals_d.html", null ],
    [ "e", "globals_e.html", null ],
    [ "g", "globals_g.html", null ],
    [ "i", "globals_i.html", null ],
    [ "o", "globals_o.html", null ],
    [ "r", "globals_r.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ]
];