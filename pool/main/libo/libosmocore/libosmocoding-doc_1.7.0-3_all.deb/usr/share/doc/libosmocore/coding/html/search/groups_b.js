var searchData=
[
  ['parity_0',['Parity',['../group__parity.html',1,'']]]
];
