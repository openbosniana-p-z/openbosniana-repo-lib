var searchData=
[
  ['bit_20compression_0',['Bit compression',['../../../core/html/group__bitcomp.html',1,'']]],
  ['bit_20vectors_1',['Bit vectors',['../../../core/html/group__bitvec.html',1,'']]]
];
