/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "libosmocoding", "index.html", [
    [ "libosmocoding Documentation", "index.html", [
      [ "Introduction", "index.html#sec_intro", null ],
      [ "Copyright and License", "index.html#sec_copyright", null ],
      [ "Homepage + Issue Tracker", "index.html#sec_tracker", null ],
      [ "Contact and Support", "index.html#sec_contact", null ]
    ] ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"group__bits.html#gac3e432aa41d4435a5d206da5b7f9a7e6",
"group__bssmap__le.html#ggaf7304891391c3aace1b54c75aa119dd0a7bb66a77d1246fe92d58436768f35076",
"group__command.html#gacffe1bf4a833d46d30fe67900f7c8fab",
"group__gsm0408.html#ga1bfae76c935759a320a49624529b8e59",
"group__gsm29205.html#ga9a29f24e0da01e4894097fef93c0c6d9",
"group__lapd.html#ga090a83d63477f4d5b591328f28051570",
"group__libgb.html#ga9eb02dcd9b1864987ffa538af6852728a2e9edabd27a0e209bfd901dc0bc225b9",
"group__logging.html#ga72d0cddff0823055cf7dbf195f96bba1",
"group__oml.html#gac398e62b1a42c2d5594b1817a77749ff",
"group__oml.html#gga94d045fc2adef7395390ee0e0265e33eab9db70f229f84447258dfecffabab61e",
"group__oml.html#ggac464dc871d95e2782f9bb7b5606a08e0af3e96a59820259c681bef72135d01149",
"group__rsl.html#gga3311798953086607584abed72b0b53dca25366b379045dda2ae5a59e2f40aad08",
"group__rsl.html#ggab97141ec5e03b589fd75f8ee5d4b7537aead9e66c87411722887b7eff6b65a828",
"group__socket.html#gae69bcda576af776a01d10ede0b774d71",
"group__tlv.html#ga4859a889693eec53ecb79f361e1884a7",
"gsm0503__amr__dtx_8c.html#aaf3b559da3028e43ec51e30b41e7e98a"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';