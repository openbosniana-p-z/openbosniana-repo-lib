var searchData=
[
  ['ussd_5frequest_0',['ussd_request',['../../../gsm/html/structussd__request.html',1,'']]]
];
