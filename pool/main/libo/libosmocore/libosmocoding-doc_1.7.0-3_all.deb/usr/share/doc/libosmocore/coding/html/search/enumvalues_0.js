var searchData=
[
  ['afs_5fonset_0',['AFS_ONSET',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8aa3dcf5ab5a039fd578353b229a200b1a',1,'gsm0503_amr_dtx.h']]],
  ['afs_5fsid_5ffirst_1',['AFS_SID_FIRST',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a80671ff0cf5f173c6230cd0802e07ec2',1,'gsm0503_amr_dtx.h']]],
  ['afs_5fsid_5fupdate_2',['AFS_SID_UPDATE',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8afd75b6e83edae2b047efdaaa20161ef6',1,'gsm0503_amr_dtx.h']]],
  ['afs_5fsid_5fupdate_5fcn_3',['AFS_SID_UPDATE_CN',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8aa3b8cd5246b7fcde15c57351aa16e50c',1,'gsm0503_amr_dtx.h']]],
  ['ahs_5fonset_4',['AHS_ONSET',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a3be49f1926262c91664284d77810d633',1,'gsm0503_amr_dtx.h']]],
  ['ahs_5fsid_5ffirst_5finh_5',['AHS_SID_FIRST_INH',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a58bf29a80404c62271d4dd7d6d33299b',1,'gsm0503_amr_dtx.h']]],
  ['ahs_5fsid_5ffirst_5fp1_6',['AHS_SID_FIRST_P1',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a77e46e6154c137187772f1694b5878b8',1,'gsm0503_amr_dtx.h']]],
  ['ahs_5fsid_5ffirst_5fp2_7',['AHS_SID_FIRST_P2',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a23b810c20fdfe3f8d178a3b9c37348f9',1,'gsm0503_amr_dtx.h']]],
  ['ahs_5fsid_5fupdate_8',['AHS_SID_UPDATE',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8ac36ed3cc9213e59edf0f324bc7897162',1,'gsm0503_amr_dtx.h']]],
  ['ahs_5fsid_5fupdate_5fcn_9',['AHS_SID_UPDATE_CN',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a4f4624db162f8c4d3ecc90dd925ebcee',1,'gsm0503_amr_dtx.h']]],
  ['ahs_5fsid_5fupdate_5finh_10',['AHS_SID_UPDATE_INH',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a9d2826bd26f739bf6979dbe0bb89c6d5',1,'gsm0503_amr_dtx.h']]],
  ['amr_5fother_11',['AMR_OTHER',['../group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8ac6826d44d302961c67736b07d4239b55',1,'gsm0503_amr_dtx.h']]]
];
