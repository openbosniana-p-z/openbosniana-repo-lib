var annotated_dup =
[
    [ "gprs_rlc_dl_hdr_egprs", "uniongprs__rlc__dl__hdr__egprs.html", "uniongprs__rlc__dl__hdr__egprs" ],
    [ "gprs_rlc_ul_hdr_egprs", "uniongprs__rlc__ul__hdr__egprs.html", "uniongprs__rlc__ul__hdr__egprs" ],
    [ "gsm0503_mcs_code", "structgsm0503__mcs__code.html", "structgsm0503__mcs__code" ]
];