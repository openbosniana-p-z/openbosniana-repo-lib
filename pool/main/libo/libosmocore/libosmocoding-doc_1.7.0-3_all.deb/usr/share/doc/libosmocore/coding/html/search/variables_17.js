var searchData=
[
  ['xfer_5fdelay_0',['xfer_delay',['../../../gsm/html/structgsm48__qos.html#a72f077535c504ca76d00c10a7275fd07',1,'gsm48_qos']]],
  ['xor_5falg_1',['xor_alg',['../../../gsm/html/group__auth.html#gadcedd117ca6eb4785411f43b74a81933',1,]]],
  ['xres_2',['xres',['../../../gsm/html/structosmo__oap__message.html#a5774a3ca9b5e56dcc3806c4d6699e8ab',1,'osmo_oap_message']]],
  ['xres_5fpresent_3',['xres_present',['../../../gsm/html/structosmo__oap__message.html#aad054c448d92be21651a581368fbe416',1,'osmo_oap_message']]]
];
