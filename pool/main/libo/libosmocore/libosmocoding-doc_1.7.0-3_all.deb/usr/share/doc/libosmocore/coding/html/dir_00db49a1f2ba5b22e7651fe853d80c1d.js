var dir_00db49a1f2ba5b22e7651fe853d80c1d =
[
    [ "gsm0503_amr_dtx.c", "gsm0503__amr__dtx_8c.html", "gsm0503__amr__dtx_8c" ],
    [ "gsm0503_coding.c", "gsm0503__coding_8c.html", "gsm0503__coding_8c" ],
    [ "gsm0503_interleaving.c", "gsm0503__interleaving_8c.html", "gsm0503__interleaving_8c" ],
    [ "gsm0503_mapping.c", "gsm0503__mapping_8c.html", "gsm0503__mapping_8c" ],
    [ "gsm0503_parity.c", "gsm0503__parity_8c.html", "gsm0503__parity_8c" ],
    [ "gsm0503_tables.c", "gsm0503__tables_8c.html", "gsm0503__tables_8c" ]
];