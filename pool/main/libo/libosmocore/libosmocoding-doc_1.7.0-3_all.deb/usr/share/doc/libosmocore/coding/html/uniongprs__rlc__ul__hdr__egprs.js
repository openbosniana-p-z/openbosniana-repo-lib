var uniongprs__rlc__ul__hdr__egprs =
[
    [ "type1", "uniongprs__rlc__ul__hdr__egprs.html#a4dae8e5b21a3ebd77faf2c980fbada94", null ],
    [ "type2", "uniongprs__rlc__ul__hdr__egprs.html#a1902b78794e80d38377771da85489df5", null ],
    [ "type3", "uniongprs__rlc__ul__hdr__egprs.html#ac54ac3dcbec27085b203171cfc95d7e6", null ]
];