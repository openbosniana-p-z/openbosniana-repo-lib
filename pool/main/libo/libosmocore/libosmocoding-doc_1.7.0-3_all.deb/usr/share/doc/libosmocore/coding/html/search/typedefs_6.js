var searchData=
[
  ['ubit_5ft_0',['ubit_t',['../../../core/html/group__bits.html#ga6a432fe43b85ec8e0d13e7de04a3f8ed',1,]]]
];
