var group__use__count =
[
    [ "osmo_use_count_cb_t", "../../core/html/group__use__count.html#ga4497d9dc69e733d16d33a455d385931e", null ],
    [ "_osmo_use_count_get_put", "../../core/html/group__use__count.html#gad3fc149e66e6f9157843169f27ce571a", null ],
    [ "count_safe", "../../core/html/group__use__count.html#gaf2aa74b203011c4359eb13cb886beae7", null ],
    [ "osmo_use_count_by", "../../core/html/group__use__count.html#gae221053a7e938cc89864a29cd72bb971", null ],
    [ "osmo_use_count_create", "../../core/html/group__use__count.html#ga90705ba109a7da55760fba37c5821817", null ],
    [ "osmo_use_count_find", "../../core/html/group__use__count.html#ga0dcc3abaab263ca652b99214f2396298", null ],
    [ "osmo_use_count_free", "../../core/html/group__use__count.html#ga7d4005ec0820c11ef960ea966b6baff9", null ],
    [ "osmo_use_count_make_static_entries", "../../core/html/group__use__count.html#ga1d3601b4f5093407d57ca3f5e1c093cc", null ],
    [ "osmo_use_count_name_buf", "../../core/html/group__use__count.html#ga7b49bfded7003847ba6bcf2e021cb4d9", null ],
    [ "osmo_use_count_repurpose_zero_entry", "../../core/html/group__use__count.html#ga98cee57f336dcd019ccce57563e2b2ea", null ],
    [ "osmo_use_count_to_str_buf", "../../core/html/group__use__count.html#ga0a979c7c3979e7cbb0981172c426a00f", null ],
    [ "osmo_use_count_to_str_c", "../../core/html/group__use__count.html#gac2e6c82a4809bae02212a09ce1e22a21", null ],
    [ "osmo_use_count_total", "../../core/html/group__use__count.html#ga34703c11c4da78bebd3322635b57e698", null ]
];