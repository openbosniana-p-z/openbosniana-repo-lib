var uniongprs__rlc__dl__hdr__egprs =
[
    [ "type1", "uniongprs__rlc__dl__hdr__egprs.html#ac31aa59cf2ac7b1841445616f899a97f", null ],
    [ "type2", "uniongprs__rlc__dl__hdr__egprs.html#aff30509a85db71b7ccbeff1642a26421", null ],
    [ "type3", "uniongprs__rlc__dl__hdr__egprs.html#aafec683e58a2c88a71d86c299827182b", null ]
];