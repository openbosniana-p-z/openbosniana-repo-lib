var searchData=
[
  ['general_2dpurpose_20utility_20functions_0',['General-purpose utility functions',['../../../core/html/group__utils.html',1,'']]],
  ['generic_20subscriber_20update_20protocol_1',['Generic Subscriber Update Protocol',['../../../gsm/html/group__gsup.html',1,'']]],
  ['gprs_20gea3_2fgea4_20ciphering_20algorithm_2',['GPRS GEA3/GEA4 ciphering algorithm',['../../../gsm/html/group__gea.html',1,'']]],
  ['gsm_2008_2e08_20_2f_203gpp_20ts_2048_2e008_20a_20interface_3',['GSM 08.08 / 3GPP TS 48.008 A Interface',['../../../gsm/html/group__gsm0808.html',1,'']]],
  ['gsm_20a5_20ciphering_20algorithm_4',['GSM A5 ciphering algorithm',['../../../gsm/html/group__a5.html',1,'']]],
  ['gsm_2fgprs_2f3g_20authentication_5',['GSM/GPRS/3G Authentication',['../../../gsm/html/group__auth.html',1,'']]],
  ['gsm0408_6',['Gsm0408',['../../../gsm/html/group__gsm0408.html',1,'']]],
  ['gsmtap_7',['GSMTAP',['../../../core/html/group__gsmtap.html',1,'']]]
];
