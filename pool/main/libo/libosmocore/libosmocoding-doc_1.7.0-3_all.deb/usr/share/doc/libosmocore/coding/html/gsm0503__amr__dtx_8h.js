var gsm0503__amr__dtx_8h =
[
    [ "gsm0503_amr_dtx_frames", "group__coding.html#gadca0cb6bbe4f321f8b7e3c14dc9007d8", [
      [ "AMR_OTHER", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8ac6826d44d302961c67736b07d4239b55", null ],
      [ "AFS_SID_FIRST", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a80671ff0cf5f173c6230cd0802e07ec2", null ],
      [ "AFS_SID_UPDATE", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8afd75b6e83edae2b047efdaaa20161ef6", null ],
      [ "AFS_SID_UPDATE_CN", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8aa3b8cd5246b7fcde15c57351aa16e50c", null ],
      [ "AFS_ONSET", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8aa3dcf5ab5a039fd578353b229a200b1a", null ],
      [ "AHS_SID_UPDATE", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8ac36ed3cc9213e59edf0f324bc7897162", null ],
      [ "AHS_SID_UPDATE_CN", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a4f4624db162f8c4d3ecc90dd925ebcee", null ],
      [ "AHS_SID_FIRST_P1", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a77e46e6154c137187772f1694b5878b8", null ],
      [ "AHS_SID_FIRST_P2", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a23b810c20fdfe3f8d178a3b9c37348f9", null ],
      [ "AHS_ONSET", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a3be49f1926262c91664284d77810d633", null ],
      [ "AHS_SID_FIRST_INH", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a58bf29a80404c62271d4dd7d6d33299b", null ],
      [ "AHS_SID_UPDATE_INH", "group__coding.html#ggadca0cb6bbe4f321f8b7e3c14dc9007d8a9d2826bd26f739bf6979dbe0bb89c6d5", null ]
    ] ],
    [ "gsm0503_amr_dtx_frame_name", "group__coding.html#ga3a3fedc575e3f94dee991684e0ff8311", null ],
    [ "gsm0503_detect_afs_dtx_frame", "group__coding.html#ga142a36f1698193812ab3cce476913d39", null ],
    [ "gsm0503_detect_afs_dtx_frame2", "group__coding.html#gae6f7ba026b9c1622324c7c803b409467", null ],
    [ "gsm0503_detect_ahs_dtx_frame", "group__coding.html#ga38e577bf45c242154a1cbfbd75dada89", null ],
    [ "gsm0503_detect_ahs_dtx_frame2", "group__coding.html#ga5edbb45ebf87a4658dec798637adf156", null ],
    [ "gsm0503_amr_dtx_frame_names", "group__coding.html#gac6374b677079e92e9c5503daed4c3f0f", null ]
];