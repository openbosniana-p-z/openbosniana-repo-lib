var structgsm0503__mcs__code =
[
    [ "data_code_len", "structgsm0503__mcs__code.html#aba5f7d9f9658bbbd5950d1a45619d694", null ],
    [ "data_conv", "structgsm0503__mcs__code.html#abfbc4bab7d69f598d9f4fe1bb7f9eea4", null ],
    [ "data_len", "structgsm0503__mcs__code.html#a1d8bfa6dafb72d7a2c10a123bfd49d7a", null ],
    [ "data_punc", "structgsm0503__mcs__code.html#a250dbe83dbebd934daf51ead61ebac78", null ],
    [ "data_punc_len", "structgsm0503__mcs__code.html#a1bbc9c20e6416aaa00d1b8a7bab1abd5", null ],
    [ "hdr_code_len", "structgsm0503__mcs__code.html#a935e6d0cc9656fba1dc44ba1c29c6347", null ],
    [ "hdr_conv", "structgsm0503__mcs__code.html#acb25873173fceb48ea889d77b23120f6", null ],
    [ "hdr_len", "structgsm0503__mcs__code.html#a63c650ba3d50208bbe9aadabea1df006", null ],
    [ "hdr_punc", "structgsm0503__mcs__code.html#a6fbc6ba97edf471a8426b02fd0920874", null ],
    [ "hdr_punc_len", "structgsm0503__mcs__code.html#a287202e409c52872d25e3c811708e644", null ],
    [ "mcs", "structgsm0503__mcs__code.html#ac5d6c2fc8db3ef14244db2f681c04c77", null ],
    [ "usf_len", "structgsm0503__mcs__code.html#a081ddfade7693f97b7d360d353195335", null ]
];