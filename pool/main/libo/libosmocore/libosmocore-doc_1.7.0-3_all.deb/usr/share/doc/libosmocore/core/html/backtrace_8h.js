var backtrace_8h =
[
    [ "osmo_generate_backtrace", "backtrace_8h.html#ae1d7c5276d845c48c0b964a1033b6c60", null ],
    [ "osmo_log_backtrace", "backtrace_8h.html#a89adddebf59157ca25eb6cb422a02151", null ]
];