var group__cpu__sched__VTY =
[
    [ "osmo_cpu_sched_vty_apply_localthread", "../../vty/html/group__cpu__sched__VTY.html#ga5eb944998ac87f1fed307eefdaa25a00", null ],
    [ "osmo_cpu_sched_vty_init", "../../vty/html/group__cpu__sched__VTY.html#ga74c34e2c9306decb850569691ab60361", null ]
];