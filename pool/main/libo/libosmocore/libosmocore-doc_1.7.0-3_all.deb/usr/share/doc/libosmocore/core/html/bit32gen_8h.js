var bit32gen_8h =
[
    [ "osmo_load32be", "bit32gen_8h.html#a1b4573684c9e7f18463c6aff20b96e2b", null ],
    [ "osmo_load32be_ext", "bit32gen_8h.html#aaaff71d90952b66d86511a79456a19d5", null ],
    [ "osmo_load32be_ext_2", "bit32gen_8h.html#a0a71bca2d15d8d95a193cfaaafe18d45", null ],
    [ "osmo_load32le", "bit32gen_8h.html#a4ed4253e2f6ca52cace75eb588a00ad5", null ],
    [ "osmo_load32le_ext", "bit32gen_8h.html#a45a1f2dd1bc797e867a0c72d86aaac26", null ],
    [ "osmo_store32be", "bit32gen_8h.html#a0b58d24b8eedd60bd90cf0d82ab28372", null ],
    [ "osmo_store32be_ext", "bit32gen_8h.html#ad136de8807ae98c8a109532cc0c4c66a", null ],
    [ "osmo_store32le", "bit32gen_8h.html#a1bb4e8a9fddab4ba628163eb609ec10d", null ],
    [ "osmo_store32le_ext", "bit32gen_8h.html#ae965d05b00bf271edbd1c5728f85606f", null ]
];