var panic_8c =
[
    [ "osmo_panic", "group__utils.html#gae8ebb6efd9b30d8d8940f6d71dc32833", null ],
    [ "osmo_panic_default", "group__utils.html#ga1a2fe815e479e972592b48d6919b8a4c", null ],
    [ "osmo_set_panic_handler", "group__utils.html#ga68ffd899763d4c8d24a8df1708b3fe9d", null ],
    [ "osmo_panic_handler", "group__utils.html#gad9bb92023569bababaef4bbf1ed9f99b", null ]
];