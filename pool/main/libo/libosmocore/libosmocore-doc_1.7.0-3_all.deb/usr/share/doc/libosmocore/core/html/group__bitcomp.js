var group__bitcomp =
[
    [ "bitcomp.h", "bitcomp_8h.html", null ],
    [ "bitcomp.c", "bitcomp_8c.html", null ],
    [ "osmo_t4_encode", "group__bitcomp.html#gaa4f70ee3b6e93fff44240366f0b6fedd", null ],
    [ "t4_rle", "group__bitcomp.html#ga756816bc8897122169638ebaa12532c4", null ],
    [ "t4_make_up", "group__bitcomp.html#ga49df6e5268e7a8b4327e5d61ddc0bb04", null ],
    [ "t4_make_up_length", "group__bitcomp.html#ga8149edc38a2202a6fbaf3a39f388e50f", null ],
    [ "t4_term", "group__bitcomp.html#ga23f45a8097583b94fd090f42cb402bd3", null ],
    [ "t4_term_length", "group__bitcomp.html#ga5668d0369e3659129c72d2293da52d7b", null ]
];