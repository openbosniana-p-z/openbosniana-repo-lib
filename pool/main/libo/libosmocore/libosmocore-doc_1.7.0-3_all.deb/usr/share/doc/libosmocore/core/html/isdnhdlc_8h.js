var isdnhdlc_8h =
[
    [ "osmo_isdnhdlc_vars", "structosmo__isdnhdlc__vars.html", "structosmo__isdnhdlc__vars" ],
    [ "OSMO_HDLC_CRC_ERROR", "isdnhdlc_8h.html#a24a5ef2e6d89c76e137dbadd829d37de", null ],
    [ "OSMO_HDLC_F_56KBIT", "isdnhdlc_8h.html#acec3d6758ab5b2c1dd2d9d7c46c29905", null ],
    [ "OSMO_HDLC_F_BITREVERSE", "isdnhdlc_8h.html#af7b5ae113e9012c6c8c2279064e97801", null ],
    [ "OSMO_HDLC_F_DCHANNEL", "isdnhdlc_8h.html#a918fed49abc9e93630fe0153cbaffcd0", null ],
    [ "OSMO_HDLC_FRAMING_ERROR", "isdnhdlc_8h.html#a14341be0f0258c3be70cf859d8a50cd4", null ],
    [ "OSMO_HDLC_LENGTH_ERROR", "isdnhdlc_8h.html#a5dc56dbb97b0b1a761afdbb1a28ecacc", null ],
    [ "osmo_isdnhdlc_decode", "isdnhdlc_8h.html#a7b51c27274ca2cccf23b4e868c7b6710", null ],
    [ "osmo_isdnhdlc_encode", "isdnhdlc_8h.html#a1b8eb0afa747804742eab4c1d59494c2", null ],
    [ "osmo_isdnhdlc_out_init", "isdnhdlc_8h.html#abe1a5cfbb77cc0324b1ac506cbc8967d", null ],
    [ "osmo_isdnhdlc_rcv_init", "isdnhdlc_8h.html#a98822a5ed1411cc5e7261f1e1e991152", null ]
];