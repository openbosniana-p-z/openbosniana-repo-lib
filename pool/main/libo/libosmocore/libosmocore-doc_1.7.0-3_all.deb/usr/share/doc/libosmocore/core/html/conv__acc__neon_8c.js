var conv__acc__neon_8c =
[
    [ "NEON_ALIGN", "conv__acc__neon_8c.html#a5486ad7225f22912ce136f208fefc237", null ],
    [ "__attribute__", "conv__acc__neon_8c.html#a654f220adbb8eaed520587f774ec00d3", null ]
];