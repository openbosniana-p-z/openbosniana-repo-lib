var byteswap_8h =
[
    [ "osmo_htonl", "byteswap_8h.html#afabda0c0661d96ff87e119997d5bddd1", null ],
    [ "osmo_htons", "byteswap_8h.html#a621e194c5a89c0c9f0a80168635c8080", null ],
    [ "osmo_ntohl", "byteswap_8h.html#a0da869fce11ebea3432d08317874f200", null ],
    [ "osmo_ntohs", "byteswap_8h.html#ab3adb87b4c847819b29c359c19fed0c2", null ],
    [ "osmo_swab16", "byteswap_8h.html#ace04f7608464f154baf391b0930372fb", null ],
    [ "osmo_swab32", "byteswap_8h.html#a6fd5d55d9e5caf60897287cf4b0984d2", null ]
];