var application_8h =
[
    [ "osmo_daemonize", "application_8h.html#aa6ae82e2c37662eda7093d3db1b3b830", null ],
    [ "osmo_init_ignore_signals", "application_8h.html#a38dc37d2cf97c98bcb1d713794ff2a75", null ],
    [ "osmo_init_logging", "application_8h.html#a4fd763edd744e7df28f7c48eef0676ae", null ],
    [ "osmo_init_logging2", "application_8h.html#a4b11cf941dd9e32e89bd24d56a808ecc", null ],
    [ "osmo_stderr_target", "application_8h.html#a2f56746f90c8f8065e8f33c007e5505e", null ]
];