var logging__gsmtap_8c =
[
    [ "GSMTAP_LOG_MAX_SIZE", "group__logging.html#ga243618945b3967a6eb290d1454f6d1e7", null ],
    [ "_gsmtap_raw_output", "group__logging.html#gadcb5d64707df94b5f4aa8671936a335e", null ],
    [ "log_target_create_gsmtap", "group__logging.html#ga4efed74fd274a942527f6c311ff5d4e9", null ],
    [ "logging_gsmtap_tid", "group__logging.html#ga717d59129ea36f1cff741576ca246a46", null ]
];