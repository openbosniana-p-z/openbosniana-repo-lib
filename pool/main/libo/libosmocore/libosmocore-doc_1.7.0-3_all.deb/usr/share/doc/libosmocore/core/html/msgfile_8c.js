var msgfile_8c =
[
    [ "_WITH_GETLINE", "msgfile_8c.html#af0f7b0f33fcbbfbf92bf1cf729b2f23c", null ],
    [ "alloc_entries", "msgfile_8c.html#a8c50eedf1ddacea2debd0c8f92b40860", null ],
    [ "alloc_entry", "msgfile_8c.html#a48ad4d6a44a7c97f67379b1472745535", null ],
    [ "handle_line", "msgfile_8c.html#a00d6e2267c4785f1a12b9ee94941d6a9", null ],
    [ "osmo_config_list_parse", "msgfile_8c.html#a40305f9090e1954fcf45028a49457105", null ]
];