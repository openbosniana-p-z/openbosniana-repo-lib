var bits_8c =
[
    [ "osmo_bit_reversal", "group__bits.html#gae4f3c9fa5d7ac188213d59dd8f83da40", null ],
    [ "osmo_nibble_shift_left_unal", "group__bits.html#ga720f02d3e0b8ead8892ea2796551d5cf", null ],
    [ "osmo_nibble_shift_right", "group__bits.html#gacc781ff2ed10005457258a5f435c96fb", null ],
    [ "osmo_pbit2ubit", "group__bits.html#ga6061c0bccf3149afbfd3717655926610", null ],
    [ "osmo_pbit2ubit_ext", "group__bits.html#ga7978cf8714618d6682751058818444c6", null ],
    [ "osmo_revbytebits_32", "group__bits.html#ga7c83c316140d1209f4b2dc83b3eea5cf", null ],
    [ "osmo_revbytebits_8", "group__bits.html#gafe16634bf4f34bd4dd0f7bc5dcf54e33", null ],
    [ "osmo_revbytebits_buf", "group__bits.html#gab44abd4982a164c8e2e5588d9fd81852", null ],
    [ "osmo_sbit2ubit", "group__bits.html#ga520d72b80bd83e41b58afe012005984f", null ],
    [ "osmo_ubit2pbit", "group__bits.html#ga0396755b3f1fb67dda62c6310bcefae5", null ],
    [ "osmo_ubit2pbit_ext", "group__bits.html#ga55b990334c0b0188134d42b6a201d6bc", null ],
    [ "osmo_ubit2sbit", "group__bits.html#ga9a76a29b0916e9cd26c5ca65dbbfb325", null ],
    [ "flip_table", "group__bits.html#ga7cc2859ee2b88036f7229b3e5102dfbe", null ]
];