var bit16gen_8h =
[
    [ "osmo_load16be", "bit16gen_8h.html#ac4316e9600be38095bd3cf9c9ba36034", null ],
    [ "osmo_load16be_ext", "bit16gen_8h.html#a450dbd88d8858eeb5de9c76f6f02b214", null ],
    [ "osmo_load16be_ext_2", "bit16gen_8h.html#a5ec2fa851cfe3fe89e4e1cfd717a38af", null ],
    [ "osmo_load16le", "bit16gen_8h.html#ac889036814030b1d0cc125fcc17e3718", null ],
    [ "osmo_load16le_ext", "bit16gen_8h.html#adaa9cbfc6f37448b137dceb82eb9b799", null ],
    [ "osmo_store16be", "bit16gen_8h.html#a1b4030030fde2f0d8ff27ea8ac3875fb", null ],
    [ "osmo_store16be_ext", "bit16gen_8h.html#a6a99c7969c0b344390345c9a3fa2caec", null ],
    [ "osmo_store16le", "bit16gen_8h.html#a940ae5f8a6b23f79393b3d12085b1a40", null ],
    [ "osmo_store16le_ext", "bit16gen_8h.html#a0a17886ab7c6a2fcccb2cdad11d98edb", null ]
];