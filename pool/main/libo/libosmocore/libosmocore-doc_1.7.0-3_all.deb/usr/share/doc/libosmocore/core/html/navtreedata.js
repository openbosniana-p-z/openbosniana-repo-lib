/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "libosmocore", "index.html", [
    [ "libosmocore Documentation", "index.html", [
      [ "Introduction", "index.html#sec_intro", null ],
      [ "Copyright and License", "index.html#sec_copyright", null ],
      [ "Homepage + Issue Tracker", "index.html#sec_tracker", null ],
      [ "Contact and Support", "index.html#sec_contact", null ]
    ] ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"functions_v.html",
"group__auth.html#ga9dff639ca2b73a4c652735c1c9a11d81",
"group__bssmap__le.html#gaee2acf440831bf44bfd394732058cef4",
"group__command.html#ga4cb0437b409b4956cae6595684c2a26b",
"group__fsm.html#ga6f501668d6d818fc87f1b18425356b19",
"group__gsm0808.html#ga429d802f8751e5394e3993bca798bd83",
"group__gsup.html#gga9f3f0838120b5d318a7548ea6cfece57a88b2d0f2d1df1af769e2677205e0e5d1",
"group__libgb.html#ga07c13484b7fee94a56f3079de207fc38",
"group__libgb.html#gga138e965973b71fed1f70981f85166f54abd3ea35fb5dd1adaf7920d7e46edc9ad",
"group__logging.html#gaf69d0014231702905b70af36ba2161d6",
"group__oml.html#gafc997e7db6a7ffc38854f419e44192ac",
"group__oml.html#gga94d045fc2adef7395390ee0e0265e33eae562568c480177449a4bd0187d2c0296",
"group__oml.html#ggac6da50805b351f6e1afce57ced59a9d5aad37501836c547e78a6fa2ac06659f26",
"group__rsl.html#gga3311798953086607584abed72b0b53dca3dc09cb7b514fecee82636f2235cc3e8",
"group__rsl.html#ggabbaa12e93081369becdd6fe0f46579f8a884954d5e36d161183eff0eb2513edd0",
"group__socket.html#ga85e86cf67b2c967170b6a9068eb1a98d",
"group__timer.html#gaaf525183a6e0d9903a2511619c57d2ce",
"group__vty.html#ga3237e741f1477116d22636f36555d563",
"isdnhdlc_8c.html#a1b8eb0afa747804742eab4c1d59494c2",
"structlog__target.html#aa5bb6f9bd13aa6bde09d52451ace29e4",
"structosmo__stats__reporter.html#a58d133ff97380412ca2cc71de2444357"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';