var conv_8h =
[
    [ "osmo_conv_term", "group__conv.html#gaf0fd132530ce2b394bad052c7242590e", [
      [ "CONV_TERM_FLUSH", "group__conv.html#ggaf0fd132530ce2b394bad052c7242590ea255ffa13977bc3a7513d90485123e7c2", null ],
      [ "CONV_TERM_TRUNCATION", "group__conv.html#ggaf0fd132530ce2b394bad052c7242590eadd3d6c82aa9a0be1f38479f89d6c1b04", null ],
      [ "CONV_TERM_TAIL_BITING", "group__conv.html#ggaf0fd132530ce2b394bad052c7242590ea63bb13a152bdb0b61594e10aabe990c1", null ]
    ] ],
    [ "osmo_conv_decode", "group__conv.html#ga8eb8fcdfe0d49890927a6ce7bfc921dc", null ],
    [ "osmo_conv_decode_deinit", "group__conv.html#gac5eaa9e63f2f78c65070dfdbd8f8cd88", null ],
    [ "osmo_conv_decode_flush", "group__conv.html#gad6eea080a67fdcecfc6d108d07d37c3c", null ],
    [ "osmo_conv_decode_get_best_end_state", "group__conv.html#gad2d7bb7224a7362c048f3c147c09c106", null ],
    [ "osmo_conv_decode_get_output", "group__conv.html#ga123033117643f7c2ea610cbc21cfeeb7", null ],
    [ "osmo_conv_decode_init", "group__conv.html#ga8d62497e9411049141f699d67068b1ab", null ],
    [ "osmo_conv_decode_reset", "group__conv.html#ga5b03fc1ff68f02690c1e6536f4a44562", null ],
    [ "osmo_conv_decode_rewind", "group__conv.html#ga118b5aec8b6ad0eb45f0cb2bc96525af", null ],
    [ "osmo_conv_decode_scan", "group__conv.html#ga8c0b5474a256cc21ba605bf2594468bc", null ],
    [ "osmo_conv_encode", "group__conv.html#ga928c04825469cc3481be1717d69534d6", null ],
    [ "osmo_conv_encode_flush", "group__conv.html#gac54f3af7b08df20b530694ee3a660918", null ],
    [ "osmo_conv_encode_init", "group__conv.html#ga729a0ee108fb0f830aef9652acb1f998", null ],
    [ "osmo_conv_encode_load_state", "group__conv.html#gacd456a6e66cd06364000d83b9d4a9c5f", null ],
    [ "osmo_conv_encode_raw", "group__conv.html#ga15d88c910f3072194278d42582162872", null ],
    [ "osmo_conv_get_input_length", "group__conv.html#gaa1382de36811cc10f218b877cad5c2d5", null ],
    [ "osmo_conv_get_output_length", "group__conv.html#ga278e64b79e6b589c835a0c401fde3660", null ]
];