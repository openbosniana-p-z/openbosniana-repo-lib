var conv__acc__neon__impl_8h =
[
    [ "__always_inline", "conv__acc__neon__impl_8h.html#a6034e8cd4bcd5bacfd060abd01bbd8a8", null ],
    [ "NEON_BRANCH_METRIC_N2", "conv__acc__neon__impl_8h.html#a61dbf015c8f61eb5d7775df881ec7daa", null ],
    [ "NEON_BRANCH_METRIC_N4", "conv__acc__neon__impl_8h.html#a64763794a6958e9f6353ca647c34035e", null ],
    [ "NEON_BUTTERFLY", "conv__acc__neon__impl_8h.html#a3fd71b2646da81cd331245dd0a99f3e7", null ],
    [ "NEON_DEINTERLEAVE_K5", "conv__acc__neon__impl_8h.html#a64a643c2264cb3d2037c1b5a92d75029", null ],
    [ "NEON_DEINTERLEAVE_K7", "conv__acc__neon__impl_8h.html#a2c3b91ddfe96dab0e7c38ab4a49cf96b", null ],
    [ "NEON_NORMALIZE_K5", "conv__acc__neon__impl_8h.html#a4ba3dac6cf9e3e6b295aa3cd4f7caea3", null ],
    [ "NEON_NORMALIZE_K7", "conv__acc__neon__impl_8h.html#a4abb399cb2e95aa683d4f3fa4cd62162", null ],
    [ "_neon_metrics_k5_n2", "conv__acc__neon__impl_8h.html#a29280174a1b24c944278ea50645d8fc0", null ],
    [ "_neon_metrics_k5_n4", "conv__acc__neon__impl_8h.html#ad117402b21d34712927b710cf3bfaca7", null ],
    [ "_neon_metrics_k7_n2", "conv__acc__neon__impl_8h.html#a6599ef80e063b632c50e57f189d8c28b", null ],
    [ "_neon_metrics_k7_n4", "conv__acc__neon__impl_8h.html#afb3c3ff371dab9cfef30df2b298aafab", null ]
];