var group__Tdef =
[
    [ "tdef.h", "tdef_8h.html", null ],
    [ "tdef.c", "tdef_8c.html", null ],
    [ "osmo_tdef", "structosmo__tdef.html", [
      [ "default_val", "structosmo__tdef.html#aaa301306dcdf81c075ca03365ad43738", null ],
      [ "desc", "structosmo__tdef.html#aa5a127f1c816e6f053a8a7b48920b6e9", null ],
      [ "max_val", "structosmo__tdef.html#a929442b826d692030796a49485436b9b", null ],
      [ "min_val", "structosmo__tdef.html#ae67d57826e38571645a9059ffa83327e", null ],
      [ "T", "structosmo__tdef.html#aa8fdd929b165511b9c68b5a8a73ea420", null ],
      [ "unit", "structosmo__tdef.html#a0e6ea0f73fe65cde08e50431d503c5f9", null ],
      [ "val", "structosmo__tdef.html#ae81b5f0c2bda9bb71b5fdd6fd8ea167e", null ]
    ] ],
    [ "osmo_tdef_state_timeout", "structosmo__tdef__state__timeout.html", [
      [ "keep_timer", "structosmo__tdef__state__timeout.html#a8a9095a9c9a8a7d9366a1c5349f68c80", null ],
      [ "T", "structosmo__tdef__state__timeout.html#a8ba74f7cd70582e4f9945203c0ff49f8", null ]
    ] ],
    [ "osmo_tdef_group", "structosmo__tdef__group.html", [
      [ "desc", "structosmo__tdef__group.html#ad11412b90aaa50cb49064974e2d4c807", null ],
      [ "name", "structosmo__tdef__group.html#a578907f52be5ebac44fef3f4d36ec129", null ],
      [ "tdefs", "structosmo__tdef__group.html#a5ba4012c7110a5464498ac7199558095", null ]
    ] ],
    [ "osmo_tdef_for_each", "group__Tdef.html#ga9bfa6d2933254ee56979be1f0230cf71", null ],
    [ "osmo_tdef_fsm_inst_state_chg", "group__Tdef.html#ga62ef360585a2162bcac01c588025ce97", null ],
    [ "osmo_tdef_groups_for_each", "group__Tdef.html#ga6b2e21ca953ab535e36f9b851d9558a5", null ],
    [ "osmo_tdef_unit", "group__Tdef.html#gaab870deed1871d59911bcd465b410f6a", [
      [ "OSMO_TDEF_S", "group__Tdef.html#ggaab870deed1871d59911bcd465b410f6aacd7acf38bfb806b297369d3967b8151d", null ],
      [ "OSMO_TDEF_MS", "group__Tdef.html#ggaab870deed1871d59911bcd465b410f6aae9571204a5e1dc1b575f94c11bc47474", null ],
      [ "OSMO_TDEF_M", "group__Tdef.html#ggaab870deed1871d59911bcd465b410f6aa757bb613b8f209d4d9e0c2d6622e06bc", null ],
      [ "OSMO_TDEF_CUSTOM", "group__Tdef.html#ggaab870deed1871d59911bcd465b410f6aa12615b1124e5e25e0a0ad4e5b13adef5", null ],
      [ "OSMO_TDEF_US", "group__Tdef.html#ggaab870deed1871d59911bcd465b410f6aa4cf1495f9310e61a17527be25486e4cc", null ]
    ] ],
    [ "_osmo_tdef_fsm_inst_state_chg", "group__Tdef.html#ga0f528b78c3b8875971f0fcbbaa52e1c6", null ],
    [ "_osmo_tdef_fsm_inst_state_chg", "group__Tdef.html#ga0949811a3638747d3ba5fc2eeba9b94c", null ],
    [ "osmo_tdef_factor", "group__Tdef.html#gae2c06fad8c067d3ae2d6ebbaa133e070", null ],
    [ "osmo_tdef_get", "group__Tdef.html#ga1902036c8ce361a6ba043b90f3026ae7", null ],
    [ "osmo_tdef_get_entry", "group__Tdef.html#ga165520a7b18876662703753759941e00", null ],
    [ "osmo_tdef_get_state_timeout", "group__Tdef.html#ga5a7532bad13a88526390b8f3c6db3374", null ],
    [ "osmo_tdef_range_str_buf", "group__Tdef.html#ga88e3725d03ea8ab0edf8013333dfedad", null ],
    [ "osmo_tdef_round", "group__Tdef.html#ga95e55c67fc577ce73009b70f1a3c432b", null ],
    [ "osmo_tdef_set", "group__Tdef.html#gab2f59867f10a781019db1d52c991ce95", null ],
    [ "osmo_tdef_unit_name", "group__Tdef.html#ga0625620798fea884f7a63efbc58defd1", null ],
    [ "osmo_tdef_val_in_range", "group__Tdef.html#ga4b9908c0c45f1226f4fae760141d54b4", null ],
    [ "osmo_tdefs_reset", "group__Tdef.html#ga0a2cda1d30e23023cc179b68b8c624e6", null ],
    [ "osmo_tdef_unit_names", "group__Tdef.html#ga4ad5be5f9d49274b4bce18320cf251b5", null ],
    [ "osmo_tdef_unit_names", "group__Tdef.html#ga4ad5be5f9d49274b4bce18320cf251b5", null ]
];