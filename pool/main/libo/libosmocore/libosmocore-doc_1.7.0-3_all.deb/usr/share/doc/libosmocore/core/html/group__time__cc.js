var group__time__cc =
[
    [ "time_cc.h", "time__cc_8h.html", null ],
    [ "time_cc.c", "time__cc_8c.html", null ],
    [ "osmo_time_cc_cfg", "structosmo__time__cc__cfg.html", [
      [ "forget_sum_usec", "structosmo__time__cc__cfg.html#af7181e34adbc13ec64a3ab90bbc3c0e2", null ],
      [ "gran_usec", "structosmo__time__cc__cfg.html#a93be973a22fb778609777a0882c612f8", null ],
      [ "rate_ctr", "structosmo__time__cc__cfg.html#aa01fa71082702abfeebac2d62ac12b3a", null ],
      [ "round_threshold_usec", "structosmo__time__cc__cfg.html#aceacac547554ccb755b66114af5971ae", null ],
      [ "T_defs", "structosmo__time__cc__cfg.html#af64ab35d0ec6ed887d568d5ec226c6db", null ],
      [ "T_forget_sum", "structosmo__time__cc__cfg.html#a18a69cabb36510378162fbf66b818cd5", null ],
      [ "T_gran", "structosmo__time__cc__cfg.html#addce4e6f974d5a0d734388dd9b3eb52b", null ],
      [ "T_round_threshold", "structosmo__time__cc__cfg.html#aea10d0878ae511a70182038011fa02a4", null ]
    ] ],
    [ "osmo_time_cc", "structosmo__time__cc.html", [
      [ "cfg", "structosmo__time__cc.html#a2baaec831f2a84fc42e884b0db2fcda9", null ],
      [ "flag_state", "structosmo__time__cc.html#a81138b0a4b00edd05220d2b2e4a9e2b9", null ],
      [ "last_counted_time", "structosmo__time__cc.html#a657c939b1574a736235defbe1fe5f8f1", null ],
      [ "reported_sum", "structosmo__time__cc.html#ab049651207b2d4207c38320c2fa6a881", null ],
      [ "start_time", "structosmo__time__cc.html#abb648f545ea2521e6688f4c39324a469", null ],
      [ "sum", "structosmo__time__cc.html#a296baa4bd538ac56e9a07bee8c48010a", null ],
      [ "timer", "structosmo__time__cc.html#a96ef07961091e1f8926b8d98ff9684b9", null ],
      [ "total_sum", "structosmo__time__cc.html#a09624b09c014251d80d28f8d0938c086", null ]
    ] ],
    [ "osmo_time_cc_cleanup", "group__time__cc.html#ga4586caf5730ea675afb0dfd64a1ade32", null ],
    [ "osmo_time_cc_init", "group__time__cc.html#gad234a5e207b1cef57390a2390ed8fc8e", null ],
    [ "osmo_time_cc_set_flag", "group__time__cc.html#ga1feb41a008ddeffe6b77a8d2569a14d4", null ]
];