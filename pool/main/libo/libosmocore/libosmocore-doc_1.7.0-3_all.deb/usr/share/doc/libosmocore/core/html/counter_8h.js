var counter_8h =
[
    [ "osmo_counter", "structosmo__counter.html", "structosmo__counter" ],
    [ "osmo_counter_alloc", "counter_8h.html#a25b161274af8c472e6dc3dd5bf5dd20d", null ],
    [ "osmo_counter_dec", "counter_8h.html#ab551812fda9da1fb0858ec791267632f", null ],
    [ "osmo_counter_difference", "counter_8h.html#a53ab8cd2ac269f632b30043674809564", null ],
    [ "osmo_counter_free", "counter_8h.html#a8fd223ccc11465261d0043498f3b7fc6", null ],
    [ "osmo_counter_get", "counter_8h.html#a9f0b07a713aefe7017cf5a588837cab5", null ],
    [ "osmo_counter_get_by_name", "counter_8h.html#a097b54f74643595cace122522a46894a", null ],
    [ "osmo_counter_inc", "counter_8h.html#a144d8342099d8071512bee17cbd2d4e3", null ],
    [ "osmo_counter_reset", "counter_8h.html#a7eb52944abbb34018fc30f6441d2815d", null ],
    [ "osmo_counters_count", "counter_8h.html#af3a51464b7c8a8f0ee01b226859ec523", null ],
    [ "osmo_counters_for_each", "counter_8h.html#a13522cfb91c1dd87cfa9d9b246676666", null ]
];