var conv__acc__sse__impl_8h =
[
    [ "__always_inline", "conv__acc__sse__impl_8h.html#a6034e8cd4bcd5bacfd060abd01bbd8a8", null ],
    [ "_I8_SHUFFLE_MASK", "conv__acc__sse__impl_8h.html#a32bc7adf90d8074af148ff6e860290e8", null ],
    [ "SSE_BRANCH_METRIC_N2", "conv__acc__sse__impl_8h.html#ac5e8b6e3204d8654e419417be1285db6", null ],
    [ "SSE_BRANCH_METRIC_N4", "conv__acc__sse__impl_8h.html#a369ef2013e844532b4d1989f29d82aa3", null ],
    [ "SSE_BUTTERFLY", "conv__acc__sse__impl_8h.html#ab4e031931b03d7b9decbc71c2dbbc80b", null ],
    [ "SSE_DEINTERLEAVE_K5", "conv__acc__sse__impl_8h.html#a58edda3346794850db562009f2984a1a", null ],
    [ "SSE_DEINTERLEAVE_K7", "conv__acc__sse__impl_8h.html#aecdecf201864014e331627daf0d15c4c", null ],
    [ "SSE_MINPOS", "conv__acc__sse__impl_8h.html#ad7c53e0ea13f56dafb49015aa6afde42", null ],
    [ "SSE_NORMALIZE_K5", "conv__acc__sse__impl_8h.html#a6dc79ea42923356306d5ce8c4019d3b8", null ],
    [ "SSE_NORMALIZE_K7", "conv__acc__sse__impl_8h.html#a6e3fa7c5ff1e4d3e244cbdf0a3bffa4b", null ],
    [ "_sse_metrics_k5_n2", "conv__acc__sse__impl_8h.html#ace021df37858dc9c7e2ffeeb5363dd16", null ],
    [ "_sse_metrics_k5_n4", "conv__acc__sse__impl_8h.html#aebbd89119405132383c7f54f818f1209", null ],
    [ "_sse_metrics_k7_n2", "conv__acc__sse__impl_8h.html#ae9ec7cd678c977a8289320f3d4643415", null ],
    [ "_sse_metrics_k7_n4", "conv__acc__sse__impl_8h.html#a82595fc4ef1bacd8b4a74d8f59277e0c", null ],
    [ "sse41_supported", "conv__acc__sse__impl_8h.html#ab87cb89f0af5dcfad8c409b0367997e5", null ]
];