var bit64gen_8h =
[
    [ "osmo_load64be", "bit64gen_8h.html#ac37a729baf4be619a2e50a960754b17b", null ],
    [ "osmo_load64be_ext", "bit64gen_8h.html#aaf77aa28a4f0e968e28c6f498a2e8ea9", null ],
    [ "osmo_load64be_ext_2", "bit64gen_8h.html#ad04fd7112f2b0b5c532ab48598807171", null ],
    [ "osmo_load64le", "bit64gen_8h.html#a807ef287aed34ef394e0296c2199ab9d", null ],
    [ "osmo_load64le_ext", "bit64gen_8h.html#a1dbb4054dc1c02e53b4f74835e8ea712", null ],
    [ "osmo_store64be", "bit64gen_8h.html#aa6c599f3b43767a7771fc93e1723c07a", null ],
    [ "osmo_store64be_ext", "bit64gen_8h.html#acd56fa8fc8e4ed1d4956769fa8862dbb", null ],
    [ "osmo_store64le", "bit64gen_8h.html#af9603548303f49aaac70953a2ee63046", null ],
    [ "osmo_store64le_ext", "bit64gen_8h.html#afb48fab8193e98a7986bc4657e66c9c4", null ]
];