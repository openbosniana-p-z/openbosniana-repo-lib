var panic_8h =
[
    [ "osmo_panic_handler_t", "group__utils.html#ga23bc29d21400af02d00e4741d96b8e73", null ],
    [ "osmo_panic", "group__utils.html#gae8ebb6efd9b30d8d8940f6d71dc32833", null ],
    [ "osmo_set_panic_handler", "group__utils.html#ga68ffd899763d4c8d24a8df1708b3fe9d", null ]
];