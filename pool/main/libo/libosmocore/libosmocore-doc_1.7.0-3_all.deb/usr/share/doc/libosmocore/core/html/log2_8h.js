var log2_8h =
[
    [ "const_ilog2", "log2_8h.html#a0e7c5d1dd4692f218a831d07bca5c644", null ],
    [ "ilog2", "log2_8h.html#a2696c6303d4c53b65a3a7f7ff771d5eb", null ],
    [ "__attribute__", "log2_8h.html#ae65d92d58bfeb475d2e2b2a66b2383bd", null ],
    [ "__attribute__", "log2_8h.html#a9d5473a6b33c7daafcf50f3849a40830", null ]
];