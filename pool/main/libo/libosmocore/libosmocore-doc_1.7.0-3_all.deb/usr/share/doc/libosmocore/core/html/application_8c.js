var application_8c =
[
    [ "osmo_daemonize", "application_8c.html#aa6ae82e2c37662eda7093d3db1b3b830", null ],
    [ "osmo_init_ignore_signals", "application_8c.html#a38dc37d2cf97c98bcb1d713794ff2a75", null ],
    [ "osmo_init_logging", "application_8c.html#a44188167ba583111b73c1bd983ffe32f", null ],
    [ "osmo_init_logging2", "application_8c.html#a4b11cf941dd9e32e89bd24d56a808ecc", null ],
    [ "sighup_hdlr", "application_8c.html#a4f4e1198dab0d79568b59722aceba92c", null ],
    [ "osmo_stderr_target", "application_8c.html#a2f56746f90c8f8065e8f33c007e5505e", null ]
];