var prim_8h =
[
    [ "_SAP_GSM_BASE", "group__prim.html#gafede4906436eeaac53464216f112a2d9", null ],
    [ "_SAP_GSM_SHIFT", "group__prim.html#gaa9cc671e11971c5cbd2e8fbe9c5de332", null ],
    [ "_SAP_SS7_BASE", "group__prim.html#ga7f7c1f3030da0d2aa57f4c69a99d06e9", null ],
    [ "_SAP_TETRA_BASE", "group__prim.html#ga66ac978ed015c4111d846c5e1dee1449", null ],
    [ "OSMO_NO_EVENT", "group__prim.html#gaada260e79492bf89c208db9184174459", null ],
    [ "OSMO_PRIM", "group__prim.html#ga173c203440160e63e5c588870638607a", null ],
    [ "OSMO_PRIM_HDR", "group__prim.html#ga43873bb5609b3d8c72a740c095264b3b", null ],
    [ "osmo_prim_cb", "group__prim.html#gab56d32c84797be881ccafdebe4b78b2a", null ],
    [ "osmo_prim_operation", "group__prim.html#ga5bd3196233677c8e9ab66b6fb97060d3", [
      [ "PRIM_OP_REQUEST", "group__prim.html#gga5bd3196233677c8e9ab66b6fb97060d3aef3a9ebe139f54ca2c1dae8b65c6880e", null ],
      [ "PRIM_OP_RESPONSE", "group__prim.html#gga5bd3196233677c8e9ab66b6fb97060d3af62503bb7df5fde38f9359b591028dc1", null ],
      [ "PRIM_OP_INDICATION", "group__prim.html#gga5bd3196233677c8e9ab66b6fb97060d3a6987bf8560df352ada9979b4457f9f0d", null ],
      [ "PRIM_OP_CONFIRM", "group__prim.html#gga5bd3196233677c8e9ab66b6fb97060d3aee86a39134232ad0417a13ef1f8e53bf", null ]
    ] ],
    [ "osmo_event_for_prim", "group__prim.html#ga65cffc8b84a2c3d2f200560096810695", null ],
    [ "osmo_prim_init", "group__prim.html#gaf826713c118d129aff1a700a742552c4", null ],
    [ "osmo_prim_op_names", "group__prim.html#ga886b7582fd2947d0582cd8c9acd30cc9", null ]
];