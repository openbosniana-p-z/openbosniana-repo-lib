var msgfile_8h =
[
    [ "osmo_config_entry", "structosmo__config__entry.html", "structosmo__config__entry" ],
    [ "osmo_config_list", "structosmo__config__list.html", "structosmo__config__list" ],
    [ "osmo_config_list_parse", "msgfile_8h.html#a40305f9090e1954fcf45028a49457105", null ]
];