var prim_8c =
[
    [ "osmo_event_for_prim", "group__prim.html#ga65cffc8b84a2c3d2f200560096810695", null ],
    [ "osmo_prim_op_names", "group__prim.html#ga886b7582fd2947d0582cd8c9acd30cc9", null ]
];