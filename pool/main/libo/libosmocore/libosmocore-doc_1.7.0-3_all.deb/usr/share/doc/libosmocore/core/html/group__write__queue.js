var group__write__queue =
[
    [ "write_queue.h", "write__queue_8h.html", null ],
    [ "write_queue.c", "write__queue_8c.html", null ],
    [ "osmo_wqueue", "structosmo__wqueue.html", [
      [ "bfd", "structosmo__wqueue.html#a57c285118552bc1dfe4800c902bb0719", null ],
      [ "current_length", "structosmo__wqueue.html#a7f42a77dae317a74b151cc76480f6729", null ],
      [ "except_cb", "structosmo__wqueue.html#a89018e4a1d9eae9790b19f2c886fa077", null ],
      [ "max_length", "structosmo__wqueue.html#a1ac0b48a931de4c45ce432098adc5a04", null ],
      [ "msg_queue", "structosmo__wqueue.html#a01ef6782c5706b22d5e72d724a742bed", null ],
      [ "read_cb", "structosmo__wqueue.html#af34ee3f3e80707ce0d9f0e8d09d46150", null ],
      [ "write_cb", "structosmo__wqueue.html#aac8455731a29b598880872f177ca483c", null ]
    ] ],
    [ "osmo_wqueue_bfd_cb", "group__write__queue.html#ga56bb1b9d13a946be09fdbf400545d7ad", null ],
    [ "osmo_wqueue_clear", "group__write__queue.html#ga833b4f5244c00c775260a83e9918073c", null ],
    [ "osmo_wqueue_enqueue", "group__write__queue.html#ga9855de966a4f01d6df3a747422b02824", null ],
    [ "osmo_wqueue_enqueue_quiet", "group__write__queue.html#ga7d4207497c2a2852f98ecf805424a504", null ],
    [ "osmo_wqueue_init", "group__write__queue.html#gacca6343dd66b8cac8a5055b2a16eb990", null ]
];