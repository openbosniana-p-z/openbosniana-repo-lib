var group__signal =
[
    [ "signal.h", "signal_8h.html", null ],
    [ "signal.c", "signal_8c.html", null ],
    [ "signal_handler", "structsignal__handler.html", [
      [ "cbfn", "structsignal__handler.html#ab656dc13121c101cede66d00dd47cef4", null ],
      [ "data", "structsignal__handler.html#abda94e2f563b0ea32df0429d12297678", null ],
      [ "entry", "structsignal__handler.html#aaf978cda06aa1baee2fea4bb483a3146", null ],
      [ "subsys", "structsignal__handler.html#a7abd0007161ea6e47b5f6244011f92c5", null ]
    ] ],
    [ "OSMO_SIGNAL_SS_APPS", "group__signal.html#gabf1fd02256768cfed6356d8434e3163a", null ],
    [ "OSMO_SIGNAL_SS_RESERVED", "group__signal.html#gaea2126eb1859066374a148c5929fc901", null ],
    [ "OSMO_SIGNAL_T_APPS", "group__signal.html#ga24a50e4e7f446e4b595ce13b66418eeb", null ],
    [ "OSMO_SIGNAL_T_RESERVED", "group__signal.html#ga2e48d094a85446edcb2a9a8b2d7adb34", null ],
    [ "osmo_signal_cbfn", "group__signal.html#gae1e33b4b31b9aa6d224de68053dcb1ce", [
      [ "SS_L_GLOBAL", "group__signal.html#ggadb49720dc49f7d4e4cf9adbf2948e409a1c16e247915ba903f0b15dd21f33f924", null ],
      [ "SS_L_INPUT", "group__signal.html#ggadb49720dc49f7d4e4cf9adbf2948e409a0f74e71436faadd50e466563f7f5fabd", null ],
      [ "SS_L_NS", "group__signal.html#ggadb49720dc49f7d4e4cf9adbf2948e409aea1b3aaafcf5689c71b9db0e2db8ab7d", null ],
      [ "SS_L_VTY", "group__signal.html#ggadb49720dc49f7d4e4cf9adbf2948e409a3b46c605181dbc6523c86e9e66b76004", null ],
      [ "S_L_GLOBAL_SHUTDOWN", "group__signal.html#ggaae05225933a42f81e7c4a9fb286596f9a4332cdc80e697a91f1f95b89b59216be", null ]
    ] ],
    [ "LLIST_HEAD", "group__signal.html#gaa46f0e38b6dcdd49627b6d171d51e9c5", null ],
    [ "osmo_signal_dispatch", "group__signal.html#ga8eb0fdf74d9ae54383b10cb88792a008", null ],
    [ "osmo_signal_register_handler", "group__signal.html#ga34e5e27e85ffdaa63744cf9e97468807", null ],
    [ "osmo_signal_talloc_ctx_init", "group__signal.html#gacbbc59427aa2fd838becc61d3443ca44", null ],
    [ "osmo_signal_unregister_handler", "group__signal.html#ga62da9d737e40883ac0d15b7b3bc049fb", null ],
    [ "tall_sigh_ctx", "group__signal.html#ga2dd2b6ac5a7a35b5c834ccf82361e39b", null ]
];