var group__use__count =
[
    [ "use_count.h", "use__count_8h.html", null ],
    [ "use_count.c", "use__count_8c.html", null ],
    [ "osmo_use_count", "structosmo__use__count.html", [
      [ "talloc_object", "structosmo__use__count.html#a931dcee6ec7160ea3dda64f6190d0a7e", null ],
      [ "use_cb", "structosmo__use__count.html#ae3ae970b037b9f0828bd4b4b5d84b248", null ],
      [ "use_counts", "structosmo__use__count.html#a2e13cc69cf4792e3260368102e6d4ee8", null ]
    ] ],
    [ "osmo_use_count_entry", "structosmo__use__count__entry.html", [
      [ "count", "structosmo__use__count__entry.html#ae27451006c39bebe8855bcde9e1b967c", null ],
      [ "entry", "structosmo__use__count__entry.html#a5a2a03538a19e29d830bf9c29382de24", null ],
      [ "use", "structosmo__use__count__entry.html#a91221ed50645c326e449bfe235650f9d", null ],
      [ "use_count", "structosmo__use__count__entry.html#a0cc73d52f17a7a3acfa3485d59d8f416", null ]
    ] ],
    [ "osmo_use_count_get_put", "group__use__count.html#ga3457c05c5d2b707d99eb01704dc5f233", null ],
    [ "osmo_use_count_cb_t", "group__use__count.html#ga4497d9dc69e733d16d33a455d385931e", null ],
    [ "_osmo_use_count_get_put", "group__use__count.html#gad3fc149e66e6f9157843169f27ce571a", null ],
    [ "count_safe", "group__use__count.html#gaf2aa74b203011c4359eb13cb886beae7", null ],
    [ "osmo_use_count_by", "group__use__count.html#gae221053a7e938cc89864a29cd72bb971", null ],
    [ "osmo_use_count_create", "group__use__count.html#ga90705ba109a7da55760fba37c5821817", null ],
    [ "osmo_use_count_find", "group__use__count.html#ga0dcc3abaab263ca652b99214f2396298", null ],
    [ "osmo_use_count_free", "group__use__count.html#ga7d4005ec0820c11ef960ea966b6baff9", null ],
    [ "osmo_use_count_make_static_entries", "group__use__count.html#ga1d3601b4f5093407d57ca3f5e1c093cc", null ],
    [ "osmo_use_count_name_buf", "group__use__count.html#ga7b49bfded7003847ba6bcf2e021cb4d9", null ],
    [ "osmo_use_count_repurpose_zero_entry", "group__use__count.html#ga98cee57f336dcd019ccce57563e2b2ea", null ],
    [ "osmo_use_count_to_str_buf", "group__use__count.html#ga0a979c7c3979e7cbb0981172c426a00f", null ],
    [ "osmo_use_count_to_str_c", "group__use__count.html#gac2e6c82a4809bae02212a09ce1e22a21", null ],
    [ "osmo_use_count_total", "group__use__count.html#ga34703c11c4da78bebd3322635b57e698", null ]
];