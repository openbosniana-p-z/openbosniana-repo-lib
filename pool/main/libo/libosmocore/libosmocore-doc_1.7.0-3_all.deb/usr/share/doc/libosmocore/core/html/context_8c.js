var context_8c =
[
    [ "__attribute__", "context_8c.html#a9ed16867a9394d9ccf1132194edae298", null ],
    [ "osmo_ctx_init", "context_8c.html#a0681c199afa71168cc7ff457fb403a5b", null ],
    [ "osmo_ctx", "context_8c.html#a0e806d75c80e71a111b18314b6b919bf", null ]
];