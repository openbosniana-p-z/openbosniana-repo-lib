var endian_8h =
[
    [ "OSMO_IS_BIG_ENDIAN", "endian_8h.html#ab67baeda1c52529fc18b1abee583d2ca", null ],
    [ "OSMO_IS_LITTLE_ENDIAN", "endian_8h.html#a15408f7c4554c93be027949399cfcaf5", null ]
];