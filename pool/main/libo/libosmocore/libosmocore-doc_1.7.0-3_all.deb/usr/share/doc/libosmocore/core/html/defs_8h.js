var defs_8h =
[
    [ "OSMO_DEPRECATED", "group__utils.html#gaae50be441dbfc7f95c61fdde4cdfb111", null ],
    [ "OSMO_DEPRECATED_OUTSIDE", "group__utils.html#ga18c73792dc759e9a929f5feda0d22f6e", null ],
    [ "OSMO_DEPRECATED_OUTSIDE_LIBOSMOCORE", "group__utils.html#ga9fc6cb4f6eae2ccd7fb2ec67a38b6fb8", null ],
    [ "OSMO_GNUC_PREREQ", "group__utils.html#ga74e01f67651f36d2eb902d318fb3f1b5", null ]
];