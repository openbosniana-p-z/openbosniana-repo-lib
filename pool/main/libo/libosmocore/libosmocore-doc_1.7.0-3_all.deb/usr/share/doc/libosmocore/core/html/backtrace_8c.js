var backtrace_8c =
[
    [ "_osmo_backtrace", "backtrace_8c.html#a7a79fd63496bc911b8321e5ab3e37ee7", null ],
    [ "osmo_generate_backtrace", "backtrace_8c.html#ae1d7c5276d845c48c0b964a1033b6c60", null ],
    [ "osmo_log_backtrace", "backtrace_8c.html#a89adddebf59157ca25eb6cb422a02151", null ]
];