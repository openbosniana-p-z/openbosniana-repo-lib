var logging__syslog_8c =
[
    [ "_syslog_output", "group__logging.html#ga97b43f9b8359fe37e51e7876884c2d43", null ],
    [ "log_target_create_syslog", "group__logging.html#gaeee882e225104fac94d0b8daa048e303", null ],
    [ "logp2syslog_level", "group__logging.html#ga8e2436af7e6195055c738e37b1016bb9", null ]
];