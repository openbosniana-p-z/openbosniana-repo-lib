var group__serial =
[
    [ "serial.h", "serial_8h.html", null ],
    [ "serial.c", "serial_8c.html", null ],
    [ "dbg_perror", "group__serial.html#ga7c79736a4054bb325bc9228b286401f7", null ],
    [ "_osmo_serial_set_baudrate", "group__serial.html#gad354988168b080f5a2a8f6b0e3aa4c2e", null ],
    [ "osmo_serial_clear_custom_baudrate", "group__serial.html#gaf674bb14346e7bbd6f0555464fb66a53", null ],
    [ "osmo_serial_init", "group__serial.html#ga1f1af4f9541cea98915c807938d576af", null ],
    [ "osmo_serial_set_baudrate", "group__serial.html#gac12e9df0274d063a3a188f16c9f86378", null ],
    [ "osmo_serial_set_custom_baudrate", "group__serial.html#ga53bf675db7d6c886d683bcfa3621193c", null ],
    [ "osmo_serial_speed_t", "group__serial.html#ga79c9ea27d7852c2652122e5bbdb47511", null ]
];