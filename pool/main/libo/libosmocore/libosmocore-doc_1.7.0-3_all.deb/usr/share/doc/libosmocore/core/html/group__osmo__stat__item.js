var group__osmo__stat__item =
[
    [ "stat_item.h", "stat__item_8h.html", null ],
    [ "osmo_stat_item_desc", "structosmo__stat__item__desc.html", [
      [ "default_value", "structosmo__stat__item__desc.html#a4e59b81f8a02fa3ced1ed4d760b37e67", null ],
      [ "description", "structosmo__stat__item__desc.html#a37ffd9f9806d546d283341ea02d921cf", null ],
      [ "name", "structosmo__stat__item__desc.html#a3e7a642d1651a2bc34718570dd9b80f4", null ],
      [ "num_values", "structosmo__stat__item__desc.html#a5ae8891d9b3619741b311510dd459630", null ],
      [ "unit", "structosmo__stat__item__desc.html#af563596769ecdaf1313a809fbda159fd", null ]
    ] ],
    [ "osmo_stat_item_group_desc", "structosmo__stat__item__group__desc.html", [
      [ "class_id", "structosmo__stat__item__group__desc.html#ab4bc4da517e6b364c33980d12813beeb", null ],
      [ "group_description", "structosmo__stat__item__group__desc.html#a9acef223dcbcf56708ee718e8e795cc1", null ],
      [ "group_name_prefix", "structosmo__stat__item__group__desc.html#a4356607204f67795efe0d85fa2d702bb", null ],
      [ "item_desc", "structosmo__stat__item__group__desc.html#a8c4c2f5d244941e49f1accac89c8f3d5", null ],
      [ "num_items", "structosmo__stat__item__group__desc.html#afb6b4aed69e38f2483c7b8db1531bf78", null ]
    ] ],
    [ "osmo_stat_item_group", "structosmo__stat__item__group.html", [
      [ "desc", "structosmo__stat__item__group.html#a6b0e959e1b5f49400e34986d58426cbc", null ],
      [ "idx", "structosmo__stat__item__group.html#af2b7f166ce30827f71075b477d425f18", null ],
      [ "items", "structosmo__stat__item__group.html#aa7fd0d6e4691b620d241e783be41f317", null ],
      [ "list", "structosmo__stat__item__group.html#af1dd5fb9c30961066b25c5359f8e7dd9", null ],
      [ "name", "structosmo__stat__item__group.html#ab29bdf5238072c11ba13846a7e1e4b4a", null ]
    ] ],
    [ "osmo_stat_item_period", "structosmo__stat__item__period.html", [
      [ "last", "structosmo__stat__item__period.html#aa3d0717377338fcb567fe610ddb8d3cb", null ],
      [ "max", "structosmo__stat__item__period.html#a87ae00431b74a609d4226ad9029ae670", null ],
      [ "min", "structosmo__stat__item__period.html#a9862c504ffca8af35a08a0010d72e8d9", null ],
      [ "n", "structosmo__stat__item__period.html#a324b7ab35148e4d017d6b472f410bbaf", null ],
      [ "sum", "structosmo__stat__item__period.html#a1464102c829b83f4c87815421b0870c2", null ]
    ] ],
    [ "osmo_stat_item", "structosmo__stat__item.html", [
      [ "desc", "structosmo__stat__item.html#a609fb2ec11e3a797c0c6f1b9c307bed2", null ],
      [ "reported", "structosmo__stat__item.html#afaed48a29956ea0319a25bc6ba676e6b", null ],
      [ "value", "structosmo__stat__item.html#a6a4a64a5740b30c2ee01d2f389a3370e", null ]
    ] ],
    [ "OSMO_STAT_ITEM_NO_UNIT", "group__osmo__stat__item.html#ga5302c4affa8c6f44c37d58782abc1cc2", null ],
    [ "OSMO_STAT_ITEM_NOVALUE_ID", "group__osmo__stat__item.html#gaf6f3007c03bc8114990c8b31bd030820", null ],
    [ "osmo_stat_item_group_handler_t", "group__osmo__stat__item.html#gab6f48cb83fad5c21428d2dbb02af048a", null ],
    [ "osmo_stat_item_handler_t", "group__osmo__stat__item.html#gabebffafb8b666e2a52c0c4784eeabfbf", null ],
    [ "LLIST_HEAD", "group__osmo__stat__item.html#ga918922f0159b002fd13bf021ec3bc294", null ],
    [ "osmo_stat_item_dec", "group__osmo__stat__item.html#ga462b34eb55a9432b335f5e2cc32a5498", null ],
    [ "osmo_stat_item_flush", "group__osmo__stat__item.html#ga312b34dbb43757e505c5c215592c7552", null ],
    [ "osmo_stat_item_for_each_group", "group__osmo__stat__item.html#gae1367b44f93a6ea46cbe90a955b06dda", null ],
    [ "osmo_stat_item_for_each_item", "group__osmo__stat__item.html#ga4b20503c85250536c1fe215aa8f0caac", null ],
    [ "osmo_stat_item_get_by_name", "group__osmo__stat__item.html#ga088dc4ca88656f25e0a0a6bdfb024bc1", null ],
    [ "osmo_stat_item_get_desc", "group__osmo__stat__item.html#ga2b5922d91fc40c32c41e59dd7f87c9b7", null ],
    [ "osmo_stat_item_get_group_by_name_idx", "group__osmo__stat__item.html#ga59062bfcaa3f804df9ac69bcf52a2fb4", null ],
    [ "osmo_stat_item_get_group_by_name_idxname", "group__osmo__stat__item.html#ga49dec12c98ad324d7c255c8a4f9f6437", null ],
    [ "osmo_stat_item_get_last", "group__osmo__stat__item.html#ga595e25b76fdca35c9e2ec5b4e4e4410a", null ],
    [ "osmo_stat_item_group_alloc", "group__osmo__stat__item.html#gaa1a7c1500d64a803883ee7ff12ccf963", null ],
    [ "osmo_stat_item_group_free", "group__osmo__stat__item.html#ga070d81e1291c4f54abfb159cda2b5340", null ],
    [ "osmo_stat_item_group_get_item", "group__osmo__stat__item.html#gad0553a8db021f131aca944e4200785ec", null ],
    [ "osmo_stat_item_group_reset", "group__osmo__stat__item.html#ga9522e7b07091b7ad531a41f07764359f", null ],
    [ "osmo_stat_item_group_set_name", "group__osmo__stat__item.html#gadf35c36fb3cefaba1a1f9d7daa68bdf4", null ],
    [ "osmo_stat_item_group_udp_idx", "group__osmo__stat__item.html#gad86cf00ee8f70547c5b80159cf7d4678", null ],
    [ "osmo_stat_item_inc", "group__osmo__stat__item.html#ga45140f45c0e7e057f83c97ddab5330e6", null ],
    [ "osmo_stat_item_init", "group__osmo__stat__item.html#ga9ac290aa2ab34c36fc86bf620adec408", null ],
    [ "osmo_stat_item_reset", "group__osmo__stat__item.html#gad3d919ff9ce0c85a69388252aeb257c9", null ],
    [ "osmo_stat_item_set", "group__osmo__stat__item.html#gabf7ea5516b1929ca8b8b2d2e51c0f662", null ],
    [ "tall_stat_item_ctx", "group__osmo__stat__item.html#ga7785ff605fed9985c603bf1a691c97a0", null ]
];