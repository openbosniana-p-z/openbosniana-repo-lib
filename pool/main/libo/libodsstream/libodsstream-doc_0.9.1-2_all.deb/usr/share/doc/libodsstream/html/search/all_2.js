var searchData=
[
  ['enddocument_0',['endDocument',['../classCustomHandler.html#ad540cce0ec23f182c3d5cb48630d578e',1,'CustomHandler::endDocument()'],['../classOdsDocHandlerInterface.html#a5acecc139ef82ba9dcb3e872ba1681ed',1,'OdsDocHandlerInterface::endDocument()'],['../classCustomHandler.html#ad540cce0ec23f182c3d5cb48630d578e',1,'CustomHandler::endDocument()']]],
  ['endline_1',['endLine',['../classCustomHandler.html#a4b4d888ba53c12aa8ed2f126a907dfaf',1,'CustomHandler::endLine()'],['../classOdsDocHandlerInterface.html#af25a15b17b886ae223503ba5a9d25fbb',1,'OdsDocHandlerInterface::endLine()'],['../classCustomHandler.html#a4b4d888ba53c12aa8ed2f126a907dfaf',1,'CustomHandler::endLine()']]],
  ['endsheet_2',['endSheet',['../classCustomHandler.html#a1ded93c3276a405795fa1918d74b2464',1,'CustomHandler::endSheet()'],['../classOdsDocHandlerInterface.html#a02d02a5f996db8e98fb2b4741707ed6a',1,'OdsDocHandlerInterface::endSheet()'],['../classCustomHandler.html#a1ded93c3276a405795fa1918d74b2464',1,'CustomHandler::endSheet()']]]
];
