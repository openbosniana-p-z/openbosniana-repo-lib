var searchData=
[
  ['cleartablecellstyleref_0',['clearTableCellStyleRef',['../classCalcWriterInterface.html#a4eaca2698a01b876b22f78cc0eab9445',1,'CalcWriterInterface']]],
  ['close_1',['close',['../classOdsDocWriter.html#a4f7ef01bde9cb59f051f775b686838bd',1,'OdsDocWriter']]]
];
