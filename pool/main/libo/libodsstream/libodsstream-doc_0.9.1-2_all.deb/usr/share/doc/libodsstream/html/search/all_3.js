var searchData=
[
  ['finished_0',['finished',['../classOds2Csv.html#a08c6fd0013ad864102b3c27e500a1ccc',1,'Ods2Csv::finished()'],['../classTsv2Ods.html#aeb4d06734a73c6a708ee5f94f6c0cce3',1,'Tsv2Ods::finished()']]]
];
