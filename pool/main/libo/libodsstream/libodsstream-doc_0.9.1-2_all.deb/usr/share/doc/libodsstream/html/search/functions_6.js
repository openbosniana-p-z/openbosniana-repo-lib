var searchData=
[
  ['odsdocreader_0',['OdsDocReader',['../classOdsDocReader.html#ada8451efcb6c8e8541cee56744e824e8',1,'OdsDocReader']]]
];
