var searchData=
[
  ['setcell_0',['setCell',['../classOdsDocHandlerInterface.html#a24eb6dd7cf9095543f0d56a605f151c4',1,'OdsDocHandlerInterface::setCell()'],['../classCustomHandler.html#a3a602cb11438a5d5513e6913340333c4',1,'CustomHandler::setCell(const OdsCell &amp;cell)'],['../classCustomHandler.html#a3a602cb11438a5d5513e6913340333c4',1,'CustomHandler::setCell(const OdsCell &amp;cell)']]],
  ['setcellannotation_1',['setCellAnnotation',['../classCalcWriterInterface.html#a5b796c6403d707997bc0862fd601a2c7',1,'CalcWriterInterface::setCellAnnotation()'],['../classOdsDocWriter.html#a5e604ea6ec667adf7036b69dd959a260',1,'OdsDocWriter::setCellAnnotation()'],['../classTsvDirectoryWriter.html#a582a9c2bc3b906986a5e91ce82030d9b',1,'TsvDirectoryWriter::setCellAnnotation()']]],
  ['setcellrange_2',['setCellRange',['../classOdsColorScale.html#a6f39b1bd4d3af453537879a8ae84d3fe',1,'OdsColorScale']]],
  ['setcurrentodstablesettings_3',['setCurrentOdsTableSettings',['../classCalcWriterInterface.html#aa507ae50431475b620c2cf0afc1e2494',1,'CalcWriterInterface::setCurrentOdsTableSettings()'],['../classOdsDocWriter.html#adc10033931a78333a099dcf64e2151ce',1,'OdsDocWriter::setCurrentOdsTableSettings()']]],
  ['setflushlines_4',['setFlushLines',['../classTsvDirectoryWriter.html#a14dd80d2a9892516d0cbbb6b237581e3',1,'TsvDirectoryWriter']]],
  ['setmaximumcolor_5',['setMaximumColor',['../classOdsColorScale.html#a9fdd6f5cf4fe11447832ec51b9e96afe',1,'OdsColorScale']]],
  ['setminimumcolor_6',['setMinimumColor',['../classOdsColorScale.html#ae581275c11d9ad1fd37486e28df3fc80',1,'OdsColorScale']]],
  ['setnosheetname_7',['setNoSheetName',['../classTsvOutputStream.html#ae71b2ebafc60089326753a4e1e8866b1',1,'TsvOutputStream']]],
  ['setquotestrings_8',['setQuoteStrings',['../classTsvDirectoryWriter.html#a506dc56dfcd7707523a6f4d415c01d6b',1,'TsvDirectoryWriter']]],
  ['setseparator_9',['setSeparator',['../classTsvDirectoryWriter.html#a5caf11c7c7b363a7f0f6f3d495e24d5e',1,'TsvDirectoryWriter']]],
  ['settablecellstyleref_10',['setTableCellStyleRef',['../classCalcWriterInterface.html#ab63637cba46581774b830cf877d81698',1,'CalcWriterInterface::setTableCellStyleRef()'],['../classOdsDocWriter.html#ada4594853df1d69c9ebe8e39aa3d3569',1,'OdsDocWriter::setTableCellStyleRef()']]],
  ['startline_11',['startLine',['../classCustomHandler.html#a041e81878b4ad10c8611a847c7d5adf5',1,'CustomHandler::startLine()'],['../classOdsDocHandlerInterface.html#a62f91a3d89f7fc45e1f5ed126cb8fcb6',1,'OdsDocHandlerInterface::startLine()'],['../classCustomHandler.html#a041e81878b4ad10c8611a847c7d5adf5',1,'CustomHandler::startLine()']]],
  ['startsheet_12',['startSheet',['../classCustomHandler.html#a225a4c2cc34e23d58fda410be0aabb32',1,'CustomHandler::startSheet()'],['../classOdsDocHandlerInterface.html#a98d2e53efc7816f4801bd8c80ec3651e',1,'OdsDocHandlerInterface::startSheet()'],['../classCustomHandler.html#a225a4c2cc34e23d58fda410be0aabb32',1,'CustomHandler::startSheet()']]]
];
