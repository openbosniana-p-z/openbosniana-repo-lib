var searchData=
[
  ['getodscellcoordinate_0',['getOdsCellCoordinate',['../classCalcWriterInterface.html#abb62d7b72f30f92f623e8d5303cacd26',1,'CalcWriterInterface::getOdsCellCoordinate()'],['../classOdsDocWriter.html#a271a86f74f2b92a2daab61ef2a17e5ad',1,'OdsDocWriter::getOdsCellCoordinate()']]],
  ['getseparator_1',['getSeparator',['../classTsvDirectoryWriter.html#a22ed8d7cf99ca349ec12f8d8470d0e43',1,'TsvDirectoryWriter']]],
  ['gettablecellstyleref_2',['getTableCellStyleRef',['../classCalcWriterInterface.html#ab931e2e2df7f4ecac06dada12078833a',1,'CalcWriterInterface::getTableCellStyleRef()'],['../classOdsDocWriter.html#a9186b91e4ee6f14a58f3a2716e7cb7bd',1,'OdsDocWriter::getTableCellStyleRef()']]]
];
