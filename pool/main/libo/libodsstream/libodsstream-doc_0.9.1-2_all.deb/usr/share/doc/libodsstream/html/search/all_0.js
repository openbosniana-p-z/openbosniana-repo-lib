var searchData=
[
  ['abouttoquitapp_0',['aboutToQuitApp',['../classOds2Csv.html#aae002dbd154529f3fd1641ebf60ef707',1,'Ods2Csv::aboutToQuitApp()'],['../classTsv2Ods.html#a971e08df89f7fcc15748bc77b44e31af',1,'Tsv2Ods::aboutToQuitApp()']]],
  ['addcolorscale_1',['addColorScale',['../classCalcWriterInterface.html#a7caab9adf40fe7867c715cd7a9aa0dac',1,'CalcWriterInterface::addColorScale()'],['../classOdsDocWriter.html#abd1abc24eb69663d5453b00859ae9505',1,'OdsDocWriter::addColorScale()']]]
];
