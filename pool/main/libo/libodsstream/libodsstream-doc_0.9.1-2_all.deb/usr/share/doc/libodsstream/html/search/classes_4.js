var searchData=
[
  ['settingsxml_0',['SettingsXml',['../classSettingsXml.html',1,'']]],
  ['stylesxml_1',['StylesXml',['../classStylesXml.html',1,'']]]
];
