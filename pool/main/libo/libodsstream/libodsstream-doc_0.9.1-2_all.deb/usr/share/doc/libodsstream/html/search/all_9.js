var searchData=
[
  ['run_0',['run',['../classOds2Csv.html#acdfb7abff9d83461a784ef78892b1761',1,'Ods2Csv::run()'],['../classTsv2Ods.html#a0f73c349032ff7aebc003f1aaae6eeac',1,'Tsv2Ods::run()']]]
];
