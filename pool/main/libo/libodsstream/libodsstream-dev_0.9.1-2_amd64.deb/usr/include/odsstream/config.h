
#pragma once

#define LIBODSSTREAM_VERSION "0.9.1"

#define LIBODSSTREAM_LIB_NAME "libodsstream"

#include <QDebug>


enum class TsvSeparator {tab, comma, semicolon};

