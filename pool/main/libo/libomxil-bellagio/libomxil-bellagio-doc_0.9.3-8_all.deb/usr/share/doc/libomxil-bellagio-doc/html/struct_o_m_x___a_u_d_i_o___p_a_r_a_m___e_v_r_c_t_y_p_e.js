var struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e =
[
    [ "bHiPassFilter", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#aa945af4eb6b2eb5e17f83e06b069fde5", null ],
    [ "bNoiseSuppressor", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#a8c5be9f300e52102265437f6ea57c545", null ],
    [ "bPostFilter", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#a7e8aba981288eae34c339e2b8a626b7c", null ],
    [ "bRATE_REDUCon", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#ae6741485d953334cbd000f0f807eaa6e", null ],
    [ "eCDMARate", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#ac9ad6ecf3dd65ff189654b5260fda6bd", null ],
    [ "nChannels", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#aac4833c2000a3dc9a2e116247a028b5d", null ],
    [ "nMaxBitRate", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#a455b01732a8f72e4bb4df4b0ffa311cf", null ],
    [ "nMinBitRate", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#a6af053b0843e3dc1be0fe9cc1f88bd11", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#aad8748fbbb031d53d60a8ddb6e74f72a", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#acbf8c05734c30abfb5a7cea81c888606", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___e_v_r_c_t_y_p_e.html#aebd3be96f47ca41237da22a112667c15", null ]
];