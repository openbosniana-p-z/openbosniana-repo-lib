var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___v_o_l_u_m_e_t_y_p_e =
[
    [ "bLinear", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___v_o_l_u_m_e_t_y_p_e.html#ae8aec73b86dd09460dbf46a66ead6f81", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___v_o_l_u_m_e_t_y_p_e.html#a303ebc098d2b1ce3c222bc67098427ef", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___v_o_l_u_m_e_t_y_p_e.html#a220a751c7fbdefb9f604da29e2bcc79e", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___v_o_l_u_m_e_t_y_p_e.html#a7b8de4d31f5f31a6d97ced96361de736", null ],
    [ "sVolume", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___v_o_l_u_m_e_t_y_p_e.html#af6908062071b09281e0eb6f31cb7025d", null ]
];