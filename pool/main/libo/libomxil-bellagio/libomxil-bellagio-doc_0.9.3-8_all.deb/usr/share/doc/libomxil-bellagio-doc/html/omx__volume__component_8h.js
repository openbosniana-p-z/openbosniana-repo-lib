var omx__volume__component_8h =
[
    [ "MAX_VOLUME_COMPONENTS", "omx__volume__component_8h.html#ae0c3b4dd6b3121420f19aa385954d12d", null ],
    [ "omx_volume_component_PrivateType_FIELDS", "omx__volume__component_8h.html#a8330a557eedcf3cf07bd69364bfb5beb", null ],
    [ "VOLUME_COMP_NAME", "omx__volume__component_8h.html#acf4a2447d468585404e55069cb93f005", null ],
    [ "VOLUME_COMP_ROLE", "omx__volume__component_8h.html#ab4bd61ca2c1282c174b9058c15fd3763", null ],
    [ "VOLUME_QUALITY_LEVELS", "omx__volume__component_8h.html#a3c8ec326e2fdb9d0c6d59ccb72ea9868", null ],
    [ "omx_volume_component_BufferMgmtCallback", "omx__volume__component_8h.html#afe9935635215be7dcaefe350df146b5d", null ],
    [ "omx_volume_component_Constructor", "omx__volume__component_8h.html#a4b12909b15766c474c6fe5dd1e50dc07", null ],
    [ "omx_volume_component_Destructor", "omx__volume__component_8h.html#a4308b35c37ec308a847436f695824441", null ],
    [ "omx_volume_component_GetConfig", "omx__volume__component_8h.html#aa22039016219ec05ce34ea20ecb5b46a", null ],
    [ "omx_volume_component_GetParameter", "omx__volume__component_8h.html#a424704835626977141c21786e2b1491f", null ],
    [ "omx_volume_component_SetConfig", "omx__volume__component_8h.html#a0048717a4840f2ba669ea04bdff1b0c5", null ],
    [ "omx_volume_component_SetParameter", "omx__volume__component_8h.html#aedc3437cf95f35c72186b6fe2ef97292", null ]
];