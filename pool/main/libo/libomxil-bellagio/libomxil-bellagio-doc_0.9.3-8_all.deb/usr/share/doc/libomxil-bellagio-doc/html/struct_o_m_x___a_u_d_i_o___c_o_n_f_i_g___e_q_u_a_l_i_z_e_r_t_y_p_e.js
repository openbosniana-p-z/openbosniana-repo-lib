var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e =
[
    [ "bEnable", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#a67c7b18f9381fa06fa3a30728615d553", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#acd6b2ff502dea37c100d698a953255e8", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#a971b6aa8119691e5bf4859c1b1ba8a98", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#a9b57489bc3e3fe78a2d9cb2b98e64ed1", null ],
    [ "sBandIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#a58c7f261194e90355e7d97073e9601f2", null ],
    [ "sBandLevel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#a73dee25a6daf04597c20fe75cdff75c5", null ],
    [ "sCenterFreq", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#ab41066062b6c413d62e18f04526a65d6", null ]
];