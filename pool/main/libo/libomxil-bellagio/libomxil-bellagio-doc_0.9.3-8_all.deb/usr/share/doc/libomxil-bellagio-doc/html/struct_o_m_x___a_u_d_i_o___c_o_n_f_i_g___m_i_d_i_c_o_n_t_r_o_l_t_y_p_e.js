var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e =
[
    [ "nChannelMuteMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a3b46a51d77b576eb17080300f4705082", null ],
    [ "nChannelSoloMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a95e017ba98eab34e2e882d1dffedaeb0", null ],
    [ "nMaxPolyphony", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a697e0daece79d5eb7e364d19964222c1", null ],
    [ "nNumRepeat", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a30ca051d1f8c44709e630fe13e5c72a3", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a3b51d6445be04e9b24d9df8e820475a9", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#ae1ad6a8a8c6c36b739a316fd780e2099", null ],
    [ "nStopTime", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a6c0bd7702ce01cabd8b70f6f22712fcd", null ],
    [ "nTrack0031MuteMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a60dcd18bbd8573e0dc0b97611a670a44", null ],
    [ "nTrack0031SoloMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a46a812edef69e6b80921e407be6deb24", null ],
    [ "nTrack3263MuteMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a2aee8d856cb600e371c37326caf91996", null ],
    [ "nTrack3263SoloMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a6dda4f3739cc91faf46d57aa4497939a", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a46f3ed74057bf0a38bd68104d637fdcc", null ],
    [ "sPitchTransposition", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#aef74b294c3a5db19a63cd1ca4b6242ed", null ],
    [ "sPlayBackRate", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a1dfc1decd3a025b1449df3f78ca170fe", null ],
    [ "sTempo", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a7a517ed02ddebdbae5ac5e5711df378a", null ]
];