var struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_m_r_t_y_p_e =
[
    [ "eAMRBandMode", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_m_r_t_y_p_e.html#af22d924bb9f4f69455204793e4e89c6e", null ],
    [ "eAMRDTXMode", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_m_r_t_y_p_e.html#a557ee1abbfe98f7da9caa420986d41c5", null ],
    [ "eAMRFrameFormat", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_m_r_t_y_p_e.html#a355451e1a6464c6eafcb0002c7a71b4e", null ],
    [ "nBitRate", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_m_r_t_y_p_e.html#aa9bd289882816c717c189ab23c62f59e", null ],
    [ "nChannels", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_m_r_t_y_p_e.html#a446ef44479274a044aeff4ff98251198", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_m_r_t_y_p_e.html#a1356590c0f6eab42e7ee085b264315b2", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_m_r_t_y_p_e.html#a1fb02dece5cd60afab0453b83d5ba6af", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_m_r_t_y_p_e.html#a4ca7c55ebc069b6e0d134c8292c7346f", null ]
];