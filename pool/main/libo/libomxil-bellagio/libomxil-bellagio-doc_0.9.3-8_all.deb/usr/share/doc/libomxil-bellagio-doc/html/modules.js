var modules =
[
    [ "OpenMAX IL Audio Domain", "group__audio.html", "group__audio" ],
    [ "OpenMAX IL Imaging and Video Domain", "group__iv.html", "group__iv" ],
    [ "OpenMAX IL core", "group__core.html", "group__core" ],
    [ "OpenMAX IL component", "group__comp.html", "group__comp" ],
    [ "Resource and Policy Management", "group__rpm.html", "group__rpm" ],
    [ "Buffer Management", "group__buf.html", "group__buf" ],
    [ "Metadata handling", "group__metadata.html", "group__metadata" ]
];