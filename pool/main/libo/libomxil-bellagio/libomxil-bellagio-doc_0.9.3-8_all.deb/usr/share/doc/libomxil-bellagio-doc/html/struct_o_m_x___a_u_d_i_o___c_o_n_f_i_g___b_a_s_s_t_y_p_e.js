var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_s_s_t_y_p_e =
[
    [ "bEnable", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_s_s_t_y_p_e.html#a5ee7923cced7722a7c7ef5f1dc285750", null ],
    [ "nBass", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_s_s_t_y_p_e.html#adbb04dc8dc0b7db91c1279a9a9d298c4", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_s_s_t_y_p_e.html#a55d3cb72679e68e2c13665bff89f8a16", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_s_s_t_y_p_e.html#a9503f5c48181e5972f445b8fc5b5fbbe", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_s_s_t_y_p_e.html#a2df2a721329d402f009938c3c79c4bbe", null ]
];