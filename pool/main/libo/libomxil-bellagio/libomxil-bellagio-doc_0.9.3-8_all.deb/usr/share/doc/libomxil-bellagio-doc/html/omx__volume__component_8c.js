var omx__volume__component_8c =
[
    [ "GAIN_VALUE", "omx__volume__component_8c.html#a9798945ad354aea53732c9cc98f617e4", null ],
    [ "omx_volume_component_BufferMgmtCallback", "omx__volume__component_8c.html#ae7256dfa73051a7c14332f37a52fbdec", null ],
    [ "omx_volume_component_Constructor", "omx__volume__component_8c.html#a4b12909b15766c474c6fe5dd1e50dc07", null ],
    [ "omx_volume_component_Destructor", "omx__volume__component_8c.html#a4308b35c37ec308a847436f695824441", null ],
    [ "omx_volume_component_GetConfig", "omx__volume__component_8c.html#aa22039016219ec05ce34ea20ecb5b46a", null ],
    [ "omx_volume_component_GetParameter", "omx__volume__component_8c.html#a424704835626977141c21786e2b1491f", null ],
    [ "omx_volume_component_SetConfig", "omx__volume__component_8c.html#a0048717a4840f2ba669ea04bdff1b0c5", null ],
    [ "omx_volume_component_SetParameter", "omx__volume__component_8c.html#aedc3437cf95f35c72186b6fe2ef97292", null ]
];