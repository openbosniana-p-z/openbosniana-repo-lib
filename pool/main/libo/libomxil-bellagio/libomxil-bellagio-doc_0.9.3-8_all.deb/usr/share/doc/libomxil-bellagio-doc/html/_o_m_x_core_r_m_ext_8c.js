var _o_m_x_core_r_m_ext_8c =
[
    [ "_GNU_SOURCE", "_o_m_x_core_r_m_ext_8c.html#a369266c24eacffb87046522897a570d5", null ],
    [ "getMultiResourceEstimates", "_o_m_x_core_r_m_ext_8c.html#a776bcbe5b8104072302444e4cd66f96a", null ],
    [ "getSupportedQualityLevels", "_o_m_x_core_r_m_ext_8c.html#a5548f5eb1f249e96aa79ab16fa20eb1f", null ],
    [ "readRegistryFile", "_o_m_x_core_r_m_ext_8c.html#afeac8319ca416c921a256407e42b089c", null ]
];