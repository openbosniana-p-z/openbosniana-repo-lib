var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e =
[
    [ "nMidiEvents", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#ac49f6cc749977f7296d360dd49ea9db5", null ],
    [ "nMidiEventSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#a6eb08d2dfc372bf4116b88c7302b942a", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#a983eaefce6541b6877f365912a594803", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#a393f436f8ec2281fb1325874d5800ca8", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#ae10e7b100b5d7b10fcf2f396d3d7df3c", null ]
];