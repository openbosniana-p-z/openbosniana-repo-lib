var omx__base__clock__port_8h =
[
    [ "omx_base_clock_PortType", "structomx__base__clock___port_type.html", "structomx__base__clock___port_type" ],
    [ "omx_base_clock_PortType_FIELDS", "omx__base__clock__port_8h.html#a9f1b2fdb5f00147948e39b7c9863f4c0", null ],
    [ "omx_base_clock_PortType", "omx__base__clock__port_8h.html#a35559e5047d68c81ad8948a0c79f8289", null ],
    [ "base_clock_port_Constructor", "omx__base__clock__port_8h.html#ad00fe59d19259a297540e7ebccf8bdbd", null ],
    [ "base_clock_port_Destructor", "omx__base__clock__port_8h.html#a18dc0c0c995ea199b689fb5db74826a0", null ],
    [ "base_clock_port_SendBufferFunction", "omx__base__clock__port_8h.html#a75d9e2707dae14f9dc88bd6c925a7935", null ]
];