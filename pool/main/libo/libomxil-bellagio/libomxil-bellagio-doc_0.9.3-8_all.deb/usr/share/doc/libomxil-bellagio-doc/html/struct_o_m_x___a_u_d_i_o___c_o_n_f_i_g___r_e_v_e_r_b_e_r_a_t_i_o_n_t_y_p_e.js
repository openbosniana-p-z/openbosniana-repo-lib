var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e =
[
    [ "bEnable", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a40f6cc27671c6996aedbb323b00bbbe8", null ],
    [ "nDecayHighFreqRatio", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a4f4d6de750583865aabb1621ba440f23", null ],
    [ "nDensity", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#ade42a9a60e53d2c410405e41799dcb11", null ],
    [ "nDiffusion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#ac0939a3828f5d702ea774af78201ea05", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#aa440dad44dab185a4395e6371c3635ab", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a6827d8f0ee4bc17e0483802eeb0ca3a4", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#ae065857d5f9cf53b083c02f2a219cd0a", null ],
    [ "sDecayTime", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#ac464db84e9f329b9efbd270b5c3946d8", null ],
    [ "sReferenceHighFreq", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a102172bd9670912d09a9072f80352f69", null ],
    [ "sReflectionsDelay", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#af2b44fab14a4f698d0b3bc91af58a85d", null ],
    [ "sReflectionsLevel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a4844e43139e92db7b2b5189be8de922d", null ],
    [ "sReverbDelay", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#aed2442fa1b78023ea219cc47288cd8ff", null ],
    [ "sReverbLevel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#aa5b4e87ae4e88f6cedaf0443fc50301d", null ],
    [ "sRoomHighFreqLevel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a736268143a8a7d42cfa9322de78b18a6", null ],
    [ "sRoomLevel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a46d0f53dc03fa8aee7071151d5593a32", null ]
];