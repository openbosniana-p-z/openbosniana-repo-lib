var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e =
[
    [ "bEnable", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#a62472c7db30c7770144d7b9d27761631", null ],
    [ "nFeedback", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#a1678eda61a36f5ef2e6b3baffd1e82a1", null ],
    [ "nModulationDepth", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#ae26f757a798662012b5ebece5f9d51e2", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#a14ac8a0f393c077998ae254cc9772668", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#a1103b8d24e6c42af35d8dab61cf3a002", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#ad0254351fab8c6b6e2684ea4ce4e5fd9", null ],
    [ "sDelay", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#a485c56d1a19ccbe7d0b6f6aa7731b324", null ],
    [ "sModulationRate", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#acd38e13eec897709fa940e6b983cb75d", null ]
];