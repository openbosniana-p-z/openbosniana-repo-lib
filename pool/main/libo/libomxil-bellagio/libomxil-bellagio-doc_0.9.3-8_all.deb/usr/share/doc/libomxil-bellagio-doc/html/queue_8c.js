var queue_8c =
[
    [ "dequeue", "queue_8c.html#a2fbbc0f2b8e7f6fff5719562b3495208", null ],
    [ "getquenelem", "queue_8c.html#adebc8aa8d0be687bce26fb8c458c447a", null ],
    [ "queue", "queue_8c.html#a29e8cac7d151c030f0e1ac1c07f18323", null ],
    [ "queue_deinit", "queue_8c.html#a7ed0f920c24a1c31472c8fc571100e37", null ],
    [ "queue_init", "queue_8c.html#a8f5abe559cd352d91efb79bc6e1788de", null ]
];