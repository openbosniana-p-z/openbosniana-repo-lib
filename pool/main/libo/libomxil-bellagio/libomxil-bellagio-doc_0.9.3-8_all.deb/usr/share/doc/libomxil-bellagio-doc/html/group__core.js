var group__core =
[
    [ "Tunneling", "group__tun.html", "group__tun" ],
    [ "Content Pipes", "group__cp.html", "group__cp" ],
    [ "OMX_COMPONENTREGISTERTYPE", "struct_o_m_x___c_o_m_p_o_n_e_n_t_r_e_g_i_s_t_e_r_t_y_p_e.html", [
      [ "pInitialize", "struct_o_m_x___c_o_m_p_o_n_e_n_t_r_e_g_i_s_t_e_r_t_y_p_e.html#a67a1292cda9dc36b98a1ea336d2ea330", null ],
      [ "pName", "struct_o_m_x___c_o_m_p_o_n_e_n_t_r_e_g_i_s_t_e_r_t_y_p_e.html#a500dc9a4cdeac4259ac8cf1fb782ddc9", null ]
    ] ],
    [ "OMX_COMMANDTYPE", "group__core.html#ga9fde5616f2752be8e4a67987ff597f98", null ],
    [ "OMX_COMPONENTINITTYPE", "group__core.html#ga3a503fec10f598112f0d0c0b77fc3977", null ],
    [ "OMX_COMPONENTREGISTERTYPE", "group__core.html#gab3b1616d0bb4c7613203c0b9a6765e4c", null ],
    [ "OMX_COMMANDTYPE", "group__core.html#ga866121e7689263734cbaef7f2946efca", [
      [ "OMX_CommandStateSet", "group__core.html#gga866121e7689263734cbaef7f2946efcaa85c11df69b1c21d18a3e3b16f1179e9b", null ],
      [ "OMX_CommandFlush", "group__core.html#gga866121e7689263734cbaef7f2946efcaa8268f8530a473ee6f5b85c61993a1d4e", null ],
      [ "OMX_CommandPortDisable", "group__core.html#gga866121e7689263734cbaef7f2946efcaa51f537c6205e087487c0d66d71c6761c", null ],
      [ "OMX_CommandPortEnable", "group__core.html#gga866121e7689263734cbaef7f2946efcaa5c6246d6d245048e2fae5e31c210e55e", null ],
      [ "OMX_CommandMarkBuffer", "group__core.html#gga866121e7689263734cbaef7f2946efcaa219404995a94edc7704e9e14783dee4c", null ],
      [ "OMX_CommandKhronosExtensions", "group__core.html#gga866121e7689263734cbaef7f2946efcaa22b50871ddc023725f9a386e5ec4a45a", null ],
      [ "OMX_CommandVendorStartUnused", "group__core.html#gga866121e7689263734cbaef7f2946efcaac0567610d2d7aebeeb37ccb205191f0b", null ],
      [ "OMX_CommandMax", "group__core.html#gga866121e7689263734cbaef7f2946efcaa4e1499e008038e4921eb8623279fb649", null ]
    ] ],
    [ "OMX_ComponentNameEnum", "group__core.html#ga4ef83dde46e3602f74c9a630c7d0a449", null ],
    [ "OMX_Deinit", "group__core.html#ga863300506af715fdf8b91f32bdcf553a", null ],
    [ "OMX_FreeHandle", "group__core.html#gabdd0de6420415a359337e73381a7ddac", null ],
    [ "OMX_GetComponentsOfRole", "group__core.html#ga431fdec2b35dc0faee19225a786610bd", null ],
    [ "OMX_GetHandle", "group__core.html#ga911625211abe7e5726afceee0fd98d74", null ],
    [ "OMX_GetRolesOfComponent", "group__core.html#ga789b35e88446bbccbc8109b659cfd98d", null ],
    [ "OMX_Init", "group__core.html#gac81e21bb18ce9bd985a933509a61884c", null ],
    [ "OMX_ComponentRegistered", "group__core.html#gaf07808cc3e8c3950a0ac4b76d17cff9e", null ]
];