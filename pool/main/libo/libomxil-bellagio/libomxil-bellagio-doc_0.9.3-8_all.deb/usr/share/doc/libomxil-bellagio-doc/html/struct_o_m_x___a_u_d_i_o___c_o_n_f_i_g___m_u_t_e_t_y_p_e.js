var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_u_t_e_t_y_p_e =
[
    [ "bMute", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_u_t_e_t_y_p_e.html#ad1bee2af0a09b13c8eea51bdde0270a9", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_u_t_e_t_y_p_e.html#afca4230f3c56f2191e6e129d948e171f", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_u_t_e_t_y_p_e.html#a5e33215c4b1f6d3839ab2c765adf666d", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_u_t_e_t_y_p_e.html#a9cc923d295b3914605cb1f21622a3ada", null ]
];