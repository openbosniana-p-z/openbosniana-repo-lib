var struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e =
[
    [ "eAACProfile", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#a088ea1f1bdb0e6a071fabadcae9cc999", null ],
    [ "eAACStreamFormat", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#ac4889bdd9b9c7fd8f3b0264c8c460d89", null ],
    [ "eChannelMode", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#a00ccb5fbfeadd7e380c88b7a94b67f8c", null ],
    [ "nAACERtools", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#a1b414339bf830e4bd3260eaf62a7f098", null ],
    [ "nAACtools", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#a8f538dcde8d7285f06045bbcbb2e947c", null ],
    [ "nAudioBandWidth", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#aaa3736522d0a2c217dd6df13986ef59d", null ],
    [ "nBitRate", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#a594ad24ec201ab8278dba5ea6d1cc010", null ],
    [ "nChannels", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#adecc5cb756ceabd0b231d16b3658bc37", null ],
    [ "nFrameLength", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#abe833b451857c529c081b6655809e7f0", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#a04045c8704b2537a71c5a0b80ce8de9c", null ],
    [ "nSampleRate", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#ae725c7ace9c026eb3f63556c2fb99603", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#a6f1da5403dd3103e4e668f0636350d75", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_a_c_p_r_o_f_i_l_e_t_y_p_e.html#a1a1d7f157118e5d715f0163093dcd108", null ]
];