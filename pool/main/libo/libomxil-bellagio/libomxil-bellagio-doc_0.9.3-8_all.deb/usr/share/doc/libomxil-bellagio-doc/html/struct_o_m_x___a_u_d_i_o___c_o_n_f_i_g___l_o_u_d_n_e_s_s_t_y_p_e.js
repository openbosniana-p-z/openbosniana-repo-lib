var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___l_o_u_d_n_e_s_s_t_y_p_e =
[
    [ "bLoudness", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___l_o_u_d_n_e_s_s_t_y_p_e.html#a2f67f54b6ee7eb201e3608a1cbc17bdb", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___l_o_u_d_n_e_s_s_t_y_p_e.html#ab7aa6082f61e630d5797285ab5310864", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___l_o_u_d_n_e_s_s_t_y_p_e.html#a7ce90d7b2ff78208eaa8327c7ba8814a", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___l_o_u_d_n_e_s_s_t_y_p_e.html#afc3b0ccd0151a1d5b0e46292340dde3a", null ]
];