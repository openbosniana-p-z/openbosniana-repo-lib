/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "OpenMAX Bellagio", "index.html", [
    [ "Todo List", "todo.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", "globals_type" ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_o_m_x___audio_8h.html",
"_o_m_x___index_8h.html#abc3b6e6cb9a9d5c14cb679ac455ea715adacb20a8cb6de11c76a22af1e60c17e0",
"dir_d44c64559bbebec7f509842c48db8b23.html",
"group__audio.html#gga554b1aa02517e2627627c36350400086a82104d7e558fdc302f39e2637c560de6",
"group__core.html#gga866121e7689263734cbaef7f2946efcaa4e1499e008038e4921eb8623279fb649",
"group__iv.html#ggab1559a0509dc70ec08026acbdf989a7ba52fb0c7d98768de63ac15394f86c9da4",
"group__video.html#ga5574a9745fa33d64a81f1c677d26b15c",
"omx__base__clock__port_8c.html#a75d9e2707dae14f9dc88bd6c925a7935",
"omx__clocksrc__component_8c.html#ae81ac2ac9aadc4842d8fb9be089c19da",
"omxrmtest_8h.html#a781dd31b9382b965a85286d78e9932b6",
"struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#ac49f6cc749977f7296d360dd49ea9db5",
"struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_t_y_p_e.html#a1e058ab3c1a0ee98a7cc829feddf10be",
"struct_o_m_x___c_o_n_f_i_g___c_o_l_o_r_k_e_y_t_y_p_e.html#a79ef54e50ac278d965f3223a46ae168b",
"struct_o_m_x___o_t_h_e_r___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#af45cee9bfc262d50076275d8edb527f6",
"struct_o_m_x___v_i_d_e_o___p_a_r_a_m___h263_t_y_p_e.html#a74265090b3736bf27379cb096af5d761",
"structomx__base__clock___port_type.html#aa5d0ec96d82c47e85471a2a52a98cf2a",
"structste_loader_component_type.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';