var _o_m_x___types_8h =
[
    [ "OMX_BU32", "struct_o_m_x___b_u32.html", "struct_o_m_x___b_u32" ],
    [ "OMX_BS32", "struct_o_m_x___b_s32.html", "struct_o_m_x___b_s32" ],
    [ "OMX_MARKTYPE", "struct_o_m_x___m_a_r_k_t_y_p_e.html", "struct_o_m_x___m_a_r_k_t_y_p_e" ],
    [ "OMX_VERSIONTYPE", "union_o_m_x___v_e_r_s_i_o_n_t_y_p_e.html", "union_o_m_x___v_e_r_s_i_o_n_t_y_p_e" ],
    [ "OMX_ALL", "_o_m_x___types_8h.html#a041405fbfc3b7bac48ce953b7dfa0384", null ],
    [ "OMX_API", "_o_m_x___types_8h.html#aa904bc42411fc5979c164cef96e90400", null ],
    [ "OMX_APIENTRY", "_o_m_x___types_8h.html#a9b7491ee0c559eaba7416fe922882f65", null ],
    [ "OMX_IN", "_o_m_x___types_8h.html#a9f94ed9e467960d51f3b1da3a4ebf55c", null ],
    [ "OMX_INOUT", "_o_m_x___types_8h.html#ae2413e67d24fdfc2c077685e84c53741", null ],
    [ "OMX_OUT", "_o_m_x___types_8h.html#ad6f8c05c2b49042f9051e1f3fce7b28c", null ],
    [ "OMX_TICKS_PER_SECOND", "_o_m_x___types_8h.html#a4405c156146397a7db512c7069989363", null ],
    [ "OMX_BOOL", "_o_m_x___types_8h.html#a02c2bc15f647977eafa0997fad3379e4", null ],
    [ "OMX_BS32", "_o_m_x___types_8h.html#aa9e07adfdda87e760a5e8f7b9c54658a", null ],
    [ "OMX_BU32", "_o_m_x___types_8h.html#a70d120558b14b049216f6142ab3caf20", null ],
    [ "OMX_BYTE", "_o_m_x___types_8h.html#a83c85f956db2283456a86366fe13fd4b", null ],
    [ "OMX_DIRTYPE", "_o_m_x___types_8h.html#a9376db3f2a93d78a8a3d37f043d9621b", null ],
    [ "OMX_ENDIANTYPE", "_o_m_x___types_8h.html#ab29a06593aebae727d263116059272e8", null ],
    [ "OMX_HANDLETYPE", "_o_m_x___types_8h.html#a7b426d7bc825bf8a56ee39dc3c217af7", null ],
    [ "OMX_MARKTYPE", "_o_m_x___types_8h.html#a10ac34664d8cb5fb067d21435e6091d2", null ],
    [ "OMX_NATIVE_DEVICETYPE", "_o_m_x___types_8h.html#a1b6fe396c89e8fd1f16f0c4d31f2f1db", null ],
    [ "OMX_NATIVE_WINDOWTYPE", "_o_m_x___types_8h.html#a644ad3a434b9803d396c71d824ef8688", null ],
    [ "OMX_NUMERICALDATATYPE", "_o_m_x___types_8h.html#a810f5cc9ffc8ce6162c7570b784b3ad2", null ],
    [ "OMX_PTR", "_o_m_x___types_8h.html#a52f5626b11279ed9a6ce8731abc365be", null ],
    [ "OMX_S16", "_o_m_x___types_8h.html#ad7761a5e2931056da5a5d3ad4e33c54a", null ],
    [ "OMX_S32", "_o_m_x___types_8h.html#a8a31dd95e8a7d81701f312de0cccc05d", null ],
    [ "OMX_S64", "_o_m_x___types_8h.html#a294aae8e97744f7b4fef35acbe125822", null ],
    [ "OMX_S8", "_o_m_x___types_8h.html#a6983b02e943866084dbe9538f5a9a3ad", null ],
    [ "OMX_STRING", "_o_m_x___types_8h.html#a35830b439b00948006e5ef824fef715f", null ],
    [ "OMX_TICKS", "_o_m_x___types_8h.html#a6b33848dcc4dbb7a64071c2a5404000a", null ],
    [ "OMX_U16", "_o_m_x___types_8h.html#a8dd126b9f6e03b8523bb431a72298738", null ],
    [ "OMX_U32", "_o_m_x___types_8h.html#a04983f4ca9c7876035dffc578597eae3", null ],
    [ "OMX_U64", "_o_m_x___types_8h.html#a52728a8994b0cb90db69445482a32b00", null ],
    [ "OMX_U8", "_o_m_x___types_8h.html#a3ad7d812ff8ffb968c08e4b7bb04becd", null ],
    [ "OMX_UUIDTYPE", "_o_m_x___types_8h.html#aae1696487cf1241800f091ca1813faf0", null ],
    [ "OMX_VERSIONTYPE", "_o_m_x___types_8h.html#af7e5ee3c6a3b6377eb37082b874cb3be", null ],
    [ "OMX_BOOL", "_o_m_x___types_8h.html#a4aa524afe637a18762ac3cfdb3ce277b", [
      [ "OMX_FALSE", "_o_m_x___types_8h.html#a4aa524afe637a18762ac3cfdb3ce277bae32d6ae989533bc97bec6620fdbcb59b", null ],
      [ "OMX_TRUE", "_o_m_x___types_8h.html#a4aa524afe637a18762ac3cfdb3ce277babd8e08f19e313ba740188e0643ed08db", null ],
      [ "OMX_BOOL_MAX", "_o_m_x___types_8h.html#a4aa524afe637a18762ac3cfdb3ce277ba50221ebdd64a837b641995b6cc178dba", null ]
    ] ],
    [ "OMX_DIRTYPE", "_o_m_x___types_8h.html#ac4e70261103440a7df8c413d0c9b4c66", [
      [ "OMX_DirInput", "_o_m_x___types_8h.html#ac4e70261103440a7df8c413d0c9b4c66a72b8df1306ce56e33e9f760fed95d0f5", null ],
      [ "OMX_DirOutput", "_o_m_x___types_8h.html#ac4e70261103440a7df8c413d0c9b4c66a84331a314371b543aca43956d065a053", null ],
      [ "OMX_DirMax", "_o_m_x___types_8h.html#ac4e70261103440a7df8c413d0c9b4c66af2f001b0b44556d1505db671b322ec4c", null ]
    ] ],
    [ "OMX_ENDIANTYPE", "_o_m_x___types_8h.html#a3c2c956d0e4e47ad96f1977395ecfb8b", [
      [ "OMX_EndianBig", "_o_m_x___types_8h.html#a3c2c956d0e4e47ad96f1977395ecfb8bab901be48c0ecf3e7ecaca92817804140", null ],
      [ "OMX_EndianLittle", "_o_m_x___types_8h.html#a3c2c956d0e4e47ad96f1977395ecfb8ba6d839114e53c7684d8946243b37ffbde", null ],
      [ "OMX_EndianMax", "_o_m_x___types_8h.html#a3c2c956d0e4e47ad96f1977395ecfb8ba87214802c0e3c40ef97fd5123d454b68", null ]
    ] ],
    [ "OMX_NUMERICALDATATYPE", "_o_m_x___types_8h.html#a5718ca72c1708092c99a714beee4d2f9", [
      [ "OMX_NumericalDataSigned", "_o_m_x___types_8h.html#a5718ca72c1708092c99a714beee4d2f9a47dd215bbfd01911416b4ce71907c2ea", null ],
      [ "OMX_NumericalDataUnsigned", "_o_m_x___types_8h.html#a5718ca72c1708092c99a714beee4d2f9a226d549568183e11f6977b2582a95e5d", null ],
      [ "OMX_NumercialDataMax", "_o_m_x___types_8h.html#a5718ca72c1708092c99a714beee4d2f9ad91dedb9ac1560673c3b3a070d2baeb0", null ]
    ] ]
];