var struct_component_list_type =
[
    [ "next", "struct_component_list_type.html#a0ec6ac47e7a18c950ce138c3fe14af53", null ],
    [ "nGroupPriority", "struct_component_list_type.html#a4d037c49e32f5b9c7b8f0356b2474237", null ],
    [ "openmaxStandComp", "struct_component_list_type.html#a1757a7eebe148704f3dedb377bf981aa", null ],
    [ "timestamp", "struct_component_list_type.html#ad11ea071e39de4956154113f08e62dce", null ]
];