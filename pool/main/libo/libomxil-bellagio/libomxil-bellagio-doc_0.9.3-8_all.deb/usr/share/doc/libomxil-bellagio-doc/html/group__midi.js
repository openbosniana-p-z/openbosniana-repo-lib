var group__midi =
[
    [ "OMX_AUDIO_PARAM_MIDITYPE", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_t_y_p_e.html", [
      [ "bLoadDefaultSound", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_t_y_p_e.html#a7bcbc2ff6852986275643cd9b1d8ffc9", null ],
      [ "eMidiFormat", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_t_y_p_e.html#ade6b5ab6531e3a54ff116f611706d16b", null ],
      [ "nFileSize", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_t_y_p_e.html#aef987b02fc2e50e77b116d189ac40ee8", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_t_y_p_e.html#a1e058ab3c1a0ee98a7cc829feddf10be", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_t_y_p_e.html#aefe14ef155d24f236129623dcc95d950", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_t_y_p_e.html#ac51e7d14462b37d15f81905c178b2e28", null ],
      [ "sMaxPolyphony", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_t_y_p_e.html#a562fb14b3871947fa97c5514120ce444", null ]
    ] ],
    [ "OMX_AUDIO_PARAM_MIDILOADUSERSOUNDTYPE", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_l_o_a_d_u_s_e_r_s_o_u_n_d_t_y_p_e.html", [
      [ "eMidiSoundBank", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_l_o_a_d_u_s_e_r_s_o_u_n_d_t_y_p_e.html#ad086498d6e30d1e237e95720f55626e7", null ],
      [ "eMidiSoundBankLayout", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_l_o_a_d_u_s_e_r_s_o_u_n_d_t_y_p_e.html#a5449f506b75ac915c029eac0f500d148", null ],
      [ "nDLSIndex", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_l_o_a_d_u_s_e_r_s_o_u_n_d_t_y_p_e.html#a01c71091bea6e013dffa9c85d35f6f73", null ],
      [ "nDLSSize", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_l_o_a_d_u_s_e_r_s_o_u_n_d_t_y_p_e.html#adc0ad15e00b3e3830286ff248943d4bc", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_l_o_a_d_u_s_e_r_s_o_u_n_d_t_y_p_e.html#a4a3ef536c3ecaf42305767721f9f9771", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_l_o_a_d_u_s_e_r_s_o_u_n_d_t_y_p_e.html#aa5b90bd25badbfccbadf4577fd97c26b", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_l_o_a_d_u_s_e_r_s_o_u_n_d_t_y_p_e.html#a5c6c2eb97a384913e5bb6059c698812a", null ],
      [ "pDLSData", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___m_i_d_i_l_o_a_d_u_s_e_r_s_o_u_n_d_t_y_p_e.html#a652c8c086a375c928bacdf3faf214ed1", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_MIDIIMMEDIATEEVENTTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html", [
      [ "nMidiEvents", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#ac49f6cc749977f7296d360dd49ea9db5", null ],
      [ "nMidiEventSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#a6eb08d2dfc372bf4116b88c7302b942a", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#a983eaefce6541b6877f365912a594803", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#a393f436f8ec2281fb1325874d5800ca8", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_i_m_m_e_d_i_a_t_e_e_v_e_n_t_t_y_p_e.html#ae10e7b100b5d7b10fcf2f396d3d7df3c", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_MIDISOUNDBANKPROGRAMTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html", [
      [ "nChannel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#a60f628f98f7b5470119f9a9de0f44770", null ],
      [ "nIDProgram", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#a4483d6ef887a5acbc449134b884035bb", null ],
      [ "nIDSoundBank", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#a21ee8fe8f07bc4258c7b4c161a5893de", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#a93b2cefbc2b4ae5244e3e6f4afde5258", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#ae4821af7f46a1d97307aa29722dc29b8", null ],
      [ "nUserSoundBankIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#a56856cf1c0b22087bbbfcc30e3b5f44b", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#af5959ed1d987128af47a692a4b77ed08", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_MIDICONTROLTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html", [
      [ "nChannelMuteMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a3b46a51d77b576eb17080300f4705082", null ],
      [ "nChannelSoloMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a95e017ba98eab34e2e882d1dffedaeb0", null ],
      [ "nMaxPolyphony", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a697e0daece79d5eb7e364d19964222c1", null ],
      [ "nNumRepeat", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a30ca051d1f8c44709e630fe13e5c72a3", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a3b51d6445be04e9b24d9df8e820475a9", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#ae1ad6a8a8c6c36b739a316fd780e2099", null ],
      [ "nStopTime", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a6c0bd7702ce01cabd8b70f6f22712fcd", null ],
      [ "nTrack0031MuteMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a60dcd18bbd8573e0dc0b97611a670a44", null ],
      [ "nTrack0031SoloMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a46a812edef69e6b80921e407be6deb24", null ],
      [ "nTrack3263MuteMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a2aee8d856cb600e371c37326caf91996", null ],
      [ "nTrack3263SoloMask", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a6dda4f3739cc91faf46d57aa4497939a", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a46f3ed74057bf0a38bd68104d637fdcc", null ],
      [ "sPitchTransposition", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#aef74b294c3a5db19a63cd1ca4b6242ed", null ],
      [ "sPlayBackRate", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a1dfc1decd3a025b1449df3f78ca170fe", null ],
      [ "sTempo", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_c_o_n_t_r_o_l_t_y_p_e.html#a7a517ed02ddebdbae5ac5e5711df378a", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_MIDISTATUSTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html", [
      [ "bVibra", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#a4363b3620e324c90ed1ae0a221a698ea", null ],
      [ "eMIDIPlayBackState", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#acd262618e150a51051e890ca89348e29", null ],
      [ "nDuration", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#a6493c79b4ffd079a24fe4b4f0e778376", null ],
      [ "nNumActiveVoices", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#aaf87404c52e7f14bd3adb33ecf46c65b", null ],
      [ "nNumMetaEvents", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#a1d1c2d18dbfd24404f79b2ef1cf8741e", null ],
      [ "nNumTracks", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#af0a9f494b4d577ea23580679d0981806", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#ac2291e8065f697ef6cee464a1ad39ae5", null ],
      [ "nPosition", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#a605085de18bb8e8017aafd99c3f9f1c8", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#ab951fadc77f632f41de144b26e464522", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#a3a19324539c3b40372a58658936eb1ec", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_MIDIMETAEVENTTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html", [
      [ "nIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#aa0dbc475a3c776a6dfb012f1187bbbad", null ],
      [ "nMetaEventSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#a10dc647459c4f203730e6b8e2af5c516", null ],
      [ "nMetaEventType", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#aa3ac808d0f94611a4debdf4db174ce04", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#af20c83a7f06f40d3d096c9a52aff1d30", null ],
      [ "nPosition", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#ac889da9e863572411f585946828358f5", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#a46da183c055f35bd6b60c03097fc63af", null ],
      [ "nTrack", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#a197621d9cda982bfd130933eeafd2301", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#af21834eb345fba04712b25e15b5c8a62", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_MIDIMETAEVENTDATATYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html", [
      [ "nData", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#a5b11d6e98cff941dbc44679b2c2edee4", null ],
      [ "nIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#accdc81f543e74f07f5cb22e65c629fe3", null ],
      [ "nMetaEventSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#abde0c859e447cbbb772cc253ad6e9e64", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#a450a4a93e0d02ab3fa000afdafa39336", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#abd6611016de28ea661044ece2133a76b", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#ae761fee9fad5bc750e30804c9d4e9b50", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG__MIDIMETAEVENTDATATYPE", "group__midi.html#ga6ebdbb27f7977096e972d36a9042e3c8", null ],
    [ "OMX_AUDIO_CONFIG_MIDICONTROLTYPE", "group__midi.html#ga34e4d36fc04d760126851532de30557d", null ],
    [ "OMX_AUDIO_CONFIG_MIDIIMMEDIATEEVENTTYPE", "group__midi.html#ga42f255a711fc78f7d2446c9e46ed8731", null ],
    [ "OMX_AUDIO_CONFIG_MIDIMETAEVENTTYPE", "group__midi.html#ga6f789718d53b54ede6c15abd147053fc", null ],
    [ "OMX_AUDIO_CONFIG_MIDISOUNDBANKPROGRAMTYPE", "group__midi.html#gad0fb3739ca20b9f226ff37c63463d7f3", null ],
    [ "OMX_AUDIO_CONFIG_MIDISTATUSTYPE", "group__midi.html#ga1aa730f6448fbf236676ba51374642b1", null ],
    [ "OMX_AUDIO_MIDIFORMATTYPE", "group__midi.html#ga3d74f570f40684cc2e6321eab71f61fd", null ],
    [ "OMX_AUDIO_MIDIPLAYBACKSTATETYPE", "group__midi.html#ga0b2121d9f039e2105e87d524b0957dac", null ],
    [ "OMX_AUDIO_MIDISOUNDBANKLAYOUTTYPE", "group__midi.html#ga780f1fec12a4f24495a6389087610433", null ],
    [ "OMX_AUDIO_MIDISOUNDBANKTYPE", "group__midi.html#gaa53ea21081dec5edee21cb21d2dbf55a", null ],
    [ "OMX_AUDIO_PARAM_MIDILOADUSERSOUNDTYPE", "group__midi.html#ga8440fe62b4a6fe72e082378e2c233f6b", null ],
    [ "OMX_AUDIO_PARAM_MIDITYPE", "group__midi.html#ga2d928dcb240d7d08562d85dd1765a1ed", null ],
    [ "OMX_AUDIO_MIDIFORMATTYPE", "group__midi.html#ga89aa99855cf7ba8c60e7c28899cd7831", [
      [ "OMX_AUDIO_MIDIFormatUnknown", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831a2471b920c9cce306085980132e10c668", null ],
      [ "OMX_AUDIO_MIDIFormatSMF0", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831adbbd42dcd1d2f83e7c5206cc7cc64a5c", null ],
      [ "OMX_AUDIO_MIDIFormatSMF1", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831a47388e22e28be9891b43223fcecf9f06", null ],
      [ "OMX_AUDIO_MIDIFormatSMF2", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831ae88cec2d2c83a2b901382ff769f863ba", null ],
      [ "OMX_AUDIO_MIDIFormatSPMIDI", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831a9d2f292f088406dc2a4e3ad317a864cf", null ],
      [ "OMX_AUDIO_MIDIFormatXMF0", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831a687765fd86254f7d11d53a8ddd710e9f", null ],
      [ "OMX_AUDIO_MIDIFormatXMF1", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831a17d9e2464535184de8cd8c04300820b6", null ],
      [ "OMX_AUDIO_MIDIFormatMobileXMF", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831a9af384160ccdf644b61adedfa6451715", null ],
      [ "OMX_AUDIO_MIDIFormatKhronosExtensions", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831a6240b77f66295fabce82c4177cc0065d", null ],
      [ "OMX_AUDIO_MIDIFormatVendorStartUnused", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831a3b0d551d6b761001d0b9039a5a0dc83b", null ],
      [ "OMX_AUDIO_MIDIFormatMax", "group__midi.html#gga89aa99855cf7ba8c60e7c28899cd7831a025432112c88636f2ae0b405b5baa49c", null ]
    ] ],
    [ "OMX_AUDIO_MIDIPLAYBACKSTATETYPE", "group__midi.html#ga188ab18146b92cdae5141c6222e9ef08", [
      [ "OMX_AUDIO_MIDIPlayBackStateUnknown", "group__midi.html#gga188ab18146b92cdae5141c6222e9ef08ad5e094f05e2b28a3cb958e5985dcdaaf", null ],
      [ "OMX_AUDIO_MIDIPlayBackStateClosedEngaged", "group__midi.html#gga188ab18146b92cdae5141c6222e9ef08ac46499fc20dd403298df9092be93c41c", null ],
      [ "OMX_AUDIO_MIDIPlayBackStateParsing", "group__midi.html#gga188ab18146b92cdae5141c6222e9ef08a39c1e38c1a2c718b3bdffa07c379d180", null ],
      [ "OMX_AUDIO_MIDIPlayBackStateOpenEngaged", "group__midi.html#gga188ab18146b92cdae5141c6222e9ef08a4c29bcd1640923f4187eba3528fc360b", null ],
      [ "OMX_AUDIO_MIDIPlayBackStatePlaying", "group__midi.html#gga188ab18146b92cdae5141c6222e9ef08a21bc52492c88f3a1c1954652dd5a2fda", null ],
      [ "OMX_AUDIO_MIDIPlayBackStatePlayingPartially", "group__midi.html#gga188ab18146b92cdae5141c6222e9ef08a1b6d3a482060eaa3b671de342e65b4c5", null ],
      [ "OMX_AUDIO_MIDIPlayBackStatePlayingSilently", "group__midi.html#gga188ab18146b92cdae5141c6222e9ef08a74321467d17db546cf23fedc0928181d", null ],
      [ "OMX_AUDIO_MIDIPlayBackStateKhronosExtensions", "group__midi.html#gga188ab18146b92cdae5141c6222e9ef08a8671f7e4b554f83f6c6c7b6fa9ac0186", null ],
      [ "OMX_AUDIO_MIDIPlayBackStateVendorStartUnused", "group__midi.html#gga188ab18146b92cdae5141c6222e9ef08ae2d53a60db61a3a7a535eaabe2a6d34a", null ],
      [ "OMX_AUDIO_MIDIPlayBackStateMax", "group__midi.html#gga188ab18146b92cdae5141c6222e9ef08a7fc81d2b1120a4817ae1a6e3cdb5307e", null ]
    ] ],
    [ "OMX_AUDIO_MIDISOUNDBANKLAYOUTTYPE", "group__midi.html#ga6f9b6234718cb6fd01ee7d4a5f08e2a8", [
      [ "OMX_AUDIO_MIDISoundBankLayoutUnused", "group__midi.html#gga6f9b6234718cb6fd01ee7d4a5f08e2a8a94ba617b8d2512cb4456c678081d7c2c", null ],
      [ "OMX_AUDIO_MIDISoundBankLayoutGM", "group__midi.html#gga6f9b6234718cb6fd01ee7d4a5f08e2a8a8739e019a98ab9cbecacec4f98a52315", null ],
      [ "OMX_AUDIO_MIDISoundBankLayoutGM2", "group__midi.html#gga6f9b6234718cb6fd01ee7d4a5f08e2a8a4aabf2a3db9b062acefef0efe0d11665", null ],
      [ "OMX_AUDIO_MIDISoundBankLayoutUser", "group__midi.html#gga6f9b6234718cb6fd01ee7d4a5f08e2a8aaf841a5170834e2254342c492d3f526a", null ],
      [ "OMX_AUDIO_MIDISoundBankLayoutKhronosExtensions", "group__midi.html#gga6f9b6234718cb6fd01ee7d4a5f08e2a8a7891a870687f63faf3a60a32f92051ab", null ],
      [ "OMX_AUDIO_MIDISoundBankLayoutVendorStartUnused", "group__midi.html#gga6f9b6234718cb6fd01ee7d4a5f08e2a8a924ef340732172e95db5ba61dffb762b", null ],
      [ "OMX_AUDIO_MIDISoundBankLayoutMax", "group__midi.html#gga6f9b6234718cb6fd01ee7d4a5f08e2a8ae00974e017c7df5e3566c25127feaff3", null ]
    ] ],
    [ "OMX_AUDIO_MIDISOUNDBANKTYPE", "group__midi.html#gad355f0d55ed54bdca395694bf2b7fe09", [
      [ "OMX_AUDIO_MIDISoundBankUnused", "group__midi.html#ggad355f0d55ed54bdca395694bf2b7fe09aa8e170a5b87415c73d7815eabca905a6", null ],
      [ "OMX_AUDIO_MIDISoundBankDLS1", "group__midi.html#ggad355f0d55ed54bdca395694bf2b7fe09a9560b28d4cb8ac64f07d27dfccf7806d", null ],
      [ "OMX_AUDIO_MIDISoundBankDLS2", "group__midi.html#ggad355f0d55ed54bdca395694bf2b7fe09aaad82920973f1de19bd348ac441a59f6", null ],
      [ "OMX_AUDIO_MIDISoundBankMobileDLSBase", "group__midi.html#ggad355f0d55ed54bdca395694bf2b7fe09a5e614142a097681102d4ae67a82d6a57", null ],
      [ "OMX_AUDIO_MIDISoundBankMobileDLSPlusOptions", "group__midi.html#ggad355f0d55ed54bdca395694bf2b7fe09a5296dc4676ed8e39b80c13993356ac63", null ],
      [ "OMX_AUDIO_MIDISoundBankKhronosExtensions", "group__midi.html#ggad355f0d55ed54bdca395694bf2b7fe09af92505247fe1cc04a86695fddebae551", null ],
      [ "OMX_AUDIO_MIDISoundBankVendorStartUnused", "group__midi.html#ggad355f0d55ed54bdca395694bf2b7fe09a01f9698c52b004153dfb7cf705c9d911", null ],
      [ "OMX_AUDIO_MIDISoundBankMax", "group__midi.html#ggad355f0d55ed54bdca395694bf2b7fe09a564f530931f07ca69a5b01df7cc813a8", null ]
    ] ]
];