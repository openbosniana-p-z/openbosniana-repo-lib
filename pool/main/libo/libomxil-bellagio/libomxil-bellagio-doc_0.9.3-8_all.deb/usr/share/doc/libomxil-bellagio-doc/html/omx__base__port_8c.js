var omx__base__port_8c =
[
    [ "DEFAULT_MIN_NUMBER_BUFFERS_PER_PORT", "omx__base__port_8c.html#aff6e673af1068a870627a9d1783ae7ac", null ],
    [ "DEFAULT_NUMBER_BUFFERS_PER_PORT", "omx__base__port_8c.html#a6c191934754e5b3e12b6c44fa4308d12", null ],
    [ "base_port_AllocateBuffer", "omx__base__port_8c.html#af37cd05fdadf451e289ab2033d7dc5c1", null ],
    [ "base_port_AllocateTunnelBuffer", "omx__base__port_8c.html#ad3c452372068c7801b428602819852fa", null ],
    [ "base_port_ComponentTunnelRequest", "omx__base__port_8c.html#acd34dcd603b1658b1fe0cc49269a99dc", null ],
    [ "base_port_Constructor", "omx__base__port_8c.html#af110b44dc7076094cf0234697e51fba6", null ],
    [ "base_port_Destructor", "omx__base__port_8c.html#afcf48c3877518487d2706e8e6bef1a2d", null ],
    [ "base_port_DisablePort", "omx__base__port_8c.html#abb30a063d32b3d2de151e64f92fe4268", null ],
    [ "base_port_EnablePort", "omx__base__port_8c.html#afddd2809a3944f8d6116c3b8d4e611d9", null ],
    [ "base_port_FlushProcessingBuffers", "omx__base__port_8c.html#a267216c232fc98dd0b2e839f91a86935", null ],
    [ "base_port_FreeBuffer", "omx__base__port_8c.html#ac2560c40ad461ba3f6a061c576948d9a", null ],
    [ "base_port_FreeTunnelBuffer", "omx__base__port_8c.html#ac6b1f00a1ac9c6d98a7e237137bbd99f", null ],
    [ "base_port_ReturnBufferFunction", "omx__base__port_8c.html#aadf72263226d5123bf9cd27ab80b2750", null ],
    [ "base_port_SendBufferFunction", "omx__base__port_8c.html#a4b4bee757868601bdf493a35c7440dfa", null ],
    [ "base_port_UseBuffer", "omx__base__port_8c.html#ae97c3b85669a4ccca24845b0a4f93132", null ]
];