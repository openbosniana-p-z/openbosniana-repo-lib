var struct_name_index_type =
[
    [ "component_name", "struct_name_index_type.html#af5d2a248ace96e42786ad526c7bff75d", null ],
    [ "index", "struct_name_index_type.html#a79c385b158de5f6ce08dfbc66557bd9b", null ],
    [ "max_components", "struct_name_index_type.html#acff0ccb162921b24fc6202127b8a2680", null ]
];