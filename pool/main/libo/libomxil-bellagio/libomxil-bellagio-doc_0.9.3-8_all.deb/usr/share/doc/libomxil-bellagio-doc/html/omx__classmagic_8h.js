var omx__classmagic_8h =
[
    [ "CLASS", "omx__classmagic_8h.html#abe50fa9c709ad8b5732c7c786cf13373", null ],
    [ "DERIVEDCLASS", "omx__classmagic_8h.html#a3d333bb35760e355d5270579d57f4309", null ],
    [ "ENDCLASS", "omx__classmagic_8h.html#a38f665d1a5cd230405e046e3acb30237", null ]
];