var omx__video__scheduler__component_8c =
[
    [ "CLOCKPORT_INDEX", "omx__video__scheduler__component_8c.html#a015489e05ca0ee94be2747067bce81fb", null ],
    [ "DEFAULT_HEIGHT", "omx__video__scheduler__component_8c.html#a1879f9e5604a01f0983829846001ab23", null ],
    [ "DEFAULT_VIDEO_INPUT_BUF_SIZE", "omx__video__scheduler__component_8c.html#ae7410194c278d4e20ceeb9cb94f64a56", null ],
    [ "DEFAULT_WIDTH", "omx__video__scheduler__component_8c.html#a93493eb8fae5549bd5be67f3449245e0", null ],
    [ "omx_video_scheduler_component_BufferMgmtCallback", "omx__video__scheduler__component_8c.html#a3d5d77905e7f7aee8adc63860157e6a7", null ],
    [ "omx_video_scheduler_component_ClockPortHandleFunction", "omx__video__scheduler__component_8c.html#a4d027931a09394685682b3eef46768d9", null ],
    [ "omx_video_scheduler_component_Constructor", "omx__video__scheduler__component_8c.html#ac4077bbdb21dc320b56082cf58746eb9", null ],
    [ "omx_video_scheduler_component_Destructor", "omx__video__scheduler__component_8c.html#a5cc0d3b48030c5517efe01505f64619e", null ],
    [ "omx_video_scheduler_component_GetParameter", "omx__video__scheduler__component_8c.html#a67d833882137750ab6df08c3d2858901", null ],
    [ "omx_video_scheduler_component_port_FlushProcessingBuffers", "omx__video__scheduler__component_8c.html#aabc5c495864ae347b156a596aca6df56", null ],
    [ "omx_video_scheduler_component_port_SendBufferFunction", "omx__video__scheduler__component_8c.html#a8d3dc621ad5150ad610f80df9ba81a94", null ],
    [ "omx_video_scheduler_component_SetParameter", "omx__video__scheduler__component_8c.html#ad86cc6fc0a352547bf22423c9ce13ef2", null ]
];