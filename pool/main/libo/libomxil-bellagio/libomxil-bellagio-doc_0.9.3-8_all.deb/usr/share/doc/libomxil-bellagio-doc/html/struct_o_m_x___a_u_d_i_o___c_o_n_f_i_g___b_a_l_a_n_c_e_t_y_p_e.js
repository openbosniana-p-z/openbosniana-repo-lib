var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_l_a_n_c_e_t_y_p_e =
[
    [ "nBalance", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_l_a_n_c_e_t_y_p_e.html#adde051e0f0f2bbc1f9410869431ac9c3", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_l_a_n_c_e_t_y_p_e.html#a85762675243bc5d0eed85087f51ee147", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_l_a_n_c_e_t_y_p_e.html#a6dcf5840485abb7540320e5fa9035b81", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___b_a_l_a_n_c_e_t_y_p_e.html#a9601d733dc54d35c41e089a95f473f61", null ]
];