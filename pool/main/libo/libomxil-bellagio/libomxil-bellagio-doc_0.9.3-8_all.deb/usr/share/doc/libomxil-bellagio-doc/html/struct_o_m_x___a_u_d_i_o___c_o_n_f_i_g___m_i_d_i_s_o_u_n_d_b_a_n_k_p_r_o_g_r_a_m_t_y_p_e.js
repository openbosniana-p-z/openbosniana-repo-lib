var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e =
[
    [ "nChannel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#a60f628f98f7b5470119f9a9de0f44770", null ],
    [ "nIDProgram", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#a4483d6ef887a5acbc449134b884035bb", null ],
    [ "nIDSoundBank", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#a21ee8fe8f07bc4258c7b4c161a5893de", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#a93b2cefbc2b4ae5244e3e6f4afde5258", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#ae4821af7f46a1d97307aa29722dc29b8", null ],
    [ "nUserSoundBankIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#a56856cf1c0b22087bbbfcc30e3b5f44b", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_o_u_n_d_b_a_n_k_p_r_o_g_r_a_m_t_y_p_e.html#af5959ed1d987128af47a692a4b77ed08", null ]
];