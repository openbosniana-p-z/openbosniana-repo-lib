var _o_m_x_core_r_m_ext_8h =
[
    [ "OMX_RESOURCETYPE", "_o_m_x_core_r_m_ext_8h.html#af689ec72d1b2b9854a276eebe0bf9877", [
      [ "OMX_ResourceTypeMemory", "_o_m_x_core_r_m_ext_8h.html#af689ec72d1b2b9854a276eebe0bf9877a5eaac244dfa28f30d452aeba458e2a77", null ],
      [ "OMX_ResourceTypeCpu", "_o_m_x_core_r_m_ext_8h.html#af689ec72d1b2b9854a276eebe0bf9877a5b828c6bce42316865e8fc700f414a39", null ]
    ] ],
    [ "getMultiResourceEstimates", "_o_m_x_core_r_m_ext_8h.html#a776bcbe5b8104072302444e4cd66f96a", null ],
    [ "getSupportedQualityLevels", "_o_m_x_core_r_m_ext_8h.html#a5548f5eb1f249e96aa79ab16fa20eb1f", null ],
    [ "readRegistryFile", "_o_m_x_core_r_m_ext_8h.html#afeac8319ca416c921a256407e42b089c", null ]
];