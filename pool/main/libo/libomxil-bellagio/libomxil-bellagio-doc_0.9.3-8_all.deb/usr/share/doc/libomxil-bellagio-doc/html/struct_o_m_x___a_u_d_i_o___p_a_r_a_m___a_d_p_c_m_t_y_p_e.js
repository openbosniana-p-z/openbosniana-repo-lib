var struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_d_p_c_m_t_y_p_e =
[
    [ "nBitsPerSample", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_d_p_c_m_t_y_p_e.html#a9965ed98281d9c9d5103d41eb090039e", null ],
    [ "nChannels", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_d_p_c_m_t_y_p_e.html#a8f2c0bcb7f1bf52e7a2a9d15c36fe9f3", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_d_p_c_m_t_y_p_e.html#a2c9b8f59410778c312256153fc1fd69e", null ],
    [ "nSampleRate", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_d_p_c_m_t_y_p_e.html#afca0a15dd701d14068b29ab48d30ddda", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_d_p_c_m_t_y_p_e.html#a7bcdef0f547b6ab468869f4f732aea85", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___p_a_r_a_m___a_d_p_c_m_t_y_p_e.html#a0ac9fae5b9ad3ac7850f844a18dc7c6c", null ]
];