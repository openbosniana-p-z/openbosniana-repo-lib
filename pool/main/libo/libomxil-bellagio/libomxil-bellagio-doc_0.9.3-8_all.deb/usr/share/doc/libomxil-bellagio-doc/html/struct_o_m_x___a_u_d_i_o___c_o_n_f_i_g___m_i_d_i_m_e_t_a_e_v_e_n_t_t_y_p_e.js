var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e =
[
    [ "nIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#aa0dbc475a3c776a6dfb012f1187bbbad", null ],
    [ "nMetaEventSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#a10dc647459c4f203730e6b8e2af5c516", null ],
    [ "nMetaEventType", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#aa3ac808d0f94611a4debdf4db174ce04", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#af20c83a7f06f40d3d096c9a52aff1d30", null ],
    [ "nPosition", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#ac889da9e863572411f585946828358f5", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#a46da183c055f35bd6b60c03097fc63af", null ],
    [ "nTrack", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#a197621d9cda982bfd130933eeafd2301", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_t_y_p_e.html#af21834eb345fba04712b25e15b5c8a62", null ]
];