var group__cp =
[
    [ "OMX_PARAM_CONTENTURITYPE", "struct_o_m_x___p_a_r_a_m___c_o_n_t_e_n_t_u_r_i_t_y_p_e.html", [
      [ "contentURI", "struct_o_m_x___p_a_r_a_m___c_o_n_t_e_n_t_u_r_i_t_y_p_e.html#ad9b93c174362a50fbce53ad19259d419", null ],
      [ "nSize", "struct_o_m_x___p_a_r_a_m___c_o_n_t_e_n_t_u_r_i_t_y_p_e.html#a861c500a2d35934daa77d6aa952eb9b8", null ],
      [ "nVersion", "struct_o_m_x___p_a_r_a_m___c_o_n_t_e_n_t_u_r_i_t_y_p_e.html#ac33304c049e7282b7397be4bde8abf44", null ]
    ] ],
    [ "OMX_PARAM_CONTENTPIPETYPE", "struct_o_m_x___p_a_r_a_m___c_o_n_t_e_n_t_p_i_p_e_t_y_p_e.html", [
      [ "hPipe", "struct_o_m_x___p_a_r_a_m___c_o_n_t_e_n_t_p_i_p_e_t_y_p_e.html#a7c1c7eb3620faa0ba1212c4995c8ab1f", null ],
      [ "nSize", "struct_o_m_x___p_a_r_a_m___c_o_n_t_e_n_t_p_i_p_e_t_y_p_e.html#ac0576a9afd716966ae720c0ab2a78fe5", null ],
      [ "nVersion", "struct_o_m_x___p_a_r_a_m___c_o_n_t_e_n_t_p_i_p_e_t_y_p_e.html#aa7abae4f889ed8674349f249eb6bbc8b", null ]
    ] ],
    [ "CP_PIPETYPE", "struct_c_p___p_i_p_e_t_y_p_e.html", [
      [ "CheckAvailableBytes", "struct_c_p___p_i_p_e_t_y_p_e.html#a66999dbc8bdd73de23ff878d178d6443", null ],
      [ "Close", "struct_c_p___p_i_p_e_t_y_p_e.html#ad6edf74783f7cf5ab82c0f64f0dbb5f7", null ],
      [ "Create", "struct_c_p___p_i_p_e_t_y_p_e.html#a27fe775a362e0881a226ba03eb7521aa", null ],
      [ "GetPosition", "struct_c_p___p_i_p_e_t_y_p_e.html#ac1aa7fc5710719328676bee76f0e92dc", null ],
      [ "GetWriteBuffer", "struct_c_p___p_i_p_e_t_y_p_e.html#acb76d30c4cb248cbbccec2959a7ed321", null ],
      [ "Open", "struct_c_p___p_i_p_e_t_y_p_e.html#a99652b10ea8f43cb323be9b6a13a8d81", null ],
      [ "Read", "struct_c_p___p_i_p_e_t_y_p_e.html#ae9177e01bb6b7774d4bece2aaf6c79e3", null ],
      [ "ReadBuffer", "struct_c_p___p_i_p_e_t_y_p_e.html#a6eacbcad997ad72c588f1bde6d788c46", null ],
      [ "RegisterCallback", "struct_c_p___p_i_p_e_t_y_p_e.html#a34dfe013dc6d3f6f2edc9e4e928517e7", null ],
      [ "ReleaseReadBuffer", "struct_c_p___p_i_p_e_t_y_p_e.html#a238a6d307ba4cfc7963cdcea10a9a305", null ],
      [ "SetPosition", "struct_c_p___p_i_p_e_t_y_p_e.html#a93e27b70626ca5e662ef93875f996319", null ],
      [ "Write", "struct_c_p___p_i_p_e_t_y_p_e.html#a2c1ffc70e0ed3c39a6b6e0073cdcb7a4", null ],
      [ "WriteBuffer", "struct_c_p___p_i_p_e_t_y_p_e.html#a2b79ef157d1779181adc2ba8b7b3e9bd", null ]
    ] ],
    [ "CP_ACCESSTYPE", "group__cp.html#ga5829189ba849266f8e449528284216ca", null ],
    [ "CP_CHECKBYTESRESULTTYPE", "group__cp.html#ga85e04a5af412470ceb934df33c2ddcd2", null ],
    [ "CP_EVENTTYPE", "group__cp.html#ga6279d0716a01fcac518be7316b663674", null ],
    [ "CP_ORIGINTYPE", "group__cp.html#ga0e7e504f2aad98950d5545233c60e654", null ],
    [ "CP_PIPETYPE", "group__cp.html#ga579f29b449afbc87df3e2da330ef0a95", null ],
    [ "OMX_PARAM_CONTENTPIPETYPE", "group__cp.html#gaa21815ff34dd71ff94252d0acb372390", null ],
    [ "OMX_PARAM_CONTENTURITYPE", "group__cp.html#ga2c6fb3ab112d83d1221ffb05761e5106", null ],
    [ "CP_ACCESSTYPE", "group__cp.html#ga0723c31d1ddd71cae78ef2b97abf286c", [
      [ "CP_AccessRead", "group__cp.html#gga0723c31d1ddd71cae78ef2b97abf286ca6ebd18724c9ac0778015a7edf22769ef", null ],
      [ "CP_AccessWrite", "group__cp.html#gga0723c31d1ddd71cae78ef2b97abf286ca172d48ae95a8f3463fa9f612e170d1c9", null ],
      [ "CP_AccessReadWrite", "group__cp.html#gga0723c31d1ddd71cae78ef2b97abf286ca419a23b906de70302e1bb4eec21d9884", null ],
      [ "CP_AccessKhronosExtensions", "group__cp.html#gga0723c31d1ddd71cae78ef2b97abf286ca48cd91e245e72661d4b71fc79c807b01", null ],
      [ "CP_AccessVendorStartUnused", "group__cp.html#gga0723c31d1ddd71cae78ef2b97abf286caad736d414554ca61f4f7616721084db7", null ],
      [ "CP_AccessMax", "group__cp.html#gga0723c31d1ddd71cae78ef2b97abf286cabbe05bfdf2ae032bc7caaa2521c7dd4b", null ]
    ] ],
    [ "CP_CHECKBYTESRESULTTYPE", "group__cp.html#gae2cb8126a9c1e61e9685fd0f5bdd9bb5", [
      [ "CP_CheckBytesOk", "group__cp.html#ggae2cb8126a9c1e61e9685fd0f5bdd9bb5aac8302184a1f160f64477c5500553469", null ],
      [ "CP_CheckBytesNotReady", "group__cp.html#ggae2cb8126a9c1e61e9685fd0f5bdd9bb5a0eab6a60e56f246db9a85e671f4d2b5e", null ],
      [ "CP_CheckBytesInsufficientBytes", "group__cp.html#ggae2cb8126a9c1e61e9685fd0f5bdd9bb5a586753552280e181be7a4f777fcd2730", null ],
      [ "CP_CheckBytesAtEndOfStream", "group__cp.html#ggae2cb8126a9c1e61e9685fd0f5bdd9bb5a39e2dc413d85f41c6883a6febbe709b8", null ],
      [ "CP_CheckBytesOutOfBuffers", "group__cp.html#ggae2cb8126a9c1e61e9685fd0f5bdd9bb5aac57b7058da73888d716e85b9b01eaed", null ],
      [ "CP_CheckBytesKhronosExtensions", "group__cp.html#ggae2cb8126a9c1e61e9685fd0f5bdd9bb5a7dfcd53c617d14fee3a590a8f48422ec", null ],
      [ "CP_CheckBytesVendorStartUnused", "group__cp.html#ggae2cb8126a9c1e61e9685fd0f5bdd9bb5a0b0a119e18ba58f443da2bfb2240424e", null ],
      [ "CP_CheckBytesMax", "group__cp.html#ggae2cb8126a9c1e61e9685fd0f5bdd9bb5af7e6ba3064473e8109824e7b7bd01f04", null ]
    ] ],
    [ "CP_EVENTTYPE", "group__cp.html#ga7dc05cd1f47f076d6a12012ed71b1888", [
      [ "CP_BytesAvailable", "group__cp.html#gga7dc05cd1f47f076d6a12012ed71b1888aed6573190378e9d57ad9f5ab6483a966", null ],
      [ "CP_Overflow", "group__cp.html#gga7dc05cd1f47f076d6a12012ed71b1888a35026b687765a42fdb16facfddbf34f2", null ],
      [ "CP_PipeDisconnected", "group__cp.html#gga7dc05cd1f47f076d6a12012ed71b1888a86080dfe6b5e080d52bfb2db5bbb724a", null ],
      [ "CP_EventKhronosExtensions", "group__cp.html#gga7dc05cd1f47f076d6a12012ed71b1888a3fd792bc448979c7b47de41c98636577", null ],
      [ "CP_EventVendorStartUnused", "group__cp.html#gga7dc05cd1f47f076d6a12012ed71b1888a474ff7146b1e5ed940c5757d6790e0e9", null ],
      [ "CP_EventMax", "group__cp.html#gga7dc05cd1f47f076d6a12012ed71b1888a6f870528818a1dd8c9a225210b107019", null ]
    ] ],
    [ "CP_ORIGINTYPE", "group__cp.html#gaa8d8efe4a0dfc1f17bae5f8fdf5e157e", [
      [ "CP_OriginBegin", "group__cp.html#ggaa8d8efe4a0dfc1f17bae5f8fdf5e157ea60db3329d056fa111fbcd3b01133e7a7", null ],
      [ "CP_OriginCur", "group__cp.html#ggaa8d8efe4a0dfc1f17bae5f8fdf5e157ea24a587587260a74efbdfbd9575d7135b", null ],
      [ "CP_OriginEnd", "group__cp.html#ggaa8d8efe4a0dfc1f17bae5f8fdf5e157ea73a8220db180976fd56907c3614e6f7c", null ],
      [ "CP_OriginKhronosExtensions", "group__cp.html#ggaa8d8efe4a0dfc1f17bae5f8fdf5e157ea528894814ba4ffc85ac17d5d08eea86d", null ],
      [ "CP_OriginVendorStartUnused", "group__cp.html#ggaa8d8efe4a0dfc1f17bae5f8fdf5e157ea605ef543ce6329875b684f6530adc888", null ],
      [ "CP_OriginMax", "group__cp.html#ggaa8d8efe4a0dfc1f17bae5f8fdf5e157eaa1b10fe5f7f7450806499b71d25e643d", null ]
    ] ],
    [ "OMX_GetContentPipe", "group__cp.html#gaf0ce1670a388de6e591ae12c64e5eb02", null ]
];