var omxvolcontroltest_8c =
[
    [ "display_help", "omxvolcontroltest_8c.html#a8f0b63bf650a5ceefc36d7e3bcb02f63", null ],
    [ "main", "omxvolcontroltest_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "volcEmptyBufferDone", "omxvolcontroltest_8c.html#a4bb1d8659e5459188216ae9042c8acbe", null ],
    [ "volcEventHandler", "omxvolcontroltest_8c.html#a820f7d55f0c0e4ae4e2ae4d90c8f10ed", null ],
    [ "volcFillBufferDone", "omxvolcontroltest_8c.html#a7ae3416364a824ab62b9254476b7ff66", null ],
    [ "appPriv", "omxvolcontroltest_8c.html#aef8e73812694e872b898c24afac4b2c2", null ],
    [ "callbacks", "omxvolcontroltest_8c.html#a38f986b17f34fc6b192366b344dab6f8", null ],
    [ "err", "omxvolcontroltest_8c.html#a756067b481e3ea442bfda1a27ce0a901", null ],
    [ "fd", "omxvolcontroltest_8c.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "filesize", "omxvolcontroltest_8c.html#a613e2963514a5e256a448f708c1af880", null ],
    [ "flagInputReceived", "omxvolcontroltest_8c.html#a09001be8d1bd644e2b2e7e173ae30355", null ],
    [ "flagIsGain", "omxvolcontroltest_8c.html#a639b49ecc44734e0e8a7f97fbd63da63", null ],
    [ "flagIsOutputExpected", "omxvolcontroltest_8c.html#a592913a656f2d9d024d7835c8592bcf0", null ],
    [ "flagOutputReceived", "omxvolcontroltest_8c.html#a46b554ecfbc82a1d706e9a4c9bf8c0bf", null ],
    [ "handle", "omxvolcontroltest_8c.html#a375d9c82d55d9c4a4a2492c25f4e24af", null ],
    [ "input_file", "omxvolcontroltest_8c.html#aa4f3a15de34c409bdec6ceacf93078ed", null ],
    [ "outfile", "omxvolcontroltest_8c.html#ae581849c67336453bd5b81e6518019a9", null ],
    [ "output_file", "omxvolcontroltest_8c.html#a95494f20e295a6f609b6ca642e48f683", null ]
];