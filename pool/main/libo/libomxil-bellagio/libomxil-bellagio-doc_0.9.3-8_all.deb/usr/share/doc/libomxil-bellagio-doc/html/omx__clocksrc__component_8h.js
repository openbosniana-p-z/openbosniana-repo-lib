var omx__clocksrc__component_8h =
[
    [ "CLOCK_COMP_NAME", "omx__clocksrc__component_8h.html#a05e7bdfe1dc82b80c06db3a808df9af4", null ],
    [ "CLOCK_COMP_ROLE", "omx__clocksrc__component_8h.html#ad3fc987dffd5055091e749a742659637", null ],
    [ "MAX_CLOCK_COMPONENTS", "omx__clocksrc__component_8h.html#a45b2c5417f814abce49328372267bd06", null ],
    [ "MAX_CLOCK_PORTS", "omx__clocksrc__component_8h.html#a8ab04026912462802b05aac83f77b607", null ],
    [ "omx_clocksrc_component_PrivateType_FIELDS", "omx__clocksrc__component_8h.html#a0dd6139ede4220211db440d37a9b3057", null ],
    [ "clocksrc_port_FlushProcessingBuffers", "omx__clocksrc__component_8h.html#a5dd5351d8581a40add4ddc06d0663d10", null ],
    [ "omx_clocksrc_BufferMgmtFunction", "omx__clocksrc__component_8h.html#a27535e7dcb83ffca5836fbbb929dead9", null ],
    [ "omx_clocksrc_component_BufferMgmtCallback", "omx__clocksrc__component_8h.html#a4fcc80070ec41d383714eeeb42508659", null ],
    [ "omx_clocksrc_component_Constructor", "omx__clocksrc__component_8h.html#ac43faf3a10e98644d388d9346b41e51f", null ],
    [ "omx_clocksrc_component_Destructor", "omx__clocksrc__component_8h.html#a24d2b63335156ba8c45f0f24176b1c2d", null ],
    [ "omx_clocksrc_component_GetConfig", "omx__clocksrc__component_8h.html#a1e958f1bb12175fa3166b513019c17cb", null ],
    [ "omx_clocksrc_component_GetParameter", "omx__clocksrc__component_8h.html#a0a3f7da2bf334585e0ca400a50bd639b", null ],
    [ "omx_clocksrc_component_SendCommand", "omx__clocksrc__component_8h.html#ae81ac2ac9aadc4842d8fb9be089c19da", null ],
    [ "omx_clocksrc_component_SetConfig", "omx__clocksrc__component_8h.html#aa1b59a18944757455eaff7121a2f0d78", null ],
    [ "omx_clocksrc_component_SetParameter", "omx__clocksrc__component_8h.html#a0dba76deb162fdd37d1fa8727b5cb2ef", null ]
];