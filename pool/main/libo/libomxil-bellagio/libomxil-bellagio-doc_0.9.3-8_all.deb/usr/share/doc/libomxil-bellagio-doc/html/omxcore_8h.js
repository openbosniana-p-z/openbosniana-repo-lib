var omxcore_8h =
[
    [ "OSCL_EXPORT_REF", "omxcore_8h.html#a665038e768ece73b351ebc4696735cfc", null ],
    [ "OSCL_IMPORT_REF", "omxcore_8h.html#a6de0f53c5c11f8f53ce72c70d74d9abc", null ],
    [ "SPECREVISION", "omxcore_8h.html#a1d0cb2ae44b83ba2b3efb247d42236f7", null ],
    [ "SPECSTEP", "omxcore_8h.html#aabf66d6b3fe21f2c8437918f8cddde92", null ],
    [ "SPECVERSIONMAJOR", "omxcore_8h.html#af40b85edcbe14a13d4422ef7189dcdd9", null ],
    [ "SPECVERSIONMINOR", "omxcore_8h.html#a0bdc096d0b64fd69fc98fd3dbd1a5e37", null ],
    [ "BOSA_AddComponentLoader", "omxcore_8h.html#a10fe142ab922602b4619bf1ea6231de4", null ]
];