var _o_m_x_component_r_m_ext_8c =
[
    [ "getQualityLevel", "_o_m_x_component_r_m_ext_8c.html#aaf8ed3f8fe5341dda4861c43a8e8c89c", null ],
    [ "setQualityLevel", "_o_m_x_component_r_m_ext_8c.html#a6dbc6c006900f3635a371835567293c8", null ]
];