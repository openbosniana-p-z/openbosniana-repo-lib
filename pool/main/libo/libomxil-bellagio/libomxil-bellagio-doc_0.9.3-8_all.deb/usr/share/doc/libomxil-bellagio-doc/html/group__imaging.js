var group__imaging =
[
    [ "OMX_IMAGE_PORTDEFINITIONTYPE", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html", [
      [ "bFlagErrorConcealment", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#a3a988dabfd86c280b41708819abbbb50", null ],
      [ "cMIMEType", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#a9b84f9e4630e4510ea5cbd42eecc3686", null ],
      [ "eColorFormat", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#a79d193560fc92944d0bb5ccb23e69978", null ],
      [ "eCompressionFormat", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#a4df77ddb0659eb342df9d84527dbf157", null ],
      [ "nFrameHeight", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#a5a59dbe3f2aeb665634676bb614e07bf", null ],
      [ "nFrameWidth", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#ab273adc49e417aec3096a1069f096de6", null ],
      [ "nSliceHeight", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#a60cfed0d8094ee6a5286aaadc3694f91", null ],
      [ "nStride", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#a49f28a02280ba1c5db9de5993e7f93e2", null ],
      [ "pNativeRender", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#a1cf771c879f0297f81cc833265db040c", null ],
      [ "pNativeWindow", "struct_o_m_x___i_m_a_g_e___p_o_r_t_d_e_f_i_n_i_t_i_o_n_t_y_p_e.html#a602827bc85cc0b3d1425e1dd6da7ef6d", null ]
    ] ],
    [ "OMX_IMAGE_PARAM_PORTFORMATTYPE", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___p_o_r_t_f_o_r_m_a_t_t_y_p_e.html", [
      [ "eColorFormat", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___p_o_r_t_f_o_r_m_a_t_t_y_p_e.html#a53de4225cdcf75ee6d119787d6db04d2", null ],
      [ "eCompressionFormat", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___p_o_r_t_f_o_r_m_a_t_t_y_p_e.html#a56e70928280311a7db1702ad683f8854", null ],
      [ "nIndex", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___p_o_r_t_f_o_r_m_a_t_t_y_p_e.html#a2f6d9aa40e3f4001eb0545ca8d77c8f2", null ],
      [ "nPortIndex", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___p_o_r_t_f_o_r_m_a_t_t_y_p_e.html#a27854675af06aeaed748ec4bc4b63430", null ],
      [ "nSize", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___p_o_r_t_f_o_r_m_a_t_t_y_p_e.html#a9b3b5e5ca57454f1811fd872bba5cbaa", null ],
      [ "nVersion", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___p_o_r_t_f_o_r_m_a_t_t_y_p_e.html#a434e7de29d7c91ce9a8e7909c06d6670", null ]
    ] ],
    [ "OMX_IMAGE_PARAM_FLASHCONTROLTYPE", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___f_l_a_s_h_c_o_n_t_r_o_l_t_y_p_e.html", [
      [ "eFlashControl", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___f_l_a_s_h_c_o_n_t_r_o_l_t_y_p_e.html#a521105b35c81695f36e5fa44cad46043", null ],
      [ "nPortIndex", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___f_l_a_s_h_c_o_n_t_r_o_l_t_y_p_e.html#a04c5ead061b39f8123fc028a36ef42f8", null ],
      [ "nSize", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___f_l_a_s_h_c_o_n_t_r_o_l_t_y_p_e.html#a1e3190d1010c31afc1e494eb6f64616e", null ],
      [ "nVersion", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___f_l_a_s_h_c_o_n_t_r_o_l_t_y_p_e.html#a81d2c381ca5e91b2a45728e9140aaba8", null ]
    ] ],
    [ "OMX_IMAGE_CONFIG_FOCUSCONTROLTYPE", "struct_o_m_x___i_m_a_g_e___c_o_n_f_i_g___f_o_c_u_s_c_o_n_t_r_o_l_t_y_p_e.html", [
      [ "eFocusControl", "struct_o_m_x___i_m_a_g_e___c_o_n_f_i_g___f_o_c_u_s_c_o_n_t_r_o_l_t_y_p_e.html#a177da15a384d2bd2bc30203dcc4d32d7", null ],
      [ "nFocusStepIndex", "struct_o_m_x___i_m_a_g_e___c_o_n_f_i_g___f_o_c_u_s_c_o_n_t_r_o_l_t_y_p_e.html#adf5931c83ca0bb3cc893671c79677c09", null ],
      [ "nFocusSteps", "struct_o_m_x___i_m_a_g_e___c_o_n_f_i_g___f_o_c_u_s_c_o_n_t_r_o_l_t_y_p_e.html#a0eb2fcb6aea3071fc5e7346ea6c070f0", null ],
      [ "nPortIndex", "struct_o_m_x___i_m_a_g_e___c_o_n_f_i_g___f_o_c_u_s_c_o_n_t_r_o_l_t_y_p_e.html#addc22bbe6028290f3c04de547aabce4b", null ],
      [ "nSize", "struct_o_m_x___i_m_a_g_e___c_o_n_f_i_g___f_o_c_u_s_c_o_n_t_r_o_l_t_y_p_e.html#a4421bd29e8f8aa31b43982e9b58222ea", null ],
      [ "nVersion", "struct_o_m_x___i_m_a_g_e___c_o_n_f_i_g___f_o_c_u_s_c_o_n_t_r_o_l_t_y_p_e.html#afdfab79caa9d23d41082af736bec555f", null ]
    ] ],
    [ "OMX_IMAGE_PARAM_QFACTORTYPE", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_f_a_c_t_o_r_t_y_p_e.html", [
      [ "nPortIndex", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_f_a_c_t_o_r_t_y_p_e.html#afc16c9a2dce74238abe3a47d576110ea", null ],
      [ "nQFactor", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_f_a_c_t_o_r_t_y_p_e.html#a6f45a9c0d41dcb4738f6882b68003b74", null ],
      [ "nSize", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_f_a_c_t_o_r_t_y_p_e.html#a889ad4b1eaf2d80e27cfe41a8cece8f9", null ],
      [ "nVersion", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_f_a_c_t_o_r_t_y_p_e.html#ab4aa9ea9060744d5cf46f79f145eea28", null ]
    ] ],
    [ "OMX_IMAGE_PARAM_QUANTIZATIONTABLETYPE", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_u_a_n_t_i_z_a_t_i_o_n_t_a_b_l_e_t_y_p_e.html", [
      [ "eQuantizationTable", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_u_a_n_t_i_z_a_t_i_o_n_t_a_b_l_e_t_y_p_e.html#a9886ead83f2d722d195151b060772543", null ],
      [ "nPortIndex", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_u_a_n_t_i_z_a_t_i_o_n_t_a_b_l_e_t_y_p_e.html#abd8392d4a81bcc7b5e4e6a01dcdc7483", null ],
      [ "nQuantizationMatrix", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_u_a_n_t_i_z_a_t_i_o_n_t_a_b_l_e_t_y_p_e.html#a4cb5d57c34670f76f1f22a0f629e78c0", null ],
      [ "nSize", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_u_a_n_t_i_z_a_t_i_o_n_t_a_b_l_e_t_y_p_e.html#a440c88672ccfecc0b6b001a2748fb79f", null ],
      [ "nVersion", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___q_u_a_n_t_i_z_a_t_i_o_n_t_a_b_l_e_t_y_p_e.html#a1b38da9de18cea7d2a1e6d21f7d18eea", null ]
    ] ],
    [ "OMX_IMAGE_PARAM_HUFFMANTTABLETYPE", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___h_u_f_f_m_a_n_t_t_a_b_l_e_t_y_p_e.html", [
      [ "eHuffmanTable", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___h_u_f_f_m_a_n_t_t_a_b_l_e_t_y_p_e.html#ac7f8b7daf0e33ad286ffb87659f6a21a", null ],
      [ "nHuffmanTable", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___h_u_f_f_m_a_n_t_t_a_b_l_e_t_y_p_e.html#a1d9d57250404bdc89b52c3c76580382a", null ],
      [ "nNumberOfHuffmanCodeOfLength", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___h_u_f_f_m_a_n_t_t_a_b_l_e_t_y_p_e.html#a38a9c10d38a0bfffb1c5b55ccc6d0385", null ],
      [ "nPortIndex", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___h_u_f_f_m_a_n_t_t_a_b_l_e_t_y_p_e.html#ae65c00aa9400cf7d5712deba9bd643c5", null ],
      [ "nSize", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___h_u_f_f_m_a_n_t_t_a_b_l_e_t_y_p_e.html#aa08668fdadd0b98ae884a56fd88a15e7", null ],
      [ "nVersion", "struct_o_m_x___i_m_a_g_e___p_a_r_a_m___h_u_f_f_m_a_n_t_t_a_b_l_e_t_y_p_e.html#ae1f1d10594797007f60e805fd91226f8", null ]
    ] ],
    [ "OMX_IMAGE_CODINGTYPE", "group__imaging.html#ga9dadef46f779c38a661e73ecbaf526a5", null ],
    [ "OMX_IMAGE_CONFIG_FOCUSCONTROLTYPE", "group__imaging.html#gacb5673c7092488ebcf0e9ff5d6458b74", null ],
    [ "OMX_IMAGE_FLASHCONTROLTYPE", "group__imaging.html#ga518a6ac7fbe31cc26e60ab8b9a589a7d", null ],
    [ "OMX_IMAGE_FOCUSCONTROLTYPE", "group__imaging.html#ga1d3640125016bbed95eef2e9071a8a07", null ],
    [ "OMX_IMAGE_HUFFMANTABLETYPE", "group__imaging.html#ga5339212095f965b91703a7fd6d962583", null ],
    [ "OMX_IMAGE_PARAM_FLASHCONTROLTYPE", "group__imaging.html#ga3ebc9f039a1131623c705f165c1eb446", null ],
    [ "OMX_IMAGE_PARAM_HUFFMANTTABLETYPE", "group__imaging.html#ga98359c2e0c86c597811bf2212f3883da", null ],
    [ "OMX_IMAGE_PARAM_PORTFORMATTYPE", "group__imaging.html#ga42c3f21863005233f01213c3959a358e", null ],
    [ "OMX_IMAGE_PARAM_QFACTORTYPE", "group__imaging.html#gaee5751d3be941f83ba7e78ecef07044a", null ],
    [ "OMX_IMAGE_PARAM_QUANTIZATIONTABLETYPE", "group__imaging.html#gaa9673978a8534cfc7ff88006f9a1680b", null ],
    [ "OMX_IMAGE_PORTDEFINITIONTYPE", "group__imaging.html#gad2b15edf819343e250982de1a70a88b6", null ],
    [ "OMX_IMAGE_QUANTIZATIONTABLETYPE", "group__imaging.html#ga1a53e9a3bf2b98fcc3316f85d0fdef7c", null ],
    [ "OMX_IMAGE_CODINGTYPE", "group__imaging.html#ga63763166aacd9125a059d7132b8b1f6b", [
      [ "OMX_IMAGE_CodingUnused", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6ba1347dfaadef651f5bae16f74e3a77f1a", null ],
      [ "OMX_IMAGE_CodingAutoDetect", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6baac6b61b4d0f9502258e60840492edc97", null ],
      [ "OMX_IMAGE_CodingJPEG", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6baabe1500c84e9b4da283fc7855a92074d", null ],
      [ "OMX_IMAGE_CodingJPEG2K", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6ba16957956c59392a72fa9194ffbf375c4", null ],
      [ "OMX_IMAGE_CodingEXIF", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6bac736b90deff73c0712a5679c8b33d6f1", null ],
      [ "OMX_IMAGE_CodingTIFF", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6bafef26ce03c829b650af3a64bfa43a812", null ],
      [ "OMX_IMAGE_CodingGIF", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6ba46598f3a72f36ac81948edc52cb6a795", null ],
      [ "OMX_IMAGE_CodingPNG", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6ba151512b7b48c03e91ef99668a1e28a51", null ],
      [ "OMX_IMAGE_CodingLZW", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6ba872b9c0a7b9f04d54c5e6c7a4c09b209", null ],
      [ "OMX_IMAGE_CodingBMP", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6ba5ee8c01e9ae39d95dc7c78144a563b8d", null ],
      [ "OMX_IMAGE_CodingKhronosExtensions", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6bacb1236a34f2bbbc82036e3e503e8cd15", null ],
      [ "OMX_IMAGE_CodingVendorStartUnused", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6ba37a7436ce3c2916cee64479cf25dda0b", null ],
      [ "OMX_IMAGE_CodingMax", "group__imaging.html#gga63763166aacd9125a059d7132b8b1f6ba76c6ba9c7a3e921f7530bfb6d67dadeb", null ]
    ] ],
    [ "OMX_IMAGE_FLASHCONTROLTYPE", "group__imaging.html#ga73ef0638c668177337da4c0acb4a7298", [
      [ "OMX_IMAGE_FlashControlOn", "group__imaging.html#gga73ef0638c668177337da4c0acb4a7298afa265ec3e1f30d5933e377471100f31e", null ],
      [ "OMX_IMAGE_FlashControlOff", "group__imaging.html#gga73ef0638c668177337da4c0acb4a7298a9d49e76635c3f49c4a30e12b045e2d3d", null ],
      [ "OMX_IMAGE_FlashControlAuto", "group__imaging.html#gga73ef0638c668177337da4c0acb4a7298a37162c084477a8f3d74fabc4b4ac9889", null ],
      [ "OMX_IMAGE_FlashControlRedEyeReduction", "group__imaging.html#gga73ef0638c668177337da4c0acb4a7298acb9844d5f2e56777dc609b4014a2ce21", null ],
      [ "OMX_IMAGE_FlashControlFillin", "group__imaging.html#gga73ef0638c668177337da4c0acb4a7298a082d4fe7d486a05bb29fae11f68853a5", null ],
      [ "OMX_IMAGE_FlashControlTorch", "group__imaging.html#gga73ef0638c668177337da4c0acb4a7298a9a1645d04dc1f3ff2d326c2e5f3aa27b", null ],
      [ "OMX_IMAGE_FlashControlKhronosExtensions", "group__imaging.html#gga73ef0638c668177337da4c0acb4a7298af29cfd10b812497f587440fd3684a811", null ],
      [ "OMX_IMAGE_FlashControlVendorStartUnused", "group__imaging.html#gga73ef0638c668177337da4c0acb4a7298a5d4e84d06a7db81469757ff764984102", null ],
      [ "OMX_IMAGE_FlashControlMax", "group__imaging.html#gga73ef0638c668177337da4c0acb4a7298a3456ba5c784943ad6dae577be4b0110a", null ]
    ] ],
    [ "OMX_IMAGE_FOCUSCONTROLTYPE", "group__imaging.html#gad3450faa311ff1337e38201d797f05d0", [
      [ "OMX_IMAGE_FocusControlOn", "group__imaging.html#ggad3450faa311ff1337e38201d797f05d0a57994defc58b730428fa6895256fa9e6", null ],
      [ "OMX_IMAGE_FocusControlOff", "group__imaging.html#ggad3450faa311ff1337e38201d797f05d0a35d88cff0a5f1d8d7d79d9c918c10b7d", null ],
      [ "OMX_IMAGE_FocusControlAuto", "group__imaging.html#ggad3450faa311ff1337e38201d797f05d0a3916d63121369cc851550286ca97523c", null ],
      [ "OMX_IMAGE_FocusControlAutoLock", "group__imaging.html#ggad3450faa311ff1337e38201d797f05d0a8bac4539d0c9010eae57f727c652fc82", null ],
      [ "OMX_IMAGE_FocusControlKhronosExtensions", "group__imaging.html#ggad3450faa311ff1337e38201d797f05d0a35da8809de7059366e5d7322f55c515c", null ],
      [ "OMX_IMAGE_FocusControlVendorStartUnused", "group__imaging.html#ggad3450faa311ff1337e38201d797f05d0a74d5837ff048eee4c6aaee19b29621ab", null ],
      [ "OMX_IMAGE_FocusControlMax", "group__imaging.html#ggad3450faa311ff1337e38201d797f05d0a272c33a9c96333454b1ce68e7d9a921a", null ]
    ] ],
    [ "OMX_IMAGE_HUFFMANTABLETYPE", "group__imaging.html#gaabd1a1d16007207cde8bc83e0d10fae3", [
      [ "OMX_IMAGE_HuffmanTableAC", "group__imaging.html#ggaabd1a1d16007207cde8bc83e0d10fae3af2578d29d2f1b6981f9be1dd570d5035", null ],
      [ "OMX_IMAGE_HuffmanTableDC", "group__imaging.html#ggaabd1a1d16007207cde8bc83e0d10fae3a520dfefdbdfd3819c5adeec841ba3ac1", null ],
      [ "OMX_IMAGE_HuffmanTableACLuma", "group__imaging.html#ggaabd1a1d16007207cde8bc83e0d10fae3ab2542529ca2c8d02cfb04b39c769ecc2", null ],
      [ "OMX_IMAGE_HuffmanTableACChroma", "group__imaging.html#ggaabd1a1d16007207cde8bc83e0d10fae3aa5061bf026376ec95922f6850e7effb5", null ],
      [ "OMX_IMAGE_HuffmanTableDCLuma", "group__imaging.html#ggaabd1a1d16007207cde8bc83e0d10fae3a89a91b5369feb4316b7ce66b728da2a8", null ],
      [ "OMX_IMAGE_HuffmanTableDCChroma", "group__imaging.html#ggaabd1a1d16007207cde8bc83e0d10fae3abe7f54daf6d5f1eaaaa76866ad7fad0f", null ],
      [ "OMX_IMAGE_HuffmanTableKhronosExtensions", "group__imaging.html#ggaabd1a1d16007207cde8bc83e0d10fae3a367b8674b22a53c6c070f1cb6bb4de5a", null ],
      [ "OMX_IMAGE_HuffmanTableVendorStartUnused", "group__imaging.html#ggaabd1a1d16007207cde8bc83e0d10fae3ac1aa004f88da31f333320462d2a100af", null ],
      [ "OMX_IMAGE_HuffmanTableMax", "group__imaging.html#ggaabd1a1d16007207cde8bc83e0d10fae3aa9f9fa38c84c3265d958d73f7787b74b", null ]
    ] ],
    [ "OMX_IMAGE_QUANTIZATIONTABLETYPE", "group__imaging.html#gaf6d20a2906c17b9a81bc28df0cee88d5", [
      [ "OMX_IMAGE_QuantizationTableLuma", "group__imaging.html#ggaf6d20a2906c17b9a81bc28df0cee88d5aae66ffaeb7d98e19fa3bd1a33c04f7bc", null ],
      [ "OMX_IMAGE_QuantizationTableChroma", "group__imaging.html#ggaf6d20a2906c17b9a81bc28df0cee88d5af741bd39fb2dc9a0d99953312546a18a", null ],
      [ "OMX_IMAGE_QuantizationTableChromaCb", "group__imaging.html#ggaf6d20a2906c17b9a81bc28df0cee88d5a46edb8542f76daba063ffa014ffc58ae", null ],
      [ "OMX_IMAGE_QuantizationTableChromaCr", "group__imaging.html#ggaf6d20a2906c17b9a81bc28df0cee88d5a00d99142790cd87d29f62a27ff11744b", null ],
      [ "OMX_IMAGE_QuantizationTableKhronosExtensions", "group__imaging.html#ggaf6d20a2906c17b9a81bc28df0cee88d5a49c4bd76ac9aacfd45a31df414c1a650", null ],
      [ "OMX_IMAGE_QuantizationTableVendorStartUnused", "group__imaging.html#ggaf6d20a2906c17b9a81bc28df0cee88d5a316c9566942b8e7da4d83bb53bdbeeeb", null ],
      [ "OMX_IMAGE_QuantizationTableMax", "group__imaging.html#ggaf6d20a2906c17b9a81bc28df0cee88d5a096f0d91af986c1ef6eca5afe8550bfa", null ]
    ] ]
];