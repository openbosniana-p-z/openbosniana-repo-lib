var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_m_u_t_e_t_y_p_e =
[
    [ "bIsMIDI", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_m_u_t_e_t_y_p_e.html#a9bbacd5b3f82eeb99521dd1c8fc1122c", null ],
    [ "bMute", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_m_u_t_e_t_y_p_e.html#ae40b303e8617fb2e3584c0c6be2b91bf", null ],
    [ "nChannel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_m_u_t_e_t_y_p_e.html#a050ef972d31db62926da72d9999eaaea", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_m_u_t_e_t_y_p_e.html#ad5bd46376cca134dd3cf7084842d4033", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_m_u_t_e_t_y_p_e.html#a39f757d1134f2d2fc408b056a28da9bb", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_m_u_t_e_t_y_p_e.html#a5f39eb59920b688f0d8c7845936eae37", null ]
];