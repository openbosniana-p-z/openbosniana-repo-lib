var omxaudiomixertest_8h =
[
    [ "appPrivateType", "structapp_private_type.html", "structapp_private_type" ],
    [ "BUFFER_IN_SIZE", "omxaudiomixertest_8h.html#a3560cbb78f152b8a0bad908c0cfad066", null ],
    [ "VERSIONMAJOR", "omxaudiomixertest_8h.html#a7ee0763bf4c31d34bba57c6a72de7dff", null ],
    [ "VERSIONMINOR", "omxaudiomixertest_8h.html#a781dd31b9382b965a85286d78e9932b6", null ],
    [ "VERSIONREVISION", "omxaudiomixertest_8h.html#a141809e2cd3dadeefaac6fb1ef94147b", null ],
    [ "VERSIONSTEP", "omxaudiomixertest_8h.html#ae070a614d88a7b5e53d9246be1efdf3b", null ],
    [ "appPrivateType", "omxaudiomixertest_8h.html#ad3d53be82f39f99d82f1f7941b2d4cf9", null ],
    [ "audiomixerEmptyBufferDone", "omxaudiomixertest_8h.html#a51d679133f25de003c48ed0c0e886d6c", null ],
    [ "audiomixerEventHandler", "omxaudiomixertest_8h.html#affa5172b8109c206fad3700d3b833214", null ],
    [ "audiomixerFillBufferDone", "omxaudiomixertest_8h.html#a82afb8c65849a8f50aec58e98d6df104", null ],
    [ "audiosinkEmptyBufferDone", "omxaudiomixertest_8h.html#a056e8a552d89456b1130e717ad648d12", null ],
    [ "audiosinkEventHandler", "omxaudiomixertest_8h.html#a5158de20cf2b4769ccf63cc25aa455d1", null ]
];