var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___n_o_i_s_e_r_e_d_u_c_t_i_o_n_t_y_p_e =
[
    [ "bNoiseReduction", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___n_o_i_s_e_r_e_d_u_c_t_i_o_n_t_y_p_e.html#a5f218aa3cc6039ab1874f7e4439164fd", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___n_o_i_s_e_r_e_d_u_c_t_i_o_n_t_y_p_e.html#a5430f15034fa1dcfebd514f376f56165", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___n_o_i_s_e_r_e_d_u_c_t_i_o_n_t_y_p_e.html#a9590e319d3fb3bd72467568c9de20f5b", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___n_o_i_s_e_r_e_d_u_c_t_i_o_n_t_y_p_e.html#aab06e0c4aebb098276ef9c5d51cdd23e", null ]
];