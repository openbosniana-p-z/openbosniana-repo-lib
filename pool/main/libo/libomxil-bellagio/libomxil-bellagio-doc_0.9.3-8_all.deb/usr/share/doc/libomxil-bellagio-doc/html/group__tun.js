var group__tun =
[
    [ "OMX_PARAM_BUFFERSUPPLIERTYPE", "struct_o_m_x___p_a_r_a_m___b_u_f_f_e_r_s_u_p_p_l_i_e_r_t_y_p_e.html", [
      [ "eBufferSupplier", "struct_o_m_x___p_a_r_a_m___b_u_f_f_e_r_s_u_p_p_l_i_e_r_t_y_p_e.html#acd2ce48eb688edcc306f313b42b168fb", null ],
      [ "nPortIndex", "struct_o_m_x___p_a_r_a_m___b_u_f_f_e_r_s_u_p_p_l_i_e_r_t_y_p_e.html#aac369739d5debbd47807ba2aad784dbc", null ],
      [ "nSize", "struct_o_m_x___p_a_r_a_m___b_u_f_f_e_r_s_u_p_p_l_i_e_r_t_y_p_e.html#aacc38b330d15b908bbfa4fcb6824797a", null ],
      [ "nVersion", "struct_o_m_x___p_a_r_a_m___b_u_f_f_e_r_s_u_p_p_l_i_e_r_t_y_p_e.html#a1c1d1e48add73d186b3ed258889b114f", null ]
    ] ],
    [ "OMX_TUNNELSETUPTYPE", "struct_o_m_x___t_u_n_n_e_l_s_e_t_u_p_t_y_p_e.html", [
      [ "eSupplier", "struct_o_m_x___t_u_n_n_e_l_s_e_t_u_p_t_y_p_e.html#a47d4123a9df639c54fd1b73dde6348e4", null ],
      [ "nTunnelFlags", "struct_o_m_x___t_u_n_n_e_l_s_e_t_u_p_t_y_p_e.html#a72a7c6f490bd7ccadc31bab56ac1dbf1", null ]
    ] ],
    [ "OMX_PARAM_BUFFERSUPPLIERTYPE", "group__tun.html#gaa3580b263e67e1a477ba142c7bf5a52f", null ],
    [ "OMX_TUNNELSETUPTYPE", "group__tun.html#ga9b435ff5055810e8e9621e85c22d233e", null ],
    [ "OMX_SetupTunnel", "group__tun.html#ga8fa43caacbb2ede24ba0d35f03ce6dbe", null ],
    [ "OMX_COMPONENTTYPE::ComponentTunnelRequest", "group__tun.html#ga0d4b2e0d8e28f54e9eb12d550c5f2e5a", null ]
];