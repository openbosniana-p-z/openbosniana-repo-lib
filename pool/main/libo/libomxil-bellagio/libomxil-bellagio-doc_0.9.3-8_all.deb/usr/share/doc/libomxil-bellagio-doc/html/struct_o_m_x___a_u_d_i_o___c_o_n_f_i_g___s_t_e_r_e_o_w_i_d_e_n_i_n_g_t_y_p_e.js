var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e =
[
    [ "bEnable", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#ad856e717e922b0fa143c65f0e98c1ea9", null ],
    [ "eWideningType", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#a08aab037fe50041d2cf4a9270328043f", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#a3708e937d32aab5e15a5d75379f76661", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#ac5763a117c11e9cedda81da3e238f7bd", null ],
    [ "nStereoWidening", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#a48e45eb2c71cb72e482376c9b349b044", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#a9c9f1a466552b31f66cf52768dfb879a", null ]
];