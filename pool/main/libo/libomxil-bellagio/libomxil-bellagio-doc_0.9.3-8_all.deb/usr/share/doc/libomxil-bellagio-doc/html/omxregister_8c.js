var omxregister_8c =
[
    [ "DEFAULT_LINE_LENGHT", "omxregister_8c.html#a7524f1cea5e8b825884ff13e7551ef17", null ],
    [ "int2strlen", "omxregister_8c.html#a0763d7af565b39379b4ebbfdde9c5bc7", null ],
    [ "main", "omxregister_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];