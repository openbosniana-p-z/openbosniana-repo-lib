var struct_b_o_s_a___c_o_m_p_o_n_e_n_t_l_o_a_d_e_r =
[
    [ "BOSA_ComponentNameEnum", "struct_b_o_s_a___c_o_m_p_o_n_e_n_t_l_o_a_d_e_r.html#ae654db6d6287be7f6e20503750d01c90", null ],
    [ "BOSA_CreateComponent", "struct_b_o_s_a___c_o_m_p_o_n_e_n_t_l_o_a_d_e_r.html#a15e90d157fbf55ecc00d012534f41bb5", null ],
    [ "BOSA_DeInitComponentLoader", "struct_b_o_s_a___c_o_m_p_o_n_e_n_t_l_o_a_d_e_r.html#a205961fe09175fdff110f9d7c6162227", null ],
    [ "BOSA_DestroyComponent", "struct_b_o_s_a___c_o_m_p_o_n_e_n_t_l_o_a_d_e_r.html#a764a32aa9fe2276a8b0aa2dc0f57b782", null ],
    [ "BOSA_GetComponentsOfRole", "struct_b_o_s_a___c_o_m_p_o_n_e_n_t_l_o_a_d_e_r.html#a836cfbd8d929532a4f98a4ab1365162d", null ],
    [ "BOSA_GetRolesOfComponent", "struct_b_o_s_a___c_o_m_p_o_n_e_n_t_l_o_a_d_e_r.html#aa29591520321b3daabfb7a7dbd6f7c47", null ],
    [ "BOSA_InitComponentLoader", "struct_b_o_s_a___c_o_m_p_o_n_e_n_t_l_o_a_d_e_r.html#a29604329359528e93f467dbba917ce1c", null ],
    [ "loaderPrivate", "struct_b_o_s_a___c_o_m_p_o_n_e_n_t_l_o_a_d_e_r.html#a3c4f47f6e5589b19f7f6613de4ccb0df", null ]
];