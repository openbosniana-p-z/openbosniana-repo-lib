var queue_8h =
[
    [ "qelem_t", "structqelem__t.html", "structqelem__t" ],
    [ "queue_t", "structqueue__t.html", "structqueue__t" ],
    [ "MAX_QUEUE_ELEMENTS", "queue_8h.html#a00fcf46a586e3c933f22d6d0b88262f1", null ],
    [ "qelem_t", "queue_8h.html#a2ea7ec244e0435dd5f3435570552b8af", null ],
    [ "queue_t", "queue_8h.html#aaea17f81ca1b54a3d28b561843c574d2", null ],
    [ "dequeue", "queue_8h.html#a2fbbc0f2b8e7f6fff5719562b3495208", null ],
    [ "getquenelem", "queue_8h.html#adebc8aa8d0be687bce26fb8c458c447a", null ],
    [ "queue", "queue_8h.html#a29e8cac7d151c030f0e1ac1c07f18323", null ],
    [ "queue_deinit", "queue_8h.html#a7ed0f920c24a1c31472c8fc571100e37", null ],
    [ "queue_init", "queue_8h.html#a8f5abe559cd352d91efb79bc6e1788de", null ]
];