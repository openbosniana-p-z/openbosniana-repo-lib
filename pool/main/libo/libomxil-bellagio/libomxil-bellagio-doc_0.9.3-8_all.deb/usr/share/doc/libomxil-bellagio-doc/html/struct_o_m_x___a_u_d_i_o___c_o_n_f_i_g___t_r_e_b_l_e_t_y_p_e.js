var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___t_r_e_b_l_e_t_y_p_e =
[
    [ "bEnable", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___t_r_e_b_l_e_t_y_p_e.html#a514836e1ecd4a12374bbadd7b04f6cb8", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___t_r_e_b_l_e_t_y_p_e.html#a0a565978e4ba53e49ccf359c0b9d6abd", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___t_r_e_b_l_e_t_y_p_e.html#a522907e1cf0e59e948697d4a78de219e", null ],
    [ "nTreble", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___t_r_e_b_l_e_t_y_p_e.html#a814ccb55328ff921182b949ecb49eaeb", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___t_r_e_b_l_e_t_y_p_e.html#a95b9f384076bcc4b92f5e64159f356d5", null ]
];