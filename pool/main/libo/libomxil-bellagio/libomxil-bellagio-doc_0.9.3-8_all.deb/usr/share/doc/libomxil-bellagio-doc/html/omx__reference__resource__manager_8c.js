var omx__reference__resource__manager_8c =
[
    [ "addElemToList", "omx__reference__resource__manager_8c.html#a1c4a982b20b05d9d5deb59c1a9d5ab42", null ],
    [ "clearList", "omx__reference__resource__manager_8c.html#a881174659b20d25bccaecbbdfe187cb2", null ],
    [ "numElemInList", "omx__reference__resource__manager_8c.html#abb69f7f84caf524a66bcefac851acbcc", null ],
    [ "preemptComponent", "omx__reference__resource__manager_8c.html#ad31d784fe5368094ed95c966192a6fe0", null ],
    [ "removeElemFromList", "omx__reference__resource__manager_8c.html#ac8544938ed46cb490e4105e354c83fb5", null ],
    [ "RM_Deinit", "omx__reference__resource__manager_8c.html#ad7d71a888886cf2ad51e4522b7daff47", null ],
    [ "RM_getResource", "omx__reference__resource__manager_8c.html#a6b5fe9df8f6241519c7cae63a76b4cb0", null ],
    [ "RM_Init", "omx__reference__resource__manager_8c.html#a924417671f701795687c6dc498fd962b", null ],
    [ "RM_printList", "omx__reference__resource__manager_8c.html#ab4e44a76c9d5b0b39835189994c5cafa", null ],
    [ "RM_RegisterComponent", "omx__reference__resource__manager_8c.html#a2e5cb678b1ad832d6a8c1a3783d89dc2", null ],
    [ "RM_releaseResource", "omx__reference__resource__manager_8c.html#ab1fd22e9e8ead657d3b5df8be7e36485", null ],
    [ "RM_removeFromWaitForResource", "omx__reference__resource__manager_8c.html#a5b75da4f3df7ef635cb08450b0a7e489", null ],
    [ "RM_waitForResource", "omx__reference__resource__manager_8c.html#aeb34421fa8c4c46d49cdd99c51f64715", null ],
    [ "searchLowerPriority", "omx__reference__resource__manager_8c.html#a418d434f34d08be0b1fc7fda38260fe3", null ],
    [ "globalComponentList", "omx__reference__resource__manager_8c.html#a384c15d2513a8ca52b0b57e80c4cb3ea", null ],
    [ "globalIndex", "omx__reference__resource__manager_8c.html#a9eb7f4c45706b93bb709336429c8147a", null ],
    [ "globalWaitingComponentList", "omx__reference__resource__manager_8c.html#ab9672f1e2e59bd8d1a2c5fd6d001c3d8", null ],
    [ "listOfcomponentRegistered", "omx__reference__resource__manager_8c.html#add4012c3489e41006d2e73c4421c14bc", null ]
];