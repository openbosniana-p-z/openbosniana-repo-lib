var omx__video__scheduler__component_8h =
[
    [ "MAX_VIDEOSCHED_COMPONENTS", "omx__video__scheduler__component_8h.html#a0f4fe0038eec7d4cb76c28c3433075cf", null ],
    [ "omx_video_scheduler_component_PrivateType_FIELDS", "omx__video__scheduler__component_8h.html#a37f7e1b4d790ff0cef2faf71e5a1780b", null ],
    [ "VIDEO_SCHEDULER_COMP_NAME", "omx__video__scheduler__component_8h.html#a4724a46fb39542888a3a8ae1ce674501", null ],
    [ "VIDEO_SCHEDULER_COMP_ROLE", "omx__video__scheduler__component_8h.html#aed265303847df41556a00aea6751391e", null ],
    [ "VIDEOSCHED_QUALITY_LEVELS", "omx__video__scheduler__component_8h.html#a186722258a20a13722e1ac50b4595682", null ],
    [ "omx_fbdev_sink_component_Deinit", "omx__video__scheduler__component_8h.html#af70f95af773a603c33cb4456a5dc5d05", null ],
    [ "omx_fbdev_sink_component_Init", "omx__video__scheduler__component_8h.html#a11297037997395bee65db42597ba12e8", null ],
    [ "omx_video_scheduler_component_BufferMgmtCallback", "omx__video__scheduler__component_8h.html#a852cbad546d2f166d29796305a8f1e35", null ],
    [ "omx_video_scheduler_component_ClockPortHandleFunction", "omx__video__scheduler__component_8h.html#ac7e9a1d9a04ea8e3377e30a3443ab084", null ],
    [ "omx_video_scheduler_component_Constructor", "omx__video__scheduler__component_8h.html#ac4077bbdb21dc320b56082cf58746eb9", null ],
    [ "omx_video_scheduler_component_Destructor", "omx__video__scheduler__component_8h.html#a5cc0d3b48030c5517efe01505f64619e", null ],
    [ "omx_video_scheduler_component_GetParameter", "omx__video__scheduler__component_8h.html#a67d833882137750ab6df08c3d2858901", null ],
    [ "omx_video_scheduler_component_port_FlushProcessingBuffers", "omx__video__scheduler__component_8h.html#aabc5c495864ae347b156a596aca6df56", null ],
    [ "omx_video_scheduler_component_port_SendBufferFunction", "omx__video__scheduler__component_8h.html#a8d3dc621ad5150ad610f80df9ba81a94", null ],
    [ "omx_video_scheduler_component_SetParameter", "omx__video__scheduler__component_8h.html#ad86cc6fc0a352547bf22423c9ce13ef2", null ]
];