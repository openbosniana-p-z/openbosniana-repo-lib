var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_v_o_l_u_m_e_t_y_p_e =
[
    [ "bIsMIDI", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_v_o_l_u_m_e_t_y_p_e.html#a33ba4444d2e6685ea84268ba385b636e", null ],
    [ "bLinear", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_v_o_l_u_m_e_t_y_p_e.html#ad407f6b4c11c9ad55e09c2b1eac84fcd", null ],
    [ "nChannel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_v_o_l_u_m_e_t_y_p_e.html#a27c3ece843eabae2defb709109d25a6c", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_v_o_l_u_m_e_t_y_p_e.html#afe5bac1a4d3ff596d926c552b11881a6", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_v_o_l_u_m_e_t_y_p_e.html#ab85dbe90c61ffe7e0f056a84a41ea27b", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_v_o_l_u_m_e_t_y_p_e.html#a833b13207888e95cfd551f0914d8c717", null ],
    [ "sVolume", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_a_n_n_e_l_v_o_l_u_m_e_t_y_p_e.html#add4b8e849d88aede80d07d917f9fee48", null ]
];