var extension__struct_8h =
[
    [ "OMX_PARAM_BELLAGIOTHREADS_ID", "struct_o_m_x___p_a_r_a_m___b_e_l_l_a_g_i_o_t_h_r_e_a_d_s___i_d.html", "struct_o_m_x___p_a_r_a_m___b_e_l_l_a_g_i_o_t_h_r_e_a_d_s___i_d" ],
    [ "multiResourceDescriptor", "structmulti_resource_descriptor.html", "structmulti_resource_descriptor" ],
    [ "multiResourceDescriptor", "extension__struct_8h.html#af31729e1aa570177f6eb116d186a30fe", null ],
    [ "OMX_PARAM_BELLAGIOTHREADS_ID", "extension__struct_8h.html#a8f7e62acb04e2c2b3efcae75f8bafdc6", null ]
];