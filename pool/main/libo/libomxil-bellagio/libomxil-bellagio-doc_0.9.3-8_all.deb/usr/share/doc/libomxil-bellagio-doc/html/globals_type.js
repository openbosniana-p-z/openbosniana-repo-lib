var globals_type =
[
    [ "a", "globals_type.html", null ],
    [ "b", "globals_type_b.html", null ],
    [ "c", "globals_type_c.html", null ],
    [ "i", "globals_type_i.html", null ],
    [ "m", "globals_type_m.html", null ],
    [ "n", "globals_type_n.html", null ],
    [ "o", "globals_type_o.html", null ],
    [ "q", "globals_type_q.html", null ],
    [ "s", "globals_type_s.html", null ],
    [ "t", "globals_type_t.html", null ]
];