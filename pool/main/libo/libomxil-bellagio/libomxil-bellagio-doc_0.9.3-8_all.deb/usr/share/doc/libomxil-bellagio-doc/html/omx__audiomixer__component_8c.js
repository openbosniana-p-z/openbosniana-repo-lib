var omx__audiomixer__component_8c =
[
    [ "GAIN_VALUE", "omx__audiomixer__component_8c.html#a9798945ad354aea53732c9cc98f617e4", null ],
    [ "checkAnyPortBeingFlushed", "omx__audiomixer__component_8c.html#a8634023fb605e98b1ace868169f6f854", null ],
    [ "omx_audio_mixer_BufferMgmtFunction", "omx__audiomixer__component_8c.html#af8dfb3d7dd81fa836105a3e5959e2a67", null ],
    [ "omx_audio_mixer_component_BufferMgmtCallback", "omx__audiomixer__component_8c.html#aa69df866649fad54f477087d5c12619d", null ],
    [ "omx_audio_mixer_component_Constructor", "omx__audiomixer__component_8c.html#ad0a03b0e1cb45b3acd497d2ca7c14cfe", null ],
    [ "omx_audio_mixer_component_Destructor", "omx__audiomixer__component_8c.html#af545bea12031ef1759299b1cbb5d6c0d", null ],
    [ "omx_audio_mixer_component_GetConfig", "omx__audiomixer__component_8c.html#aca915f1479673cff0bf59e2f6b2ee105", null ],
    [ "omx_audio_mixer_component_GetParameter", "omx__audiomixer__component_8c.html#a171523b3c6e884d7139c938dc9b37f39", null ],
    [ "omx_audio_mixer_component_SetConfig", "omx__audiomixer__component_8c.html#ae37d60299de367f2ed0a2cf0d59f5b63", null ],
    [ "omx_audio_mixer_component_SetParameter", "omx__audiomixer__component_8c.html#ab87f0da6dea6224806ceaf4c6cc23aea", null ]
];