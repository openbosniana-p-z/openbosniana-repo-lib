var group__rpm =
[
    [ "OMX_PARAM_SUSPENSIONPOLICYTYPE", "struct_o_m_x___p_a_r_a_m___s_u_s_p_e_n_s_i_o_n_p_o_l_i_c_y_t_y_p_e.html", [
      [ "ePolicy", "struct_o_m_x___p_a_r_a_m___s_u_s_p_e_n_s_i_o_n_p_o_l_i_c_y_t_y_p_e.html#abebf1bb22f704b8029335731193d31db", null ],
      [ "nSize", "struct_o_m_x___p_a_r_a_m___s_u_s_p_e_n_s_i_o_n_p_o_l_i_c_y_t_y_p_e.html#a859415e3346331bb8744dfeeda3e4c32", null ],
      [ "nVersion", "struct_o_m_x___p_a_r_a_m___s_u_s_p_e_n_s_i_o_n_p_o_l_i_c_y_t_y_p_e.html#a2673a2a0c70e5f909569c9fc0396e40b", null ]
    ] ],
    [ "OMX_PARAM_SUSPENSIONTYPE", "struct_o_m_x___p_a_r_a_m___s_u_s_p_e_n_s_i_o_n_t_y_p_e.html", [
      [ "eType", "struct_o_m_x___p_a_r_a_m___s_u_s_p_e_n_s_i_o_n_t_y_p_e.html#a7ad5a52fb8e17ba9f626002f920bce7c", null ],
      [ "nSize", "struct_o_m_x___p_a_r_a_m___s_u_s_p_e_n_s_i_o_n_t_y_p_e.html#a7638ecf3b37241e6094fc5845847730a", null ],
      [ "nVersion", "struct_o_m_x___p_a_r_a_m___s_u_s_p_e_n_s_i_o_n_t_y_p_e.html#a5f2938c9b8a2bc6a05a971e2bd4283a9", null ]
    ] ],
    [ "OMX_RESOURCECONCEALMENTTYPE", "struct_o_m_x___r_e_s_o_u_r_c_e_c_o_n_c_e_a_l_m_e_n_t_t_y_p_e.html", [
      [ "bResourceConcealmentForbidden", "struct_o_m_x___r_e_s_o_u_r_c_e_c_o_n_c_e_a_l_m_e_n_t_t_y_p_e.html#a4e763332576dfc0a383d81c6b831921f", null ],
      [ "nSize", "struct_o_m_x___r_e_s_o_u_r_c_e_c_o_n_c_e_a_l_m_e_n_t_t_y_p_e.html#a1e3c6fb9844a5f52a0f0a53005e5dda8", null ],
      [ "nVersion", "struct_o_m_x___r_e_s_o_u_r_c_e_c_o_n_c_e_a_l_m_e_n_t_t_y_p_e.html#a76722cc2a0245a074e39f29e6349e667", null ]
    ] ],
    [ "OMX_PRIORITYMGMTTYPE", "struct_o_m_x___p_r_i_o_r_i_t_y_m_g_m_t_t_y_p_e.html", [
      [ "nGroupID", "struct_o_m_x___p_r_i_o_r_i_t_y_m_g_m_t_t_y_p_e.html#a48e37deefbd4553aa7ad533ca33564ac", null ],
      [ "nGroupPriority", "struct_o_m_x___p_r_i_o_r_i_t_y_m_g_m_t_t_y_p_e.html#aaa639fbc2914079a7a22d094a250e1be", null ],
      [ "nSize", "struct_o_m_x___p_r_i_o_r_i_t_y_m_g_m_t_t_y_p_e.html#a4a03a6ad8a7ca8cfcf9014e3acb6b63a", null ],
      [ "nVersion", "struct_o_m_x___p_r_i_o_r_i_t_y_m_g_m_t_t_y_p_e.html#af70427ccb6756867f01101924324152b", null ]
    ] ],
    [ "OMX_PARAM_SUSPENSIONPOLICYTYPE", "group__rpm.html#gaaaf23b0e9c25d0ec7055c84b91743347", null ],
    [ "OMX_PARAM_SUSPENSIONTYPE", "group__rpm.html#gae72c02c83ed21d3bc5010f44ab5d0f57", null ],
    [ "OMX_PRIORITYMGMTTYPE", "group__rpm.html#gad2a051be76d72233a076980e764bf4a7", null ],
    [ "OMX_RESOURCECONCEALMENTTYPE", "group__rpm.html#ga9f9681d607c5b32006da9a3090dfd165", null ],
    [ "OMX_SUSPENSIONPOLICYTYPE", "group__rpm.html#ga44f5e8c27febca587354f356b566353a", null ],
    [ "OMX_SUSPENSIONTYPE", "group__rpm.html#ga75ac2f3780dda0428d158b46dd3414ea", null ],
    [ "OMX_SUSPENSIONPOLICYTYPE", "group__rpm.html#ga60944169c840b15d35fdc646a2f665a4", [
      [ "OMX_SuspensionDisabled", "group__rpm.html#gga60944169c840b15d35fdc646a2f665a4aa33830bdff565dc2e00797454e15d462", null ],
      [ "OMX_SuspensionEnabled", "group__rpm.html#gga60944169c840b15d35fdc646a2f665a4ac4a2338a71059350f35cbca22a7631eb", null ],
      [ "OMX_SuspensionPolicyKhronosExtensions", "group__rpm.html#gga60944169c840b15d35fdc646a2f665a4a501b9c7b073de10f9d0357dd9ac3d01b", null ],
      [ "OMX_SuspensionPolicyStartUnused", "group__rpm.html#gga60944169c840b15d35fdc646a2f665a4a645c0a7425df9b529f8dad27447d008b", null ],
      [ "OMX_SuspensionPolicyMax", "group__rpm.html#gga60944169c840b15d35fdc646a2f665a4aaa60e9a85d5f6c57798eabdcab8f7187", null ]
    ] ],
    [ "OMX_SUSPENSIONTYPE", "group__rpm.html#ga49215c89c7027e2af51ac5adfec0e782", [
      [ "OMX_NotSuspended", "group__rpm.html#gga49215c89c7027e2af51ac5adfec0e782a1f2e2d0846c4c9057252035854bc36f1", null ],
      [ "OMX_Suspended", "group__rpm.html#gga49215c89c7027e2af51ac5adfec0e782a8862b8ef26c42d80e17b7ff9933b2052", null ],
      [ "OMX_SuspensionKhronosExtensions", "group__rpm.html#gga49215c89c7027e2af51ac5adfec0e782a6a86f3449f94c2920831db676ee5e36d", null ],
      [ "OMX_SuspensionVendorStartUnused", "group__rpm.html#gga49215c89c7027e2af51ac5adfec0e782abade4ec2e0459dd3ea3d71c25293928f", null ],
      [ "OMX_SuspendMax", "group__rpm.html#gga49215c89c7027e2af51ac5adfec0e782a5e022fc54f44ad34a608aa4c4389966a", null ]
    ] ]
];