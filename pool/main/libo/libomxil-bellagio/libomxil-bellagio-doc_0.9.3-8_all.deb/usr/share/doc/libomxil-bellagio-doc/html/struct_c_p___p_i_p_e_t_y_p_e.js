var struct_c_p___p_i_p_e_t_y_p_e =
[
    [ "CheckAvailableBytes", "struct_c_p___p_i_p_e_t_y_p_e.html#a66999dbc8bdd73de23ff878d178d6443", null ],
    [ "Close", "struct_c_p___p_i_p_e_t_y_p_e.html#ad6edf74783f7cf5ab82c0f64f0dbb5f7", null ],
    [ "Create", "struct_c_p___p_i_p_e_t_y_p_e.html#a27fe775a362e0881a226ba03eb7521aa", null ],
    [ "GetPosition", "struct_c_p___p_i_p_e_t_y_p_e.html#ac1aa7fc5710719328676bee76f0e92dc", null ],
    [ "GetWriteBuffer", "struct_c_p___p_i_p_e_t_y_p_e.html#acb76d30c4cb248cbbccec2959a7ed321", null ],
    [ "Open", "struct_c_p___p_i_p_e_t_y_p_e.html#a99652b10ea8f43cb323be9b6a13a8d81", null ],
    [ "Read", "struct_c_p___p_i_p_e_t_y_p_e.html#ae9177e01bb6b7774d4bece2aaf6c79e3", null ],
    [ "ReadBuffer", "struct_c_p___p_i_p_e_t_y_p_e.html#a6eacbcad997ad72c588f1bde6d788c46", null ],
    [ "RegisterCallback", "struct_c_p___p_i_p_e_t_y_p_e.html#a34dfe013dc6d3f6f2edc9e4e928517e7", null ],
    [ "ReleaseReadBuffer", "struct_c_p___p_i_p_e_t_y_p_e.html#a238a6d307ba4cfc7963cdcea10a9a305", null ],
    [ "SetPosition", "struct_c_p___p_i_p_e_t_y_p_e.html#a93e27b70626ca5e662ef93875f996319", null ],
    [ "Write", "struct_c_p___p_i_p_e_t_y_p_e.html#a2c1ffc70e0ed3c39a6b6e0073cdcb7a4", null ],
    [ "WriteBuffer", "struct_c_p___p_i_p_e_t_y_p_e.html#a2b79ef157d1779181adc2ba8b7b3e9bd", null ]
];