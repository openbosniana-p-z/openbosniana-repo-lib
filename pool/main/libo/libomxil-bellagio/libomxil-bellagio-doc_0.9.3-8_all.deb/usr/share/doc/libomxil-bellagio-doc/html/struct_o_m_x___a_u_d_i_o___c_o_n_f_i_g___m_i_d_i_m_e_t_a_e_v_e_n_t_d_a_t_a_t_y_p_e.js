var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e =
[
    [ "nData", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#a5b11d6e98cff941dbc44679b2c2edee4", null ],
    [ "nIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#accdc81f543e74f07f5cb22e65c629fe3", null ],
    [ "nMetaEventSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#abde0c859e447cbbb772cc253ad6e9e64", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#a450a4a93e0d02ab3fa000afdafa39336", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#abd6611016de28ea661044ece2133a76b", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_m_e_t_a_e_v_e_n_t_d_a_t_a_t_y_p_e.html#ae761fee9fad5bc750e30804c9d4e9b50", null ]
];