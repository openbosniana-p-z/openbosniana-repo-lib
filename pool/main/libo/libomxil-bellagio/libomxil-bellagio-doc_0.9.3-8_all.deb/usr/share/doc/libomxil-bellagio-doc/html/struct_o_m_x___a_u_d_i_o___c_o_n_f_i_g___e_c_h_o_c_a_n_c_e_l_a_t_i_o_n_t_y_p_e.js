var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_c_h_o_c_a_n_c_e_l_a_t_i_o_n_t_y_p_e =
[
    [ "eEchoCancelation", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_c_h_o_c_a_n_c_e_l_a_t_i_o_n_t_y_p_e.html#a788a32bd3c7a2167d5d961318d2fef32", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_c_h_o_c_a_n_c_e_l_a_t_i_o_n_t_y_p_e.html#a96213e6659a8bef00f21e327d045e3e8", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_c_h_o_c_a_n_c_e_l_a_t_i_o_n_t_y_p_e.html#afae7c27b0a3249b6828ae0ed20390df9", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_c_h_o_c_a_n_c_e_l_a_t_i_o_n_t_y_p_e.html#aac9984a6760c8fc9a2e80182018009c1", null ]
];