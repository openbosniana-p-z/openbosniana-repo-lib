var group__effects =
[
    [ "OMX_AUDIO_CONFIG_EQUALIZERTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html", [
      [ "bEnable", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#a67c7b18f9381fa06fa3a30728615d553", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#acd6b2ff502dea37c100d698a953255e8", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#a971b6aa8119691e5bf4859c1b1ba8a98", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#a9b57489bc3e3fe78a2d9cb2b98e64ed1", null ],
      [ "sBandIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#a58c7f261194e90355e7d97073e9601f2", null ],
      [ "sBandLevel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#a73dee25a6daf04597c20fe75cdff75c5", null ],
      [ "sCenterFreq", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_q_u_a_l_i_z_e_r_t_y_p_e.html#ab41066062b6c413d62e18f04526a65d6", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_STEREOWIDENINGTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html", [
      [ "bEnable", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#ad856e717e922b0fa143c65f0e98c1ea9", null ],
      [ "eWideningType", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#a08aab037fe50041d2cf4a9270328043f", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#a3708e937d32aab5e15a5d75379f76661", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#ac5763a117c11e9cedda81da3e238f7bd", null ],
      [ "nStereoWidening", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#a48e45eb2c71cb72e482376c9b349b044", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___s_t_e_r_e_o_w_i_d_e_n_i_n_g_t_y_p_e.html#a9c9f1a466552b31f66cf52768dfb879a", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_CHORUSTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html", [
      [ "bEnable", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#a62472c7db30c7770144d7b9d27761631", null ],
      [ "nFeedback", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#a1678eda61a36f5ef2e6b3baffd1e82a1", null ],
      [ "nModulationDepth", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#ae26f757a798662012b5ebece5f9d51e2", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#a14ac8a0f393c077998ae254cc9772668", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#a1103b8d24e6c42af35d8dab61cf3a002", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#ad0254351fab8c6b6e2684ea4ce4e5fd9", null ],
      [ "sDelay", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#a485c56d1a19ccbe7d0b6f6aa7731b324", null ],
      [ "sModulationRate", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___c_h_o_r_u_s_t_y_p_e.html#acd38e13eec897709fa940e6b983cb75d", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_REVERBERATIONTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html", [
      [ "bEnable", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a40f6cc27671c6996aedbb323b00bbbe8", null ],
      [ "nDecayHighFreqRatio", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a4f4d6de750583865aabb1621ba440f23", null ],
      [ "nDensity", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#ade42a9a60e53d2c410405e41799dcb11", null ],
      [ "nDiffusion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#ac0939a3828f5d702ea774af78201ea05", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#aa440dad44dab185a4395e6371c3635ab", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a6827d8f0ee4bc17e0483802eeb0ca3a4", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#ae065857d5f9cf53b083c02f2a219cd0a", null ],
      [ "sDecayTime", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#ac464db84e9f329b9efbd270b5c3946d8", null ],
      [ "sReferenceHighFreq", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a102172bd9670912d09a9072f80352f69", null ],
      [ "sReflectionsDelay", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#af2b44fab14a4f698d0b3bc91af58a85d", null ],
      [ "sReflectionsLevel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a4844e43139e92db7b2b5189be8de922d", null ],
      [ "sReverbDelay", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#aed2442fa1b78023ea219cc47288cd8ff", null ],
      [ "sReverbLevel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#aa5b4e87ae4e88f6cedaf0443fc50301d", null ],
      [ "sRoomHighFreqLevel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a736268143a8a7d42cfa9322de78b18a6", null ],
      [ "sRoomLevel", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___r_e_v_e_r_b_e_r_a_t_i_o_n_t_y_p_e.html#a46d0f53dc03fa8aee7071151d5593a32", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_ECHOCANCELATIONTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_c_h_o_c_a_n_c_e_l_a_t_i_o_n_t_y_p_e.html", [
      [ "eEchoCancelation", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_c_h_o_c_a_n_c_e_l_a_t_i_o_n_t_y_p_e.html#a788a32bd3c7a2167d5d961318d2fef32", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_c_h_o_c_a_n_c_e_l_a_t_i_o_n_t_y_p_e.html#a96213e6659a8bef00f21e327d045e3e8", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_c_h_o_c_a_n_c_e_l_a_t_i_o_n_t_y_p_e.html#afae7c27b0a3249b6828ae0ed20390df9", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___e_c_h_o_c_a_n_c_e_l_a_t_i_o_n_t_y_p_e.html#aac9984a6760c8fc9a2e80182018009c1", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_NOISEREDUCTIONTYPE", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___n_o_i_s_e_r_e_d_u_c_t_i_o_n_t_y_p_e.html", [
      [ "bNoiseReduction", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___n_o_i_s_e_r_e_d_u_c_t_i_o_n_t_y_p_e.html#a5f218aa3cc6039ab1874f7e4439164fd", null ],
      [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___n_o_i_s_e_r_e_d_u_c_t_i_o_n_t_y_p_e.html#a5430f15034fa1dcfebd514f376f56165", null ],
      [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___n_o_i_s_e_r_e_d_u_c_t_i_o_n_t_y_p_e.html#a9590e319d3fb3bd72467568c9de20f5b", null ],
      [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___n_o_i_s_e_r_e_d_u_c_t_i_o_n_t_y_p_e.html#aab06e0c4aebb098276ef9c5d51cdd23e", null ]
    ] ],
    [ "OMX_AUDIO_CONFIG_CHORUSTYPE", "group__effects.html#ga606e9c3d956f9cba42948a00b3e9273f", null ],
    [ "OMX_AUDIO_CONFIG_ECHOCANCELATIONTYPE", "group__effects.html#ga5d77737fcce713d5996849c105524b1f", null ],
    [ "OMX_AUDIO_CONFIG_EQUALIZERTYPE", "group__effects.html#ga9a847fae7d80e54f471de6d80680e89c", null ],
    [ "OMX_AUDIO_CONFIG_NOISEREDUCTIONTYPE", "group__effects.html#ga5fb34b63eca5f057a1357c8223743362", null ],
    [ "OMX_AUDIO_CONFIG_REVERBERATIONTYPE", "group__effects.html#gaec87147a3fd9e348282219478b3f3b15", null ],
    [ "OMX_AUDIO_CONFIG_STEREOWIDENINGTYPE", "group__effects.html#gaf1337b68aded4d8a9b951284c7ca640e", null ],
    [ "OMX_AUDIO_ECHOCANTYPE", "group__effects.html#ga56bd152ec578f5b13b24f168ce97907f", null ],
    [ "OMX_AUDIO_STEREOWIDENINGTYPE", "group__effects.html#gaf94a89bc17cdc834e139e9cc1c818bd6", null ],
    [ "OMX_AUDIO_ECHOCANTYPE", "group__effects.html#ga200d093905fe6bd42e75fffc1c98af03", [
      [ "OMX_AUDIO_EchoCanOff", "group__effects.html#gga200d093905fe6bd42e75fffc1c98af03acf90d7307bc135203a1df4f037d1c922", null ],
      [ "OMX_AUDIO_EchoCanNormal", "group__effects.html#gga200d093905fe6bd42e75fffc1c98af03aafcf34d5e145912dfb6582388acf1f8b", null ],
      [ "OMX_AUDIO_EchoCanHFree", "group__effects.html#gga200d093905fe6bd42e75fffc1c98af03a23bb153e9a4a0472d92222b3fb56e0b0", null ],
      [ "OMX_AUDIO_EchoCanCarKit", "group__effects.html#gga200d093905fe6bd42e75fffc1c98af03a4e703fa746c2c72678777261706fc41c", null ],
      [ "OMX_AUDIO_EchoCanKhronosExtensions", "group__effects.html#gga200d093905fe6bd42e75fffc1c98af03abe8271368d5738827ea76d1783af3d2d", null ],
      [ "OMX_AUDIO_EchoCanVendorStartUnused", "group__effects.html#gga200d093905fe6bd42e75fffc1c98af03a3993ddceebd6e14561bbdd4ab89a5a45", null ],
      [ "OMX_AUDIO_EchoCanMax", "group__effects.html#gga200d093905fe6bd42e75fffc1c98af03a5e67fa07c85cdcaa40080e21c2c8f29f", null ]
    ] ],
    [ "OMX_AUDIO_STEREOWIDENINGTYPE", "group__effects.html#ga5b5723f745c6682ad2015c8057e532ac", [
      [ "OMX_AUDIO_StereoWideningHeadphones", "group__effects.html#gga5b5723f745c6682ad2015c8057e532aca9b1744afd68424e2a759688aa19da1fe", null ],
      [ "OMX_AUDIO_StereoWideningLoudspeakers", "group__effects.html#gga5b5723f745c6682ad2015c8057e532aca48801d59ae475a616e838b0f89dd476c", null ],
      [ "OMX_AUDIO_StereoWideningKhronosExtensions", "group__effects.html#gga5b5723f745c6682ad2015c8057e532aca81391d71ca18cbccc27ddf6bdd62c8d9", null ],
      [ "OMX_AUDIO_StereoWideningVendorStartUnused", "group__effects.html#gga5b5723f745c6682ad2015c8057e532aca9172713832254c7307a3790004f13b5a", null ],
      [ "OMX_AUDIO_StereoWideningMax", "group__effects.html#gga5b5723f745c6682ad2015c8057e532aca29ee39ee560985aa7f752f56fdbde866", null ]
    ] ]
];