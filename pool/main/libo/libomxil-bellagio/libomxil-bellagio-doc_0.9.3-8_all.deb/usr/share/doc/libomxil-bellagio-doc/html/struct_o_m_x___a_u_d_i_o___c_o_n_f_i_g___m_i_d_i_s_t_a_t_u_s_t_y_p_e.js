var struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e =
[
    [ "bVibra", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#a4363b3620e324c90ed1ae0a221a698ea", null ],
    [ "eMIDIPlayBackState", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#acd262618e150a51051e890ca89348e29", null ],
    [ "nDuration", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#a6493c79b4ffd079a24fe4b4f0e778376", null ],
    [ "nNumActiveVoices", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#aaf87404c52e7f14bd3adb33ecf46c65b", null ],
    [ "nNumMetaEvents", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#a1d1c2d18dbfd24404f79b2ef1cf8741e", null ],
    [ "nNumTracks", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#af0a9f494b4d577ea23580679d0981806", null ],
    [ "nPortIndex", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#ac2291e8065f697ef6cee464a1ad39ae5", null ],
    [ "nPosition", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#a605085de18bb8e8017aafd99c3f9f1c8", null ],
    [ "nSize", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#ab951fadc77f632f41de144b26e464522", null ],
    [ "nVersion", "struct_o_m_x___a_u_d_i_o___c_o_n_f_i_g___m_i_d_i_s_t_a_t_u_s_t_y_p_e.html#a3a19324539c3b40372a58658936eb1ec", null ]
];