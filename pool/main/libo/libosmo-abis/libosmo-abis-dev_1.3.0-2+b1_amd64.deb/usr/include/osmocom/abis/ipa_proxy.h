#ifndef _IPA_PROXY_H_
#define _IPA_PROXY_H_

void ipa_proxy_vty_init(void);

#endif
