#ifndef _OSMO_ABIS_H_
#define _OSMO_ABIS_H_

void libosmo_abis_init(void *ctx);

#endif
