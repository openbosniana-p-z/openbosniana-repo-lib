If you want to contribute to this module, you can file a bug report at
github issues or email us with your suggestions.

As of version 0.58, it is just about possible to install this module
from the github repository, so you may be able to fork the module and
install it successfully on your local computer. If so, please try
sending a pull request.

