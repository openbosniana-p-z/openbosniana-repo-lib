# jquery.fixedtableheader
jQuery Fixed Table Header Plugin

The plugin fixes header row of table without div overflow. It fixes header row when scroll down the page.

You can use fixedtableheader plugin with ASP.NET DataGrid or GridView.

For demo and details:

[http://www.mustafaozcan.net/en/jquery-fixed-table-header-plugin/](http://www.mustafaozcan.net/en/jquery-fixed-table-header-plugin/)

Developed by [Mustafa OZCAN](http://www.mustafaozcan.net)
