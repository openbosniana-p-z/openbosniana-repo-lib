define(['css!./component'], function() {
  return {component: 'is here'};
});
