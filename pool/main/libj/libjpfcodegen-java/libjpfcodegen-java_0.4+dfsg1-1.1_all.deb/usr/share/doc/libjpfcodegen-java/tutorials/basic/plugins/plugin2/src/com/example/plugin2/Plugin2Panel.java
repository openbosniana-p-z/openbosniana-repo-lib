package com.example.plugin2;

import java.awt.Label;

import javax.swing.JPanel;

public class Plugin2Panel extends JPanel {

	private static final long serialVersionUID = -7872548230704172959L;

	public Plugin2Panel(){
		this.add(new Label("I am Panel 2!"));
	}
}
