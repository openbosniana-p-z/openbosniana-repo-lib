;jQuery(function ($) {
    $.colorpicker.regional['uk'] = {
        ok: 'ОК',
        cancel: 'Скасувати',
        none: 'Ніякий',
        button: 'Колір',
        title: 'Обрати колір',
        transparent: 'Прозорий',
        hsvH: 'H',
        hsvS: 'S',
        hsvV: 'V',
        rgbR: 'R',
        rgbG: 'G',
        rgbB: 'B',
        labL: 'L',
        labA: 'a',
        labB: 'b',
        hslH: 'H',
        hslS: 'S',
        hslL: 'L',
        cmykC: 'C',
        cmykM: 'M',
        cmykY: 'Y',
        cmykK: 'K',
        alphaA: 'A'
    };
});
