;jQuery(function($) {
    $.colorpicker.regional['pt-br'] = {
		ok:				'OK',
		cancel:			'Cancelar',
		none:			'Nenhum',
		button:			'Cor',
		title:			'Escolha uma cor',
		transparent:	'Transparente',
		hsvH:			'H',
		hsvS:			'S',
		hsvV:			'V',
		rgbR:			'R',
		rgbG:			'G',
		rgbB:			'B',
		labL:			'L',
		labA:			'a',
		labB:			'b',
		hslH:			'H',
		hslS:			'S',
		hslL:			'L',
		cmykC:			'C',
		cmykM:			'M',
		cmykY:			'Y',
		cmykK:			'K',
		alphaA:			'A'
	};
});
