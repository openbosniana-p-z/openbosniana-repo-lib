;jQuery(function($) {
	$.colorpicker.regional['sr'] = {
		ok:				'OK',
		cancel:			'Odustani',
		none:			'Nijedno',
		button:			'Boja',
		title:			'Izaberi boju',
		transparent:	'Providno',
		hsvH:			'H',
		hsvS:			'S',
		hsvV:			'V',
		rgbR:			'R',
		rgbG:			'G',
		rgbB:			'B',
		labL:			'L',
		labA:			'a',
		labB:			'b',
		hslH:			'H',
		hslS:			'S',
		hslL:			'L',
		cmykC:			'C',
		cmykM:			'M',
		cmykY:			'Y',
		cmykK:			'K',
		alphaA:			'A'
	};
});
