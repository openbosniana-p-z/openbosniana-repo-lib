var a00260 =
[
    [ "connect_direct", "a00847.html", [
      [ "connect_direct", "a00847.html#a3ae8ab240a1f152c64cd40493d92f846", null ],
      [ "do_startconnect", "a00847.html#a11ef1d3b39a643854b51e81f2b1e869a", null ]
    ] ],
    [ "connect_lazy", "a00851.html", [
      [ "connect_lazy", "a00851.html#a9d93b15b0681f3b4e25e9fab79adb8cd", null ],
      [ "do_completeconnect", "a00851.html#a676c90683625962c20bc4dbf43b6ab88", null ]
    ] ],
    [ "connect_async", "a00855.html", [
      [ "connect_async", "a00855.html#adcace783d423c5306fb72087d5171c31", null ],
      [ "do_completeconnect", "a00855.html#a828cbfb35995d5253ee614e773c2f299", null ],
      [ "do_dropconnect", "a00855.html#a771a68adc4ae8d8300994b023f99e44d", null ],
      [ "do_startconnect", "a00855.html#a0424b0e2dc2f2b3270dd619048d55241", null ],
      [ "is_ready", "a00855.html#a9ff38ee84570b5484137247828162170", null ]
    ] ],
    [ "connect_null", "a00859.html", [
      [ "connect_null", "a00859.html#a0f3aae5285574af29d06abdcb7f2560c", null ]
    ] ],
    [ "connectionpolicy", "a00875.html", [
      [ "handle", "a00875.html#af84188f72d515ed0df7288d65645ae8d", null ],
      [ "connectionpolicy", "a00875.html#ab46be4bfe19a8a022f441d120b6b2f09", null ],
      [ "~connectionpolicy", "a00875.html#ad669bbf53c833a5826f6cac823321b9f", null ],
      [ "do_completeconnect", "a00875.html#a0bbbedd08b7f579e5a2577e97b7e09b7", null ],
      [ "do_disconnect", "a00875.html#a456e5b1db2ffc2cb3bba6059dd9a1e74", null ],
      [ "do_dropconnect", "a00875.html#a6e60c7930eba822154470aa3f50d238a", null ],
      [ "do_startconnect", "a00875.html#ab7c76ae54326197bcbe6d35b5bbb246f", null ],
      [ "is_ready", "a00875.html#ac584cd2d0aefb7bea639e450d74ac565", null ],
      [ "normalconnect", "a00875.html#a5b4be97db7a8739e9f4fc7e1b7ab587c", null ],
      [ "options", "a00875.html#a58dc9afcedf47b0450c338eb9d0fca5a", null ]
    ] ],
    [ "asyncconnection", "a00260.html#ga7121f95bc086259290652be9456b1bb8", null ],
    [ "connection", "a00260.html#ga774f723d641b0ed16355f21113bec338", null ],
    [ "lazyconnection", "a00260.html#ga4e45c2897c00be5e06e2f7e79c693759", null ],
    [ "nullconnection", "a00260.html#ga07f8f728bed77b9a10b302872dbad1c7", null ]
];