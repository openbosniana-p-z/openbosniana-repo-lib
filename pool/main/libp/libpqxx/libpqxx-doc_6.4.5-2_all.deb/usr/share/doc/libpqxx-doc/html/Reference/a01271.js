var a01271 =
[
    [ "namedclass", "a01271.html#a3962cd8000c76fd68466510577a0e452", null ],
    [ "namedclass", "a01271.html#a2b61c8e2fb62026e8fca183d7434388a", null ],
    [ "classname", "a01271.html#acd0034031bf707caf53125c2d61c940f", null ],
    [ "description", "a01271.html#acff74613029db4047e9d6e81c0d0d723", null ],
    [ "name", "a01271.html#a2da0b5a7975ac06760f6d477ffffcb7f", null ]
];