var a00875 =
[
    [ "handle", "a00875.html#af84188f72d515ed0df7288d65645ae8d", null ],
    [ "connectionpolicy", "a00875.html#ab46be4bfe19a8a022f441d120b6b2f09", null ],
    [ "~connectionpolicy", "a00875.html#ad669bbf53c833a5826f6cac823321b9f", null ],
    [ "do_completeconnect", "a00875.html#a0bbbedd08b7f579e5a2577e97b7e09b7", null ],
    [ "do_disconnect", "a00875.html#a456e5b1db2ffc2cb3bba6059dd9a1e74", null ],
    [ "do_dropconnect", "a00875.html#a6e60c7930eba822154470aa3f50d238a", null ],
    [ "do_startconnect", "a00875.html#ab7c76ae54326197bcbe6d35b5bbb246f", null ],
    [ "is_ready", "a00875.html#ac584cd2d0aefb7bea639e450d74ac565", null ],
    [ "normalconnect", "a00875.html#a5b4be97db7a8739e9f4fc7e1b7ab587c", null ],
    [ "options", "a00875.html#a58dc9afcedf47b0450c338eb9d0fca5a", null ]
];