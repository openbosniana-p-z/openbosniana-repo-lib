var annotated_dup =
[
    [ "pqxx", "a00265.html", "a00265" ],
    [ "std", null, [
      [ "back_insert_iterator< pqxx::tablewriter >", "a01235.html", "a01235" ]
    ] ]
];