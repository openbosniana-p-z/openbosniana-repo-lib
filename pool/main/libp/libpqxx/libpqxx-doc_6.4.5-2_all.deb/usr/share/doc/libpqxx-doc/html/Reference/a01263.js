var a01263 =
[
    [ "argument_type", "a00258.html#gac7459a3079c6c2d9f254f99c55a71be2", null ],
    [ "transactor", "a00258.html#ga326761951cbf1a7b38ee912a4ca3556f", null ],
    [ "name", "a00258.html#gaddb2c3c00478bf242a2e579b6ab695c6", null ],
    [ "on_abort", "a00258.html#gab37059bd3afe9fda32585403725eba01", null ],
    [ "on_commit", "a00258.html#gaacc3fb9eb7993788cafe66aa88d87d6b", null ],
    [ "on_doubt", "a00258.html#ga17e9939255df13786447d6001e360f50", null ],
    [ "operator()", "a00258.html#gab02770d55fdda6bc4e5b4323aa53e4e8", null ]
];