var a01083 =
[
    [ "off_type", "a01083.html#ac15a47b4dfd644ba5014ca712b5b650d", null ],
    [ "openmode", "a01083.html#a6b09598014eca3c4c4b8a0c1495185d3", null ],
    [ "pos_type", "a01083.html#a188585737986781a9f1a24aaa2614803", null ],
    [ "seekdir", "a01083.html#a9230026566fa1f7c32d2abcc2a5571eb", null ],
    [ "size_type", "a01083.html#a72fd2f2fffcdb481d3ba5608b3db10cd", null ],
    [ "largeobjectaccess", "a01083.html#a6a83ff716d73bdf627d8ad29405b297d", null ],
    [ "largeobjectaccess", "a01083.html#af58cb0a2bfe6da7b3d17a572fd4ae573", null ],
    [ "largeobjectaccess", "a01083.html#abe93b38428b31cc1a533381f055fb3b8", null ],
    [ "largeobjectaccess", "a01083.html#aa93b5a0de67a09ab92514670ebcca638", null ],
    [ "~largeobjectaccess", "a01083.html#ad0b34b6f869e0cd0dbbb034fe2dfce5a", null ],
    [ "cread", "a01083.html#aed70276203f8505b25051f8407c61fff", null ],
    [ "cseek", "a01083.html#a86298b9dd2e670858c9e04f3d4043b7e", null ],
    [ "ctell", "a01083.html#a4665a2bbcffa4eb07725a9d17f1e0430", null ],
    [ "cwrite", "a01083.html#a012fd587c7a28bc32d980bed26349bac", null ],
    [ "process_notice", "a01083.html#a354fe371fdb18fd212411b862916d4b7", null ],
    [ "read", "a01083.html#aac375f66e0a9fb817e4e59a1e73f6ba7", null ],
    [ "seek", "a01083.html#ae74922e23584d6410cf37f89f10c1a53", null ],
    [ "tell", "a01083.html#a972d8559cae789984a194c98a88b943b", null ],
    [ "to_file", "a01083.html#af4b23a20a59887e503d84ed00066b8ca", null ],
    [ "write", "a01083.html#ad04b47cf5b016f02e855f5e9c0bbccae", null ],
    [ "write", "a01083.html#aaaad87ca613bccb90e5a8c61a45d83ef", null ]
];