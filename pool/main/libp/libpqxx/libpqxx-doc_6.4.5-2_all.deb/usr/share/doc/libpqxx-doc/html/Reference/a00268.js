var a00268 =
[
    [ "internal", "a00269.html", "a00269" ],
    [ "invocation", "a01119.html", "a01119" ]
];