var a00887 =
[
    [ "difference_type", "a00887.html#a93f9c7921dce69c01af1293c1a21c3bd", null ],
    [ "size_type", "a00887.html#a11670c73f8c7448882956a059906bb45", null ],
    [ "icursorstream", "a00887.html#a9d23e2f3cdac465efb354e0ab689304c", null ],
    [ "icursorstream", "a00887.html#a24212e9d6d97c744f5c4eed30d8d92a2", null ],
    [ "get", "a00887.html#a0602dd0f6ed2641bbb98ad584bcf60e7", null ],
    [ "ignore", "a00887.html#a777b5c8fe3f9e0160cea11ba00be5a27", null ],
    [ "operator bool", "a00887.html#a6cd63131c948738d9e8e2e70e6c63cae", null ],
    [ "operator>>", "a00887.html#a7ac105c3e882661d8f1220ccf9164c27", null ],
    [ "set_stride", "a00887.html#a255914b05d1f935922338eeebcb10144", null ],
    [ "stride", "a00887.html#a358a58171e0ec246b7db315f97f25dcd", null ],
    [ "internal::gate::icursorstream_icursor_iterator", "a00887.html#a81bc68e9ddb56368929d58e0820e72f0", null ]
];