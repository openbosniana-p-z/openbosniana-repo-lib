var a01227 =
[
    [ "tablestream", "a01227.html#a9feaf356af248750c1df317e558ff479", null ],
    [ "~tablestream", "a01227.html#af70a02df94343667c83e80317608f121", null ],
    [ "base_close", "a01227.html#a8206b4b9b8dc8139e7b9be97d3c91d95", null ],
    [ "complete", "a01227.html#a0241100d03b034b8e7b59201a6a1b88f", null ],
    [ "is_finished", "a01227.html#a4f0723693cf935e9523f74dd1988be5c", null ],
    [ "NullStr", "a01227.html#a0d9b23340de6c1671325cd6df5acbd77", null ]
];