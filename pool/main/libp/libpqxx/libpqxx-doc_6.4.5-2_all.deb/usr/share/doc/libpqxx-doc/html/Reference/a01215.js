var a01215 =
[
    [ "operator()", "a01215.html#a17d787d4a70cbcb7c228da14131ada6f", null ],
    [ "operator()", "a01215.html#a123a7262affe18aff9ab4d78b3608fd2", null ]
];