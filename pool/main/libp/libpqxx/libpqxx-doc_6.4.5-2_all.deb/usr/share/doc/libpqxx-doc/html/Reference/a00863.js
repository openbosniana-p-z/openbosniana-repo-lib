var a00863 =
[
    [ "reactivation_avoidance_counter", "a00863.html#a80f8a1826d3602adbc4cda22cd42d9cf", null ],
    [ "add", "a00863.html#aeb2dfb56258a2da6948a69aba71ea319", null ],
    [ "clear", "a00863.html#a3d67761fe7a6ea6f0aa5dbe0950a84e0", null ],
    [ "get", "a00863.html#a0677be8c2516021122f9671ae175c469", null ]
];