var a00919 =
[
    [ "sql_error", "a00919.html#acbad476bd57abb883768448ee7dc480d", null ],
    [ "~sql_error", "a00919.html#a39bafd01a909dfbc01ea59e1407cea69", null ],
    [ "query", "a00919.html#a0015b251167f819b4455a5738cd0024d", null ],
    [ "sqlstate", "a00919.html#ad14aad9cb9bbde030229e120920b442f", null ]
];