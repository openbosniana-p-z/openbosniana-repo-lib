var a01007 =
[
    [ "invalid_cursor_name", "a01007.html#ae1e1f06bb18e7426a239e2c21d083a92", null ]
];