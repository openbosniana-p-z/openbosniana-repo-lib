var a01107 =
[
    [ "notification_receiver", "a01107.html#af1f7329b7989d05272f6ac354fa1ac3e", null ],
    [ "notification_receiver", "a01107.html#a6f64b03667197bccb77c9fa4a1ecfbe0", null ],
    [ "~notification_receiver", "a01107.html#ae4ed572d3a137b331d363bae82f4ce9b", null ],
    [ "channel", "a01107.html#ad7325261a2df46e301d12355e21c4827", null ],
    [ "conn", "a01107.html#a21aa2ef2803730f1e67a8d02503b8385", null ],
    [ "operator()", "a01107.html#ab1956501c582e41377bc54b4db377ded", null ],
    [ "operator=", "a01107.html#af30be436b943dca0e3fb866748e738eb", null ]
];