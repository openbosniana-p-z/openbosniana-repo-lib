var a00927 =
[
    [ "transaction_rollback", "a00927.html#a3d9b9bad82fb16db092e11bef19308f0", null ]
];