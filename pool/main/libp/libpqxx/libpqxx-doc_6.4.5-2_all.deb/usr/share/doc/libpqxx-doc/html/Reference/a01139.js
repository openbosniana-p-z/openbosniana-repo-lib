var a01139 =
[
    [ "isolation_tag", "a01139.html#ad05fa8ae535413268e3764b7f13a13f8", null ],
    [ "~basic_robusttransaction", "a01139.html#abd409fa6084b85dda719b956c436e655", null ],
    [ "basic_robusttransaction", "a01139.html#a93ef1abd22e7604e5ab6934e047a2340", null ]
];