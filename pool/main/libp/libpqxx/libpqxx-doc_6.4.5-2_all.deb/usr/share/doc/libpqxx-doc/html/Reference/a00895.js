var a00895 =
[
    [ "~dbtransaction", "a00895.html#ace1dc32cc5ab0d51481518e659675b79", null ],
    [ "dbtransaction", "a00895.html#a49d5c0050ec02eba8440b1bdb20a1539", null ],
    [ "dbtransaction", "a00895.html#a12e833c152ed73fabe7c4c30020140e2", null ],
    [ "do_abort", "a00895.html#a6d692e99cbd8bebbcd49fde95e6804c1", null ],
    [ "do_begin", "a00895.html#a64f907c0fb11007624aa89e2ef09b0b5", null ],
    [ "do_commit", "a00895.html#a6e7b375bdfb7d7c98ec04a3b333b917b", null ],
    [ "do_exec", "a00895.html#afd414585f3f01f4e3723d67ddb82a015", null ],
    [ "start_backend_transaction", "a00895.html#a601f599d9c5cca86ce84a77bdac941db", null ]
];