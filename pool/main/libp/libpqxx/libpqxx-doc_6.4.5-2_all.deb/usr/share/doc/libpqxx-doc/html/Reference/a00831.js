var a00831 =
[
    [ "juncture", "a00831.html#a039577d83d313a6daf35fd7c273e189e", [
      [ "row_start", "a00831.html#a039577d83d313a6daf35fd7c273e189ea61a1264caabd3fb22d3aaba393661e97", null ],
      [ "row_end", "a00831.html#a039577d83d313a6daf35fd7c273e189ea3eeeb0fa9ac4aa38809089dee7c0d879", null ],
      [ "null_value", "a00831.html#a039577d83d313a6daf35fd7c273e189eacfc01607c500e3cce7684d4342f6e1c4", null ],
      [ "string_value", "a00831.html#a039577d83d313a6daf35fd7c273e189ea01f9439484cc9ef178b02c8388484ace", null ],
      [ "done", "a00831.html#a039577d83d313a6daf35fd7c273e189ea46ec51c6920747094c2f6c757d78b3f6", null ]
    ] ],
    [ "array_parser", "a00831.html#ade823e39ce5d924cb0f266f2d224bb55", null ],
    [ "get_next", "a00831.html#a962eb270fa67041e2ea33127ca26ae4f", null ]
];