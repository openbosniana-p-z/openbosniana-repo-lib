var a00262 =
[
    [ "pqxx_exception", "a00907.html", [
      [ "~pqxx_exception", "a00907.html#a99010718ddac985b922d570d77a1c95f", null ],
      [ "base", "a00907.html#ad4a6b02d8be201b42b1d5b5836084dd8", null ]
    ] ],
    [ "failure", "a00911.html", [
      [ "failure", "a00911.html#a0e7e8831fed026375c499ee03f501f50", null ]
    ] ],
    [ "broken_connection", "a00915.html", [
      [ "broken_connection", "a00915.html#abead818453c7c47646f924c0b6cbff7d", null ],
      [ "broken_connection", "a00915.html#a003c1c85d2c6c40f6d5b985394aa34b2", null ]
    ] ],
    [ "sql_error", "a00919.html", [
      [ "sql_error", "a00919.html#acbad476bd57abb883768448ee7dc480d", null ],
      [ "~sql_error", "a00919.html#a39bafd01a909dfbc01ea59e1407cea69", null ],
      [ "query", "a00919.html#a0015b251167f819b4455a5738cd0024d", null ],
      [ "sqlstate", "a00919.html#ad14aad9cb9bbde030229e120920b442f", null ]
    ] ],
    [ "in_doubt_error", "a00923.html", [
      [ "in_doubt_error", "a00923.html#a378d91b2f08324db0725a7c89f6dedcf", null ]
    ] ],
    [ "transaction_rollback", "a00927.html", [
      [ "transaction_rollback", "a00927.html#a3d9b9bad82fb16db092e11bef19308f0", null ]
    ] ],
    [ "serialization_failure", "a00931.html", [
      [ "serialization_failure", "a00931.html#a13f05db07efdd6a7114994767f347171", null ]
    ] ],
    [ "statement_completion_unknown", "a00935.html", [
      [ "statement_completion_unknown", "a00935.html#a955db6d5139dd1bff85d56cf2ae3a3b3", null ]
    ] ],
    [ "deadlock_detected", "a00939.html", [
      [ "deadlock_detected", "a00939.html#aa18a2441da593a362ffdc401fa53d452", null ]
    ] ],
    [ "internal_error", "a00943.html", [
      [ "internal_error", "a00943.html#a4514fd8ae629c3e2524b1a8257abeb29", null ]
    ] ],
    [ "usage_error", "a00947.html", [
      [ "usage_error", "a00947.html#ac13c13a650ab45684355682a98655f5b", null ]
    ] ],
    [ "argument_error", "a00951.html", [
      [ "argument_error", "a00951.html#a1b68c0e492e7cb4f9458ca0de1b85862", null ]
    ] ],
    [ "conversion_error", "a00955.html", [
      [ "conversion_error", "a00955.html#aa26b38ec0b49d925597fb0924d34e5a2", null ]
    ] ],
    [ "range_error", "a00959.html", [
      [ "range_error", "a00959.html#afe1f00814531af326e7fb11757f978e9", null ]
    ] ],
    [ "unexpected_rows", "a00963.html", [
      [ "unexpected_rows", "a00963.html#a27a8fea34697f071bb241719d1311f59", null ]
    ] ],
    [ "feature_not_supported", "a00967.html", [
      [ "feature_not_supported", "a00967.html#a28ed693891edba70b8159ba2bbb2c0be", null ]
    ] ],
    [ "data_exception", "a00971.html", [
      [ "data_exception", "a00971.html#a96e4990de3ddf41081cd4d38cef65289", null ]
    ] ],
    [ "integrity_constraint_violation", "a00975.html", [
      [ "integrity_constraint_violation", "a00975.html#a1b32f524e275c2483fe560b2ec297ade", null ]
    ] ],
    [ "restrict_violation", "a00979.html", [
      [ "restrict_violation", "a00979.html#a13507165f6fe8e4b1a8cee9a9b92d7dd", null ]
    ] ],
    [ "not_null_violation", "a00983.html", [
      [ "not_null_violation", "a00983.html#ab508c17c08534959c4eb683466d19229", null ]
    ] ],
    [ "foreign_key_violation", "a00987.html", [
      [ "foreign_key_violation", "a00987.html#adf74b0e75bf2f173d3eb58cf3d79d954", null ]
    ] ],
    [ "unique_violation", "a00991.html", [
      [ "unique_violation", "a00991.html#a775878d150aeca86a488c10121847eae", null ]
    ] ],
    [ "check_violation", "a00995.html", [
      [ "check_violation", "a00995.html#ab8cae59880efdf8073e711d3b6f66770", null ]
    ] ],
    [ "invalid_cursor_state", "a00999.html", [
      [ "invalid_cursor_state", "a00999.html#ae92ad3d9802c66e1950c10175c3554d5", null ]
    ] ],
    [ "invalid_sql_statement_name", "a01003.html", [
      [ "invalid_sql_statement_name", "a01003.html#aa526e6d2cfe418fd8049749089d09040", null ]
    ] ],
    [ "invalid_cursor_name", "a01007.html", [
      [ "invalid_cursor_name", "a01007.html#ae1e1f06bb18e7426a239e2c21d083a92", null ]
    ] ],
    [ "syntax_error", "a01011.html", [
      [ "syntax_error", "a01011.html#afdd97271aa7af752d4f9f8022884c26f", null ],
      [ "error_position", "a01011.html#ae489a0cf604c668f9dbaa89a3df9dedd", null ]
    ] ],
    [ "undefined_column", "a01015.html", [
      [ "undefined_column", "a01015.html#ae594f5d60da8f9147f3328058e62ff93", null ]
    ] ],
    [ "undefined_function", "a01019.html", [
      [ "undefined_function", "a01019.html#ab3637c6ddd15eeaf072d711ea8e9278c", null ]
    ] ],
    [ "undefined_table", "a01023.html", [
      [ "undefined_table", "a01023.html#a7408dd8ecf61f70db9b238e7010724d5", null ]
    ] ],
    [ "insufficient_privilege", "a01027.html", [
      [ "insufficient_privilege", "a01027.html#ae0e0cbf810c4f7963211d2902cc1a7bb", null ]
    ] ],
    [ "insufficient_resources", "a01031.html", [
      [ "insufficient_resources", "a01031.html#af1082f1471283fc29e467d08c4c37acd", null ]
    ] ],
    [ "disk_full", "a01035.html", [
      [ "disk_full", "a01035.html#a313c79e858e9bc8baf56f2ceacd4ae37", null ]
    ] ],
    [ "out_of_memory", "a01039.html", [
      [ "out_of_memory", "a01039.html#ab885d17acce2d4ea78b2d5ded74bf5c3", null ]
    ] ],
    [ "too_many_connections", "a01043.html", [
      [ "too_many_connections", "a01043.html#ad613a4a06c35fc29cdb838427250d727", null ]
    ] ],
    [ "plpgsql_error", "a01047.html", [
      [ "plpgsql_error", "a01047.html#ab62f910fc207d828f25eba2923d4ee3a", null ]
    ] ],
    [ "plpgsql_raise", "a01051.html", [
      [ "plpgsql_raise", "a01051.html#aa3188ff1059b85846ebe05c8173fa0df", null ]
    ] ],
    [ "plpgsql_no_data_found", "a01055.html", [
      [ "plpgsql_no_data_found", "a01055.html#a7aefa6df3c7d06197e3158aa7ee87f49", null ]
    ] ],
    [ "plpgsql_too_many_rows", "a01059.html", [
      [ "plpgsql_too_many_rows", "a01059.html#acf6c5e6af7420c198546869c7aff08d4", null ]
    ] ]
];