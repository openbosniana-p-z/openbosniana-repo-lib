var a00907 =
[
    [ "~pqxx_exception", "a00907.html#a99010718ddac985b922d570d77a1c95f", null ],
    [ "base", "a00907.html#ad4a6b02d8be201b42b1d5b5836084dd8", null ]
];