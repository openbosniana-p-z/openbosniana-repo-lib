var a01071 =
[
    [ "char_type", "a01071.html#ab93e5d4638629e50e3dbec0b62ded415", null ],
    [ "int_type", "a01071.html#a60bfa85673a1ebe08f3a866d5e436fed", null ],
    [ "off_type", "a01071.html#a46d7cc465adf72e9ef840bc1e8e55175", null ],
    [ "pos_type", "a01071.html#a2256e9e4cb048ca119a082f63dec9647", null ],
    [ "traits_type", "a01071.html#a0762c09d15182babab76ec4182ce8681", null ],
    [ "basic_fieldstream", "a01071.html#a1f1918fb6cf893bb59e8b3e2921c22fd", null ]
];