var a01219 =
[
    [ "subtransaction", "a01219.html#a04516b0c229237fafd29f9c8c30fec39", null ],
    [ "subtransaction", "a01219.html#a17d6c609cc2708ff30bf1ee2e13c415c", null ],
    [ "~subtransaction", "a01219.html#a50fe87342d56e35e44ad8d2537f8c50e", null ]
];