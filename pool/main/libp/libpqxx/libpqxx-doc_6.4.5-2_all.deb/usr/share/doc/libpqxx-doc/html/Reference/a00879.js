var a00879 =
[
    [ "difference_type", "a00879.html#ada166a0fb33fe691868dad036d3b2d03", null ],
    [ "size_type", "a00879.html#a5933f6fed7891b6e7aa9bc43059a0e7b", null ],
    [ "accesspolicy", "a00879.html#a591ac7d2302288890c04e6159eb6d30e", [
      [ "forward_only", "a00879.html#a591ac7d2302288890c04e6159eb6d30eaf440221f717464c87f043899cc117cbf", null ],
      [ "random_access", "a00879.html#a591ac7d2302288890c04e6159eb6d30ea7f6c1ed7719885433353a78946b2c5f3", null ]
    ] ],
    [ "ownershippolicy", "a00879.html#a8d5f8214ede2ab27dd588defc2847330", [
      [ "owned", "a00879.html#a8d5f8214ede2ab27dd588defc2847330a3ace6a7a5ca4ec3b486f2f35fd2420b0", null ],
      [ "loose", "a00879.html#a8d5f8214ede2ab27dd588defc2847330a4c37408c49492bfe9f012812226dd1fd", null ]
    ] ],
    [ "updatepolicy", "a00879.html#aba6fa56f1ef2d25c3c73240de6b9c212", [
      [ "read_only", "a00879.html#aba6fa56f1ef2d25c3c73240de6b9c212a8122c0c4a5eb9c9dbf27ab40a2686eb0", null ],
      [ "update", "a00879.html#aba6fa56f1ef2d25c3c73240de6b9c212a12fa229ee3e760f1ca86d66304554b63", null ]
    ] ],
    [ "cursor_base", "a00879.html#aa77f18cfbbb68f81e730f3bfbbb5c89b", null ],
    [ "cursor_base", "a00879.html#a515de31d551c34a0d2ed8bbeb16ef212", null ],
    [ "cursor_base", "a00879.html#a92ebe0bfff015fc1d85ab30d1ac97ef4", null ],
    [ "name", "a00879.html#a42459f9e64851788fe0b3a772b4684b1", null ],
    [ "operator=", "a00879.html#aad6dcfe71bcbb1a66b04b1315d017f99", null ],
    [ "m_name", "a00879.html#a947b286d508fad4a1823f8b13a5ccef3", null ]
];