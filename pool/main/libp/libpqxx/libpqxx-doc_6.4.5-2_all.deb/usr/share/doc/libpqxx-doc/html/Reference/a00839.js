var a00839 =
[
    [ "basic_connection", "a00839.html#aba8b432e3ddb48446c5daf27ca191c91", null ],
    [ "basic_connection", "a00839.html#a0436a1271586987e97bdf5b59b96f607", null ],
    [ "basic_connection", "a00839.html#aa6c74a9abcfa2b13c2334d0c38f66305", null ],
    [ "basic_connection", "a00839.html#a864a689820abb61e79482142354877bd", null ]
];