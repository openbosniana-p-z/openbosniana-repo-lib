var a01275 =
[
    [ "unique", "a01275.html#a3c86ac44f808e0ae9bbde8de77258159", null ],
    [ "unique", "a01275.html#a6d7ae2b85e804f3dd23dc3293962234a", null ],
    [ "get", "a01275.html#a8fd470f0cbef8526c8148f44199190bc", null ],
    [ "operator=", "a01275.html#a89c230a1d8cc5da8abe8ae9cbc2540f1", null ],
    [ "register_guest", "a01275.html#af63037d4d5b6751f78f93a062154d293", null ],
    [ "unregister_guest", "a01275.html#aeab06f9ea29aa7628b571a38ed6b0f3e", null ]
];