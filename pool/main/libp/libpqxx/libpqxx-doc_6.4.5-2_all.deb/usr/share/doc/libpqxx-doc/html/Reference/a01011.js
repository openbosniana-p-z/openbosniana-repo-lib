var a01011 =
[
    [ "syntax_error", "a01011.html#afdd97271aa7af752d4f9f8022884c26f", null ],
    [ "error_position", "a01011.html#ae489a0cf604c668f9dbaa89a3df9dedd", null ]
];