var a00899 =
[
    [ "errorhandler", "a00899.html#a4627d71dc5156998ab1a8705fe5db974", null ],
    [ "~errorhandler", "a00899.html#a102761e1ec70d1f2d339d250bcdc799c", null ],
    [ "operator()", "a00899.html#ac0e41896075d40c1c2439c6662ed0799", null ],
    [ "internal::gate::errorhandler_connection_base", "a00899.html#a08b329d18887eeb882ff0c80b8ae74ba", null ]
];