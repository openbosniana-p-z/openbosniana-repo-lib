var a00835 =
[
    [ "basic_connection_base", "a00835.html#afd89f4c442ef6b5c586168949124ea92", null ],
    [ "basic_connection_base", "a00835.html#a11e306c9d2aee94482d87eb666381bdb", null ],
    [ "basic_connection_base", "a00835.html#afad301146d88cce2ec18b4af9e7d20c2", null ],
    [ "basic_connection_base", "a00835.html#ad09659ca1a0c7a9213f58bf66646c091", null ],
    [ "~basic_connection_base", "a00835.html#ae78d4742db05a287d85779d98e3d2d3c", null ],
    [ "options", "a00835.html#a117bd8f519d9df806614c888b72f2754", null ]
];