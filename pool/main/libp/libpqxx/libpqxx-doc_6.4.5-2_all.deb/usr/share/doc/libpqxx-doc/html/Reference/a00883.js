var a00883 =
[
    [ "difference_type", "a00883.html#a8f3b200166af0e4c2aa2649204df0b2b", null ],
    [ "size_type", "a00883.html#a8dbf98af7391df15a686bfb9853e8394", null ],
    [ "stateless_cursor", "a00883.html#aa042b1c72b16911a4f2e1c73be3d8942", null ],
    [ "stateless_cursor", "a00883.html#a8231490bf29aa7686c4daa3b1fc97ed1", null ],
    [ "close", "a00883.html#a333403f9410c09e299d87cc6f06738d0", null ],
    [ "name", "a00883.html#a313adb605a31c7b2d7b63a0dc561f9a0", null ],
    [ "retrieve", "a00883.html#a97046479f709ae621473c48ed7a0932d", null ],
    [ "size", "a00883.html#ae278f24bab98d3946061934a48992067", null ]
];