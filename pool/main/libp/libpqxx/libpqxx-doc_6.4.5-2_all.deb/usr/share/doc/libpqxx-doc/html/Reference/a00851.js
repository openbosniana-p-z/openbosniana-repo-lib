var a00851 =
[
    [ "connect_lazy", "a00851.html#a9d93b15b0681f3b4e25e9fab79adb8cd", null ],
    [ "do_completeconnect", "a00851.html#a676c90683625962c20bc4dbf43b6ab88", null ]
];