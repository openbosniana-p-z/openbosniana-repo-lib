var a00847 =
[
    [ "connect_direct", "a00847.html#a3ae8ab240a1f152c64cd40493d92f846", null ],
    [ "do_startconnect", "a00847.html#a11ef1d3b39a643854b51e81f2b1e869a", null ]
];