var a01247 =
[
    [ "isolation_tag", "a01247.html#aa8cc82d045fc6a287ebc3c3b152b6d67", null ],
    [ "transaction", "a01247.html#a5ad879f746d13f51e469c67665b5d3f9", null ],
    [ "transaction", "a01247.html#a664bdb9c889f946c162cac14bdbe6b7b", null ],
    [ "~transaction", "a01247.html#a69ab36d20e4b04500a094cae9954c97f", null ]
];