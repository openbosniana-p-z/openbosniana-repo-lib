var structpst__desc__tree =
[
    [ "assoc_tree", "structpst__desc__tree.html#a4053f4efe7fabd0e0d19ead57b14bc98", null ],
    [ "child", "structpst__desc__tree.html#a2e049e1efeddc15532e05839c6174aca", null ],
    [ "child_tail", "structpst__desc__tree.html#a9adf0457b752c08aeac9cf4a9ee26b89", null ],
    [ "d_id", "structpst__desc__tree.html#ae63bfa0506df0c39b27e02ce7101b0df", null ],
    [ "desc", "structpst__desc__tree.html#a97871cdc8ac25519742b49d81a06cc17", null ],
    [ "next", "structpst__desc__tree.html#a13ca30f1c5d38a9cd886e93a674876cb", null ],
    [ "no_child", "structpst__desc__tree.html#a79bc2b124a95a3777eac6ec650bb717a", null ],
    [ "parent", "structpst__desc__tree.html#a9b07fced4289c54b2f9db701309b9ac7", null ],
    [ "parent_d_id", "structpst__desc__tree.html#a95886c82a833909549fbd5eff3c2003e", null ],
    [ "prev", "structpst__desc__tree.html#a4202afc77ea4db474ecc821e7ca22324", null ]
];