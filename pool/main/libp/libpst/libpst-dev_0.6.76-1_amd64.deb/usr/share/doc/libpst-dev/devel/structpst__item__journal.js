var structpst__item__journal =
[
    [ "description", "structpst__item__journal.html#a00bae7b93cc867ed846081cbcbdbed1b", null ],
    [ "end", "structpst__item__journal.html#a0dc12521d1f9888b1384b37d86021923", null ],
    [ "start", "structpst__item__journal.html#a53b4bf1896c4a0538f86ec5fd3e4b556", null ],
    [ "type", "structpst__item__journal.html#a03637b74ae30f45e8be952bd3dbac77a", null ]
];