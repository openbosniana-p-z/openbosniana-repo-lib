var structpst__item__folder =
[
    [ "assoc_count", "structpst__item__folder.html#ab06246ba222313709b68fbac2678c14f", null ],
    [ "item_count", "structpst__item__folder.html#afc5b81423e2e217713458a0862c639e6", null ],
    [ "subfolder", "structpst__item__folder.html#a2198dd4573f246272653be6ddb0e64bf", null ],
    [ "unseen_item_count", "structpst__item__folder.html#aace1f1b072a2ba45d5ba416b4301e622", null ]
];