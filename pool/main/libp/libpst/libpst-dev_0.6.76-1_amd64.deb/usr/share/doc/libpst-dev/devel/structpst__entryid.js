var structpst__entryid =
[
    [ "entryid", "structpst__entryid.html#a712b892005cccc699994fb0327204957", null ],
    [ "id", "structpst__entryid.html#a2be6cdcf88ecd55ecb5b5445802ce7c4", null ],
    [ "u1", "structpst__entryid.html#a519ea480934678588156fcfc1b16953e", null ]
];