var structpst__item__appointment =
[
    [ "alarm", "structpst__item__appointment.html#aff9714e71e9f2612fc56c9efd13ad18e", null ],
    [ "alarm_filename", "structpst__item__appointment.html#a4e888b1822686865c9a31bf7940e399d", null ],
    [ "alarm_minutes", "structpst__item__appointment.html#a4b4d05cfee8823068ee46009ba9a03ef", null ],
    [ "all_day", "structpst__item__appointment.html#a6399207e8ef0cdb37893715fce5759e0", null ],
    [ "end", "structpst__item__appointment.html#a7d29e98e9052a4c7f866d2b06d3ee712", null ],
    [ "is_recurring", "structpst__item__appointment.html#a7eef2fda06954346d8894a06c94a224f", null ],
    [ "label", "structpst__item__appointment.html#a2aca3d6391bc24f26d68237b69216e2b", null ],
    [ "location", "structpst__item__appointment.html#a0b9c459290d4c90aeb3d0bb99834e8e5", null ],
    [ "recurrence_data", "structpst__item__appointment.html#afd60a0673191b1f4a2d85f9d10602e19", null ],
    [ "recurrence_description", "structpst__item__appointment.html#a20ae1589337570ac0beef64a19be07e1", null ],
    [ "recurrence_end", "structpst__item__appointment.html#af22b04600115378790ce9bf69efa422b", null ],
    [ "recurrence_start", "structpst__item__appointment.html#ae8fc87b285eb7a428f0efeb7a84f96e2", null ],
    [ "recurrence_type", "structpst__item__appointment.html#ade51e7cbc09e4ca8c39f3b6d6e3476db", null ],
    [ "reminder", "structpst__item__appointment.html#ad624b3c1166e2867013b54ab58c63943", null ],
    [ "showas", "structpst__item__appointment.html#ab03ca84acd1f96880dcf1ebeeefdeed5", null ],
    [ "start", "structpst__item__appointment.html#af37804a2ff6bd134316639b255711d61", null ],
    [ "timezonestring", "structpst__item__appointment.html#acfb56231a5b583e916dc3514fe0fee02", null ]
];