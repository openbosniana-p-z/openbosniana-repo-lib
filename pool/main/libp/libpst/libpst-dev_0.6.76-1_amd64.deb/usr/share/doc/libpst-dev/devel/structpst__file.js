var structpst__file =
[
    [ "block_head", "structpst__file.html#a7769614d85bf8359bb017813e8c8bd4f", null ],
    [ "charset", "structpst__file.html#afc0abf894b46f0582d651eddcbe3541e", null ],
    [ "cwd", "structpst__file.html#a0836103b6046b555d147bf44584102fa", null ],
    [ "d_head", "structpst__file.html#aaf5344f31e149ff0afb64074b81d67ab", null ],
    [ "d_tail", "structpst__file.html#ab4381d0030463db64a7cec4aef274088", null ],
    [ "do_read64", "structpst__file.html#a934b0e620cd8117f6f78e0f27d60a2f6", null ],
    [ "encryption", "structpst__file.html#a5c0c653118d15ab375e9ad4b5bf32a16", null ],
    [ "fname", "structpst__file.html#af7375fa8b9abddd13d173719a2f761e6", null ],
    [ "fp", "structpst__file.html#ac8c07003c5e5e92867eafe821299b360", null ],
    [ "i_capacity", "structpst__file.html#a11624a5943c5e84269818d2842f5cb15", null ],
    [ "i_count", "structpst__file.html#aba1ff8472f8475cf5ac9790f3014d63d", null ],
    [ "i_table", "structpst__file.html#a4845afe25be80a71761ea02acf52ae66", null ],
    [ "ind_type", "structpst__file.html#a6d2ea97bf1dd4c699307f7a0d2d0b241", null ],
    [ "index1", "structpst__file.html#a236d987098be87aca4c8425a1b439124", null ],
    [ "index1_back", "structpst__file.html#a3428239190356ce61ea1c49e6901aa35", null ],
    [ "index2", "structpst__file.html#a24fb10af30360d9a1990cf546a532154", null ],
    [ "index2_back", "structpst__file.html#a970a48d4514ca456fa61f1448821ba99", null ],
    [ "size", "structpst__file.html#a6d71d43bcb98b353f7f3e7b648407546", null ],
    [ "x_head", "structpst__file.html#acf892ef2183fc8c6f295253a74e13134", null ]
];