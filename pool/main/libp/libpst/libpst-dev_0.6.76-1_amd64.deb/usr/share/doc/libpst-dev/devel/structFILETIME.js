var structFILETIME =
[
    [ "dwHighDateTime", "structFILETIME.html#a543da86c41405dab23039927ef7bc5bf", null ],
    [ "dwLowDateTime", "structFILETIME.html#a9eb75a091d37f541085bd2cb6607651b", null ]
];