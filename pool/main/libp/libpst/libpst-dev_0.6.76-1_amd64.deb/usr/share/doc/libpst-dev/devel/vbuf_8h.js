var vbuf_8h =
[
    [ "pst_varbuf", "structpst__varbuf.html", "structpst__varbuf" ],
    [ "pst_vbuf", "vbuf_8h.html#aaa1dee6fbcaea8e1108159d4f17ab23e", null ],
    [ "pst_unicode_init", "vbuf_8h.html#acac0ab240cfa50ebe0950c9b1a409a56", null ],
    [ "pst_vb_8bit2utf8", "vbuf_8h.html#a0fdf2eef1097ae8e76c72975ad8b9827", null ],
    [ "pst_vb_utf16to8", "vbuf_8h.html#a750cb3dc289c2ba8348dc3234607d5a0", null ],
    [ "pst_vb_utf8to8bit", "vbuf_8h.html#acbb9b73b82b6c1552fbd23f84982b142", null ],
    [ "pst_vballoc", "vbuf_8h.html#a8faefe0cac6a2fa6b3ab49714005927b", null ],
    [ "pst_vbappend", "vbuf_8h.html#a17620fb77cc01f2949ca0ca48e5af8fd", null ],
    [ "pst_vbgrow", "vbuf_8h.html#a7c0093c16ca48161ae5e028c84da4d8f", null ],
    [ "pst_vbset", "vbuf_8h.html#a61fa92419f63297cedc2e2234b740293", null ]
];