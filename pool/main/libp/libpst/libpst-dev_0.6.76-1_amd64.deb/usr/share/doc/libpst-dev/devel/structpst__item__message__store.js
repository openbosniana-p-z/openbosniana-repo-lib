var structpst__item__message__store =
[
    [ "common_view_folder", "structpst__item__message__store.html#a584e01148311423077fc343ef0c4de1e", null ],
    [ "default_outbox_folder", "structpst__item__message__store.html#a444ae76c613bd8a6457d84408159d881", null ],
    [ "deleted_items_folder", "structpst__item__message__store.html#ad3efbed37d91bb7bed45d2c8409ef9db", null ],
    [ "pwd_chksum", "structpst__item__message__store.html#ae129914ae499a10092ce15505031358a", null ],
    [ "search_root_folder", "structpst__item__message__store.html#a2a790f4cc3b09d018ab4e3b03cc142e5", null ],
    [ "sent_items_folder", "structpst__item__message__store.html#aa905fe6d4bf01d390c5a67d2d8f4ebb8", null ],
    [ "top_of_folder", "structpst__item__message__store.html#a55be4581ce431f73daaf62eb807ed95e", null ],
    [ "top_of_personal_folder", "structpst__item__message__store.html#afc7a9b6e3feacf7febb639c553e4d599", null ],
    [ "user_views_folder", "structpst__item__message__store.html#abd87d2174c20729c78153637d57f46e3", null ],
    [ "valid_mask", "structpst__item__message__store.html#a1c6a4218571df9baa69ef22fafc45141", null ]
];