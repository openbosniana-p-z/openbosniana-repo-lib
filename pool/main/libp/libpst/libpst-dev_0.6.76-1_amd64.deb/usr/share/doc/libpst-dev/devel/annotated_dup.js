var annotated_dup =
[
    [ "FILETIME", "structFILETIME.html", "structFILETIME" ],
    [ "pst_binary", "structpst__binary.html", "structpst__binary" ],
    [ "pst_block_recorder", "structpst__block__recorder.html", "structpst__block__recorder" ],
    [ "pst_desc_tree", "structpst__desc__tree.html", "structpst__desc__tree" ],
    [ "pst_entryid", "structpst__entryid.html", "structpst__entryid" ],
    [ "pst_file", "structpst__file.html", "structpst__file" ],
    [ "pst_id2_tree", "structpst__id2__tree.html", "structpst__id2__tree" ],
    [ "pst_index_ll", "structpst__index__ll.html", "structpst__index__ll" ],
    [ "pst_item", "structpst__item.html", "structpst__item" ],
    [ "pst_item_appointment", "structpst__item__appointment.html", "structpst__item__appointment" ],
    [ "pst_item_attach", "structpst__item__attach.html", "structpst__item__attach" ],
    [ "pst_item_contact", "structpst__item__contact.html", "structpst__item__contact" ],
    [ "pst_item_email", "structpst__item__email.html", "structpst__item__email" ],
    [ "pst_item_extra_field", "structpst__item__extra__field.html", "structpst__item__extra__field" ],
    [ "pst_item_folder", "structpst__item__folder.html", "structpst__item__folder" ],
    [ "pst_item_journal", "structpst__item__journal.html", "structpst__item__journal" ],
    [ "pst_item_message_store", "structpst__item__message__store.html", "structpst__item__message__store" ],
    [ "pst_recurrence", "structpst__recurrence.html", "structpst__recurrence" ],
    [ "pst_string", "structpst__string.html", "structpst__string" ],
    [ "pst_varbuf", "structpst__varbuf.html", "structpst__varbuf" ],
    [ "pst_x_attrib_ll", "structpst__x__attrib__ll.html", "structpst__x__attrib__ll" ]
];