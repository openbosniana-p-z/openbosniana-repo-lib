var structpst__item__attach =
[
    [ "content_id", "structpst__item__attach.html#ae7482e68971ce340cf086c82eee592f5", null ],
    [ "data", "structpst__item__attach.html#ab79e885778187f23470077c019cbe55b", null ],
    [ "filename1", "structpst__item__attach.html#aa92be7fef8034cb5601757fb315d2a98", null ],
    [ "filename2", "structpst__item__attach.html#a3ab64218cbb476d5199f8f3d06db2f37", null ],
    [ "i_id", "structpst__item__attach.html#a35e9b86a479c9e0bd276c7c0456b262e", null ],
    [ "id2_head", "structpst__item__attach.html#a1d8374ed6ddb401a31315026365f3dbe", null ],
    [ "id2_val", "structpst__item__attach.html#a384b52bc2c71402224656825746934b7", null ],
    [ "method", "structpst__item__attach.html#a6506d560e58790270d9d7cc89500e886", null ],
    [ "mimetype", "structpst__item__attach.html#ab44388a512817ce10c1e010785d76b12", null ],
    [ "next", "structpst__item__attach.html#a3644889ae2e6601452092a41cce66c12", null ],
    [ "position", "structpst__item__attach.html#a7f352742f214de9b71224516d5b23bc2", null ],
    [ "sequence", "structpst__item__attach.html#ab6a648439f6c497a6ddf75b2e661dad4", null ]
];