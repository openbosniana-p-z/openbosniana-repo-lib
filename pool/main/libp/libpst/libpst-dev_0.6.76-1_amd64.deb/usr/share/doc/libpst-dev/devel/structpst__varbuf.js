var structpst__varbuf =
[
    [ "b", "structpst__varbuf.html#a41add60a1e6cd0d6aec24116927e5dd0", null ],
    [ "blen", "structpst__varbuf.html#af17585e4393bd710acf0399bbddd2c09", null ],
    [ "buf", "structpst__varbuf.html#aebeafb40438282a084f73a1798f7514f", null ],
    [ "dlen", "structpst__varbuf.html#aa308264a87b31a7b38dd1384c81e9d7d", null ]
];