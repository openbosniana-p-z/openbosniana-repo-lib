var structpst__string =
[
    [ "is_utf8", "structpst__string.html#a143e846cde590cea9dd34a595333082d", null ],
    [ "str", "structpst__string.html#a8a0c092f11d7cd6b6218e2881cfab51c", null ]
];