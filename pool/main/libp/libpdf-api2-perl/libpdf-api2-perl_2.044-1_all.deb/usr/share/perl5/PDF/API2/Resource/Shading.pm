package PDF::API2::Resource::Shading;

use base 'PDF::API2::Resource';

use strict;
use warnings;

our $VERSION = '2.044'; # VERSION

1;
