
#ifndef PDB_REDO_EXPORT_H
#define PDB_REDO_EXPORT_H

#ifdef PDB_REDO_STATIC_DEFINE
#  define PDB_REDO_EXPORT
#  define PDB_REDO_NO_EXPORT
#else
#  ifndef PDB_REDO_EXPORT
#    ifdef pdb_redo_EXPORTS
        /* We are building this library */
#      define PDB_REDO_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define PDB_REDO_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef PDB_REDO_NO_EXPORT
#    define PDB_REDO_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef PDB_REDO_DEPRECATED
#  define PDB_REDO_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef PDB_REDO_DEPRECATED_EXPORT
#  define PDB_REDO_DEPRECATED_EXPORT PDB_REDO_EXPORT PDB_REDO_DEPRECATED
#endif

#ifndef PDB_REDO_DEPRECATED_NO_EXPORT
#  define PDB_REDO_DEPRECATED_NO_EXPORT PDB_REDO_NO_EXPORT PDB_REDO_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef PDB_REDO_NO_DEPRECATED
#    define PDB_REDO_NO_DEPRECATED
#  endif
#endif

#endif /* PDB_REDO_EXPORT_H */
