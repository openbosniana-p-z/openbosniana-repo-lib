use Demo_IMPORT {hash=>[1,2]}, [9..11], qw(foo :BAR qux), \"str";

print foo(), "\n";

print bar(), "\n";

print always(), "\n";
