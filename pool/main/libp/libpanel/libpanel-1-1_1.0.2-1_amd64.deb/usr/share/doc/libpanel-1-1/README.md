# Libpanel

Libpanel helps you create IDE-like applications using GTK 4 and libadwaita.

It has widgets for panels, docks, columns and grids of pages. Primarily, it's
design and implementation focus around GNOME Builder and Drafting projects.

