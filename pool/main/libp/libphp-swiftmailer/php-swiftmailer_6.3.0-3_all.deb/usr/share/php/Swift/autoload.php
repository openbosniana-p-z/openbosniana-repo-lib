<?php

require_once 'Egulias/EmailValidator/autoload.php';

require_once __DIR__ . '/swift_required.php';
