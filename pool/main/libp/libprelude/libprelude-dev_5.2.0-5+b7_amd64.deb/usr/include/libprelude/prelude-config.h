/* Used from libprelude headers */
#define HAVE_VARIADIC_MACROS 1
/* #undef PRELUDE_ALIGNED_ACCESS */
/* #undef PRELUDE_WORDS_BIGENDIAN */
#define __PRELUDE_FUNC__ __func__
#ifndef TIME_WITH_SYS_TIME
#define TIME_WITH_SYS_TIME 1
#endif
#ifndef HAVE_UID_T
#define HAVE_UID_T 1
#endif
#ifndef HAVE_GID_T
#define HAVE_GID_T 1
#endif
