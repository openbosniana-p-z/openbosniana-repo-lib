use Perl6::Form;

print form
	'A left-justified field look like this: \{[[[[[[[[[[[}',
	'The escape character for formats is: \\';
