use Perl6::Form;

my @nums = (0..10);

print form "left: {}   right: {]{2}]}", \@nums, \@nums;
