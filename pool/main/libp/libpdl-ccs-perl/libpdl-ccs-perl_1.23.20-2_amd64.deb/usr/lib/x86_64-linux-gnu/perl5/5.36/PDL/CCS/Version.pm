## File: PDL::CCS::Version.pm
## Author: Bryan Jurish
## Description: set version for PDL::CCS

package PDL::CCS::Version;
our $VERSION = '1.23.20'; ##-- update with perl-reversion from Perl::Version module

1; ##-- make perl happy
