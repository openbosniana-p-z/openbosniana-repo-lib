#pragma once

#define PAPPSOMSPP_NAME "libpappsomspp"
#define PAPPSOMSPP_VERSION "0.9.6"


