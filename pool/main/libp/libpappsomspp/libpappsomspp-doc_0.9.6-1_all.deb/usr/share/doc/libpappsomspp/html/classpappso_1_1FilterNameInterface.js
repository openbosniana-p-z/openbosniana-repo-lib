var classpappso_1_1FilterNameInterface =
[
    [ "~FilterNameInterface", "classpappso_1_1FilterNameInterface.html#a53ecf233221aacf15f6694f1929953c5", null ],
    [ "buildFilterFromString", "classpappso_1_1FilterNameInterface.html#ad784b96ae55e45936b0c639b48944892", null ],
    [ "name", "classpappso_1_1FilterNameInterface.html#a92a12d503e58cc684068fdae4b78a794", null ],
    [ "toString", "classpappso_1_1FilterNameInterface.html#a80404eaf6d9083edb708603763359848", null ]
];