var classpappso_1_1FastaHandlerInterface =
[
    [ "setSequence", "classpappso_1_1FastaHandlerInterface.html#afc27b28f5be073565ba016fd131d86fc", null ]
];