var classpappso_1_1PappsoException =
[
    [ "PappsoException", "classpappso_1_1PappsoException.html#a1b4f01c390905ebe84aeb40f3b046ad6", null ],
    [ "PappsoException", "classpappso_1_1PappsoException.html#a188aa0975c7701ee4f3272f21a1db378", null ],
    [ "~PappsoException", "classpappso_1_1PappsoException.html#aed74bcba935b125cb16fdbb3fd515e21", null ],
    [ "clone", "classpappso_1_1PappsoException.html#a3c24ba1d4c15f50d740f47e852b49f40", null ],
    [ "qwhat", "classpappso_1_1PappsoException.html#ac3420244696e54e2a67395a161b87be6", null ],
    [ "raise", "classpappso_1_1PappsoException.html#ade1e0eba8a7dca47479494f1ec4a09d9", null ],
    [ "what", "classpappso_1_1PappsoException.html#aaad322f7f7eed392e19ddd4a16044c1e", null ],
    [ "m_message", "classpappso_1_1PappsoException.html#a46c84aec90ec50125b69eadee25e7ec8", null ],
    [ "m_stdMessage", "classpappso_1_1PappsoException.html#ae07b1cfc2414559346122fb1b3bb5247", null ]
];