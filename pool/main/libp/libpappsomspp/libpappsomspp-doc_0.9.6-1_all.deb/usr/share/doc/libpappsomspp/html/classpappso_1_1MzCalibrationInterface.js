var classpappso_1_1MzCalibrationInterface =
[
    [ "MzCalibrationInterface", "classpappso_1_1MzCalibrationInterface.html#a1c2cc65ff99955b52fda3c13e6a968a2", null ],
    [ "~MzCalibrationInterface", "classpappso_1_1MzCalibrationInterface.html#a1ee96720ea9c95f1aa6a0cd4e992a383", null ],
    [ "getMzFromTofIndex", "classpappso_1_1MzCalibrationInterface.html#a499ee1a6cea71b344c4d393455dcbccc", null ],
    [ "getTofFromTofIndex", "classpappso_1_1MzCalibrationInterface.html#a776d644fa9303992fdb6fc03da5e7ba9", null ],
    [ "getTofFromTofIndex", "classpappso_1_1MzCalibrationInterface.html#a0c92aaa269af2d1a96695db7ca205bfe", null ],
    [ "getTofIndexFromMz", "classpappso_1_1MzCalibrationInterface.html#ab232275366d2ef45ea07f0967a3ab344", null ],
    [ "operator=", "classpappso_1_1MzCalibrationInterface.html#aade30836970b49942203090d0c6e90e1", null ],
    [ "operator==", "classpappso_1_1MzCalibrationInterface.html#a54fbfbe91375e5c23d1965d6e3a20104", null ],
    [ "m_digitizerDelay", "classpappso_1_1MzCalibrationInterface.html#a724e7c044693d6feba06a3bf86952459", null ],
    [ "m_digitizerTimebase", "classpappso_1_1MzCalibrationInterface.html#a2794b15e0d35970b580dc190496ce39c", null ],
    [ "m_mzCalibrationArr", "classpappso_1_1MzCalibrationInterface.html#a2678f255bda1709260feec1807033836", null ]
];