var classpappso_1_1FastaFileIndexerInterface =
[
    [ "close", "classpappso_1_1FastaFileIndexerInterface.html#a2759e817208c8bf3d8ff58afd4e8b305", null ],
    [ "getSequenceByIndex", "classpappso_1_1FastaFileIndexerInterface.html#a5ca3e1abb8ac63e059bfe89b3137ce9b", null ],
    [ "open", "classpappso_1_1FastaFileIndexerInterface.html#ab7d46da51bc3b762d8031488074e8547", null ]
];