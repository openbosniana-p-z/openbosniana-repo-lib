var classpappso_1_1FilterInterface =
[
    [ "~FilterInterface", "classpappso_1_1FilterInterface.html#afadee5cb7a319b99f339e7ef22d7f54d", null ],
    [ "filter", "classpappso_1_1FilterInterface.html#a2a938d1b6870ec72a481e8f9963696ea", null ]
];