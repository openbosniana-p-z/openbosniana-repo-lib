var classpappso_1_1MzCalibrationModel1 =
[
    [ "MzCalibrationModel1", "classpappso_1_1MzCalibrationModel1.html#a0d3bb8609ce7363d0f8b90f4f6aa31df", null ],
    [ "~MzCalibrationModel1", "classpappso_1_1MzCalibrationModel1.html#aed8411d74ec708c324ff51416aa200b7", null ],
    [ "getMzFromTofIndex", "classpappso_1_1MzCalibrationModel1.html#a046b41dbd1d0ce4980485263780a7e86", null ],
    [ "getTofIndexFromMz", "classpappso_1_1MzCalibrationModel1.html#a901e77c4ba093c9aea13595e062b9519", null ]
];