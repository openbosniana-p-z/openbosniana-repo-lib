var classpappso_1_1DaltonPrecision =
[
    [ "DaltonPrecision", "classpappso_1_1DaltonPrecision.html#aa13205dbccafe3f65c5182a90540cd0c", null ],
    [ "~DaltonPrecision", "classpappso_1_1DaltonPrecision.html#a9f6f0191916399ada084973fda676ed3", null ],
    [ "delta", "classpappso_1_1DaltonPrecision.html#ac5894e84d4b57f557b17da187dc51a0a", null ],
    [ "toString", "classpappso_1_1DaltonPrecision.html#a40355c2186998bbf6e6e54f62134e959", null ],
    [ "unit", "classpappso_1_1DaltonPrecision.html#ace59e5fb6237ce1d83ef13dedc1df4ba", null ],
    [ "PrecisionFactory", "classpappso_1_1DaltonPrecision.html#add0dedf9e13051f73c58dd3293a0af7a", null ]
];