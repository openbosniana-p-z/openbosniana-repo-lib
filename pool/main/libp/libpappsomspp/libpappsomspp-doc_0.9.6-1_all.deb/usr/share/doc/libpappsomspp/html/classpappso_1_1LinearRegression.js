var classpappso_1_1LinearRegression =
[
    [ "LinearRegression", "classpappso_1_1LinearRegression.html#ae2ad3e6de5c94e7d21e0d686731a60f1", null ],
    [ "getCoefficientOfDetermination", "classpappso_1_1LinearRegression.html#a93ea7b9cdc6dd0e6fb5582a398a5ae63", null ],
    [ "getIntercept", "classpappso_1_1LinearRegression.html#a027fa30a0461b35e682e0be18b624583", null ],
    [ "getNrmsd", "classpappso_1_1LinearRegression.html#a41a9bab7a252e40530177614e9420ef3", null ],
    [ "getRmsd", "classpappso_1_1LinearRegression.html#ac80d8462167c4286b7073f62990a84e6", null ],
    [ "getSlope", "classpappso_1_1LinearRegression.html#aafe4d50a920fae67998dcc75a81af21f", null ],
    [ "getYfromX", "classpappso_1_1LinearRegression.html#a60e74b7b32a247ede9e0d4495c672f5a", null ],
    [ "_intercept", "classpappso_1_1LinearRegression.html#aa9dc2b9f49a65a0f770d040774d345ce", null ],
    [ "_slope", "classpappso_1_1LinearRegression.html#a7437a88639a2845d71b25e6c5cb706b9", null ]
];