var classpappso_1_1MzxmlOutput_1_1Translater =
[
    [ "Translater", "classpappso_1_1MzxmlOutput_1_1Translater.html#a7504e02e8bb7aca83d173f2f48f350bb", null ],
    [ "~Translater", "classpappso_1_1MzxmlOutput_1_1Translater.html#a71c7d987a5d5a47a0857ca7bac432b92", null ],
    [ "needPeakList", "classpappso_1_1MzxmlOutput_1_1Translater.html#adbe0c106756ce969c5d29bdaef431d4e", null ],
    [ "setQualifiedMassSpectrum", "classpappso_1_1MzxmlOutput_1_1Translater.html#afb7de5e6fbcd18530e4a9810c9ceb3f0", null ],
    [ "mp_output", "classpappso_1_1MzxmlOutput_1_1Translater.html#ad257c1de8582805b1a5dcaacb24aa5bf", null ]
];