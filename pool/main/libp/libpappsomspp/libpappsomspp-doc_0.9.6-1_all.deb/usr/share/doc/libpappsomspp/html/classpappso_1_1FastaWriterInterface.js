var classpappso_1_1FastaWriterInterface =
[
    [ "writeProtein", "classpappso_1_1FastaWriterInterface.html#ace714279e2756e442eee00ebc462f6c2", null ]
];