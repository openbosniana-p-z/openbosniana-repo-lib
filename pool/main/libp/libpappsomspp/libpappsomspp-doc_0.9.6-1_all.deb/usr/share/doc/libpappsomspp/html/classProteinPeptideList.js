var classProteinPeptideList =
[
    [ "ProteinPeptideList", "classProteinPeptideList.html#a618c84703abf1af5be579b495cf2d274", null ],
    [ "~ProteinPeptideList", "classProteinPeptideList.html#a6b8864b06e4e8cd94ec16489db8379f3", null ]
];