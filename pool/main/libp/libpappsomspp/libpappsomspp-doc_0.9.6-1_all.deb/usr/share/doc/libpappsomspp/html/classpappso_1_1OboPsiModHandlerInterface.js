var classpappso_1_1OboPsiModHandlerInterface =
[
    [ "setOboPsiModTerm", "classpappso_1_1OboPsiModHandlerInterface.html#afc0796cfbabb8f04bf988f12216582a7", null ]
];