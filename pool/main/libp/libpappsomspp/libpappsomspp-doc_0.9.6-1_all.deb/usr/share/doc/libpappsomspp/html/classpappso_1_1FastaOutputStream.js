var classpappso_1_1FastaOutputStream =
[
    [ "FastaOutputStream", "classpappso_1_1FastaOutputStream.html#a0ed677e98cd6334a7914d7b223d10678", null ],
    [ "~FastaOutputStream", "classpappso_1_1FastaOutputStream.html#a36e0b8153373791f4118a0af33ef6530", null ],
    [ "writeProtein", "classpappso_1_1FastaOutputStream.html#aa9f99b9767eab1dd9e6b7b0ccdba77e9", null ],
    [ "m_ofastastream", "classpappso_1_1FastaOutputStream.html#ab53aee24741af052581aa98d1661b465", null ]
];