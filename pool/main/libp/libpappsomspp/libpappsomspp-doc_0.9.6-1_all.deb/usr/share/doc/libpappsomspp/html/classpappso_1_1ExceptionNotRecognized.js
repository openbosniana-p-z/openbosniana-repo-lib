var classpappso_1_1ExceptionNotRecognized =
[
    [ "ExceptionNotRecognized", "classpappso_1_1ExceptionNotRecognized.html#a9f185ac7b69e267a477499b47fea8dde", null ],
    [ "clone", "classpappso_1_1ExceptionNotRecognized.html#a21490e4b61754521df19aa972b230ac6", null ]
];