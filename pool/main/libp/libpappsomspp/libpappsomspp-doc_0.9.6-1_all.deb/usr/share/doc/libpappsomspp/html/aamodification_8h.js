var aamodification_8h =
[
    [ "pappso::AaModification", "classpappso_1_1AaModification.html", "classpappso_1_1AaModification" ],
    [ "AaModificationP", "aamodification_8h.html#a6667b884cdc0a569198c8746cd587878", null ],
    [ "AaModificationUp", "aamodification_8h.html#ae0ee432a661c752968c76e81d216200c", null ],
    [ "PeptideSp", "aamodification_8h.html#a4ce6dddf6b323285a7c8bd3559e0cf5f", null ]
];