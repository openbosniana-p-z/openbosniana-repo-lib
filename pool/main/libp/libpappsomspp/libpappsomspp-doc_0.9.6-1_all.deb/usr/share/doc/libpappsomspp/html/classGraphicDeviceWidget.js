var classGraphicDeviceWidget =
[
    [ "GraphicDeviceWidget", "classGraphicDeviceWidget.html#a48695aaaf8903cbeb29ae37ed6d6d070", null ],
    [ "~GraphicDeviceWidget", "classGraphicDeviceWidget.html#a6e92dc2ddd41c131df1f9339534b5b21", null ],
    [ "toQPaintDevice", "classGraphicDeviceWidget.html#a082e166ee815a6db127a28bb6072de31", null ],
    [ "toSvgFile", "classGraphicDeviceWidget.html#a28f360d7f56c9c1a4a4a909592a39991", null ]
];