var classpappso_1_1MsRunSlice =
[
    [ "MsRunSlice", "classpappso_1_1MsRunSlice.html#a64bf9b5126e3363fd00961243d0b0232", null ],
    [ "MsRunSlice", "classpappso_1_1MsRunSlice.html#a6f38098e8749a8650efbfe62293a679e", null ],
    [ "~MsRunSlice", "classpappso_1_1MsRunSlice.html#a26d542f1bf5a1ecdda371d76f8ae43bf", null ],
    [ "appendToStream", "classpappso_1_1MsRunSlice.html#aa3b111f8ebf612132ec474e82bedd01a", null ],
    [ "clear", "classpappso_1_1MsRunSlice.html#ae0310dcc6c27b269c93ac114ae73f0d1", null ],
    [ "getSliceNumber", "classpappso_1_1MsRunSlice.html#ae52cc0d1d08d1dbe1159e00bf07050f6", null ],
    [ "getSpectrum", "classpappso_1_1MsRunSlice.html#a2d22e8fd7c6d4632234403e19b0df4da", null ],
    [ "getSpectrum", "classpappso_1_1MsRunSlice.html#a1baeb6b74424b7c9226cac2c5c958181", null ],
    [ "makeMsRunSliceSp", "classpappso_1_1MsRunSlice.html#a6a5964def6c1946d1816038a2acb0320", null ],
    [ "setSize", "classpappso_1_1MsRunSlice.html#ae614dbffd633f32b7a0701c4e2250f41", null ],
    [ "setSliceNumber", "classpappso_1_1MsRunSlice.html#a8ac58e342b1831aa2a8ef509cba3a49d", null ],
    [ "setSpectrum", "classpappso_1_1MsRunSlice.html#a7cbde62e7e32c33ed35e8c13e60d5730", null ],
    [ "size", "classpappso_1_1MsRunSlice.html#af73fe9e7905462c8c2120caf273f4df7", null ],
    [ "m_sliceNumber", "classpappso_1_1MsRunSlice.html#a5e3ce41490b5d624d75732db563f8ecd", null ],
    [ "m_spectrumList", "classpappso_1_1MsRunSlice.html#afd4dc7af9cd0e554cb7927190b72a7b0", null ]
];