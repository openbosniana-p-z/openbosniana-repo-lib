var classpappso_1_1FilterRoundY =
[
    [ "FilterRoundY", "classpappso_1_1FilterRoundY.html#adf308a35c42c9603f931d1d57cdd1e0c", null ],
    [ "FilterRoundY", "classpappso_1_1FilterRoundY.html#a28a3e1d613a7fd18196bf2448248c8f6", null ],
    [ "~FilterRoundY", "classpappso_1_1FilterRoundY.html#a15336ecad96d467f2b43b03edbc7d4e1", null ],
    [ "filter", "classpappso_1_1FilterRoundY.html#a0360f1e30c88c18d3ccedf4b709d74b0", null ],
    [ "operator=", "classpappso_1_1FilterRoundY.html#a5164c4882d4b98c0b5dfe664880a403f", null ]
];