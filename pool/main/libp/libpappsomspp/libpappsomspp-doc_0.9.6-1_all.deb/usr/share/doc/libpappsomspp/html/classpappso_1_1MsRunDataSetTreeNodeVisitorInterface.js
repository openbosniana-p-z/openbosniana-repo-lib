var classpappso_1_1MsRunDataSetTreeNodeVisitorInterface =
[
    [ "setNodesToProcessCount", "classpappso_1_1MsRunDataSetTreeNodeVisitorInterface.html#a68280c5c7a9c605e692f018a0683e4d8", null ],
    [ "shouldStop", "classpappso_1_1MsRunDataSetTreeNodeVisitorInterface.html#a6726ec784b12f4b1c9a60f2bfb756e4e", null ],
    [ "visit", "classpappso_1_1MsRunDataSetTreeNodeVisitorInterface.html#a7c3fde2f5759ca9edaa97197550c762a", null ]
];