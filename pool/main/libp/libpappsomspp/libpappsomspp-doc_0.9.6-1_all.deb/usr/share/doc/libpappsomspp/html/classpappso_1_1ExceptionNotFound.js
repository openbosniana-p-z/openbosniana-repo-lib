var classpappso_1_1ExceptionNotFound =
[
    [ "ExceptionNotFound", "classpappso_1_1ExceptionNotFound.html#aab44a4d746dab7ce2fff56cc2f08f72a", null ],
    [ "clone", "classpappso_1_1ExceptionNotFound.html#a6bdfc045a0fa1ed21441fbfa4c62c285", null ]
];