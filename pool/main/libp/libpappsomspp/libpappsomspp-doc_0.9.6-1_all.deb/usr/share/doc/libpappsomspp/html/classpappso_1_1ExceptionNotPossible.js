var classpappso_1_1ExceptionNotPossible =
[
    [ "ExceptionNotPossible", "classpappso_1_1ExceptionNotPossible.html#a53707fa150f5b4bbaaf2db8f0f491754", null ],
    [ "clone", "classpappso_1_1ExceptionNotPossible.html#a01f02b471b7e7ac59a3a1a10280245c3", null ]
];