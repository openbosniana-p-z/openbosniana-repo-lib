var classpappso_1_1MzxmlOutput =
[
    [ "Translater", "classpappso_1_1MzxmlOutput_1_1Translater.html", "classpappso_1_1MzxmlOutput_1_1Translater" ],
    [ "MzxmlOutput", "classpappso_1_1MzxmlOutput.html#a07c53a08336f9c831ec5c4e0164869ea", null ],
    [ "~MzxmlOutput", "classpappso_1_1MzxmlOutput.html#a744ca2bd9bab272fb53a23969f8cd623", null ],
    [ "close", "classpappso_1_1MzxmlOutput.html#a49523e07bb79cd806c37dd60f8a70e2c", null ],
    [ "getPrecursorScanNumber", "classpappso_1_1MzxmlOutput.html#ada57a793610d24d20ad05adc3348d999", null ],
    [ "getScanNumber", "classpappso_1_1MzxmlOutput.html#a9700fc2bb33a889203823888d6f28a6b", null ],
    [ "getScanNumberFromNativeId", "classpappso_1_1MzxmlOutput.html#a07c4f11c7d651484a98befa1f64427aa", null ],
    [ "maskMs1", "classpappso_1_1MzxmlOutput.html#ad386cb61cbff902ec9368214e57766c3", null ],
    [ "setReadAhead", "classpappso_1_1MzxmlOutput.html#a03a34387e0d0f1afeeb7054e7992a3e4", null ],
    [ "write", "classpappso_1_1MzxmlOutput.html#a311a481eeb345228257c1addcb05d326", null ],
    [ "writeHeader", "classpappso_1_1MzxmlOutput.html#aec512782e9c83f440163daa6e8489fca", null ],
    [ "writeQualifiedMassSpectrum", "classpappso_1_1MzxmlOutput.html#acdc9527a449a1e1f293aad669d1612b2", null ],
    [ "m_isReadAhead", "classpappso_1_1MzxmlOutput.html#a724061806cd1733d41c99a1d240e80d3", null ],
    [ "m_monitor", "classpappso_1_1MzxmlOutput.html#a7062dca74116ac82b49989f2304d8ea8", null ],
    [ "m_ms1IsMasked", "classpappso_1_1MzxmlOutput.html#a3bf0f98377df522dc4beacf16073b187", null ],
    [ "mpa_outputStream", "classpappso_1_1MzxmlOutput.html#aa72b33135c03fa26fab3ca4c090184c0", null ]
];