var classpappso_1_1FilterMorphoSum =
[
    [ "FilterMorphoSum", "classpappso_1_1FilterMorphoSum.html#a8f540ec4d5538563cf0b8187f3f3ef20", null ],
    [ "FilterMorphoSum", "classpappso_1_1FilterMorphoSum.html#a0fe47d62d182572a635615cddfff19b8", null ],
    [ "~FilterMorphoSum", "classpappso_1_1FilterMorphoSum.html#a112e1c3cb8890beb7c62f5152fc95fe1", null ],
    [ "getWindowValue", "classpappso_1_1FilterMorphoSum.html#acc072c6d5b45993464cec46168d68ddc", null ],
    [ "operator=", "classpappso_1_1FilterMorphoSum.html#a47f7b13cfd0df994c58ea2992c7edc98", null ]
];