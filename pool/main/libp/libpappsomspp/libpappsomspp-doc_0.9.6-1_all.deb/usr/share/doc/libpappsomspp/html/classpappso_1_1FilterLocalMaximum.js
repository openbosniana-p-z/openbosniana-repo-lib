var classpappso_1_1FilterLocalMaximum =
[
    [ "FilterLocalMaximum", "classpappso_1_1FilterLocalMaximum.html#ab64c60744ba78ce33a12f3741b10f3c9", null ],
    [ "FilterLocalMaximum", "classpappso_1_1FilterLocalMaximum.html#aa82920cd4ac8f637753cad1bd8a8e6ac", null ],
    [ "~FilterLocalMaximum", "classpappso_1_1FilterLocalMaximum.html#a69f9772de718d54c52cf1656fd05518e", null ],
    [ "filter", "classpappso_1_1FilterLocalMaximum.html#a2a15ae47362c3d3a94b9d97e70a82c31", null ],
    [ "getHalfWindowSize", "classpappso_1_1FilterLocalMaximum.html#a18a85ebf2f674e7feba48ff01b0e8744", null ],
    [ "m_halfWindowSize", "classpappso_1_1FilterLocalMaximum.html#a7cf80922e5bd8c60745fef34e5381146", null ]
];