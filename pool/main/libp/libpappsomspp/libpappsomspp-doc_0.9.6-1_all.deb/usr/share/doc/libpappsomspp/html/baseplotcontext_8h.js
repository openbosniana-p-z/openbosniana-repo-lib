var baseplotcontext_8h =
[
    [ "pappso::BasePlotContext", "classpappso_1_1BasePlotContext.html", "classpappso_1_1BasePlotContext" ],
    [ "DragDirections", "baseplotcontext_8h.html#aa5a26073a7a64056a3ad72375c1f2b94", [
      [ "NOT_SET", "baseplotcontext_8h.html#aa5a26073a7a64056a3ad72375c1f2b94a1c250a21210b7b88a14db9a0cbe71162", null ],
      [ "LEFT_TO_RIGHT", "baseplotcontext_8h.html#aa5a26073a7a64056a3ad72375c1f2b94a3ba9c296d0eb2686b837d4f10e27243b", null ],
      [ "RIGHT_TO_LEFT", "baseplotcontext_8h.html#aa5a26073a7a64056a3ad72375c1f2b94a132e23a80cef8d694ea55b6e790b9e4a", null ],
      [ "TOP_TO_BOTTOM", "baseplotcontext_8h.html#aa5a26073a7a64056a3ad72375c1f2b94a99330b5426599e4d48e0f69ca4089fc1", null ],
      [ "BOTTOM_TO_TOP", "baseplotcontext_8h.html#aa5a26073a7a64056a3ad72375c1f2b94a74db93190a9be48683571425f41c12c8", null ]
    ] ]
];