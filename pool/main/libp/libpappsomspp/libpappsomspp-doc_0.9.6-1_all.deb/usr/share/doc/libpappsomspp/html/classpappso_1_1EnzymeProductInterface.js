var classpappso_1_1EnzymeProductInterface =
[
    [ "setPeptide", "classpappso_1_1EnzymeProductInterface.html#a62425d6db461f89f1349280f3796bba7", null ]
];