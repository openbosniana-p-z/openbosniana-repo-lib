var classpappso_1_1FilterGreatestYperWindow =
[
    [ "FilterGreatestYperWindow", "classpappso_1_1FilterGreatestYperWindow.html#a8649edb828af0dc9257096275356f909", null ],
    [ "FilterGreatestYperWindow", "classpappso_1_1FilterGreatestYperWindow.html#a281bb1d6e01767832b2cfb27814e6a36", null ],
    [ "~FilterGreatestYperWindow", "classpappso_1_1FilterGreatestYperWindow.html#a79e66ef9f5eb3f604255670749d46fdd", null ],
    [ "filter", "classpappso_1_1FilterGreatestYperWindow.html#a2d6d2ba10b053a66bba55c66214fe7ec", null ],
    [ "getNumberOfPoints", "classpappso_1_1FilterGreatestYperWindow.html#af81418483c1d7493c772315d8e322a4e", null ],
    [ "operator=", "classpappso_1_1FilterGreatestYperWindow.html#aa54f0ef354930d8627641df96b78038a", null ],
    [ "m_numberOfPoints", "classpappso_1_1FilterGreatestYperWindow.html#a300ce3f38af125bfe4ba9e9125c8950d", null ],
    [ "m_xWindowRange", "classpappso_1_1FilterGreatestYperWindow.html#acd38c01d5eb5222b0d59000100c8e2ba", null ]
];