var classpappso_1_1AtomNumberInterface =
[
    [ "getNumberOfAtom", "classpappso_1_1AtomNumberInterface.html#afe436385b56ae48e9c8e4b1602bd69f9", null ],
    [ "getNumberOfIsotope", "classpappso_1_1AtomNumberInterface.html#a5e72cc6561f9a4230366f940a3cdeca7", null ]
];