var classpappso_1_1Ion =
[
    [ "Ion", "classpappso_1_1Ion.html#aa2bf61e34d90d75bfcced745e2faca07", null ],
    [ "~Ion", "classpappso_1_1Ion.html#a785985f562ac73e7aefe51e358ad874b", null ],
    [ "getMass", "classpappso_1_1Ion.html#a26cf490d37d63e0bacf6e1aed1c75c76", null ],
    [ "getMz", "classpappso_1_1Ion.html#ad9727ef9629b1340e2640ad52e084cac", null ]
];