var baseplotwidget_8cpp =
[
    [ "basePlotContextMetaTypeId", "baseplotwidget_8cpp.html#adcafa991f7cb44840c6c16f41997da06", null ],
    [ "basePlotContextPtrMetaTypeId", "baseplotwidget_8cpp.html#a6814100bc7d5b293be0c8f183b66bede", null ]
];