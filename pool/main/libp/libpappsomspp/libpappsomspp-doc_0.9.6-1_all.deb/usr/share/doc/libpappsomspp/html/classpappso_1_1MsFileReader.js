var classpappso_1_1MsFileReader =
[
    [ "MsFileReader", "classpappso_1_1MsFileReader.html#a829f3744555e120badf9a9c471521cd1", null ],
    [ "~MsFileReader", "classpappso_1_1MsFileReader.html#a7f7f7b1cecbc838e981367568cfc1311", null ],
    [ "getFileFormat", "classpappso_1_1MsFileReader.html#a8dbe4f4536b1fdfea13d596e263b5361", null ],
    [ "getMsRunIds", "classpappso_1_1MsFileReader.html#aafa870b40aa29d0c1fd7ba9571902e3a", null ],
    [ "m_fileFormat", "classpappso_1_1MsFileReader.html#a0ceb92e45afad15dd3810cd67738603f", null ],
    [ "m_fileName", "classpappso_1_1MsFileReader.html#adce21bac3a431b48de0ac0c91eab3c1a", null ]
];