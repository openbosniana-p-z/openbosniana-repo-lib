var classpappso_1_1MsRunSimpleStatistics =
[
    [ "getMsLevelCount", "classpappso_1_1MsRunSimpleStatistics.html#ab614769555f8618fb4e4f1688f337841", null ],
    [ "getTotalCount", "classpappso_1_1MsRunSimpleStatistics.html#a25bb3ee06004b6da2152643c0b18132a", null ],
    [ "loadingEnded", "classpappso_1_1MsRunSimpleStatistics.html#a273d6b2dd97efb84a29cf0f5c65dcec7", null ],
    [ "needPeakList", "classpappso_1_1MsRunSimpleStatistics.html#a5f63c787089601b3884054a121ffed9f", null ],
    [ "setQualifiedMassSpectrum", "classpappso_1_1MsRunSimpleStatistics.html#a0cae8c2ffec42415a4c78818478672ac", null ],
    [ "m_countMsLevelSpectrum", "classpappso_1_1MsRunSimpleStatistics.html#a35d9262f34937af8f078e52bb5f43730", null ]
];