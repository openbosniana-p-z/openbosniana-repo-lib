var classpappso_1_1DeepProtEnumStr =
[
    [ "DeepProtMatchTypeFromString", "classpappso_1_1DeepProtEnumStr.html#a6a966f8727bbef700650207e7a0fbe89", null ],
    [ "DeepProtPeptideCandidateStatusFromString", "classpappso_1_1DeepProtEnumStr.html#a910f3a241e714b40dca51aa593a32a55", null ],
    [ "toString", "classpappso_1_1DeepProtEnumStr.html#a160a0ecb48e1474eb6599d92853a4fd2", null ],
    [ "toString", "classpappso_1_1DeepProtEnumStr.html#a4c788d597e8b04fbbecb7d45e3404683", null ]
];