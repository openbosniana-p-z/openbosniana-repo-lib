var classpappso_1_1IonMobilityGrid =
[
    [ "IonMobilityGrid", "classpappso_1_1IonMobilityGrid.html#aba33fd64704b2173f5fa4d602e9a2631", null ],
    [ "~IonMobilityGrid", "classpappso_1_1IonMobilityGrid.html#af8cf2d4dbcc4148ea80fedda7fd15102", null ],
    [ "computeCorrections", "classpappso_1_1IonMobilityGrid.html#aacd75c7b20efc1d72bb8e5e83e95e7f7", null ],
    [ "getMapCorrectionsStart", "classpappso_1_1IonMobilityGrid.html#a4282a2cb84bbb54ddda3a01a8c42ec34", null ],
    [ "getMapDiferrencesStart", "classpappso_1_1IonMobilityGrid.html#acb450a353c14a20572882c5922a9e48c", null ],
    [ "storeObservedIdentityBetween", "classpappso_1_1IonMobilityGrid.html#ac523160fc42e20f82c77926ea9ac4756", null ],
    [ "translateXicCoordFromTo", "classpappso_1_1IonMobilityGrid.html#a6ad2c9a04842cde8d92f70b695ef41a9", null ],
    [ "m_mapCorrectionsStart", "classpappso_1_1IonMobilityGrid.html#a81228451036138ab12c077aa240910de", null ],
    [ "m_mapCorrectionsStop", "classpappso_1_1IonMobilityGrid.html#a0ec2637e9d359b6bfa3ec3ae0b18a618", null ],
    [ "m_mapDiferrencesStart", "classpappso_1_1IonMobilityGrid.html#a7cc693a7e6bf0a09f272ac58540aa06a", null ],
    [ "m_mapDiferrencesStop", "classpappso_1_1IonMobilityGrid.html#adfc979d3469554c33557d7e287cea09c", null ]
];