var classpappso_1_1MassSpectrumFilterInterface =
[
    [ "~MassSpectrumFilterInterface", "classpappso_1_1MassSpectrumFilterInterface.html#a2ca15351a406695733bcd9186b5eceb6", null ],
    [ "filter", "classpappso_1_1MassSpectrumFilterInterface.html#a3d86e704c61b633fc97eeac2bf9ae4a7", null ]
];