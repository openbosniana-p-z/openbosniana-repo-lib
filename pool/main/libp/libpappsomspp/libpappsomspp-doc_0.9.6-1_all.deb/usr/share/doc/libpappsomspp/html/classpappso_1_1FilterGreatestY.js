var classpappso_1_1FilterGreatestY =
[
    [ "FilterGreatestY", "classpappso_1_1FilterGreatestY.html#a6f16073fc072b98f7df2942c776999ff", null ],
    [ "FilterGreatestY", "classpappso_1_1FilterGreatestY.html#aaad434a7ef9a5d9a0d4a8239ecd89c3f", null ],
    [ "~FilterGreatestY", "classpappso_1_1FilterGreatestY.html#ab0d6c9df554cc5cd9d47f0d80275631f", null ],
    [ "filter", "classpappso_1_1FilterGreatestY.html#a3299ccb2754f1cf0d7c111d675b23dcd", null ],
    [ "getNumberOfPoints", "classpappso_1_1FilterGreatestY.html#a81f1b1c441ae47005d8d9fd6f981e131", null ],
    [ "operator=", "classpappso_1_1FilterGreatestY.html#a7d0a1151735ec8d79ad7c1c176012509", null ],
    [ "m_numberOfPoints", "classpappso_1_1FilterGreatestY.html#aa1610cc605683fa73672d877ebcf21d0", null ]
];