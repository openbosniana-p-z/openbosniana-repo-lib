var classpappso_1_1ExceptionNotImplemented =
[
    [ "ExceptionNotImplemented", "classpappso_1_1ExceptionNotImplemented.html#a42c95e5d6627de7aac2994fdb9e57221", null ],
    [ "clone", "classpappso_1_1ExceptionNotImplemented.html#ab5453609165c3f6549d422af0ebd3720", null ]
];