var classpappso_1_1OboChooserWidget =
[
    [ "OboChooserWidget", "classpappso_1_1OboChooserWidget.html#a6273f0520b5469994eee0c561987998c", null ],
    [ "~OboChooserWidget", "classpappso_1_1OboChooserWidget.html#ae81c09015b84393f72f9a18e7c35bbf9", null ],
    [ "getOboPsiModTermSelected", "classpappso_1_1OboChooserWidget.html#ae1442937853be7f992e5bf154fc39f4f", null ],
    [ "isOboTermSelected", "classpappso_1_1OboChooserWidget.html#aef9f968cc833d1d7aab8fdba330752b9", null ],
    [ "setMzTarget", "classpappso_1_1OboChooserWidget.html#a2177feedb021abab274e2ac4a1c8ae40", null ],
    [ "setPrecision", "classpappso_1_1OboChooserWidget.html#a07d337ab3df0bda8a9ac8500db20f3b1", null ],
    [ "ui", "classpappso_1_1OboChooserWidget.html#a18ae5b2c60de202787467a9ca15cea94", null ]
];