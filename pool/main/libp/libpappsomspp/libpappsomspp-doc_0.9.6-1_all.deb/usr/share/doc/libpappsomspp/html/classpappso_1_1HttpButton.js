var classpappso_1_1HttpButton =
[
    [ "HttpButton", "classpappso_1_1HttpButton.html#aaca4aa1de46b6cbfb894df198e629f97", null ],
    [ "~HttpButton", "classpappso_1_1HttpButton.html#ac03480fc09d5f937f07ef2f5253cd81d", null ],
    [ "getChEBIUrl", "classpappso_1_1HttpButton.html#a91d752016b4477cd50542c66ad34a6d4", null ],
    [ "getOlsUrl", "classpappso_1_1HttpButton.html#ad66bd222909159eb6d2473222116310d", null ],
    [ "getPubMedUrl", "classpappso_1_1HttpButton.html#ae88a93a3d564e9f20aa3a8ece5e67e4e", null ],
    [ "getRESIDUrl", "classpappso_1_1HttpButton.html#a6c6c7554178c62b15d2ec1b22fbea05c", null ],
    [ "getUnimodUrl", "classpappso_1_1HttpButton.html#a19d5ac1505755213ba8e6be49f928786", null ],
    [ "mousePressEvent", "classpappso_1_1HttpButton.html#a4bbdd5725d31d6c180a5c878bd20f0a8", null ],
    [ "setText", "classpappso_1_1HttpButton.html#a3ddbbb72bd0ac955641cf1a55b541e65", null ]
];