var classpappso_1_1GrpGroupingMonitorInterface =
[
    [ "~GrpGroupingMonitorInterface", "classpappso_1_1GrpGroupingMonitorInterface.html#ad4128dedbeadbc5ab818d198eee8582e", null ],
    [ "groupingProtein", "classpappso_1_1GrpGroupingMonitorInterface.html#ae7e94b2fea4fea63044a76b828f69216", null ],
    [ "removingNonInformativeSubGroupsInGroup", "classpappso_1_1GrpGroupingMonitorInterface.html#a0a58c17a3a3c5474ca3456c2ce9eb86c", null ],
    [ "startGrouping", "classpappso_1_1GrpGroupingMonitorInterface.html#aaf5e2aeb5b6030d9ca98a03e819f5bcb", null ],
    [ "startNumberingAllGroups", "classpappso_1_1GrpGroupingMonitorInterface.html#a185c699d627581ae34abf9b7fc3c8fb2", null ],
    [ "startRemovingNonInformativeSubGroupsInAllGroups", "classpappso_1_1GrpGroupingMonitorInterface.html#a5f1d9aacb46f4c62e9a2cb348923f9e9", null ],
    [ "stopGrouping", "classpappso_1_1GrpGroupingMonitorInterface.html#a910ce2afa7870e8f1dc91600c75aa744", null ],
    [ "stopRemovingNonInformativeSubGroupsInAllGroups", "classpappso_1_1GrpGroupingMonitorInterface.html#aec8604ae98cf09e1b931e64f9165650a", null ]
];