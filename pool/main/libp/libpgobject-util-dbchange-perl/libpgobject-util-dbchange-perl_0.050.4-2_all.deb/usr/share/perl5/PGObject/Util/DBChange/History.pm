# just returns a list of values
package PGObject::Util::DBChange::History;

use warnings;
use strict;

use PGObject::Util::DBChange;


sub get_changes { [] };

1;
