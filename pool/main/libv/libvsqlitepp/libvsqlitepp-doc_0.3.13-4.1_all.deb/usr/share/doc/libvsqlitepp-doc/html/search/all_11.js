var searchData=
[
  ['text_88',['text',['../namespacesqlite.html#a24df146a8eed4c7eb0378eed5d1b5700a1ab1e70476f59020c524a6bd6250a184',1,'sqlite']]],
  ['transaction_89',['transaction',['../structsqlite_1_1transaction.html',1,'sqlite::transaction'],['../structsqlite_1_1transaction.html#a5c6afe92f4d6da9ce6da97f48377b34c',1,'sqlite::transaction::transaction()']]],
  ['transaction_2ehpp_90',['transaction.hpp',['../transaction_8hpp.html',1,'']]],
  ['transaction_5ftype_91',['transaction_type',['../namespacesqlite.html#a2f22489cefe2822b93e5b3cd743cffc6',1,'sqlite']]],
  ['type_92',['type',['../namespacesqlite.html#a24df146a8eed4c7eb0378eed5d1b5700',1,'sqlite']]]
];
