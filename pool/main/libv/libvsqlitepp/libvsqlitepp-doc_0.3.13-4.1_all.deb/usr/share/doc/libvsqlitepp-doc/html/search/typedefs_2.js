var searchData=
[
  ['result_5ftype_215',['result_type',['../namespacesqlite.html#a003f065ca592f83d39c04f420345100b',1,'sqlite']]]
];
