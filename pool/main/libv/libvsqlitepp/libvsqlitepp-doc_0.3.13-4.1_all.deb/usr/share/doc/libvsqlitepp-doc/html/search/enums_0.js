var searchData=
[
  ['transaction_5ftype_217',['transaction_type',['../namespacesqlite.html#a2f22489cefe2822b93e5b3cd743cffc6',1,'sqlite']]],
  ['type_218',['type',['../namespacesqlite.html#a24df146a8eed4c7eb0378eed5d1b5700',1,'sqlite']]]
];
