var searchData=
[
  ['sqlite_124',['sqlite',['../namespacesqlite.html',1,'']]]
];
