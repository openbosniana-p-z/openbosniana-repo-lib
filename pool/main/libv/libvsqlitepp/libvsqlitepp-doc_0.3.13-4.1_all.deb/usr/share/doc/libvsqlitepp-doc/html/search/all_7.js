var searchData=
[
  ['handle_48',['handle',['../structsqlite_1_1connection.html#af6f210ec001c6b9be2c28937f84e5b8e',1,'sqlite::connection']]]
];
