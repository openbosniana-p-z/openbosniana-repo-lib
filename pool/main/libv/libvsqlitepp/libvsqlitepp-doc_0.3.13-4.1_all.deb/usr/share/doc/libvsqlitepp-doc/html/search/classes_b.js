var searchData=
[
  ['view_123',['view',['../structsqlite_1_1view.html',1,'sqlite']]]
];
