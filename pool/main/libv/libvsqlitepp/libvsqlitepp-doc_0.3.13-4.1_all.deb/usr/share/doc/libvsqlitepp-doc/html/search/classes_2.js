var searchData=
[
  ['database_5fexception_111',['database_exception',['../structsqlite_1_1database__exception.html',1,'sqlite']]],
  ['database_5fmisuse_5fexception_112',['database_misuse_exception',['../structsqlite_1_1database__misuse__exception.html',1,'sqlite']]]
];
