var searchData=
[
  ['query_117',['query',['../structsqlite_1_1query.html',1,'sqlite']]]
];
