var searchData=
[
  ['buffer_5ftoo_5fsmall_5fexception_108',['buffer_too_small_exception',['../structsqlite_1_1buffer__too__small__exception.html',1,'sqlite']]]
];
