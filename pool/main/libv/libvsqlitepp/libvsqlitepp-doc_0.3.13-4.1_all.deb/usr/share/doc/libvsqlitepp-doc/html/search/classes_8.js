var searchData=
[
  ['savepoint_120',['savepoint',['../structsqlite_1_1savepoint.html',1,'sqlite']]]
];
