var searchData=
[
  ['next_5frow_60',['next_row',['../structsqlite_1_1result.html#a323f438649d6a3f806bd5ec29b845995',1,'sqlite::result']]],
  ['nil_61',['nil',['../namespacesqlite.html#a19a7e7fc7013336c607c6bdf5a9ef50c',1,'sqlite']]],
  ['null_62',['null',['../namespacesqlite.html#a24df146a8eed4c7eb0378eed5d1b5700a560c243d0aea17a7787fef5ca613f162',1,'sqlite']]],
  ['null_5ft_63',['null_t',['../structsqlite_1_1null__t.html',1,'sqlite']]],
  ['null_5ftype_64',['null_type',['../structsqlite_1_1null__type.html',1,'sqlite']]]
];
