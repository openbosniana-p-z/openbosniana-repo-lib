var searchData=
[
  ['isactive_174',['isActive',['../structsqlite_1_1savepoint.html#acb518b89eb1d48d24790bbf7ba6eb185',1,'sqlite::savepoint::isActive()'],['../structsqlite_1_1transaction.html#a982aea95a08fc501bd6441bb27691236',1,'sqlite::transaction::isActive()']]]
];
