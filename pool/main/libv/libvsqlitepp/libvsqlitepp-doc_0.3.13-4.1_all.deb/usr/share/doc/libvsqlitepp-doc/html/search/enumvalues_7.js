var searchData=
[
  ['undefined_227',['undefined',['../namespacesqlite.html#a2f22489cefe2822b93e5b3cd743cffc6a5e543256c480ac577d30f76f9120eb74',1,'sqlite']]],
  ['unknown_228',['unknown',['../namespacesqlite.html#a24df146a8eed4c7eb0378eed5d1b5700ab5fdd5b8df675cf89fab9dcd71b37eb1',1,'sqlite']]]
];
