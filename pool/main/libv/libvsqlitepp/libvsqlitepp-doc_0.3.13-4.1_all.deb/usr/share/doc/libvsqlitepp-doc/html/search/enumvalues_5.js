var searchData=
[
  ['real_225',['real',['../namespacesqlite.html#a24df146a8eed4c7eb0378eed5d1b5700a55ad5f8e3c01ab3b8a911fc88f3dbe00',1,'sqlite']]]
];
