var searchData=
[
  ['database_5fexception_149',['database_exception',['../structsqlite_1_1database__exception.html#ad955066a586109e40f5a51947c8eecd3',1,'sqlite::database_exception']]],
  ['database_5fmisuse_5fexception_150',['database_misuse_exception',['../structsqlite_1_1database__misuse__exception.html#ae4ffae6633e4171efca6cd11b8912172',1,'sqlite::database_misuse_exception']]],
  ['detach_151',['detach',['../structsqlite_1_1connection.html#a70c6b8f37146b2266cc289b0cfcfcd7a',1,'sqlite::connection']]],
  ['drop_152',['drop',['../structsqlite_1_1view.html#a1c04a78431a1b5a73f99653a1001c955',1,'sqlite::view::drop(std::string const &amp;alias)'],['../structsqlite_1_1view.html#a57c0edce911ba52a43f8e91f87828624',1,'sqlite::view::drop(std::string const &amp;database, std::string const &amp;alias)']]]
];
