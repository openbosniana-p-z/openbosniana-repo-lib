var searchData=
[
  ['real_73',['real',['../namespacesqlite.html#a24df146a8eed4c7eb0378eed5d1b5700a55ad5f8e3c01ab3b8a911fc88f3dbe00',1,'sqlite']]],
  ['release_74',['release',['../structsqlite_1_1savepoint.html#a2fb0684eca3fce967d094a7e1bc7293c',1,'sqlite::savepoint']]],
  ['result_75',['result',['../structsqlite_1_1result.html',1,'sqlite::result'],['../structsqlite_1_1query.html#a1ae01d651e848b2e1ec52caf46bcec38',1,'sqlite::query::result()'],['../structsqlite_1_1result.html#a60ee286f4138b369ad4f66c2b5e36d68',1,'sqlite::result::result()']]],
  ['result_2ehpp_76',['result.hpp',['../result_8hpp.html',1,'']]],
  ['result_5fconstruct_5fparams_5fprivate_77',['result_construct_params_private',['../structsqlite_1_1result__construct__params__private.html',1,'sqlite']]],
  ['result_5fconstruct_5fparams_5fprivate_2ehpp_78',['result_construct_params_private.hpp',['../result__construct__params__private_8hpp.html',1,'']]],
  ['result_5ftype_79',['result_type',['../namespacesqlite.html#a003f065ca592f83d39c04f420345100b',1,'sqlite']]],
  ['rollback_80',['rollback',['../structsqlite_1_1savepoint.html#a680c6d2c960d8494b657a1c3270780af',1,'sqlite::savepoint::rollback()'],['../structsqlite_1_1transaction.html#aad553ed20d28813b77342dd7a72e6618',1,'sqlite::transaction::rollback()']]],
  ['row_5fcount_81',['row_count',['../structsqlite_1_1result__construct__params__private.html#ab82b08c8df020c0c1f750d57ec5e54de',1,'sqlite::result_construct_params_private']]]
];
