var searchData=
[
  ['begin_3',['begin',['../structsqlite_1_1transaction.html#a9d70151fbc58b2ccd495b985ffe00ecc',1,'sqlite::transaction']]],
  ['bind_4',['bind',['../structsqlite_1_1command.html#a09a49212b0c0b760035f160e3eb4ed63',1,'sqlite::command::bind(int idx)'],['../structsqlite_1_1command.html#a6cca51b28db12ae910b529b0c47b196d',1,'sqlite::command::bind(int idx, int v)'],['../structsqlite_1_1command.html#a689f675f36e0434031d5c404d49d48bc',1,'sqlite::command::bind(int idx, boost::int64_t v)'],['../structsqlite_1_1command.html#a1a9a2ec75af89ad25dfea3e53f8ee3f6',1,'sqlite::command::bind(int idx, double v)'],['../structsqlite_1_1command.html#ad62b405d3482e6e3d943a6314f088fd8',1,'sqlite::command::bind(int idx, std::string const &amp;v)'],['../structsqlite_1_1command.html#a07656657dcbba77da862c88073ea16a9',1,'sqlite::command::bind(int idx, void const *buf, size_t buf_size)'],['../structsqlite_1_1command.html#a77d5ea1040b34eb46e2d3a93294514b9',1,'sqlite::command::bind(int idx, std::vector&lt; unsigned char &gt; const &amp;v)']]],
  ['blob_5',['blob',['../namespacesqlite.html#a24df146a8eed4c7eb0378eed5d1b5700a4dcb69cd3bd9945ae70f33bb6ffd3807',1,'sqlite']]],
  ['blob_5fref_5ft_6',['blob_ref_t',['../namespacesqlite.html#afc72b0006a971ab4acc286a9646eaec7',1,'sqlite']]],
  ['blob_5ft_7',['blob_t',['../namespacesqlite.html#a3cfe00bbdca6df265ec7028e84aa64ec',1,'sqlite']]],
  ['buffer_5ftoo_5fsmall_5fexception_8',['buffer_too_small_exception',['../structsqlite_1_1buffer__too__small__exception.html',1,'sqlite::buffer_too_small_exception'],['../structsqlite_1_1buffer__too__small__exception.html#abcaa5ecf126011f23d68259e2788bd8c',1,'sqlite::buffer_too_small_exception::buffer_too_small_exception()']]]
];
