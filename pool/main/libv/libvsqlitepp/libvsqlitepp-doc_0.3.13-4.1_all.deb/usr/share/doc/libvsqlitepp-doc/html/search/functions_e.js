var searchData=
[
  ['transaction_186',['transaction',['../structsqlite_1_1transaction.html#a5c6afe92f4d6da9ce6da97f48377b34c',1,'sqlite::transaction']]]
];
