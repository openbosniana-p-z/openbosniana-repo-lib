var searchData=
[
  ['finalize_32',['finalize',['../structsqlite_1_1command.html#a0f6ee7ea384ed0a49a00d52c4cf74ca9',1,'sqlite::command']]]
];
