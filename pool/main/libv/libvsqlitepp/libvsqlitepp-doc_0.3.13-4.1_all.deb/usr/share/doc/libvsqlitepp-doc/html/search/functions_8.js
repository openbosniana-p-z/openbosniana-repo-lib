var searchData=
[
  ['next_5frow_175',['next_row',['../structsqlite_1_1result.html#a323f438649d6a3f806bd5ec29b845995',1,'sqlite::result']]]
];
