var searchData=
[
  ['result_231',['result',['../structsqlite_1_1query.html#a1ae01d651e848b2e1ec52caf46bcec38',1,'sqlite::query']]]
];
