var searchData=
[
  ['query_2ehpp_130',['query.hpp',['../query_8hpp.html',1,'']]]
];
