var searchData=
[
  ['text_226',['text',['../namespacesqlite.html#a24df146a8eed4c7eb0378eed5d1b5700a1ab1e70476f59020c524a6bd6250a184',1,'sqlite']]]
];
