var searchData=
[
  ['release_181',['release',['../structsqlite_1_1savepoint.html#a2fb0684eca3fce967d094a7e1bc7293c',1,'sqlite::savepoint']]],
  ['result_182',['result',['../structsqlite_1_1result.html#a60ee286f4138b369ad4f66c2b5e36d68',1,'sqlite::result']]],
  ['rollback_183',['rollback',['../structsqlite_1_1savepoint.html#a680c6d2c960d8494b657a1c3270780af',1,'sqlite::savepoint::rollback()'],['../structsqlite_1_1transaction.html#aad553ed20d28813b77342dd7a72e6618',1,'sqlite::transaction::rollback()']]]
];
