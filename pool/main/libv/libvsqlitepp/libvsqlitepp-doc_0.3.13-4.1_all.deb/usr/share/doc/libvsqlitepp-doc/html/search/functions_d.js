var searchData=
[
  ['savepoint_184',['savepoint',['../structsqlite_1_1savepoint.html#af03144d27215df297527dd68266302a4',1,'sqlite::savepoint']]],
  ['step_185',['step',['../structsqlite_1_1command.html#a4d37a70ff3a1d7d8f3b689fc09501e89',1,'sqlite::command::step()'],['../structsqlite_1_1query.html#a851a6d78f5119e6aac47ce9bcc126914',1,'sqlite::query::step()']]]
];
