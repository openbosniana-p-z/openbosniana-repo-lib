var searchData=
[
  ['blob_5fref_5ft_212',['blob_ref_t',['../namespacesqlite.html#afc72b0006a971ab4acc286a9646eaec7',1,'sqlite']]],
  ['blob_5ft_213',['blob_t',['../namespacesqlite.html#a3cfe00bbdca6df265ec7028e84aa64ec',1,'sqlite']]]
];
