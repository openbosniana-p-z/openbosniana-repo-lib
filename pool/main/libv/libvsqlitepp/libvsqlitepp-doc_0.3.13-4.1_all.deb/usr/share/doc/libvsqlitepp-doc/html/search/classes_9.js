var searchData=
[
  ['transaction_121',['transaction',['../structsqlite_1_1transaction.html',1,'sqlite']]]
];
