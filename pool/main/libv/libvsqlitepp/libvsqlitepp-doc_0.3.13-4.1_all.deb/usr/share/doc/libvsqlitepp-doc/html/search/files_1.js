var searchData=
[
  ['database_5fexception_2ehpp_127',['database_exception.hpp',['../database__exception_8hpp.html',1,'']]]
];
