# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.1.x   | :white_check_mark: |

## Reporting a Vulnerability

Please send report privately to evpobry@gmail.com, and include how would you like to be credited.
