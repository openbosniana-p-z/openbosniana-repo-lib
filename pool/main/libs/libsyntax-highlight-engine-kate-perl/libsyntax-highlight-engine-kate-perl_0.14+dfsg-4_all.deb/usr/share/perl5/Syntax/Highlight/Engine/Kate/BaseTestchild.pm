package Syntax::Highlight::Engine::Kate::BaseTestchild;

our $VERSION = '0.14';

use strict;
use warnings;

# stub, just to get indexed by PAUSE and hide old version of this file from CPAN smokers.

1;
