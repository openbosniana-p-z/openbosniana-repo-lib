// dummy prefix file, used for CW based projects which do
// not need the prefix file here, but in the target settings

#ifdef _MSC_VER
#error "this is not the right prefix_file.h -> reorder include paths such that project-specific prefix is used!"
#endif

#ifdef __PALM_OS__
#error "this is not the right prefix_file.h -> reorder access paths such that project-specific prefix is used!"
#endif

