package SOAP::WSDL::XSD::Typelib::Builtin::NCName;
use strict;
use warnings;
use Class::Std::Fast::Storable constructor => 'none', cache => 1;
use base qw(SOAP::WSDL::XSD::Typelib::Builtin::Name);
Class::Std::initialize();
1;
