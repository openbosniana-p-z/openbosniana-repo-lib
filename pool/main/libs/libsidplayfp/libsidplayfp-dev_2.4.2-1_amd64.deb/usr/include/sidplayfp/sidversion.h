#ifndef LIBSIDPLAYFP_VERSION_H
#define LIBSIDPLAYFP_VERSION_H

#ifndef SIDPLAYFP_H
#  error Do not include directly.
#endif



#define LIBSIDPLAYFP_VERSION_MAJ 2
#define LIBSIDPLAYFP_VERSION_MIN 4
#define LIBSIDPLAYFP_VERSION_LEV 2

#endif
