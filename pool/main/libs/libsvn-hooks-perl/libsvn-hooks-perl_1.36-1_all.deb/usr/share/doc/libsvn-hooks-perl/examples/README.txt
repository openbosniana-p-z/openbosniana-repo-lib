The files in this directory contain snippets that may be useful. You
can just copy them to your svn-hooks.conf file and adapt them to your
needs.

