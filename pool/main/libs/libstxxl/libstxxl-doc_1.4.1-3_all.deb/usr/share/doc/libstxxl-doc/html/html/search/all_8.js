var searchData=
[
  ['logging_20macros_20stxxl_5fmsg',['Logging Macros STXXL_MSG',['../common_logging.html',1,'common']]],
  ['license_5f1_5f0_2etxt',['LICENSE_1_0.txt',['../license.html',1,'textfiles']]]
];
