var searchData=
[
  ['design_20of_20stxxl',['Design of STXXL',['../design.html',1,'index']]],
  ['deque',['Deque',['../design_deque.html',1,'design_stl_containers']]],
  ['disk_20configuration_20files',['Disk Configuration Files',['../install_config.html',1,'install']]]
];
