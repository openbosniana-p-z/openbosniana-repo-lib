var searchData=
[
  ['vector',['Vector',['../design_vector.html',1,'design_stl_containers']]]
];
