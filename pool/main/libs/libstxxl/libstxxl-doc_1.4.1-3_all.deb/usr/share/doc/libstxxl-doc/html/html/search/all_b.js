var searchData=
[
  ['parallel_20disk_20sorting',['Parallel Disk Sorting',['../design_algo_sorting.html',1,'design_stl_algo']]],
  ['priority_20queue',['Priority Queue',['../design_pqueue.html',1,'design_stl_containers']]]
];
