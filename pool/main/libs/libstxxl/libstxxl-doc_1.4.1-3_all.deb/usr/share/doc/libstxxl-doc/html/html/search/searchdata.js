var indexSectionsWithContent =
{
  0: "abcdefgilmopqrstuvw",
  1: "bcis",
  2: "acdefgilmopqrstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "groups",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Modules",
  2: "Pages"
};

