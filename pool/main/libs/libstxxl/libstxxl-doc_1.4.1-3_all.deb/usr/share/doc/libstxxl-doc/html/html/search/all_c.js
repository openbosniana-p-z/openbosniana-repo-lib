var searchData=
[
  ['queue',['Queue',['../design_queue.html',1,'design_stl_containers']]]
];
