#!/usr/bin/perl -w

use strict;

use BER;

print pretty_print ("\x41\x01\xff"),"\n";
1;
