var structcan__bittiming =
[
    [ "bitrate", "structcan__bittiming.html#ab9f18578a4803318e6c5bff8407db9e2", null ],
    [ "brp", "structcan__bittiming.html#a036b3894f622856b8bcf0d6bcea1281c", null ],
    [ "phase_seg1", "structcan__bittiming.html#af854744b57b2979206881bd82c49a134", null ],
    [ "phase_seg2", "structcan__bittiming.html#a06593aa29b4bae7274cdb32fe4deb15d", null ],
    [ "prop_seg", "structcan__bittiming.html#a6bbce8e0d8836ab579b5ea9dc49f10f6", null ],
    [ "sample_point", "structcan__bittiming.html#aa12db4bc04ba90017ad7bd203db75e27", null ],
    [ "sjw", "structcan__bittiming.html#af9e3e1a1c9435aa22b66f2f17db6e319", null ],
    [ "tq", "structcan__bittiming.html#ae01e3296ea4966dea02bd6afc6a9d6ae", null ]
];