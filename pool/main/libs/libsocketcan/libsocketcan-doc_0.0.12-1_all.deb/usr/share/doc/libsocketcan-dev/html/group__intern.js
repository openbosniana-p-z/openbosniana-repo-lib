var group__intern =
[
    [ "do_get_nl_link", "group__intern.html#gaba8e592ddb074f5d1e64bbcfa235b422", null ],
    [ "do_set_nl_link", "group__intern.html#ga7ef3b2896003a70bce26863b966b788d", null ],
    [ "get_link", "group__intern.html#ga3ff496242b6fc2a59158345a1a2dc4c8", null ],
    [ "open_nl_sock", "group__intern.html#gac82d66f72ac28fbb9a2adbf35a608088", null ],
    [ "send_dump_request", "group__intern.html#ga89756618f7d363a99902471b891288ee", null ],
    [ "send_mod_request", "group__intern.html#ga1b91cad86ec363cdab22c7da046f18e3", null ],
    [ "set_link", "group__intern.html#ga1946ba447b350f53076da2a3d113af54", null ]
];