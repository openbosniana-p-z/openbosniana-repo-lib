var annotated_dup =
[
    [ "can_berr_counter", "structcan__berr__counter.html", "structcan__berr__counter" ],
    [ "can_bittiming", "structcan__bittiming.html", "structcan__bittiming" ],
    [ "can_bittiming_const", "structcan__bittiming__const.html", "structcan__bittiming__const" ],
    [ "can_clock", "structcan__clock.html", "structcan__clock" ],
    [ "can_ctrlmode", "structcan__ctrlmode.html", "structcan__ctrlmode" ],
    [ "can_device_stats", "structcan__device__stats.html", "structcan__device__stats" ]
];