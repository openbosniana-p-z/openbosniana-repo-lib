var structcan__device__stats =
[
    [ "arbitration_lost", "structcan__device__stats.html#af9ff72bd174d8728b2ca33db23e483f5", null ],
    [ "bus_error", "structcan__device__stats.html#a6070940a84fd0c3723791d6f60e9cc9c", null ],
    [ "bus_off", "structcan__device__stats.html#ad8e9b6ac45c918505366cd010c80acf0", null ],
    [ "error_passive", "structcan__device__stats.html#a79f6126001c0dff6e0f76af0cdfa3567", null ],
    [ "error_warning", "structcan__device__stats.html#a7fa74765380b46157a1722414c6afef4", null ],
    [ "restarts", "structcan__device__stats.html#abb0ad203fc01cc033e70afad2bb5fb6f", null ]
];