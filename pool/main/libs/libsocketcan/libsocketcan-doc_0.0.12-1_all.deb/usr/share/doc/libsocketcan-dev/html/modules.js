var modules =
[
    [ "External API", "group__extern.html", "group__extern" ],
    [ "Interally used callbacks and structures", "group__intern.html", "group__intern" ]
];