var structcan__bittiming__const =
[
    [ "brp_inc", "structcan__bittiming__const.html#abd72df953b6c015d934f2c1fa55e2f15", null ],
    [ "brp_max", "structcan__bittiming__const.html#a4ff4828bebbc733fa0aa419d91e24bc2", null ],
    [ "brp_min", "structcan__bittiming__const.html#a9c48a4e1b12c513a0d8f556f173a542d", null ],
    [ "name", "structcan__bittiming__const.html#a843bbe31f6e4d40a3ef455cca19f5235", null ],
    [ "sjw_max", "structcan__bittiming__const.html#af9c2882bbfc47694e6a15635e6c1205a", null ],
    [ "tseg1_max", "structcan__bittiming__const.html#a30b694d8191996fbf950cf491866c92b", null ],
    [ "tseg1_min", "structcan__bittiming__const.html#af9b82dec179e94c1e9542cbbcf7abfe5", null ],
    [ "tseg2_max", "structcan__bittiming__const.html#a86ff0ccf55bf0308292b9fc4010b2b03", null ],
    [ "tseg2_min", "structcan__bittiming__const.html#a1d2450d2f5480ab570de73f2c61967e5", null ]
];