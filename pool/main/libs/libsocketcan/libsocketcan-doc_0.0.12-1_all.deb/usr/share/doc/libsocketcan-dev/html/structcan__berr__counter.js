var structcan__berr__counter =
[
    [ "rxerr", "structcan__berr__counter.html#aa66283ec3f112fc67a8ad5ea4306ec6b", null ],
    [ "txerr", "structcan__berr__counter.html#aaa164657f7e8a5db39714439e762ba0e", null ]
];