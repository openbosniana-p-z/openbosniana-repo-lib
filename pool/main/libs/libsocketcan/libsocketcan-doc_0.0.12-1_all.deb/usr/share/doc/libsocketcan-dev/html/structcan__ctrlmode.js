var structcan__ctrlmode =
[
    [ "flags", "structcan__ctrlmode.html#a09f5843a2059efc593fed83a627ab2df", null ],
    [ "mask", "structcan__ctrlmode.html#a0c62d1c0c083c81fa6ab8146191d58ac", null ]
];