var structcan__clock =
[
    [ "freq", "structcan__clock.html#a41877e7c8b305548c17bf2dfe2538927", null ]
];