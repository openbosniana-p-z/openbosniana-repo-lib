Build Instructions
==================

Compile example files with the following gcc flags:
```
gcc -o bot bot.c `pkg-config --cflags --libs libstrophe`
```
