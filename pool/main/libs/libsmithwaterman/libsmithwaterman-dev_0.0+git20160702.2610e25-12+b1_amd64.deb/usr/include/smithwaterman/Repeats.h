#include <iostream>
#include <string>
#include <map>

using namespace std;

map<string, int> repeatCounts(long int pos, const string& seq, int maxsize);
bool isRepeatUnit(const string& seq, const string& unit);
