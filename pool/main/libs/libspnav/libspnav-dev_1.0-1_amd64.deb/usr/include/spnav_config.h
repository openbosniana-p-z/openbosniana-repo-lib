#ifndef SPNAV_CONFIG_H_
#define SPNAV_CONFIG_H_

#define SPNAV_USE_X11

#endif	/* SPNAV_CONFIG_H_ */
