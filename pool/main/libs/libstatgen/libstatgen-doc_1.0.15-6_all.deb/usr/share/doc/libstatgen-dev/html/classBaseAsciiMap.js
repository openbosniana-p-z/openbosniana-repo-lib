var classBaseAsciiMap =
[
    [ "SPACE_TYPE", "classBaseAsciiMap.html#ab024b3ae803f74e750387c1b27583151", [
      [ "UNKNOWN", "classBaseAsciiMap.html#ab024b3ae803f74e750387c1b27583151a50ada7a2b81aee742f3942a9e197cf85", null ],
      [ "BASE_SPACE", "classBaseAsciiMap.html#ab024b3ae803f74e750387c1b27583151ae2fa30ee63bedc39a2461262b42a31c8", null ],
      [ "COLOR_SPACE", "classBaseAsciiMap.html#ab024b3ae803f74e750387c1b27583151a201513bbf1d1b8144bf28de2cae9f0cc", null ]
    ] ],
    [ "getBaseIndex", "classBaseAsciiMap.html#ac117f9c74e741245a023f9e0c4730290", null ],
    [ "getSpaceType", "classBaseAsciiMap.html#ace3dad14b5660b6e8eb09387473efaa1", null ],
    [ "resetBaseMapType", "classBaseAsciiMap.html#a9c6ae85125965657c9630d7cc9eb4099", null ],
    [ "resetPrimerCount", "classBaseAsciiMap.html#aacee9a2fe25f8d2a190d991fbdad3d65", null ],
    [ "setBaseMapType", "classBaseAsciiMap.html#a17a84bbea63abe68d7baf795ddc3775a", null ],
    [ "setNumPrimerBases", "classBaseAsciiMap.html#a88a9c3d62039a643cd2ef7e4744bb69f", null ]
];