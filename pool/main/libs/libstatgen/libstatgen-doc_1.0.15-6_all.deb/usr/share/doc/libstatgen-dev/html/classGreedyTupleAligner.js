var classGreedyTupleAligner =
[
    [ "Align", "classGreedyTupleAligner.html#a7d51a81792c60d5b267c3ac098f5d1dd", null ],
    [ "MatchTuple", "classGreedyTupleAligner.html#a1849478ea810bd5386b32b47d3c27d2c", null ]
];