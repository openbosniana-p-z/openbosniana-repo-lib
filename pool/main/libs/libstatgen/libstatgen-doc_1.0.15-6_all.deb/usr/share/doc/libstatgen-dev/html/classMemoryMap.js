var classMemoryMap =
[
    [ "create", "classMemoryMap.html#ae69a48f002cef2f1dd1a4ce36f71e0b7", null ],
    [ "create", "classMemoryMap.html#a3881391f4314e151603f6982ba81c513", null ],
    [ "open", "classMemoryMap.html#aa687055cbcd75e39d88262a0af223cbb", null ]
];