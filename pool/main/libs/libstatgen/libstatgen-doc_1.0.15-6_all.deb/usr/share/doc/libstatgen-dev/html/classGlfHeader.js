var classGlfHeader =
[
    [ "GlfHeader", "classGlfHeader.html#afb29b9a2bb4f62d244105bf1ecd56e7a", null ],
    [ "copy", "classGlfHeader.html#a918d47d405ca5d7fcf411e00d1bcf4de", null ],
    [ "getHeaderTextString", "classGlfHeader.html#afc14b17a9eb754aaa932f38621a0670e", null ],
    [ "operator=", "classGlfHeader.html#ac15e976977c58ca473d305f468dfa80f", null ],
    [ "read", "classGlfHeader.html#ae947c7650f47e72a77bc80eb175083de", null ],
    [ "resetHeader", "classGlfHeader.html#a4e0c6b9bf46a58d028c5aea4b8574a6e", null ],
    [ "setHeaderTextString", "classGlfHeader.html#a21824bb20a6338771292b1f705c709d2", null ],
    [ "write", "classGlfHeader.html#ae9f08e6649f42071d3f2e0b6f905c0f9", null ]
];