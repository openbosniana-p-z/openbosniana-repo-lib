var classIndexBase =
[
    [ "Bin", "classIndexBase_1_1Bin.html", null ],
    [ "Reference", "classIndexBase_1_1Reference.html", null ],
    [ "getNumRefs", "classIndexBase.html#a7733150fe59249c82c1fafb4e053516a", null ],
    [ "readIndex", "classIndexBase.html#a7d59a6c4b9466f19b556c834eec97939", null ],
    [ "resetIndex", "classIndexBase.html#afb7e6861224ac058f7bb0458de8a3443", null ]
];