var classGlfStatus =
[
    [ "Status", "classGlfStatus.html#ae5a30b3898bff0b98f403b9e8f099968", [
      [ "SUCCESS", "classGlfStatus.html#ae5a30b3898bff0b98f403b9e8f099968ab55afec1d2e0f96498d76436f4413a27", null ],
      [ "UNKNOWN", "classGlfStatus.html#ae5a30b3898bff0b98f403b9e8f099968aa8685d6ebbdb50ab41533e07f212f93b", null ],
      [ "FAIL_IO", "classGlfStatus.html#ae5a30b3898bff0b98f403b9e8f099968af15490c12f5ce7c548eb6d7302e9bd0a", null ],
      [ "FAIL_ORDER", "classGlfStatus.html#ae5a30b3898bff0b98f403b9e8f099968a4a9208b4cdd844024d04c952f1e91b6b", null ],
      [ "FAIL_PARSE", "classGlfStatus.html#ae5a30b3898bff0b98f403b9e8f099968acb43f23119b6a564303a265c62a843fb", null ],
      [ "INVALID", "classGlfStatus.html#ae5a30b3898bff0b98f403b9e8f099968ac157e49c5a15a1840353eea65043d427", null ],
      [ "FAIL_MEM", "classGlfStatus.html#ae5a30b3898bff0b98f403b9e8f099968a441f86d49aec9a302482c9a4895d1a5f", null ]
    ] ],
    [ "GlfStatus", "classGlfStatus.html#ae2c233e066217db6bb6320f97f5c8a5b", null ],
    [ "~GlfStatus", "classGlfStatus.html#a3a2a3b16b6c1f8572c30261fed907435", null ],
    [ "addError", "classGlfStatus.html#a7b76da95d5e3bc4e86532a88ff7a4e04", null ],
    [ "addError", "classGlfStatus.html#aaca5b8ae3304763293b30da1a2564cb2", null ],
    [ "getStatus", "classGlfStatus.html#a9974c491811a5e4499c9447aa392c718", null ],
    [ "getStatusMessage", "classGlfStatus.html#a4cfca1f4b440c1fb0192abb2d04b231c", null ],
    [ "operator!=", "classGlfStatus.html#abab59a1985fc78eedc66a22bb390765c", null ],
    [ "operator=", "classGlfStatus.html#a5afb31c8defb8e4771de73e11d6581c3", null ],
    [ "operator==", "classGlfStatus.html#a71d36517d75c0faeb4f65ab53e116bd8", null ],
    [ "reset", "classGlfStatus.html#af05bc23befc6fd0af4e517a54b7d20a7", null ],
    [ "setStatus", "classGlfStatus.html#a66f5de529c06a1fd2271061ec5647236", null ]
];