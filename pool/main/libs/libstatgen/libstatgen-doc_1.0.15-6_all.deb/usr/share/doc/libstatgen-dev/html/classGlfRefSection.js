var classGlfRefSection =
[
    [ "GlfRefSection", "classGlfRefSection.html#a1abe75aafa8dc7bde10f9fd4ec03576e", null ],
    [ "copy", "classGlfRefSection.html#a229b79b8e971ccc8abaae77e17e767f8", null ],
    [ "getName", "classGlfRefSection.html#aeec735c4e4c24c366695a860ac79cb15", null ],
    [ "getRefLen", "classGlfRefSection.html#acf206f3e5522b03229c62e5b6364eb5e", null ],
    [ "operator=", "classGlfRefSection.html#a3f75aab04eb8c205de9f64e1050fca3a", null ],
    [ "print", "classGlfRefSection.html#a5dff540451abf8b8a32dd380e971a8c9", null ],
    [ "read", "classGlfRefSection.html#a3305186bf1cbaa00827b9618dc105069", null ],
    [ "resetRefSection", "classGlfRefSection.html#a1000ad1deaad8fc3e6cae2492cd00c30", null ],
    [ "setName", "classGlfRefSection.html#a1c4ee4d880c42d07b375e4a2023adc88", null ],
    [ "setRefLen", "classGlfRefSection.html#aa463f2388d4ca94353c503aa4bd5aa18", null ],
    [ "write", "classGlfRefSection.html#a971d458f545328e0df49c098b76fdf6e", null ]
];