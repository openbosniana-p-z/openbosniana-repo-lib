var classFastQFile =
[
    [ "FastQFile", "classFastQFile.html#aed6f62ceb453b3a4ee37ea9ddcc3bc6e", null ],
    [ "closeFile", "classFastQFile.html#ab29e37787c05c795bef76126b30ac4ab", null ],
    [ "disableMessages", "classFastQFile.html#a47c869635b7445db6ab15b8c2d705d56", null ],
    [ "disableSeqIDCheck", "classFastQFile.html#a53a41fbc06705fdae119e6d58a34033b", null ],
    [ "enableMessages", "classFastQFile.html#ace8830137352075a59b8eb60e3f65792", null ],
    [ "enableSeqIDCheck", "classFastQFile.html#a364b82d2504db70fd60b612070472773", null ],
    [ "getSpaceType", "classFastQFile.html#a6c86d045210daa3d9fe547618cf9122e", null ],
    [ "interleaved", "classFastQFile.html#a258ec90c966c2d58dfbf5ee65b3c6774", null ],
    [ "isEof", "classFastQFile.html#af232549b3d9b4cf543ccc75ecc83ca82", null ],
    [ "isOpen", "classFastQFile.html#a4a33e4796e75b053fc718924e821d833", null ],
    [ "keepReadingFile", "classFastQFile.html#acd17711a164aab24a3da25cf86750262", null ],
    [ "openFile", "classFastQFile.html#a25fd33e94e2f64c777481cd776d5481e", null ],
    [ "readFastQSequence", "classFastQFile.html#a9a22f50eb7219c5a2dd77b535c020a9a", null ],
    [ "setMaxErrors", "classFastQFile.html#aeb71070154a8bf421044defca9305bf3", null ],
    [ "validateFastQFile", "classFastQFile.html#acb81a87d21d4e7ce836894a3b57fcf80", null ]
];