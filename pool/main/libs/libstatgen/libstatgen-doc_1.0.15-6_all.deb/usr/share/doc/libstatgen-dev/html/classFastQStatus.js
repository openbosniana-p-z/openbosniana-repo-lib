var classFastQStatus =
[
    [ "Status", "classFastQStatus.html#a8e1a5da1fc6579314498a4df333d9e2e", [
      [ "FASTQ_SUCCESS", "classFastQStatus.html#a8e1a5da1fc6579314498a4df333d9e2ea4d453ae09ca54977130ef20c0ae2ffc9", null ],
      [ "FASTQ_INVALID", "classFastQStatus.html#a8e1a5da1fc6579314498a4df333d9e2ea71f9a8ad755b1b4c2da6a2d6ecd7edf2", null ],
      [ "FASTQ_ORDER_ERROR", "classFastQStatus.html#a8e1a5da1fc6579314498a4df333d9e2ea32755363c7c43ac28bc093f8f01279e0", null ],
      [ "FASTQ_OPEN_ERROR", "classFastQStatus.html#a8e1a5da1fc6579314498a4df333d9e2ea8974726dd045abeaca99ea1dfe840089", null ],
      [ "FASTQ_CLOSE_ERROR", "classFastQStatus.html#a8e1a5da1fc6579314498a4df333d9e2eaaff7b1b10d012f1269df1c223a9d5780", null ],
      [ "FASTQ_READ_ERROR", "classFastQStatus.html#a8e1a5da1fc6579314498a4df333d9e2ea48efe193a4dfb8ffc3ceb8afedfdb931", null ],
      [ "FASTQ_NO_SEQUENCE_ERROR", "classFastQStatus.html#a8e1a5da1fc6579314498a4df333d9e2ea9623690cdcb2a566513298140ae3f94d", null ]
    ] ]
];