var classGlfFileReader =
[
    [ "GlfFileReader", "classGlfFileReader.html#a22ce34cf15732bc42a076d4cb948bb4a", null ],
    [ "GlfFileReader", "classGlfFileReader.html#ad1f6288688d62f9bf37827cac6d644d7", null ]
];