var classBaseComposition =
[
    [ "BaseComposition", "classBaseComposition.html#a61388fb8ee85b60dd9b8e09188e3e59c", null ],
    [ "clear", "classBaseComposition.html#a477406d0201648e561a2718c3c35eab3", null ],
    [ "getSpaceType", "classBaseComposition.html#a76bb74b1526602a60afcb4c484111b87", null ],
    [ "print", "classBaseComposition.html#a97c0fb6965aa30ace40f82d15a1d8b52", null ],
    [ "resetBaseMapType", "classBaseComposition.html#aba8eb28add40b06dbe3784a6b0a3f72a", null ],
    [ "setBaseMapType", "classBaseComposition.html#a66fe9e534bee251d5119f2830ae4e61f", null ],
    [ "updateComposition", "classBaseComposition.html#a25d7e2341416605d80c0c5165e0140ae", null ]
];