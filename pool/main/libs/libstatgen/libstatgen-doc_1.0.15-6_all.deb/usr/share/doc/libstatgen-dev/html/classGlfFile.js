var classGlfFile =
[
    [ "OpenType", "classGlfFile.html#a69bf09b3b9169323566d526812bb1e00", [
      [ "READ", "classGlfFile.html#a69bf09b3b9169323566d526812bb1e00a1520bacdf9131057c4301c7c8ff01b93", null ],
      [ "WRITE", "classGlfFile.html#a69bf09b3b9169323566d526812bb1e00aaf4db6ce1326caf6181904858681b745", null ]
    ] ],
    [ "GlfFile", "classGlfFile.html#a719dff9f2e13d8ca1d5c185b906dbe1e", null ],
    [ "GlfFile", "classGlfFile.html#ac874320c2832c1a4939f125335d74d63", null ],
    [ "~GlfFile", "classGlfFile.html#a1772552f9d2cebdaf120db7d7c6ec800", null ],
    [ "close", "classGlfFile.html#a7f3b179f8c9674d5b33af4c7181dd8f5", null ],
    [ "getCurrentRecordCount", "classGlfFile.html#ac4220a9b795414ca95414443d28fb1d6", null ],
    [ "getFailure", "classGlfFile.html#a6632df981f0c2d50d531b7b44db1b8be", null ],
    [ "getNextRecord", "classGlfFile.html#a6868f380cd18a7348bd00f9159cafb63", null ],
    [ "getNextRefSection", "classGlfFile.html#a164c37931f61be7c0d251dae085523c1", null ],
    [ "getStatus", "classGlfFile.html#acd86be675dee429786bf72ff60a0260f", null ],
    [ "getStatusMessage", "classGlfFile.html#a260948048c56305735251f7080a3d042", null ],
    [ "isEOF", "classGlfFile.html#ad92a776149f7e0cb601aa6f1cf3486f0", null ],
    [ "openForRead", "classGlfFile.html#a785bcad4b25c777d30b6d9b7379f6b03", null ],
    [ "openForRead", "classGlfFile.html#a29e9ec06d839a07bbe815949e38b07cc", null ],
    [ "openForWrite", "classGlfFile.html#a5e48dc3d476f1423459020485dfabc87", null ],
    [ "readHeader", "classGlfFile.html#abb4e13baeb1d543933f70242121004c0", null ],
    [ "writeHeader", "classGlfFile.html#a89e8fd9575f59c9d7d3ec59269c2e967", null ],
    [ "writeRecord", "classGlfFile.html#afefeca506e4f126531124a2724a90490", null ],
    [ "writeRefSection", "classGlfFile.html#a337ccd4b44c8864f671ebbb15955bb1a", null ]
];