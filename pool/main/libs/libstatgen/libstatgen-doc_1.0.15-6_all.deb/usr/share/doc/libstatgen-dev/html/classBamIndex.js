var classBamIndex =
[
    [ "getChunksForRegion", "classBamIndex.html#a3b084107c962c98840b17c6d4c889ce3", null ],
    [ "getNumMappedReads", "classBamIndex.html#a4d417c34a7a5e23983e7a435d4abb8d6", null ],
    [ "getNumUnMappedReads", "classBamIndex.html#ae713c325d5fe3d7854fd5fd5934c9e69", null ],
    [ "getReferenceMinMax", "classBamIndex.html#abf1887753e820e8951be9b05f476c27a", null ],
    [ "printIndex", "classBamIndex.html#af2ff9005b96919205be0f075e7fc66e1", null ],
    [ "readIndex", "classBamIndex.html#a8bc02dd5624956de5674f43f6da84536", null ],
    [ "resetIndex", "classBamIndex.html#a1816aea5cb6f3b19ac76a25f242d41d9", null ]
];