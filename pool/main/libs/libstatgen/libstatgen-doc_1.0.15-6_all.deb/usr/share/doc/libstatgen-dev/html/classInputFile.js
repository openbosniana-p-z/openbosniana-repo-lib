var classInputFile =
[
    [ "ifileCompression", "classInputFile.html#aded484baa375ceb713b876e0cc916aba", [
      [ "DEFAULT", "classInputFile.html#aded484baa375ceb713b876e0cc916abaabef404c2b43c599d446b6c38105efbbf", null ],
      [ "UNCOMPRESSED", "classInputFile.html#aded484baa375ceb713b876e0cc916abaacc5ade47f2d3c546e8d8b4317a3b7d47", null ],
      [ "GZIP", "classInputFile.html#aded484baa375ceb713b876e0cc916abaa4704f1bcaa4b7bbcd5f00f8372d53f0a", null ],
      [ "BGZF", "classInputFile.html#aded484baa375ceb713b876e0cc916abaa014f2a1d3c454c3850ce41208455ab22", null ]
    ] ],
    [ "InputFile", "classInputFile.html#a639375676099652952b522f0e3fd3a0d", null ],
    [ "~InputFile", "classInputFile.html#a184a592debf38e724f5c709e0b8b4eac", null ],
    [ "InputFile", "classInputFile.html#abade0d0c8e9c703b9720e2a69a61321e", null ],
    [ "bufferReads", "classInputFile.html#a09cedf4267afe1821b2c6adab9146bfe", null ],
    [ "disableBuffering", "classInputFile.html#a548fc8ff782c6e87bf7b0326abee9832", null ],
    [ "discardLine", "classInputFile.html#ad3fdc01e2f1c97be7fb9cd28f09eb321", null ],
    [ "getFileName", "classInputFile.html#a85198242bf38a41878d219bc975ddaa9", null ],
    [ "ifclose", "classInputFile.html#a0ae7eac29d554867ce313248f9ba2a11", null ],
    [ "ifeof", "classInputFile.html#a69cf36304ff0156600abf1b7d089c2ae", null ],
    [ "ifgetc", "classInputFile.html#aada5ebb654e1e387d7e23edcda8faa31", null ],
    [ "ifgetline", "classInputFile.html#aa47fca506c763c033f12546fd3f4b107", null ],
    [ "ifread", "classInputFile.html#a9817560e8ddad1d6871777753513606b", null ],
    [ "ifrewind", "classInputFile.html#a9ca3f375b22ce0ac433bee1c832360be", null ],
    [ "ifseek", "classInputFile.html#af594990c9aaf183ad1f56cdfe03cf331", null ],
    [ "iftell", "classInputFile.html#a9d60032aa1231eafa19814b4cb7a2ae4", null ],
    [ "ifwrite", "classInputFile.html#a4fc153d2450b98a2c8db5e2dc9076900", null ],
    [ "isOpen", "classInputFile.html#a63a23a0e86b0a65a64d83d3f93d84d05", null ],
    [ "readLine", "classInputFile.html#a46fc979b233c909453def2690804242f", null ],
    [ "readTilChar", "classInputFile.html#a4a44dea831fa14835e6dab67172ee125", null ],
    [ "readTilChar", "classInputFile.html#af6e98e557bf4a9175ab0b3e60233a1dd", null ],
    [ "readTilTab", "classInputFile.html#aea4148b4699e9260cc12be88e25bfb7a", null ],
    [ "setAttemptRecovery", "classInputFile.html#a7f276aefa134a3fafc1b54739b1012b7", null ]
];