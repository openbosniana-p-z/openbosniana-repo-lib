var classErrorHandler =
[
    [ "HandlingType", "classErrorHandler.html#aaa5221c8ddd7cf46fba5307cd28f8542", [
      [ "EXCEPTION", "classErrorHandler.html#aaa5221c8ddd7cf46fba5307cd28f8542adf3df2c3eeea36dd858d58e0f77136e9", null ],
      [ "ABORT", "classErrorHandler.html#aaa5221c8ddd7cf46fba5307cd28f8542a63087b530484db1a5b3bb9711f1718e0", null ],
      [ "RETURN", "classErrorHandler.html#aaa5221c8ddd7cf46fba5307cd28f8542a19c08a8df70c2b3ecf66a6705dd38678", null ]
    ] ],
    [ "ErrorHandler", "classErrorHandler.html#a7e5f379bd231442b898cef94556b2107", null ],
    [ "~ErrorHandler", "classErrorHandler.html#a73c7e690b864697e507aaeb537b3c3e5", null ]
];