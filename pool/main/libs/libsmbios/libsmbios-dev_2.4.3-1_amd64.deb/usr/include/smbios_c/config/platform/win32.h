//  (C) Copyright John Maddock 2001 - 2003.
//  (C) Copyright Bill Kempf 2001.
//  (C) Copyright Aleksey Gurtovoy 2003.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for most recent version.

//  Win32 specific config options:

#define LIBSMBIOS_C_PLATFORM "Win32"
#define LIBSMBIOS_C_PLATFORM_WIN32

