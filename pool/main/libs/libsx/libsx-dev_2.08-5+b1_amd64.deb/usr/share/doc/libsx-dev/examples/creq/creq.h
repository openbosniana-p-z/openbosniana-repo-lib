int GetColor(unsigned char *r, unsigned char *g, unsigned char *b);
