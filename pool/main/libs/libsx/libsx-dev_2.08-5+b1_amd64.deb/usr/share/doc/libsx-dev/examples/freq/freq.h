char *SimpleGetFile(char *path);
