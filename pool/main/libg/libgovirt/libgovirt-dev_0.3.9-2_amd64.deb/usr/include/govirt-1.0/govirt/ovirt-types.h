
/*
 * ovirt-types.h: base oVirt types
 *
 * Copyright (C) 2012 Red Hat, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see
 * <http://www.gnu.org/licenses/>.
 *
 * Author: Christophe Fergeau <cfergeau@redhat.com>
 */
#ifndef __OVIRT_TYPES_H__
#define __OVIRT_TYPES_H__

G_BEGIN_DECLS

typedef struct _OvirtApi OvirtApi;
typedef struct _OvirtCdrom OvirtCdrom;
typedef struct _OvirtCluster OvirtCluster;
typedef struct _OvirtCollection OvirtCollection;
typedef struct _OvirtDisk OvirtDisk;
typedef struct _OvirtDataCenter OvirtDataCenter;
typedef struct _OvirtHost OvirtHost;
typedef struct _OvirtProxy OvirtProxy;
typedef struct _OvirtStorageDomain OvirtStorageDomain;
typedef struct _OvirtVmDisplay OvirtVmDisplay;
typedef struct _OvirtVmPool OvirtVmPool;
typedef struct _OvirtVm OvirtVm;

G_END_DECLS

#endif /* __OVIRT_TYPES_H__ */
