#ifndef _GEPUB__H_
#define _GEPUB__H_

#include <config.h>

#include "gepub-archive.h"
#include "gepub-text-chunk.h"
#include "gepub-doc.h"

#ifdef GEPUB_WIDGET_ENABLED
#include "gepub-widget.h"
#endif

#endif
