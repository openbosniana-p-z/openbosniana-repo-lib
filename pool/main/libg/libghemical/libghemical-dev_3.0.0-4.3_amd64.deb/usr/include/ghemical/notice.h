// NOTICE.H : copyright notices...

// Copyright (C) 2000 Tommi Hassinen.

// This package is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.

// This package is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this package; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

/*################################################################################################*/

#ifndef NOTICE_H
#define NOTICE_H

#include "libghemicaldefine.h"
#include "libghemical-features.h"

/* added by Robert Williams for Compaq cxx, alpha 11/28/01 */
#define __USE_STD_IOSTREAM

#include <iostream>
using namespace std;

/*################################################################################################*/

#define LIB_INTRO_NOTICE_LINES 4
#define COPYRIGHT_NOTICE_LINES 21

const char * get_lib_intro_notice_line(int);
const char * get_copyright_notice_line(int);

void print_lib_intro_notice(ostream &);
void print_copyright_notice(ostream &);

/*################################################################################################*/

void assertion_failed(const char *, int, const char *);

/*################################################################################################*/

#endif	// NOTICE_H

// eof
