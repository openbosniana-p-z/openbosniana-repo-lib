/* src/libghemical-features.h.  Generated from libghemical-features.h.in by configure.  */
/*
 * libghemical-features.h.in: 
 */
#ifndef LIBGHEMICAL_FEATURES_H
#define LIBGHEMICAL_FEATURES_H

/* Define if you are building a version that interfaces directly with MOPAC7
   */
#define ENABLE_MOPAC7 /**/

/* Define if you are building a version that interfaces directly with MPQC */
#define ENABLE_MPQC /**/

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `blas' library (-lblas). */
#define HAVE_LIBBLAS 1

/* Define to 1 if you have the `lapack' library (-llapack). */
#define HAVE_LIBLAPACK 1

/* Define to 1 if you have the `m' library (-lm). */
#define HAVE_LIBM 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Where the data files are ; set in the configure.ac */
#define LIBDATA_PATH "/usr/share/libghemical"

/* This is the releasedate of libghemical--it is set in the configure.ac */
#define LIBRELEASEDATE "2011-10-12"

/* This is the version of libghemical to be built--it is set in the
   configure.ac */
#define LIBVERSION "3.0.0"

/* This is the major version of SC (MPQC's underlying library) found by
   configure */
#define SC_MAJOR_VERSION 2

/* This is the micro version of SC (MPQC's underlying library) found by
   configure */
#define SC_MICRO_VERSION 1

/* This is the minor version of SC (MPQC's underlying library) found by
   configure */
#define SC_MINOR_VERSION 3

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

#endif /* LIBGHEMICAL_FEATURES_H */
