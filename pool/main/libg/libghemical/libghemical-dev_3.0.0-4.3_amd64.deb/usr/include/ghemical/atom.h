// ATOM.H : the atom-related classes.

// Copyright (C) 1998 Tommi Hassinen.

// This package is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.

// This package is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this package; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

/*################################################################################################*/

#ifndef ATOM_H
#define ATOM_H

#include "libghemicaldefine.h"
#include "libghemical-features.h"

class element;

class crec;
class atom;

/*################################################################################################*/

class bond;	// bond.h
class model;	// model.h

#include "typedef.h"

#include <cstdlib>

#include <list>
#include <vector>
using namespace std;

/*################################################################################################*/

#define ELEMENT_SYMBOLS 110

/// An element class.

class element
{
	private:
	
	i32s atomic_number;			///< This is the atomic number, or NOT_DEFINED (equal to -1) for a dummy atom.
	
	static const char string[ELEMENT_SYMBOLS][32];
	static const char symbol[ELEMENT_SYMBOLS][4];
	
	static const fGL color[ELEMENT_SYMBOLS][3];
	
	static const fGL mass[ELEMENT_SYMBOLS];
	static const fGL vdwr[ELEMENT_SYMBOLS];

	public:
	
	static element current_element;		///< This is the current element that user has selected.
	
	public:
	
	element(void);
	element(char *);	///< By symbols.
	element(i32s);		///< By atomic numbers.
	~element(void);
	
	const i32s GetAtomicNumber(void) const;
	const char * GetString(void) const;
	const char * GetSymbol(void) const;	
	const fGL * GetColor(void) const;
	fGL GetAtomicMass(void) const;
	fGL GetVDWRadius(void) const;

// JUST DISABLED FOR A WHILE; remove the "const" settings from tables and write prefs directly there??? QUICKER!!!
// JUST DISABLED FOR A WHILE; remove the "const" settings from tables and write prefs directly there??? QUICKER!!!
// JUST DISABLED FOR A WHILE; remove the "const" settings from tables and write prefs directly there??? QUICKER!!!
//	fGL GetVDWRadius(prefs *) const;
//	const fGL * GetColor(prefs *) const;
	
	void operator++(void);
	void operator--(void);
};

/*################################################################################################*/

/// A connectivity record class.
/** The connectivity records are maintained in the atom objects, to make quick browising of 
bond networks possible. */

class crec
{
//	protected:
	public:		// TODO : not properly divided in public/protected data.
	
	atom * atmr;
	bond * bndr;
	
	public:
	
	crec(void);
	crec(atom *, bond *);
	~crec(void);
	
//	bool operator<(const crec &) const { return false; }		// just for STL...
	bool operator==(const crec &) const;
};

/*################################################################################################*/

typedef list<crec>::iterator iter_cl;		// cl = connectivity list
typedef list<atom>::iterator iter_al;		// al = atom list

typedef atom * ref_atom;

/*################################################################################################*/

#define ATOMFLAG_USER_SELECTED		(1 << 0)

#define ATOMFLAG_USER_HIDDEN		(1 << 1)	// the USER_HIDDEN flag means:
// the wants to hide these atoms from the graphics view ; the flag is NOT affected to any calculations.

#define ATOMFLAG_USER_LOCKED		(1 << 2)	// the USER_LOCKED flag means:
// 1) DoSHAKE() should not move it 2) in MD acc/vel always 0.0 and is not included when calculating Ekin/T.
// THIS IS STILL AN INCOMPLETE IMPLEMENTATION!!! be careful with this and test before any serious use...

// the flags below this level are "internal" and should NOT be saved in any files (mask 0xFF).
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#define ATOMFLAG_IS_SOLVENT_ATOM	(1 << 8)	// todo : energy groups?!?!?
#define ATOMFLAG_MEASURE_TOOL_SEL	(1 << 16)	// -> replace by this when rdy...

#define ATOMFLAG_IS_HIDDEN		(1 << 9)	// handled by the setup classes...
#define ATOMFLAG_IS_QM_ATOM		(1 << 10)	// handled by the setup classes...
#define ATOMFLAG_IS_MM_ATOM		(1 << 11)	// handled by the setup classes...
#define ATOMFLAG_IS_SF_ATOM		(1 << 12)	// handled by the setup classes...

#define ATOMFLAG_MEASURE_ND_RDF		(1 << 24)
#define ATOMFLAG_COUNT_IN_RDF		(1 << 25)

/// An atom class.
/** Will store all data about an atom, including type, coordinates, and a connectivity 
record list for quick access to neighbor atoms. */

class atom
{
	protected:
	
	model * mdl;
	
//	protected:
	public:		// TODO : not properly divided in public/protected data.
	
	element el;		// is saved into files!!!
	int formal_charge;	// is saved into files!!! NOT YET BUT SHOULD!!!
	
	i32s atmtp;		///< The normal MM atomtype.
	i32s atmtp_E;		///< MM atomtype "exception"; related to macromolecules...
	char atmtp_s[4];	///< MM atomtype "exception"; related to macromolecules...
	
	f64 charge;		// is saved into files???
	f64 mass;
	
	f64 vdwr;		// important in SF!!!
	
	i32u my_glname;		// this is reserved for the GUI stuff...
	
protected:
	list<crec> cr_list;		///< Connectivity records.
	
	fGL * crd_table;		///< The actual coordinate data; see also model::PushCRDSets().
	i32u crd_table_size_loc;
public:
	
/// Molecule, chain, residue and atom ID-numbers.
/** model::GatherGroups() will maintain molecule numbers, and sequence builders will handle the rest. 
mol/chn id's are unique, but res/atm numbers are repeated in different chains and molecules.*/
	i32s id[4];
	
/// Residue-ID numbers related to sequence-builder. Not sensitive to protonation states etc...
	i32s builder_res_id;
	
	i32s index;		///< Index of this entry in model::atom_list. Updated by model::UpdateIndex().
	i32s varind;		///< Index of this entry in setup::atmtab. Updated by setup::UpdateSetupInfo().
	
	i32u flags;		///< The flags that carry various information. These are saved into files.
	i32s ecomp_grp_i;
	
	friend class model;	// model::PushCRDSets() needs this...
	
	public:
	
	atom(void);
	atom(element, const fGL *, i32u);
	atom(const atom &);
	~atom(void);
	
	model * GetModel(void) { return mdl; }
	
	const fGL * GetCRD(i32u);
	void SetCRD(i32s, fGL, fGL, fGL);
	
	iter_cl GetConnRecsBegin(void) { return cr_list.begin(); }	//const;
	iter_cl GetConnRecsEnd(void) { return cr_list.end(); }		//const;
	crec & GetFirstConnRec(void) { return cr_list.front(); }
	crec & GetLastConnRec(void) { return cr_list.back(); }
	int GetConnRecCount(void) { return (int) cr_list.size(); }	///< This will return cr_list.size().
	
	bool GetSelected(void) const;
	void SetSelected(bool);
	
	bool GetLocked(void) const;
	void SetLocked(bool);
	
	bool operator<(const atom &) const;	///< Using id-numbers.
	bool operator==(const atom &) const;	///< Using pointers.
};

/*################################################################################################*/

#endif	// ATOM_H

// eof
