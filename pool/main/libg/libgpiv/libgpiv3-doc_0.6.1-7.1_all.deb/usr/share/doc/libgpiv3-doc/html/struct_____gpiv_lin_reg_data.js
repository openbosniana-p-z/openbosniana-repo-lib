var struct_____gpiv_lin_reg_data =
[
    [ "c0", "struct_____gpiv_lin_reg_data.html#a87bdec94df16e0bef45ba3406f68c8a7", null ],
    [ "c1", "struct_____gpiv_lin_reg_data.html#a51528a4004ff14f4612edbfb25e6b813", null ],
    [ "cov00", "struct_____gpiv_lin_reg_data.html#ad6b6af5e0032a77e53265b7271b1a8ca", null ],
    [ "cov01", "struct_____gpiv_lin_reg_data.html#a9f23cf24a213e56d071c275c74438466", null ],
    [ "cov11", "struct_____gpiv_lin_reg_data.html#af9f35ec99c5b9efaf50f5548cfe18fc4", null ],
    [ "sumsq", "struct_____gpiv_lin_reg_data.html#ac1a3fd4af2ae6348fe8b20ad7a4f73ff", null ]
];