var gpiv_valid_8h =
[
    [ "__GpivLinRegData", "struct_____gpiv_lin_reg_data.html", "struct_____gpiv_lin_reg_data" ],
    [ "GPIV_GRADIENT_THRESHOLD", "gpiv-valid_8h.html#aa83d5bb0e873f752e12f63e6f82dd9a8", null ],
    [ "GPIV_RESIDU_MAX_NORMMEDIAN", "gpiv-valid_8h.html#a000727d3b679f5196d5c7e890408bd0f", null ],
    [ "GPIV_THRESHOLD_DEFAULT", "gpiv-valid_8h.html#af3f83a48f62a982dd9f1d77cd660e0c7", null ],
    [ "GPIV_VALID_MAX_SWEEP", "gpiv-valid_8h.html#a8473e1e6d8f676eb5680497021db58d8", null ],
    [ "GpivLinRegData", "gpiv-valid_8h.html#ab63e27265d535004ada0f849b99ef8bc", null ],
    [ "gpiv_cumhisto_eqdatbin_gnuplot", "gpiv-valid_8h.html#aa2f496a93157c7e2a4a16cfca75d6144", null ],
    [ "gpiv_valid_errvec", "gpiv-valid_8h.html#a2dcf3d1c728d39eb696ecf6043c9259f", null ],
    [ "gpiv_valid_gradient", "gpiv-valid_8h.html#ad3123a3293b4ec27b00ba98487f86c64", null ],
    [ "gpiv_valid_peaklck", "gpiv-valid_8h.html#a8badfdcd91c11f539bf0304bb7b3033b", null ],
    [ "gpiv_valid_residu", "gpiv-valid_8h.html#a19b5eaeb1430f7bffebe71b65bd8562c", null ],
    [ "gpiv_valid_residu_stats", "gpiv-valid_8h.html#a9386a7b0f03c7eef8e934de20519b122", null ],
    [ "gpiv_valid_threshold", "gpiv-valid_8h.html#a0c38d2d4957bf12d331e834b3bb794ea", null ]
];