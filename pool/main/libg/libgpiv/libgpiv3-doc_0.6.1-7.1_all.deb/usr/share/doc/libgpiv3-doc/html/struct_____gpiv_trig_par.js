var struct_____gpiv_trig_par =
[
    [ "ttime", "struct_____gpiv_trig_par.html#a53b8a4468a1220edbbccf149d749db95", null ],
    [ "ttime__cam_acq_period__set", "struct_____gpiv_trig_par.html#a20dc4b2db1ec2c4e7697005d966cf431", null ],
    [ "ttime__cycles__set", "struct_____gpiv_trig_par.html#add385e3c03c7613cefb2093f52d7c12b", null ],
    [ "ttime__dt__set", "struct_____gpiv_trig_par.html#a1e7aee509e5e45a11deb8d4d191292bb", null ],
    [ "ttime__increment__set", "struct_____gpiv_trig_par.html#ab64350b01bea41eaa3c759d0cc35d8c1", null ],
    [ "ttime__laser_trig_pw__set", "struct_____gpiv_trig_par.html#a77432201a2bb36182d7a988e11054517", null ],
    [ "ttime__mode__set", "struct_____gpiv_trig_par.html#acd7dce1a0d913eb4f968b894409c13a4", null ],
    [ "ttime__time2laser__set", "struct_____gpiv_trig_par.html#ac46e929e00e1818885f0338f4a731380", null ]
];