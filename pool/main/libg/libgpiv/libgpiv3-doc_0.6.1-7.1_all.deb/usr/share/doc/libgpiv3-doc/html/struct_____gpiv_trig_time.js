var struct_____gpiv_trig_time =
[
    [ "cam_acq_period", "struct_____gpiv_trig_time.html#a06149d87b100207912939ab970c9925e", null ],
    [ "cycles", "struct_____gpiv_trig_time.html#aa7216c9de9080500adc1a425dcfdc4a0", null ],
    [ "dt", "struct_____gpiv_trig_time.html#a9585944fb8972d136e9c367ac3a88649", null ],
    [ "increment", "struct_____gpiv_trig_time.html#a138f86bd8b09af22283249e46d26d8e3", null ],
    [ "laser_trig_pw", "struct_____gpiv_trig_time.html#a98c568aa6cf83bd82f44a085b5791e1d", null ],
    [ "mode", "struct_____gpiv_trig_time.html#aecc5f6062aad6fbf91e04fe3c280ebe9", null ],
    [ "time2laser", "struct_____gpiv_trig_time.html#a4c87bdbc02cdbdb4f7e8df376c15764b", null ]
];