var globals_func =
[
    [ "g", "globals_func.html", null ]
];