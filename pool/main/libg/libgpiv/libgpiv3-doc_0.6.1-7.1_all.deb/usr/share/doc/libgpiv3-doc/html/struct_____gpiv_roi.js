var struct_____gpiv_roi =
[
    [ "x_1", "struct_____gpiv_roi.html#a5ffae152ca70fcddd87447fec71cd5f3", null ],
    [ "x_2", "struct_____gpiv_roi.html#ae23407d06055a101ddbb271528100bd1", null ],
    [ "y_1", "struct_____gpiv_roi.html#a4bac2f17ca7ce6ad10897b228aaa6eaa", null ],
    [ "y_2", "struct_____gpiv_roi.html#af1ea5d9489489e1e21597ae4f34da6bb", null ]
];