var struct_____gpiv_bin_data =
[
    [ "bound", "struct_____gpiv_bin_data.html#a9dd532c6837e39670fce41f4a855d455", null ],
    [ "centre", "struct_____gpiv_bin_data.html#a844454c42b13a36b26f96ed27ea51383", null ],
    [ "comment", "struct_____gpiv_bin_data.html#afbcbdcfb3bc46f477dd5ca5f661ebb13", null ],
    [ "count", "struct_____gpiv_bin_data.html#ac0f4d2add23b31e516e055759174186f", null ],
    [ "max", "struct_____gpiv_bin_data.html#a3f528edb2a76435e56a7f110fdeab120", null ],
    [ "min", "struct_____gpiv_bin_data.html#ae908c276798bfad4792b3ae1c86e7b50", null ],
    [ "nbins", "struct_____gpiv_bin_data.html#ada1c6a911ccad6a74464affe1b9e9119", null ]
];