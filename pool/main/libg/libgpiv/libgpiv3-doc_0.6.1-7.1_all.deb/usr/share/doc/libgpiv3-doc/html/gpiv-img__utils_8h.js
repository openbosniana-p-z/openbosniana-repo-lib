var gpiv_img__utils_8h =
[
    [ "gpiv_alloc_img", "gpiv-img__utils_8h.html#a8f45984754a340158d7dab53595342d2", null ],
    [ "gpiv_check_alloc_img", "gpiv-img__utils_8h.html#aa5132c8d0b6f6b8d92e499ca2e4c7486", null ],
    [ "gpiv_cp_img", "gpiv-img__utils_8h.html#a7bd2e348e49ddb78b915bef5d6a5264c", null ],
    [ "gpiv_cp_img_data", "gpiv-img__utils_8h.html#a2d346f070e4746e9adfe17fec58ae3a5", null ],
    [ "gpiv_free_img", "gpiv-img__utils_8h.html#a7439b6adce73f85c7226e03b444081bb", null ]
];