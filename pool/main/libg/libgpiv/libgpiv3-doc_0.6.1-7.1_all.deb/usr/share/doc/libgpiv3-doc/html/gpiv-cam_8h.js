var gpiv_cam_8h =
[
    [ "__GpivCamPar", "struct_____gpiv_cam_par.html", "struct_____gpiv_cam_par" ],
    [ "__GpivCamVar", "struct_____gpiv_cam_var.html", "struct_____gpiv_cam_var" ],
    [ "GPIV_CAMPAR_CYCLES_MAX", "gpiv-cam_8h.html#a516195ec309ec0b7422da851d0d8c6df", null ],
    [ "GPIV_CAMPAR_CYCLES_MAX", "gpiv-cam_8h.html#a516195ec309ec0b7422da851d0d8c6df", null ],
    [ "GPIV_CAMPAR_CYCLES_MIN", "gpiv-cam_8h.html#ad489304d10b10965ae5d823357548748", null ],
    [ "GPIV_CAMPAR_CYCLES_MIN", "gpiv-cam_8h.html#ad489304d10b10965ae5d823357548748", null ],
    [ "GPIV_CAMPAR_DEFAULT__CYCLES", "gpiv-cam_8h.html#a4f680edf53246907ed8fc67d063d4bd9", null ],
    [ "GPIV_CAMPAR_DEFAULT__FNAME", "gpiv-cam_8h.html#a230e4347bc560903a30efe5cc91f9d39", null ],
    [ "GPIV_CAMPAR_DEFAULT__MODE", "gpiv-cam_8h.html#af93a7e8e1689f367ad068e922727646e", null ],
    [ "GPIV_CAMPAR_KEY", "gpiv-cam_8h.html#a90aecfbfe6e710c381bad82cac7163b4", null ],
    [ "GPIV_CAMPAR_KEY__CYCLES", "gpiv-cam_8h.html#af76a6c5c6d96fba37db65ba9672fcdaf", null ],
    [ "GPIV_CAMPAR_KEY__FNAME", "gpiv-cam_8h.html#a199f79dba5fc3902217bb198ac8649e6", null ],
    [ "GPIV_CAMPAR_KEY__MODE", "gpiv-cam_8h.html#aa0e0dc92171647dc51bc9c8766ce5838", null ],
    [ "GpivCamPar", "gpiv-cam_8h.html#af9a3668d7ecc39144914f00a4508bf9c", null ],
    [ "GpivCamVar", "gpiv-cam_8h.html#a650d46ccd46d96852b3c890d71d1df48", null ],
    [ "GpivCamMode", "gpiv-cam_8h.html#a59d3dcc93601706d4addef9e7b704cc8", [
      [ "GPIV_CAM_MODE__PERIODIC", "gpiv-cam_8h.html#a59d3dcc93601706d4addef9e7b704cc8aa4a8f9ada9d569bbab97337e517e001d", null ],
      [ "GPIV_CAM_MODE__DURATION", "gpiv-cam_8h.html#a59d3dcc93601706d4addef9e7b704cc8a9f639d33743ce1028cac7d988339760a", null ],
      [ "GPIV_CAM_MODE__ONE_SHOT_IRQ", "gpiv-cam_8h.html#a59d3dcc93601706d4addef9e7b704cc8aaa10bea5d98f65aed31e78a2277f6be9", null ],
      [ "GPIV_CAM_MODE__TRIGGER_IRQ", "gpiv-cam_8h.html#a59d3dcc93601706d4addef9e7b704cc8a343270632d6663bed496ad759638c74f", null ],
      [ "GPIV_CAM_MODE__INCREMENT", "gpiv-cam_8h.html#a59d3dcc93601706d4addef9e7b704cc8add2934daabb8f23d246748c1e03aa26d", null ],
      [ "GPIV_CAM_MODE__DOUBLE", "gpiv-cam_8h.html#a59d3dcc93601706d4addef9e7b704cc8a533d6fc0e22ee7c0145ddc589e3e03d8", null ]
    ] ],
    [ "gpiv_cam_check_parameters_read", "gpiv-cam_8h.html#a46ad84c8e6ea3878b74138fcfadba41b", null ],
    [ "gpiv_cam_default_parameters", "gpiv-cam_8h.html#a0c9c97c53cd02648d5cceaa4d2c4f755", null ],
    [ "gpiv_cam_free_camvar", "gpiv-cam_8h.html#a4d4b25877c2f575d38ec70b537908956", null ],
    [ "gpiv_cam_get_camvar", "gpiv-cam_8h.html#ad3913265575357e2546081c58a1bf718", null ],
    [ "gpiv_cam_parameters__set", "gpiv-cam_8h.html#ac0a0a34912953ea440130398d3ad275b", null ],
    [ "gpiv_cam_print_parameters", "gpiv-cam_8h.html#a7b4445505c33bc4bd0245db41323d15c", null ],
    [ "gpiv_cam_read_parameters", "gpiv-cam_8h.html#abf69210895576d63922d5e9357e1e833", null ],
    [ "gpiv_cam_test_parameter", "gpiv-cam_8h.html#a39b0c795b5e68069a7f8732288ab1ec9", null ]
];