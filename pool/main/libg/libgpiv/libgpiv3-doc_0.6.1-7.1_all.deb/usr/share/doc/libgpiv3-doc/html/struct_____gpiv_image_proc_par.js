var struct_____gpiv_image_proc_par =
[
    [ "bit", "struct_____gpiv_image_proc_par.html#a1692c85f98d4acb0ddfa28fe6c6e30da", null ],
    [ "bit__set", "struct_____gpiv_image_proc_par.html#adf0aacf4d97fde36556838dbe90fb005", null ],
    [ "filter", "struct_____gpiv_image_proc_par.html#a55edb3846141dcd568bd8b7afacd7359", null ],
    [ "filter__set", "struct_____gpiv_image_proc_par.html#a8a4c1615d228b653fed229c9b608d7f6", null ],
    [ "smooth_operator", "struct_____gpiv_image_proc_par.html#ad0ed241a9fd0dba98c5d8135f2fdaa08", null ],
    [ "smooth_operator__set", "struct_____gpiv_image_proc_par.html#a334b67a25d7a19a137a39a65cb697f4c", null ],
    [ "threshold", "struct_____gpiv_image_proc_par.html#a84b7ec66cfd289c1a70e867cf6dbe507", null ],
    [ "threshold__set", "struct_____gpiv_image_proc_par.html#a91d918b99ed9ccea13d693b3401d81ac", null ],
    [ "window", "struct_____gpiv_image_proc_par.html#aa51c260f0e5980c824711c398f513143", null ],
    [ "window__set", "struct_____gpiv_image_proc_par.html#afb904c99d0dfa71d1c054a484848b18f", null ]
];