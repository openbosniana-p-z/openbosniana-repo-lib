var gpiv_valid__par_8h =
[
    [ "__GpivValidPar", "struct_____gpiv_valid_par.html", "struct_____gpiv_valid_par" ],
    [ "GPIV_VALIDPAR_KEY", "gpiv-valid__par_8h.html#a7df4fd96e81a728de198b990247dd0be", null ],
    [ "GPIV_VALIDPAR_MAX__NEIGHBORS", "gpiv-valid__par_8h.html#a699cf33f248b4fa68e6c99d82c96a73e", null ],
    [ "GpivValidPar", "gpiv-valid__par_8h.html#a5b0fa496d1389c1251558891f5be6c0a", null ],
    [ "ResiduType", "gpiv-valid__par_8h.html#ace4fe6a2b4e89362d4e229d91fbdfdf7", [
      [ "GPIV_VALID_RESIDUTYPE__SNR", "gpiv-valid__par_8h.html#ace4fe6a2b4e89362d4e229d91fbdfdf7a33c8e7e7f02ff885256878dc7e7dbb2e", null ],
      [ "GPIV_VALID_RESIDUTYPE__MEDIAN", "gpiv-valid__par_8h.html#ace4fe6a2b4e89362d4e229d91fbdfdf7a09edae6c922afdd5e4afb5f1ed27f957", null ],
      [ "GPIV_VALID_RESIDUTYPE__NORMMEDIAN", "gpiv-valid__par_8h.html#ace4fe6a2b4e89362d4e229d91fbdfdf7ae99c453df13faff818ca7f02ca32c272", null ]
    ] ],
    [ "SubstitutionType", "gpiv-valid__par_8h.html#a8787de801c3bacdff13a7df70cc9dc89", [
      [ "GPIV_VALID_SUBSTYPE__NONE", "gpiv-valid__par_8h.html#a8787de801c3bacdff13a7df70cc9dc89a0808278243507b50f980d31760c0952a", null ],
      [ "GPIV_VALID_SUBSTYPE__L_MEAN", "gpiv-valid__par_8h.html#a8787de801c3bacdff13a7df70cc9dc89ab07e3ff686bee8e86933ca6af1c2609b", null ],
      [ "GPIV_VALID_SUBSTYPE__MEDIAN", "gpiv-valid__par_8h.html#a8787de801c3bacdff13a7df70cc9dc89a3e7142e31570b2ff2028553b0279ec6b", null ],
      [ "GPIV_VALID_SUBSTYPE__COR_PEAK", "gpiv-valid__par_8h.html#a8787de801c3bacdff13a7df70cc9dc89a3ccdac098e739eaa024663587d22705e", null ]
    ] ],
    [ "gpiv_valid_check_parameters_read", "gpiv-valid__par_8h.html#acab56dfc2854fd4c487114017b9e6ed2", null ],
    [ "gpiv_valid_cp_parameters", "gpiv-valid__par_8h.html#a917162c44940d317f2b7d9b5ef2d48d4", null ],
    [ "gpiv_valid_default_parameters", "gpiv-valid__par_8h.html#ab4885f0f6f63acf183aa2443325637e9", null ],
    [ "gpiv_valid_dupl_parameters", "gpiv-valid__par_8h.html#a8acb8e0ca01ba5f08957c98debe173a7", null ],
    [ "gpiv_valid_fread_hdf5_parameters", "gpiv-valid__par_8h.html#ad0ad8f2a6fc2dd4f6aab6fbc4af16367", null ],
    [ "gpiv_valid_fwrite_hdf5_parameters", "gpiv-valid__par_8h.html#a473d0fc72454a6e9edcf0d3ae9af16d7", null ],
    [ "gpiv_valid_get_parameters_from_resources", "gpiv-valid__par_8h.html#a7561e73e85bb0eaeac8ecf252b50ee85", null ],
    [ "gpiv_valid_parameters_set", "gpiv-valid__par_8h.html#a1e0ed5e3dfa6571f242639764fc79768", null ],
    [ "gpiv_valid_print_parameters", "gpiv-valid__par_8h.html#a11d5533e641b653bb1e85d1aea1a900a", null ],
    [ "gpiv_valid_read_parameters", "gpiv-valid__par_8h.html#ae2519636b5b2ffac4e0ac2c14ded5834", null ],
    [ "gpiv_valid_testadjust_parameters", "gpiv-valid__par_8h.html#a2688f28d78047233901b918da7d6f13c", null ],
    [ "gpiv_valid_testonly_parameters", "gpiv-valid__par_8h.html#a3bb6b964a761afac84bb76b8ffb975b8", null ]
];