var struct_____gpiv_cam_var =
[
    [ "camera", "struct_____gpiv_cam_var.html#a7745cecfa01b22ded9c0dc5df488b622", null ],
    [ "camera_nodes", "struct_____gpiv_cam_var.html#a11d99c0aafa6efde90dc6d98540a9dbf", null ],
    [ "capture", "struct_____gpiv_cam_var.html#a1b2fca87f8ca41c00a8d8bc251f6f112", null ],
    [ "feature_info", "struct_____gpiv_cam_var.html#a6b29467c84a1bffe798b8197f2b4af00", null ],
    [ "feature_set", "struct_____gpiv_cam_var.html#a125af8960204b663919a838b9de2ebc5", null ],
    [ "handle", "struct_____gpiv_cam_var.html#af638dd28b3579898fbface0b6db52d27", null ],
    [ "maxspeed", "struct_____gpiv_cam_var.html#a37ed1cd013c53b60ab06115679f36504", null ],
    [ "misc_info", "struct_____gpiv_cam_var.html#a7b6bd392f25a3802886815f06e527b7c", null ],
    [ "numCameras", "struct_____gpiv_cam_var.html#abcc081033fe9cea79f9570322967fb43", null ],
    [ "numNodes", "struct_____gpiv_cam_var.html#a16d51b9af5817f7a59b8ff3c4fdd87c2", null ],
    [ "port", "struct_____gpiv_cam_var.html#a30d7e1dc4799ef27af6426fda2c3fc3b", null ]
];