var struct_____gpiv_valid_par =
[
    [ "data_yield", "struct_____gpiv_valid_par.html#aa133fe785789709c054c2eded7998271", null ],
    [ "data_yield__set", "struct_____gpiv_valid_par.html#ac29c480427bf67e83bcacada68304f05", null ],
    [ "histo_type", "struct_____gpiv_valid_par.html#ae2ee86d0d7776f9d712aa8b519e8b842", null ],
    [ "histo_type__set", "struct_____gpiv_valid_par.html#a06049a668872e40e3b8ca5b523be151b", null ],
    [ "neighbors", "struct_____gpiv_valid_par.html#a3b100c4a3ed1854879e405768e8382ac", null ],
    [ "neighbors__set", "struct_____gpiv_valid_par.html#a6a4e38087a23c465b2f3623a8bb3b8b0", null ],
    [ "residu_max", "struct_____gpiv_valid_par.html#a06339d2538a3d8cc05dd138b186021c3", null ],
    [ "residu_max__set", "struct_____gpiv_valid_par.html#a123ea9d80de64d4733ad75a0c5c54473", null ],
    [ "residu_type", "struct_____gpiv_valid_par.html#a2033bd030eaedad32e7a93fe5af11e73", null ],
    [ "residu_type__set", "struct_____gpiv_valid_par.html#a40b4d9cfc0e2278102cf0f1e0bf8be74", null ],
    [ "subst_type", "struct_____gpiv_valid_par.html#a74ccee3b97ad821f781d3e0d86c8d7f2", null ],
    [ "subst_type__set", "struct_____gpiv_valid_par.html#a3a189a0f0e61bfa2f6911a6895ebca75", null ]
];