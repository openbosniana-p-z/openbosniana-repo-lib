var struct_____gpiv_scalar_data =
[
    [ "comment", "struct_____gpiv_scalar_data.html#ad0421aa66e6230ff97ae7d3767e360e0", null ],
    [ "flag", "struct_____gpiv_scalar_data.html#af162fb954901aeacae4724ec3aae8ca5", null ],
    [ "nx", "struct_____gpiv_scalar_data.html#a474972dcf05bf4c0bd50352c83a1c80c", null ],
    [ "ny", "struct_____gpiv_scalar_data.html#a0cee78b2834040c61792db1854d4e74f", null ],
    [ "point_x", "struct_____gpiv_scalar_data.html#a1cc77d404732f7dfbcdde775992244f6", null ],
    [ "point_y", "struct_____gpiv_scalar_data.html#a4f8511dbe99aa11d4b05b71fd51b550d", null ],
    [ "scalar", "struct_____gpiv_scalar_data.html#a973c5781fef615a2f31a317563453cd0", null ],
    [ "scale", "struct_____gpiv_scalar_data.html#a31f6824b02fd84c96aee411db48d365d", null ],
    [ "scale__set", "struct_____gpiv_scalar_data.html#a46699a3e680390e9ca6c67d8226a4a17", null ]
];