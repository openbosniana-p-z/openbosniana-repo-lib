var struct_____gpiv_cam_par =
[
    [ "cycles", "struct_____gpiv_cam_par.html#a169957a06b274f3708f462277ad59a52", null ],
    [ "cycles__set", "struct_____gpiv_cam_par.html#aa6c83cf257edbb023e7b97c11f9dc57f", null ],
    [ "fname", "struct_____gpiv_cam_par.html#a122b1dfbd8f8efaa32614fbffe8ae49a", null ],
    [ "fname__set", "struct_____gpiv_cam_par.html#af43e664b022a328962ae4b87d114a917", null ],
    [ "mode", "struct_____gpiv_cam_par.html#a72a825e37ea5894ccc8d0322e2deafbb", null ],
    [ "mode__set", "struct_____gpiv_cam_par.html#ac0e09baa3b951f811b3cf1572250c567", null ]
];