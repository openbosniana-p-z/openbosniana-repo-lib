
package GO::Handlers::lexanalysis2sql;
use base qw(GO::Handlers::abstract_sql_writer GO::Handlers::lexanalysis);
use strict;

1;
