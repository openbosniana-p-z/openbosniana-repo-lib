# stag-handle.pl -p GO::Parsers::GoOntParser -m <THIS> function/function.ontology

package GO::Handlers::xml;
use base qw(Data::Stag::XMLWriter Exporter);
1;
