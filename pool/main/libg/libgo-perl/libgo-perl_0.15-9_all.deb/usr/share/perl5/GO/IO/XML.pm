package GO::IO::XML;
use base qw(GO::IO::RDFXML);
1;




