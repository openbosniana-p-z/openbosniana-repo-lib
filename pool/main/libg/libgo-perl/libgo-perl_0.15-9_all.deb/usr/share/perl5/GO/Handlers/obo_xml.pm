# stag-handle.pl -p GO::Parsers::GoOntParser -m <THIS> function/function.ontology

package GO::Handlers::obo_xml;
use base qw(Data::Stag::XMLWriter Exporter);
1;
