package GO::Handlers::obo;
use base qw(GO::Handlers::obo_text);
1;
