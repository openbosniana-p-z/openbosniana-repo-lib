package GO::Parsers::obo_parser;
use base qw(GO::Parsers::obo_text_parser);
1;
