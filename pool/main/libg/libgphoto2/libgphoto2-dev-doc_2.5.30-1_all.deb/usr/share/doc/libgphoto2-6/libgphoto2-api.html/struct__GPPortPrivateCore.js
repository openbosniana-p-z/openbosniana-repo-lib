var struct__GPPortPrivateCore =
[
    [ "error", "struct__GPPortPrivateCore.html#abe1878c0c093a21e926dcccd6c2ea335", null ],
    [ "info", "struct__GPPortPrivateCore.html#a01acb7d55497723970bf96a9bbe78d3f", null ],
    [ "lh", "struct__GPPortPrivateCore.html#a250d684685d84b01240c072a8c151c17", null ],
    [ "ops", "struct__GPPortPrivateCore.html#a1fd9de117f1f3519bf325cf2fc77ef8c", null ]
];