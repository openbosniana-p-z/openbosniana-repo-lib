var gphoto2_library_8c =
[
    [ "camera_abilities", "gphoto2-library_8c.html#a14e65a4ed26c2c6e19c54fce9325d1a4", null ],
    [ "camera_id", "gphoto2-library_8c.html#a6b9e41589d48154298976ee65aa9f9d6", null ],
    [ "camera_init", "gphoto2-library_8c.html#af64e74d7d05e0b44b3bdaa031a24ec68", null ]
];