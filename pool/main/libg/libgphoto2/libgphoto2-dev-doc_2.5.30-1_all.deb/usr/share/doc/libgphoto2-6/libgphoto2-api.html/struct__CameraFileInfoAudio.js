var struct__CameraFileInfoAudio =
[
    [ "fields", "struct__CameraFileInfoAudio.html#aa929345276953d49d7be754bcd4f478a", null ],
    [ "size", "struct__CameraFileInfoAudio.html#a33ea53cadff0dccbf6ec3c3f466a99c9", null ],
    [ "status", "struct__CameraFileInfoAudio.html#a190a2dd6da89b72e4df72ee5c2014230", null ],
    [ "type", "struct__CameraFileInfoAudio.html#a7c3eaef785f49622bd15f3b1c51b1b95", null ]
];