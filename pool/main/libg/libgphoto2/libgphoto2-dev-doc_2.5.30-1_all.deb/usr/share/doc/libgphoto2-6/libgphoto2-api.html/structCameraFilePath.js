var structCameraFilePath =
[
    [ "folder", "structCameraFilePath.html#a576f3bdaaf2905795120cb4a8b274364", null ],
    [ "name", "structCameraFilePath.html#a26f1902eac5f6088334edbd1351e7ec9", null ]
];