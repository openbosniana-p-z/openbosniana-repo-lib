var globals_func =
[
    [ "c", "globals_func.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "f", "globals_func_f.html", null ],
    [ "g", "globals_func_g.html", null ],
    [ "p", "globals_func_p.html", null ],
    [ "s", "globals_func_s.html", null ]
];