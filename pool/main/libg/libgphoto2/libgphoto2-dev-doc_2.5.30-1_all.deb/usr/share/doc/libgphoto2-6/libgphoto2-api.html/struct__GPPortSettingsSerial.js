var struct__GPPortSettingsSerial =
[
    [ "bits", "struct__GPPortSettingsSerial.html#a699b27be2f7f039add66a8d586d8470c", null ],
    [ "parity", "struct__GPPortSettingsSerial.html#a66ae25e0d97ba9cf54cf30d7d6c40c70", null ],
    [ "port", "struct__GPPortSettingsSerial.html#a3c6725885e8d794b106e693a4d23277a", null ],
    [ "speed", "struct__GPPortSettingsSerial.html#a96548754f1af02d86de8c7b81d45b1d3", null ],
    [ "stopbits", "struct__GPPortSettingsSerial.html#aad83bb0af225730ec3e80539c66304a7", null ]
];