var struct__GPPortSettingsUSB =
[
    [ "altsetting", "struct__GPPortSettingsUSB.html#ae7646e7a75f9eca3f54803236076c4b3", null ],
    [ "config", "struct__GPPortSettingsUSB.html#a8029797699db63d05c648d331c2a7cbf", null ],
    [ "inep", "struct__GPPortSettingsUSB.html#a63ebb151a79e282d6ab1b5145d5cd2ef", null ],
    [ "intep", "struct__GPPortSettingsUSB.html#ad73d86a0eeb6297f9c96da2ccc512478", null ],
    [ "interface", "struct__GPPortSettingsUSB.html#ab19b0959c59e0976d4c09a8e4ddec61d", null ],
    [ "maxpacketsize", "struct__GPPortSettingsUSB.html#aafe4b13b8950ef9bd6fa76804fc948be", null ],
    [ "outep", "struct__GPPortSettingsUSB.html#a4902c422f6461bfbf01a4c7c31df09ca", null ],
    [ "port", "struct__GPPortSettingsUSB.html#a82659d453d3bd2dac315bd9782761e73", null ]
];