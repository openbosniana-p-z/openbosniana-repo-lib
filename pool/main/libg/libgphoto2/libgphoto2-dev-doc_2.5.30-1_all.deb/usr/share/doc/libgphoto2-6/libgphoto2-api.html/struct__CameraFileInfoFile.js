var struct__CameraFileInfoFile =
[
    [ "fields", "struct__CameraFileInfoFile.html#a5e3516f901c3f3a1f94a4ee8bda370c2", null ],
    [ "height", "struct__CameraFileInfoFile.html#af076fe6da9612a0167acf489c40f31e8", null ],
    [ "mtime", "struct__CameraFileInfoFile.html#ae7acce7dab662a7dfb088602176ac20b", null ],
    [ "permissions", "struct__CameraFileInfoFile.html#a6f4e10ef142ae1126784ff1f826a78fe", null ],
    [ "size", "struct__CameraFileInfoFile.html#a78631442027c5f7134498ba323891ed3", null ],
    [ "status", "struct__CameraFileInfoFile.html#a363772961bf2fc2e90c27120849e8010", null ],
    [ "type", "struct__CameraFileInfoFile.html#a8b798b3031a1998be77beb5ba547cb62", null ],
    [ "width", "struct__CameraFileInfoFile.html#a8cc5d010274aec1dfc222f1649133e2f", null ]
];