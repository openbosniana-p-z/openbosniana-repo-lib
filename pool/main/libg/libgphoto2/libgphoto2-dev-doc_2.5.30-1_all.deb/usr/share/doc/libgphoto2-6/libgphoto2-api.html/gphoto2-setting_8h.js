var gphoto2_setting_8h =
[
    [ "gp_setting_get", "gphoto2-setting_8h.html#a4b50249c04f6a48156bad839827e67b7", null ],
    [ "gp_setting_set", "gphoto2-setting_8h.html#a6100f1cf5f3e90c2491807b6db1796af", null ]
];