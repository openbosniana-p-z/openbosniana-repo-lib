var structCameraText =
[
    [ "text", "structCameraText.html#af37011bda3c08a5b85d996a8a96a1175", null ]
];