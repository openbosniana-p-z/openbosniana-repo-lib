var struct__Camera =
[
    [ "pc", "struct__Camera.html#aa1e698a6fa5414e25381db64c7471e40", null ],
    [ "pl", "struct__Camera.html#a640193a6f18e834a87e71bc9dd3fedd2", null ]
];