var dir_4206fa17ee070de85e5fb63facf13fa1 =
[
    [ "gphoto2-abilities-list.h", "gphoto2-abilities-list_8h.html", "gphoto2-abilities-list_8h" ],
    [ "gphoto2-camera.h", "gphoto2-camera_8h.html", "gphoto2-camera_8h" ],
    [ "gphoto2-context.h", "gphoto2-context_8h.html", "gphoto2-context_8h" ],
    [ "gphoto2-file.h", "gphoto2-file_8h.html", "gphoto2-file_8h" ],
    [ "gphoto2-filesys.h", "gphoto2-filesys_8h.html", "gphoto2-filesys_8h" ],
    [ "gphoto2-library.h", "gphoto2-library_8h.html", "gphoto2-library_8h" ],
    [ "gphoto2-list.h", "gphoto2-list_8h.html", "gphoto2-list_8h" ],
    [ "gphoto2-result.h", "gphoto2-result_8h.html", "gphoto2-result_8h" ],
    [ "gphoto2-setting.h", "gphoto2-setting_8h.html", "gphoto2-setting_8h" ],
    [ "gphoto2-version.h", "gphoto2-version_8h.html", null ],
    [ "gphoto2-widget.h", "gphoto2-widget_8h.html", "gphoto2-widget_8h" ],
    [ "gphoto2.h", "gphoto2_8h.html", null ]
];