var dir_68c4d028e8e6091a637f06831eeab3d9 =
[
    [ "gphoto2", "dir_ff2570e7e5c377838c8e56ea8c3b24f7.html", "dir_ff2570e7e5c377838c8e56ea8c3b24f7" ],
    [ "libgphoto2_port", "dir_6b27e2d59bc0984e94c7e2a478593fae.html", "dir_6b27e2d59bc0984e94c7e2a478593fae" ]
];