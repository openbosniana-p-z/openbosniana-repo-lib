var gphoto2_port_result_8c =
[
    [ "gp_port_result_as_string", "gphoto2-port-result_8c.html#adf4aef611a5095fea6c462573acad818", null ]
];