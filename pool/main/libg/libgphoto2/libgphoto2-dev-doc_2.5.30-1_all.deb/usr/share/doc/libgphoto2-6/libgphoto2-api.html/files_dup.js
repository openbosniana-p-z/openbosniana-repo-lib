var files_dup =
[
    [ "camlibs", "dir_72b6eb78ea8bf859fcb0e4198a96160a.html", "dir_72b6eb78ea8bf859fcb0e4198a96160a" ],
    [ "gphoto2", "dir_4206fa17ee070de85e5fb63facf13fa1.html", "dir_4206fa17ee070de85e5fb63facf13fa1" ],
    [ "libgphoto2", "dir_df723b3f25cfe80b0e773fc78a5873a4.html", "dir_df723b3f25cfe80b0e773fc78a5873a4" ],
    [ "libgphoto2_port", "dir_68c4d028e8e6091a637f06831eeab3d9.html", "dir_68c4d028e8e6091a637f06831eeab3d9" ]
];