var gphoto2_result_8c =
[
    [ "gp_result_as_string", "gphoto2-result_8c.html#ac0756fbd093a7848d75b44344fc40053", null ]
];