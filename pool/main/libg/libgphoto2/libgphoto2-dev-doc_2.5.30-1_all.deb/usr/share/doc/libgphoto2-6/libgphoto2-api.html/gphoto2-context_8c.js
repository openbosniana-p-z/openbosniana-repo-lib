var gphoto2_context_8c =
[
    [ "_GPContext", "struct__GPContext.html", null ],
    [ "gp_context_cancel", "gphoto2-context_8c.html#a1decda483ec848e9cfd0ce68fb35ba82", null ],
    [ "gp_context_idle", "gphoto2-context_8c.html#afefd086439808e0ea31fe982cf2bf742", null ],
    [ "gp_context_message", "gphoto2-context_8c.html#aaf988fc2b9e09b4054ac5988b683ed52", null ],
    [ "gp_context_new", "gphoto2-context_8c.html#acb292d0c149d54e7ce839e6f888d0cd5", null ],
    [ "gp_context_progress_start", "gphoto2-context_8c.html#a6d241a0d2941e08a4d918cd923b7d9f3", null ],
    [ "gp_context_question", "gphoto2-context_8c.html#a118cc634d4288bc3722391691bf89f0c", null ],
    [ "gp_context_ref", "gphoto2-context_8c.html#a941ca9159c54542bbdb3fc6f165f2851", null ],
    [ "gp_context_unref", "gphoto2-context_8c.html#ac015a1ed8c349b1bda9b0f652904d0ac", null ]
];