var gphoto2_port_info_list_8h =
[
    [ "GPPortType", "gphoto2-port-info-list_8h.html#a0607050fab17d2a8c0cbff5747aadc06", [
      [ "GP_PORT_NONE", "gphoto2-port-info-list_8h.html#a0607050fab17d2a8c0cbff5747aadc06a69a2f40a085ca30689e9adca79304839", null ],
      [ "GP_PORT_SERIAL", "gphoto2-port-info-list_8h.html#a0607050fab17d2a8c0cbff5747aadc06aebfd6b4f7f72955e68a546eab8d6b081", null ],
      [ "GP_PORT_USB", "gphoto2-port-info-list_8h.html#a0607050fab17d2a8c0cbff5747aadc06add04533b323ad226aadbb648394308c8", null ],
      [ "GP_PORT_DISK", "gphoto2-port-info-list_8h.html#a0607050fab17d2a8c0cbff5747aadc06ad1d3c38f402a1ac16f2a368bf46ca695", null ],
      [ "GP_PORT_PTPIP", "gphoto2-port-info-list_8h.html#a0607050fab17d2a8c0cbff5747aadc06a55be3c4c7891e428a671bae0333aafea", null ],
      [ "GP_PORT_USB_DISK_DIRECT", "gphoto2-port-info-list_8h.html#a0607050fab17d2a8c0cbff5747aadc06ad617621b30d81296d06c2a31a3e5d13a", null ],
      [ "GP_PORT_USB_SCSI", "gphoto2-port-info-list_8h.html#a0607050fab17d2a8c0cbff5747aadc06a4b179bbb6f1ffe6cf74fca54aea94f2a", null ],
      [ "GP_PORT_IP", "gphoto2-port-info-list_8h.html#a0607050fab17d2a8c0cbff5747aadc06a36c923c944c7ade4127e9a9984630b98", null ]
    ] ],
    [ "gp_port_info_get_name", "gphoto2-port-info-list_8h.html#a9810bfba9c986f4d102cfaf649199f21", null ],
    [ "gp_port_info_get_path", "gphoto2-port-info-list_8h.html#a9736997967ed0bdb2ac0ace4e02df531", null ],
    [ "gp_port_info_get_type", "gphoto2-port-info-list_8h.html#a70f65ef80a59174adfa52c3e199752d4", null ],
    [ "gp_port_info_list_append", "gphoto2-port-info-list_8h.html#acbb59be40d7a67a13b7ffd26dcd3e9bb", null ],
    [ "gp_port_info_list_count", "gphoto2-port-info-list_8h.html#a29c6f449ee68a718c6c31b1f10202fda", null ],
    [ "gp_port_info_list_free", "gphoto2-port-info-list_8h.html#ab60c983825bfa2b6aa2fcb1e1a32b08f", null ],
    [ "gp_port_info_list_get_info", "gphoto2-port-info-list_8h.html#a85b97ad361854a8076b61be70fe85304", null ],
    [ "gp_port_info_list_load", "gphoto2-port-info-list_8h.html#a61b08d6eddea3c0e0c51869363632cea", null ],
    [ "gp_port_info_list_lookup_name", "gphoto2-port-info-list_8h.html#a45fd0887ac55832030f5f063d828c135", null ],
    [ "gp_port_info_list_lookup_path", "gphoto2-port-info-list_8h.html#ad925c660b558db82d22c62e8ae09c756", null ],
    [ "gp_port_info_list_new", "gphoto2-port-info-list_8h.html#a311d69766c99ba691b0d8f7bfb725d8a", null ],
    [ "gp_port_info_new", "gphoto2-port-info-list_8h.html#a8677c876b22dc6b4545e92fda9810ed4", null ],
    [ "gp_port_info_set_name", "gphoto2-port-info-list_8h.html#a2784f52a6cddb255967a1400e0e07a9a", null ],
    [ "gp_port_info_set_path", "gphoto2-port-info-list_8h.html#a4621674c74440cc4d68d24e45fc9f148", null ],
    [ "gp_port_info_set_type", "gphoto2-port-info-list_8h.html#a292ba5489b58951ccb1c858afe2f2798", null ],
    [ "gp_port_init_localedir", "gphoto2-port-info-list_8h.html#a165a0da49a5445bf3b0cb3a98b482455", null ],
    [ "gp_port_message_codeset", "gphoto2-port-info-list_8h.html#a50b6aadf6f944f92dd084933170498ea", null ]
];