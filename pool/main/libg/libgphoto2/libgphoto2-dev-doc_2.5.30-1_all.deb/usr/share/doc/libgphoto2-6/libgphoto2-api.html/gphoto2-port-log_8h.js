var gphoto2_port_log_8h =
[
    [ "GP_LOG_ALL", "gphoto2-port-log_8h.html#ab9d873393f29f25bb32cb8fea18e0024", null ],
    [ "GPLogFunc", "gphoto2-port-log_8h.html#a15b313ab823ec9df21b2eacfa4e19720", null ],
    [ "GPLogLevel", "gphoto2-port-log_8h.html#abd2f5081afa2596ee01a61415fcdb06b", [
      [ "GP_LOG_ERROR", "gphoto2-port-log_8h.html#abd2f5081afa2596ee01a61415fcdb06ba1fbaa945332b1e324217c2a4e27015dd", null ],
      [ "GP_LOG_VERBOSE", "gphoto2-port-log_8h.html#abd2f5081afa2596ee01a61415fcdb06ba055df478ccbb83e8b7c9c2ac9ee4a65c", null ],
      [ "GP_LOG_DEBUG", "gphoto2-port-log_8h.html#abd2f5081afa2596ee01a61415fcdb06badfd0d1ea537692a3dd8acc3b5675c9d2", null ],
      [ "GP_LOG_DATA", "gphoto2-port-log_8h.html#abd2f5081afa2596ee01a61415fcdb06bab7502e71c4972bf803722a33b99be75f", null ]
    ] ],
    [ "gp_log", "gphoto2-port-log_8h.html#a77325969d9eb7e1b9c2285233c7b3862", null ],
    [ "gp_log_add_func", "gphoto2-port-log_8h.html#aad08200a2e1b98c54ba32e8c80bfac6c", null ],
    [ "gp_log_data", "gphoto2-port-log_8h.html#acb3fc0f7a49dd49fa8bdbe4cdaacdd0a", null ],
    [ "gp_log_remove_func", "gphoto2-port-log_8h.html#a0b14529482e5bc725bcc003583337ea7", null ],
    [ "gp_logv", "gphoto2-port-log_8h.html#a07601ec204167a55885e02b80edd3fcf", null ]
];