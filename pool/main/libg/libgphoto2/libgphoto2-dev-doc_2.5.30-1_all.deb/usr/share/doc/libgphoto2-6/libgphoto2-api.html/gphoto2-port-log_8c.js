var gphoto2_port_log_8c =
[
    [ "LogFunc", "structLogFunc.html", "structLogFunc" ],
    [ "HEXDUMP_BLOCK_DISTANCE", "gphoto2-port-log_8c.html#aa670fefafc10fc80dba398d2050ce62c", null ],
    [ "HEXDUMP_COMPLETE_LINE", "gphoto2-port-log_8c.html#a25d3dff9fc4f2a43d2fb7c992d46e24b", null ],
    [ "HEXDUMP_INIT_X", "gphoto2-port-log_8c.html#a2bdf0f15991734c7a632c10714553277", null ],
    [ "HEXDUMP_INIT_Y", "gphoto2-port-log_8c.html#a4d62d7864045598068173b20f87380ea", null ],
    [ "HEXDUMP_LINE_WIDTH", "gphoto2-port-log_8c.html#accc780c98fc95b8ddce8f259c1575745", null ],
    [ "HEXDUMP_MIDDLE", "gphoto2-port-log_8c.html#ae21578f6dac5be34d83475a83e271d73", null ],
    [ "HEXDUMP_OFFSET_WIDTH", "gphoto2-port-log_8c.html#a425183fc022968cf26219b38421b42ee", null ],
    [ "gp_log", "gphoto2-port-log_8c.html#a77325969d9eb7e1b9c2285233c7b3862", null ],
    [ "gp_log_add_func", "gphoto2-port-log_8c.html#aad08200a2e1b98c54ba32e8c80bfac6c", null ],
    [ "gp_log_data", "gphoto2-port-log_8c.html#acb3fc0f7a49dd49fa8bdbe4cdaacdd0a", null ],
    [ "gp_log_remove_func", "gphoto2-port-log_8c.html#a0b14529482e5bc725bcc003583337ea7", null ],
    [ "gp_logv", "gphoto2-port-log_8c.html#a07601ec204167a55885e02b80edd3fcf", null ]
];