var classgig_1_1MidiRule =
[
    [ "~MidiRule", "classgig_1_1MidiRule.html#a2249119c36d155d3584dba68d52b9e2b", null ],
    [ "UpdateChunks", "classgig_1_1MidiRule.html#a65520a911a5e94c445905e91ac6a8be3", null ],
    [ "Instrument", "classgig_1_1MidiRule.html#a2ff0e65835bfc4a6510c2a5e3c1fe8fb", null ]
];