var classgig_1_1MidiRuleUnknown =
[
    [ "MidiRuleUnknown", "classgig_1_1MidiRuleUnknown.html#a03b84c05c45d0d81ed965ea836765e4b", null ],
    [ "UpdateChunks", "classgig_1_1MidiRuleUnknown.html#ad7a0f0125f401e78af854c472e838609", null ],
    [ "Instrument", "classgig_1_1MidiRuleUnknown.html#a2ff0e65835bfc4a6510c2a5e3c1fe8fb", null ]
];