var classKorg_1_1Exception =
[
    [ "Exception", "classKorg_1_1Exception.html#ae30eefd4d0aaff7e194332d8d4a9721a", null ],
    [ "PrintMessage", "classKorg_1_1Exception.html#a3778fd0b0e80e21d958b18eb6024165f", null ],
    [ "Message", "classKorg_1_1Exception.html#a18da67273067e2e0a84477518219b4a6", null ]
];