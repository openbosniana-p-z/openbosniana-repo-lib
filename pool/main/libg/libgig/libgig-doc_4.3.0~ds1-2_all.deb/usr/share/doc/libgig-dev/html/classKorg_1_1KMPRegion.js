var classKorg_1_1KMPRegion =
[
    [ "KMPRegion", "classKorg_1_1KMPRegion.html#adc655f778346dce3ad2fbbcec4165bc6", null ],
    [ "~KMPRegion", "classKorg_1_1KMPRegion.html#a8f1b460b4564f1fa7fd389c6d7420d4e", null ],
    [ "FullSampleFileName", "classKorg_1_1KMPRegion.html#a17f141a579f8de9a2b51eb42b01508b9", null ],
    [ "GetInstrument", "classKorg_1_1KMPRegion.html#a48bfeb4f98786d0384caaae81f8124a2", null ],
    [ "KMPInstrument", "classKorg_1_1KMPRegion.html#ae2cd90f1c046dbea04a23536cf43bb08", null ],
    [ "FilterCutoff", "classKorg_1_1KMPRegion.html#a95ea25cb4c43a5524fd83e804936f24e", null ],
    [ "Level", "classKorg_1_1KMPRegion.html#a6a63593ab02a010d1666a77a660be45a", null ],
    [ "OriginalKey", "classKorg_1_1KMPRegion.html#a72256eca59d7c9401f3ac0113d4465c0", null ],
    [ "Pan", "classKorg_1_1KMPRegion.html#a996f53b8392edaddba37bdf1be756c6e", null ],
    [ "SampleFileName", "classKorg_1_1KMPRegion.html#a067f724bfe12a6ea206c3f38256d61c9", null ],
    [ "TopKey", "classKorg_1_1KMPRegion.html#ac9a181f7437c1c27e908d90a82b2fc97", null ],
    [ "Transpose", "classKorg_1_1KMPRegion.html#a495398f15566717a0c4fdc0c04904bd4", null ],
    [ "Tune", "classKorg_1_1KMPRegion.html#a25a04b4032f0bc8b1b6a1a0b50d3d052", null ]
];