var namespaceSerialization =
[
    [ "UID", "classSerialization_1_1UID.html", "classSerialization_1_1UID" ],
    [ "DataType", "classSerialization_1_1DataType.html", "classSerialization_1_1DataType" ],
    [ "Member", "classSerialization_1_1Member.html", "classSerialization_1_1Member" ],
    [ "Object", "classSerialization_1_1Object.html", "classSerialization_1_1Object" ],
    [ "Archive", "classSerialization_1_1Archive.html", "classSerialization_1_1Archive" ],
    [ "Exception", "classSerialization_1_1Exception.html", "classSerialization_1_1Exception" ],
    [ "Array", "namespaceSerialization.html#ab89d302e3ac7badab8e31d0026643be4", null ],
    [ "ID", "namespaceSerialization.html#a0a6a9a523d799cd7b4dcc8bfe573bbb9", null ],
    [ "Map", "namespaceSerialization.html#a9afe07985eedde106591346603767c58", null ],
    [ "RawData", "namespaceSerialization.html#ac2a2b8eaea1928d3faacf4c3a57ee1e2", null ],
    [ "Set", "namespaceSerialization.html#a58e2292bda0a3814577b25419f547595", null ],
    [ "String", "namespaceSerialization.html#a7db3e1b680778131c10815e8509efa23", null ],
    [ "UIDChain", "namespaceSerialization.html#aa6ec113cd1af5dd3297ccc63d4d25c4d", null ],
    [ "Version", "namespaceSerialization.html#aa67af1774d76bce729e640d685964934", null ],
    [ "time_base_t", "namespaceSerialization.html#af7af2dcb41c42e9711bb53e2e4e94d5a", [
      [ "LOCAL_TIME", "namespaceSerialization.html#af7af2dcb41c42e9711bb53e2e4e94d5aabfe7b5a404e0caf8a3e04b4c660c894f", null ],
      [ "UTC_TIME", "namespaceSerialization.html#af7af2dcb41c42e9711bb53e2e4e94d5aa32ecb1026fcbe669997e9fa56e91df20", null ]
    ] ],
    [ "_encode", "namespaceSerialization.html#aa40f003f8c93c031b7024b2f52348870", null ],
    [ "_stringToNumber", "namespaceSerialization.html#a3c83a9b628b72afae6dd3b80ae891b48", null ],
    [ "_stringToNumber", "namespaceSerialization.html#a59ec5a3ccc6bb939898f41c09d8f1cb7", null ],
    [ "IsClass", "namespaceSerialization.html#a7d1d2803be85a41c204555b1ecd8c373", null ],
    [ "IsEnum", "namespaceSerialization.html#a61d3b658ef82d7af51c78ff4de926c13", null ],
    [ "IsUnion", "namespaceSerialization.html#a064dd04769f6cff191c6e289aab8586c", null ],
    [ "toString", "namespaceSerialization.html#a760dcb46f1088980cf15d5cb5ae5ec7b", null ],
    [ "toString", "namespaceSerialization.html#a6e525b40a01b67d9e1a1bce250f38991", null ],
    [ "NO_UID", "namespaceSerialization.html#a51b840bb74ee1538697763b103ab725e", null ]
];