var namespaceKorg =
[
    [ "KSFSample", "classKorg_1_1KSFSample.html", "classKorg_1_1KSFSample" ],
    [ "KMPRegion", "classKorg_1_1KMPRegion.html", "classKorg_1_1KMPRegion" ],
    [ "KMPInstrument", "classKorg_1_1KMPInstrument.html", "classKorg_1_1KMPInstrument" ],
    [ "Exception", "classKorg_1_1Exception.html", "classKorg_1_1Exception" ],
    [ "buffer_t", "namespaceKorg.html#ada63b2cb3dc90054fd84fbf2a13a3791", null ],
    [ "String", "namespaceKorg.html#aab705af46a02c7ad7c050014666b6653", null ],
    [ "libraryName", "namespaceKorg.html#a5953e638e4e7cfc041c8606a5af07afc", null ],
    [ "libraryVersion", "namespaceKorg.html#a2f205140eddd7e48169848e0c9c2d868", null ],
    [ "readText", "namespaceKorg.html#a257f82e7e7c5d9ed35d595b04be716b3", null ],
    [ "readText12", "namespaceKorg.html#af917986075cdccaeaae0b2cdbbc539c8", null ],
    [ "readText16", "namespaceKorg.html#a5a341bd93e19f700a1e3b4f1110a01e0", null ],
    [ "readText24", "namespaceKorg.html#a5ecd1e8f605dfa8cd3da6677a057c481", null ],
    [ "removeFileTypeExtension", "namespaceKorg.html#afba6872fb6e9d00ee2d2d513e3fa7253", null ]
];