var classgig_1_1MidiRuleLegato =
[
    [ "MidiRuleLegato", "classgig_1_1MidiRuleLegato.html#a024d89ce940a81698f034aef4a107b13", null ],
    [ "MidiRuleLegato", "classgig_1_1MidiRuleLegato.html#a5eafcd073f98a59fa516c70ac370d950", null ],
    [ "UpdateChunks", "classgig_1_1MidiRuleLegato.html#ad30c24fe72001882e03bc523ab8422d8", null ],
    [ "Instrument", "classgig_1_1MidiRuleLegato.html#a2ff0e65835bfc4a6510c2a5e3c1fe8fb", null ],
    [ "AltSustain1Key", "classgig_1_1MidiRuleLegato.html#a92f9877c254a5851a111931c4e4e9e54", null ],
    [ "AltSustain2Key", "classgig_1_1MidiRuleLegato.html#ae2b8cf329f07406fd2489c070f3a928e", null ],
    [ "BypassController", "classgig_1_1MidiRuleLegato.html#af63f396a630da18a71d1765463d66b2c", null ],
    [ "BypassKey", "classgig_1_1MidiRuleLegato.html#a7ab8d0f94d15a2496601757bfe475e36", null ],
    [ "BypassUseController", "classgig_1_1MidiRuleLegato.html#abf0e7e17008dbe0982d609222fa1c91d", null ],
    [ "KeyRange", "classgig_1_1MidiRuleLegato.html#af13e8e71c8a7ce1b3a25a3e2a47bbdde", null ],
    [ "LegatoSamples", "classgig_1_1MidiRuleLegato.html#a340dd10cf089363f1b9ae80d0a223e11", null ],
    [ "ReleaseTime", "classgig_1_1MidiRuleLegato.html#ae76a57db494351c89be233465e43f69d", null ],
    [ "ReleaseTriggerKey", "classgig_1_1MidiRuleLegato.html#af4f8c5c50ea9c4fef071dea5ef27b900", null ],
    [ "ThresholdTime", "classgig_1_1MidiRuleLegato.html#a2c4afe818136585a599495a999b1d856", null ]
];