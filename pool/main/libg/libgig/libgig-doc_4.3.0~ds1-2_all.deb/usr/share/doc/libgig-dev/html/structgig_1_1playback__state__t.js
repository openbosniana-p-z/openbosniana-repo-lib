var structgig_1_1playback__state__t =
[
    [ "loop_cycles_left", "structgig_1_1playback__state__t.html#a1887ed4483f6e9adfabd0e27dab73533", null ],
    [ "position", "structgig_1_1playback__state__t.html#a4c0950516f1c83b42fd017b3d2b5cf0f", null ],
    [ "reverse", "structgig_1_1playback__state__t.html#a09d3145574d56d231618eeb21365e61d", null ]
];