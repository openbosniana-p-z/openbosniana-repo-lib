var structDLS_1_1version__t =
[
    [ "build", "structDLS_1_1version__t.html#a86bb6d4e6f6a03ce3f64340246d6bc88", null ],
    [ "major", "structDLS_1_1version__t.html#a797fecb55df3ae383f2150a4e3f771a1", null ],
    [ "minor", "structDLS_1_1version__t.html#abbc1e5551087b1b2ea177dd563974c2a", null ],
    [ "release", "structDLS_1_1version__t.html#a254041ed5d5f6e4bd98f0e301ba118c3", null ]
];