var classAkaiPartition =
[
    [ "Acquire", "classAkaiPartition.html#a26ae27a5d123e4924d8d7de5def76300", null ],
    [ "AkaiToAscii", "classAkaiPartition.html#a0e31933b3fbe62550a3d7d1a62893fc1", null ],
    [ "GetOffset", "classAkaiPartition.html#ad5783609f7e6843b1f7e37f5aecc32ee", null ],
    [ "GetParent", "classAkaiPartition.html#ae824cf9a92e52bdcc9013815eab0b636", null ],
    [ "GetVolume", "classAkaiPartition.html#a81f7b30c6a5640b65bd7f7c1b19cfe0d", null ],
    [ "GetVolume", "classAkaiPartition.html#a6d71f895cdf4339dc0b73a602dd1a1f3", null ],
    [ "IsEmpty", "classAkaiPartition.html#a03704478b11f5dd385837e776331b34f", null ],
    [ "ListVolumes", "classAkaiPartition.html#a0b13d0c35ea74007502d684c355494d2", null ],
    [ "ReadDirEntry", "classAkaiPartition.html#af51ed6c6dc962e529d59cd330a67b49f", null ],
    [ "ReadFAT", "classAkaiPartition.html#a0da6d86f1888ab3d9be52fd2eec1cecf", null ],
    [ "Release", "classAkaiPartition.html#a6b368d141486277ac2befb066649e6c8", null ],
    [ "SetOffset", "classAkaiPartition.html#a91e7cfd99367c478996bb2cd839e6242", null ],
    [ "AkaiDisk", "classAkaiPartition.html#a10bc588423e9282f04b87ea59bbc2ad7", null ]
];