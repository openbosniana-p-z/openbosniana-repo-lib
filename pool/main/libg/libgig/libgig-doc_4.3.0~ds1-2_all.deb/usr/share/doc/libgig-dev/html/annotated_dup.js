var annotated_dup =
[
    [ "DLS", "namespaceDLS.html", [
      [ "version_t", "structDLS_1_1version__t.html", "structDLS_1_1version__t" ],
      [ "dlsid_t", "structDLS_1_1dlsid__t.html", "structDLS_1_1dlsid__t" ],
      [ "range_t", "structDLS_1_1range__t.html", "structDLS_1_1range__t" ],
      [ "sample_loop_t", "structDLS_1_1sample__loop__t.html", "structDLS_1_1sample__loop__t" ],
      [ "Connection", "classDLS_1_1Connection.html", "classDLS_1_1Connection" ],
      [ "Storage", "classDLS_1_1Storage.html", "classDLS_1_1Storage" ],
      [ "Articulation", "classDLS_1_1Articulation.html", "classDLS_1_1Articulation" ],
      [ "Articulator", "classDLS_1_1Articulator.html", "classDLS_1_1Articulator" ],
      [ "Info", "classDLS_1_1Info.html", "classDLS_1_1Info" ],
      [ "Resource", "classDLS_1_1Resource.html", "classDLS_1_1Resource" ],
      [ "Sampler", "classDLS_1_1Sampler.html", "classDLS_1_1Sampler" ],
      [ "Sample", "classDLS_1_1Sample.html", "classDLS_1_1Sample" ],
      [ "Region", "classDLS_1_1Region.html", "classDLS_1_1Region" ],
      [ "Instrument", "classDLS_1_1Instrument.html", "classDLS_1_1Instrument" ],
      [ "File", "classDLS_1_1File.html", "classDLS_1_1File" ],
      [ "Exception", "classDLS_1_1Exception.html", "classDLS_1_1Exception" ]
    ] ],
    [ "gig", "namespacegig.html", [
      [ "range_t", "structgig_1_1range__t.html", "structgig_1_1range__t" ],
      [ "buffer_t", "structgig_1_1buffer__t.html", "structgig_1_1buffer__t" ],
      [ "leverage_ctrl_t", "structgig_1_1leverage__ctrl__t.html", "structgig_1_1leverage__ctrl__t" ],
      [ "dimension_def_t", "structgig_1_1dimension__def__t.html", "structgig_1_1dimension__def__t" ],
      [ "crossfade_t", "structgig_1_1crossfade__t.html", "structgig_1_1crossfade__t" ],
      [ "playback_state_t", "structgig_1_1playback__state__t.html", "structgig_1_1playback__state__t" ],
      [ "eg_opt_t", "structgig_1_1eg__opt__t.html", "structgig_1_1eg__opt__t" ],
      [ "DimensionRegion", "classgig_1_1DimensionRegion.html", "classgig_1_1DimensionRegion" ],
      [ "Sample", "classgig_1_1Sample.html", "classgig_1_1Sample" ],
      [ "Region", "classgig_1_1Region.html", "classgig_1_1Region" ],
      [ "MidiRule", "classgig_1_1MidiRule.html", "classgig_1_1MidiRule" ],
      [ "MidiRuleCtrlTrigger", "classgig_1_1MidiRuleCtrlTrigger.html", "classgig_1_1MidiRuleCtrlTrigger" ],
      [ "MidiRuleLegato", "classgig_1_1MidiRuleLegato.html", "classgig_1_1MidiRuleLegato" ],
      [ "MidiRuleAlternator", "classgig_1_1MidiRuleAlternator.html", "classgig_1_1MidiRuleAlternator" ],
      [ "MidiRuleUnknown", "classgig_1_1MidiRuleUnknown.html", "classgig_1_1MidiRuleUnknown" ],
      [ "Script", "classgig_1_1Script.html", "classgig_1_1Script" ],
      [ "ScriptGroup", "classgig_1_1ScriptGroup.html", "classgig_1_1ScriptGroup" ],
      [ "Instrument", "classgig_1_1Instrument.html", "classgig_1_1Instrument" ],
      [ "Group", "classgig_1_1Group.html", "classgig_1_1Group" ],
      [ "File", "classgig_1_1File.html", "classgig_1_1File" ],
      [ "Exception", "classgig_1_1Exception.html", "classgig_1_1Exception" ]
    ] ],
    [ "Korg", "namespaceKorg.html", [
      [ "KSFSample", "classKorg_1_1KSFSample.html", "classKorg_1_1KSFSample" ],
      [ "KMPRegion", "classKorg_1_1KMPRegion.html", "classKorg_1_1KMPRegion" ],
      [ "KMPInstrument", "classKorg_1_1KMPInstrument.html", "classKorg_1_1KMPInstrument" ],
      [ "Exception", "classKorg_1_1Exception.html", "classKorg_1_1Exception" ]
    ] ],
    [ "RIFF", "namespaceRIFF.html", [
      [ "progress_t", "structRIFF_1_1progress__t.html", "structRIFF_1_1progress__t" ],
      [ "Chunk", "classRIFF_1_1Chunk.html", "classRIFF_1_1Chunk" ],
      [ "List", "classRIFF_1_1List.html", "classRIFF_1_1List" ],
      [ "File", "classRIFF_1_1File.html", "classRIFF_1_1File" ],
      [ "Exception", "classRIFF_1_1Exception.html", "classRIFF_1_1Exception" ]
    ] ],
    [ "Serialization", "namespaceSerialization.html", [
      [ "UID", "classSerialization_1_1UID.html", "classSerialization_1_1UID" ],
      [ "DataType", "classSerialization_1_1DataType.html", "classSerialization_1_1DataType" ],
      [ "Member", "classSerialization_1_1Member.html", "classSerialization_1_1Member" ],
      [ "Object", "classSerialization_1_1Object.html", "classSerialization_1_1Object" ],
      [ "Archive", "classSerialization_1_1Archive.html", "classSerialization_1_1Archive" ],
      [ "Exception", "classSerialization_1_1Exception.html", "classSerialization_1_1Exception" ]
    ] ],
    [ "sf2", "namespacesf2.html", [
      [ "Region", "classsf2_1_1Region.html", "classsf2_1_1Region" ]
    ] ],
    [ "AkaiDisk", "classAkaiDisk.html", "classAkaiDisk" ],
    [ "AkaiPartition", "classAkaiPartition.html", "classAkaiPartition" ],
    [ "AkaiProgram", "classAkaiProgram.html", "classAkaiProgram" ],
    [ "AkaiVolume", "classAkaiVolume.html", "classAkaiVolume" ],
    [ "DiskImage", "classDiskImage.html", "classDiskImage" ]
];