/* libgda/libgdammconfig.h.  Generated from libgdammconfig.h.in by configure.  */
#ifndef _LIBGDAMM_CONFIG_H
#define _LIBGDAMM_CONFIG_H

#include <glibmmconfig.h>

/* Major version number of libgdamm. */
#define LIBGDAMM_MAJOR_VERSION 4

/* Micro version number of libgdamm. */
#define LIBGDAMM_MICRO_VERSION 11

/* Minor version number of libgdamm. */
#define LIBGDAMM_MINOR_VERSION 99

#endif /* !_LIBGDAMM_CONFIG_H */
