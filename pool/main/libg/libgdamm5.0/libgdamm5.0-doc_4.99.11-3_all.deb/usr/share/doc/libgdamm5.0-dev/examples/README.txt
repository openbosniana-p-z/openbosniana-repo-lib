simple: Reads the rows from a table.
introspection: Discovers the tables in a database, and the fields in that table.
list_data_sources: Discovers the data sources that the user has already configured.
