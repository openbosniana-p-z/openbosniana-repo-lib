package Genome::Env::GENOME_MODEL_ROOT;
our $VERSION = $Genome::VERSION;
1;
