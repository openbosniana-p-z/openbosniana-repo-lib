package Genome::Env::GENOME_VIEW_CACHE;
our $VERSION = $Genome::VERSION;
1;

