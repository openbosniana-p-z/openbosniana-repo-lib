package Genome::Env::GENOME_DEV_MODE;
our $VERSION = $Genome::VERSION;
1;
