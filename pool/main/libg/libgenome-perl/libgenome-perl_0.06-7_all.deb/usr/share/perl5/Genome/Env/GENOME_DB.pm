=pod

=head1 NAME

GENOME_DB  - Database root directory

=head1 DESCRIPTION

The GENOME_DB environment variable is the root directory for data base storage.

=head1 DEFAULT VALUE

 /var/lib/genome/db/

=cut

1;
