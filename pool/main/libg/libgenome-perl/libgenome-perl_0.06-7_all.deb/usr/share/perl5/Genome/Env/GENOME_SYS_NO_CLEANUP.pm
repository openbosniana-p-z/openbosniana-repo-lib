=pod

=head1 NAME

GENOME_TEST_DEV  - Temp files cleanup condition

=head1 DESCRIPTION

The GENOME_SYS_NO_CLEANUP environment variable, when set to true, will not clean up temporary files/directories on process exit

=head1 DEFAULT VALUE

 unset

=cut

1;
