=pod

=head1 NAME

GENOME_TEST_DEV  - Code test condition

=head1 DESCRIPTION

The GENOME_TEST_DEV environment variable, when set to true, runs tests
for incomplete/experiemental code.  

=head1 DEFAULT VALUE

 unset

=cut

1;
