# Contributing Guidelines

Fork repository on GitHub and submit a pull request.

Submitting a pull request indicates your acceptance of the license of the project.
