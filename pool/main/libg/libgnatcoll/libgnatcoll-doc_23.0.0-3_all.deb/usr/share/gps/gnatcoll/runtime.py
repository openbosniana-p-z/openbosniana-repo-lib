XML = r'''<?xml version="1.0"?>
<GPS>
  <documentation_file>
     <shell>Editor.edit "gnatcoll-wstring_list_builders.ads"</shell>
     <descr>GNATCOLL.WString_List_Builders</descr>
     <menu>/Help/GNAT Runtime/GNATCOLL/WString__List__Builders</menu>
     <category>GNAT Components Collection</category>
  </documentation_file>

</GPS>'''
import GPS
GPS.parse_xml(XML)
