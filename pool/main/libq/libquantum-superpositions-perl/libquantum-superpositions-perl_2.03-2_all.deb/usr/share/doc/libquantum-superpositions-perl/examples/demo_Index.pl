#!/usr/bin/perl

use Quantum::Superpositions BINARY => ["CORE::index"];
	
	print index(any("opts","tops","spot"),"o"), "\n";
	print index("stop",any("p","s")), "\n"; 
