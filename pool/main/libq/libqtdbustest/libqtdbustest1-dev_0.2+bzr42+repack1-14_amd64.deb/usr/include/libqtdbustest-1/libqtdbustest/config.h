/*
 * Copyright (C) 2013 Canonical, Ltd.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of version 3 of the GNU Lesser General Public License as published
 * by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Author: Pete Woods <pete.woods@canonical.com>
 */

#ifndef LIBQTDBUSTEST_CONFIG_H_
#define LIBQTDBUSTEST_CONFIG_H_

#define DBUS_SYSTEM_CONFIG_FILE "/usr/share/libqtdbustest/system.conf"
#define DBUS_SESSION_CONFIG_FILE "/usr/share/libqtdbustest/session.conf"
#define QTDBUSTEST_WATCHDOG_BIN "/usr/lib/x86_64-linux-gnu/libqtdbustest/watchdog"

#endif // LIBQTDBUSTEST_CONFIG_H_
