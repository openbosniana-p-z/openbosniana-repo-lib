#!/bin/sh -e

systemd_unit_exists() {
	[ $(systemctl list-unit-files "${1}*" | wc -l) -gt 3 ]
}

if systemd_unit_exists phonesim; then
    systemctl --user restart phonesim
    sleep 15
fi

exec "/usr/libexec/$(dpkg-architecture -qDEB_HOST_MULTIARCH)/libqofono-qt5/tests/${1?Test executable expected}"
