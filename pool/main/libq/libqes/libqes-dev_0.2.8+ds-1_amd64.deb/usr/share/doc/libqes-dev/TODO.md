KDM Todos:
---------

Error handling:

 - write tests

qes_seq:

 - split qes_seq_print into separate functions for FASTQ and FASTA. Also maybe
   allow line wrapping for FASTA.
