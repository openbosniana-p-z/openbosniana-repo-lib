/* src/rep_config.h.  Generated from rep_config.h.in by configure.  */
/* rep_config.h.in -- configure defs needed by library callers */

#ifndef REP_CONFIG_H
#define REP_CONFIG_H

/* Version number */
#define rep_VERSION "0.92.5"

/* libtool interface revision number */
#define rep_INTERFACE 16

/* Define if you have some flavour of Unix */
#define rep_HAVE_UNIX 1

/* An implicitly signed integer type, that a pointer can be cast to and
   from without dropping bits */
#define rep_PTR_SIZED_INT long int

/* This is either L or LL -- the suffix to append to integer constants
   of the above type */
#define rep_PTR_SIZED_INT_SUFFIX L

/* A string, the printf integer conversion of the above integer type,
   i.e. "" for int, "l" for long, "ll" for long long */
#define rep_PTR_SIZED_INT_CONV "l"

/* The number of bytes in the above type. */
#define rep_PTR_SIZED_INT_SIZEOF 8
#define rep_PTR_SIZED_INT_BITS (rep_PTR_SIZED_INT_SIZEOF * CHAR_BIT)

/* The minimum alignment of memory allocated by malloc(). The default of
   four should be ok for most systems? */
#define rep_MALLOC_ALIGNMENT 8

/* Defined if `long long int' is available */
#define rep_HAVE_LONG_LONG 1

#endif /* REP_CONFIG_H */
