﻿lopts = {}
lopts_default = {}
lopts['pt_BR'] = [u'grammar', u'cap', u'dup', u'pair', u'spaces', u'mdash', u'quotation', u'times', u'spaces2', u'ndash', u'apostrophe', u'ellipsis', u'spaces3', u'minus', u'metric', u'gerund', u'nonmetric', u'paronimo', u'composto', u'malmau', u'aha', u'meiameio', u'verbo', u'pronominal', u'pronome', u'porque']
lopts_default['pt_BR'] = [u'grammar', u'cap', u'dup', u'pair', u'spaces', u'mdash', u'quotation', u'spaces2', u'ndash', u'apostrophe', u'ellipsis', u'spaces3', u'metric', u'gerund', u'nonmetric', u'paronimo', u'composto', u'malmau', u'aha', u'meiameio', u'verbo', u'pronominal', u'pronome', u'porque']
