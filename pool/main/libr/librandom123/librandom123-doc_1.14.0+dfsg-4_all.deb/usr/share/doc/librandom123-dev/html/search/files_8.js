var searchData=
[
  ['readme_0',['README',['../examples_2README.html',1,'(Global Namespace)'],['../tests_2README.html',1,'(Global Namespace)']]],
  ['reinterpretctr_2ehpp_1',['ReinterpretCtr.hpp',['../ReinterpretCtr_8hpp.html',1,'']]],
  ['releasenotes_2edox_2',['releasenotes.dox',['../releasenotes_8dox.html',1,'']]]
];
