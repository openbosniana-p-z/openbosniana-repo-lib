var searchData=
[
  ['philox2x32_5fr_0',['philox2x32_R',['../philox_8h.html#acf0a4b82a9fd3f4695c04210df0cbefe',1,'philox.h']]],
  ['philox2x32keyinit_1',['philox2x32keyinit',['../philox_8h.html#ae5dd55c0697c37598c1fbce66457e124',1,'philox.h']]],
  ['philox2x64_5fr_2',['philox2x64_R',['../philox_8h.html#a03c068219ecebcc870afa14a330c0735',1,'philox.h']]],
  ['philox2x64keyinit_3',['philox2x64keyinit',['../philox_8h.html#a36b9225fcb73f91d116b424f721275f1',1,'philox.h']]],
  ['philox4x32_5fr_4',['philox4x32_R',['../philox_8h.html#a205fdd66786445b3e1c4157bd96d0967',1,'philox.h']]],
  ['philox4x32keyinit_5',['philox4x32keyinit',['../philox_8h.html#a5a012bb440c039eda46802b447c31851',1,'philox.h']]],
  ['philox4x64_5fr_6',['philox4x64_R',['../philox_8h.html#ac72571943d83caf2f79b7bd309a2ae92',1,'philox.h']]],
  ['philox4x64keyinit_7',['philox4x64keyinit',['../philox_8h.html#a101674ffc206e3bd600f9544de0c3c4a',1,'philox.h']]]
];
