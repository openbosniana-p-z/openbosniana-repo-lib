var searchData=
[
  ['random123_3a_20a_20library_20of_20counter_2dbased_20random_20number_20generators_0',['Random123: a Library of Counter-Based Random Number Generators',['../index.html',1,'']]],
  ['release_20notes_1',['Release Notes',['../Release_01Notes.html',1,'']]]
];
