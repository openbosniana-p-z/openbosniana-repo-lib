var searchData=
[
  ['preprocessor_20symbols_20for_20porting_20random123_20to_20different_20platforms_2e_0',['Preprocessor symbols for porting Random123 to different platforms.',['../porting.html',1,'']]]
];
