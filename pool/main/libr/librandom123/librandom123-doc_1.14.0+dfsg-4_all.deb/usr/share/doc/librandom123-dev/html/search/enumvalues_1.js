var searchData=
[
  ['philox2x64_5frounds_0',['philox2x64_rounds',['../group__PhiloxNxW.html#ggaca9df5cdadde758a63952daa97ddff91ae15befbf8ae3f2e93d6e49ea9e05b636',1,'philox.h']]],
  ['philox4x32_5frounds_1',['philox4x32_rounds',['../group__PhiloxNxW.html#gga67fd1bf4ed858d01663a7d6b219b97a2ac9dec73e096a7afb5d82f2388a7a5412',1,'philox.h']]],
  ['philox4x64_5frounds_2',['philox4x64_rounds',['../group__PhiloxNxW.html#ggaf603860d055cee96c75f6986641e9cada3407accddb6e873c1005a4ab2edcef67',1,'philox.h']]]
];
