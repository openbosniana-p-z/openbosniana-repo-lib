var searchData=
[
  ['double2_0',['double2',['../structr123_1_1double2.html',1,'r123']]]
];
