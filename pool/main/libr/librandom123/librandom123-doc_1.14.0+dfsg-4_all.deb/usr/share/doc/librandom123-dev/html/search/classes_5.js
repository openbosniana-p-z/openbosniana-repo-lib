var searchData=
[
  ['philox2x32_5fr_0',['Philox2x32_R',['../structr123_1_1Philox2x32__R.html',1,'r123']]],
  ['philox2x64_5fr_1',['Philox2x64_R',['../structr123_1_1Philox2x64__R.html',1,'r123']]],
  ['philox4x32_5fr_2',['Philox4x32_R',['../structr123_1_1Philox4x32__R.html',1,'r123']]],
  ['philox4x64_5fr_3',['Philox4x64_R',['../structr123_1_1Philox4x64__R.html',1,'r123']]]
];
