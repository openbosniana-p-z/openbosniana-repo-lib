var searchData=
[
  ['_5fmm_5fextract_5flo64_0',['_mm_extract_lo64',['../sse_8h.html#adac6aaf79c4428abcd30bf583eeb5450',1,'sse.h']]],
  ['_5fphilox2xwbumpkey_5ftpl_1',['_philox2xWbumpkey_tpl',['../philox_8h.html#a848725dc9596794d470a64317cdd10bc',1,'philox.h']]],
  ['_5fphilox4xwround_5ftpl_2',['_philox4xWround_tpl',['../group__PhiloxNxW.html#ga142124c3d38f9a62dcae98ac23ba4de0',1,'philox.h']]]
];
