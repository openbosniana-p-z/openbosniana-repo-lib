module Librarian
  module Puppet
    VERSION = "3.0.1"
  end
end
