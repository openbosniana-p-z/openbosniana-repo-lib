require "librarian/puppet/action/install"
require "librarian/puppet/action/resolve"
