require 'librarian/puppet/source/path'
require 'librarian/puppet/source/git'
require 'librarian/puppet/source/forge'
require 'librarian/puppet/source/githubtarball'
