module Librarian
  module Puppet
    module Simple
      VERSION = "0.0.5"
    end
  end
end
