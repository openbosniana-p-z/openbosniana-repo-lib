require "librarian/puppet/simple/version"

module Librarian
  module Puppet
    module Simple
      # Your code goes here...
    end
  end
end
