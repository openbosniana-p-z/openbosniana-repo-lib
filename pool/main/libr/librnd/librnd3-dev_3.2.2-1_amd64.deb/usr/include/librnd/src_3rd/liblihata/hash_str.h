/* for internal use: shared hash utility functions for string hashes */
int lht_str_keyeq(const char *k1, const char *k2);
unsigned lht_str_keyhash(const char *key);
