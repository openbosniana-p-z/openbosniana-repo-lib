#ifndef GENHT_VERSION_H
#define GENHT_VERSION_H

/* API version: MAJOR changes only on incompatible API change */
#define GENHT_APIVER_MAJOR 1

/* API version: MAJOR changes only on compatible API change (additions) */
#define GENHT_APIVER_MINOR 1

/* Code version as numbers */
#define GENHT_VER_MAJOR GENHT_APIVER_MAJOR
#define GENHT_VER_MINOR GENHT_APIVER_MINOR
#define GENHT_VER_PATCH 3

/* Code version as string */
#define GENHT_VER_STR "1.1.3"

#endif
