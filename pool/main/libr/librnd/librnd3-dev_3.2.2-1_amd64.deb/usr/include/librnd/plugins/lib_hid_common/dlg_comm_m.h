fgw_error_t rnd_act_gui_PromptFor(fgw_arg_t *res, int argc, fgw_arg_t *argv);
fgw_error_t rnd_act_gui_MessageBox(fgw_arg_t *res, int argc, fgw_arg_t *argv);
fgw_error_t rnd_act_gui_FallbackColorPick(fgw_arg_t *res, int argc, fgw_arg_t *argv);
fgw_error_t rnd_act_gui_MayOverwriteFile(fgw_arg_t *res, int argc, fgw_arg_t *argv);

