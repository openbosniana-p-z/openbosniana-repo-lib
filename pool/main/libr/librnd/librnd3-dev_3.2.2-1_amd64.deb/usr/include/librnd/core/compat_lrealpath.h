#ifndef RND_LREALPATH_H
#define RND_LREALPATH_H

/* A well-defined realpath () that is always compiled in.  */
char *rnd_lrealpath(const char *);

#endif /* RND_LREALPATH_H */
