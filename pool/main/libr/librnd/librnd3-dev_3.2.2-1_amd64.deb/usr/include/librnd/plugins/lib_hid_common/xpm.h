const char **rnd_dlg_xpm_by_name(const char *name);
