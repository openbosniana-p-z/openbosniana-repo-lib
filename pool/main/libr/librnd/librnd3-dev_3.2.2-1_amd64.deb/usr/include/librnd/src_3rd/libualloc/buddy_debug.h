#include "buddy_api.h"

void uall_buddy_visualize(uall_buddy1_t *const buddy, FILE *const file);


