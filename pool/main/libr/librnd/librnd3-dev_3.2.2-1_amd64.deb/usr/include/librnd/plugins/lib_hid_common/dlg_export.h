extern const char rnd_acts_ExportDialog[];
extern const char rnd_acth_ExportDialog[];
fgw_error_t rnd_act_ExportDialog(fgw_arg_t *ores, int oargc, fgw_arg_t *oargv);

extern const char rnd_acts_PrintDialog[];
extern const char rnd_acth_PrintDialog[];
fgw_error_t rnd_act_PrintDialog(fgw_arg_t *ores, int oargc, fgw_arg_t *oargv);
