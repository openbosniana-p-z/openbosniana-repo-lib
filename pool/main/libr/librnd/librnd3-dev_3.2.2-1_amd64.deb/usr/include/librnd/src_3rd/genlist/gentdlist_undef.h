#ifndef TDL_DONT_UNDEF
#	undef TDL
#	undef TDL_LIST_T
# undef TDL_LIST_U
#	undef TDL_ITEM_T
#	undef TDL_SIZE_T
#	undef TDL_FIELD
#	undef TDL_FUNC
#endif
