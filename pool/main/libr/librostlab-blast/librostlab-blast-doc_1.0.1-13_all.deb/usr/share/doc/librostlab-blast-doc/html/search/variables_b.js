var searchData=
[
  ['name_0',['name',['../structrostlab_1_1blast_1_1hit.html#af0f70425cc41a304b6bdbe3b0dcdb7a1',1,'rostlab::blast::hit::name()'],['../structrostlab_1_1blast_1_1oneline.html#a3fbcd78ceac1b92d2d16bcb73ed09a7f',1,'rostlab::blast::oneline::name()']]],
  ['noidx_1',['noidx',['../structrostlab_1_1blast_1_1round.html#ad23b74c5b8d122c47a0d54be37aa0cda',1,'rostlab::blast::round']]]
];
