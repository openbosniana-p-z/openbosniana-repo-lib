var searchData=
[
  ['hit_0',['hit',['../structrostlab_1_1blast_1_1hit.html#a7847e0f5d63534eb5f8908a5d9e043cb',1,'rostlab::blast::hit']]],
  ['hsp_1',['hsp',['../structrostlab_1_1blast_1_1hsp.html#af82dd84c1d093225de32776f35314bd5',1,'rostlab::blast::hsp']]]
];
