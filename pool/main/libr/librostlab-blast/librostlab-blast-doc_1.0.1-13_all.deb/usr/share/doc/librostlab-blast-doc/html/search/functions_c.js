var searchData=
[
  ['result_0',['result',['../classrostlab_1_1blast_1_1parser__driver.html#a97758814e87b1a81b2b2f5560782995b',1,'rostlab::blast::parser_driver::result()'],['../structrostlab_1_1blast_1_1result.html#ab9c59fe3193479880e965e44d0f379da',1,'rostlab::blast::result::result()']]],
  ['round_1',['round',['../structrostlab_1_1blast_1_1round.html#a0d2c4122d5e867afa678f48fe368f009',1,'rostlab::blast::round']]]
];
