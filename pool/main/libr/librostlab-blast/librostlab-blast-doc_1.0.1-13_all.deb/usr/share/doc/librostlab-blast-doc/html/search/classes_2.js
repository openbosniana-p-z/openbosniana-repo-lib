var searchData=
[
  ['hit_0',['hit',['../structrostlab_1_1blast_1_1hit.html',1,'rostlab::blast']]],
  ['hsp_1',['hsp',['../structrostlab_1_1blast_1_1hsp.html',1,'rostlab::blast']]]
];
