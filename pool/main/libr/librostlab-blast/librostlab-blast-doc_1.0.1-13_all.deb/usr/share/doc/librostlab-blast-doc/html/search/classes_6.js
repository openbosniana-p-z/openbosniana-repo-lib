var searchData=
[
  ['result_0',['result',['../structrostlab_1_1blast_1_1result.html',1,'rostlab::blast']]],
  ['round_1',['round',['../structrostlab_1_1blast_1_1round.html',1,'rostlab::blast']]]
];
