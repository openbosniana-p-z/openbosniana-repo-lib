var searchData=
[
  ['filename_5ftype_0',['filename_type',['../classrostlab_1_1blast_1_1position.html#a0197d7c5bc731f896d559c7854769530',1,'rostlab::blast::position::filename_type()'],['../classrostlab_1_1blast_1_1location.html#a378deb74ced8781be9da2dd371ddad36',1,'rostlab::blast::location::filename_type()']]]
];
