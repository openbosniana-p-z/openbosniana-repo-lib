var searchData=
[
  ['raw_5fscore_0',['raw_score',['../structrostlab_1_1blast_1_1hsp.html#aaf207b4f63e9bcd357b2829affea1e2a',1,'rostlab::blast::hsp']]],
  ['references_1',['references',['../structrostlab_1_1blast_1_1result.html#a8525a2fea583e9167f7bfd51589faf43',1,'rostlab::blast::result']]],
  ['rounds_2',['rounds',['../structrostlab_1_1blast_1_1result.html#abab428d7a9f9e6f78a20e29321ee459c',1,'rostlab::blast::result']]]
];
