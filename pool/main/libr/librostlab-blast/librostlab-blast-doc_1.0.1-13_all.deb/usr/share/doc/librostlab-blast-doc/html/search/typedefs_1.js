var searchData=
[
  ['counter_5ftype_0',['counter_type',['../classrostlab_1_1blast_1_1position.html#add1b58b9540e788e6e028e430876fd89',1,'rostlab::blast::position::counter_type()'],['../classrostlab_1_1blast_1_1location.html#a4b3cf7eb1f097a70fea5d90f22546521',1,'rostlab::blast::location::counter_type()']]]
];
