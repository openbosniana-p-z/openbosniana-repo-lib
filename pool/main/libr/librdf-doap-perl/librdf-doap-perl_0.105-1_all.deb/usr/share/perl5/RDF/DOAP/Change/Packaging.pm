package RDF::DOAP::Change::Packaging;

our $AUTHORITY = 'cpan:TOBYINK';
our $VERSION   = '0.105';

use Moose::Role;

1;
