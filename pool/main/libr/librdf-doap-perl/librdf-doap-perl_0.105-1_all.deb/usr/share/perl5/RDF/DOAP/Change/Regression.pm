package RDF::DOAP::Change::Regression;

our $AUTHORITY = 'cpan:TOBYINK';
our $VERSION   = '0.105';

use Moose::Role;

1;
