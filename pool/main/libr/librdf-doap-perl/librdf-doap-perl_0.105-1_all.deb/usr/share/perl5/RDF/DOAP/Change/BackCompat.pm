package RDF::DOAP::Change::BackCompat;

our $AUTHORITY = 'cpan:TOBYINK';
our $VERSION   = '0.105';

use Moose::Role;

1;
