document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Text Documents (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="vi/text/swriter/main0000.html?DbPAR=WRITER">Chào mừng đến với Trợ Giúp của LibreOffice Writer</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0503.html?DbPAR=WRITER">Tính năng LibreOffice Writer</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/main.html?DbPAR=WRITER">Hướng dẫn Sử dụng LibreOffice Writer</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Neo và thay đổi kích thước cửa sổ</a></li>\
    <li><a target="_top" href="vi/text/swriter/04/01020000.html?DbPAR=WRITER">Các phím tắt đối với LibreOffice Writer</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/words_count.html?DbPAR=WRITER">Đếm Từ</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/keyboard.html?DbPAR=WRITER">Sử dụng Phím tắt (Khả năng Truy cập LibreOffice Writer)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Trình đơn</label><ul>\
    <li><a target="_top" href="vi/text/swriter/main0100.html?DbPAR=WRITER">Trình đơn</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0101.html?DbPAR=WRITER">Tập tin</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0102.html?DbPAR=WRITER">Sửa</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0103.html?DbPAR=WRITER">Xem</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0104.html?DbPAR=WRITER">Chèn</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0105.html?DbPAR=WRITER">Định dạng</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0115.html?DbPAR=WRITER">Styles (menu)</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0110.html?DbPAR=WRITER">Bảng</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0120.html?DbPAR=WRITER">Form Menu</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0106.html?DbPAR=WRITER">Công cụ</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0107.html?DbPAR=WRITER">Cửa sổ</a></li>\
    <li><a target="_top" href="vi/text/shared/main0108.html?DbPAR=WRITER">Trợ giúp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Thanh công cụ</label><ul>\
    <li><a target="_top" href="vi/text/swriter/main0200.html?DbPAR=WRITER">Thanh công cụ</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0206.html?DbPAR=WRITER">Thanh điểm chấm và đánh số</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0205.html?DbPAR=WRITER">Thanh thuộc tính đối tượng vẽ</a></li>\
    <li><a target="_top" href="vi/text/shared/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="vi/text/shared/main0226.html?DbPAR=WRITER">Thanh công cụ thiết kế biểu mẫu</a></li>\
    <li><a target="_top" href="vi/text/shared/main0213.html?DbPAR=WRITER">Thanh điều hướng biểu mẫu</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0202.html?DbPAR=WRITER">Thanh định dạng</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0214.html?DbPAR=WRITER">Thanh công thức</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0215.html?DbPAR=WRITER">Thanh khung</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0203.html?DbPAR=WRITER">Image Bar</a></li>\
    <li><a target="_top" href="vi/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo Toolbar</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0216.html?DbPAR=WRITER">OLE Object Bar</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0210.html?DbPAR=WRITER">Print Preview Bar (Writer)</a></li>\
    <li><a target="_top" href="vi/text/shared/main0214.html?DbPAR=WRITER">Thanh thiết kế truy vấn</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0213.html?DbPAR=WRITER">Thước</a></li>\
    <li><a target="_top" href="vi/text/shared/main0201.html?DbPAR=WRITER">Thanh chuẩn</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0208.html?DbPAR=WRITER">Status Bar (Writer)</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0204.html?DbPAR=WRITER">Thanh bảng</a></li>\
    <li><a target="_top" href="vi/text/shared/main0212.html?DbPAR=WRITER">Thanh dữ liệu bảng</a></li>\
    <li><a target="_top" href="vi/text/swriter/main0220.html?DbPAR=WRITER">Thanh đối tượng văn bản</a></li>\
    <li><a target="_top" href="vi/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Track Changes Toolbar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navigating Text Documents</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Dịch chuyển và chọn bằng bàn phím</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Di chuyển và Sao chép Văn bản trong Tài liệu</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Sắp đặt lại tài liệu bằng cách dùng Bộ điều hướng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Chèn Siêu liên kết bằng Bộ điều hướng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/navigator.html?DbPAR=WRITER">Bộ điều hướng cho tài liệu Văn bản</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Dùng Con Trỏ Trực Tiếp</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatting Text Documents</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Thay Đổi Hướng Trang (Nằm ngang hay Nằm dọc)</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/text_capital.html?DbPAR=WRITER">Chuyển đổi giữa Chữ Hoa và Chữ Thường</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Ẩn văn bản</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Xác định Đầu/Chân trang Khác nhau</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Chèn Tên và Số thứ tự Chương vào Đầu/Chân Trang</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Áp dụng Định dạng Văn bản trong khi Gõ</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/reset_format.html?DbPAR=WRITER">Đặt lại Thuộc tính Phông</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Áp dụng Kiểu dáng ở Chế độ Định dạng Tô đầy</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/wrap.html?DbPAR=WRITER">Cuộn Văn bản quanh Đối tượng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Dùng Khung để Đặt Văn bản ở Giữa trên Trang</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Nhấn mạnh Văn bản</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Văn Bản Xoay</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/page_break.html?DbPAR=WRITER">Chèn và Xoá Chỗ Ngắt Trang</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Tạo và Áp dụng Kiểu dáng Trang</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/subscript.html?DbPAR=WRITER">Chuyển văn bản thành chỉ số trên/dưới</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Mẫu và Kiểu dáng</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Mẫu và Kiểu dáng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Kiểu dáng trang xen kẽ trên trang chẵn và lẻ</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/change_header.html?DbPAR=WRITER">Tạo kiểu dáng trang dựa trên trang hiện thời</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/load_styles.html?DbPAR=WRITER">Sử dụng Kiểu dáng từ Tài liệu hay Mẫu Khác</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Tạo Kiểu dáng Mới từ Vùng chọn</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Cập nhật Kiểu dáng từ Vùng chọn</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/template_manager.html?DbPAR=WRITER">Template Manager</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Graphics in Text Documents</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Chèn Đồ Họa</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Chèn Đồ Họa Từ Tập Tin</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Chèn đồ họa từ Bộ sưu tập bằng cách kéo và thả</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Chèn ảnh đã quét</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Chèn Đồ thị Calc vào Tài liệu Văn bản</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Chèn Đồ họa từ LibreOffice Draw hay Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tables in Text Documents</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Bật/tắt Khả năng Nhận ra Số trong Bảng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/tablemode.html?DbPAR=WRITER">Sửa đổi Hàng và Cột bằng Bàn phím</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/table_delete.html?DbPAR=WRITER">Xoá Bảng hay Nội dung của Bảng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/table_insert.html?DbPAR=WRITER">Chèn Bảng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Lặp lại Tiêu đề Bảng trên Trang Mới</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Thay đổi Kích cỡ của Hàng hay Cột trong Bảng Văn bản</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objects in Text Documents</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Đặt Vị trí Đối tượng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/wrap.html?DbPAR=WRITER">Cuộn Văn bản quanh Đối tượng</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sections and Frames in Text Documents</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/sections.html?DbPAR=WRITER">Sử Dụng Phần</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/section_edit.html?DbPAR=WRITER">Chỉnh Sửa Phần</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/section_insert.html?DbPAR=WRITER">Chèn Phần</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Tables of Contents and Indexes</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Chỉ Mục Tự Xác Định</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Tạo Mục Lục</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/indices_index.html?DbPAR=WRITER">Tạo Chỉ mục theo Thứ tự abc</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Chỉ Mục Bao Quát Vài Tài Liệu</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Tạo Thư Tịch</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Chỉnh sửa hay Xoá mục nhập Bảng và Chỉ mục</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Cập nhật, Chỉnh sửa và Xoá các Chỉ mục và Mục lục</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Xác định mục nhập Chỉ mục hay Mục lục</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/indices_form.html?DbPAR=WRITER">Định dạng Chỉ mục hay Mục lục</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Fields in Text Documents</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/fields.html?DbPAR=WRITER">Thông tin về Trường</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/fields_date.html?DbPAR=WRITER">Chèn trường ngày tháng cố định hay thay đổi</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/field_convert.html?DbPAR=WRITER">Chuyển đổi Trường sang Văn bản</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Tính trong tài liệu văn bản</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Tính qua bảng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/calculate.html?DbPAR=WRITER">Tính trong tài liệu văn bản</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Tính và dán kết quả công thức vào tài liệu văn bản</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Tính tổng các ô trong bảng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Tính công thức phức tạp trong tài liệu văn bản</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Hiển thị kết quả phép tính bảng trong bảng khác</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Special Text Elements</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/captions.html?DbPAR=WRITER">Sử dụng phụ đề</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Văn bản Điều kiện</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Văn bản điều kiện khi đếm trang</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/fields_date.html?DbPAR=WRITER">Chèn trường ngày tháng cố định hay thay đổi</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Thêm trường nhập liệu</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Chèn số thứ tự trang của trang tiếp tục</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Chèn số thứ tự trang vào phần chân trang</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Ẩn văn bản</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Xác định Đầu/Chân trang Khác nhau</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Chèn Tên và Số thứ tự Chương vào Đầu/Chân Trang</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Truy vấn Dữ liệu Người dùng trong Trường hay Điều kiện</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Chèn và Chỉnh sửa Cước chú hay Kết chú</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Giãn cách giữa các cước chú</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/header_footer.html?DbPAR=WRITER">Thông tin về Đầu trang và Chân trang</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Định Dạng Đầu/Chân Trang</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/text_animation.html?DbPAR=WRITER">Hoạt hoạ Văn bản</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Tạo Thư Mẫu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automatic Functions</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Thêm ngoại lệ vào danh sách Tự động Sửa lỗi</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/autotext.html?DbPAR=WRITER">Sử dụng Tốc ký</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Tạo danh sách kiểu đánh số hay chấm điểm trong khi gõ</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/auto_off.html?DbPAR=WRITER">Tắt Tự động Sửa lỗi</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Tự động Kiểm tra Chính tả</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Bật/tắt Khả năng Nhận ra Số trong Bảng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Gạch Nối Từ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numbering and Lists</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Thêm số thứ tự chương vào phụ đề</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Tạo danh sách kiểu đánh số hay chấm điểm trong khi gõ</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Kết hợp Danh sách Đánh số</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Thêm Số thứ tự Dòng</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Xác định Phạm vi Số</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Đánh Số</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Thêm chấm điểm</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Spellchecking, Thesaurus, and Languages</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Tự động Kiểm tra Chính tả</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Gỡ bỏ Từ khỏi Từ điển tự định nghĩa</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Từ điển gần nghĩa</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Kiểm tra chính tả và ngữ pháp</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Troubleshooting Tips</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Chèn Văn bản đằng Trước Bảng ở Đầu Trang</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Tới liên kết lưu riêng</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/send2html.html?DbPAR=WRITER">Lưu Tài liệu Văn bản bằng Định dạng HTML</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Chèn Toàn Tài liệu Văn bản</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Master Documents</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Tài liệu Chủ và Tài liệu Phụ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Links and References</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/references.html?DbPAR=WRITER">Chèn Tham Chiếu Chéo</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Chèn Siêu liên kết bằng Bộ điều hướng</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">In ấn</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selecting What to Print</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Chọn khay đựng giấy của máy in</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/print_preview.html?DbPAR=WRITER">Xem Thử Trang Trước Khi In</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/print_small.html?DbPAR=WRITER">In Ra Nhiều Trang Trên Cùng Tờ Giấy</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Tạo và Áp dụng Kiểu dáng Trang</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Searching and Replacing</label><ul>\
    <li><a target="_top" href="vi/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="vi/text/shared/01/02100001.html?DbPAR=WRITER">Danh sách Biểu thức Chính quy</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML Documents (Writer Web)</label><ul>\
    <li><a target="_top" href="vi/text/shared/07/09000000.html?DbPAR=WRITER">Trang Web</a></li>\
    <li><a target="_top" href="vi/text/shared/02/01170700.html?DbPAR=WRITER">Bộ lọc và Biểu mẫu HTML</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/send2html.html?DbPAR=WRITER">Lưu Tài liệu Văn bản bằng Định dạng HTML</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Spreadsheets (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="vi/text/scalc/main0000.html?DbPAR=CALC">Chào mừng dùng Trợ giúp của LibreOffice Calc</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0503.html?DbPAR=CALC">Tính năng LibreOffice Calc</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/keyboard.html?DbPAR=CALC">Phím tắt (Khả năng truy cập bảng LibreOffice Calc)</a></li>\
    <li><a target="_top" href="vi/text/scalc/04/01020000.html?DbPAR=CALC">Phím tắt cho Bảng tính</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="vi/text/scalc/05/02140000.html?DbPAR=CALC">Mã lỗi trong LibreOffice Calc</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060112.html?DbPAR=CALC">Phần bổ trợ để lập trình trong LibreOffice Calc</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/main.html?DbPAR=CALC">Hướng dẫn sử dụng LibreOffice Calc</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Trình đơn</label><ul>\
    <li><a target="_top" href="vi/text/scalc/main0100.html?DbPAR=CALC">Trình đơn</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0101.html?DbPAR=CALC">Tập tin</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0102.html?DbPAR=CALC">Sửa</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0103.html?DbPAR=CALC">Xem</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0104.html?DbPAR=CALC">Chèn</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0105.html?DbPAR=CALC">Định dạng</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0116.html?DbPAR=CALC">Sheet</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0112.html?DbPAR=CALC">Dữ liệu</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0106.html?DbPAR=CALC">Công cụ</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0107.html?DbPAR=CALC">Cửa sổ</a></li>\
    <li><a target="_top" href="vi/text/shared/main0108.html?DbPAR=CALC">Trợ giúp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Thanh công cụ</label><ul>\
    <li><a target="_top" href="vi/text/scalc/main0200.html?DbPAR=CALC">Thanh công cụ</a></li>\
    <li><a target="_top" href="vi/text/shared/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0202.html?DbPAR=CALC">Thanh định dạng</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0203.html?DbPAR=CALC">Thanh thuộc tính đối tượng vẽ</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0205.html?DbPAR=CALC">Thanh định dạng văn bản</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0206.html?DbPAR=CALC">Thanh công thức</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0208.html?DbPAR=CALC">Thanh trạng thái</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0210.html?DbPAR=CALC">Thanh xem thử trang</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0214.html?DbPAR=CALC">Image Bar</a></li>\
    <li><a target="_top" href="vi/text/scalc/main0218.html?DbPAR=CALC">Thanh công cụ</a></li>\
    <li><a target="_top" href="vi/text/shared/main0201.html?DbPAR=CALC">Thanh chuẩn</a></li>\
    <li><a target="_top" href="vi/text/shared/main0212.html?DbPAR=CALC">Thanh dữ liệu bảng</a></li>\
    <li><a target="_top" href="vi/text/shared/main0213.html?DbPAR=CALC">Thanh điều hướng biểu mẫu</a></li>\
    <li><a target="_top" href="vi/text/shared/main0214.html?DbPAR=CALC">Thanh thiết kế truy vấn</a></li>\
    <li><a target="_top" href="vi/text/shared/main0226.html?DbPAR=CALC">Thanh công cụ thiết kế biểu mẫu</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Functions Types and Operators</label><ul>\
    <li><a target="_top" href="vi/text/scalc/01/04060000.html?DbPAR=CALC">Trợ lý Hàm</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060100.html?DbPAR=CALC">Hàm được phân loại</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060107.html?DbPAR=CALC">Hàm Mảng</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060120.html?DbPAR=CALC">Bit Operation Functions</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060101.html?DbPAR=CALC">Các hàm cơ sở dữ liệu</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060102.html?DbPAR=CALC">Hàm Ngày/Giờ</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060103.html?DbPAR=CALC">Hàm Tài Chính (Phần 1)</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060119.html?DbPAR=CALC">Hàm Tài Chính Phần 2</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060118.html?DbPAR=CALC">Hàm Tài Chính (Phần 3)</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060104.html?DbPAR=CALC">Hàm Thông Tin</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060105.html?DbPAR=CALC">Hàm Lôgic</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060106.html?DbPAR=CALC">Hàm toán học</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060108.html?DbPAR=CALC">Hàm Thống Kê</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060181.html?DbPAR=CALC">Hàm Thống Kê Phần 1</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060182.html?DbPAR=CALC">Hàm Thống Kê Phần 2</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060183.html?DbPAR=CALC">Hàm Thống Kê Phần 3</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060184.html?DbPAR=CALC">Hàm Thống Kê Phần 4</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060185.html?DbPAR=CALC">Hàm Thống Kê Phần 5</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060109.html?DbPAR=CALC">Hàm Bảng Tính</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060110.html?DbPAR=CALC">Hàm văn bản</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060111.html?DbPAR=CALC">Hàm Bổ trợ</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060115.html?DbPAR=CALC">Hàm bổ trợ, Danh sách hàm phân tích Phần 1</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060116.html?DbPAR=CALC">Hàm bổ trợ, Danh sách hàm phân tích Phần 2</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/04060199.html?DbPAR=CALC">Toán tử trong LibreOffice Calc</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Các hàm do người sử dụng quy định</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/webquery.html?DbPAR=CALC">Chèn Dữ liệu bên Ngoài vào Bảng (WebQuery)</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/html_doc.html?DbPAR=CALC">Lưu và Mở bảng tính theo HTML</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/csv_formula.html?DbPAR=CALC">Nhập và xuất các tập tin văn bản</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Định dạng</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/text_rotate.html?DbPAR=CALC">Xoay văn bản</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/text_wrap.html?DbPAR=CALC">Viết văn bản nhiều dòng</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/text_numbers.html?DbPAR=CALC">Định dạng Số dưới dạng Văn bản</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/super_subscript.html?DbPAR=CALC">Chỉ số trên/dưới trong văn bản</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/row_height.html?DbPAR=CALC">Thay đổi chiều cao hàng hay chiều rộng cột</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Áp dụng Định dạng có điều kiện</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Tô sáng các số âm</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Gán định dạng theo công thức</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Nhập một số bắt đầu bằng số 0</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/format_table.html?DbPAR=CALC">Định dạng Bảng tính</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/format_value.html?DbPAR=CALC">Định dạng Số thập phân</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/value_with_name.html?DbPAR=CALC">Đặt tên ô</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/table_rotate.html?DbPAR=CALC">Xoay bảng (Chuyển vị)</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/rename_table.html?DbPAR=CALC">Đặt lại tên trang tính</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/year2000.html?DbPAR=CALC">Năm 19xx/20xx</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Dùng các số được làm tròn</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/currency_format.html?DbPAR=CALC">Các ô ở dạng tiền tệ</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/autoformat.html?DbPAR=CALC">Dùng Tự động định dạng trong bảng</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/note_insert.html?DbPAR=CALC">Chèn và Sửa Ghi Chú</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/design.html?DbPAR=CALC">Chọn sắc thái cho bảng tính</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Nhập phân số</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtering and Sorting</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/filters.html?DbPAR=CALC">Ứng dụng bộ lọc</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/autofilter.html?DbPAR=CALC">Áp dụng Tự động Lọc</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/sorted_list.html?DbPAR=CALC">Ứng dụng Danh sách Sắp xếp</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">In ấn</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/print_title_row.html?DbPAR=CALC">In hàng hoặc cột trên mọi trang</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/print_landscape.html?DbPAR=CALC">In trang theo định dạng nằm ngang</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/print_details.html?DbPAR=CALC">In chi tiết trang tính</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/print_exact.html?DbPAR=CALC">Xác định số trang để in</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Data Ranges</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/database_define.html?DbPAR=CALC">Đặt phạm vi cho cơ sở dữ liệu</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/database_filter.html?DbPAR=CALC">Lọc phạm vi các ô</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/database_sort.html?DbPAR=CALC">Dữ liệu sắp thứ tự</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Pivot Table</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/datapilot.html?DbPAR=CALC">Xẻ bảng</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Tạo các bảng DataPilot</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Xoá bảng DataPilot</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Sửa các bảng DataPilot</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Lọc các bảng DataPilot</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Chọn các phạm vi đầu ra DataPilot</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Cập nhật bảng DataPilot</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivot Chart</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Kịch bản</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/scenario.html?DbPAR=CALC">Dùng kịch bản</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotals</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">References</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Địa chỉ và Tham chiếu, Tuyệt đối và Tương đối</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/cellreferences.html?DbPAR=CALC">Tham chiếu một ô trong tài liệu khác</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Tham chiếu tới bảng khác và tham chiếu URL</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Tham chiếu các ô bằng cách Kéo Thả</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/address_auto.html?DbPAR=CALC">Nhận tên dưới dạng địa chỉ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Viewing, Selecting, Copying</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/table_view.html?DbPAR=CALC">Thay đổi ô Xem bảng</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/formula_value.html?DbPAR=CALC">Hiển thị Công thức hay Giá trị</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/line_fix.html?DbPAR=CALC">Hàng hay cột đông cứng dạng đầu trang</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/multi_tables.html?DbPAR=CALC">Điều hướng qua các thẻ trang tính</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Chép tới nhiều bảng</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/cellcopy.html?DbPAR=CALC">Chỉ chép những ô được hiển thị</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/mark_cells.html?DbPAR=CALC">Chọn nhiều ô</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formulas and Calculations</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/formulas.html?DbPAR=CALC">Tính dùng Công thức</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/formula_copy.html?DbPAR=CALC">Chép công thức</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/formula_enter.html?DbPAR=CALC">Nhập công thức</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/formula_value.html?DbPAR=CALC">Hiển thị Công thức hay Giá trị</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/calculate.html?DbPAR=CALC">Tính toán trong bảng tính</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/calc_date.html?DbPAR=CALC">Tính toán với Ngày và Thời gian</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/calc_series.html?DbPAR=CALC">Tự động Tính Nối tiếp</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Tính hiệu thời gian</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/matrixformula.html?DbPAR=CALC">Nhập Công thức Ma trận</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Bảo vệ</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/cell_protect.html?DbPAR=CALC">Giữ cho các ô không đổi</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Bỏ bảo vệ cho các ô</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Writing Calc Macros</label><ul>\
    <li><a target="_top" href="vi/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="vi/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatting Borders in Calc with Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Lặt vặt</label><ul>\
    <li><a target="_top" href="vi/text/scalc/guide/auto_off.html?DbPAR=CALC">Tắt chế độ Tự động Thay đổi</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/consolidate.html?DbPAR=CALC">Kết hợp dữ liệu</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/goalseek.html?DbPAR=CALC">Ứng dụng Tìm Mục Tiêu</a></li>\
    <li><a target="_top" href="vi/text/scalc/01/solver.html?DbPAR=CALC">Giải phương trình</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/multioperation.html?DbPAR=CALC">Ứng dụng nhiều thao tác</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/multitables.html?DbPAR=CALC">Ứng dụng nhiều trang tính</a></li>\
    <li><a target="_top" href="vi/text/scalc/guide/validity.html?DbPAR=CALC">Tính hợp lệ của nội dung ô</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentations (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="vi/text/simpress/main0000.html?DbPAR=IMPRESS">Chào mừng dùng Trợ giúp của LibreOffice Impress</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0503.html?DbPAR=IMPRESS">Tính năng LibreOffice Impress</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Dùng Phím Tắt trong LibreOffice Impress</a></li>\
    <li><a target="_top" href="vi/text/simpress/04/01020000.html?DbPAR=IMPRESS">Phím tắt cho LibreOffice Impress</a></li>\
    <li><a target="_top" href="vi/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Keyboard Shortcuts</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/main.html?DbPAR=IMPRESS">Hướng dẫn về sử dụng LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Trình đơn</label><ul>\
    <li><a target="_top" href="vi/text/simpress/main0100.html?DbPAR=IMPRESS">Trình đơn</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0101.html?DbPAR=IMPRESS">Tập tin</a></li>\
    <li><a target="_top" href="vi/text/simpress/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0103.html?DbPAR=IMPRESS">Xem</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0104.html?DbPAR=IMPRESS">Chèn</a></li>\
    <li><a target="_top" href="vi/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="vi/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0114.html?DbPAR=IMPRESS">Chiếu ảnh</a></li>\
    <li><a target="_top" href="vi/text/simpress/main_tools.html?DbPAR=IMPRESS">Tools</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0107.html?DbPAR=IMPRESS">Cửa sổ</a></li>\
    <li><a target="_top" href="vi/text/shared/main0108.html?DbPAR=IMPRESS">Trợ giúp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Thanh công cụ</label><ul>\
    <li><a target="_top" href="vi/text/simpress/main0200.html?DbPAR=IMPRESS">Thanh công cụ</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0210.html?DbPAR=IMPRESS">Thanh vẽ</a></li>\
    <li><a target="_top" href="vi/text/shared/main0227.html?DbPAR=IMPRESS">Thanh sửa điểm</a></li>\
    <li><a target="_top" href="vi/text/shared/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="vi/text/shared/main0226.html?DbPAR=IMPRESS">Thanh công cụ thiết kế biểu mẫu</a></li>\
    <li><a target="_top" href="vi/text/shared/main0213.html?DbPAR=IMPRESS">Thanh điều hướng biểu mẫu</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0214.html?DbPAR=IMPRESS">Image Bar</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0202.html?DbPAR=IMPRESS">Thanh dòng và tô đầy</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0213.html?DbPAR=IMPRESS">Thanh tùy chọn</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0211.html?DbPAR=IMPRESS">Thanh phác thảo</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0209.html?DbPAR=IMPRESS">Thước</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0212.html?DbPAR=IMPRESS">Thanh sắp xếp ảnh chiếu</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0204.html?DbPAR=IMPRESS">Thanh xem ảnh chiếu</a></li>\
    <li><a target="_top" href="vi/text/shared/main0201.html?DbPAR=IMPRESS">Thanh chuẩn</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0206.html?DbPAR=IMPRESS">Thanh trạng thái</a></li>\
    <li><a target="_top" href="vi/text/shared/main0204.html?DbPAR=IMPRESS">Thanh bảng</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0203.html?DbPAR=IMPRESS">Thanh định dạng văn bản</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="vi/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Lưu Trình diễn theo Định dạng HTML</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Nhập khẩu Trang HTML vào Trình diễn</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Xuất khẩu hoạt ảnh theo định dạng GIF</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Chèn Bảng Tính vào Ảnh Chiếu</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Chèn đồ họa</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Định dạng</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Nạp Kiểu Dáng Dòng và Mũi Tên</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Xác định màu sắc riêng</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Tạo sự tô đầy dải màu</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Thay thế màu sắc</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Sắp đặt, Sắp hàng và Phân phối các Đối tượng</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/background.html?DbPAR=IMPRESS">Thay đổi nền của ảnh chiếu</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/footer.html?DbPAR=IMPRESS">Thêm Đầu/Chân Trang cho Mọi Ảnh Chiếu</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Di chuyển Đối tượng</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">In ấn</label><ul>\
    <li><a target="_top" href="vi/text/simpress/guide/printing.html?DbPAR=IMPRESS">In ra Trình diễn</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">In ra ảnh chiếu vừa với cỡ giấy</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Hiệu ứng</label><ul>\
    <li><a target="_top" href="vi/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Xuất khẩu hoạt ảnh theo định dạng GIF</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Hoạt họa Đối tượng trên Ảnh chiếu Trình diễn</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Hoạt họa sự Chuyển tiếp Ảnh chiếu</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Mờ đi chéo hai đối tượng</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Tạo ảnh GIF đã hoạt họa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objects, Graphics, and Bitmaps</label><ul>\
    <li><a target="_top" href="vi/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Kết hợp Đối tượng và Cấu tạo Hình</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Nhóm lại đối tượng</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Vẽ hình quạt và hình phân</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Nhân đôi đối tượng</a></li>\
    <li><a target="_top" href="vi/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformations</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Xoay Đối tượng</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Tập hợp các đối tượng ba chiều (3D)</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Kết nối dòng</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Chuyển đổi Ký tự Văn bản sang Đối tượng Vẽ</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Chuyển đổi Ảnh bitmap sang Đồ họa Véc-tơ</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Chuyển đổi Đối tượng 2D sang Đường Cong, Hình Đa Giác và Đối tượng 3D</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Nạp Kiểu Dáng Dòng và Mũi Tên</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Vẽ Đường Cong</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Chỉnh Sửa Đường Cong</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Chèn đồ họa</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Chèn Bảng Tính vào Ảnh Chiếu</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Di chuyển Đối tượng</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Chọn Đối Tượng Nằm Dưới</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Tạo một lưu đồ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text in Presentations</label><ul>\
    <li><a target="_top" href="vi/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Thêm Văn bản</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Chuyển đổi Ký tự Văn bản sang Đối tượng Vẽ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Viewing</label><ul>\
    <li><a target="_top" href="vi/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Thay đổi Thứ tự Ảnh chiếu</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Thu Phóng bằng Bàn Phím</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Slide Shows</label><ul>\
    <li><a target="_top" href="vi/text/simpress/guide/show.html?DbPAR=IMPRESS">Hiển Thị Chiếu Ảnh</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/individual.html?DbPAR=IMPRESS">Tạo Chiếu Ảnh Riêng</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Thử Thời gian Chuyển đổi Ảnh chiếu</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Drawings (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="vi/text/sdraw/main0000.html?DbPAR=DRAW">Chào mừng dùng Trợ Giúp của LibreOffice Draw</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main0503.html?DbPAR=DRAW">Tính năng LibreOffice Draw</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Phím tắt cho Đối tượng Vẽ</a></li>\
    <li><a target="_top" href="vi/text/sdraw/04/01020000.html?DbPAR=DRAW">Phím tắt cho bản Vẽ</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/main.html?DbPAR=DRAW">Hướng dẫn về cách sử dụng LibreOffice Draw</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menus</label><ul>\
    <li><a target="_top" href="vi/text/sdraw/main0100.html?DbPAR=DRAW">Trình đơn</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main0101.html?DbPAR=DRAW">Tập tin</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main0103.html?DbPAR=DRAW">View (menu in Draw)</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main_insert.html?DbPAR=DRAW">Insert</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main_tools.html?DbPAR=DRAW">Tools</a></li>\
    <li><a target="_top" href="vi/text/simpress/main0107.html?DbPAR=DRAW">Cửa sổ</a></li>\
    <li><a target="_top" href="vi/text/shared/main0108.html?DbPAR=DRAW">Trợ giúp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Toolbars</label><ul>\
    <li><a target="_top" href="vi/text/sdraw/main0200.html?DbPAR=DRAW">Thanh công cụ</a></li>\
    <li><a target="_top" href="vi/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D-Settings</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main0210.html?DbPAR=DRAW">Thanh vẽ</a></li>\
    <li><a target="_top" href="vi/text/shared/main0227.html?DbPAR=DRAW">Thanh sửa điểm</a></li>\
    <li><a target="_top" href="vi/text/shared/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="vi/text/shared/main0226.html?DbPAR=DRAW">Thanh công cụ thiết kế biểu mẫu</a></li>\
    <li><a target="_top" href="vi/text/shared/main0213.html?DbPAR=DRAW">Thanh điều hướng biểu mẫu</a></li>\
    <li><a target="_top" href="vi/text/sdraw/main0213.html?DbPAR=DRAW">Thanh tùy chọn</a></li>\
    <li><a target="_top" href="vi/text/shared/main0201.html?DbPAR=DRAW">Thanh chuẩn</a></li>\
    <li><a target="_top" href="vi/text/shared/main0204.html?DbPAR=DRAW">Thanh bảng</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Loading, Saving, Importing, and Exporting</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Chèn đồ họa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatting</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Nạp Kiểu Dáng Dòng và Mũi Tên</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/color_define.html?DbPAR=DRAW">Xác định màu sắc riêng</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/gradient.html?DbPAR=DRAW">Tạo sự tô đầy dải màu</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Thay thế màu sắc</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Sắp đặt, Sắp hàng và Phân phối các Đối tượng</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/background.html?DbPAR=DRAW">Thay đổi nền của ảnh chiếu</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/move_object.html?DbPAR=DRAW">Di chuyển Đối tượng</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Printing</label><ul>\
    <li><a target="_top" href="vi/text/simpress/guide/printing.html?DbPAR=DRAW">In ra Trình diễn</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/print_tofit.html?DbPAR=DRAW">In ra ảnh chiếu vừa với cỡ giấy</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effects</label><ul>\
    <li><a target="_top" href="vi/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Mờ đi chéo hai đối tượng</a></li>\
    <li><a target="_top" href="vi/text/shared/01/05350000.html?DbPAR=DRAW">Hiệu ứng 3D</a></li>\
    <li><a target="_top" href="vi/text/simpress/02/10030000.html?DbPAR=DRAW">Transformations</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objects, Graphics, and Bitmaps</label><ul>\
    <li><a target="_top" href="vi/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Kết hợp Đối tượng và Cấu tạo Hình</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Vẽ hình quạt và hình phân</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Nhân đôi đối tượng</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Xoay Đối tượng</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Tập hợp các đối tượng ba chiều (3D)</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Kết nối dòng</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/text2curve.html?DbPAR=DRAW">Chuyển đổi Ký tự Văn bản sang Đối tượng Vẽ</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/vectorize.html?DbPAR=DRAW">Chuyển đổi Ảnh bitmap sang Đồ họa Véc-tơ</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/3d_create.html?DbPAR=DRAW">Chuyển đổi Đối tượng 2D sang Đường Cong, Hình Đa Giác và Đối tượng 3D</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Nạp Kiểu Dáng Dòng và Mũi Tên</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/line_draw.html?DbPAR=DRAW">Vẽ Đường Cong</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/line_edit.html?DbPAR=DRAW">Chỉnh Sửa Đường Cong</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Chèn đồ họa</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/table_insert.html?DbPAR=DRAW">Chèn Bảng Tính vào Ảnh Chiếu</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/move_object.html?DbPAR=DRAW">Di chuyển Đối tượng</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/select_object.html?DbPAR=DRAW">Chọn Đối Tượng Nằm Dưới</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/orgchart.html?DbPAR=DRAW">Tạo một lưu đồ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Groups and Layers</label><ul>\
    <li><a target="_top" href="vi/text/sdraw/guide/groups.html?DbPAR=DRAW">Nhóm lại đối tượng</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserting Layers</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="vi/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text in Drawings</label><ul>\
    <li><a target="_top" href="vi/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Thêm Văn bản</a></li>\
    <li><a target="_top" href="vi/text/simpress/guide/text2curve.html?DbPAR=DRAW">Chuyển đổi Ký tự Văn bản sang Đối tượng Vẽ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Viewing</label><ul>\
    <li><a target="_top" href="vi/text/simpress/guide/change_scale.html?DbPAR=DRAW">Thu Phóng bằng Bàn Phím</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Database Functionality (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">General Information</label><ul>\
    <li><a target="_top" href="vi/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/database_main.html?DbPAR=BASE">Database Overview</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_new.html?DbPAR=BASE">Creating a New Database</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_tables.html?DbPAR=BASE">Working with Tables</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_queries.html?DbPAR=BASE">Working with Queries</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_forms.html?DbPAR=BASE">Working with Forms</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_reports.html?DbPAR=BASE">Creating Reports</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_register.html?DbPAR=BASE">Registering and Deleting a Database</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_im_export.html?DbPAR=BASE">Importing and Exporting Data in Base</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Executing SQL Commands</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formulas (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="vi/text/smath/main0000.html?DbPAR=MATH">Chào mừng dùng Trợ giúp của LibreOffice Help</a></li>\
    <li><a target="_top" href="vi/text/smath/main0503.html?DbPAR=MATH">Tính năng LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formula Elements</label><ul>\
    <li><a target="_top" href="vi/text/smath/01/03090100.html?DbPAR=MATH">Toán tử đơn/đôi</a></li>\
    <li><a target="_top" href="vi/text/smath/01/03090200.html?DbPAR=MATH">Quan hệ</a></li>\
    <li><a target="_top" href="vi/text/smath/01/03090800.html?DbPAR=MATH">Phép tính Tập hợp</a></li>\
    <li><a target="_top" href="vi/text/smath/01/03090400.html?DbPAR=MATH">Hàm</a></li>\
    <li><a target="_top" href="vi/text/smath/01/03090300.html?DbPAR=MATH">Toán tử</a></li>\
    <li><a target="_top" href="vi/text/smath/01/03090600.html?DbPAR=MATH">Thuộc tính</a></li>\
    <li><a target="_top" href="vi/text/smath/01/03090500.html?DbPAR=MATH">Dấu ngoặc</a></li>\
    <li><a target="_top" href="vi/text/smath/01/03090700.html?DbPAR=MATH">Định dạng</a></li>\
    <li><a target="_top" href="vi/text/smath/01/03091600.html?DbPAR=MATH">Các ký hiệu khác</a></li>\
      </ul></li>\
    <li><a target="_top" href="vi/text/smath/guide/main.html?DbPAR=MATH">Hướng dẫn sử dụng LibreOffice Math</a></li>\
    <li><a target="_top" href="vi/text/smath/guide/keyboard.html?DbPAR=MATH">Phím tắt (khả năng truy cập LibreOffice Math)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Command and Menu Reference</label><ul>\
    <li><a target="_top" href="vi/text/smath/main0100.html?DbPAR=MATH">Trình đơn</a></li>\
    <li><a target="_top" href="vi/text/smath/main0200.html?DbPAR=MATH">Thanh công cụ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Working with Formulas</label><ul>\
    <li><a target="_top" href="vi/text/smath/guide/align.html?DbPAR=MATH">Chỉnh canh các phần hàm bằng tay</a></li>\
    <li><a target="_top" href="vi/text/smath/guide/color.html?DbPAR=MATH">Applying Color to Formula Parts</a></li>\
    <li><a target="_top" href="vi/text/smath/guide/attributes.html?DbPAR=MATH">Thay đổi thuộc tính mặc định</a></li>\
    <li><a target="_top" href="vi/text/smath/guide/brackets.html?DbPAR=MATH">Trộn các phần công thức trong dấu ngoặc</a></li>\
    <li><a target="_top" href="vi/text/smath/guide/comment.html?DbPAR=MATH">Gõ ghi chú</a></li>\
    <li><a target="_top" href="vi/text/smath/guide/newline.html?DbPAR=MATH">Ngắt dòng</a></li>\
    <li><a target="_top" href="vi/text/smath/guide/parentheses.html?DbPAR=MATH">Chèn dấu ngoặc</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Charts and Diagrams</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">General Information</label><ul>\
    <li><a target="_top" href="vi/text/schart/main0000.html?DbPAR=CHART">Đồ thị trong LibreOffice</a></li>\
    <li><a target="_top" href="vi/text/schart/main0503.html?DbPAR=CHART">Tính năng tạo biểu đồ của LibreOffice</a></li>\
    <li><a target="_top" href="vi/text/schart/04/01020000.html?DbPAR=CHART">Các phím tắt dùng cho biểu đồ</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Macros and Scripting</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="vi/text/sbasic/shared/main0601.html?DbPAR=BASIC">Trợ giúp LibreOffice Basic</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01000000.html?DbPAR=BASIC">Lập trình bằng LibreOffice Basic</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/00000002.html?DbPAR=BASIC">Từ điển Thuật ngữ LibreOffice Basic</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01010210.html?DbPAR=BASIC">Thông tin Cơ bản</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01020000.html?DbPAR=BASIC">Cú pháp</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01030100.html?DbPAR=BASIC">Toàn cảnh IDE</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01030200.html?DbPAR=BASIC">Trình Sửa Basic</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01050100.html?DbPAR=BASIC">Cửa sổ Quan sát</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/main0211.html?DbPAR=BASIC">Thanh công cụ Vĩ lệnh</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/05060700.html?DbPAR=BASIC">Vĩ lệnh</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Command Reference</label><ul>\
    <li><a target="_top" href="vi/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01020500.html?DbPAR=BASIC">Thư viện, Mô-đun và Hộp thoại</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Functions, Statements and Operators</label><ul>\
    <li><a target="_top" href="vi/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100000.html?DbPAR=BASIC">Biến</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03060000.html?DbPAR=BASIC">Toán tử Lôgic</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120000.html?DbPAR=BASIC">Chuỗi</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030000.html?DbPAR=BASIC">Hàm Ngày và Giờ</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03070000.html?DbPAR=BASIC">Toán tử</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080000.html?DbPAR=BASIC">Hàm thuộc số</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080100.html?DbPAR=BASIC">Hàm lượng giác</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010000.html?DbPAR=BASIC">Hàm V/R Màn hình</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020000.html?DbPAR=BASIC">Hàm V/R Tập Tin</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090000.html?DbPAR=BASIC">Điều khiển sự thực hiện chương trình</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03050000.html?DbPAR=BASIC">Hàm Quản Lý Lỗi</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03130000.html?DbPAR=BASIC">Các lệnh khác</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080300.html?DbPAR=BASIC">Tạo ra các số ngẫu nhiên</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090400.html?DbPAR=BASIC">Câu lệnh bổ sung</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alphabetic List of Functions, Statements and Operators</label><ul>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03050000.html?DbPAR=BASIC">Hàm Quản Lý Lỗi</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080000.html?DbPAR=BASIC">Hàm thuộc số</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080400.html?DbPAR=BASIC">Tính căn bậc hai</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write Statement</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03120300.html?DbPAR=BASIC">Chỉnh Sửa Nội Dung Chuỗi</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01020100.html?DbPAR=BASIC">Sử dụng Biến</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Advanced Basic Libraries</label><ul>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard Library</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Library</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForge Library</label><ul>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge Libraries</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guides</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/macro_recording.html?DbPAR=BASIC">Recording a Macro</a></li>\
    <li><a target="_top" href="vi/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Thay đổi các Các thuộc tính của Điều khiển trong bộ Sửa Hộp thoại</a></li>\
    <li><a target="_top" href="vi/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Tạo Điều khiển trong bộ Sửa Hộp thoại</a></li>\
    <li><a target="_top" href="vi/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Mẫu thí dụ Lập trình cho Điều khiển trong bộ Sửa Hộp thoại</a></li>\
    <li><a target="_top" href="vi/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="vi/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Tạo hộp thoại Basic</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01030400.html?DbPAR=BASIC">Tổ chức các Thư viện và Mô-đun</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01020100.html?DbPAR=BASIC">Sử dụng Biến</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01020200.html?DbPAR=BASIC">Sử dụng Đối tượng</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01030300.html?DbPAR=BASIC">Gỡ lỗi một Chương trình Basic</a></li>\
    <li><a target="_top" href="vi/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="vi/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="vi/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic to Python</a></li>\
    <li><a target="_top" href="vi/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python Scripts Help</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="vi/text/sbasic/python/main0000.html?DbPAR=BASIC">Python Scripts</a></li>\
    <li><a target="_top" href="vi/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE for Python</a></li>\
    <li><a target="_top" href="vi/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="vi/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programming with Python</label><ul>\
    <li><a target="_top" href="vi/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="vi/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python examples</a></li>\
    <li><a target="_top" href="vi/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Script Development Tools</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice Installation</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Changing the Association of Microsoft Office Document Types</a></li>\
    <li><a target="_top" href="vi/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Safe Mode</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Common Help Topics</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">General Information</label><ul>\
    <li><a target="_top" href="vi/text/shared/main0400.html?DbPAR=SHARED">Phím tắt</a></li>\
    <li><a target="_top" href="vi/text/shared/00/00000005.html?DbPAR=SHARED">Từ điển thuật ngữ tổng quát</a></li>\
    <li><a target="_top" href="vi/text/shared/00/00000002.html?DbPAR=SHARED">Từ điển các thuật ngữ Internet</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/accessibility.html?DbPAR=SHARED">Accessibility in LibreOffice</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/keyboard.html?DbPAR=SHARED">Phím tắt (Khả năng truy cập bảng LibreOffice Calc)</a></li>\
    <li><a target="_top" href="vi/text/shared/04/01010000.html?DbPAR=SHARED">Phím tắt chung trong LibreOffice</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/version_number.html?DbPAR=SHARED">Versions and Build Numbers</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice and Microsoft Office</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/ms_user.html?DbPAR=SHARED">Using Microsoft Office and LibreOffice</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Comparing Microsoft Office and LibreOffice Terms</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">About Converting Microsoft Office Documents</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Changing the Association of Microsoft Office Document Types</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice Options</label><ul>\
    <li><a target="_top" href="vi/text/shared/optionen/01000000.html?DbPAR=SHARED">Tùy chọn</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01010100.html?DbPAR=SHARED">Dữ liệu Người dùng</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01010200.html?DbPAR=SHARED">Chung</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01010800.html?DbPAR=SHARED">Xem</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01010900.html?DbPAR=SHARED">Tùy chọn in</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01010300.html?DbPAR=SHARED">Đường dẫn</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01010700.html?DbPAR=SHARED">Phông</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01030300.html?DbPAR=SHARED">Bảo mật</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01012000.html?DbPAR=SHARED">Application Colors</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01013000.html?DbPAR=SHARED">Khả năng truy cập</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/java.html?DbPAR=SHARED">Advanced</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01010400.html?DbPAR=SHARED">Đồ giúp viết</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01010600.html?DbPAR=SHARED">Chung</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01020000.html?DbPAR=SHARED">Tùy chọn Nạp/Lưu</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01030000.html?DbPAR=SHARED">Tùy chọn Internet</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01040000.html?DbPAR=SHARED">Tùy chọn Tài liệu Văn bản</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01050000.html?DbPAR=SHARED">Tùy chọn Tài liệu HTML</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01060000.html?DbPAR=SHARED">Tùy chọn Bảng tính</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01070000.html?DbPAR=SHARED">Tùy chọn Trình diễn</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01080000.html?DbPAR=SHARED">Tùy chọn vẽ</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01090000.html?DbPAR=SHARED">Công thức</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01110000.html?DbPAR=SHARED">Tùy chọn Đồ thị</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01130100.html?DbPAR=SHARED">Thuộc tính VBA</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01150000.html?DbPAR=SHARED">Tùy chọn Thiết lập Ngôn ngữ</a></li>\
    <li><a target="_top" href="vi/text/shared/optionen/01160000.html?DbPAR=SHARED">Tùy chọn nguồn dữ liệu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Wizards</label><ul>\
    <li><a target="_top" href="vi/text/shared/autopi/01000000.html?DbPAR=SHARED">Trợ lý</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Trợ lý Thư</label><ul>\
    <li><a target="_top" href="vi/text/shared/autopi/01010000.html?DbPAR=SHARED">Trợ lý Thư</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Trợ lý Điện thư</label><ul>\
    <li><a target="_top" href="vi/text/shared/autopi/01020000.html?DbPAR=SHARED">Trợ lý Điện thư</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Trợ lý Nghị sự</label><ul>\
    <li><a target="_top" href="vi/text/shared/autopi/01040000.html?DbPAR=SHARED">Trợ lý Nghị sự</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML Export Wizard</label><ul>\
    <li><a target="_top" href="vi/text/shared/autopi/01110000.html?DbPAR=SHARED">Xuất dạng HTML</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Document Converter Wizard</label><ul>\
    <li><a target="_top" href="vi/text/shared/autopi/01130000.html?DbPAR=SHARED">Bộ Chuyển đổi Tài liệu</a></li>\
      </ul></li>\
    <li><a target="_top" href="vi/text/shared/autopi/01150000.html?DbPAR=SHARED">Trợ lý Chuyển đổi Euro</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configuring LibreOffice</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/configure_overview.html?DbPAR=SHARED">Configuring LibreOffice</a></li>\
    <li><a target="_top" href="vi/text/shared/01/packagemanager.html?DbPAR=SHARED">Bộ Quản Lý Phần Mở Rộng</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/flat_icons.html?DbPAR=SHARED">Thay đổi ô Xem bảng</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Adding Buttons to Toolbars</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/workfolder.html?DbPAR=SHARED">Changing Your Working Directory</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Registering an Address Book</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/formfields.html?DbPAR=SHARED">Chèn và Sửa Chú thích</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Working with the User Interface</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navigation to Quickly Reach Objects</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/navigator.html?DbPAR=SHARED">Navigator for Document Overview</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/autohide.html?DbPAR=SHARED">Showing, Docking and Hiding Windows</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/textmode_change.html?DbPAR=SHARED">Switching Between Insert Mode and Overwrite Mode</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Using Toolbars</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digital Signatures</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/digital_signatures.html?DbPAR=SHARED">About Digital Signatures</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Applying Digital Signatures</a></li>\
    <li><a target="_top" href="vi/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="vi/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="vi/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="vi/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="vi/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Printing, Faxing, Sending</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/labels_database.html?DbPAR=SHARED">Printing Address Labels</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Printing in Black and White</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/fax.html?DbPAR=SHARED">Sending Faxes and Configuring LibreOffice for Faxing</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Drag & Drop</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/dragdrop.html?DbPAR=SHARED">Dragging and Dropping Within a LibreOffice Document</a></li>\
    <li><a target="_top" href="vi/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Di chuyển và Sao chép Văn bản trong Tài liệu</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copying Spreadsheet Areas to Text Documents</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copying Graphics Between Documents</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Copying Graphics From the Gallery</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Drag-and-Drop With the Data Source View</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copy and Paste</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Copying Drawing Objects Into Other Documents</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copying Graphics Between Documents</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Copying Graphics From the Gallery</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copying Spreadsheet Areas to Text Documents</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Charts and Diagrams</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/chart_insert.html?DbPAR=SHARED">Inserting Charts</a></li>\
    <li><a target="_top" href="vi/text/schart/main0000.html?DbPAR=SHARED">Đồ thị trong LibreOffice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Load, Save, Import, Export, PDF</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/doc_open.html?DbPAR=SHARED">Opening Documents</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/import_ms.html?DbPAR=SHARED">Opening documents saved in other formats</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/doc_save.html?DbPAR=SHARED">Saving Documents</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Saving Documents Automatically</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/export_ms.html?DbPAR=SHARED">Saving Documents in Other Formats</a></li>\
    <li><a target="_top" href="vi/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Xuất dạng PDF</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Importing and Exporting Data in Text Format</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Links and References</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Inserting Hyperlinks</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Relative and Absolute Links</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Editing Hyperlinks</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Document Version Tracking</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Comparing Versions of a Document</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Merging Versions</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Recording Changes</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/redlining.html?DbPAR=SHARED">Recording and Displaying Changes</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Accepting or Rejecting Changes</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Version Management</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Labels and Business Cards</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/labels.html?DbPAR=SHARED">Creating and Printing Labels and Business Cards</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Inserting External Data</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/copytable2application.html?DbPAR=SHARED">Inserting Data From Spreadsheets</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/copytext2application.html?DbPAR=SHARED">Inserting Data From Text Documents</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Inserting, Editing, Saving Bitmaps</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Adding Graphics to the Gallery</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automatic Functions</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Turning off Automatic URL Recognition</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Searching and Replacing</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/data_search2.html?DbPAR=SHARED">Searching With a Form Filter</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_search.html?DbPAR=SHARED">Searching Tables and Form Documents</a></li>\
    <li><a target="_top" href="vi/text/shared/01/02100001.html?DbPAR=SHARED">Danh sách Biểu thức Chính quy</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guides</label><ul>\
    <li><a target="_top" href="vi/text/shared/guide/linestyles.html?DbPAR=SHARED">Applying Line Styles</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/text_color.html?DbPAR=SHARED">Changing the Color of Text</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/change_title.html?DbPAR=SHARED">Changing the Title of a Document</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/round_corner.html?DbPAR=SHARED">Creating Round Corners</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/background.html?DbPAR=SHARED">Xác định Màu Nền hay Ảnh Nền</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Defining Line Styles</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Editing Graphic Objects</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/line_intext.html?DbPAR=SHARED">Drawing Lines in Text</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/aaa_start.html?DbPAR=SHARED">First Steps</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserting Objects From the Gallery</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Inserting Special Characters</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/tabs.html?DbPAR=SHARED">Chèn và Sửa Chú thích</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Using Remote Files</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/protection.html?DbPAR=SHARED">Protecting Content in LibreOffice</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Protecting Records</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Selecting the Maximum Printable Area on a Page</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/measurement_units.html?DbPAR=SHARED">Selecting Measurement Units</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/language_select.html?DbPAR=SHARED">Selecting the Document Language</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Thiết kế Bảng</a></li>\
    <li><a target="_top" href="vi/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Turning off Bullets and Numbering for Individual Paragraphs</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
