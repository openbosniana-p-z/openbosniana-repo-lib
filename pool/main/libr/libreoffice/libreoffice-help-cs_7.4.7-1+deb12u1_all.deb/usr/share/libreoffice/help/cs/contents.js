document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Textové dokumenty (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Obecné informace a používání uživatelského rozhraní</label><ul>\
    <li><a target="_top" href="cs/text/swriter/main0000.html?DbPAR=WRITER">Vítejte v nápovědě k aplikaci LibreOffice Writer</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0503.html?DbPAR=WRITER">Funkce obsažené v aplikaci LibreOffice Writer</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/main.html?DbPAR=WRITER">Instrukce pro použití LibreOffice Writer</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Ukotvení a změna velikosti oken</a></li>\
    <li><a target="_top" href="cs/text/swriter/04/01020000.html?DbPAR=WRITER">Klávesové zkratky pro LibreOffice Writer</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/words_count.html?DbPAR=WRITER">Počet slov</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/keyboard.html?DbPAR=WRITER">Používání klávesových zkratek (zpřístupnění programu LibreOffice Writer)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Přehled příkazů a nabídek</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Nabídky</label><ul>\
    <li><a target="_top" href="cs/text/swriter/main0100.html?DbPAR=WRITER">Nabídky</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0101.html?DbPAR=WRITER">Soubor</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0102.html?DbPAR=WRITER">Upravit</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0103.html?DbPAR=WRITER">Zobrazit</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0104.html?DbPAR=WRITER">Vložit</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0105.html?DbPAR=WRITER">Formát</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0115.html?DbPAR=WRITER">Styly (nabídka)</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0110.html?DbPAR=WRITER">Tabulka</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0120.html?DbPAR=WRITER">Nabídka Formulář</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0106.html?DbPAR=WRITER">Nástroje</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0107.html?DbPAR=WRITER">Okno</a></li>\
    <li><a target="_top" href="cs/text/shared/main0108.html?DbPAR=WRITER">Nápověda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Nástrojové lišty</label><ul>\
    <li><a target="_top" href="cs/text/swriter/main0200.html?DbPAR=WRITER">Nástrojové lišty</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0206.html?DbPAR=WRITER">Lišta Odrážky a číslování</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0205.html?DbPAR=WRITER">Lišta Vlastnosti objektu kresby</a></li>\
    <li><a target="_top" href="cs/text/shared/find_toolbar.html?DbPAR=WRITER">Lišta Najít</a></li>\
    <li><a target="_top" href="cs/text/shared/main0226.html?DbPAR=WRITER">Nástrojová lišta Návrh formuláře</a></li>\
    <li><a target="_top" href="cs/text/shared/main0213.html?DbPAR=WRITER">Lišta Navigace ve formuláři</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0202.html?DbPAR=WRITER">Lišta Formátování</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0214.html?DbPAR=WRITER">Lišta vzorců</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0215.html?DbPAR=WRITER">Lišta Rámec</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0203.html?DbPAR=WRITER">Lišta Obrázek</a></li>\
    <li><a target="_top" href="cs/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Nástrojová lišta LibreLogo</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0216.html?DbPAR=WRITER">Lišta objekt OLE</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0210.html?DbPAR=WRITER">Lišta Náhled tisku (Writer)</a></li>\
    <li><a target="_top" href="cs/text/shared/main0214.html?DbPAR=WRITER">Lišta Návrh dotazu</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0213.html?DbPAR=WRITER">Pravítka</a></li>\
    <li><a target="_top" href="cs/text/shared/main0201.html?DbPAR=WRITER">Lišta Standardní</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0208.html?DbPAR=WRITER">Stavový řádek (Writer)</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0204.html?DbPAR=WRITER">Lišta Tabulka</a></li>\
    <li><a target="_top" href="cs/text/shared/main0212.html?DbPAR=WRITER">Lišta Data tabulky</a></li>\
    <li><a target="_top" href="cs/text/swriter/main0220.html?DbPAR=WRITER">Lišta Textový objekt</a></li>\
    <li><a target="_top" href="cs/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Nástrojová lišta Sledování změn</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navigace v textových dokumentech</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Procházení a vybírání pomocí klávesnice</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Přesouvání a kopírování textu v dokumentech</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Uspořádání dokumentu pomocí Navigátoru</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Vkládání hypertextových odkazů pomocí navigátoru</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/navigator.html?DbPAR=WRITER">Navigátor v textových dokumentech</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Použití přímého kurzoru</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formátování textových dokumentů</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Změna orientace stránky (na šířku nebo na výšku)</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/text_capital.html?DbPAR=WRITER">Změna velkých a malých písmen v textu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Skrývání textu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definování různých záhlaví a zápatí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Vložení názvu a čísla kapitoly do záhlaví nebo zápatí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Použití formátování textu při psaní</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/reset_format.html?DbPAR=WRITER">Obnovení vlastností písma</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Používání stylů v režimu vyplňování formátů</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/wrap.html?DbPAR=WRITER">Obtékání textu okolo objektů</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Zarovnání textu na střed stránky pomocí rámce</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Zvýraznění textu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Otáčení textu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/page_break.html?DbPAR=WRITER">Vkládání a odebírání zalomení stránky</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Vytváření a používání stylů stránky</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/subscript.html?DbPAR=WRITER">Vytvoření horního a dolního indexu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Šablony a styly</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Šablony a styly</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Střídání stylů stránek na lichých a sudých stránkách</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/change_header.html?DbPAR=WRITER">Vytvoření stylu stránky založeného na aktuální stránce</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/load_styles.html?DbPAR=WRITER">Použití stylů z jiného dokumentu nebo šablony</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Vytvoření nového stylu z výběru</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Aktualizace stylu z výběru</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/standard_template.html?DbPAR=WRITER">Vytváření a změna výchozích a vlastních šablon</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/template_manager.html?DbPAR=WRITER">Správce šablon</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Obrázky v textových dokumentech</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Vložení obrázku</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Vložení obrázku ze souboru</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Vkládání obrázků z Galerie přetáhnutím myší</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Vložení naskenovaného obrázku</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Vložení grafu z Calcu do textového dokumentu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Vložení obrázku z programu LibreOffice Draw nebo Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabulky v textových dokumentech</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Zapnutí a vypnutí rozpoznávání čísel v tabulkách</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/tablemode.html?DbPAR=WRITER">Úpravy řádků a sloupců pomocí klávesnice</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/table_delete.html?DbPAR=WRITER">Mazání tabulek nebo obsahů tabulek</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/table_insert.html?DbPAR=WRITER">Vkládání tabulek</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Opakování záhlaví tabulky na nové stránce</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Změna velikosti řádků a sloupců v textové tabulce</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objekty v textových dokumentech</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Umístění objektů</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/wrap.html?DbPAR=WRITER">Obtékání textu okolo objektů</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sekce a rámce v textových dokumentech</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/sections.html?DbPAR=WRITER">Použití sekcí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/text_frame.html?DbPAR=WRITER">Vkládání, úpravy a propojování rámců</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/section_edit.html?DbPAR=WRITER">Úpravy sekcí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/section_insert.html?DbPAR=WRITER">Vkládání sekcí</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Obsahy a rejstříky</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Číslování kapitol</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Rejstříky vytvořené uživatelem</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Vytvoření obsahu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/indices_index.html?DbPAR=WRITER">Vytváření abecedních rejstříků</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Rejstříky pokrývající více dokumentů</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Vytvoření seznamu použité literatury</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Úpravy nebo odstraňování položek rejstříku a obsahu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Aktualizace, úpravy a odstraňování rejstříků a obsahů</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Definování položek rejstříků a obsahů</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formátování rejstříku nebo obsahu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Pole v textových dokumentech</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/fields.html?DbPAR=WRITER">O polích</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/fields_date.html?DbPAR=WRITER">Vkládání pevného nebo proměnného pole data</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/field_convert.html?DbPAR=WRITER">Přeměna pole na text</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Výpočty v textových dokumentech</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Výpočty přes více tabulek</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/calculate.html?DbPAR=WRITER">Výpočty v textových dokumentech</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Výpočet a vložení výsledku vzorce do textového dokumentu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Výpočet celkového součtu buněk tabulky</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Výpočet složitých vzorců v textových dokumentech</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Zobrazení výsledku výpočtu z jedné tabulky v jiné</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Speciální textové prvky</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/captions.html?DbPAR=WRITER">Použití popisků</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Podmíněný text</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Podmíněný text pro počty stránek</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/fields_date.html?DbPAR=WRITER">Vkládání pevného nebo proměnného pole data</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Vkládání vstupních polí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Vložení čísel následujících stránek</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Vkládání čísel stránek do zápatí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Skrývání textu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definování různých záhlaví a zápatí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Vložení názvu a čísla kapitoly do záhlaví nebo zápatí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Dotazování na uživatelské údaje v polích a podmínkách</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Vkládání a úpravy poznámek pod čarou a vysvětlivek</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Vzdálenost mezi poznámkami pod čarou</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/header_footer.html?DbPAR=WRITER">O záhlaví a zápatí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formátování záhlaví a zápatí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/text_animation.html?DbPAR=WRITER">Animování textu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Vytvoření hromadného dopisu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automatické funkce</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Přidávání výjimek do seznamu automatických oprav</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/autotext.html?DbPAR=WRITER">Použití automatického textu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Vytvoření číslovaného nebo odrážkového seznamu při psaní</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/auto_off.html?DbPAR=WRITER">Vypnutí funkce Automatické opravy</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatická kontrola pravopisu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Zapnutí a vypnutí rozpoznávání čísel v tabulkách</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Dělení slov</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Číslování a seznamy</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Přidání čísla kapitoly do popisků</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Vytvoření číslovaného nebo odrážkového seznamu při psaní</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Číslování kapitol</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Změna úrovně odstavce seznamu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Kombinování číslovaných seznamů</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Přidání číslování řádků</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Změna číslování v seřazeném seznamu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Definování intervalu číslování</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Přidání číslování</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Číslování a styly odstavce</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Přidání odrážek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Kontrola pravopisu, slovník synonym a jazyky</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatická kontrola pravopisu</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Odebrání slov z uživatelského slovníku</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Slovník synonym</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Kontrola pravopisu a gramatiky</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Užitečné rady</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Vložení textu před tabulku na začátek stránky</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Přechod na určitou záložku</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Načítání, ukládání, import, export a redakční úpravy</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/send2html.html?DbPAR=WRITER">Ukládání textových dokumentů ve formátu HTML</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Vložení celého textového dokumentu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/redaction.html?DbPAR=WRITER">Redakční úprava</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatická redakční úprava</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Hlavní dokumenty</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Hlavní dokument a jeho přílohy</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Odkazy</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/references.html?DbPAR=WRITER">Vkládání křížových odkazů</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Vkládání hypertextových odkazů pomocí navigátoru</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Tisk</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/print_selection.html?DbPAR=WRITER">Výběr tisknutých částí</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Výběr zásobníku papíru</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/print_preview.html?DbPAR=WRITER">Náhled stránky před tiskem</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/print_small.html?DbPAR=WRITER">Tisk více stránek na jeden list</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Vytváření a používání stylů stránky</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Hledání a nahrazování</label><ul>\
    <li><a target="_top" href="cs/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Použití regulárních výrazů při vyhledávání textu</a></li>\
    <li><a target="_top" href="cs/text/shared/01/02100001.html?DbPAR=WRITER">Seznam regulárních výrazů</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML dokumenty (Writer Web)</label><ul>\
    <li><a target="_top" href="cs/text/shared/07/09000000.html?DbPAR=WRITER">Webové stránky</a></li>\
    <li><a target="_top" href="cs/text/shared/02/01170700.html?DbPAR=WRITER">Filtry a formuláře HTML</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/send2html.html?DbPAR=WRITER">Ukládání textových dokumentů ve formátu HTML</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Sešity (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Obecné informace a používání uživatelského rozhraní</label><ul>\
    <li><a target="_top" href="cs/text/scalc/main0000.html?DbPAR=CALC">Vítejte v nápovědě k LibreOffice Calc</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0503.html?DbPAR=CALC">Funkce obsažené v aplikaci LibreOffice Calc</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/keyboard.html?DbPAR=CALC">Klávesové zkratky (zpřístupnění LibreOffice Calc)</a></li>\
    <li><a target="_top" href="cs/text/scalc/04/01020000.html?DbPAR=CALC">Klávesové zkratky pro práci se sešity</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Přesnost výpočtů</a></li>\
    <li><a target="_top" href="cs/text/scalc/05/02140000.html?DbPAR=CALC">Kódy chyb v aplikaci LibreOffice Calc</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060112.html?DbPAR=CALC">Doplňky pro programování v LibreOffice Calc</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/main.html?DbPAR=CALC">Instrukce pro použití LibreOffice Calc</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Přehled příkazů a nabídek</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Nabídky</label><ul>\
    <li><a target="_top" href="cs/text/scalc/main0100.html?DbPAR=CALC">Nabídky</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0101.html?DbPAR=CALC">Soubor</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0102.html?DbPAR=CALC">Upravit</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0103.html?DbPAR=CALC">Zobrazit</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0104.html?DbPAR=CALC">Vložit</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0105.html?DbPAR=CALC">Formát</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0116.html?DbPAR=CALC">List</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0112.html?DbPAR=CALC">Data</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0106.html?DbPAR=CALC">Nástroje</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0107.html?DbPAR=CALC">Okno</a></li>\
    <li><a target="_top" href="cs/text/shared/main0108.html?DbPAR=CALC">Nápověda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Nástrojové lišty</label><ul>\
    <li><a target="_top" href="cs/text/scalc/main0200.html?DbPAR=CALC">Nástrojové lišty</a></li>\
    <li><a target="_top" href="cs/text/shared/find_toolbar.html?DbPAR=CALC">Lišta Najít</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0202.html?DbPAR=CALC">Lišta Formátování</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0203.html?DbPAR=CALC">Lišta Vlastnosti objektu kresby</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0205.html?DbPAR=CALC">Lišta Formátování textu</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0206.html?DbPAR=CALC">Lišta vzorců</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0208.html?DbPAR=CALC">Stavový řádek</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0210.html?DbPAR=CALC">Lišta Náhled tisku</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0214.html?DbPAR=CALC">Lišta Obrázek</a></li>\
    <li><a target="_top" href="cs/text/scalc/main0218.html?DbPAR=CALC">Lišta Nástroje</a></li>\
    <li><a target="_top" href="cs/text/shared/main0201.html?DbPAR=CALC">Lišta Standardní</a></li>\
    <li><a target="_top" href="cs/text/shared/main0212.html?DbPAR=CALC">Lišta Data tabulky</a></li>\
    <li><a target="_top" href="cs/text/shared/main0213.html?DbPAR=CALC">Lišta Navigace ve formuláři</a></li>\
    <li><a target="_top" href="cs/text/shared/main0214.html?DbPAR=CALC">Lišta Návrh dotazu</a></li>\
    <li><a target="_top" href="cs/text/shared/main0226.html?DbPAR=CALC">Nástrojová lišta Návrh formuláře</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Typy funkcí a operátory</label><ul>\
    <li><a target="_top" href="cs/text/scalc/01/04060000.html?DbPAR=CALC">Průvodce funkcí</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060100.html?DbPAR=CALC">Funkce podle kategorie</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060107.html?DbPAR=CALC">Maticové funkce</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060120.html?DbPAR=CALC">Funkce bitových operací</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060101.html?DbPAR=CALC">Databázové funkce</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060102.html?DbPAR=CALC">Datové a časové funkce</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060103.html?DbPAR=CALC">Finanční funkce – první část</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060119.html?DbPAR=CALC">Finanční funkce – část 2</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060118.html?DbPAR=CALC">Finanční funkce – část 3</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060104.html?DbPAR=CALC">Informační funkce</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060105.html?DbPAR=CALC">Logické funkce</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060106.html?DbPAR=CALC">Matematické funkce</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060108.html?DbPAR=CALC">Statistické funkce</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060181.html?DbPAR=CALC">Statistické funkce – část 1</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060182.html?DbPAR=CALC">Statistické funkce – část 2</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060183.html?DbPAR=CALC">Statistické funkce – část 3</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060184.html?DbPAR=CALC">Statistické funkce – část 4</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060185.html?DbPAR=CALC">Statistické funkce – část 5</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060109.html?DbPAR=CALC">Funkce sešitu</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060110.html?DbPAR=CALC">Textové funkce</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060111.html?DbPAR=CALC">Funkce dostupné z doplňků</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060115.html?DbPAR=CALC">Funkce dostupné z doplňků – Analytické funkce, část 1</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060116.html?DbPAR=CALC">Funkce dostupné z doplňků – Analytické funkce, část 2</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/04060199.html?DbPAR=CALC">Operátory v LibreOffice Calc</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Uživatelem definované funkce</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Načítání, ukládání, import, export a redakční úpravy</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/webquery.html?DbPAR=CALC">Vkládání externích dat do tabulky (Webový dotaz)</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/html_doc.html?DbPAR=CALC">Uložení a otevření sešitu ve formátu HTML</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/csv_formula.html?DbPAR=CALC">Import a export textových souborů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/redaction.html?DbPAR=CALC">Redakční úprava</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatická redakční úprava</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formátování</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/text_rotate.html?DbPAR=CALC">Otáčení textu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/text_wrap.html?DbPAR=CALC">Zápis víceřádkového textu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formátování čísel jako textu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/super_subscript.html?DbPAR=CALC">Horní a dolní index</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/row_height.html?DbPAR=CALC">Změna výšky řádku a šířky sloupce</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Použití podmíněného formátování</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Zvýraznění záporných čísel</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Přiřazení formátu pomocí vzorce</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Zadání čísla začínajícího nulou</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/format_table.html?DbPAR=CALC">Formátování sešitů</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/format_value.html?DbPAR=CALC">Formátování čísel s desetinnými místy</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/value_with_name.html?DbPAR=CALC">Vytváření názvů buněk</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/table_rotate.html?DbPAR=CALC">Otáčení tabulek (transponování)</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/rename_table.html?DbPAR=CALC">Přejmenování listu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/year2000.html?DbPAR=CALC">Roky 19xx/20xx</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Zaokrouhlování čísel</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/currency_format.html?DbPAR=CALC">Buňky s formátem měny</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/autoformat.html?DbPAR=CALC">Automatický formát tabulky</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/note_insert.html?DbPAR=CALC">Vkládání a úprava komentářů</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/design.html?DbPAR=CALC">Výběr motivů vzhledu pro sešity</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Zadání zlomků</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtrování a řazení</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/filters.html?DbPAR=CALC">Použití filtrů</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/specialfilter.html?DbPAR=CALC">Použití pokročilých filtrů</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/autofilter.html?DbPAR=CALC">Použití automatického filtru</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/sorted_list.html?DbPAR=CALC">Použití řazených seznamů</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Odstraňování duplicitních hodnot</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Tisk</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/print_title_row.html?DbPAR=CALC">Tisk vybraných řádků nebo sloupců na každé stránce</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/print_landscape.html?DbPAR=CALC">Tisk listu na šířku</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/print_details.html?DbPAR=CALC">Podrobnosti tisku listu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/print_exact.html?DbPAR=CALC">Výběr stránek pro tisk</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Oblasti dat</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/database_define.html?DbPAR=CALC">Definování databázové oblasti</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtrování oblastí buněk</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/database_sort.html?DbPAR=CALC">Řazení dat</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Kontingenční tabulka</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/datapilot.html?DbPAR=CALC">Kontingenční tabulka</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Vytvoření kontingenční tabulky</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Smazání kontingenční tabulky</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Úprava kontingenční tabulky</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtrování kontingenční tabulky</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Výběr výstupní oblasti kontingenční tabulky</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Aktualizace kontingenční tabulky</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Kontingenční graf</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/pivotchart.html?DbPAR=CALC">Kontingenční graf</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Vytvoření kontingenčního grafu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Úprava kontingečních grafů</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtrování v kontingenčních grafech</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Aktualizace kontingenčního grafu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Smazání kontingenčního grafu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Scénáře</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/scenario.html?DbPAR=CALC">Použití scénářů</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Mezisoučty</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Použití nástroje Mezisoučty</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Odkazy</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Adresy a odkazy, absolutní a relativní</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/cellreferences.html?DbPAR=CALC">Vytvoření odkazu na buňku jiného dokumentu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Odkazování do jiných sešitů a odkazování na URL</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Odkazování na buňky metodou táhni a pusť</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/address_auto.html?DbPAR=CALC">Rozpoznání názvů jako adres</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Prohlížení, výběr, kopírování</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/table_view.html?DbPAR=CALC">Změna tabulkového pohledu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/formula_value.html?DbPAR=CALC">Zobrazení vzorců a hodnot</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/line_fix.html?DbPAR=CALC">Ukotvení řádků a sloupců jako záhlaví</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navigace mezi listy sešitu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Kopírování do více listů</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/cellcopy.html?DbPAR=CALC">Kopírování pouze viditelných buněk</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/mark_cells.html?DbPAR=CALC">Výběr několika buněk</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Vzorce a výpočty</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/formulas.html?DbPAR=CALC">Počítání se vzorci</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/formula_copy.html?DbPAR=CALC">Kopírování vzorců</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/formula_enter.html?DbPAR=CALC">Vkládání vzorců</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/formula_value.html?DbPAR=CALC">Zobrazení vzorců a hodnot</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/calculate.html?DbPAR=CALC">Výpočty v sešitech</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/calc_date.html?DbPAR=CALC">Výpočty s údaji času a kalendářních dat</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/calc_series.html?DbPAR=CALC">Automatická tvorba posloupností</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Výpočet časového rozdílu</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/matrixformula.html?DbPAR=CALC">Zadání maticového vzorce</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/wildcards.html?DbPAR=CALC">Použití zástupných znaků ve vzorcích</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Uzamknutí</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/cell_protect.html?DbPAR=CALC">Ochrana buněk před změnami</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Odemknutí buněk</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Psaní maker Calcu</label><ul>\
    <li><a target="_top" href="cs/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Čtení a zápis hodnot do oblastí</a></li>\
    <li><a target="_top" href="cs/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formátování ohraničení v Calcu pomocí maker</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Ostatní</label><ul>\
    <li><a target="_top" href="cs/text/scalc/guide/auto_off.html?DbPAR=CALC">Vypnutí automatických změn</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/consolidate.html?DbPAR=CALC">Konsolidace dat</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/goalseek.html?DbPAR=CALC">Použití funkce Hledat řešení</a></li>\
    <li><a target="_top" href="cs/text/scalc/01/solver.html?DbPAR=CALC">Řešitel</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/multioperation.html?DbPAR=CALC">Provedení vícenásobné operace</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/multitables.html?DbPAR=CALC">Práce s více listy</a></li>\
    <li><a target="_top" href="cs/text/scalc/guide/validity.html?DbPAR=CALC">Platnost obsahu buněk</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Prezentace (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Obecné informace a používání uživatelského rozhraní</label><ul>\
    <li><a target="_top" href="cs/text/simpress/main0000.html?DbPAR=IMPRESS">Vítejte v nápovědě k LibreOffice Impress</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0503.html?DbPAR=IMPRESS">Funkce obsažené v aplikaci LibreOffice Impress</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Použití klávesových zkratek v LibreOffice Impress</a></li>\
    <li><a target="_top" href="cs/text/simpress/04/01020000.html?DbPAR=IMPRESS">Klávesové zkratky pro LibreOffice Impress</a></li>\
    <li><a target="_top" href="cs/text/simpress/04/presenter.html?DbPAR=IMPRESS">Klávesové zkratky Obrazovky přednášejícího</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/main.html?DbPAR=IMPRESS">Instrukce pro použití LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Přehled příkazů a nabídek</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Nabídky</label><ul>\
    <li><a target="_top" href="cs/text/simpress/main0100.html?DbPAR=IMPRESS">Nabídky</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0101.html?DbPAR=IMPRESS">Soubor</a></li>\
    <li><a target="_top" href="cs/text/simpress/main_edit.html?DbPAR=IMPRESS">Upravit</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0103.html?DbPAR=IMPRESS">Zobrazit</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0104.html?DbPAR=IMPRESS">Vložit</a></li>\
    <li><a target="_top" href="cs/text/simpress/main_format.html?DbPAR=IMPRESS">Formát</a></li>\
    <li><a target="_top" href="cs/text/simpress/main_slide.html?DbPAR=IMPRESS">Snímek</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0114.html?DbPAR=IMPRESS">Prezentace</a></li>\
    <li><a target="_top" href="cs/text/simpress/main_tools.html?DbPAR=IMPRESS">Nástroje</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0107.html?DbPAR=IMPRESS">Okno</a></li>\
    <li><a target="_top" href="cs/text/shared/main0108.html?DbPAR=IMPRESS">Nápověda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Nástrojové lišty</label><ul>\
    <li><a target="_top" href="cs/text/simpress/main0200.html?DbPAR=IMPRESS">Nástrojové lišty</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0210.html?DbPAR=IMPRESS">Lišta Kresba</a></li>\
    <li><a target="_top" href="cs/text/shared/main0227.html?DbPAR=IMPRESS">Lišta Upravit body</a></li>\
    <li><a target="_top" href="cs/text/shared/find_toolbar.html?DbPAR=IMPRESS">Lišta Najít</a></li>\
    <li><a target="_top" href="cs/text/shared/main0226.html?DbPAR=IMPRESS">Nástrojová lišta Návrh formuláře</a></li>\
    <li><a target="_top" href="cs/text/shared/main0213.html?DbPAR=IMPRESS">Lišta Navigace ve formuláři</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0214.html?DbPAR=IMPRESS">Lišta Obrázek</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0202.html?DbPAR=IMPRESS">Lišta Čára a výplň</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0213.html?DbPAR=IMPRESS">Lišta Možnosti</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0211.html?DbPAR=IMPRESS">Lišta Osnova</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0209.html?DbPAR=IMPRESS">Pravítka</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0212.html?DbPAR=IMPRESS">Lišta Pořadač snímků</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0204.html?DbPAR=IMPRESS">Lišta Pohled na snímky</a></li>\
    <li><a target="_top" href="cs/text/shared/main0201.html?DbPAR=IMPRESS">Lišta Standardní</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0206.html?DbPAR=IMPRESS">Stavový řádek</a></li>\
    <li><a target="_top" href="cs/text/shared/main0204.html?DbPAR=IMPRESS">Lišta Tabulka</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0203.html?DbPAR=IMPRESS">Lišta Formátování textu</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Načítání, ukládání, import, export a redakční úpravy</label><ul>\
    <li><a target="_top" href="cs/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Uložení prezentace ve formátu HTML</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Import stránek HTML do prezentací</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Načítání palet barev, přechodů a šrafování</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Export animací ve formátu GIF</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Vkládání sešitů do snímků</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Vložení obrázku</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Vložit snímek ze souboru</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redakční úprava</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatická redakční úprava</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formátování</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Načítání palet barev, přechodů a šrafování</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Načtení stylů čar a šipek</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Definice vlastních barev</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Vytvoření barevného přechodu</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Nahrazování barev</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Uspořádání, zarovnání a rozmístění objektů</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/background.html?DbPAR=IMPRESS">Změna výplně pozadí snímku</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/footer.html?DbPAR=IMPRESS">Přidání záhlaví a zápatí pro všechny snímky</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Změna a přidání předlohy stránky</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Přesouvání objektů</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Tisk</label><ul>\
    <li><a target="_top" href="cs/text/simpress/guide/printing.html?DbPAR=IMPRESS">Tisk prezentací</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Vytištění snímku, aby se vešel na papír</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Efekty</label><ul>\
    <li><a target="_top" href="cs/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Export animací ve formátu GIF</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animace objektů na snímcích prezentace</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animace přechodů mezi snímky</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Přechod tvarů dvou objektů</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Vytváření animovaných obrázků ve formátu GIF</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objekty, obrázky a rastry</label><ul>\
    <li><a target="_top" href="cs/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Skládání objektů a konstrukce tvarů</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Seskupení objektů</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Kreslení výsečí a úsečí</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplikování objektů</a></li>\
    <li><a target="_top" href="cs/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformace</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Otáčení objektů</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Skládání 3D objektů</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Spojování čar</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Převod znaků textu na objekty kresby</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Převod rastrových obrázků na vektorovou grafiku</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Převod 2D objektů na křivky, mnohoúhelníky a 3D objekty</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Načtení stylů čar a šipek</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Kreslení křivek</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Úprava křivek</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Vložení obrázku</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Vkládání sešitů do snímků</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Přesouvání objektů</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Výběr objektů vespod</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Vytvoření vývojového diagramu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text v prezentacích</label><ul>\
    <li><a target="_top" href="cs/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Přidání textu</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Převod znaků textu na objekty kresby</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Prohlížení</label><ul>\
    <li><a target="_top" href="cs/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Změna pořadí snímků</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Přibližování pomocí klávesnice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Prezentace</label><ul>\
    <li><a target="_top" href="cs/text/simpress/guide/show.html?DbPAR=IMPRESS">Zobrazení prezentace</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Použití obrazovky přednášejícího</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Příručka pro Impress Remote</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/individual.html?DbPAR=IMPRESS">Vytvoření vlastní prezentace</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Vyzkoušení časování změn snímků</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Kresby (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Obecné informace a používání uživatelského rozhraní</label><ul>\
    <li><a target="_top" href="cs/text/sdraw/main0000.html?DbPAR=DRAW">Vítejte v nápovědě k LibreOffice Draw</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main0503.html?DbPAR=DRAW">Funkce obsažené v aplikaci LibreOffice Draw</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Klávesové zkratky pro objekty kresby</a></li>\
    <li><a target="_top" href="cs/text/sdraw/04/01020000.html?DbPAR=DRAW">Klávesové zkratky pro kreslení</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/main.html?DbPAR=DRAW">Instrukce pro použití LibreOffice Draw</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Přehled příkazů a nabídek</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Nabídky</label><ul>\
    <li><a target="_top" href="cs/text/sdraw/main0100.html?DbPAR=DRAW">Nabídky</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main0101.html?DbPAR=DRAW">Soubor</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main_edit.html?DbPAR=DRAW">Upravit</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main0103.html?DbPAR=DRAW">Zobrazit (nabídka v Draw)</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main_insert.html?DbPAR=DRAW">Vložit</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main_format.html?DbPAR=DRAW">Formát</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main_page.html?DbPAR=DRAW">Stránka</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main_shape.html?DbPAR=DRAW">Tvar</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main_tools.html?DbPAR=DRAW">Nástroje</a></li>\
    <li><a target="_top" href="cs/text/simpress/main0107.html?DbPAR=DRAW">Okno</a></li>\
    <li><a target="_top" href="cs/text/shared/main0108.html?DbPAR=DRAW">Nápověda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Lišty nástrojů</label><ul>\
    <li><a target="_top" href="cs/text/sdraw/main0200.html?DbPAR=DRAW">Nástrojové lišty</a></li>\
    <li><a target="_top" href="cs/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D nastavení</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main0210.html?DbPAR=DRAW">Lišta Kresba</a></li>\
    <li><a target="_top" href="cs/text/shared/main0227.html?DbPAR=DRAW">Lišta Upravit body</a></li>\
    <li><a target="_top" href="cs/text/shared/find_toolbar.html?DbPAR=DRAW">Lišta Najít</a></li>\
    <li><a target="_top" href="cs/text/shared/main0226.html?DbPAR=DRAW">Nástrojová lišta Návrh formuláře</a></li>\
    <li><a target="_top" href="cs/text/shared/main0213.html?DbPAR=DRAW">Lišta Navigace ve formuláři</a></li>\
    <li><a target="_top" href="cs/text/sdraw/main0213.html?DbPAR=DRAW">Lišta Možnosti</a></li>\
    <li><a target="_top" href="cs/text/shared/main0201.html?DbPAR=DRAW">Lišta Standardní</a></li>\
    <li><a target="_top" href="cs/text/shared/main0204.html?DbPAR=DRAW">Lišta Tabulka</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Načítání, ukládání, import a export</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/palette_files.html?DbPAR=DRAW">Načítání palet barev, přechodů a šrafování</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Vložení obrázku</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formátování</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/palette_files.html?DbPAR=DRAW">Načítání palet barev, přechodů a šrafování</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Načtení stylů čar a šipek</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/color_define.html?DbPAR=DRAW">Definice vlastních barev</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/gradient.html?DbPAR=DRAW">Vytvoření barevného přechodu</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Nahrazování barev</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Uspořádání, zarovnání a rozmístění objektů</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/background.html?DbPAR=DRAW">Změna výplně pozadí snímku</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/masterpage.html?DbPAR=DRAW">Změna a přidání předlohy stránky</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/move_object.html?DbPAR=DRAW">Přesouvání objektů</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Tisk</label><ul>\
    <li><a target="_top" href="cs/text/simpress/guide/printing.html?DbPAR=DRAW">Tisk prezentací</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Vytištění snímku, aby se vešel na papír</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Efekty</label><ul>\
    <li><a target="_top" href="cs/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Přechod tvarů dvou objektů</a></li>\
    <li><a target="_top" href="cs/text/shared/01/05350000.html?DbPAR=DRAW">3D efekty</a></li>\
    <li><a target="_top" href="cs/text/simpress/02/10030000.html?DbPAR=DRAW">Transformace</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objekty, obrázky a rastry</label><ul>\
    <li><a target="_top" href="cs/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Skládání objektů a konstrukce tvarů</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Kreslení výsečí a úsečí</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplikování objektů</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Otáčení objektů</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Skládání 3D objektů</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Spojování čar</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/text2curve.html?DbPAR=DRAW">Převod znaků textu na objekty kresby</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/vectorize.html?DbPAR=DRAW">Převod rastrových obrázků na vektorovou grafiku</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/3d_create.html?DbPAR=DRAW">Převod 2D objektů na křivky, mnohoúhelníky a 3D objekty</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Načtení stylů čar a šipek</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/line_draw.html?DbPAR=DRAW">Kreslení křivek</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/line_edit.html?DbPAR=DRAW">Úprava křivek</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Vložení obrázku</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/table_insert.html?DbPAR=DRAW">Vkládání sešitů do snímků</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/move_object.html?DbPAR=DRAW">Přesouvání objektů</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/select_object.html?DbPAR=DRAW">Výběr objektů vespod</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/orgchart.html?DbPAR=DRAW">Vytvoření vývojového diagramu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Skupiny a vrstvy</label><ul>\
    <li><a target="_top" href="cs/text/sdraw/guide/groups.html?DbPAR=DRAW">Seskupení objektů</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/layers.html?DbPAR=DRAW">O vrstvách</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Vkládání vrstev</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Práce s vrstvami</a></li>\
    <li><a target="_top" href="cs/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Přesouvání objektů do jiné vrstvy</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text v kresbách</label><ul>\
    <li><a target="_top" href="cs/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Přidání textu</a></li>\
    <li><a target="_top" href="cs/text/simpress/guide/text2curve.html?DbPAR=DRAW">Převod znaků textu na objekty kresby</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Prohlížení</label><ul>\
    <li><a target="_top" href="cs/text/simpress/guide/change_scale.html?DbPAR=DRAW">Přibližování pomocí klávesnice</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Databázová funkce (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Obecné informace</label><ul>\
    <li><a target="_top" href="cs/text/sdatabase/main.html?DbPAR=BASE">Databáze LibreOffice</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/database_main.html?DbPAR=BASE">Přehled databáze</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_new.html?DbPAR=BASE">Vytvoření nové databáze</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_tables.html?DbPAR=BASE">Práce s tabulkami</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_queries.html?DbPAR=BASE">Práce s dotazy</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_forms.html?DbPAR=BASE">Práce s formuláři</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_reports.html?DbPAR=BASE">Vytvoření sestavy</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_register.html?DbPAR=BASE">Registrace a odstranění databáze</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_im_export.html?DbPAR=BASE">Import a export dat v aplikaci Base</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Provádění příkazů SQL</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Vzorce (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Obecné informace a používání uživatelského rozhraní</label><ul>\
    <li><a target="_top" href="cs/text/smath/main0000.html?DbPAR=MATH">Vítejte v nápovědě k LibreOffice Math</a></li>\
    <li><a target="_top" href="cs/text/smath/main0503.html?DbPAR=MATH">Funkce obsažené v aplikaci LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Prvky vzorce</label><ul>\
    <li><a target="_top" href="cs/text/smath/01/03090100.html?DbPAR=MATH">Unární/binární operátory</a></li>\
    <li><a target="_top" href="cs/text/smath/01/03090200.html?DbPAR=MATH">Relace</a></li>\
    <li><a target="_top" href="cs/text/smath/01/03090800.html?DbPAR=MATH">Množinové operace</a></li>\
    <li><a target="_top" href="cs/text/smath/01/03090400.html?DbPAR=MATH">Funkce</a></li>\
    <li><a target="_top" href="cs/text/smath/01/03090300.html?DbPAR=MATH">Operátory</a></li>\
    <li><a target="_top" href="cs/text/smath/01/03090600.html?DbPAR=MATH">Atributy</a></li>\
    <li><a target="_top" href="cs/text/smath/01/03090500.html?DbPAR=MATH">Závorky</a></li>\
    <li><a target="_top" href="cs/text/smath/01/03090700.html?DbPAR=MATH">Formát</a></li>\
    <li><a target="_top" href="cs/text/smath/01/03091600.html?DbPAR=MATH">Jiné symboly</a></li>\
      </ul></li>\
    <li><a target="_top" href="cs/text/smath/guide/main.html?DbPAR=MATH">Instrukce pro použití LibreOffice Math</a></li>\
    <li><a target="_top" href="cs/text/smath/guide/keyboard.html?DbPAR=MATH">Klávesové zkratky (zpřístupnění LibreOffice Math)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Přehled příkazů a nabídek</label><ul>\
    <li><a target="_top" href="cs/text/smath/main0100.html?DbPAR=MATH">Nabídky</a></li>\
    <li><a target="_top" href="cs/text/smath/main0200.html?DbPAR=MATH">Nástrojové lišty</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Práce se vzorci</label><ul>\
    <li><a target="_top" href="cs/text/smath/guide/align.html?DbPAR=MATH">Ruční zarovnání částí vzorce</a></li>\
    <li><a target="_top" href="cs/text/smath/guide/color.html?DbPAR=MATH">Použití barvy na část vzorce</a></li>\
    <li><a target="_top" href="cs/text/smath/guide/attributes.html?DbPAR=MATH">Změna výchozích atributů</a></li>\
    <li><a target="_top" href="cs/text/smath/guide/brackets.html?DbPAR=MATH">Spojování částí vzorce pomocí závorek</a></li>\
    <li><a target="_top" href="cs/text/smath/guide/comment.html?DbPAR=MATH">Zadávání komentářů</a></li>\
    <li><a target="_top" href="cs/text/smath/guide/newline.html?DbPAR=MATH">Zadávání zalomení řádku</a></li>\
    <li><a target="_top" href="cs/text/smath/guide/parentheses.html?DbPAR=MATH">Vkládání závorek</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Grafy a diagramy</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Obecné informace</label><ul>\
    <li><a target="_top" href="cs/text/schart/main0000.html?DbPAR=CHART">Grafy v LibreOffice</a></li>\
    <li><a target="_top" href="cs/text/schart/main0503.html?DbPAR=CHART">Vlastnosti grafů LibreOffice</a></li>\
    <li><a target="_top" href="cs/text/schart/04/01020000.html?DbPAR=CHART">Klávesové zkratky pro grafy</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makra a skriptování</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Obecné informace a používání uživatelského rozhraní</label><ul>\
    <li><a target="_top" href="cs/text/sbasic/shared/main0601.html?DbPAR=BASIC">Nápověda LibreOffice Basic</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programování v LibreOffice Basic</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/00000002.html?DbPAR=BASIC">Slovník LibreOffice Basic</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01010210.html?DbPAR=BASIC">Základy</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01020000.html?DbPAR=BASIC">Syntaxe</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01030100.html?DbPAR=BASIC">Přehled rozhraní IDE</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01030200.html?DbPAR=BASIC">Editor jazyka Basic</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01050100.html?DbPAR=BASIC">Okno Kukátka</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/main0211.html?DbPAR=BASIC">Nástrojová lišta Makro</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makro</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Podpora maker VBA</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Přehled příkazů</label><ul>\
    <li><a target="_top" href="cs/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Možnosti kompilátoru</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01020300.html?DbPAR=BASIC">Použití procedur, funkcí nebo vlastností</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01020500.html?DbPAR=BASIC">Knihovny, moduly a dialogová okna</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/conventions.html?DbPAR=BASIC">Diagramy syntaxe</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funkce, výrazy a operátory</label><ul>\
    <li><a target="_top" href="cs/text/sbasic/shared/03040000.html?DbPAR=BASIC">Konstanty jazyka Basic</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100000.html?DbPAR=BASIC">Proměnné</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03060000.html?DbPAR=BASIC">Logické operátory</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03110100.html?DbPAR=BASIC">Porovnávací operátory</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120000.html?DbPAR=BASIC">Řetězce</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030000.html?DbPAR=BASIC">Funkce data a času</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03070000.html?DbPAR=BASIC">Matematické operátory</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080000.html?DbPAR=BASIC">Číselné funkce</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080100.html?DbPAR=BASIC">Trigonometrické funkce</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010000.html?DbPAR=BASIC">Funkce pro práci s obrazovkou</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020000.html?DbPAR=BASIC">Funkce pro práci se soubory</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090000.html?DbPAR=BASIC">Řízení běhu programu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funkce pro zpracovávání chyb</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03130000.html?DbPAR=BASIC">Další příkazy</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080300.html?DbPAR=BASIC">Generování náhodných čísel</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">Objekty UNO</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Použití funkcí Calcu v makrech</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Funkce pouze pro VBA</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090400.html?DbPAR=BASIC">Další příkazy</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Abecední seznam funkcí, výrazů a operátorů</label><ul>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080601.html?DbPAR=BASIC">Funkce Abs</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03060100.html?DbPAR=BASIC">Operátor AND</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03104200.html?DbPAR=BASIC">Funkce Array</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120101.html?DbPAR=BASIC">Funkce Asc</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120111.html?DbPAR=BASIC">Funkce AscW</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080101.html?DbPAR=BASIC">Funkce Atn</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03130100.html?DbPAR=BASIC">Příkaz Beep</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010301.html?DbPAR=BASIC">Funkce Blue</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090401.html?DbPAR=BASIC">Příkaz Call</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/CallByName.html?DbPAR=BASIC">Funkce CallByName</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090102.html?DbPAR=BASIC">Příkaz Select...Case</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100100.html?DbPAR=BASIC">Funkce CBool</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120105.html?DbPAR=BASIC">Funkce CByte</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100050.html?DbPAR=BASIC">Funkce CCur</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030116.html?DbPAR=BASIC">Funkce CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030115.html?DbPAR=BASIC">Funkce CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030114.html?DbPAR=BASIC">Funkce CDateFromUnoTime</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030113.html?DbPAR=BASIC">Funkce CDateToUnoTime</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030112.html?DbPAR=BASIC">Funkce CDateFromUnoDate</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030111.html?DbPAR=BASIC">Funkce CDateToUnoDate</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030108.html?DbPAR=BASIC">Funkce CDateFromIso</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030107.html?DbPAR=BASIC">Funkce CDateToIso</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100300.html?DbPAR=BASIC">Funkce CDate</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100400.html?DbPAR=BASIC">Funkce CDbl</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100060.html?DbPAR=BASIC">Funkce CDec</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020401.html?DbPAR=BASIC">Příkaz ChDir</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020402.html?DbPAR=BASIC">Příkaz ChDrive</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090402.html?DbPAR=BASIC">Funkce Choose</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120102.html?DbPAR=BASIC">Funkce Chr</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120112.html?DbPAR=BASIC">Funkce ChrW [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100500.html?DbPAR=BASIC">Funkce CInt</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100600.html?DbPAR=BASIC">Funkce CLng</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020101.html?DbPAR=BASIC">Příkaz Close</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/collection.html?DbPAR=BASIC">Objekt Collection</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100700.html?DbPAR=BASIC">Příkaz Const</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120313.html?DbPAR=BASIC">Funkce ConvertFromURL</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120312.html?DbPAR=BASIC">Funkce ConvertToURL</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080102.html?DbPAR=BASIC">Funkce Cos</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03132400.html?DbPAR=BASIC">Funkce CreateObject</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03131800.html?DbPAR=BASIC">Funkce CreateUnoDialog</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03132000.html?DbPAR=BASIC">Funkce CreateUnoListener</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03131600.html?DbPAR=BASIC">Funkce CreateUnoService</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03131500.html?DbPAR=BASIC">Funkce CreateUnoStruct</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03132300.html?DbPAR=BASIC">Funkce CreateUnoValue</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100900.html?DbPAR=BASIC">Funkce CSng</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101000.html?DbPAR=BASIC">Funkce CStr</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020403.html?DbPAR=BASIC">Funkce CurDir</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100070.html?DbPAR=BASIC">Funkce CVar</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03100080.html?DbPAR=BASIC">Funkce CVErr</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030301.html?DbPAR=BASIC">Funkce Date</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030110.html?DbPAR=BASIC">Funkce DateAdd</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030120.html?DbPAR=BASIC">Funkce DateDiff</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030130.html?DbPAR=BASIC">Funkce DatePart</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030101.html?DbPAR=BASIC">Funkce DateSerial</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030102.html?DbPAR=BASIC">Funkce DateValue</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030103.html?DbPAR=BASIC">Funkce Day</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140000.html?DbPAR=BASIC">Funkce DDB [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090403.html?DbPAR=BASIC">Příkaz Declare</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101100.html?DbPAR=BASIC">Příkaz DefBool</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101110.html?DbPAR=BASIC">Příkaz DefCur</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101300.html?DbPAR=BASIC">Příkaz DefDate</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101400.html?DbPAR=BASIC">Příkaz DefDbl</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101120.html?DbPAR=BASIC">Příkaz DefErr</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101500.html?DbPAR=BASIC">Příkaz DefInt</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101600.html?DbPAR=BASIC">Příkaz DefLng</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101700.html?DbPAR=BASIC">Příkaz DefObj</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101130.html?DbPAR=BASIC">Příkaz DefSng</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03101140.html?DbPAR=BASIC">Příkaz DefStr</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102000.html?DbPAR=BASIC">Příkaz DefVar</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03104300.html?DbPAR=BASIC">Funkce DimArray</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102100.html?DbPAR=BASIC">Příkaz Dim</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020404.html?DbPAR=BASIC">Funkce Dir</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090201.html?DbPAR=BASIC">Příkaz Do...Loop</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090404.html?DbPAR=BASIC">Příkaz End</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/enum.html?DbPAR=BASIC">Příkaz Enum</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03130800.html?DbPAR=BASIC">Funkce Environ</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020301.html?DbPAR=BASIC">Funkce Eof</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03104600.html?DbPAR=BASIC">Funkce EqualUnoObjects</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03060200.html?DbPAR=BASIC">Operátor Eqv</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03104700.html?DbPAR=BASIC">Příkaz Erase</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03050100.html?DbPAR=BASIC">Funkce Erl</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03050200.html?DbPAR=BASIC">Funkce Err</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Objekt Err VBA</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03050300.html?DbPAR=BASIC">Funkce Error</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funkce pro zpracovávání chyb</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090412.html?DbPAR=BASIC">Příkaz Exit</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080201.html?DbPAR=BASIC">Funkce Exp</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020405.html?DbPAR=BASIC">Funkce FileAttr</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020406.html?DbPAR=BASIC">Příkaz FileCopy</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020407.html?DbPAR=BASIC">Funkce FileDateTime</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020415.html?DbPAR=BASIC">Funkce FileExists</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020408.html?DbPAR=BASIC">Funkce FileLen</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103800.html?DbPAR=BASIC">Funkce FindObject</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103900.html?DbPAR=BASIC">Funkce FindPropertyObject</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080501.html?DbPAR=BASIC">Funkce Fix</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090202.html?DbPAR=BASIC">Příkaz For...Next</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090202.html?DbPAR=BASIC">Příkaz For...Next</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120301.html?DbPAR=BASIC">Funkce Format</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03150000.html?DbPAR=BASIC">Funkce FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03170010.html?DbPAR=BASIC">Funkce FormatNumber [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080503.html?DbPAR=BASIC">Funkce Frac</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020102.html?DbPAR=BASIC">Funkce FreeFile</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090405.html?DbPAR=BASIC">Funkce FreeLibrary</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090406.html?DbPAR=BASIC">Příkaz Function</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140001.html?DbPAR=BASIC">Funkce FV [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020409.html?DbPAR=BASIC">Funkce GetAttr</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03132500.html?DbPAR=BASIC">Funkce GetDefaultContext</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03132100.html?DbPAR=BASIC">Funkce GetGuiType</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03131700.html?DbPAR=BASIC">Funkce GetProcessServiceManager</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">Funkce GetPathSeparator</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03131000.html?DbPAR=BASIC">Funkce GetSolarVersion</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03130700.html?DbPAR=BASIC">Funkce GetSystemTicks</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020201.html?DbPAR=BASIC">Příkaz Get</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103450.html?DbPAR=BASIC">Příkaz Global</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090301.html?DbPAR=BASIC">Příkaz GoSub...Return</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090302.html?DbPAR=BASIC">Příkaz GoTo</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010302.html?DbPAR=BASIC">Funkce Green</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03104400.html?DbPAR=BASIC">Funkce HasUnoInterfaces</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080801.html?DbPAR=BASIC">Funkce Hex</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030201.html?DbPAR=BASIC">Funkce Hour</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090103.html?DbPAR=BASIC">Funkce IIf</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090101.html?DbPAR=BASIC">Příkaz If...Then...Else</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03060300.html?DbPAR=BASIC">Operátor Imp</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120401.html?DbPAR=BASIC">Funkce InStr</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120411.html?DbPAR=BASIC">Funkce InStrRev [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03160000.html?DbPAR=BASIC">Funkce Input [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010201.html?DbPAR=BASIC">Funkce InputBox</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020202.html?DbPAR=BASIC">Příkaz Input#</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080502.html?DbPAR=BASIC">Funkce Int</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140002.html?DbPAR=BASIC">Funkce IPmt [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140003.html?DbPAR=BASIC">Funkce IRR [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Operátor Is</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102200.html?DbPAR=BASIC">Funkce IsArray</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102300.html?DbPAR=BASIC">Funkce IsDate</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102400.html?DbPAR=BASIC">Funkce IsEmpty</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102450.html?DbPAR=BASIC">Funkce IsError</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03104000.html?DbPAR=BASIC">Funkce IsMissing</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102600.html?DbPAR=BASIC">Funkce IsNull</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102700.html?DbPAR=BASIC">Funkce IsNumeric</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102800.html?DbPAR=BASIC">Funkce IsObject</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03104500.html?DbPAR=BASIC">Funkce IsUnoStruct</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120315.html?DbPAR=BASIC">Funkce Join</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020410.html?DbPAR=BASIC">Příkaz Kill</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102900.html?DbPAR=BASIC">Funkce LBound</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120302.html?DbPAR=BASIC">Funkce LCase</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120304.html?DbPAR=BASIC">Příkaz LSet</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120305.html?DbPAR=BASIC">Funkce LTrim</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120303.html?DbPAR=BASIC">Funkce Left</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120402.html?DbPAR=BASIC">Funkce Len</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103100.html?DbPAR=BASIC">Příkaz Let</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020203.html?DbPAR=BASIC">Příkaz Line Input#</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020302.html?DbPAR=BASIC">Funkce Loc</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020303.html?DbPAR=BASIC">Funkce Lof</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080202.html?DbPAR=BASIC">Funkce Log</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120306.html?DbPAR=BASIC">Funkce Mid, příkaz Mid</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030202.html?DbPAR=BASIC">Funkce Minute</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140004.html?DbPAR=BASIC">Funkce MIRR [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020411.html?DbPAR=BASIC">Příkaz MkDir</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03070600.html?DbPAR=BASIC">Operátor Mod</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030104.html?DbPAR=BASIC">Funkce Month</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03150002.html?DbPAR=BASIC">Funkce MonthName [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010102.html?DbPAR=BASIC">Funkce MsgBox</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010101.html?DbPAR=BASIC">Příkaz MsgBox</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020412.html?DbPAR=BASIC">Příkaz Name</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">Operátor New</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03060400.html?DbPAR=BASIC">Operátor Not</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030203.html?DbPAR=BASIC">Funkce Now</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140005.html?DbPAR=BASIC">Funkce NPer [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140006.html?DbPAR=BASIC">Funkce NPV [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080000.html?DbPAR=BASIC">Číselné funkce</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080802.html?DbPAR=BASIC">Funkce Oct</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03050500.html?DbPAR=BASIC">Příkaz On Error GoTo ... Resume</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090303.html?DbPAR=BASIC">Příkaz On...GoSub; příkaz On...GoTo</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020103.html?DbPAR=BASIC">Příkaz Open</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103200.html?DbPAR=BASIC">Příkaz Option Base</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103300.html?DbPAR=BASIC">Příkaz Option Explicit</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103350.html?DbPAR=BASIC">Příkaz Option VBASupport</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (v příkazu Function)</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03060500.html?DbPAR=BASIC">Operátor Or</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/partition.html?DbPAR=BASIC">Funkce Partition</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140007.html?DbPAR=BASIC">Funkce Pmt [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140008.html?DbPAR=BASIC">Funkce PPmt [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010103.html?DbPAR=BASIC">Příkaz Print#</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/property.html?DbPAR=BASIC">Příkaz Property</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103400.html?DbPAR=BASIC">Příkaz Public</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020204.html?DbPAR=BASIC">Příkaz Put#</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140009.html?DbPAR=BASIC">Funkce PV [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010304.html?DbPAR=BASIC">Funkce QBColor</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140010.html?DbPAR=BASIC">Funkce Rate [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080301.html?DbPAR=BASIC">Příkaz Randomize</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03102101.html?DbPAR=BASIC">Příkaz ReDim</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010303.html?DbPAR=BASIC">Funkce Red</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090407.html?DbPAR=BASIC">Příkaz Rem</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/replace.html?DbPAR=BASIC">Funkce Replace</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020104.html?DbPAR=BASIC">Příkaz Reset</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/Resume.html?DbPAR=BASIC">Příkaz Resume</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010305.html?DbPAR=BASIC">Funkce RGB</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03010306.html?DbPAR=BASIC">Funkce RGB [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120307.html?DbPAR=BASIC">Funkce Right</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020413.html?DbPAR=BASIC">Příkaz RmDir</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080302.html?DbPAR=BASIC">Funkce Rnd</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03170000.html?DbPAR=BASIC">Funkce Round [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120308.html?DbPAR=BASIC">Příkaz RSet</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120309.html?DbPAR=BASIC">Funkce RTrim</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030204.html?DbPAR=BASIC">Funkce Second</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020304.html?DbPAR=BASIC">Funkce Seek</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020305.html?DbPAR=BASIC">Příkaz Seek#</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090102.html?DbPAR=BASIC">Příkaz Select...Case</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020414.html?DbPAR=BASIC">Příkaz SetAttr</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103700.html?DbPAR=BASIC">Příkaz Set</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080701.html?DbPAR=BASIC">Funkce Sgn</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03130500.html?DbPAR=BASIC">Funkce Shell</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080103.html?DbPAR=BASIC">Funkce Sin</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140011.html?DbPAR=BASIC">Funkce SLN [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120201.html?DbPAR=BASIC">Funkce Space a Spc</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120201.html?DbPAR=BASIC">Funkce Space a Spc</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120314.html?DbPAR=BASIC">Funkce Split</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080401.html?DbPAR=BASIC">Funkce Sqr</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080400.html?DbPAR=BASIC">Výpočet druhé odmocniny</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">Objekt StarDesktop</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103500.html?DbPAR=BASIC">Příkaz Static</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090408.html?DbPAR=BASIC">Příkaz Stop</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120403.html?DbPAR=BASIC">Funkce StrComp</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/strconv.html?DbPAR=BASIC">Funkce StrConv [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120103.html?DbPAR=BASIC">Funkce Str</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120412.html?DbPAR=BASIC">Funkce StrReverse [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120202.html?DbPAR=BASIC">Funkce String</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090409.html?DbPAR=BASIC">Příkaz Sub</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090410.html?DbPAR=BASIC">Funkce Switch</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03140012.html?DbPAR=BASIC">Funkce SYD [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03080104.html?DbPAR=BASIC">Funkce Tan</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03132200.html?DbPAR=BASIC">Objekt ThisComponent</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">Objekt ThisDatabaseDocument</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030205.html?DbPAR=BASIC">Funkce TimeSerial</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030206.html?DbPAR=BASIC">Funkce TimeValue</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030302.html?DbPAR=BASIC">Funkce Time</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030303.html?DbPAR=BASIC">Funkce Timer</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120311.html?DbPAR=BASIC">Funkce Trim</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03131300.html?DbPAR=BASIC">Funkce TwipsPerPixelX</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03131400.html?DbPAR=BASIC">Funkce TwipsPerPixelY</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090413.html?DbPAR=BASIC">Příkaz Type</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103600.html?DbPAR=BASIC">Funkce TypeName a VarType</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03103000.html?DbPAR=BASIC">Funkce UBound</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120310.html?DbPAR=BASIC">Funkce UCase</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120104.html?DbPAR=BASIC">Funkce Val</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03130600.html?DbPAR=BASIC">Funkce Wait</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03130610.html?DbPAR=BASIC">Příkaz WaitUntil</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030105.html?DbPAR=BASIC">Funkce WeekDay</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03150001.html?DbPAR=BASIC">Funkce WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090203.html?DbPAR=BASIC">Příkaz While...Wend</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03090411.html?DbPAR=BASIC">Příkaz With</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03020205.html?DbPAR=BASIC">Příkaz Write</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03060600.html?DbPAR=BASIC">Operátor XOR</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03030106.html?DbPAR=BASIC">Funkce Year</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03070100.html?DbPAR=BASIC">Operátor "-"</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03070200.html?DbPAR=BASIC">Operátor "*"</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03070300.html?DbPAR=BASIC">Operátor "+"</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03070400.html?DbPAR=BASIC">Operátor "/"</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03070700.html?DbPAR=BASIC">Operátor "\"</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03070500.html?DbPAR=BASIC">Operátor "^"</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03120300.html?DbPAR=BASIC">Úprava obsahu řetězce</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01020100.html?DbPAR=BASIC">Použití proměnných</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/conventions.html?DbPAR=BASIC">Diagramy syntaxe</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Pokročilé knihovny Basicu</label><ul>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Knihovna Tools</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Knihovna DEPOT</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Knihovna EURO</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Knihovna FORMWIZARD</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Knihovna GIMMICKS</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">Knihovna ImportWizard</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Knihovna SCHEDULE</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Knihovna SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Knihovna TEMPLATE</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">Knihovna WikiEditor</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">Knihovna ScriptForge</label><ul>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">Knihovny ScriptForge</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Vytváření skriptů Pythonu s knihovnou ScriptForge</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">Signatury metod knihovny ScriptForge</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">Služba ScriptForge.Array (SF_Array)</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">Služba SFDocuments.Base</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">Služba ScriptForge.Basic</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">Služba SFDocuments.Calc</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">Služba SFDocuments.Chart</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">Služba SFDatabases.Database</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">Služba SFDialogs.Dialog</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">Služba SFDialogs.DialogControl</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">Služba ScriptForge.Dictionary</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">Služba SFDocuments.Document</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">Služba ScriptForge.Exception (SF_Exception)</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">Služba ScriptForge.FileSystem</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">Služba SFDocuments.Form</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">Služba SFDocuments.FormControl</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">Služba ScriptForge.L10N</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">Služba SFWidgets.Menu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">Služba ScriptForge.Platform</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">Služba SFWidgets.PopupMenu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">Služba ScriptForge.Region</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">Služba ScriptForge.Services</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">Služba ScriptForge.Session</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">Služba ScriptForge.String (SF_String)</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">Služba ScriptForge.TextStream</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">Služba ScriptForge.Timer</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">Služba ScriptForge.UI</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">Služba SFUnitTests.UnitTest</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">Služba SFDocuments.Writer</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Návody</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/macro_recording.html?DbPAR=BASIC">Záznam makra</a></li>\
    <li><a target="_top" href="cs/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Změna vlastností ovládacích prvků v Editoru dialogových oken</a></li>\
    <li><a target="_top" href="cs/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Vytvoření ovládacích prvků v Editoru dialogových oken</a></li>\
    <li><a target="_top" href="cs/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Příklady programů pro ovládací prvky v Editoru dialogových oken</a></li>\
    <li><a target="_top" href="cs/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Otevření dialogového okna pomocí Basicu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Vytvoření dialogového okna v aplikaci Basic</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01030400.html?DbPAR=BASIC">Správa knihoven a modulů</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01020100.html?DbPAR=BASIC">Použití proměnných</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01020200.html?DbPAR=BASIC">Použití objektů</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01030300.html?DbPAR=BASIC">Ladění programu v Basicu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/shared/01040000.html?DbPAR=BASIC">Makra řízená událostmi dokumentu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Příklady programování v jazyce Basic</a></li>\
    <li><a target="_top" href="cs/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Python z Basicu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Nápověda pro skripty Pythonu</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Obecné informace a používání uživatelského rozhraní</label><ul>\
    <li><a target="_top" href="cs/text/sbasic/python/main0000.html?DbPAR=BASIC">Skripty Pythonu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE pro Python</a></li>\
    <li><a target="_top" href="cs/text/sbasic/python/python_locations.html?DbPAR=BASIC">Uspořádání skriptů Pythonu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/python/python_shell.html?DbPAR=BASIC">Interaktivní shell Pythonu</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programování pomocí Pythonu</label><ul>\
    <li><a target="_top" href="cs/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python: Programování pomocí Pythonu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/python/python_examples.html?DbPAR=BASIC">Příklady v Pythonu</a></li>\
    <li><a target="_top" href="cs/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Basic z Pythonu</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Nástroje pro vývoj skriptů</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/dev_tools.html?DbPAR=BASIC">Nástroje pro vývojáře</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Instalace LibreOffice</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Změna asociace dokumentů typu Microsoft Office</a></li>\
    <li><a target="_top" href="cs/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Nouzový režim</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Společná témata nápovědy</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Obecné informace</label><ul>\
    <li><a target="_top" href="cs/text/shared/main0400.html?DbPAR=SHARED">Klávesové zkratky</a></li>\
    <li><a target="_top" href="cs/text/shared/00/00000005.html?DbPAR=SHARED">Obecná terminologie</a></li>\
    <li><a target="_top" href="cs/text/shared/00/00000002.html?DbPAR=SHARED">Výklad pojmů - terminologie Internetu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/accessibility.html?DbPAR=SHARED">Zpřístupnění LibreOffice</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/keyboard.html?DbPAR=SHARED">Klávesové zkratky (zpřístupnění LibreOffice)</a></li>\
    <li><a target="_top" href="cs/text/shared/04/01010000.html?DbPAR=SHARED">Všeobecné klávesové zkratky v LibreOffice</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/version_number.html?DbPAR=SHARED">Verze a čísla sestavení</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice a Microsoft Office</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/ms_user.html?DbPAR=SHARED">Použití Microsoft Office a LibreOffice</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Srovnání termínů Microsoft Office a LibreOffice</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">O převodu dokumentů Microsoft Office</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Změna asociace dokumentů typu Microsoft Office</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Možnosti LibreOffice</label><ul>\
    <li><a target="_top" href="cs/text/shared/optionen/01000000.html?DbPAR=SHARED">Možnosti</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01010100.html?DbPAR=SHARED">Uživatelské údaje</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01010200.html?DbPAR=SHARED">Obecné</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01010800.html?DbPAR=SHARED">Zobrazit</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01010900.html?DbPAR=SHARED">Možnosti tisku</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01010300.html?DbPAR=SHARED">Cesty</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01010700.html?DbPAR=SHARED">Písma</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01030300.html?DbPAR=SHARED">Zabezpečení</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01012000.html?DbPAR=SHARED">Barvy aplikací</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01013000.html?DbPAR=SHARED">Zpřístupnění</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/java.html?DbPAR=SHARED">Pokročilé</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expertní nastavení</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01010400.html?DbPAR=SHARED">Pomůcky pro psaní</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01010600.html?DbPAR=SHARED">Obecné</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01020000.html?DbPAR=SHARED">Možnosti pro načítání/ukládání</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01030000.html?DbPAR=SHARED">Možnosti Internetu</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01040000.html?DbPAR=SHARED">Možnosti textového dokumentu</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01050000.html?DbPAR=SHARED">Možnosti HTML dokumentu</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01060000.html?DbPAR=SHARED">Možnosti pro sešity</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01070000.html?DbPAR=SHARED">Možnosti pro prezentaci</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01080000.html?DbPAR=SHARED">Možnosti kreslení</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01090000.html?DbPAR=SHARED">Vzorce</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01110000.html?DbPAR=SHARED">Možnosti pro graf</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01130100.html?DbPAR=SHARED">Vlastnosti VBA</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01140000.html?DbPAR=SHARED">Jazyky (Možnosti)</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01150000.html?DbPAR=SHARED">Jazyková nastavení</a></li>\
    <li><a target="_top" href="cs/text/shared/optionen/01160000.html?DbPAR=SHARED">Možnosti pro zdroje dat</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Průvodci</label><ul>\
    <li><a target="_top" href="cs/text/shared/autopi/01000000.html?DbPAR=SHARED">Průvodce</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Průvodce dopisem</label><ul>\
    <li><a target="_top" href="cs/text/shared/autopi/01010000.html?DbPAR=SHARED">Průvodce dopisem</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Průvodce faxem</label><ul>\
    <li><a target="_top" href="cs/text/shared/autopi/01020000.html?DbPAR=SHARED">Průvodce faxem</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Průvodce poradou</label><ul>\
    <li><a target="_top" href="cs/text/shared/autopi/01040000.html?DbPAR=SHARED">Průvodce poradou</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Průvodce exportem do HTML</label><ul>\
    <li><a target="_top" href="cs/text/shared/autopi/01110000.html?DbPAR=SHARED">Exportovat HTML</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Průvodce převodem dokumentů</label><ul>\
    <li><a target="_top" href="cs/text/shared/autopi/01130000.html?DbPAR=SHARED">Konvertor dokumentů</a></li>\
      </ul></li>\
    <li><a target="_top" href="cs/text/shared/autopi/01150000.html?DbPAR=SHARED">Eurokonvertor</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Nastavení LibreOffice</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/configure_overview.html?DbPAR=SHARED">Konfigurace LibreOffice</a></li>\
    <li><a target="_top" href="cs/text/shared/01/packagemanager.html?DbPAR=SHARED">Správce rozšíření</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/flat_icons.html?DbPAR=SHARED">Změna velikosti ikon</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Přidání tlačítek na nástrojové lišty</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/workfolder.html?DbPAR=SHARED">Změna pracovního adresáře</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/standard_template.html?DbPAR=SHARED">Vytváření a změna výchozích a vlastních šablon</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Registrace adresáře</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/formfields.html?DbPAR=SHARED">Vložení a úprava tlačítek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Práce s uživatelským rozhraním</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Rychlá navigace k objektům</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/navigator.html?DbPAR=SHARED">Navigátor a přehled o dokumentu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/autohide.html?DbPAR=SHARED">Zobrazení, ukotvení a skrytí oken</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/textmode_change.html?DbPAR=SHARED">Přepnutí mezi režimem vkládání a režimem přepisování</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Použití nástrojových lišt</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Elektronické podpisy</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Elektronické podpisy</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Použití elektronických podpisů</a></li>\
    <li><a target="_top" href="cs/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">Elektronické podpisy v exportu do PDF</a></li>\
    <li><a target="_top" href="cs/text/shared/01/timestampauth.html?DbPAR=SHARED">Autority časových razítek pro elektronické podpisy</a></li>\
    <li><a target="_top" href="cs/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Podepisování existujících PDF</a></li>\
    <li><a target="_top" href="cs/text/shared/01/addsignatureline.html?DbPAR=SHARED">Přidání podpisového řádku do dokumentu</a></li>\
    <li><a target="_top" href="cs/text/shared/01/signsignatureline.html?DbPAR=SHARED">Podepsání podpisového řádku</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Tisk, fax, odesílání pošty</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/labels_database.html?DbPAR=SHARED">Tisk adresních štítků</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Černobílý tisk</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/email.html?DbPAR=SHARED">Odeslání dokumentu jako e-mailu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/fax.html?DbPAR=SHARED">Odesílání faxů a konfigurace LibreOffice pro faxování</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Přetahování</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/dragdrop.html?DbPAR=SHARED">Přetahování v dokumentu LibreOffice</a></li>\
    <li><a target="_top" href="cs/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Přesouvání a kopírování textu v dokumentech</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kopírování oblasti sešitu do textového dokumentu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kopírování obrázků mezi dokumenty</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kopírování obrázků z galerie</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Přetažení s prohlížečem zdroje dat</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Kopírování a vkládání</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Kopírování objektů kresby do jiných dokumentů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kopírování obrázků mezi dokumenty</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kopírování obrázků z galerie</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kopírování oblasti sešitu do textového dokumentu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Grafy a diagramy</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/chart_insert.html?DbPAR=SHARED">Vkládání grafů</a></li>\
    <li><a target="_top" href="cs/text/schart/main0000.html?DbPAR=SHARED">Grafy v LibreOffice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Načítání, ukládání, import, export, PDF</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/doc_open.html?DbPAR=SHARED">Otevírání dokumentů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/import_ms.html?DbPAR=SHARED">Otevření dokumentů uložených v jiných formátech</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/doc_save.html?DbPAR=SHARED">Ukládání dokumentů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Automatické ukládání dokumentů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/export_ms.html?DbPAR=SHARED">Ukládání dokumentů v jiných formátech</a></li>\
    <li><a target="_top" href="cs/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Exportovat jako PDF</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Import a export dat v textovém formátu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Odkazy</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Vkládání hypertextových odkazů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Relativní a absolutní odkazy</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Úprava hypertextových odkazů</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Sledování změn dokumentu</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Porovnání verzí dokumentu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Sloučení verzí</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Sledování změn</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/redlining.html?DbPAR=SHARED">Zaznamenání a zobrazení změn</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Přijetí nebo odmítnutí změn</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Správa verzí</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Štítky a vizitky</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/labels.html?DbPAR=SHARED">Vytváření a tisk štítků a vizitek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Vkládání externích dat</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/copytable2application.html?DbPAR=SHARED">Vkládání dat ze sešitů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/copytext2application.html?DbPAR=SHARED">Vkládání dat z textových dokumentů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Vložení, úpravy a uložení rastrových obrázků</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Přidání obrázku do galerie</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automatické funkce</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Vypnutí automatického rozpoznání URL</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Hledání a nahrazování</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/data_search2.html?DbPAR=SHARED">Hledání pomocí formulářového filtru</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_search.html?DbPAR=SHARED">Vyhledávání v tabulkách a formulářových dokumentech</a></li>\
    <li><a target="_top" href="cs/text/shared/01/02100001.html?DbPAR=SHARED">Seznam regulárních výrazů</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Návody</label><ul>\
    <li><a target="_top" href="cs/text/shared/guide/linestyles.html?DbPAR=SHARED">Použití stylu čáry</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/text_color.html?DbPAR=SHARED">Změna barvy textu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/change_title.html?DbPAR=SHARED">Změna nadpisu dokumentu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/round_corner.html?DbPAR=SHARED">Zaoblení rohů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/background.html?DbPAR=SHARED">Určení barvy nebo obrázku na pozadí</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/palette_files.html?DbPAR=SHARED">Načítání palet barev, přechodů a šrafování</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/lineend_define.html?DbPAR=SHARED">Definování stylů šipek</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Definování stylu čáry</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Úprava grafických objektů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/line_intext.html?DbPAR=SHARED">Kreslení čar v textu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/aaa_start.html?DbPAR=SHARED">První kroky</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Vkládání objektů z galerie</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Vkládání nezlomitelných mezer, spojovníků a volitelných rozdělení</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Vložení speciálních znaků</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/tabs.html?DbPAR=SHARED">Vložení a úprava kroků tabulátoru</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Použití vzdálených souborů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/protection.html?DbPAR=SHARED">Ochrana obsahu v LibreOffice</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Zamčení záznamů</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Výběr maximální tisknutelné plochy na stránce</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/measurement_units.html?DbPAR=SHARED">Výběr měrných jednotek</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/language_select.html?DbPAR=SHARED">Výběr jazyka dokumentu</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Návrh tabulky</a></li>\
    <li><a target="_top" href="cs/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Vypnutí odrážek a číslování u některých odstavců</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
