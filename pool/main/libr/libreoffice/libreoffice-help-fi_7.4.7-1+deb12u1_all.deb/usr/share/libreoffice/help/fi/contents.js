document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Tekstiasiakirjat (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Yleistietoa ja käyttöliittymän käyttö</label><ul>\
    <li><a target="_top" href="fi/text/swriter/main0000.html?DbPAR=WRITER">LibreOffice Writer</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0503.html?DbPAR=WRITER">Writerin ominaisuudet</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/main.html?DbPAR=WRITER">LibreOffice Writerin käyttöohjeet</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Ikkunoiden kiinnittäminen ja koon muuttaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/04/01020000.html?DbPAR=WRITER">LibreOffice Writerin pikanäppäimet</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/words_count.html?DbPAR=WRITER">Sanojen laskeminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/keyboard.html?DbPAR=WRITER">Näppäinoikoteiden käyttö (LibreOffice Writerin saavutettavuus)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Komento- ja valikkohakemisto</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Valikot</label><ul>\
    <li><a target="_top" href="fi/text/swriter/main0100.html?DbPAR=WRITER">Valikot</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0101.html?DbPAR=WRITER">Tiedosto</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0102.html?DbPAR=WRITER">Muokkaa</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0103.html?DbPAR=WRITER">Näytä</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0104.html?DbPAR=WRITER">Lisää</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0105.html?DbPAR=WRITER">Muotoilu</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0115.html?DbPAR=WRITER">Tyylit-valikko</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0110.html?DbPAR=WRITER">Taulukko</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0120.html?DbPAR=WRITER">Lomake-valikko</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0106.html?DbPAR=WRITER">Työkalut</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0107.html?DbPAR=WRITER">Ikkuna</a></li>\
    <li><a target="_top" href="fi/text/shared/main0108.html?DbPAR=WRITER">Ohje</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Työkalurivit</label><ul>\
    <li><a target="_top" href="fi/text/swriter/main0200.html?DbPAR=WRITER">Työkalurivit</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0206.html?DbPAR=WRITER">Luettelomerkit ja numerointi -palkki</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0205.html?DbPAR=WRITER">Piirroksen ominaisuudet -palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="fi/text/shared/main0226.html?DbPAR=WRITER">Lomakkeen rakenne -palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0213.html?DbPAR=WRITER">Lomakkeen navigointi -palkki</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0202.html?DbPAR=WRITER">Muotoilu-palkki</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0214.html?DbPAR=WRITER">Kaavarivi</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0215.html?DbPAR=WRITER">Kehys-palkki</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0203.html?DbPAR=WRITER">Kuva-palkki</a></li>\
    <li><a target="_top" href="fi/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo-palkki</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0216.html?DbPAR=WRITER">OLE Object Bar</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0210.html?DbPAR=WRITER">Print Preview Bar (Writer)</a></li>\
    <li><a target="_top" href="fi/text/shared/main0214.html?DbPAR=WRITER">Kyselyn suunnittelu -palkki</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0213.html?DbPAR=WRITER">Viivaimet</a></li>\
    <li><a target="_top" href="fi/text/shared/main0201.html?DbPAR=WRITER">Oletus-palkki</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0208.html?DbPAR=WRITER">Tilarivi (Writer)</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0204.html?DbPAR=WRITER">Taulukko-palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0212.html?DbPAR=WRITER">Taulun tiedot -palkki</a></li>\
    <li><a target="_top" href="fi/text/swriter/main0220.html?DbPAR=WRITER">Tekstiobjekti-palkki</a></li>\
    <li><a target="_top" href="fi/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Track Changes Toolbar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Tekstiasiakirjoissa liikkuminen</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Siirtyminen ja valinta näppäimistöä käyttäen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Tekstien siirtäminen ja kopiointi asiakirjoissa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Asiakirjan järjestely rakenneselaimella</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Hyperlinkkien lisääminen rakenneselaimella</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/navigator.html?DbPAR=WRITER">Rakenneselain tekstiasiakirjoissa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Suoran kohdistimen käyttäminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Tekstiasiakirjan muotoilu</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Sivun suunnan vaihtaminen (vaaka- tai pystysuunta)</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/text_capital.html?DbPAR=WRITER">Tekstin aakkoslajin vaihtaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Tekstin piilottaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Erilaisten ylä- tai alatunnisteiden määrittäminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Luvun nimi ja numero ylä- tai alatunnisteeseen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Tekstin muotoilun käyttäminen kirjoitettaessa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/reset_format.html?DbPAR=WRITER">Fonttimääritteiden palauttaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Tyylien käyttö täyttömuotoilutilassa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/wrap.html?DbPAR=WRITER">Tekstin rivitys objektien ympäri</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Kehyksen käyttö tekstin keskittämiseen sivulle</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Tekstin korostaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Tekstin kierto</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/page_break.html?DbPAR=WRITER">Sivunvaihtojen lisääminen ja poistaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Sivutyylien luominen ja käyttö</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/subscript.html?DbPAR=WRITER">Ylä- tai alaindeksitekstin tuottaminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Mallit ja tyylit</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Mallit ja tyylit</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Parillisten ja parittomien sivujen sivutyylit</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/change_header.html?DbPAR=WRITER">Käsiteltävään sivuun perustuvan sivutyylin luominen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/load_styles.html?DbPAR=WRITER">Eri asiakirjasta tai mallista saatavien tyylien käyttäminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Uusien tyylien luominen valinnasta</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Tyylien päivittäminen valinnoista</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/template_manager.html?DbPAR=WRITER">Template Manager</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Kuvat tekstiasiakirjoissa</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Grafiikan lisääminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Kuvan lisääminen tiedostosta</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Kuvien lisääminen galleriasta vetämällä ja pudottamalla</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Skannatun kuvan lisääminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Kaavion kopiointi Calcista tekstiasiakirjaan</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Kuvien lisääminen LibreOffice Impressistä tai Draw&#39;sta</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Taulukot tekstiasiakirjoissa</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Lukujen tunnistuksen kytkeminen taulukoissa käyttöön ja pois</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/tablemode.html?DbPAR=WRITER">Rivien ja sarakkeiden muuttaminen näppäimistöä käyttäen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/table_delete.html?DbPAR=WRITER">Taulukoiden tai taulukkosisältöjen poistaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/table_insert.html?DbPAR=WRITER">Taulukoiden lisääminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Taulukko-otsikon toistaminen uudella sivulla</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Tekstitaulukon sarakkeiden ja rivien koon muuttaminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objektit tekstiasiakirjoissa</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Objektien sijoittelu</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/wrap.html?DbPAR=WRITER">Tekstin rivitys objektien ympäri</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Tekstiasiakirjan osat ja kehykset</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/sections.html?DbPAR=WRITER">Osien käyttö</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/text_frame.html?DbPAR=WRITER">Kehysten lisääminen, muokkaaminen ja linkittäminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/section_edit.html?DbPAR=WRITER">Osien muokkaus</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/section_insert.html?DbPAR=WRITER">Osien lisääminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Sisällysluettelot ja hakemistot</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Lukujen numerointi</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Käyttäjän määrittämät hakemistot</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Sisällysluettelon luominen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/indices_index.html?DbPAR=WRITER">Aakkoshakemistojen luominen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Useita asiakirjoja kattavat hakemistot</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Lähdeluettelon luominen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Hakemisto- ja luettelomerkintöjen muokkaaminen ja poistaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Hakemistojen ja sisällysluetteloiden päivittäminen, muokkaaminen ja poistaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Hakemisto- tai sisällysluettelomerkinnän määrittäminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/indices_form.html?DbPAR=WRITER">Hakemiston tai sisällysluettelon muotoilu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Kentät tekstiasiakirjoissa</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/fields.html?DbPAR=WRITER">Kentistä</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/fields_date.html?DbPAR=WRITER">Pysyvän tai päivittyvän päivämääräkentän lisääminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/field_convert.html?DbPAR=WRITER">Kentän muuntaminen tekstiksi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Laskutoimitukset tekstiasiakirjoissa</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Monitaulukkolaskenta</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/calculate.html?DbPAR=WRITER">Tekstiasiakirjan laskentaominaisuudet</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Lausekkeen laskeminen ja tuloksen liittäminen tekstiasiakirjassa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Yhteissumman laskeminen taulukon soluista</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Monimutkaisten lausekkeiden laskenta tekstiasiakirjoissa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Taulukon laskentatuloksen esittäminen eri taulukossa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Tekstin erikoiselementit</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/captions.html?DbPAR=WRITER">Kuvatekstien käyttö</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Ehdollinen teksti</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Ehdollinen teksti sivujen laskentaan</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/fields_date.html?DbPAR=WRITER">Pysyvän tai päivittyvän päivämääräkentän lisääminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Syöttökenttien lisääminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Muiden sivujen sivunumeroiden lisääminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Sivunumerot alatunnisteisiin</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Tekstin piilottaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Erilaisten ylä- tai alatunnisteiden määrittäminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Luvun nimi ja numero ylä- tai alatunnisteeseen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Käyttäjätietojen kysely kentissä tai ehdoissa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Ala- ja loppuviitteiden lisääminen tai poistaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Alaviitteiden väli</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/header_footer.html?DbPAR=WRITER">Ylä- ja alatunnisteista</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Ylä- ja alatunnisteiden muotoilu</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/text_animation.html?DbPAR=WRITER">Tekstianimaatio</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Joukkokirjeen luominen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automaattiset toiminnot</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Poikkeusten lisääminen automaattisten korjausten luetteloon</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/autotext.html?DbPAR=WRITER">Automaattisen tekstin käyttäminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Luetelmien luominen kirjoitettaessa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/auto_off.html?DbPAR=WRITER">Automaattisen korjauksen sammuttaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automaattinen oikoluku</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Lukujen tunnistuksen kytkeminen taulukoissa käyttöön ja pois</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Tavutus</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numeroinnit ja luettelot</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Lukujen numeroiden lisääminen kuvateksteihin</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Luetelmien luominen kirjoitettaessa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Lukujen numerointi</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Luettelokappaleen luettelotason vaihtaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Numeroitujen luetteloiden yhdistäminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Rivinumeroiden lisääminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Järjestetyn luettelon numeroinnin muuttaminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Numeroalueiden määrittäminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Numeroinnin lisääminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Luettelomerkkien lisääminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Oikoluku, synonyymisanasto ja kielet</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automaattinen oikoluku</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Sanoja poistaminen käyttäjän määrittämästä sanastosta</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Synonyymisanasto</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Oikeinkirjoituksen ja kieliopin tarkistus</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Vinkkejä ongelmien ratkaisuun</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Tekstin lisääminen taulukon edelle sivun yläreunassa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Siirtyminen määrättyyn kirjanmerkkiin</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Lataaminen, tallentaminen, tuonti, vienti ja sanitointi</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/send2html.html?DbPAR=WRITER">Tekstiasiakirjojen tallentaminen HTML-muotoon</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Koko tekstiasiakirjan lisääminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/redaction.html?DbPAR=WRITER">Sanitointi</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automaattinen sanitointi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Perusasiakirjat</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Perusasiakirjat ja osa-asiakirjat</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Linkit ja viitteet</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/references.html?DbPAR=WRITER">Ristiviittauksien lisääminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Hyperlinkkien lisääminen rakenneselaimella</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Tulostus</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/print_selection.html?DbPAR=WRITER">Tulostettavan valitseminen</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Tulostimen paperilokeron valinta</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/print_preview.html?DbPAR=WRITER">Esikatselu ennen tulostusta</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/print_small.html?DbPAR=WRITER">Monisivuinen tulostus arkille</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Sivutyylien luominen ja käyttö</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Etsiminen ja korvaaminen</label><ul>\
    <li><a target="_top" href="fi/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Säännöllisten lausekkeiden käyttäminen tekstihauissa</a></li>\
    <li><a target="_top" href="fi/text/shared/01/02100001.html?DbPAR=WRITER">Säännöllisten lausekkeiden luettelo</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML-asiakirjat (Writer Web)</label><ul>\
    <li><a target="_top" href="fi/text/shared/07/09000000.html?DbPAR=WRITER">Web-sivut</a></li>\
    <li><a target="_top" href="fi/text/shared/02/01170700.html?DbPAR=WRITER">Suodattimet ja lomakkeet HTML:ssä</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/send2html.html?DbPAR=WRITER">Tekstiasiakirjojen tallentaminen HTML-muotoon</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Taulukkolaskenta (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Yleistietoa ja käyttöliittymän käyttö</label><ul>\
    <li><a target="_top" href="fi/text/scalc/main0000.html?DbPAR=CALC">LibreOffice Calc</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0503.html?DbPAR=CALC">LibreOffice Calcin ominaisuudet</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/keyboard.html?DbPAR=CALC">Pikanäppäimet (LibreOffice Calcin saavutettavuus)</a></li>\
    <li><a target="_top" href="fi/text/scalc/04/01020000.html?DbPAR=CALC">Taulukkolaskennan pikanäppäimet</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Laskentatarkkuus</a></li>\
    <li><a target="_top" href="fi/text/scalc/05/02140000.html?DbPAR=CALC">LibreOffice Calcin virhekoodit</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060112.html?DbPAR=CALC">Add-in for Programming in LibreOffice Calc</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/main.html?DbPAR=CALC">LibreOffice Calcin käyttöohjeet</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Komento- ja valikkohakemisto</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Valikot</label><ul>\
    <li><a target="_top" href="fi/text/scalc/main0100.html?DbPAR=CALC">Valikot</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0101.html?DbPAR=CALC">Tiedosto</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0102.html?DbPAR=CALC">Muokkaa</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0103.html?DbPAR=CALC">Näytä</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0104.html?DbPAR=CALC">Lisää</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0105.html?DbPAR=CALC">Muotoilu</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0116.html?DbPAR=CALC">Taulukko</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0112.html?DbPAR=CALC">Tiedot</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0106.html?DbPAR=CALC">Työkalut</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0107.html?DbPAR=CALC">Ikkuna</a></li>\
    <li><a target="_top" href="fi/text/shared/main0108.html?DbPAR=CALC">Ohje</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Työkalurivit</label><ul>\
    <li><a target="_top" href="fi/text/scalc/main0200.html?DbPAR=CALC">Työkalurivit</a></li>\
    <li><a target="_top" href="fi/text/shared/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0202.html?DbPAR=CALC">Muotoilu-palkki</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0203.html?DbPAR=CALC">Piirroksen ominaisuudet -palkki</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0205.html?DbPAR=CALC">Tekstin muotoilu -palkki</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0206.html?DbPAR=CALC">Kaavarivi</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0208.html?DbPAR=CALC">Tilarivi</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0210.html?DbPAR=CALC">Tulostuksen esikatselu -palkki</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0214.html?DbPAR=CALC">Kuva-palkki</a></li>\
    <li><a target="_top" href="fi/text/scalc/main0218.html?DbPAR=CALC">Työkalut-palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0201.html?DbPAR=CALC">Oletus-palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0212.html?DbPAR=CALC">Taulun tiedot -palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0213.html?DbPAR=CALC">Lomakkeen navigointi -palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0214.html?DbPAR=CALC">Kyselyn suunnittelu -palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0226.html?DbPAR=CALC">Lomakkeen rakenne -palkki</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Funktiotyypit ja operaattorit</label><ul>\
    <li><a target="_top" href="fi/text/scalc/01/04060000.html?DbPAR=CALC">Function Wizard</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060100.html?DbPAR=CALC">Functions by Category</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060107.html?DbPAR=CALC">Array Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060120.html?DbPAR=CALC">Bit Operation Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060101.html?DbPAR=CALC">Database Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060102.html?DbPAR=CALC">Date & Time Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060103.html?DbPAR=CALC">Financial Functions Part One</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060119.html?DbPAR=CALC">Financial Functions Part Two</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060118.html?DbPAR=CALC">Financial Functions Part Three</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060104.html?DbPAR=CALC">Information Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060105.html?DbPAR=CALC">Logical Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060106.html?DbPAR=CALC">Mathematical Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060108.html?DbPAR=CALC">Statistics Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060181.html?DbPAR=CALC">Statistical Functions Part One</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060182.html?DbPAR=CALC">Statistical Functions Part Two</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060183.html?DbPAR=CALC">Statistical Functions Part Three</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060184.html?DbPAR=CALC">Statistical Functions Part Four</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060185.html?DbPAR=CALC">Statistical Functions Part Five</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060109.html?DbPAR=CALC">Spreadsheet Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060110.html?DbPAR=CALC">Text Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060111.html?DbPAR=CALC">Add-in Functions</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060115.html?DbPAR=CALC">Add-in Functions, List of Analysis Functions Part One</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060116.html?DbPAR=CALC">Add-in Functions, List of Analysis Functions Part Two</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/04060199.html?DbPAR=CALC">Operators in LibreOffice Calc</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Käyttäjän määrittämät funktiot</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Lataaminen, tallentaminen, tuonti, vienti ja sanitointi</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/webquery.html?DbPAR=CALC">Ulkoisen aineiston lisääminen taulukkoon (web-kysely)</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/html_doc.html?DbPAR=CALC">Taulukoiden tallentaminen ja avaaminen HTML-muodossa</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/csv_formula.html?DbPAR=CALC">Tekstitiedostojen tuonti ja vienti</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/redaction.html?DbPAR=CALC">Sanitointi</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/auto_redact.html?DbPAR=CALC">Automaattinen sanitointi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Muotoilu</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/text_rotate.html?DbPAR=CALC">Tekstin kierto</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/text_wrap.html?DbPAR=CALC">Monirivisen tekstin kirjoittaminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/text_numbers.html?DbPAR=CALC">Lukujen muotoilu tekstinä</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/super_subscript.html?DbPAR=CALC">Tekstin ylä- ja alaindeksit</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/row_height.html?DbPAR=CALC">Rivikorkeuden ja sarakeleveyden muuttaminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Ehdollisen muotoilun käyttäminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Negatiivisten lukujen korostaminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Muotoilun asettaminen kaavalla</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Luvun syöttäminen etunollin</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/format_table.html?DbPAR=CALC">Laskentataulukoiden muotoilu</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/format_value.html?DbPAR=CALC">Desimaalilukujen muotoilu</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/value_with_name.html?DbPAR=CALC">Solujen nimeäminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/table_rotate.html?DbPAR=CALC">Taulukoiden kierto (transponointi)</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/rename_table.html?DbPAR=CALC">Taulukot uudelleen nimeäminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/year2000.html?DbPAR=CALC">Vuodet 19xx/20xx</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Lukujen pyöristys</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/currency_format.html?DbPAR=CALC">Valuuttalukumuoto soluissa</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/autoformat.html?DbPAR=CALC">Automaattisen muotoilun käyttö taulukoissa</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/note_insert.html?DbPAR=CALC">Huomautusten lisääminen ja muokkaaminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/design.html?DbPAR=CALC">Taulukoiden teemojen valinta</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Murtolukujen syöttäminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Suodatus ja lajittelu</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/filters.html?DbPAR=CALC">Suodattimien käyttö</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/autofilter.html?DbPAR=CALC">Automaattisen suodatuksen käyttö</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/sorted_list.html?DbPAR=CALC">Lajitteluluetteloiden käyttö</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Tulostaminen</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/print_title_row.html?DbPAR=CALC">Rivien tai sarakkeiden toistaminen jokaiselle tulostesivulle</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/print_landscape.html?DbPAR=CALC">Taulukoiden tulostaminen vaakasivuille</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/print_details.html?DbPAR=CALC">Taulukon yksityiskohtien tulostaminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/print_exact.html?DbPAR=CALC">Tulostettavien sivujen lukumäärän määritys</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Arvoalueet</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/database_define.html?DbPAR=CALC">Tietokanta-alueiden määritys</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/database_filter.html?DbPAR=CALC">Solualueiden suodatus</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/database_sort.html?DbPAR=CALC">Lajittelu tietokanta-alueilla</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Pivot-taulukko</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/datapilot.html?DbPAR=CALC">Pivot-taulukko</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Pivot-taulukoiden luominen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Pivot-taulukoiden poistaminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Pivot-taulukoiden muokkaaminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Pivot-taulukoiden suodattaminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Pivot-taulukoiden tuotosalueiden valitseminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Pivot-taulukoiden päivittäminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivot-kaavio</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Skenaariot</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/scenario.html?DbPAR=CALC">Skenaarioiden käyttö</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Välisummat</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Soluviitteet</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Osoitteet ja viitteet, absoluuttiset ja suhteelliset</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/cellreferences.html?DbPAR=CALC">Soluun viittaaminen toisessa asiakirjassa</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Viittaaminen toisiin taulukoihin ja URL-osoitteiden viitteet</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Soluviittaus vedä ja pudota -toiminnolla</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/address_auto.html?DbPAR=CALC">Nimien tunnistus osoitteiksi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Selailu, valinta ja kopiointi</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/table_view.html?DbPAR=CALC">Taulukkonäkymän muuttaminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/formula_value.html?DbPAR=CALC">Kaavojen tai arvojen esittäminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/line_fix.html?DbPAR=CALC">Sarakkeiden tai rivien lukitseminen otsikoiksi</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navigointi taulukkovalitsimilla</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Monitaulukkotäyttö</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/cellcopy.html?DbPAR=CALC">Vain näkyvien solujen kopiointi</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/mark_cells.html?DbPAR=CALC">Useiden solujen valitseminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Kaavat ja laskutoimitukset</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/formulas.html?DbPAR=CALC">Kaavoilla laskeminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/formula_copy.html?DbPAR=CALC">Kaavojen kopiointi</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/formula_enter.html?DbPAR=CALC">Kaavojen syöttäminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/formula_value.html?DbPAR=CALC">Kaavojen tai arvojen esittäminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/calculate.html?DbPAR=CALC">Laskenta laskentataulukoissa</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/calc_date.html?DbPAR=CALC">Päivämäärillä ja ajoilla laskeminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/calc_series.html?DbPAR=CALC">Sarjojen automaattinen laskenta</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Aikaerojen laskenta</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/matrixformula.html?DbPAR=CALC">Matriisikaavojen syöttäminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/wildcards.html?DbPAR=CALC">Jokerimerkkien käyttäminen kaavoissa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Suojaus</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/cell_protect.html?DbPAR=CALC">Solujen suojaaminen muutoksilta</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Suojauksen purku soluista</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Calc-makrojen kirjoittaminen</label><ul>\
    <li><a target="_top" href="fi/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="fi/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatting Borders in Calc with Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Muut asiat</label><ul>\
    <li><a target="_top" href="fi/text/scalc/guide/auto_off.html?DbPAR=CALC">Automaattisten muutosten poistaminen käytöstä</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/consolidate.html?DbPAR=CALC">Tietojen yhdistäminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/goalseek.html?DbPAR=CALC">Tavoitteen haun käyttäminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/01/solver.html?DbPAR=CALC">Ratkaisin</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/multioperation.html?DbPAR=CALC">Monilaskennan käyttö</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/multitables.html?DbPAR=CALC">Useiden taulukkojen käyttäminen</a></li>\
    <li><a target="_top" href="fi/text/scalc/guide/validity.html?DbPAR=CALC">Solusisältöjen kelpoisuus</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Esitykset (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Yleistietoa ja käyttöliittymän käyttö</label><ul>\
    <li><a target="_top" href="fi/text/simpress/main0000.html?DbPAR=IMPRESS">LibreOffice Impress</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0503.html?DbPAR=IMPRESS">LibreOffice Impressin ominaisuudet</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Näppäinoikoteiden käyttö LibreOffice Impressissä</a></li>\
    <li><a target="_top" href="fi/text/simpress/04/01020000.html?DbPAR=IMPRESS">LibreOffice Impressin pikanäppäimet</a></li>\
    <li><a target="_top" href="fi/text/simpress/04/presenter.html?DbPAR=IMPRESS">Esittäjän apunäytön pikanäppäimet</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/main.html?DbPAR=IMPRESS">LibreOffice Impressin käyttöohjeet</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Komento- ja valikkohakemisto</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Valikot</label><ul>\
    <li><a target="_top" href="fi/text/simpress/main0100.html?DbPAR=IMPRESS">Valikot</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0101.html?DbPAR=IMPRESS">Tiedosto</a></li>\
    <li><a target="_top" href="fi/text/simpress/main_edit.html?DbPAR=IMPRESS">Muokkaa</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0103.html?DbPAR=IMPRESS">Näytä</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0104.html?DbPAR=IMPRESS">Lisää</a></li>\
    <li><a target="_top" href="fi/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="fi/text/simpress/main_slide.html?DbPAR=IMPRESS">Dia</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0114.html?DbPAR=IMPRESS">Diaesitys</a></li>\
    <li><a target="_top" href="fi/text/simpress/main_tools.html?DbPAR=IMPRESS">Työkalut</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0107.html?DbPAR=IMPRESS">Ikkuna</a></li>\
    <li><a target="_top" href="fi/text/shared/main0108.html?DbPAR=IMPRESS">Ohje</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Työkalurivit</label><ul>\
    <li><a target="_top" href="fi/text/simpress/main0200.html?DbPAR=IMPRESS">Työkalurivit</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0210.html?DbPAR=IMPRESS">Piirros-palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0227.html?DbPAR=IMPRESS">Muokkaa pisteitä -palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="fi/text/shared/main0226.html?DbPAR=IMPRESS">Lomakkeen rakenne -palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0213.html?DbPAR=IMPRESS">Lomakkeen navigointi -palkki</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0214.html?DbPAR=IMPRESS">Kuva-palkki</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0202.html?DbPAR=IMPRESS">Viivat ja täyttö -palkki</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0213.html?DbPAR=IMPRESS">Asetukset-palkki</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0211.html?DbPAR=IMPRESS">Jäsennys-palkki</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0209.html?DbPAR=IMPRESS">Viivaimet</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0212.html?DbPAR=IMPRESS">Diojen lajittelu -palkki</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0204.html?DbPAR=IMPRESS">Dialajittelunäkymä-palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0201.html?DbPAR=IMPRESS">Oletus-palkki</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0206.html?DbPAR=IMPRESS">Tilarivi</a></li>\
    <li><a target="_top" href="fi/text/shared/main0204.html?DbPAR=IMPRESS">Taulukko-palkki</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0203.html?DbPAR=IMPRESS">Tekstin muotoilu -palkki</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Lataaminen, tallentaminen, tuonti, vienti ja sanitointi</label><ul>\
    <li><a target="_top" href="fi/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Esityksen tallennus HTML-muodossa</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/html_import.html?DbPAR=IMPRESS">HTML-sivujen tuonti esityksiin</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Väri-, liukuvärjäys- ja viivoituspalettien lataaminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Animaatioiden vienti GIF-tiedostomuodossa</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Laskentataulukoiden sijoittaminen dioihin</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Kuvan lisäys</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/redaction.html?DbPAR=IMPRESS">Sanitointi</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automaattinen sanitointi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Muotoilu</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Väri-, liukuvärjäys- ja viivoituspalettien lataaminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Viiva- ja nuolityylien lataaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Omien värien sekoittaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Liukuvärjäyksen luominen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Värien korvaaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Objektien järjestäminen, kohdistus ja välien tasaus</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/background.html?DbPAR=IMPRESS">Dian taustatäytön muuttaminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/footer.html?DbPAR=IMPRESS">Ylä- tai alatunnisteen lisääminen joka dialle</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Objektien siirtäminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Tulostaminen</label><ul>\
    <li><a target="_top" href="fi/text/simpress/guide/printing.html?DbPAR=IMPRESS">Esityksen tulostaminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Dian tulostaminen paperikokoon sovittaen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Tehosteet</label><ul>\
    <li><a target="_top" href="fi/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Animaatioiden vienti GIF-tiedostomuodossa</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animoidut objektit esitysdioilla</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animoidut dianvaihdot</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Kahden objektin muodonvaihdos</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">GIF-animaatiokuvien luominen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objektit, piirrokset ja kuvat</label><ul>\
    <li><a target="_top" href="fi/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Objektien nivonta ja muoto-operaatiot</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Objektien ryhmittely</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Sektoreiden ja segmenttien piirtäminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Objektien monistus</a></li>\
    <li><a target="_top" href="fi/text/simpress/02/10030000.html?DbPAR=IMPRESS">Muunnokset</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Osapiirrosten kierto</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">3D-kappaleiden kokoaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Viivojen yhdistäminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Kirjainten muuntaminen piirrosobjekteiksi</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Bittikarttakuvien muuntaminen vektorigrafiikaksi</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Kaksiulotteisten objektien muuntaminen käyriksi, monikulmioiksi ja kolmiulotteisiksi objekteiksi</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Viiva- ja nuolityylien lataaminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Käyrien piirtäminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Käyrien muokkaaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Kuvan lisäys</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Laskentataulukoiden sijoittaminen dioihin</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Objektien siirtäminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Alempien objektien poiminta</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Vuokaavioiden luominen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Teksti esityksissä</label><ul>\
    <li><a target="_top" href="fi/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Tekstin lisääminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Kirjainten muuntaminen piirrosobjekteiksi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Katselu</label><ul>\
    <li><a target="_top" href="fi/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Diojen järjestyksen vaihtaminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Zoomaus näppäimin</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Diaesitykset</label><ul>\
    <li><a target="_top" href="fi/text/simpress/guide/show.html?DbPAR=IMPRESS">Diaesityksen näyttäminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Esittäjän apunäytön käyttäminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/individual.html?DbPAR=IMPRESS">Uusi mukautettu esitys</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Harjoittele dian vaihdon ajoitusta</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Piirrokset (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Yleistä tietoa ja käyttöliittymän käyttäminen</label><ul>\
    <li><a target="_top" href="fi/text/sdraw/main0000.html?DbPAR=DRAW">LibreOffice Draw</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main0503.html?DbPAR=DRAW">LibreOffice Draw&#39;n ominaisuudet</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Piirrosten pikanäppäimet</a></li>\
    <li><a target="_top" href="fi/text/sdraw/04/01020000.html?DbPAR=DRAW">Piirtämisen pikanäppäimet</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/main.html?DbPAR=DRAW">LibreOffice Draw&#39;n käyttöohjeet</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Komento- ja valikkohakemisto</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Valikot</label><ul>\
    <li><a target="_top" href="fi/text/sdraw/main0100.html?DbPAR=DRAW">Valikot</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main0101.html?DbPAR=DRAW">Tiedosto</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main_edit.html?DbPAR=DRAW">Muokkaa</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main0103.html?DbPAR=DRAW">View (menu in Draw)</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main_insert.html?DbPAR=DRAW">Lisää</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main_page.html?DbPAR=DRAW">Sivu</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main_tools.html?DbPAR=DRAW">Työkalut</a></li>\
    <li><a target="_top" href="fi/text/simpress/main0107.html?DbPAR=DRAW">Ikkuna</a></li>\
    <li><a target="_top" href="fi/text/shared/main0108.html?DbPAR=DRAW">Ohje</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Työkalurivit</label><ul>\
    <li><a target="_top" href="fi/text/sdraw/main0200.html?DbPAR=DRAW">Työkalurivit</a></li>\
    <li><a target="_top" href="fi/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D-asetukset</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main0210.html?DbPAR=DRAW">Piirros-palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0227.html?DbPAR=DRAW">Muokkaa pisteitä -palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="fi/text/shared/main0226.html?DbPAR=DRAW">Lomakkeen rakenne -palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0213.html?DbPAR=DRAW">Lomakkeen navigointi -palkki</a></li>\
    <li><a target="_top" href="fi/text/sdraw/main0213.html?DbPAR=DRAW">Asetukset-palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0201.html?DbPAR=DRAW">Oletus-palkki</a></li>\
    <li><a target="_top" href="fi/text/shared/main0204.html?DbPAR=DRAW">Taulukko-palkki</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Lataaminen, tallentaminen, tuonti ja vienti</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/palette_files.html?DbPAR=DRAW">Väri-, liukuvärjäys- ja viivoituspalettien lataaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Kuvan lisäys</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Muotoilu</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/palette_files.html?DbPAR=DRAW">Väri-, liukuvärjäys- ja viivoituspalettien lataaminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Viiva- ja nuolityylien lataaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/color_define.html?DbPAR=DRAW">Omien värien sekoittaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/gradient.html?DbPAR=DRAW">Liukuvärjäyksen luominen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Värien korvaaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Objektien järjestäminen, kohdistus ja välien tasaus</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/background.html?DbPAR=DRAW">Dian taustatäytön muuttaminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/move_object.html?DbPAR=DRAW">Objektien siirtäminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Tulostaminen</label><ul>\
    <li><a target="_top" href="fi/text/simpress/guide/printing.html?DbPAR=DRAW">Esityksen tulostaminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Dian tulostaminen paperikokoon sovittaen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Tehosteet</label><ul>\
    <li><a target="_top" href="fi/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Kahden objektin muodonvaihdos</a></li>\
    <li><a target="_top" href="fi/text/shared/01/05350000.html?DbPAR=DRAW">Kolmiulotteiset tehosteet</a></li>\
    <li><a target="_top" href="fi/text/simpress/02/10030000.html?DbPAR=DRAW">Muunnokset</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objektit, grafiikka ja bittikartat</label><ul>\
    <li><a target="_top" href="fi/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Objektien nivonta ja muoto-operaatiot</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Sektoreiden ja segmenttien piirtäminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Objektien monistus</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Osapiirrosten kierto</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">3D-kappaleiden kokoaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Viivojen yhdistäminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/text2curve.html?DbPAR=DRAW">Kirjainten muuntaminen piirrosobjekteiksi</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/vectorize.html?DbPAR=DRAW">Bittikarttakuvien muuntaminen vektorigrafiikaksi</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/3d_create.html?DbPAR=DRAW">Kaksiulotteisten objektien muuntaminen käyriksi, monikulmioiksi ja kolmiulotteisiksi objekteiksi</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Viiva- ja nuolityylien lataaminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/line_draw.html?DbPAR=DRAW">Käyrien piirtäminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/line_edit.html?DbPAR=DRAW">Käyrien muokkaaminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Kuvan lisäys</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/table_insert.html?DbPAR=DRAW">Laskentataulukoiden sijoittaminen dioihin</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/move_object.html?DbPAR=DRAW">Objektien siirtäminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/select_object.html?DbPAR=DRAW">Alempien objektien poiminta</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/orgchart.html?DbPAR=DRAW">Vuokaavioiden luominen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Ryhmät ja kerrokset</label><ul>\
    <li><a target="_top" href="fi/text/sdraw/guide/groups.html?DbPAR=DRAW">Objektien ryhmittely</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/layers.html?DbPAR=DRAW">Tietoa kerroksista</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Kerrosten lisääminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Kerrosten käyttäminen</a></li>\
    <li><a target="_top" href="fi/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Objektien siirtäminen eri kerrokselle</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Teksti piirroksissa</label><ul>\
    <li><a target="_top" href="fi/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Tekstin lisääminen</a></li>\
    <li><a target="_top" href="fi/text/simpress/guide/text2curve.html?DbPAR=DRAW">Kirjainten muuntaminen piirrosobjekteiksi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Katseleminen</label><ul>\
    <li><a target="_top" href="fi/text/simpress/guide/change_scale.html?DbPAR=DRAW">Zoomaus näppäimin</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Tietokantatoiminnot (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Yleistä tietoa</label><ul>\
    <li><a target="_top" href="fi/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/database_main.html?DbPAR=BASE">Tietokannan yleiskuvaus</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_new.html?DbPAR=BASE">Tietokannan luominen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_tables.html?DbPAR=BASE">Taulujen käyttö</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_queries.html?DbPAR=BASE">Kyselyiden käyttö</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_forms.html?DbPAR=BASE">Lomakkeiden käyttö</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_reports.html?DbPAR=BASE">Raporttien laatiminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_register.html?DbPAR=BASE">Tietokannan rekisteröinti ja poistaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_im_export.html?DbPAR=BASE">Aineiston tuonti ja vienti Basessa</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_enter_sql.html?DbPAR=BASE">SQL-lauseiden suorittaminen</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Kaavat (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Yleistietoa ja käyttöliittymän käyttö</label><ul>\
    <li><a target="_top" href="fi/text/smath/main0000.html?DbPAR=MATH">LibreOffice Math</a></li>\
    <li><a target="_top" href="fi/text/smath/main0503.html?DbPAR=MATH">LibreOffice Mathin ominaisuudet</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOfficen kaavaelementit</label><ul>\
    <li><a target="_top" href="fi/text/smath/01/03090100.html?DbPAR=MATH">Yksi- ja kaksipaikkaiset operaattorit</a></li>\
    <li><a target="_top" href="fi/text/smath/01/03090200.html?DbPAR=MATH">Relaatiot</a></li>\
    <li><a target="_top" href="fi/text/smath/01/03090800.html?DbPAR=MATH">Joukko-operaatiot</a></li>\
    <li><a target="_top" href="fi/text/smath/01/03090400.html?DbPAR=MATH">Funktiot</a></li>\
    <li><a target="_top" href="fi/text/smath/01/03090300.html?DbPAR=MATH">Operaattorit</a></li>\
    <li><a target="_top" href="fi/text/smath/01/03090600.html?DbPAR=MATH">Määritteet</a></li>\
    <li><a target="_top" href="fi/text/smath/01/03090500.html?DbPAR=MATH">Sulkeet</a></li>\
    <li><a target="_top" href="fi/text/smath/01/03090700.html?DbPAR=MATH">Muodot</a></li>\
    <li><a target="_top" href="fi/text/smath/01/03091600.html?DbPAR=MATH">Muut symbolit</a></li>\
      </ul></li>\
    <li><a target="_top" href="fi/text/smath/guide/main.html?DbPAR=MATH">LibreOffice Mathin käyttöohjeet</a></li>\
    <li><a target="_top" href="fi/text/smath/guide/keyboard.html?DbPAR=MATH">Oikotiet (LibreOffice Math ja saavutettavuus)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Komento- ja valikkohakemisto</label><ul>\
    <li><a target="_top" href="fi/text/smath/main0100.html?DbPAR=MATH">Valikot</a></li>\
    <li><a target="_top" href="fi/text/smath/main0200.html?DbPAR=MATH">Työkalurivit</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Kaavojen käyttö</label><ul>\
    <li><a target="_top" href="fi/text/smath/guide/align.html?DbPAR=MATH">Kaavan osien kohdistaminen yksitellen</a></li>\
    <li><a target="_top" href="fi/text/smath/guide/color.html?DbPAR=MATH">Kaavan osien värittäminen</a></li>\
    <li><a target="_top" href="fi/text/smath/guide/attributes.html?DbPAR=MATH">Oletusmääritteiden vaihtaminen</a></li>\
    <li><a target="_top" href="fi/text/smath/guide/brackets.html?DbPAR=MATH">Kaavan osien yhdistely sulkeilla</a></li>\
    <li><a target="_top" href="fi/text/smath/guide/comment.html?DbPAR=MATH">Kommentointi</a></li>\
    <li><a target="_top" href="fi/text/smath/guide/newline.html?DbPAR=MATH">Rivinvaihtojen lisääminen</a></li>\
    <li><a target="_top" href="fi/text/smath/guide/parentheses.html?DbPAR=MATH">Sulkeiden lisääminen</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Kaaviot ja diagrammit</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Yleistietoa</label><ul>\
    <li><a target="_top" href="fi/text/schart/main0000.html?DbPAR=CHART">LibreOffice-kaaviot</a></li>\
    <li><a target="_top" href="fi/text/schart/main0503.html?DbPAR=CHART">LibreOffice-kaavion ominaisuudet</a></li>\
    <li><a target="_top" href="fi/text/schart/04/01020000.html?DbPAR=CHART">Kaavion pikanäppäimet</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makrot ja komentosarjat</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Yleistä tietoa ja käyttöliittymän käyttäminen</label><ul>\
    <li><a target="_top" href="fi/text/sbasic/shared/main0601.html?DbPAR=BASIC">Yleiskuvaus LibreOffice Basicin ohjeista</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01000000.html?DbPAR=BASIC">Ohjelmointi LibreOffice Basicilla</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basic-sanasto</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01010210.html?DbPAR=BASIC">Perusteet</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01020000.html?DbPAR=BASIC">Syntaksi</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basicin kehitysympäristö (IDE)</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01030100.html?DbPAR=BASIC">IDE, yleiskuvaus</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01030200.html?DbPAR=BASIC">Basic-muokkain</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01050100.html?DbPAR=BASIC">Seurantaikkuna</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/main0211.html?DbPAR=BASIC">Makro-palkki</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makro</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Komentohakemisto</label><ul>\
    <li><a target="_top" href="fi/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01020500.html?DbPAR=BASIC">Kirjastot, moduulit ja valintaikkunat</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funktiot, lauseet ja operaattorit</label><ul>\
    <li><a target="_top" href="fi/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic-vakiot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100000.html?DbPAR=BASIC">Muuttujat</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03060000.html?DbPAR=BASIC">Loogiset operaattorit</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120000.html?DbPAR=BASIC">Merkkijonot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030000.html?DbPAR=BASIC">Päivämäärän ja kellonajan funktiot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03070000.html?DbPAR=BASIC">Matemaattiset operaattorit</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numeeriset funktiot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080100.html?DbPAR=BASIC">Trigonometriset funktiot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010000.html?DbPAR=BASIC">Näytön I/O -funktiot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020000.html?DbPAR=BASIC">Tiedoston I/O -funktiot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090000.html?DbPAR=BASIC">Ohjelman suorituksen hallinta</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03050000.html?DbPAR=BASIC">Virheenkäsittelyn funktiot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03130000.html?DbPAR=BASIC">Muut komennot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080300.html?DbPAR=BASIC">Satunnaislukujen tuottaminen</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090400.html?DbPAR=BASIC">Lisää lauseita</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Aakkosellinen luettelo funktioista, lauseista ja operaattoreista</label><ul>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03050000.html?DbPAR=BASIC">Virheenkäsittelyn funktiot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numeeriset funktiot</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080400.html?DbPAR=BASIC">Neliöjuuren laskeminen</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write Statement</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03120300.html?DbPAR=BASIC">Merkkijonon sisällön muokkaaminen</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01020100.html?DbPAR=BASIC">Muuttujien käyttö</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Edistyneet Basic-kirjastot</label><ul>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard Library</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Library</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForge-kirjasto</label><ul>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge Libraries</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Oppaat</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/macro_recording.html?DbPAR=BASIC">Makron nauhoitus</a></li>\
    <li><a target="_top" href="fi/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Ohjausobjektin ominaisuuksien muuttaminen valintaikkunan muokkaimessa</a></li>\
    <li><a target="_top" href="fi/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Ohjausobjektien luominen valintaikkunamuokkaimessa</a></li>\
    <li><a target="_top" href="fi/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Ohjelmointiesimerkkejä: ohjausobjektit valintaikkunan muokkaimessa</a></li>\
    <li><a target="_top" href="fi/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="fi/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Basic-valintaikkunoiden luominen</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01030400.html?DbPAR=BASIC">Kirjastojen ja moduulien järjestäminen</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01020100.html?DbPAR=BASIC">Muuttujien käyttö</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01020200.html?DbPAR=BASIC">Objektien käyttö</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01030300.html?DbPAR=BASIC">Basic-ohjelman vianjäljitys</a></li>\
    <li><a target="_top" href="fi/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="fi/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="fi/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic to Python</a></li>\
    <li><a target="_top" href="fi/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python-komentosarjojen ohje</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Yleistä tietoa ja käyttöliittymän käyttäminen</label><ul>\
    <li><a target="_top" href="fi/text/sbasic/python/main0000.html?DbPAR=BASIC">Python Scripts</a></li>\
    <li><a target="_top" href="fi/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE for Python</a></li>\
    <li><a target="_top" href="fi/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="fi/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Python-ohjelmointi</label><ul>\
    <li><a target="_top" href="fi/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="fi/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python examples</a></li>\
    <li><a target="_top" href="fi/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Komentosarjojen kehitystyökalut</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOfficen asentaminen</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office -asiakirjojen sovelluskytkentöjen muuttaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Vikasietotila</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Ohjeita yleisistä aiheista</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Yleistietoa</label><ul>\
    <li><a target="_top" href="fi/text/shared/main0400.html?DbPAR=SHARED">Pikanäppäimet</a></li>\
    <li><a target="_top" href="fi/text/shared/00/00000005.html?DbPAR=SHARED">Yleissanasto</a></li>\
    <li><a target="_top" href="fi/text/shared/00/00000002.html?DbPAR=SHARED">Internet-termien sanasto</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/accessibility.html?DbPAR=SHARED">Saavutettavuus ja LibreOffice</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/keyboard.html?DbPAR=SHARED">Oikotiet (LibreOffice ja saavutettavuus)</a></li>\
    <li><a target="_top" href="fi/text/shared/04/01010000.html?DbPAR=SHARED">Yleiset  LibreOffice-pikanäppäimet</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/version_number.html?DbPAR=SHARED">Versio- ja pakettinumerot</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice ja Microsoft Office</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/ms_user.html?DbPAR=SHARED">Microsoft Officen ja LibreOfficen käyttäminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Microsoft Officen ja LibreOfficen termien vertailu</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Microsoft Office -asiakirjojen muuntamisesta</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office -asiakirjojen sovelluskytkentöjen muuttaminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice-asetukset</label><ul>\
    <li><a target="_top" href="fi/text/shared/optionen/01000000.html?DbPAR=SHARED">Asetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01010100.html?DbPAR=SHARED">Käyttäjän tiedot</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01010200.html?DbPAR=SHARED">Yleistä</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01010800.html?DbPAR=SHARED">Näytä</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01010900.html?DbPAR=SHARED">Tulostusasetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01010300.html?DbPAR=SHARED">Polut</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01010700.html?DbPAR=SHARED">Fontit</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01030300.html?DbPAR=SHARED">Suojaus</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01012000.html?DbPAR=SHARED">Sovelluksen värit</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01013000.html?DbPAR=SHARED">Saavutettavuus</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/java.html?DbPAR=SHARED">Lisäasetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01010400.html?DbPAR=SHARED">Kirjoituksen aputyökalut</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01010600.html?DbPAR=SHARED">Yleistä</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01020000.html?DbPAR=SHARED">Lataus/tallennus asetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01030000.html?DbPAR=SHARED">Internet-asetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01040000.html?DbPAR=SHARED">Tekstiasiakirjan asetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01050000.html?DbPAR=SHARED">HTML-asiakirjan asetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01060000.html?DbPAR=SHARED">Laskentataulukon asetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01070000.html?DbPAR=SHARED">Esitysasetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01080000.html?DbPAR=SHARED">Piirtämisasetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01090000.html?DbPAR=SHARED">Kaava</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01110000.html?DbPAR=SHARED">Kaavioasetukset</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA-ominaisuudet</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01150000.html?DbPAR=SHARED">Kieliasetuksien valinnat</a></li>\
    <li><a target="_top" href="fi/text/shared/optionen/01160000.html?DbPAR=SHARED">Tietolähteiden asetukset</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Ohjatut toiminnot</label><ul>\
    <li><a target="_top" href="fi/text/shared/autopi/01000000.html?DbPAR=SHARED">Ohjattu toiminto</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Kirjeen luonti ohjatusti</label><ul>\
    <li><a target="_top" href="fi/text/shared/autopi/01010000.html?DbPAR=SHARED">Kirjeen ohjattu luonti</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Ohjattu faksin luonti</label><ul>\
    <li><a target="_top" href="fi/text/shared/autopi/01020000.html?DbPAR=SHARED">Ohjattu faksin luonti</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Esityslistan luonti ohjatusti</label><ul>\
    <li><a target="_top" href="fi/text/shared/autopi/01040000.html?DbPAR=SHARED">Ohjattu esityslistan luonti</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML-sivun vienti ohjatusti</label><ul>\
    <li><a target="_top" href="fi/text/shared/autopi/01110000.html?DbPAR=SHARED">HTML-vienti</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Asiakirjojen ohjattu muunnos</label><ul>\
    <li><a target="_top" href="fi/text/shared/autopi/01130000.html?DbPAR=SHARED">Asiakirjamuunnin</a></li>\
      </ul></li>\
    <li><a target="_top" href="fi/text/shared/autopi/01150000.html?DbPAR=SHARED">Euromuunnin</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">LibreOfficen asetusten muuttaminen</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/configure_overview.html?DbPAR=SHARED">LibreOffice-ohjelmiston kokoonpanon määrittäminen</a></li>\
    <li><a target="_top" href="fi/text/shared/01/packagemanager.html?DbPAR=SHARED">Lisäosien hallinta</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/flat_icons.html?DbPAR=SHARED">Kuvakkeiden koon muuttaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Painikkeiden lisääminen työkalupalkkiin</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/workfolder.html?DbPAR=SHARED">Työhakemiston vaihtaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Osoitekirjan rekisteröinti</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/formfields.html?DbPAR=SHARED">Painikkeiden lisääminen ja muokkaaminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Käyttöliittymän ohjeet</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Objektien nopea selaaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/navigator.html?DbPAR=SHARED">Rakenneselaimen käyttö asiakirjan yleiskatsaukseen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/autohide.html?DbPAR=SHARED">Ikkunoiden näyttäminen, kiinnittäminen ja piilottaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/textmode_change.html?DbPAR=SHARED">Lisäystilan ja korvaustilan välillä vaihtaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Työkalurivien käyttö</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Sähköiset allekirjoitukset</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Digitaalisista allekirjoituksista</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Digitaalisten allekirjoitusten käyttö</a></li>\
    <li><a target="_top" href="fi/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="fi/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="fi/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="fi/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="fi/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Tulostaminen, faksaaminen ja lähettäminen</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/labels_database.html?DbPAR=SHARED">Osoitetarrojen tulostaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Mustavalkotulostus</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/email.html?DbPAR=SHARED">Asiakirjojen lähettäminen sähköpostilla</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/fax.html?DbPAR=SHARED">Faksien lähettäminen ja LibreOffice-faksiasetukset</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Vedä ja pudota</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/dragdrop.html?DbPAR=SHARED">Vedä ja pudota -toiminto LibreOffice-asiakirjassa</a></li>\
    <li><a target="_top" href="fi/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Tekstien siirtäminen ja kopiointi asiakirjoissa</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Laskentataulukon alueiden kopiointi tekstiasiakirjoihin</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kuvien kopiointi asiakirjojen välillä</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kuvien kopiointi galleriasta</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Vedä ja pudota tietolähdenäkymässä</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Kopioi ja liitä</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Piirrosten kopiointi muihin asiakirjoihin</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kuvien kopiointi asiakirjojen välillä</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kuvien kopiointi galleriasta</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Laskentataulukon alueiden kopiointi tekstiasiakirjoihin</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Kaaviot ja diagrammit</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/chart_insert.html?DbPAR=SHARED">Kaavioiden lisääminen</a></li>\
    <li><a target="_top" href="fi/text/schart/main0000.html?DbPAR=SHARED">LibreOffice-kaaviot</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Lataa, tallenna, tuo, vie, PDF</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/doc_open.html?DbPAR=SHARED">Asiakirjojen avaaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/import_ms.html?DbPAR=SHARED">Muissa tiedostomuodoissa tallennettujen asiakirjojen avaaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/doc_save.html?DbPAR=SHARED">Asiakirjojen tallennus</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Asiakirjojen tallentaminen automaattisesti</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/export_ms.html?DbPAR=SHARED">Asiakirjojen tallentaminen muihin tiedostomuotoihin</a></li>\
    <li><a target="_top" href="fi/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Vie PDF-asiakirjana</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Tekstimuotoisen aineiston tuonti ja vienti</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Linkit ja viitteet</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Hyperlinkkien lisääminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Suhteelliset ja absoluuttiset linkit</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Hyperlinkkien muokkaus</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Asiakirjan versioiden hallinta</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Asiakirjan versioiden vertailu</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Versioiden yhdistäminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Muutosten nauhoittaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/redlining.html?DbPAR=SHARED">Muutoksien nauhoittaminen ja esittäminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Muutoksien hyväksyntä tai hylkäys</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Versiohallinta</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Tarrat ja käyntikortit</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/labels.html?DbPAR=SHARED">Osoitetarrojen ja käyntikorttien laatiminen ja tulostus</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Ulkoisten tietojen lisääminen</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/copytable2application.html?DbPAR=SHARED">Aineiston lisääminen laskentataulukosta</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/copytext2application.html?DbPAR=SHARED">Aineiston lisääminen tekstiasiakirjoista</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Bittikarttakuvien lisääminen, muokkaaminen ja tallennus</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Kuvien lisääminen galleriaan</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automaattiset toiminnot</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Automaattisen URL-tunnistuksen estäminen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Etsiminen ja korvaaminen</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/data_search2.html?DbPAR=SHARED">Haku lomakesuodattimin</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_search.html?DbPAR=SHARED">Haku taulukoista ja lomakeasiakirjoista</a></li>\
    <li><a target="_top" href="fi/text/shared/01/02100001.html?DbPAR=SHARED">Säännöllisten lausekkeiden luettelo</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Oppaat</label><ul>\
    <li><a target="_top" href="fi/text/shared/guide/linestyles.html?DbPAR=SHARED">Viivatyylien käyttäminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/text_color.html?DbPAR=SHARED">Tekstin värin vaihtaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/change_title.html?DbPAR=SHARED">Asiakirjan otsikon vaihtaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/round_corner.html?DbPAR=SHARED">Pyöreiden kulmien luominen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/background.html?DbPAR=SHARED">Taustavärin tai -kuvan määrääminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/palette_files.html?DbPAR=SHARED">Väri-, liukuvärjäys- ja viivoituspalettien lataaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/lineend_define.html?DbPAR=SHARED">Nuolityylien määritteleminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Viivatyylien määrittäminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Grafiikkaobjektien muokkaaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/line_intext.html?DbPAR=SHARED">Viivojen piirtäminen tekstiin</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/aaa_start.html?DbPAR=SHARED">Alkuvaiheet</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Objektien lisääminen galleriasta</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Sitovien välilyöntien, yhdysmerkkien ja tavutusvihjeiden lisääminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Erikoismerkkien lisääminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/tabs.html?DbPAR=SHARED">Sarkainten lisääminen ja muokkaaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Using Remote Files</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/protection.html?DbPAR=SHARED">Sisällön suojaaminen LibreOffice-ohjelmistossa</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Muutoshistoria suojaaminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Sivun laajimman tulostusalueen valitseminen</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/measurement_units.html?DbPAR=SHARED">Mittayksikköjen valinta</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/language_select.html?DbPAR=SHARED">Asiakirjan kielen valinta</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Taulun suunnittelu</a></li>\
    <li><a target="_top" href="fi/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Luetelmien välttäminen yksittäisissä kappaleissa</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
