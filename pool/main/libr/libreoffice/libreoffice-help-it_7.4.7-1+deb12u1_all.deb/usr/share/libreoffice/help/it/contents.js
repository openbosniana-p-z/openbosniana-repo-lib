document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Documenti di testo (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Informazioni generali e utilizzo dell&#39;interfaccia utente</label><ul>\
    <li><a target="_top" href="it/text/swriter/main0000.html?DbPAR=WRITER">Benvenuti nella guida di LibreOffice Writer</a></li>\
    <li><a target="_top" href="it/text/swriter/main0503.html?DbPAR=WRITER">Funzioni di LibreOffice Writer</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/main.html?DbPAR=WRITER">Istruzioni per l&#39;uso di LibreOffice Writer</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Ancorare e ridimensionare le finestre</a></li>\
    <li><a target="_top" href="it/text/swriter/04/01020000.html?DbPAR=WRITER">Tasti di scelta rapida per LibreOffice Writer</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/words_count.html?DbPAR=WRITER">Conteggio delle parole</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/keyboard.html?DbPAR=WRITER">Usare i tasti di scelta rapida (funzioni di accesso facilitato in LibreOffice Writer)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Riferimento dei comandi e dei menu</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menu</label><ul>\
    <li><a target="_top" href="it/text/swriter/main0100.html?DbPAR=WRITER">Menu</a></li>\
    <li><a target="_top" href="it/text/swriter/main0101.html?DbPAR=WRITER">File</a></li>\
    <li><a target="_top" href="it/text/swriter/main0102.html?DbPAR=WRITER">Modifica</a></li>\
    <li><a target="_top" href="it/text/swriter/main0103.html?DbPAR=WRITER">Visualizzazione</a></li>\
    <li><a target="_top" href="it/text/swriter/main0104.html?DbPAR=WRITER">Inserisci</a></li>\
    <li><a target="_top" href="it/text/swriter/main0105.html?DbPAR=WRITER">Formato</a></li>\
    <li><a target="_top" href="it/text/swriter/main0115.html?DbPAR=WRITER">Stili (menu)</a></li>\
    <li><a target="_top" href="it/text/swriter/main0110.html?DbPAR=WRITER">Tabella</a></li>\
    <li><a target="_top" href="it/text/swriter/main0120.html?DbPAR=WRITER">Menu Formulario</a></li>\
    <li><a target="_top" href="it/text/swriter/main0106.html?DbPAR=WRITER">Strumenti</a></li>\
    <li><a target="_top" href="it/text/swriter/main0107.html?DbPAR=WRITER">Finestra</a></li>\
    <li><a target="_top" href="it/text/shared/main0108.html?DbPAR=WRITER">Guida</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Barre degli strumenti</label><ul>\
    <li><a target="_top" href="it/text/swriter/main0200.html?DbPAR=WRITER">Barre degli strumenti</a></li>\
    <li><a target="_top" href="it/text/swriter/main0206.html?DbPAR=WRITER">Barra Elenchi puntati e numerati</a></li>\
    <li><a target="_top" href="it/text/swriter/main0205.html?DbPAR=WRITER">Barra Proprietà oggetto di disegno</a></li>\
    <li><a target="_top" href="it/text/shared/find_toolbar.html?DbPAR=WRITER">Barra Trova</a></li>\
    <li><a target="_top" href="it/text/shared/main0226.html?DbPAR=WRITER">Barra degli strumenti Struttura del formulario</a></li>\
    <li><a target="_top" href="it/text/shared/main0213.html?DbPAR=WRITER">Barra di navigazione dei formulari</a></li>\
    <li><a target="_top" href="it/text/swriter/main0202.html?DbPAR=WRITER">Barra di formattazione</a></li>\
    <li><a target="_top" href="it/text/swriter/main0214.html?DbPAR=WRITER">Barra di calcolo</a></li>\
    <li><a target="_top" href="it/text/swriter/main0215.html?DbPAR=WRITER">Barra Cornice</a></li>\
    <li><a target="_top" href="it/text/swriter/main0203.html?DbPAR=WRITER">Barra Immagine</a></li>\
    <li><a target="_top" href="it/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Barra degli strumenti di LibreLogo</a></li>\
    <li><a target="_top" href="it/text/swriter/main0216.html?DbPAR=WRITER">Barra Oggetto OLE</a></li>\
    <li><a target="_top" href="it/text/swriter/main0210.html?DbPAR=WRITER">Barra Anteprima di stampa (Writer)</a></li>\
    <li><a target="_top" href="it/text/shared/main0214.html?DbPAR=WRITER">Barra Struttura ricerca</a></li>\
    <li><a target="_top" href="it/text/swriter/main0213.html?DbPAR=WRITER">Righelli</a></li>\
    <li><a target="_top" href="it/text/shared/main0201.html?DbPAR=WRITER">Barra standard</a></li>\
    <li><a target="_top" href="it/text/swriter/main0208.html?DbPAR=WRITER">Barra di stato (Writer)</a></li>\
    <li><a target="_top" href="it/text/swriter/main0204.html?DbPAR=WRITER">Barra degli oggetti per tabella</a></li>\
    <li><a target="_top" href="it/text/shared/main0212.html?DbPAR=WRITER">Barra Dati tabella</a></li>\
    <li><a target="_top" href="it/text/swriter/main0220.html?DbPAR=WRITER">Barra degli oggetti del testo</a></li>\
    <li><a target="_top" href="it/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Barra degli strumenti Revisioni</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Spostarsi tra i documenti di testo</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navigare e selezionare parti di testo con la tastiera</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Spostare e copiare un testo in un documento</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Ridisporre un documento con il Navigatore</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserire collegamenti con il Navigatore</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/navigator.html?DbPAR=WRITER">Navigatore per documenti di testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Usare il cursore diretto</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formattare documenti di testo</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Cambiare l&#39;orientazione della pagina (verticale o orizzontale)</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/text_capital.html?DbPAR=WRITER">Rendere un testo maiuscolo o minuscolo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Nascondere un testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definire intestazioni e piè di pagina differenti</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserire il titolo e il numero del capitolo nell&#39;intestazione o nel piè di pagina</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Formattare il testo durante la digitazione</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/reset_format.html?DbPAR=WRITER">Ripristino degli attributi dei caratteri</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Applicare gli stili di formato in modo riempimento</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/wrap.html?DbPAR=WRITER">Far scorrere un testo intorno agli oggetti</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Centrare un testo nella pagina con una cornice</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Evidenziare un testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Ruotare un testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/page_break.html?DbPAR=WRITER">Inserire ed eliminare un&#39;interruzione di pagina</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Creare e applicare stili di pagina</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/subscript.html?DbPAR=WRITER">Formattare un testo come apice o pedice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Modelli e stili</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Modelli di documento e stili</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Alternare gli stili di pagina sulle pagine sinistre e destre</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/change_header.html?DbPAR=WRITER">Creare uno stile di pagina basato sulla formattazione della pagina attuale</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/load_styles.html?DbPAR=WRITER">Usare uno stile di formato di un altro documento o modello di documento</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Creare un nuovo stile di formato da una selezione</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Aggiornare lo stile di formato dalla selezione</a></li>\
    <li><a target="_top" href="it/text/shared/guide/standard_template.html?DbPAR=WRITER">Creazione e modifica di modelli predefiniti e personalizzati</a></li>\
    <li><a target="_top" href="it/text/shared/guide/template_manager.html?DbPAR=WRITER">Gestore dei modelli</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Immagini nei documenti di testo</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Inserire un&#39;immagine</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Inserire un&#39;immagine da un file</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Inserire un&#39;immagine dalla Galleria col trascinamento</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Inserire un&#39;immagine acquisita con lo scanner</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Inserire un grafico di Calc in un documento di testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Inserire immagini da LibreOffice Draw oppure Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabelle nei documenti di testo</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Attivare e disattivare il riconoscimento dei numeri nelle tabelle</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/tablemode.html?DbPAR=WRITER">Modificare righe e colonne con la tastiera</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/table_delete.html?DbPAR=WRITER">Eliminare una tabella o il suo contenuto</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/table_insert.html?DbPAR=WRITER">Inserire tabelle</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Ripetere la riga d&#39;intestazione di una tabella su una nuova pagina</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Ridimensionare righe e colonne in una tabella di testo</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Oggetti nei documenti di testo</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Posizionare gli oggetti</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/wrap.html?DbPAR=WRITER">Far scorrere un testo intorno agli oggetti</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sezioni e cornici nei documenti di testo</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/sections.html?DbPAR=WRITER">Usare le sezioni</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserire, modificare e concatenare cornici</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/section_edit.html?DbPAR=WRITER">Modificare una sezione</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/section_insert.html?DbPAR=WRITER">Inserire una sezione</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Indici generali e indici analitici</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numerazione capitoli</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Indici personalizzati</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Creare un indice generale</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/indices_index.html?DbPAR=WRITER">Creare un indice analitico</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Indici analitici per più documenti</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Creare una bibliografia</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Modificare o eliminare le voci di indice e tabella</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Aggiornare, modificare ed eliminare un indice generale o analitico</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Definire le voci di un indice</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formattare un indice generale o analitico</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Campi nei documenti di testo</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/fields.html?DbPAR=WRITER">Informazioni sui comandi di campo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserire una data fissa o variabile</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/field_convert.html?DbPAR=WRITER">Convertire un comando di campo in un testo</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Eseguire calcoli nei documenti di testo</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Calcolare con più tabelle</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/calculate.html?DbPAR=WRITER">Eseguire calcoli in documenti di testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Calcolare una formula e inserire il risultato in un documento di testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Calcolare la somma delle celle di una tabella</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Calcolare formule complesse in un documento di testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Visualizzare il risultato di un calcolo in una tabella differente</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Elementi di testo speciali</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/captions.html?DbPAR=WRITER">Usare le didascalie</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Testo condizionale</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Testo condizionale per il numero di pagine</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserire una data fissa o variabile</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Aggiungere campi di digitazione</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Inserire i numeri di pagina delle pagine di continuazione</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Inserire il numero di pagina nel piè di pagina</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Nascondere un testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definire intestazioni e piè di pagina differenti</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserire il titolo e il numero del capitolo nell&#39;intestazione o nel piè di pagina</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Richiamare i dati utente nei comandi di campo o nelle condizioni</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Inserire e modificare una nota a piè pagina o una nota di chiusura</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Spazio tra note a piè pagina</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/header_footer.html?DbPAR=WRITER">Informazioni sulle intestazioni e i piè di pagina</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formattare le intestazioni e i piè di pagina</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/text_animation.html?DbPAR=WRITER">Applicare effetti di animazione a un testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Creare una stampa in serie</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Funzioni automatiche</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Aggiungere eccezioni all&#39;elenco Correzione automatica</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/autotext.html?DbPAR=WRITER">Usare il testo automatico</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Creare un elenco puntato o numerato durante la digitazione</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/auto_off.html?DbPAR=WRITER">Disattivare la Correzione automatica</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Eseguire automaticamente il controllo ortografico</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Attivare e disattivare il riconoscimento dei numeri nelle tabelle</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Sillabazione</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numerazione ed elenchi</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Aggiungere il numero del capitolo alle didascalie</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Creare un elenco puntato o numerato durante la digitazione</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numerazione capitoli</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Modificare il livello di un paragrafo elenco</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Combinare due elenchi numerati</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Numerare righe di testo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modificare la numerazione di un elenco ordinato</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Definire una sequenza</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Numerare i paragrafi</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Elenchi numerati e stili di paragrafo</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Aggiungere punti elenco</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Controllo ortografico, dizionario dei sinonimi e lingue</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Eseguire automaticamente il controllo ortografico</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Eliminare una parola da un dizionario personalizzato</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Sinonimi</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Controllo ortografia e grammatica</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Suggerimenti per la risoluzione dei problemi</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Inserire un testo prima di una tabella a inizio pagina</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Accedere a un segnalibro specifico</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Caricare, salvare, importare, esportare e oscurare</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/send2html.html?DbPAR=WRITER">Salvare i documenti di testo in formato HTML</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Inserire un intero documento di testo</a></li>\
    <li><a target="_top" href="it/text/shared/guide/redaction.html?DbPAR=WRITER">Oscuramento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/auto_redact.html?DbPAR=WRITER">Oscuramento automatico</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Documenti master</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Documenti master e sotto-documenti</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Collegamenti e riferimenti</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/references.html?DbPAR=WRITER">Inserire riferimenti incrociati</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserire collegamenti con il Navigatore</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Stampa</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selezionare le parti da stampare</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Selezionare vassoi per la carta della stampante</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/print_preview.html?DbPAR=WRITER">Visualizzare l&#39;anteprima di una pagina prima della stampa</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/print_small.html?DbPAR=WRITER">Stampare più pagine su uno stesso foglio</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Creare e applicare stili di pagina</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Ricerca e sostituzione</label><ul>\
    <li><a target="_top" href="it/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Uso delle espressioni regolari nelle ricerche di testo</a></li>\
    <li><a target="_top" href="it/text/shared/01/02100001.html?DbPAR=WRITER">Elenco delle espressioni regolari</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">Documenti HTML (Writer Web)</label><ul>\
    <li><a target="_top" href="it/text/shared/07/09000000.html?DbPAR=WRITER">Pagine web</a></li>\
    <li><a target="_top" href="it/text/shared/02/01170700.html?DbPAR=WRITER">Filtri HTML e formulari</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/send2html.html?DbPAR=WRITER">Salvare i documenti di testo in formato HTML</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Fogli elettronici (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Informazioni generali e utilizzo dell&#39;interfaccia utente</label><ul>\
    <li><a target="_top" href="it/text/scalc/main0000.html?DbPAR=CALC">Benvenuti nella Guida di LibreOffice Calc</a></li>\
    <li><a target="_top" href="it/text/scalc/main0503.html?DbPAR=CALC">Funzioni di LibreOffice Calc</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/keyboard.html?DbPAR=CALC">Tasti di scelta rapida (accesso facilitato di LibreOffice Calc)</a></li>\
    <li><a target="_top" href="it/text/scalc/04/01020000.html?DbPAR=CALC">Tasti di scelta rapida per i fogli elettronici</a></li>\
    <li><a target="_top" href="it/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Accuratezza di calcolo</a></li>\
    <li><a target="_top" href="it/text/scalc/05/02140000.html?DbPAR=CALC">Codici di errore in LibreOffice Calc</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060112.html?DbPAR=CALC">Componente aggiuntivo per la programmazione in LibreOffice Calc</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/main.html?DbPAR=CALC">Istruzioni per l&#39;uso di LibreOffice Calc</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Riferimento per comandi e menu</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menu</label><ul>\
    <li><a target="_top" href="it/text/scalc/main0100.html?DbPAR=CALC">Menu</a></li>\
    <li><a target="_top" href="it/text/scalc/main0101.html?DbPAR=CALC">File</a></li>\
    <li><a target="_top" href="it/text/scalc/main0102.html?DbPAR=CALC">Modifica</a></li>\
    <li><a target="_top" href="it/text/scalc/main0103.html?DbPAR=CALC">Visualizzazione</a></li>\
    <li><a target="_top" href="it/text/scalc/main0104.html?DbPAR=CALC">Inserisci</a></li>\
    <li><a target="_top" href="it/text/scalc/main0105.html?DbPAR=CALC">Formato</a></li>\
    <li><a target="_top" href="it/text/scalc/main0116.html?DbPAR=CALC">Foglio</a></li>\
    <li><a target="_top" href="it/text/scalc/main0112.html?DbPAR=CALC">Dati</a></li>\
    <li><a target="_top" href="it/text/scalc/main0106.html?DbPAR=CALC">Strumenti</a></li>\
    <li><a target="_top" href="it/text/scalc/main0107.html?DbPAR=CALC">Finestra</a></li>\
    <li><a target="_top" href="it/text/shared/main0108.html?DbPAR=CALC">Guida</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Barre degli strumenti</label><ul>\
    <li><a target="_top" href="it/text/scalc/main0200.html?DbPAR=CALC">Barre degli strumenti</a></li>\
    <li><a target="_top" href="it/text/shared/find_toolbar.html?DbPAR=CALC">Barra Trova</a></li>\
    <li><a target="_top" href="it/text/scalc/main0202.html?DbPAR=CALC">Barra di formattazione</a></li>\
    <li><a target="_top" href="it/text/scalc/main0203.html?DbPAR=CALC">Barra Proprietà oggetto di disegno</a></li>\
    <li><a target="_top" href="it/text/scalc/main0205.html?DbPAR=CALC">Barra Formattazione del testo</a></li>\
    <li><a target="_top" href="it/text/scalc/main0206.html?DbPAR=CALC">Barra di calcolo</a></li>\
    <li><a target="_top" href="it/text/scalc/main0208.html?DbPAR=CALC">Barra di stato</a></li>\
    <li><a target="_top" href="it/text/scalc/main0210.html?DbPAR=CALC">Barra Anteprima di stampa</a></li>\
    <li><a target="_top" href="it/text/scalc/main0214.html?DbPAR=CALC">Barra Immagine</a></li>\
    <li><a target="_top" href="it/text/scalc/main0218.html?DbPAR=CALC">Barra degli strumenti</a></li>\
    <li><a target="_top" href="it/text/shared/main0201.html?DbPAR=CALC">Barra standard</a></li>\
    <li><a target="_top" href="it/text/shared/main0212.html?DbPAR=CALC">Barra Dati tabella</a></li>\
    <li><a target="_top" href="it/text/shared/main0213.html?DbPAR=CALC">Barra di navigazione dei formulari</a></li>\
    <li><a target="_top" href="it/text/shared/main0214.html?DbPAR=CALC">Barra Struttura ricerca</a></li>\
    <li><a target="_top" href="it/text/shared/main0226.html?DbPAR=CALC">Barra degli strumenti Struttura del formulario</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Tipi di funzioni e operatori</label><ul>\
    <li><a target="_top" href="it/text/scalc/01/04060000.html?DbPAR=CALC">Creazione guidata funzione</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060100.html?DbPAR=CALC">Funzioni per categoria</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060107.html?DbPAR=CALC">Categoria Matrice</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060120.html?DbPAR=CALC">Funzioni di operazione sui bit</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060101.html?DbPAR=CALC">Categoria database</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060102.html?DbPAR=CALC">Categoria Data&Orario</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060103.html?DbPAR=CALC">Categoria Finanza 1</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060119.html?DbPAR=CALC">Categoria Finanza 2</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060118.html?DbPAR=CALC">Categoria Finanza 3</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060104.html?DbPAR=CALC">Categoria Informazione</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060105.html?DbPAR=CALC">Categoria Logica</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060106.html?DbPAR=CALC">Categoria Matematica</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060108.html?DbPAR=CALC">Categoria Statistica</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060181.html?DbPAR=CALC">Categoria Statistica 1</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060182.html?DbPAR=CALC">Categoria Statistica 2</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060183.html?DbPAR=CALC">Categoria Statistica 3</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060184.html?DbPAR=CALC">Categoria Statistica 4</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060185.html?DbPAR=CALC">Categoria Statistica 5</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060109.html?DbPAR=CALC">Funzioni foglio elettronico</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060110.html?DbPAR=CALC">Categoria Testo</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060111.html?DbPAR=CALC">Funzioni aggiuntive</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060115.html?DbPAR=CALC">Categoria Componenti aggiuntivi - Elenco delle funzioni di analisi 1</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060116.html?DbPAR=CALC">Funzioni aggiuntive, elenco delle funzioni di analisi 2</a></li>\
    <li><a target="_top" href="it/text/scalc/01/04060199.html?DbPAR=CALC">Operatori di LibreOffice Calc</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Funzioni definite dall&#39;utente</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Caricare, salvare, importare, esportare e oscurare</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/webquery.html?DbPAR=CALC">Inserire dati esterni nella tabella (WebQuery)</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/html_doc.html?DbPAR=CALC">Salvare e aprire fogli in formato HTML</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/csv_formula.html?DbPAR=CALC">Importare ed esportare file di testo</a></li>\
    <li><a target="_top" href="it/text/shared/guide/redaction.html?DbPAR=CALC">Oscuramento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/auto_redact.html?DbPAR=CALC">Oscuramento automatico</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formattazione</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/text_rotate.html?DbPAR=CALC">Ruotare un testo</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/text_wrap.html?DbPAR=CALC">Scrivere un testo su più righe</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formattare i numeri come testo</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/super_subscript.html?DbPAR=CALC">Testo in apice/pedice</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/row_height.html?DbPAR=CALC">Cambiare l&#39;altezza delle righe o la larghezza delle colonne</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Applicare una formattazione condizionale</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Evidenziare i numeri negativi</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Assegnare i formati mediante formule</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Inserire un numero con zero iniziali</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/format_table.html?DbPAR=CALC">Formattare un foglio elettronico</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/format_value.html?DbPAR=CALC">Formattare numeri con decimali</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/value_with_name.html?DbPAR=CALC">Nominare le celle</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/table_rotate.html?DbPAR=CALC">Ruotare una tabella (trasposizione)</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/rename_table.html?DbPAR=CALC">Rinominare fogli</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/year2000.html?DbPAR=CALC">Anni 19xx/20xx</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Utilizzare numeri arrotondati</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/currency_format.html?DbPAR=CALC">Celle in formato valuta</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/autoformat.html?DbPAR=CALC">Usare la formattazione automatica per le tabelle</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/note_insert.html?DbPAR=CALC">Inserire e modificare i commenti</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/design.html?DbPAR=CALC">Selezionare i temi da applicare ai fogli elettronici</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Inserire frazioni</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtraggio e ordinamento</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/filters.html?DbPAR=CALC">Applicare filtri</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applicare filtri avanzati</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/autofilter.html?DbPAR=CALC">Applicare il Filtro automatico</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/sorted_list.html?DbPAR=CALC">Applicare elenchi di ordinamento</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Rimuovere valori duplicati</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Stampa</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/print_title_row.html?DbPAR=CALC">Stampare righe o colonne su ogni pagina</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/print_landscape.html?DbPAR=CALC">Stampare fogli in formato orizzontale</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/print_details.html?DbPAR=CALC">Stampare i dettagli di un foglio</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/print_exact.html?DbPAR=CALC">Impostare il numero di pagine da stampare</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Area dati</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/database_define.html?DbPAR=CALC">Definire un&#39;area di database</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/database_filter.html?DbPAR=CALC">Definire un&#39;area di celle</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/database_sort.html?DbPAR=CALC">Ordinare i dati</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Tabella pivot</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/datapilot.html?DbPAR=CALC">Tabella pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Creare tabelle pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Eliminare tabelle pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Modificare tabelle pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtrare le tabelle pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Selezionare l&#39;area risultato della tabella pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Aggiornare le tabelle pivot</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Grafico pivot</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/pivotchart.html?DbPAR=CALC">Grafico pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creare grafici pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Modificare grafici pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtrare grafici pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Aggiornare grafici pivot</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Eliminare grafici pivot</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Scenari</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/scenario.html?DbPAR=CALC">Usare gli scenari</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotali</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Usare lo strumento Subtotali</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Riferimenti incrociati</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Indirizzi e riferimenti, assoluti e relativi</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/cellreferences.html?DbPAR=CALC">Riferimento a una cella in un altro documento</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Riferimenti ad altri fogli e riferimenti a URL</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Creare riferimenti nelle celle mediante trascinamento</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/address_auto.html?DbPAR=CALC">Riconoscere un nome come indirizzo</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Visualizzare, selezionare, copiare</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/table_view.html?DbPAR=CALC">Modificare le viste delle tabelle</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/formula_value.html?DbPAR=CALC">Visualizzare formule o valori</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/line_fix.html?DbPAR=CALC">Fissare righe o colonne come intestazioni</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navigazione tramite le linguette dei fogli</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Copiare in più fogli</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/cellcopy.html?DbPAR=CALC">Copiare solo le celle visibili</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/mark_cells.html?DbPAR=CALC">Selezionare più celle</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formule e calcoli</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/formulas.html?DbPAR=CALC">Calcolare con le formule</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/formula_copy.html?DbPAR=CALC">Copiare formule</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/formula_enter.html?DbPAR=CALC">Inserimento di formule</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/formula_value.html?DbPAR=CALC">Visualizzare formule o valori</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/calculate.html?DbPAR=CALC">Eseguire calcoli in un foglio elettronico</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/calc_date.html?DbPAR=CALC">Calcoli con date e orari</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/calc_series.html?DbPAR=CALC">Calcolare automaticamente le serie</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Calcolare differenze di orario</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/matrixformula.html?DbPAR=CALC">Inserire formule di matrice</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/wildcards.html?DbPAR=CALC">Usare i caratteri jolly nelle formule</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Protezione</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/cell_protect.html?DbPAR=CALC">Proteggere le celle da modifiche</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Disattivare la protezione delle celle</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Scrivere macro per Calc</label><ul>\
    <li><a target="_top" href="it/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Leggere e scrivere valori negli intervalli di celle</a></li>\
    <li><a target="_top" href="it/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formattare i bordi in Calc usando le Macro</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Altro</label><ul>\
    <li><a target="_top" href="it/text/scalc/guide/auto_off.html?DbPAR=CALC">Disattivare le modifiche automatiche</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/consolidate.html?DbPAR=CALC">Consolidare i dati</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/goalseek.html?DbPAR=CALC">Applicare la ricerca del valore di destinazione</a></li>\
    <li><a target="_top" href="it/text/scalc/01/solver.html?DbPAR=CALC">Risolutore</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/multioperation.html?DbPAR=CALC">Applicare operazioni multiple</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/multitables.html?DbPAR=CALC">Applicare più fogli</a></li>\
    <li><a target="_top" href="it/text/scalc/guide/validity.html?DbPAR=CALC">Validità dei contenuti delle celle</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentazioni (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Informazioni generali e utilizzo dell&#39;interfaccia utente</label><ul>\
    <li><a target="_top" href="it/text/simpress/main0000.html?DbPAR=IMPRESS">Benvenuti nella Guida di LibreOffice Impress</a></li>\
    <li><a target="_top" href="it/text/simpress/main0503.html?DbPAR=IMPRESS">Funzioni di LibreOffice Impress</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Usare i tasti di scelta rapida in LibreOffice Impress</a></li>\
    <li><a target="_top" href="it/text/simpress/04/01020000.html?DbPAR=IMPRESS">Tasti di scelta rapida per LibreOffice Impress</a></li>\
    <li><a target="_top" href="it/text/simpress/04/presenter.html?DbPAR=IMPRESS">Tasti di scelta rapida della Console del relatore</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/main.html?DbPAR=IMPRESS">Istruzioni per LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Riferimento dei comandi e dei menu</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menu</label><ul>\
    <li><a target="_top" href="it/text/simpress/main0100.html?DbPAR=IMPRESS">Menu</a></li>\
    <li><a target="_top" href="it/text/simpress/main0101.html?DbPAR=IMPRESS">File</a></li>\
    <li><a target="_top" href="it/text/simpress/main_edit.html?DbPAR=IMPRESS">Modifica</a></li>\
    <li><a target="_top" href="it/text/simpress/main0103.html?DbPAR=IMPRESS">Visualizzazione</a></li>\
    <li><a target="_top" href="it/text/simpress/main0104.html?DbPAR=IMPRESS">Inserisci</a></li>\
    <li><a target="_top" href="it/text/simpress/main_format.html?DbPAR=IMPRESS">Formato</a></li>\
    <li><a target="_top" href="it/text/simpress/main_slide.html?DbPAR=IMPRESS">Diapositiva</a></li>\
    <li><a target="_top" href="it/text/simpress/main0114.html?DbPAR=IMPRESS">Presentazione</a></li>\
    <li><a target="_top" href="it/text/simpress/main_tools.html?DbPAR=IMPRESS">Strumenti</a></li>\
    <li><a target="_top" href="it/text/simpress/main0107.html?DbPAR=IMPRESS">Finestra</a></li>\
    <li><a target="_top" href="it/text/shared/main0108.html?DbPAR=IMPRESS">Guida</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Barre degli strumenti</label><ul>\
    <li><a target="_top" href="it/text/simpress/main0200.html?DbPAR=IMPRESS">Barre degli strumenti</a></li>\
    <li><a target="_top" href="it/text/simpress/main0210.html?DbPAR=IMPRESS">Barra Disegno</a></li>\
    <li><a target="_top" href="it/text/shared/main0227.html?DbPAR=IMPRESS">Barra Modifica punti</a></li>\
    <li><a target="_top" href="it/text/shared/find_toolbar.html?DbPAR=IMPRESS">Barra Trova</a></li>\
    <li><a target="_top" href="it/text/shared/main0226.html?DbPAR=IMPRESS">Barra degli strumenti Struttura del formulario</a></li>\
    <li><a target="_top" href="it/text/shared/main0213.html?DbPAR=IMPRESS">Barra di navigazione dei formulari</a></li>\
    <li><a target="_top" href="it/text/simpress/main0214.html?DbPAR=IMPRESS">Barra Immagine</a></li>\
    <li><a target="_top" href="it/text/simpress/main0202.html?DbPAR=IMPRESS">Barra Stile e riempimento</a></li>\
    <li><a target="_top" href="it/text/simpress/main0213.html?DbPAR=IMPRESS">Barra Opzioni</a></li>\
    <li><a target="_top" href="it/text/simpress/main0211.html?DbPAR=IMPRESS">Barra Struttura</a></li>\
    <li><a target="_top" href="it/text/simpress/main0209.html?DbPAR=IMPRESS">Righelli</a></li>\
    <li><a target="_top" href="it/text/simpress/main0212.html?DbPAR=IMPRESS">Barra Ordine diapositive</a></li>\
    <li><a target="_top" href="it/text/simpress/main0204.html?DbPAR=IMPRESS">Barra Vista diapositiva</a></li>\
    <li><a target="_top" href="it/text/shared/main0201.html?DbPAR=IMPRESS">Barra standard</a></li>\
    <li><a target="_top" href="it/text/simpress/main0206.html?DbPAR=IMPRESS">Barra di stato</a></li>\
    <li><a target="_top" href="it/text/shared/main0204.html?DbPAR=IMPRESS">Barra Tabella</a></li>\
    <li><a target="_top" href="it/text/simpress/main0203.html?DbPAR=IMPRESS">Barra Formattazione del testo</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Caricare, salvare, importare, esportare e oscurare</label><ul>\
    <li><a target="_top" href="it/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Salvare una presentazione in formato HTML</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Importare pagine HTML in una presentazione</a></li>\
    <li><a target="_top" href="it/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Caricare tavolozze di colori, sfumature o tratteggi</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Esportare le animazioni in formato GIF</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Inserire fogli elettronici nelle diapositive</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserire un&#39;immagine</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Inserisci diapositiva da file</a></li>\
    <li><a target="_top" href="it/text/shared/guide/redaction.html?DbPAR=IMPRESS">Oscuramento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Oscuramento automatico</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formattazione</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Caricare tavolozze di colori, sfumature o tratteggi</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Caricare gli stili per le linee e le frecce</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Definire colori personalizzati</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Creare riempimenti sfumati</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Sostituire i colori</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Disporre, allineare e distribuire gli oggetti</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/background.html?DbPAR=IMPRESS">Modificare il colore o il motivo di sfondo</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/footer.html?DbPAR=IMPRESS">Aggiungere un&#39;intestazione o un piè di pagina a tutte le diapositive</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Cambiare e aggiungere una pagina schema</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Spostare gli oggetti</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Stampa</label><ul>\
    <li><a target="_top" href="it/text/simpress/guide/printing.html?DbPAR=IMPRESS">Stampare una presentazione</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Stampare una diapositiva adattandola alla dimensione del foglio</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Effetti</label><ul>\
    <li><a target="_top" href="it/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Esportare le animazioni in formato GIF</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animare gli oggetti delle diapositive</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animare le transizioni delle diapositive</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Morphing di due oggetti</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Creare immagini GIF animate</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Oggetti, immagini e bitmap</label><ul>\
    <li><a target="_top" href="it/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Combinare oggetti e costruire forme</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Raggruppare gli oggetti</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Disegnare settori e segmenti</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplicare oggetti</a></li>\
    <li><a target="_top" href="it/text/simpress/02/10030000.html?DbPAR=IMPRESS">Trasformazioni</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Ruotare gli oggetti</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Comporre oggetti 3D</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Collegare linee</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Convertire caratteri di testo in oggetti di disegno</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Convertire immagini bitmap in immagini vettoriali</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Convertire gli oggetti 2D in curve, poligoni e oggetti 3D</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Caricare gli stili per le linee e le frecce</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Disegnare le curve</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Modificare le curve</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserire un&#39;immagine</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Inserire fogli elettronici nelle diapositive</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Spostare gli oggetti</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Selezionare gli oggetti sottostanti</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Creare un diagramma di flusso</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Testo nelle presentazioni</label><ul>\
    <li><a target="_top" href="it/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Inserire un testo</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Convertire caratteri di testo in oggetti di disegno</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Visualizzazione</label><ul>\
    <li><a target="_top" href="it/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Cambiare l&#39;ordine delle diapositive</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Zoom con il tastierino numerico</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Presentazioni</label><ul>\
    <li><a target="_top" href="it/text/simpress/guide/show.html?DbPAR=IMPRESS">Eseguire una presentazione</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Usare la Console del relatore</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Guida di Impress Remote</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/individual.html?DbPAR=IMPRESS">Creare una presentazione personalizzata</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Cronometrare i tempi per il cambio di diapositiva</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Disegni (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Informazioni generali e utilizzo dell&#39;interfaccia utente</label><ul>\
    <li><a target="_top" href="it/text/sdraw/main0000.html?DbPAR=DRAW">Benvenuti nella Guida di LibreOffice Draw</a></li>\
    <li><a target="_top" href="it/text/sdraw/main0503.html?DbPAR=DRAW">Funzioni di LibreOffice Draw</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Tasti di scelta rapida per gli oggetti di disegno</a></li>\
    <li><a target="_top" href="it/text/sdraw/04/01020000.html?DbPAR=DRAW">Tasti di scelta rapida per i disegni</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/main.html?DbPAR=DRAW">Istruzioni per l&#39;uso di LibreOffice Draw</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Riferimento dei comandi e dei menu</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menu</label><ul>\
    <li><a target="_top" href="it/text/sdraw/main0100.html?DbPAR=DRAW">Menu</a></li>\
    <li><a target="_top" href="it/text/sdraw/main0101.html?DbPAR=DRAW">File</a></li>\
    <li><a target="_top" href="it/text/sdraw/main_edit.html?DbPAR=DRAW">Modifica</a></li>\
    <li><a target="_top" href="it/text/sdraw/main0103.html?DbPAR=DRAW">Visualizza (menu in Draw)</a></li>\
    <li><a target="_top" href="it/text/sdraw/main_insert.html?DbPAR=DRAW">Inserisci</a></li>\
    <li><a target="_top" href="it/text/sdraw/main_format.html?DbPAR=DRAW">Formato</a></li>\
    <li><a target="_top" href="it/text/sdraw/main_page.html?DbPAR=DRAW">Pagina</a></li>\
    <li><a target="_top" href="it/text/sdraw/main_shape.html?DbPAR=DRAW">Forma</a></li>\
    <li><a target="_top" href="it/text/sdraw/main_tools.html?DbPAR=DRAW">Strumenti</a></li>\
    <li><a target="_top" href="it/text/simpress/main0107.html?DbPAR=DRAW">Finestra</a></li>\
    <li><a target="_top" href="it/text/shared/main0108.html?DbPAR=DRAW">Guida</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Barre degli strumenti</label><ul>\
    <li><a target="_top" href="it/text/sdraw/main0200.html?DbPAR=DRAW">Barre degli strumenti</a></li>\
    <li><a target="_top" href="it/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">Impostazioni 3D</a></li>\
    <li><a target="_top" href="it/text/sdraw/main0210.html?DbPAR=DRAW">Barra degli oggetti per disegno</a></li>\
    <li><a target="_top" href="it/text/shared/main0227.html?DbPAR=DRAW">Barra Modifica punti</a></li>\
    <li><a target="_top" href="it/text/shared/find_toolbar.html?DbPAR=DRAW">Barra Trova</a></li>\
    <li><a target="_top" href="it/text/shared/main0226.html?DbPAR=DRAW">Barra degli strumenti Struttura del formulario</a></li>\
    <li><a target="_top" href="it/text/shared/main0213.html?DbPAR=DRAW">Barra di navigazione dei formulari</a></li>\
    <li><a target="_top" href="it/text/sdraw/main0213.html?DbPAR=DRAW">Barra delle opzioni</a></li>\
    <li><a target="_top" href="it/text/shared/main0201.html?DbPAR=DRAW">Barra standard</a></li>\
    <li><a target="_top" href="it/text/shared/main0204.html?DbPAR=DRAW">Barra Tabella</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Caricare, salvare, importare ed esportare</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/palette_files.html?DbPAR=DRAW">Caricare tavolozze di colori, sfumature o tratteggi</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserire un&#39;immagine</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formattazione</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/palette_files.html?DbPAR=DRAW">Caricare tavolozze di colori, sfumature o tratteggi</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Caricare gli stili per le linee e le frecce</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/color_define.html?DbPAR=DRAW">Definire colori personalizzati</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/gradient.html?DbPAR=DRAW">Creare riempimenti sfumati</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Sostituire i colori</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Disporre, allineare e distribuire gli oggetti</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/background.html?DbPAR=DRAW">Modificare il colore o il motivo di sfondo</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/masterpage.html?DbPAR=DRAW">Cambiare e aggiungere una pagina schema</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/move_object.html?DbPAR=DRAW">Spostare gli oggetti</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Stampa</label><ul>\
    <li><a target="_top" href="it/text/simpress/guide/printing.html?DbPAR=DRAW">Stampare una presentazione</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Stampare una diapositiva adattandola alla dimensione del foglio</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effetti</label><ul>\
    <li><a target="_top" href="it/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Morphing di due oggetti</a></li>\
    <li><a target="_top" href="it/text/shared/01/05350000.html?DbPAR=DRAW">Effetti 3D</a></li>\
    <li><a target="_top" href="it/text/simpress/02/10030000.html?DbPAR=DRAW">Trasformazioni</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Oggetti, immagini e bitmap</label><ul>\
    <li><a target="_top" href="it/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Combinare oggetti e costruire forme</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Disegnare settori e segmenti</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplicare oggetti</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Ruotare gli oggetti</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Comporre oggetti 3D</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Collegare linee</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/text2curve.html?DbPAR=DRAW">Convertire caratteri di testo in oggetti di disegno</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/vectorize.html?DbPAR=DRAW">Convertire immagini bitmap in immagini vettoriali</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/3d_create.html?DbPAR=DRAW">Convertire gli oggetti 2D in curve, poligoni e oggetti 3D</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Caricare gli stili per le linee e le frecce</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/line_draw.html?DbPAR=DRAW">Disegnare le curve</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/line_edit.html?DbPAR=DRAW">Modificare le curve</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserire un&#39;immagine</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/table_insert.html?DbPAR=DRAW">Inserire fogli elettronici nelle diapositive</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/move_object.html?DbPAR=DRAW">Spostare gli oggetti</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/select_object.html?DbPAR=DRAW">Selezionare gli oggetti sottostanti</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/orgchart.html?DbPAR=DRAW">Creare un diagramma di flusso</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Gruppi e livelli</label><ul>\
    <li><a target="_top" href="it/text/sdraw/guide/groups.html?DbPAR=DRAW">Raggruppare gli oggetti</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/layers.html?DbPAR=DRAW">Informazioni sui livelli</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserire livelli</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Lavorare con i livelli</a></li>\
    <li><a target="_top" href="it/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Spostare oggetti in un altro livello</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Testo nei disegni</label><ul>\
    <li><a target="_top" href="it/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Inserire un testo</a></li>\
    <li><a target="_top" href="it/text/simpress/guide/text2curve.html?DbPAR=DRAW">Convertire caratteri di testo in oggetti di disegno</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Visualizzazione</label><ul>\
    <li><a target="_top" href="it/text/simpress/guide/change_scale.html?DbPAR=DRAW">Zoom con il tastierino numerico</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Funzionalità di database (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Informazioni generali</label><ul>\
    <li><a target="_top" href="it/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="it/text/shared/guide/database_main.html?DbPAR=BASE">Panoramica sui database</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_new.html?DbPAR=BASE">Creazione di un nuovo database</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_tables.html?DbPAR=BASE">Lavorare con le tabelle</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_queries.html?DbPAR=BASE">Lavorare con le ricerche</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_forms.html?DbPAR=BASE">Uso dei formulari</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_reports.html?DbPAR=BASE">Creazione di rapporti</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_register.html?DbPAR=BASE">Registrare ed eliminare un database</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_im_export.html?DbPAR=BASE">Importazione ed esportazione dei dati in Base</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Eseguire comandi SQL</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formule (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Informazioni generali e utilizzo dell&#39;interfaccia utente</label><ul>\
    <li><a target="_top" href="it/text/smath/main0000.html?DbPAR=MATH">Benvenuti nella Guida di LibreOffice Math</a></li>\
    <li><a target="_top" href="it/text/smath/main0503.html?DbPAR=MATH">Funzioni di LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">Elementi di formula LibreOffice</label><ul>\
    <li><a target="_top" href="it/text/smath/01/03090100.html?DbPAR=MATH">Operatori unari/binari</a></li>\
    <li><a target="_top" href="it/text/smath/01/03090200.html?DbPAR=MATH">Relazioni</a></li>\
    <li><a target="_top" href="it/text/smath/01/03090800.html?DbPAR=MATH">Operazioni degli insiemi</a></li>\
    <li><a target="_top" href="it/text/smath/01/03090400.html?DbPAR=MATH">Funzioni</a></li>\
    <li><a target="_top" href="it/text/smath/01/03090300.html?DbPAR=MATH">Operatori</a></li>\
    <li><a target="_top" href="it/text/smath/01/03090600.html?DbPAR=MATH">Attributi</a></li>\
    <li><a target="_top" href="it/text/smath/01/03090500.html?DbPAR=MATH">Parentesi</a></li>\
    <li><a target="_top" href="it/text/smath/01/03090700.html?DbPAR=MATH">Formato</a></li>\
    <li><a target="_top" href="it/text/smath/01/03091600.html?DbPAR=MATH">Altri simboli</a></li>\
      </ul></li>\
    <li><a target="_top" href="it/text/smath/guide/main.html?DbPAR=MATH">Istruzioni per LibreOffice Math</a></li>\
    <li><a target="_top" href="it/text/smath/guide/keyboard.html?DbPAR=MATH">Tasti di scelta rapida (funzioni di accesso facilitato di LibreOffice Math)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Riferimento dei comandi e dei menu</label><ul>\
    <li><a target="_top" href="it/text/smath/main0100.html?DbPAR=MATH">Menu</a></li>\
    <li><a target="_top" href="it/text/smath/main0200.html?DbPAR=MATH">Barre degli strumenti</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Lavorare con le formule</label><ul>\
    <li><a target="_top" href="it/text/smath/guide/align.html?DbPAR=MATH">Allineare manualmente parti di formule</a></li>\
    <li><a target="_top" href="it/text/smath/guide/color.html?DbPAR=MATH">Applicare colore a parti della formula</a></li>\
    <li><a target="_top" href="it/text/smath/guide/attributes.html?DbPAR=MATH">Modificare attributi predefiniti</a></li>\
    <li><a target="_top" href="it/text/smath/guide/brackets.html?DbPAR=MATH">Raggruppare parti di formule tra parentesi</a></li>\
    <li><a target="_top" href="it/text/smath/guide/comment.html?DbPAR=MATH">Scrivere un commento</a></li>\
    <li><a target="_top" href="it/text/smath/guide/newline.html?DbPAR=MATH">Inserire interruzioni di riga</a></li>\
    <li><a target="_top" href="it/text/smath/guide/parentheses.html?DbPAR=MATH">Inserire parentesi</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Grafici e diagrammi</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Informazioni generali</label><ul>\
    <li><a target="_top" href="it/text/schart/main0000.html?DbPAR=CHART">Grafici in LibreOffice</a></li>\
    <li><a target="_top" href="it/text/schart/main0503.html?DbPAR=CHART">Funzioni di LibreOffice Chart</a></li>\
    <li><a target="_top" href="it/text/schart/04/01020000.html?DbPAR=CHART">Tasti di scelta rapida per i grafici</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Macro e script</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Informazioni generali e utilizzo dell&#39;interfaccia utente</label><ul>\
    <li><a target="_top" href="it/text/sbasic/shared/main0601.html?DbPAR=BASIC">Guida di LibreOffice Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programmare con LibreOffice Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/00000002.html?DbPAR=BASIC">Glossario di LibreOffice Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01010210.html?DbPAR=BASIC">Fondamenti</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01020000.html?DbPAR=BASIC">Sintassi</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01050000.html?DbPAR=BASIC">Guida all&#39;IDE LibreOffice Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01030100.html?DbPAR=BASIC">Introduzione all&#39;IDE</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01030200.html?DbPAR=BASIC">Editor Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01050100.html?DbPAR=BASIC">Finestra Controllo</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/main0211.html?DbPAR=BASIC">Barra delle macro</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/05060700.html?DbPAR=BASIC">Macro</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Supporto per macro VBA</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Riferimento per i comandi</label><ul>\
    <li><a target="_top" href="it/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Opzioni del compilatore</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01020300.html?DbPAR=BASIC">Usare le procedure, le funzioni o le proprietà</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01020500.html?DbPAR=BASIC">Librerie, moduli e finestre di dialogo</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/conventions.html?DbPAR=BASIC">Diagrammi della sintassi</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funzioni, istruzioni e operatori</label><ul>\
    <li><a target="_top" href="it/text/sbasic/shared/03040000.html?DbPAR=BASIC">Costanti di Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variabili</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03060000.html?DbPAR=BASIC">Operatori logici</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03110100.html?DbPAR=BASIC">Operatori di confronto</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120000.html?DbPAR=BASIC">Stringhe</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030000.html?DbPAR=BASIC">Funzioni per data e ora</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03070000.html?DbPAR=BASIC">Operatori matematici</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funzioni numeriche</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080100.html?DbPAR=BASIC">Funzioni trigonometriche</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010000.html?DbPAR=BASIC">Funzioni di I/O dello schermo</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020000.html?DbPAR=BASIC">Funzioni di I/O dei file</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090000.html?DbPAR=BASIC">Controllare l&#39;esecuzione dei programmi</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funzioni di gestione degli errori</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03130000.html?DbPAR=BASIC">Altri comandi</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080300.html?DbPAR=BASIC">Generare numeri casuali</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">Oggetti UNO</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Utilizzo delle funzioni di Calc nelle macro</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Funzioni VBA esclusive</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090400.html?DbPAR=BASIC">Altre istruzioni</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Elenco alfabetico di funzioni, istruzioni e operatori</label><ul>\
    <li><a target="_top" href="it/text/sbasic/shared/03080601.html?DbPAR=BASIC">Funzione Abs</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03060100.html?DbPAR=BASIC">Operatore AND</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03104200.html?DbPAR=BASIC">Funzione Array</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120101.html?DbPAR=BASIC">Funzione Asc</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120111.html?DbPAR=BASIC">Funzione AscW</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080101.html?DbPAR=BASIC">Funzione Atn</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03130100.html?DbPAR=BASIC">Istruzione Beep</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010301.html?DbPAR=BASIC">Funzione Blue</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090401.html?DbPAR=BASIC">Istruzione Call</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/CallByName.html?DbPAR=BASIC">Funzione CallByName</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090102.html?DbPAR=BASIC">Istruzione Select...Case</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100100.html?DbPAR=BASIC">Funzione CBool</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120105.html?DbPAR=BASIC">Funzione CByte</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100050.html?DbPAR=BASIC">Funzione CCur</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030116.html?DbPAR=BASIC">Funzione CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030115.html?DbPAR=BASIC">Funzione CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030114.html?DbPAR=BASIC">Funzione CDateFromUnoTime</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030113.html?DbPAR=BASIC">Funzione CDateToUnoTime</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030112.html?DbPAR=BASIC">Funzione CDateFromUnoDate</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030111.html?DbPAR=BASIC">Funzione CDateToUnoDate</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030108.html?DbPAR=BASIC">Funzione CDateFromIso</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030107.html?DbPAR=BASIC">Funzione CDateToIso</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100300.html?DbPAR=BASIC">Funzione CDate</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100400.html?DbPAR=BASIC">Funzione CDbl</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100060.html?DbPAR=BASIC">Funzione CDec</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020401.html?DbPAR=BASIC">Istruzione ChDir</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020402.html?DbPAR=BASIC">Istruzione ChDrive</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090402.html?DbPAR=BASIC">Funzione Choose</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120102.html?DbPAR=BASIC">Funzione Chr</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120112.html?DbPAR=BASIC">Funzione ChrW [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100500.html?DbPAR=BASIC">Funzione CInt</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100600.html?DbPAR=BASIC">Funzione CLng</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020101.html?DbPAR=BASIC">Istruzione Close</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/collection.html?DbPAR=BASIC">Oggetto Collection</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100700.html?DbPAR=BASIC">Istruzione Const</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120313.html?DbPAR=BASIC">Funzione ConvertFromURL</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120312.html?DbPAR=BASIC">Funzione ConvertToURL</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080102.html?DbPAR=BASIC">Funzione Cos</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03132400.html?DbPAR=BASIC">Funzione CreateObject</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03131800.html?DbPAR=BASIC">Funzione CreateUnoDialog</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03132000.html?DbPAR=BASIC">Funzione CreateUnoListener</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03131600.html?DbPAR=BASIC">Funzione CreateUnoService</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03131500.html?DbPAR=BASIC">Funzione CreateUnoStruct</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03132300.html?DbPAR=BASIC">Funzione CreateUnoValue</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100900.html?DbPAR=BASIC">Funzione CSng</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101000.html?DbPAR=BASIC">Funzione CStr</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020403.html?DbPAR=BASIC">Funzione CurDir</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100070.html?DbPAR=BASIC">Funzione CVar</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03100080.html?DbPAR=BASIC">Funzione CVErr</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030301.html?DbPAR=BASIC">Funzione Date</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030110.html?DbPAR=BASIC">Funzione DateAdd</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030120.html?DbPAR=BASIC">Funzione DateDiff</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030130.html?DbPAR=BASIC">Funzione DatePart</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030101.html?DbPAR=BASIC">Funzione DateSerial</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030102.html?DbPAR=BASIC">Funzione DateValue</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030103.html?DbPAR=BASIC">Funzione Day</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140000.html?DbPAR=BASIC">Funzione DDB [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090403.html?DbPAR=BASIC">Istruzione Declare</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101100.html?DbPAR=BASIC">Istruzione DefBool</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101110.html?DbPAR=BASIC">Istruzione DefCur</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101300.html?DbPAR=BASIC">Istruzione DefDate</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101400.html?DbPAR=BASIC">Istruzione DefDbl</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101120.html?DbPAR=BASIC">Istruzione DefErr</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101500.html?DbPAR=BASIC">Istruzione DefInt</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101600.html?DbPAR=BASIC">Istruzione DefLng</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101700.html?DbPAR=BASIC">Istruzione DefObj</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101130.html?DbPAR=BASIC">Istruzione DefSng</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03101140.html?DbPAR=BASIC">Istruzione DefStr</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102000.html?DbPAR=BASIC">Istruzione DefVar</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03104300.html?DbPAR=BASIC">Funzione DimArray</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102100.html?DbPAR=BASIC">Istruzione Dim</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020404.html?DbPAR=BASIC">Funzione Dir</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090201.html?DbPAR=BASIC">Istruzione Do...Loop</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090404.html?DbPAR=BASIC">Istruzione End</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/enum.html?DbPAR=BASIC">Istruzione Enum</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03130800.html?DbPAR=BASIC">Funzione Environ</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020301.html?DbPAR=BASIC">Funzione Eof</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03104600.html?DbPAR=BASIC">Funzione EqualUnoObjects</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03060200.html?DbPAR=BASIC">Operatore Eqv</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03104700.html?DbPAR=BASIC">Istruzione Erase</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03050100.html?DbPAR=BASIC">Funzione Erl</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03050200.html?DbPAR=BASIC">Funzione Err</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err Oggetto VBA</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03050300.html?DbPAR=BASIC">Funzione Error</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funzioni di gestione degli errori</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090412.html?DbPAR=BASIC">Istruzione Exit</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080201.html?DbPAR=BASIC">Funzione Exp</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020405.html?DbPAR=BASIC">Funzione FileAttr</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020406.html?DbPAR=BASIC">Istruzione FileCopy</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020407.html?DbPAR=BASIC">Funzione FileDateTime</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020415.html?DbPAR=BASIC">Funzione FileExists</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020408.html?DbPAR=BASIC">Funzione FileLen</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103800.html?DbPAR=BASIC">Funzione FindObject</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103900.html?DbPAR=BASIC">Funzione FindPropertyObject</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080501.html?DbPAR=BASIC">Funzione Fix</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090202.html?DbPAR=BASIC">Istruzione For...Next</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090202.html?DbPAR=BASIC">Istruzione For...Next</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120301.html?DbPAR=BASIC">Funzione Format</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03150000.html?DbPAR=BASIC">Funzione FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03170010.html?DbPAR=BASIC">Funzione FormatNumber [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080503.html?DbPAR=BASIC">Funzione Frac</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020102.html?DbPAR=BASIC">Funzione FreeFile</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090405.html?DbPAR=BASIC">Funzione FreeLibrary</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090406.html?DbPAR=BASIC">Istruzione Function</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140001.html?DbPAR=BASIC">Funzione FV [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020409.html?DbPAR=BASIC">Funzione GetAttr</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03132500.html?DbPAR=BASIC">Funzione GetDefaultContext</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03132100.html?DbPAR=BASIC">Funzione GetGuiType</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03131700.html?DbPAR=BASIC">Funzione GetProcessServiceManager</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">Funzione GetPathSeparator</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03131000.html?DbPAR=BASIC">Funzione GetSolarVersion</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03130700.html?DbPAR=BASIC">Funzione GetSystemTicks</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020201.html?DbPAR=BASIC">Istruzione Get</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103450.html?DbPAR=BASIC">Istruzione Global</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090301.html?DbPAR=BASIC">Istruzione GoSub...Return</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090302.html?DbPAR=BASIC">Istruzione GoTo</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010302.html?DbPAR=BASIC">Funzione Green</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03104400.html?DbPAR=BASIC">Funzione HasUnoInterfaces</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080801.html?DbPAR=BASIC">Funzione Hex</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030201.html?DbPAR=BASIC">Funzione Hour</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090103.html?DbPAR=BASIC">Funzione IIf</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090101.html?DbPAR=BASIC">Istruzione If... Then... Else</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03060300.html?DbPAR=BASIC">Operatore Imp</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120401.html?DbPAR=BASIC">Funzione InStr</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120411.html?DbPAR=BASIC">Funzione InStrRev [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03160000.html?DbPAR=BASIC">Funzione Input [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010201.html?DbPAR=BASIC">Funzione InputBox</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020202.html?DbPAR=BASIC">Istruzione Input#</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080502.html?DbPAR=BASIC">Funzione Int</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140002.html?DbPAR=BASIC">Funzione IPmt [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140003.html?DbPAR=BASIC">Funzione IRR [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Operatore Is</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102200.html?DbPAR=BASIC">Funzione IsArray</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102300.html?DbPAR=BASIC">Funzione IsDate</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102400.html?DbPAR=BASIC">Funzione IsEmpty</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102450.html?DbPAR=BASIC">Funzione IsError</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03104000.html?DbPAR=BASIC">Funzione IsMissing</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102600.html?DbPAR=BASIC">Funzione IsNull</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102700.html?DbPAR=BASIC">Funzione IsNumeric</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102800.html?DbPAR=BASIC">Funzione IsObject</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03104500.html?DbPAR=BASIC">Funzione IsUnoStruct</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120315.html?DbPAR=BASIC">Funzione Join</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020410.html?DbPAR=BASIC">Istruzione Kill</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102900.html?DbPAR=BASIC">Funzione LBound</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120302.html?DbPAR=BASIC">Funzione LCase</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120304.html?DbPAR=BASIC">Funzione LSet</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120305.html?DbPAR=BASIC">Funzione LTrim</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120303.html?DbPAR=BASIC">Funzione Left</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120402.html?DbPAR=BASIC">Funzione Len</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103100.html?DbPAR=BASIC">Istruzione Let</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020203.html?DbPAR=BASIC">Istruzione Line Input#</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020302.html?DbPAR=BASIC">Funzione Loc</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020303.html?DbPAR=BASIC">Funzione Lof</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080202.html?DbPAR=BASIC">Funzione Log</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120306.html?DbPAR=BASIC">Funzione Mid, Istruzione Mid</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030202.html?DbPAR=BASIC">Funzione Minute</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140004.html?DbPAR=BASIC">Funzione MIRR [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020411.html?DbPAR=BASIC">Istruzione MkDir</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03070600.html?DbPAR=BASIC">Operatore Mod</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030104.html?DbPAR=BASIC">Funzione Month</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03150002.html?DbPAR=BASIC">Funzione MonthName [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010102.html?DbPAR=BASIC">Funzione MsgBox</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010101.html?DbPAR=BASIC">Istruzione MsgBox</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020412.html?DbPAR=BASIC">Istruzione Name</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">Operatore New</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03060400.html?DbPAR=BASIC">Operatore Not</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030203.html?DbPAR=BASIC">Funzione Now</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140005.html?DbPAR=BASIC">Funzione NPer [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140006.html?DbPAR=BASIC">Funzione NPV [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funzioni numeriche</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080802.html?DbPAR=BASIC">Funzione Oct</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03050500.html?DbPAR=BASIC">Istruzione On Error GoTo ... Resume</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090303.html?DbPAR=BASIC">Istruzione On...GoSub; Istruzione On...GoTo</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020103.html?DbPAR=BASIC">Istruzione Open</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103200.html?DbPAR=BASIC">Istruzione Option Base</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103300.html?DbPAR=BASIC">Istruzione Option Explicit</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103350.html?DbPAR=BASIC">Istruzione Option VBASupport</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (nell&#39;istruzione Function)</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03060500.html?DbPAR=BASIC">Operatore OR</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/partition.html?DbPAR=BASIC">Funzione Partition</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140007.html?DbPAR=BASIC">Funzione Pmt [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140008.html?DbPAR=BASIC">Funzione PPmt [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010103.html?DbPAR=BASIC">Istruzione Print#</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/property.html?DbPAR=BASIC">Istruzione Property</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103400.html?DbPAR=BASIC">Istruzione Public</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020204.html?DbPAR=BASIC">Istruzione Put#</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140009.html?DbPAR=BASIC">Funzione PV [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010304.html?DbPAR=BASIC">Funzione QBColor</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140010.html?DbPAR=BASIC">Funzione Rate [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080301.html?DbPAR=BASIC">Istruzione Randomize</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03102101.html?DbPAR=BASIC">Istruzione ReDim</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010303.html?DbPAR=BASIC">Funzione Red</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090407.html?DbPAR=BASIC">Istruzione Rem</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/replace.html?DbPAR=BASIC">Funzione Replace</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020104.html?DbPAR=BASIC">Istruzione Reset</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/Resume.html?DbPAR=BASIC">Istruzione Resume</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010305.html?DbPAR=BASIC">Funzione RGB</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03010306.html?DbPAR=BASIC">Funzione RGB [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120307.html?DbPAR=BASIC">Funzione Right</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020413.html?DbPAR=BASIC">Istruzione RmDir</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080302.html?DbPAR=BASIC">Funzione Rnd</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03170000.html?DbPAR=BASIC">Funzione Round [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120308.html?DbPAR=BASIC">Funzione RSet</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120309.html?DbPAR=BASIC">Funzione RTrim</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030204.html?DbPAR=BASIC">Funzione Second</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020304.html?DbPAR=BASIC">Funzione Seek</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020305.html?DbPAR=BASIC">Istruzione Seek#</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090102.html?DbPAR=BASIC">Istruzione Select...Case</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020414.html?DbPAR=BASIC">Istruzione SetAttr</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103700.html?DbPAR=BASIC">Istruzione Set</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080701.html?DbPAR=BASIC">Funzione Sgn</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03130500.html?DbPAR=BASIC">Funzione Shell</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080103.html?DbPAR=BASIC">Funzione Sin</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140011.html?DbPAR=BASIC">Funzione SLN [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120201.html?DbPAR=BASIC">Funzione Space e Spc</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120201.html?DbPAR=BASIC">Funzione Space e Spc</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120314.html?DbPAR=BASIC">Funzione Split</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080401.html?DbPAR=BASIC">Funzione Sqr</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080400.html?DbPAR=BASIC">Calcolo della radice quadrata</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">Oggetto StarDesktop</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103500.html?DbPAR=BASIC">Istruzione Static</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090408.html?DbPAR=BASIC">Istruzione Stop</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120403.html?DbPAR=BASIC">Funzione StrComp</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/strconv.html?DbPAR=BASIC">Funzione StrConv [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120103.html?DbPAR=BASIC">Funzione Str</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120412.html?DbPAR=BASIC">Funzione StrReverse [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120202.html?DbPAR=BASIC">Funzione String</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090409.html?DbPAR=BASIC">Istruzione Sub</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090410.html?DbPAR=BASIC">Funzione Switch</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03140012.html?DbPAR=BASIC">Funzione SYD [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03080104.html?DbPAR=BASIC">Funzione Tan</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03132200.html?DbPAR=BASIC">Oggetto ThisComponent</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">Oggetto ThisDatabaseDocument</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030205.html?DbPAR=BASIC">Funzione TimeSerial</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030206.html?DbPAR=BASIC">Funzione TimeValue</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030302.html?DbPAR=BASIC">Funzione Time</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030303.html?DbPAR=BASIC">Funzione Timer</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120311.html?DbPAR=BASIC">Funzione Trim</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03131300.html?DbPAR=BASIC">Funzione TwipsPerPixelX</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03131400.html?DbPAR=BASIC">Funzione TwipsPerPixelY</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090413.html?DbPAR=BASIC">Istruzione Type</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103600.html?DbPAR=BASIC">Funzione TypeName; Funzione VarType</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03103000.html?DbPAR=BASIC">Funzione UBound</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120310.html?DbPAR=BASIC">Funzione UCase</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120104.html?DbPAR=BASIC">Funzione Val</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03130600.html?DbPAR=BASIC">Istruzione Wait</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03130610.html?DbPAR=BASIC">Istruzione WaitUntil</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030105.html?DbPAR=BASIC">Funzione WeekDay</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03150001.html?DbPAR=BASIC">Funzione WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090203.html?DbPAR=BASIC">Istruzione While... Wend</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03090411.html?DbPAR=BASIC">Istruzione With</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03020205.html?DbPAR=BASIC">Istruzione Write</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03060600.html?DbPAR=BASIC">Operatore XOR</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03030106.html?DbPAR=BASIC">Funzione Year</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03070100.html?DbPAR=BASIC">Operatore "-"</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03070200.html?DbPAR=BASIC">Operatore "*"</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03070300.html?DbPAR=BASIC">Operatore "+"</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03070400.html?DbPAR=BASIC">Operatore "/"</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03070700.html?DbPAR=BASIC">Operatore "\"</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03070500.html?DbPAR=BASIC">Operatore "^"</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03120300.html?DbPAR=BASIC">Modificare il contenuto delle stringhe</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01020100.html?DbPAR=BASIC">Usare le variabili</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/conventions.html?DbPAR=BASIC">Diagrammi della sintassi</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Librerie Basic avanzate</label><ul>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Libreria Tools</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Libreria DEPOT</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Libreria EURO</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Libreria FORMWIZARD</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Libreria GIMMICKS</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">Libreria ImportWizard</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Libreria SCHEDULE</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Libreria SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Libreria TEMPLATE</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">Libreria WikiEditor</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">Libreria ScriptForge</label><ul>\
    <li><a target="_top" href="it/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">Librerie ScriptForge</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creazione di script in Python con ScriptForge</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">Metodo Signatures di ScriptForge</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">Servizio ScriptForge.Array (SF_Array)</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">Servizio SFDocuments.Base</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">Servizio ScriptForge.Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">Servizio SFDocuments.Calc</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">Servizio SFDocuments.Chart</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">Servizio SFDatabases.Database</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">Servizio SFDialogs.Dialog</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">Servizio SFDialogs.DialogControl</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">Servizio ScriptForge.Dictionary</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">Servizio SFDocuments.Document</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">Servizio ScriptForge.Exception (SF_Exception)</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">Servizio ScriptForge.FileSystem</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">Servizio SFDocuments.Form</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">Servizio SFDocuments.FormControl</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">Servizio ScriptForge.L10N</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">Servizio SFWidgets.Menu</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">Servizio ScriptForge.Platform</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">Servizio SFWidgets.PopupMenu</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">Servizio ScriptForge.Region</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">Servizio ScriptForge.Services</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">Servizio ScriptForge.Session</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">Servizio ScriptForge.String (SF_String)</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">Servizio ScriptForge.TextStream</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">Servizio ScriptForge.Timer</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">Servizio ScriptForge.UI</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">Servizio SFUnitTests.UnitTest</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">Servizio SFDocuments.Writer</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Linee guida</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/macro_recording.html?DbPAR=BASIC">Registrare una macro</a></li>\
    <li><a target="_top" href="it/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Cambiare le proprietà di un campo di controllo nell&#39;editor delle finestre di dialogo</a></li>\
    <li><a target="_top" href="it/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Creare un campo di controllo nell&#39;editor delle finestre di dialogo</a></li>\
    <li><a target="_top" href="it/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Esempi di programmazione per i campi di controllo nell&#39;editor delle finestre di dialogo</a></li>\
    <li><a target="_top" href="it/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Visualizzare una finestra di dialogo usando Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Creare una finestra di dialogo Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01030400.html?DbPAR=BASIC">Organizzare librerie e moduli</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01020100.html?DbPAR=BASIC">Usare le variabili</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01020200.html?DbPAR=BASIC">Usare gli oggetti</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01030300.html?DbPAR=BASIC">Eseguire il debug di un programma Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/shared/01040000.html?DbPAR=BASIC">Macro controllate dagli eventi nel documento</a></li>\
    <li><a target="_top" href="it/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Esempi di programmazione in Basic</a></li>\
    <li><a target="_top" href="it/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Da Basic a Python</a></li>\
    <li><a target="_top" href="it/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Guida agli script di Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Informazioni generali e utilizzo dell&#39;interfaccia utente</label><ul>\
    <li><a target="_top" href="it/text/sbasic/python/main0000.html?DbPAR=BASIC">Script Python</a></li>\
    <li><a target="_top" href="it/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE per Python</a></li>\
    <li><a target="_top" href="it/text/sbasic/python/python_locations.html?DbPAR=BASIC">Organizzazione degli script Python</a></li>\
    <li><a target="_top" href="it/text/sbasic/python/python_shell.html?DbPAR=BASIC">Shell interattiva Python</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programmare con Python</label><ul>\
    <li><a target="_top" href="it/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python: programmare con Python</a></li>\
    <li><a target="_top" href="it/text/sbasic/python/python_examples.html?DbPAR=BASIC">Esempi di Python</a></li>\
    <li><a target="_top" href="it/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Da Python a Basic</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Strumenti per lo sviluppo degli script</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/dev_tools.html?DbPAR=BASIC">Strumenti per lo sviluppo</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Installazione di LibreOffice</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Modificare l&#39;associazione dei tipi di documento di Microsoft Office</a></li>\
    <li><a target="_top" href="it/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Modalità provvisoria</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Argomenti comuni della guida</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Informazioni generali</label><ul>\
    <li><a target="_top" href="it/text/shared/main0400.html?DbPAR=SHARED">Tasti di scelta rapida</a></li>\
    <li><a target="_top" href="it/text/shared/00/00000005.html?DbPAR=SHARED">Glossario generale</a></li>\
    <li><a target="_top" href="it/text/shared/00/00000002.html?DbPAR=SHARED">Glossario di termini Internet</a></li>\
    <li><a target="_top" href="it/text/shared/guide/accessibility.html?DbPAR=SHARED">Accesso facilitato in LibreOffice</a></li>\
    <li><a target="_top" href="it/text/shared/guide/keyboard.html?DbPAR=SHARED">Tasti di scelta rapida (accesso facilitato in LibreOffice)</a></li>\
    <li><a target="_top" href="it/text/shared/04/01010000.html?DbPAR=SHARED">Tasti di scelta rapida generali di LibreOffice</a></li>\
    <li><a target="_top" href="it/text/shared/guide/version_number.html?DbPAR=SHARED">Versioni e numeri di build</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice e Microsoft Office</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/ms_user.html?DbPAR=SHARED">Utilizzare Microsoft Office e LibreOffice</a></li>\
    <li><a target="_top" href="it/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Confronto tra le funzioni di Microsoft Office e LibreOffice</a></li>\
    <li><a target="_top" href="it/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Informazioni sulla conversione di documenti di Microsoft Office</a></li>\
    <li><a target="_top" href="it/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Modificare l&#39;associazione dei tipi di documento di Microsoft Office</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Opzioni di LibreOffice</label><ul>\
    <li><a target="_top" href="it/text/shared/optionen/01000000.html?DbPAR=SHARED">Opzioni</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01010100.html?DbPAR=SHARED">Dati utente</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01010200.html?DbPAR=SHARED">Generale</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01010800.html?DbPAR=SHARED">Vista</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01010900.html?DbPAR=SHARED">Opzioni di stampa</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01010300.html?DbPAR=SHARED">Percorsi</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01010700.html?DbPAR=SHARED">Tipi di carattere</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01030300.html?DbPAR=SHARED">Sicurezza</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01012000.html?DbPAR=SHARED">Colori applicazione</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01013000.html?DbPAR=SHARED">Accesso facilitato</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/java.html?DbPAR=SHARED">Avanzate</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Configurazione avanzata</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">IDE Basic</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01010400.html?DbPAR=SHARED">Linguistica</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01010600.html?DbPAR=SHARED">Generale</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01020000.html?DbPAR=SHARED">Opzioni Carica/Salva</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01030000.html?DbPAR=SHARED">Opzioni Internet</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01040000.html?DbPAR=SHARED">Opzioni documento di testo</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01050000.html?DbPAR=SHARED">Opzioni per i documenti HTML</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01060000.html?DbPAR=SHARED">Opzioni foglio elettronico</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01070000.html?DbPAR=SHARED">Opzioni della presentazione</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01080000.html?DbPAR=SHARED">Opzioni disegno</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01090000.html?DbPAR=SHARED">Formula</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01110000.html?DbPAR=SHARED">Opzioni grafico</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01130100.html?DbPAR=SHARED">Proprietà VBA</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01140000.html?DbPAR=SHARED">Lingue (opzioni)</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01150000.html?DbPAR=SHARED">Opzioni di impostazioni della lingua</a></li>\
    <li><a target="_top" href="it/text/shared/optionen/01160000.html?DbPAR=SHARED">Opzioni sorgenti dati</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Procedure guidate</label><ul>\
    <li><a target="_top" href="it/text/shared/autopi/01000000.html?DbPAR=SHARED">Procedura guidata</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Creazione guidata lettera</label><ul>\
    <li><a target="_top" href="it/text/shared/autopi/01010000.html?DbPAR=SHARED">Creazione guidata lettera</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Creazione guidata fax</label><ul>\
    <li><a target="_top" href="it/text/shared/autopi/01020000.html?DbPAR=SHARED">Creazione guidata fax</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Creazione guidata agenda</label><ul>\
    <li><a target="_top" href="it/text/shared/autopi/01040000.html?DbPAR=SHARED">Creazione guidata agenda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Esportazione guidata HTML</label><ul>\
    <li><a target="_top" href="it/text/shared/autopi/01110000.html?DbPAR=SHARED">Esportazione HTML</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Convertitore documenti</label><ul>\
    <li><a target="_top" href="it/text/shared/autopi/01130000.html?DbPAR=SHARED">Convertitore di documenti</a></li>\
      </ul></li>\
    <li><a target="_top" href="it/text/shared/autopi/01150000.html?DbPAR=SHARED">Conversione guidata euro</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configurare LibreOffice</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/configure_overview.html?DbPAR=SHARED">Configurazione di LibreOffice</a></li>\
    <li><a target="_top" href="it/text/shared/01/packagemanager.html?DbPAR=SHARED">Gestione estensioni</a></li>\
    <li><a target="_top" href="it/text/shared/guide/flat_icons.html?DbPAR=SHARED">Modificare la vista dell&#39;icona</a></li>\
    <li><a target="_top" href="it/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Aggiungere pulsanti alle barre</a></li>\
    <li><a target="_top" href="it/text/shared/guide/workfolder.html?DbPAR=SHARED">Modificare la vostra cartella di lavoro</a></li>\
    <li><a target="_top" href="it/text/shared/guide/standard_template.html?DbPAR=SHARED">Creazione e modifica di modelli predefiniti e personalizzati</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Registrare una rubrica</a></li>\
    <li><a target="_top" href="it/text/shared/guide/formfields.html?DbPAR=SHARED">Inserire e modificare i pulsanti</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Lavorare con l&#39;interfaccia utente</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navigazione per raggiungere rapidamente gli oggetti</a></li>\
    <li><a target="_top" href="it/text/shared/guide/navigator.html?DbPAR=SHARED">Navigatore per una panoramica del documento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/autohide.html?DbPAR=SHARED">Mostrare, ancorare e nascondere le finestre</a></li>\
    <li><a target="_top" href="it/text/shared/guide/textmode_change.html?DbPAR=SHARED">Commutare tra il modo Inserimento e il modo Sovrascrittura</a></li>\
    <li><a target="_top" href="it/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Utilizzare le barre degli strumenti</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Firme digitali</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Utilizzare le firme digitali</a></li>\
    <li><a target="_top" href="it/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Applicare le firme digitali</a></li>\
    <li><a target="_top" href="it/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">Firma digitale dell&#39;esportazione PDF</a></li>\
    <li><a target="_top" href="it/text/shared/01/timestampauth.html?DbPAR=SHARED">Autorità di marcatura temporale per le firme digitali</a></li>\
    <li><a target="_top" href="it/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Firmare un PDF esistente</a></li>\
    <li><a target="_top" href="it/text/shared/01/addsignatureline.html?DbPAR=SHARED">Aggiunta di una riga della firma nei documenti</a></li>\
    <li><a target="_top" href="it/text/shared/01/signsignatureline.html?DbPAR=SHARED">Firmare la riga della firma</a></li>\
    <li><a target="_top" href="it/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Stampa, fax e invio di documenti</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/labels_database.html?DbPAR=SHARED">Stampare etichette con indirizzi</a></li>\
    <li><a target="_top" href="it/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Stampa in bianco e nero</a></li>\
    <li><a target="_top" href="it/text/shared/guide/email.html?DbPAR=SHARED">Inviare documenti come e-mail</a></li>\
    <li><a target="_top" href="it/text/shared/guide/fax.html?DbPAR=SHARED">Inviare i fax e configurare LibreOffice per l&#39;invio di fax</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Trascina selezione (Drag & Drop)</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/dragdrop.html?DbPAR=SHARED">Uso della funzione Drag&Drop nei documenti di LibreOffice</a></li>\
    <li><a target="_top" href="it/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Spostare e copiare un testo in un documento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copiare un&#39;area di un foglio elettronico in un documento di testo</a></li>\
    <li><a target="_top" href="it/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copiare un&#39;immagine tra due documenti</a></li>\
    <li><a target="_top" href="it/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Copiare un&#39;immagine dalla Galleria</a></li>\
    <li><a target="_top" href="it/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Trascina selezione (drag-and-drop) con la vista della sorgente dati</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copia e Incolla</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Copiare oggetti di disegno in altri documenti</a></li>\
    <li><a target="_top" href="it/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copiare un&#39;immagine tra due documenti</a></li>\
    <li><a target="_top" href="it/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Copiare un&#39;immagine dalla Galleria</a></li>\
    <li><a target="_top" href="it/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copiare un&#39;area di un foglio elettronico in un documento di testo</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Grafici e diagrammi</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/chart_insert.html?DbPAR=SHARED">Inserire grafici</a></li>\
    <li><a target="_top" href="it/text/schart/main0000.html?DbPAR=SHARED">Grafici in LibreOffice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Carica, Salva, Importa, Esporta, PDF</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/doc_open.html?DbPAR=SHARED">Aprire un documento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/import_ms.html?DbPAR=SHARED">Aprire documenti salvati in altri formati</a></li>\
    <li><a target="_top" href="it/text/shared/guide/doc_save.html?DbPAR=SHARED">Salvare un documento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Salvare automaticamente i documenti</a></li>\
    <li><a target="_top" href="it/text/shared/guide/export_ms.html?DbPAR=SHARED">Salvare i documenti in altri formati</a></li>\
    <li><a target="_top" href="it/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Esporta come file PDF</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Importare ed esportare dati in formato testo</a></li>\
    <li><a target="_top" href="it/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Collegamenti e riferimenti</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Inserire un collegamento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Collegamenti relativi e assoluti</a></li>\
    <li><a target="_top" href="it/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Modificare un collegamento</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Tracciamento delle versioni del documento</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Confrontare le versioni di un documento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Unire le versioni</a></li>\
    <li><a target="_top" href="it/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Registrare le modifiche</a></li>\
    <li><a target="_top" href="it/text/shared/guide/redlining.html?DbPAR=SHARED">Registrare e visualizzare le modifiche</a></li>\
    <li><a target="_top" href="it/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Accettare o rifiutare le modifiche</a></li>\
    <li><a target="_top" href="it/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Gestione versioni</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etichette e biglietti da visita</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/labels.html?DbPAR=SHARED">Creare e stampare etichette e biglietti da visita</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Inserire dati esterni</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/copytable2application.html?DbPAR=SHARED">Inserire dati da fogli elettronici</a></li>\
    <li><a target="_top" href="it/text/shared/guide/copytext2application.html?DbPAR=SHARED">Inserire dati da documenti di testo</a></li>\
    <li><a target="_top" href="it/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Inserire, modificare e salvare immagini bitmap</a></li>\
    <li><a target="_top" href="it/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Aggiungere immagini alla Galleria</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Funzioni automatiche</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Disabilitare il riconoscimento automatico degli URL</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Ricerca e sostituzione</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/data_search2.html?DbPAR=SHARED">Cercare con un filtro del formulario</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_search.html?DbPAR=SHARED">Eseguire ricerche in tabelle e formulari</a></li>\
    <li><a target="_top" href="it/text/shared/01/02100001.html?DbPAR=SHARED">Elenco delle espressioni regolari</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guide</label><ul>\
    <li><a target="_top" href="it/text/shared/guide/linestyles.html?DbPAR=SHARED">Applicare uno stile di linea</a></li>\
    <li><a target="_top" href="it/text/shared/guide/text_color.html?DbPAR=SHARED">Modificare il colore di un testo</a></li>\
    <li><a target="_top" href="it/text/shared/guide/change_title.html?DbPAR=SHARED">Modificare il titolo di un documento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/round_corner.html?DbPAR=SHARED">Generare angoli smussati</a></li>\
    <li><a target="_top" href="it/text/shared/guide/background.html?DbPAR=SHARED">Impostare colori o immagini di sfondo</a></li>\
    <li><a target="_top" href="it/text/shared/guide/palette_files.html?DbPAR=SHARED">Caricare tavolozze di colori, sfumature o tratteggi</a></li>\
    <li><a target="_top" href="it/text/shared/guide/lineend_define.html?DbPAR=SHARED">Definire le estremità linea</a></li>\
    <li><a target="_top" href="it/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Definire uno stile di linea</a></li>\
    <li><a target="_top" href="it/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Modificare oggetti grafici</a></li>\
    <li><a target="_top" href="it/text/shared/guide/line_intext.html?DbPAR=SHARED">Disegnare una linea nel testo</a></li>\
    <li><a target="_top" href="it/text/shared/guide/aaa_start.html?DbPAR=SHARED">Prime operazioni</a></li>\
    <li><a target="_top" href="it/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserire oggetti dalla Galleria</a></li>\
    <li><a target="_top" href="it/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserire spazi non divisibili, trattini e trattini morbidi</a></li>\
    <li><a target="_top" href="it/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Inserire caratteri speciali</a></li>\
    <li><a target="_top" href="it/text/shared/guide/tabs.html?DbPAR=SHARED">Inserire e modificare le tabulazioni</a></li>\
    <li><a target="_top" href="it/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Uso dei file remoti</a></li>\
    <li><a target="_top" href="it/text/shared/guide/protection.html?DbPAR=SHARED">Proteggere il contenuto in LibreOffice</a></li>\
    <li><a target="_top" href="it/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Proteggere la registrazione</a></li>\
    <li><a target="_top" href="it/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Selezionare l&#39;area stampabile massima su una pagina</a></li>\
    <li><a target="_top" href="it/text/shared/guide/measurement_units.html?DbPAR=SHARED">Selezionare l&#39;unità di misura</a></li>\
    <li><a target="_top" href="it/text/shared/guide/language_select.html?DbPAR=SHARED">Selezionare la lingua del documento</a></li>\
    <li><a target="_top" href="it/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Struttura tabella</a></li>\
    <li><a target="_top" href="it/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Disattivare gli elenchi puntati e numerati per singoli paragrafi</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
