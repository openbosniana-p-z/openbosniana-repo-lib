/* config_host/config_typesizes.h.  Generated from config_typesizes.h.in by configure.  */
/*

   Alignments and sizes of types.

*/

#ifndef CONFIG_TYPESIZES_H
#define CONFIG_TYPESIZES_H

#define SAL_TYPES_ALIGNMENT2 2
#define SAL_TYPES_ALIGNMENT4 4
#define SAL_TYPES_ALIGNMENT8 8
#define SAL_TYPES_SIZEOFSHORT 2
#define SAL_TYPES_SIZEOFINT 4
#define SAL_TYPES_SIZEOFLONG 8
#define SAL_TYPES_SIZEOFLONGLONG 8
#define SAL_TYPES_SIZEOFPOINTER 8

#endif
