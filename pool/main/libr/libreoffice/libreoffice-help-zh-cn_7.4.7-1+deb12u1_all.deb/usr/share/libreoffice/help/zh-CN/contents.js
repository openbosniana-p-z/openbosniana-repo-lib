document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">文本文档 (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">常规信息及用户界面用法</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/main0000.html?DbPAR=WRITER">欢迎使用 LibreOffice Writer 文本文档帮助</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0503.html?DbPAR=WRITER">LibreOffice Writer 的主要功能</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/main.html?DbPAR=WRITER">LibreOffice Writer 使用说明</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">固定窗口和调整窗口大小</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/04/01020000.html?DbPAR=WRITER">用于 LibreOffice Writer 的快捷键</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/words_count.html?DbPAR=WRITER">字数统计</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/keyboard.html?DbPAR=WRITER">使用快捷键 (LibreOffice Writer 辅助功能)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">命令和菜单项指南</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">菜单</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/main0100.html?DbPAR=WRITER">菜单</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0101.html?DbPAR=WRITER">文件</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0102.html?DbPAR=WRITER">编辑</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0103.html?DbPAR=WRITER">视图</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0104.html?DbPAR=WRITER">插入</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0105.html?DbPAR=WRITER">格式</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0115.html?DbPAR=WRITER">Styles (menu)</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0110.html?DbPAR=WRITER">表格</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0120.html?DbPAR=WRITER">表单菜单</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0106.html?DbPAR=WRITER">工具</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0107.html?DbPAR=WRITER">窗口</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0108.html?DbPAR=WRITER">「帮助」菜单</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">工具栏</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/main0200.html?DbPAR=WRITER">工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0206.html?DbPAR=WRITER">项目符号与编号栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0205.html?DbPAR=WRITER">绘图对象属性栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0226.html?DbPAR=WRITER">表单设计工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0213.html?DbPAR=WRITER">表单导航栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0202.html?DbPAR=WRITER">「格式」工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0214.html?DbPAR=WRITER">公式编辑栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0215.html?DbPAR=WRITER">框架栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0203.html?DbPAR=WRITER">图像栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo 工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0216.html?DbPAR=WRITER">OLE Object Bar</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0210.html?DbPAR=WRITER">Print Preview Bar (Writer)</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0214.html?DbPAR=WRITER">查询设计栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0213.html?DbPAR=WRITER">标尺</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0201.html?DbPAR=WRITER">标准工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0208.html?DbPAR=WRITER">Status Bar (Writer)</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0204.html?DbPAR=WRITER">表格栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0212.html?DbPAR=WRITER">表格数据工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/main0220.html?DbPAR=WRITER">文字对象工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Track Changes Toolbar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">在文本文档中导航</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">使用键盘浏览和选择</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">在文档中移动和复制文本</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">使用「导航」重新排列文档</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">使用导航插入超链接</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/navigator.html?DbPAR=WRITER">文本文档中的导航器</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">使用直接定位光标</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">格式化文本文档</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/pageorientation.html?DbPAR=WRITER">修改页面方向 (横向或纵向)</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/text_capital.html?DbPAR=WRITER">修改文字的大小写</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/hidden_text.html?DbPAR=WRITER">隐藏文本</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">定义不同的页眉与页脚</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">在页眉或页脚中插入章节名称和编号</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">输入时应用文本格式</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/reset_format.html?DbPAR=WRITER">重置字体属性</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">在填充格式模式中应用样式</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/wrap.html?DbPAR=WRITER">围绕对象的文字环绕</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/text_centervert.html?DbPAR=WRITER">利用框架使文字在页面上居中</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">强调文本</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/text_rotate.html?DbPAR=WRITER">旋转文字</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/page_break.html?DbPAR=WRITER">插入和删除分页符</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/pagestyles.html?DbPAR=WRITER">创建和应用页面样式</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/subscript.html?DbPAR=WRITER">将文字设为上标或下标</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">模板与样式</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/templates_styles.html?DbPAR=WRITER">模板和样式</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">对奇数页和偶数页应用不同的页面样式</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/change_header.html?DbPAR=WRITER">根据当前页面创建页面样式</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/load_styles.html?DbPAR=WRITER">使用其他文档或模板中的样式</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">从选项中创建新样式</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/stylist_update.html?DbPAR=WRITER">从选项中更新样式</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/template_manager.html?DbPAR=WRITER">模板管理器</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">文本文档中的图形</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">插入图形</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">从文件中插入图形</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">使用拖放功能从图库插入图形</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">插入扫描图像</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">将 Calc 图表插入文本文档</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">从 LibreOffice Draw 或 Impress 插入图形</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">文本文档中的表格</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">打开或关闭表格中的数字识别</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/tablemode.html?DbPAR=WRITER">通过键盘修改行和列</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/table_delete.html?DbPAR=WRITER">删除表格或目录</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/table_insert.html?DbPAR=WRITER">插入表格</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">在新页面上重复表格标题</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/table_sizing.html?DbPAR=WRITER">更改文本表格中行和列的大小</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">文本文档中的对象</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/anchor_object.html?DbPAR=WRITER">定位对象</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/wrap.html?DbPAR=WRITER">围绕对象的文字环绕</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">文本文档中的章节及框架</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/sections.html?DbPAR=WRITER">使用区域</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/text_frame.html?DbPAR=WRITER">插入、编辑和链接框架</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/section_edit.html?DbPAR=WRITER">编辑区域</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/section_insert.html?DbPAR=WRITER">插入区域</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">目录与索引</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">章节编号</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">自定义索引</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/indices_toc.html?DbPAR=WRITER">创建目录</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/indices_index.html?DbPAR=WRITER">创建字母顺序索引</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">覆盖多个文档的索引</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/indices_literature.html?DbPAR=WRITER">创建参考文献</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/indices_delete.html?DbPAR=WRITER">编辑或删除索引与目录条目</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/indices_edit.html?DbPAR=WRITER">更新、编辑和删除索引与目录</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/indices_enter.html?DbPAR=WRITER">定义索引或目录条目</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/indices_form.html?DbPAR=WRITER">格式化索引或目录</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">文本文档中的字段</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/fields.html?DbPAR=WRITER">关于字段</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/fields_date.html?DbPAR=WRITER">插入固定或可变的日期字段</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/field_convert.html?DbPAR=WRITER">将字段转换成文本</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">文本文档中的计算</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">跨表格计算</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/calculate.html?DbPAR=WRITER">在文本文档中计算</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">在文本文档中计算并粘贴公式的结果</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">计算表格中的单元格总计</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">文本文档中的复杂公式计算</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">将表格计算结果显示到另一表格中</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">特殊文本元素</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/captions.html?DbPAR=WRITER">使用标题</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/conditional_text.html?DbPAR=WRITER">有条件的文字</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">用于页数的有条件的文字</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/fields_date.html?DbPAR=WRITER">插入固定或可变的日期字段</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/fields_enter.html?DbPAR=WRITER">添加输入字段</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">插入续页页码</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">将页码插入页脚</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/hidden_text.html?DbPAR=WRITER">隐藏文本</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">定义不同的页眉与页脚</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">在页眉或页脚中插入章节名称和编号</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">按字段或条件查询用户数据</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">插入和编辑脚注或尾注</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">脚注之间的间距</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/header_footer.html?DbPAR=WRITER">关于页眉与页脚</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/header_with_line.html?DbPAR=WRITER">格式化页眉或页脚</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/text_animation.html?DbPAR=WRITER">使用文本动画</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">创建制式信函</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">自动函数</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">将例外情况添加到自动更正列表中</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/autotext.html?DbPAR=WRITER">使用自动图文集</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">输入时创建编号/项目符号列表</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/auto_off.html?DbPAR=WRITER">关闭自动更正</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">自动检查拼写</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">打开或关闭表格中的数字识别</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">断词</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">项目符号与编号</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">向标题添加章节编号</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">输入时创建编号/项目符号列表</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">章节编号</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">合并编号列表</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">添加行编号</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/number_sequence.html?DbPAR=WRITER">定义编号范围</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">添加编号</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">添加项目符号</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">拼写检查、同义词库及语言选项</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">自动检查拼写</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">从自定义词典中删除字</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">同义词库</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">检查拼写和语法</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">疑难问题技巧</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">在页面顶部的表格之前插入文字</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">转到特定书签</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">载入、保存、导入、导出与遮盖保密内容</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/send2html.html?DbPAR=WRITER">以 HTML 格式保存文本文档</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">插入完整文本文档</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">主控文档</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/globaldoc.html?DbPAR=WRITER">主控文档和子文档</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">链接与引用</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/references.html?DbPAR=WRITER">插入交叉引用</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">使用导航插入超链接</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">打印</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selecting What to Print</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/printer_tray.html?DbPAR=WRITER">选择打印机纸张来源</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/print_preview.html?DbPAR=WRITER">打印前预览页面</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/print_small.html?DbPAR=WRITER">在一张纸上打印多个页面</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/pagestyles.html?DbPAR=WRITER">创建和应用页面样式</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">搜索与替换</label><ul>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/search_regexp.html?DbPAR=WRITER">在文字搜索中使用正则表达式</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/02100001.html?DbPAR=WRITER">正则表达式列表</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML 文档 (Writer Web)</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/07/09000000.html?DbPAR=WRITER">网页</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/02/01170700.html?DbPAR=WRITER">HTML 筛选器和表单</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/send2html.html?DbPAR=WRITER">以 HTML 格式保存文本文档</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">电子表格 (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">常规信息及用户界面用法</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/main0000.html?DbPAR=CALC">欢迎使用 LibreOffice Calc 帮助</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0503.html?DbPAR=CALC">LibreOffice Calc 电子表格的功能</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/keyboard.html?DbPAR=CALC">快捷键 (LibreOffice Calc 辅助功能)</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/04/01020000.html?DbPAR=CALC">电子表格的快捷键</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/05/02140000.html?DbPAR=CALC">LibreOffice Calc 中的错误代码</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060112.html?DbPAR=CALC">LibreOffice Calc 中用于编程的加载宏</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/main.html?DbPAR=CALC">LibreOffice Calc 使用说明</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">命令和菜单项指南</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">菜单</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/main0100.html?DbPAR=CALC">菜单</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0101.html?DbPAR=CALC">文件</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0102.html?DbPAR=CALC">编辑</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0103.html?DbPAR=CALC">视图</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0104.html?DbPAR=CALC">插入</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0105.html?DbPAR=CALC">格式</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0116.html?DbPAR=CALC">工作表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0112.html?DbPAR=CALC">数据</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0106.html?DbPAR=CALC">工具</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0107.html?DbPAR=CALC">窗口</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0108.html?DbPAR=CALC">「帮助」菜单</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">工具栏</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/main0200.html?DbPAR=CALC">工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0202.html?DbPAR=CALC">「格式」工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0203.html?DbPAR=CALC">绘图对象属性栏</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0205.html?DbPAR=CALC">文字格式栏</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0206.html?DbPAR=CALC">公式栏</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0208.html?DbPAR=CALC">状态栏</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0210.html?DbPAR=CALC">「打印预览」工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0214.html?DbPAR=CALC">图像工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/main0218.html?DbPAR=CALC">工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0201.html?DbPAR=CALC">标准工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0212.html?DbPAR=CALC">表格数据工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0213.html?DbPAR=CALC">表单导航栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0214.html?DbPAR=CALC">查询设计栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0226.html?DbPAR=CALC">表单设计工具栏</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">函数 (公式) 类别及运算符</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060000.html?DbPAR=CALC">函数向导</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060100.html?DbPAR=CALC">函数清单 (根据类别)</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060107.html?DbPAR=CALC">矩阵函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060120.html?DbPAR=CALC">位操作函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060101.html?DbPAR=CALC">数据库函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060102.html?DbPAR=CALC">日期与时间函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060103.html?DbPAR=CALC">财务函数第一部分</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060119.html?DbPAR=CALC">财务函数第二部分</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060118.html?DbPAR=CALC">金融函数第三部分</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060104.html?DbPAR=CALC">信息函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060105.html?DbPAR=CALC">逻辑函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060106.html?DbPAR=CALC">数学函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060108.html?DbPAR=CALC">统计函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060181.html?DbPAR=CALC">统计函数第一部分</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060182.html?DbPAR=CALC">统计函数第二部分</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060183.html?DbPAR=CALC">统计函数第三部分</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060184.html?DbPAR=CALC">统计函数第四部分</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060185.html?DbPAR=CALC">统计函数第五部分</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060109.html?DbPAR=CALC">电子表格函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060110.html?DbPAR=CALC">文字函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060111.html?DbPAR=CALC">加载宏函数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060115.html?DbPAR=CALC">加载宏函数，分析函数列表第一部分</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060116.html?DbPAR=CALC">扩展函数，分析函数列表第二部分</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/04060199.html?DbPAR=CALC">LibreOffice Calc 中的运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/userdefined_function.html?DbPAR=CALC">自定义函数</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">载入、保存、导入、导出与遮盖保密内容</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/webquery.html?DbPAR=CALC">在表格中插入外部数据 (WebQuery)</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/html_doc.html?DbPAR=CALC">将工作表以 HTML 格式保存和打开</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/csv_formula.html?DbPAR=CALC">导入与导出文本文件</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">格式化</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/text_rotate.html?DbPAR=CALC">旋转文字</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/text_wrap.html?DbPAR=CALC">单元格内手动强制换行</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/text_numbers.html?DbPAR=CALC">将数字格式化为文本</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/super_subscript.html?DbPAR=CALC">文字上标/下标</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/row_height.html?DbPAR=CALC">改变行高或列宽</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">应用条件格式</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">高亮显示负数</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">根据公式指定的格式</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">输入带前置零的数字</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/format_table.html?DbPAR=CALC">格式化电子表格</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/format_value.html?DbPAR=CALC">格式化带小数的数字</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/value_with_name.html?DbPAR=CALC">命名单元格</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/table_rotate.html?DbPAR=CALC">旋转表格 (转置)</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/rename_table.html?DbPAR=CALC">重命名工作表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx 年</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">使用四舍五入的数字</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/currency_format.html?DbPAR=CALC">采用货币格式的单元格</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/autoformat.html?DbPAR=CALC">表格的自动格式</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/note_insert.html?DbPAR=CALC">插入和编辑批注</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/design.html?DbPAR=CALC">选择工作表主题</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/fraction_enter.html?DbPAR=CALC">输入分数</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">筛选与排序</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/filters.html?DbPAR=CALC">应用筛选</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/autofilter.html?DbPAR=CALC">添加自动筛选</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/sorted_list.html?DbPAR=CALC">应用排序列表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">打印</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/print_title_row.html?DbPAR=CALC">在每一页上打印行或列</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/print_landscape.html?DbPAR=CALC">横向打印工作表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/print_details.html?DbPAR=CALC">打印工作表详细资料</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/print_exact.html?DbPAR=CALC">定义打印的页数</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">数据区域</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/database_define.html?DbPAR=CALC">定义数据库区域</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/database_filter.html?DbPAR=CALC">过滤单元格范围</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/database_sort.html?DbPAR=CALC">数据排序</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">数据透视表</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/datapilot.html?DbPAR=CALC">数据透视表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">创建数据透视表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">删除数据透视表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">编辑透视表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">筛选数据透视表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">选择数据透视表输出范围</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">更新数据透视表</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">数据透视图</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/pivotchart.html?DbPAR=CALC">数据透视图</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">创建数据透视图</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">编辑数据透视图</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">筛选数据透视图</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">数据透视图更新</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">删除数据透视图</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">方案</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/scenario.html?DbPAR=CALC">使用方案</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">小计</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">引用</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">地址和引用，绝对和相对</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/cellreferences.html?DbPAR=CALC">引用其他文档中的单元格</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">引用其他工作表以及引用 URL</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">通过拖放来引用单元格</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/address_auto.html?DbPAR=CALC">将名称识别为地址</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">查看、选择、复制</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/table_view.html?DbPAR=CALC">修改表格视图</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/formula_value.html?DbPAR=CALC">显示公式或数值</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/line_fix.html?DbPAR=CALC">行或列作为标题固定</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/multi_tables.html?DbPAR=CALC">浏览工作表标签</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/edit_multitables.html?DbPAR=CALC">复制到多个工作表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/cellcopy.html?DbPAR=CALC">仅复制可见单元格</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/mark_cells.html?DbPAR=CALC">选择多个单元格</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">公式与计算</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/formulas.html?DbPAR=CALC">通过公式计算</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/formula_copy.html?DbPAR=CALC">复制公式</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/formula_enter.html?DbPAR=CALC">输入公式</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/formula_value.html?DbPAR=CALC">显示公式或数值</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/calculate.html?DbPAR=CALC">电子表格中的计算</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/calc_date.html?DbPAR=CALC">使用日期与时间进行计算</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/calc_series.html?DbPAR=CALC">自动计算序列</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">计算时差</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/matrixformula.html?DbPAR=CALC">输入矩阵公式</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">保护</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/cell_protect.html?DbPAR=CALC">保护单元格不被修改</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">取消单元格保护</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">编写Calc电子表格宏</label><ul>\
    <li><a target="_top" href="zh-CN/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatting Borders in Calc with Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">其它选项</label><ul>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/auto_off.html?DbPAR=CALC">关闭自动更正功能</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/consolidate.html?DbPAR=CALC">合并计算数据</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/goalseek.html?DbPAR=CALC">应用单变量求解</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/01/solver.html?DbPAR=CALC">求解器</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/multioperation.html?DbPAR=CALC">应用多重计算</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/multitables.html?DbPAR=CALC">应用多个工作表</a></li>\
    <li><a target="_top" href="zh-CN/text/scalc/guide/validity.html?DbPAR=CALC">单元格内容的有效性</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">演示文稿 (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">常规信息及用户界面用法</label><ul>\
    <li><a target="_top" href="zh-CN/text/simpress/main0000.html?DbPAR=IMPRESS">欢迎使用 LibreOffice Impress 帮助</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0503.html?DbPAR=IMPRESS">LibreOffice Impress 功能</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">使用 LibreOffice Impress 中的快捷键</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/04/01020000.html?DbPAR=IMPRESS">LibreOffice Impress 的快捷键</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/04/presenter.html?DbPAR=IMPRESS">演讲者控制台快捷键</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/main.html?DbPAR=IMPRESS">LibreOffice Impress 使用说明</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">命令和菜单项指南</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">菜单</label><ul>\
    <li><a target="_top" href="zh-CN/text/simpress/main0100.html?DbPAR=IMPRESS">菜单</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0101.html?DbPAR=IMPRESS">文件</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main_edit.html?DbPAR=IMPRESS">编辑</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0103.html?DbPAR=IMPRESS">视图</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0104.html?DbPAR=IMPRESS">插入</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main_format.html?DbPAR=IMPRESS">格式</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main_slide.html?DbPAR=IMPRESS">幻灯片</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0114.html?DbPAR=IMPRESS">幻灯片放映</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main_tools.html?DbPAR=IMPRESS">工具</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0107.html?DbPAR=IMPRESS">窗口</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0108.html?DbPAR=IMPRESS">「帮助」菜单</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">工具栏</label><ul>\
    <li><a target="_top" href="zh-CN/text/simpress/main0200.html?DbPAR=IMPRESS">工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0210.html?DbPAR=IMPRESS">绘图栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0227.html?DbPAR=IMPRESS">编辑接点栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0226.html?DbPAR=IMPRESS">表单设计工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0213.html?DbPAR=IMPRESS">表单导航栏</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0214.html?DbPAR=IMPRESS">图像栏</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0202.html?DbPAR=IMPRESS">线条和填充栏</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0213.html?DbPAR=IMPRESS">选项栏</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0211.html?DbPAR=IMPRESS">大纲工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0209.html?DbPAR=IMPRESS">标尺</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0212.html?DbPAR=IMPRESS">「幻灯片浏览」栏</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0204.html?DbPAR=IMPRESS">幻灯片视图中的对象栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0201.html?DbPAR=IMPRESS">标准工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0206.html?DbPAR=IMPRESS">状态栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0204.html?DbPAR=IMPRESS">表格工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0203.html?DbPAR=IMPRESS">文字格式栏</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">载入、保存、导入、导出与遮盖保密内容</label><ul>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/html_export.html?DbPAR=IMPRESS">以 HTML 格式保存演示文稿</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/html_import.html?DbPAR=IMPRESS">将 HTML 页面导入演示文稿</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">以 GIF 格式导出动画</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">在幻灯片中包括电子表格</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">插入图形</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">格式化</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">加载线条和箭头样式</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">定义自定义颜色</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">创建渐变填充</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">替换颜色</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">排列，对齐和分布对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/background.html?DbPAR=IMPRESS">修改幻灯片背景填充</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/footer.html?DbPAR=IMPRESS">向所有幻灯片添加页眉或页脚</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/move_object.html?DbPAR=IMPRESS">移动对象</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">打印</label><ul>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/printing.html?DbPAR=IMPRESS">打印演示文稿</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">根据纸张尺寸调整幻灯片打印</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">特效</label><ul>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">以 GIF 格式导出动画</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">为演示文稿幻灯片中的对象设置动画</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">以动画方式切换幻灯片</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">交叉淡入淡出两个对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">创建动画 GIF 图像</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">对象、图形和位图</label><ul>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">结合对象与构造形状</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/groups.html?DbPAR=IMPRESS">组合对象</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">绘制扇形和圆缺</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">复制对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformations</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">旋转对象</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">组合三维对象</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">连接线条</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">将文本字符转换为绘图对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">将位图图像转换成矢量图形</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">将二维对象转换成曲线、多边形和三维对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">加载线条和箭头样式</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">绘制曲线</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">编辑曲线</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">插入图形</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">在幻灯片中包括电子表格</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/move_object.html?DbPAR=IMPRESS">移动对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/select_object.html?DbPAR=IMPRESS">选择底层对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">创建流程图</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">演示文稿中的文本</label><ul>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">添加文本</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">将文本字符转换为绘图对象</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">查看</label><ul>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">修改幻灯片顺序</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">使用小键盘缩放</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">幻灯片播放</label><ul>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/show.html?DbPAR=IMPRESS">显示幻灯片放映</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">使用「演讲者控制台」</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote 指南</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/individual.html?DbPAR=IMPRESS">创建自定义幻灯片放映</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">幻灯片更换的排练计时</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">绘图 (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">常规信息及用户界面用法</label><ul>\
    <li><a target="_top" href="zh-CN/text/sdraw/main0000.html?DbPAR=DRAW">欢迎使用 LibreOffice Draw 帮助</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main0503.html?DbPAR=DRAW">LibreOffice Draw 功能</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/keyboard.html?DbPAR=DRAW">绘图对象的快捷键</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/04/01020000.html?DbPAR=DRAW">绘图快捷键</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/main.html?DbPAR=DRAW">LibreOffice Draw 使用说明</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">命令及菜单项参考</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">菜单</label><ul>\
    <li><a target="_top" href="zh-CN/text/sdraw/main0100.html?DbPAR=DRAW">菜单</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main0101.html?DbPAR=DRAW">文件</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main_edit.html?DbPAR=DRAW">编辑</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main0103.html?DbPAR=DRAW">查看（Draw中的菜单）</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main_insert.html?DbPAR=DRAW">插入</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main_format.html?DbPAR=DRAW">格式</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main_page.html?DbPAR=DRAW">页面</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main_tools.html?DbPAR=DRAW">工具</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/main0107.html?DbPAR=DRAW">窗口</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0108.html?DbPAR=DRAW">「帮助」菜单</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">工具栏</label><ul>\
    <li><a target="_top" href="zh-CN/text/sdraw/main0200.html?DbPAR=DRAW">工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D 设置</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main0210.html?DbPAR=DRAW">绘图栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0227.html?DbPAR=DRAW">编辑接点栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0226.html?DbPAR=DRAW">表单设计工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0213.html?DbPAR=DRAW">表单导航栏</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/main0213.html?DbPAR=DRAW">选项工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0201.html?DbPAR=DRAW">标准工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/main0204.html?DbPAR=DRAW">表格工具栏</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">载入、保存、导入及导出</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">插入图形</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">格式化</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">加载线条和箭头样式</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/color_define.html?DbPAR=DRAW">定义自定义颜色</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/gradient.html?DbPAR=DRAW">创建渐变填充</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">替换颜色</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">排列，对齐和分布对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/background.html?DbPAR=DRAW">修改幻灯片背景填充</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/move_object.html?DbPAR=DRAW">移动对象</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">打印</label><ul>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/printing.html?DbPAR=DRAW">打印演示文稿</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/print_tofit.html?DbPAR=DRAW">根据纸张尺寸调整幻灯片打印</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">效果</label><ul>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">交叉淡入淡出两个对象</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/05350000.html?DbPAR=DRAW">三维效果</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/02/10030000.html?DbPAR=DRAW">Transformations</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">对象、图形和位图</label><ul>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">结合对象与构造形状</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">绘制扇形和圆缺</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">复制对象</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">旋转对象</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">组合三维对象</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/join_objects.html?DbPAR=DRAW">连接线条</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/text2curve.html?DbPAR=DRAW">将文本字符转换为绘图对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/vectorize.html?DbPAR=DRAW">将位图图像转换成矢量图形</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/3d_create.html?DbPAR=DRAW">将二维对象转换成曲线、多边形和三维对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">加载线条和箭头样式</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/line_draw.html?DbPAR=DRAW">绘制曲线</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/line_edit.html?DbPAR=DRAW">编辑曲线</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">插入图形</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/table_insert.html?DbPAR=DRAW">在幻灯片中包括电子表格</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/move_object.html?DbPAR=DRAW">移动对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/select_object.html?DbPAR=DRAW">选择底层对象</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/orgchart.html?DbPAR=DRAW">创建流程图</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">组合与分层</label><ul>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/groups.html?DbPAR=DRAW">组合对象</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserting Layers</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">绘图中的文本</label><ul>\
    <li><a target="_top" href="zh-CN/text/sdraw/guide/text_enter.html?DbPAR=DRAW">添加文本</a></li>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/text2curve.html?DbPAR=DRAW">将文本字符转换为绘图对象</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">查看</label><ul>\
    <li><a target="_top" href="zh-CN/text/simpress/guide/change_scale.html?DbPAR=DRAW">使用小键盘缩放</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">数据库功能 (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">常规信息</label><ul>\
    <li><a target="_top" href="zh-CN/text/sdatabase/main.html?DbPAR=BASE">LibreOffice 数据库</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/database_main.html?DbPAR=BASE">数据库摘要</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_new.html?DbPAR=BASE">创建新数据库</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_tables.html?DbPAR=BASE">使用表格</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_queries.html?DbPAR=BASE">使用查询</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_forms.html?DbPAR=BASE">使用表单</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_reports.html?DbPAR=BASE">创建报表</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_register.html?DbPAR=BASE">注册和删除数据库</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_im_export.html?DbPAR=BASE">导入与导出 Base 中的数据</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_enter_sql.html?DbPAR=BASE">执行 SQL 命令</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">公式 (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">常规信息及用户界面用法</label><ul>\
    <li><a target="_top" href="zh-CN/text/smath/main0000.html?DbPAR=MATH">欢迎使用 LibreOffice Math 帮助</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/main0503.html?DbPAR=MATH">LibreOffice Math 功能</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice 公式元素</label><ul>\
    <li><a target="_top" href="zh-CN/text/smath/01/03090100.html?DbPAR=MATH">一元/二元运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/01/03090200.html?DbPAR=MATH">关系</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/01/03090800.html?DbPAR=MATH">设置操作</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/01/03090400.html?DbPAR=MATH">功能</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/01/03090300.html?DbPAR=MATH">运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/01/03090600.html?DbPAR=MATH">属性</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/01/03090500.html?DbPAR=MATH">括号</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/01/03090700.html?DbPAR=MATH">格式</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/01/03091600.html?DbPAR=MATH">其他符号</a></li>\
      </ul></li>\
    <li><a target="_top" href="zh-CN/text/smath/guide/main.html?DbPAR=MATH">LibreOffice Math 使用说明</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/guide/keyboard.html?DbPAR=MATH">快捷方式 (LibreOffice Math 辅助功能)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">命令和菜单项指南</label><ul>\
    <li><a target="_top" href="zh-CN/text/smath/main0100.html?DbPAR=MATH">菜单</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/main0200.html?DbPAR=MATH">工具栏</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">使用公式</label><ul>\
    <li><a target="_top" href="zh-CN/text/smath/guide/align.html?DbPAR=MATH">手动对齐公式部分</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/guide/color.html?DbPAR=MATH">将颜色应用于公式的各个部分</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/guide/attributes.html?DbPAR=MATH">修改默认属性</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/guide/brackets.html?DbPAR=MATH">合并括号中的公式部分</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/guide/comment.html?DbPAR=MATH">输入注释</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/guide/newline.html?DbPAR=MATH">输入换行符</a></li>\
    <li><a target="_top" href="zh-CN/text/smath/guide/parentheses.html?DbPAR=MATH">插入括号</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">图表与图示</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">常规信息</label><ul>\
    <li><a target="_top" href="zh-CN/text/schart/main0000.html?DbPAR=CHART">LibreOffice 中的图表</a></li>\
    <li><a target="_top" href="zh-CN/text/schart/main0503.html?DbPAR=CHART">LibreOffice 图表功能</a></li>\
    <li><a target="_top" href="zh-CN/text/schart/04/01020000.html?DbPAR=CHART">图表的快捷键</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">宏与脚本</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice Basic</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">常规信息及用户界面用法</label><ul>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice Basic 帮助</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01000000.html?DbPAR=BASIC">使用 LibreOffice Basic 编程</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basic 词汇表</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01010210.html?DbPAR=BASIC">Basics</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01020000.html?DbPAR=BASIC">语法</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01030100.html?DbPAR=BASIC">IDE 概况</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01030200.html?DbPAR=BASIC">Basic 编辑器</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01050100.html?DbPAR=BASIC">监视窗口</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/main0211.html?DbPAR=BASIC">宏工具栏</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/05060700.html?DbPAR=BASIC">宏</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">对 VBA 宏的支持</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">命令行参考</label><ul>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01020500.html?DbPAR=BASIC">程序库、模块和对话框</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">函数、语句和运算符</label><ul>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic 中的常量</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100000.html?DbPAR=BASIC">变量</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03060000.html?DbPAR=BASIC">逻辑运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03110100.html?DbPAR=BASIC">比较运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120000.html?DbPAR=BASIC">字符串</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030000.html?DbPAR=BASIC">日期与时间函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03070000.html?DbPAR=BASIC">数学运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080000.html?DbPAR=BASIC">数字函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080100.html?DbPAR=BASIC">三角函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010000.html?DbPAR=BASIC">屏幕 I/O 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020000.html?DbPAR=BASIC">文件 I/O 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090000.html?DbPAR=BASIC">控制程序的执行</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03050000.html?DbPAR=BASIC">错误处理函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03130000.html?DbPAR=BASIC">其他命令</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080300.html?DbPAR=BASIC">生成随机数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO 对象</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">独家 VBA 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090400.html?DbPAR=BASIC">其他语句</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">按字母排序的函数、语句和运算符列表</label><ul>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090404.html?DbPAR=BASIC">End 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03050000.html?DbPAR=BASIC">错误处理函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090406.html?DbPAR=BASIC">函数语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid 函数, Mid 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080000.html?DbPAR=BASIC">数字函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub 语句; On...GoTo 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (函数语句)</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space 与 Spc 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space 与 Spc 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080400.html?DbPAR=BASIC">计算平方根</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120202.html?DbPAR=BASIC">String 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName 函数; VarType 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName 函数 [VBA]</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03090411.html?DbPAR=BASIC">With 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write 语句</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year 函数</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" 运算符</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03120300.html?DbPAR=BASIC">编辑字符串内容</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01020100.html?DbPAR=BASIC">使用变量</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">高级 Basic 库</label><ul>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">工具库</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Depot 库</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Euro 库</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FormWizard 库</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Gimmicks 库</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard Library</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Schedule 库</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">ScriptBindingLibrary 库</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Template 库</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Library</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForge库</label><ul>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge 库</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">指南</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/macro_recording.html?DbPAR=BASIC">录制一个宏</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/guide/control_properties.html?DbPAR=BASIC">修改对话框编辑器中控件的属性</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/guide/insert_control.html?DbPAR=BASIC">在对话框编辑器中创建控件</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/guide/sample_code.html?DbPAR=BASIC">对话框编辑器中控件的编程示例</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">通过 Basic 打开对话框</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">创建 Basic 对话框</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01030400.html?DbPAR=BASIC">管理库和模块</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01020100.html?DbPAR=BASIC">使用变量</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01020200.html?DbPAR=BASIC">使用对象</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01030300.html?DbPAR=BASIC">调试 Basic 程序</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic 编程示例</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">从 Basic 到 Python</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python 脚本帮助</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">常规信息及用户界面用法</label><ul>\
    <li><a target="_top" href="zh-CN/text/sbasic/python/main0000.html?DbPAR=BASIC">Python 脚本</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/python/python_ide.html?DbPAR=BASIC">Python 集成开发环境(IDE)</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python 脚本管理</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python 交互式 shell</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">使用 Python 语言编程</label><ul>\
    <li><a target="_top" href="zh-CN/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : 用 Python 语言编程</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python 示例</a></li>\
    <li><a target="_top" href="zh-CN/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">从 Python 调用 BASIC</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">脚本开发工具</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice 安装</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">修改 Microsoft Office 文档类型的关联</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">安全模式</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">常见的帮助主题</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">常规信息</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/main0400.html?DbPAR=SHARED">快捷键</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/00/00000005.html?DbPAR=SHARED">通用词汇表</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/00/00000002.html?DbPAR=SHARED">Internet 术语词汇表</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/accessibility.html?DbPAR=SHARED">LibreOffice 中的辅助功能</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/keyboard.html?DbPAR=SHARED">快捷方式 (LibreOffice 辅助功能)</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/04/01010000.html?DbPAR=SHARED">LibreOffice 中的常规快捷键</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/version_number.html?DbPAR=SHARED">版本和编译号</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice 与 Microsoft Office</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/ms_user.html?DbPAR=SHARED">使用 Microsoft Office 和 LibreOffice</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">比较 Microsoft Office 和 LibreOffice 的术语</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">关于转换 Microsoft Office 文档</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">修改 Microsoft Office 文档类型的关联</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice 选项</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01000000.html?DbPAR=SHARED">选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01010100.html?DbPAR=SHARED">用户数据</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01010200.html?DbPAR=SHARED">常规</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01010800.html?DbPAR=SHARED">视图</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01010900.html?DbPAR=SHARED">打印选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01010300.html?DbPAR=SHARED">路径</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01010700.html?DbPAR=SHARED">字体</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01030300.html?DbPAR=SHARED">安全性</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01012000.html?DbPAR=SHARED">应用程序颜色</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01013000.html?DbPAR=SHARED">辅助功能</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/java.html?DbPAR=SHARED">高级</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/expertconfig.html?DbPAR=SHARED">专家配置</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01010400.html?DbPAR=SHARED">写作辅助</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01010600.html?DbPAR=SHARED">通用</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01020000.html?DbPAR=SHARED">加载/保存选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01030000.html?DbPAR=SHARED">Internet 选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01040000.html?DbPAR=SHARED">文本文档选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01050000.html?DbPAR=SHARED">HTML 文档选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01060000.html?DbPAR=SHARED">电子表格选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01070000.html?DbPAR=SHARED">演示文稿选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01080000.html?DbPAR=SHARED">绘图选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01090000.html?DbPAR=SHARED">公式</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01110000.html?DbPAR=SHARED">图表选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA 属性</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01150000.html?DbPAR=SHARED">语言设置选项</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/optionen/01160000.html?DbPAR=SHARED">数据源选项</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">向导</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/autopi/01000000.html?DbPAR=SHARED">向导</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">信函向导</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/autopi/01010000.html?DbPAR=SHARED">信函向导</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">传真向导</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/autopi/01020000.html?DbPAR=SHARED">传真向导</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">会议议程向导</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/autopi/01040000.html?DbPAR=SHARED">议程向导</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML 导出向导</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/autopi/01110000.html?DbPAR=SHARED">HTML 导出</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">文档转换器向导</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/autopi/01130000.html?DbPAR=SHARED">文档转换器</a></li>\
      </ul></li>\
    <li><a target="_top" href="zh-CN/text/shared/autopi/01150000.html?DbPAR=SHARED">欧元换算器向导</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">配置 LibreOffice</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/configure_overview.html?DbPAR=SHARED">配置 LibreOffice</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/packagemanager.html?DbPAR=SHARED">扩展管理器</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/flat_icons.html?DbPAR=SHARED">修改图标视图</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">向工具栏添加按钮</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/workfolder.html?DbPAR=SHARED">修改您的工作目录</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_addressbook.html?DbPAR=SHARED">注册通讯簿</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/formfields.html?DbPAR=SHARED">插入和编辑按钮</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">用户界面使用</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">快速浏览到对象</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/navigator.html?DbPAR=SHARED">文档概览导航</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/autohide.html?DbPAR=SHARED">显示、停靠和隐藏窗口</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/textmode_change.html?DbPAR=SHARED">在插入模式和覆盖模式之间切换</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">使用工具栏</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">数字签名</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/digital_signatures.html?DbPAR=SHARED">关于数字签名</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">应用数字签名</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/signexistingpdf.html?DbPAR=SHARED">签署现有的 PDF</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">打印、传真、发送</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/labels_database.html?DbPAR=SHARED">打印地址标签</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">黑白打印</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/fax.html?DbPAR=SHARED">发送传真和 LibreOffice 传真配置</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">拖放</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/dragdrop.html?DbPAR=SHARED">在 LibreOffice 文档中拖放</a></li>\
    <li><a target="_top" href="zh-CN/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">在文档中移动和复制文本</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">复制电子表格区域至文本文档</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">在文档之间复制图形</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">从图库复制图形</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">拖放数据源视图</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">复制与粘贴</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">将图形对象复制到其他文档中</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">在文档之间复制图形</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">从图库复制图形</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">复制电子表格区域至文本文档</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">图表与图示</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/chart_insert.html?DbPAR=SHARED">插入图表</a></li>\
    <li><a target="_top" href="zh-CN/text/schart/main0000.html?DbPAR=SHARED">LibreOffice 中的图表</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">载入、保存、导入、导出与 PDF</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/doc_open.html?DbPAR=SHARED">打开文档</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/import_ms.html?DbPAR=SHARED">打开以其他格式保存的文档</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/doc_save.html?DbPAR=SHARED">保存文档</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/doc_autosave.html?DbPAR=SHARED">自动保存文档</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/export_ms.html?DbPAR=SHARED">以其他格式保存文档</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">导出为 PDF 格式</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">以文本格式导入与导出数据</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">链接与引用</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">插入超链接</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">相对链接和绝对链接</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">编辑超链接</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">文档版本跟踪</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">比较文档版本</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">合并版本</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/redlining_enter.html?DbPAR=SHARED">记录修改</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/redlining.html?DbPAR=SHARED">记录和显示修改</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/redlining_accept.html?DbPAR=SHARED">接受或拒绝修改</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/redlining_versions.html?DbPAR=SHARED">版本管理</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">标签与名片</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/labels.html?DbPAR=SHARED">制作并打印标签和名片</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">插入外部数据</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/copytable2application.html?DbPAR=SHARED">从插入电子表格数据</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/copytext2application.html?DbPAR=SHARED">插入文本文档数据</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">插入、编辑和保存位图</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">将图形添加到图库中</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">自动函数</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/autocorr_url.html?DbPAR=SHARED">关闭「自动 URL 识别」</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">搜索与替换</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_search2.html?DbPAR=SHARED">使用表单筛选器查找</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_search.html?DbPAR=SHARED">查找表格和表单文档</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/01/02100001.html?DbPAR=SHARED">正则表达式列表</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">指南</label><ul>\
    <li><a target="_top" href="zh-CN/text/shared/guide/linestyles.html?DbPAR=SHARED">应用线型</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/text_color.html?DbPAR=SHARED">修改文字的颜色</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/change_title.html?DbPAR=SHARED">修改文档的标题</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/round_corner.html?DbPAR=SHARED">创建圆角</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/background.html?DbPAR=SHARED">定义背景颜色或背景图形</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/linestyle_define.html?DbPAR=SHARED">定义线型</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">编辑图形对象</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/line_intext.html?DbPAR=SHARED">在文本中绘制线条</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/aaa_start.html?DbPAR=SHARED">第一个步骤</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/gallery_insert.html?DbPAR=SHARED">从图库中插入对象</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/space_hyphen.html?DbPAR=SHARED">插入不间断空格、不间断连字符和软连字符</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">插入特殊字符</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/tabs.html?DbPAR=SHARED">插入和编辑制表位</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">使用远程文件</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/protection.html?DbPAR=SHARED">保护 LibreOffice 中的内容</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/redlining_protect.html?DbPAR=SHARED">保护记录</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/pageformat_max.html?DbPAR=SHARED">选择页面上的最大可打印区域</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/measurement_units.html?DbPAR=SHARED">选择度量单位</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/language_select.html?DbPAR=SHARED">选择文档语言</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">表格设计</a></li>\
    <li><a target="_top" href="zh-CN/text/shared/guide/numbering_stop.html?DbPAR=SHARED">关闭单独段落的项目符号与编号</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
