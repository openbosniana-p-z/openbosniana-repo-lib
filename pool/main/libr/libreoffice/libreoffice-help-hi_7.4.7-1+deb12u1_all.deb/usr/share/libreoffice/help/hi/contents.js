document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Text Documents (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="hi/text/swriter/main0000.html?DbPAR=WRITER">LibreOffice राइटर मदद में आपका स्वागत है</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0503.html?DbPAR=WRITER">LibreOffice Writer Features</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/main.html?DbPAR=WRITER">LibreOffice राइटर इस्तेमाल करने हेतु निर्देश</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">विंडो को अन्यत्र रखना तथा नया आकार देना</a></li>\
    <li><a target="_top" href="hi/text/swriter/04/01020000.html?DbPAR=WRITER">Shortcut Keys for LibreOffice Writer</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/words_count.html?DbPAR=WRITER">शब्दों को गिना जा रहा है</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/keyboard.html?DbPAR=WRITER">शॉर्टकट कुंजियों का इस्तेमाल करना (LibreOffice राइटर एक्सेसिबिलिटी)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">मेन्यू</label><ul>\
    <li><a target="_top" href="hi/text/swriter/main0100.html?DbPAR=WRITER">मेनू</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0101.html?DbPAR=WRITER">फ़ाइल</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0102.html?DbPAR=WRITER">संपादन</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0103.html?DbPAR=WRITER">दृश्य</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0104.html?DbPAR=WRITER">प्रविष्ट</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0105.html?DbPAR=WRITER">प्रारुप</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0115.html?DbPAR=WRITER">Styles (menu)</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0110.html?DbPAR=WRITER">तालिका</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0120.html?DbPAR=WRITER">Form Menu</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0106.html?DbPAR=WRITER">औज़ार</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0107.html?DbPAR=WRITER">विंडो</a></li>\
    <li><a target="_top" href="hi/text/shared/main0108.html?DbPAR=WRITER">मदद</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">औज़ार पट्टियाँ</label><ul>\
    <li><a target="_top" href="hi/text/swriter/main0200.html?DbPAR=WRITER">औज़ार-पट्टियाँ</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0206.html?DbPAR=WRITER">चिह्न तथा क्रमांक डालने की पट्टी</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0205.html?DbPAR=WRITER">ड्राइंग वस्तु गुण पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="hi/text/shared/main0226.html?DbPAR=WRITER">फ़ॉर्म डिज़ाइन औज़ारपट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0213.html?DbPAR=WRITER">फ़ॉर्म नेविगेशन पट्टी</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0202.html?DbPAR=WRITER">फॉर्मेटिंग पट्टी</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0214.html?DbPAR=WRITER">सूत्र पट्टी</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0215.html?DbPAR=WRITER">फ्रेम पट्टी</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0203.html?DbPAR=WRITER">Image Bar</a></li>\
    <li><a target="_top" href="hi/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo Toolbar</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0216.html?DbPAR=WRITER">OLE Object Bar</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0210.html?DbPAR=WRITER">Print Preview Bar (Writer)</a></li>\
    <li><a target="_top" href="hi/text/shared/main0214.html?DbPAR=WRITER">क्वैरी डिज़ाइन पट्टी</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0213.html?DbPAR=WRITER">मापक</a></li>\
    <li><a target="_top" href="hi/text/shared/main0201.html?DbPAR=WRITER">मानक पट्टी</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0208.html?DbPAR=WRITER">Status Bar (Writer)</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0204.html?DbPAR=WRITER">तालिका पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0212.html?DbPAR=WRITER">सारणी डाटा पट्टी</a></li>\
    <li><a target="_top" href="hi/text/swriter/main0220.html?DbPAR=WRITER">पाठ वस्तु पट्टी</a></li>\
    <li><a target="_top" href="hi/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Track Changes Toolbar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navigating Text Documents</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">कुंजीपट के द्वारा नेविगेशन व चयन</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">दस्तावेज़ों में पाठ खिसकाना व नक़ल करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">नेविगेटर द्वरा दस्तावेज़ को फिर से जमाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">नेविगेटर के जरिए हायपरलिंक प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/navigator.html?DbPAR=WRITER">पाठ दस्तावेज़ों के लिए नेविगेटर</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">डायरेक्ट संकेतक का इस्तेमाल करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatting Text Documents</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/pageorientation.html?DbPAR=WRITER">पृष्ठ की दिशा बदलना (आड़ा या खड़ा)</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/text_capital.html?DbPAR=WRITER">पाठ का केस बदलना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/hidden_text.html?DbPAR=WRITER">पाठ को छुपाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">विभिन्न शीर्ष-सूचना व पाद-सूचना पारिभाषित करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">शीर्ष-टिप्पणी या पाद-टिप्पणी में अध्याय नाम तथा संख्या प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">टाइप करते समय पाठ फ़ॉर्मेटिंग लागू करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/reset_format.html?DbPAR=WRITER">फ़ॉन्ट गुण रीसेट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">फिल फ़ॉर्मेट मोड में शैलियाँ लागू करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/wrap.html?DbPAR=WRITER">वस्तु के चारों ओर पाठ घेरें</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/text_centervert.html?DbPAR=WRITER">पृष्ठ पर बीचोंबीच रखने के लिए फ्रेम का इस्तेमाल</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">पाठ को गाढ़ा करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/text_rotate.html?DbPAR=WRITER">पाठ को घुमाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/page_break.html?DbPAR=WRITER">पृष्ठ ब्रेक प्रविष्ट करना व मिटाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/pagestyles.html?DbPAR=WRITER">पृष्ठ सूचियाँ बनाना बनाना व उन्हें लागू करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/subscript.html?DbPAR=WRITER">पाठ को सबस्क्रिप्ट या सुपरस्क्रिप्ट बनाना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">टैम्पलेट व शैलियाँ</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/templates_styles.html?DbPAR=WRITER">टैम्पलेट व शैलियाँ</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">सम तथा विषम पृष्ठों पर वैकल्पिक पृष्ठ शैलियाँ</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/change_header.html?DbPAR=WRITER">मौजूदा पृष्ठ पर आधारित पृष्ठ शैली बनाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/load_styles.html?DbPAR=WRITER">अन्य दस्तावेज़ या टेम्प्लेट से शैलियाँ इस्तेमाल करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">चयनित से नई शैली बनाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/stylist_update.html?DbPAR=WRITER">चयनित से शैलियाँ अद्यतन करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/template_manager.html?DbPAR=WRITER">Template Manager</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Graphics in Text Documents</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">चित्र प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">किसी फ़ाइल से चित्र प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">खींचना व छोड़ना के जरिए गैलरी में से चित्र जोड़ना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">स्कैन की गई छवि को प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">पाठ दस्तावेज़ में कॅल्क चार्ट प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">LibreOffice ड्रा या इम्प्रेस से ग्राफ़िक्स प्रविष्ट करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tables in Text Documents</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">तालिकाओं में संख्या पहचान चालू या बन्द करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/tablemode.html?DbPAR=WRITER">पंक्तियों और स्तंभों को कुंजीपट द्वारा परिवर्धित करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/table_delete.html?DbPAR=WRITER">तालिका या तालिका के अवयवों को मिटाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/table_insert.html?DbPAR=WRITER">तालिकाएँ प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">नए पृष्ठ पर तालिका शीर्षक को दोहराना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Resizing Rows and Columns in a Text Table</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objects in Text Documents</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/anchor_object.html?DbPAR=WRITER">वस्तुओं को जमाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/wrap.html?DbPAR=WRITER">वस्तु के चारों ओर पाठ घेरें</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sections and Frames in Text Documents</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/sections.html?DbPAR=WRITER">खण्डों का इस्तेमाल करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/section_edit.html?DbPAR=WRITER">खण्डों का संपादन</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/section_insert.html?DbPAR=WRITER">Inserting Sections</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Tables of Contents and Indexes</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">उपयोक्ता द्वारा पारिभाषित निर्देशिकाएँ</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/indices_toc.html?DbPAR=WRITER">विषय-वस्तु तालिका बनाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/indices_index.html?DbPAR=WRITER">अकारादिक्रम में अनुक्रमणिकाएँ बनाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">निर्देशिकाएँ जिनमें बहुत से दस्तावेज़ हैं</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/indices_literature.html?DbPAR=WRITER">ग्रंथसूची बनाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/indices_delete.html?DbPAR=WRITER">अनुक्रमणिकाएँ व तालिका प्रविष्टियाँ संपादन या मिटाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/indices_edit.html?DbPAR=WRITER">निर्देशिकाओं तथा विषय-वस्तु तालिका को अद्यतन करना, संपादन करना  तथा मिटाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/indices_enter.html?DbPAR=WRITER">निर्देशिका या विषय-सूची तालिका प्रविष्टियाँ पारिभाषित करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/indices_form.html?DbPAR=WRITER">निर्देशिका या विषय-सूची तालिका फ़ॉर्मेट करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Fields in Text Documents</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/fields.html?DbPAR=WRITER">क्षेत्रों के बारे में</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/fields_date.html?DbPAR=WRITER">स्थिर या परिवर्तनीय समय क्षेत्र प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/field_convert.html?DbPAR=WRITER">क्षेत्र को पाठ में बदलना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">पाठ दस्तावेज़ों में गणनाएँ</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">तालिकाओं में गणनाएँ करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/calculate.html?DbPAR=WRITER">पाठ दस्तावेज़ों में गणनाएँ</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">पाठ दस्तावेज़ में सूत्र के परिणाम की गणना करना तथा चिपकाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">तालिकाओं में कक्षों के योगों की गणना करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">पाठ दस्तावेज़ों में जटिल सूत्रों की गणना करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">तालिका गणना के परिणाम को भिन्न तालिका में दिखाना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Special Text Elements</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/captions.html?DbPAR=WRITER">शीर्षक इस्तेमाल करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/conditional_text.html?DbPAR=WRITER">सशर्त पाठ</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">पृष्ठ गणना के लिए शर्तयुक्त पाठ</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/fields_date.html?DbPAR=WRITER">स्थिर या परिवर्तनीय समय क्षेत्र प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/fields_enter.html?DbPAR=WRITER">इनपुट क्षेत्र जोड़ना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">शेष पृष्ठों में पृष्ठ क्रमांक प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">पादशीर्षक में पृष्ठ क्रमांक प्रविष्ट करें</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/hidden_text.html?DbPAR=WRITER">पाठ को छुपाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">विभिन्न शीर्ष-सूचना व पाद-सूचना पारिभाषित करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">शीर्ष-टिप्पणी या पाद-टिप्पणी में अध्याय नाम तथा संख्या प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">उपयोक्ता डाटा को क्षेत्र या कंडीशन में क्वैरी करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">पाद-टिप्पणी या अंत-टिप्पणी प्रविष्ट करना व संपादित करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">पाद-टिप्पणियाँ के बीच की दूरी</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/header_footer.html?DbPAR=WRITER">पाद-सूचना व शीर्ष-सूचना के बारे में</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/header_with_line.html?DbPAR=WRITER">पाद-सूचना व शीर्ष-सूचना फ़ॉर्मेट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/text_animation.html?DbPAR=WRITER">पाठ को एनीमेट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">फॉर्म पत्र बनाना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automatic Functions</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">स्वतःसुधार सूची में एक अपवाद जोड़ना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/autotext.html?DbPAR=WRITER">स्वतःपाठ इस्तेमाल करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">जब आप टाइप कर रहे हों तो क्रमांकित या चिह्नित (बुलेटेड) सूची बनाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/auto_off.html?DbPAR=WRITER">Turning Off AutoCorrect</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">वर्तनी स्वचालित जाँचें</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">तालिकाओं में संख्या पहचान चालू या बन्द करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">हायफनेशन</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numbering and Lists</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">शीर्षकों में अध्याय क्रमांक जोड़ना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">जब आप टाइप कर रहे हों तो क्रमांकित या चिह्नित (बुलेटेड) सूची बनाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">क्रमांकित सूचियों को जोड़ना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">पंक्ति क्रमांक डालना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/number_sequence.html?DbPAR=WRITER">संख्या का दायरा पारिभाषित करें</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">क्रमांकन जोड़ा जा रहा है</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">बुलेट जोड़ा जा रहा है</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Spellchecking, Thesaurus, and Languages</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">वर्तनी स्वचालित जाँचें</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">उपयोक्ता पारिभाषित शब्दकोश से शब्दों को मिटाना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">समांतर शब्दकोश</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Checking Spelling and Grammar</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Troubleshooting Tips</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">पृष्ठ के शीर्ष पर तालिका के पहले पाठ प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">विशिष्ट पसंद पर जाना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/send2html.html?DbPAR=WRITER">पाठ दस्तावेज़ एचटीएमएल फॉर्मेट में सहेजना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">एक सम्पूर्ण दस्तावेज़ को प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Master Documents</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Master Documents and Subdocuments</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Links and References</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/references.html?DbPAR=WRITER">क्रास रेफ़रेंसेज़ प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">नेविगेटर के जरिए हायपरलिंक प्रविष्ट करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Printing</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selecting What to Print</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/printer_tray.html?DbPAR=WRITER">प्रिंटर काग़ज़ ट्रे चुनना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/print_preview.html?DbPAR=WRITER">छापने से पहले पृष्ठ का पूर्वावलोकन</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/print_small.html?DbPAR=WRITER">एक शीट में बहुत से पृष्ठ छापना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/pagestyles.html?DbPAR=WRITER">पृष्ठ सूचियाँ बनाना बनाना व उन्हें लागू करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Searching and Replacing</label><ul>\
    <li><a target="_top" href="hi/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="hi/text/shared/01/02100001.html?DbPAR=WRITER">नियमित एक्सप्रेशन की सूची</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML Documents (Writer Web)</label><ul>\
    <li><a target="_top" href="hi/text/shared/07/09000000.html?DbPAR=WRITER">Web Pages</a></li>\
    <li><a target="_top" href="hi/text/shared/02/01170700.html?DbPAR=WRITER">HTML Filters and Forms</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/send2html.html?DbPAR=WRITER">पाठ दस्तावेज़ एचटीएमएल फॉर्मेट में सहेजना</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Spreadsheets (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="hi/text/scalc/main0000.html?DbPAR=CALC">LibreOffice Calc हेल्प में आपका स्वागत है</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0503.html?DbPAR=CALC">LibreOffice Calc Features</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/keyboard.html?DbPAR=CALC">शॉर्टकट कुंजियाँ (LibreOffice कॅल्क एक्सेसिबिलिटी)</a></li>\
    <li><a target="_top" href="hi/text/scalc/04/01020000.html?DbPAR=CALC">स्प्रेडशीट के लिए शॉर्टकट कुंजियाँ</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="hi/text/scalc/05/02140000.html?DbPAR=CALC">Error Codes in LibreOffice Calc</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060112.html?DbPAR=CALC">Add-in for Programming in LibreOffice Calc</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/main.html?DbPAR=CALC">LibreOffice कॅल्क इस्तेमाल करने हेतु निर्देश</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">मेन्यू</label><ul>\
    <li><a target="_top" href="hi/text/scalc/main0100.html?DbPAR=CALC">मेनू</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0101.html?DbPAR=CALC">फ़ाइल</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0102.html?DbPAR=CALC">संपादन</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0103.html?DbPAR=CALC">दृश्य</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0104.html?DbPAR=CALC">प्रविष्ट</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0105.html?DbPAR=CALC">प्रारुप</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0116.html?DbPAR=CALC">Sheet</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0112.html?DbPAR=CALC">डाटा</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0106.html?DbPAR=CALC">औज़ार</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0107.html?DbPAR=CALC">विंडो</a></li>\
    <li><a target="_top" href="hi/text/shared/main0108.html?DbPAR=CALC">मदद</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">औज़ार पट्टियाँ</label><ul>\
    <li><a target="_top" href="hi/text/scalc/main0200.html?DbPAR=CALC">औज़ार पट्टियाँ</a></li>\
    <li><a target="_top" href="hi/text/shared/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0202.html?DbPAR=CALC">फॉर्मेटिंग पट्टी</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0203.html?DbPAR=CALC">ड्राइंग वस्तु गुण पट्टी</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0205.html?DbPAR=CALC">पाठ फॉर्मेटिंग पट्टी</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0206.html?DbPAR=CALC">सूत्र पट्टी</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0208.html?DbPAR=CALC">स्थिति पट्टी</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0210.html?DbPAR=CALC">पृष्ठ पूर्वावलोकन पट्टी</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0214.html?DbPAR=CALC">Image Bar</a></li>\
    <li><a target="_top" href="hi/text/scalc/main0218.html?DbPAR=CALC">औज़ार पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0201.html?DbPAR=CALC">मानक पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0212.html?DbPAR=CALC">सारणी डाटा पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0213.html?DbPAR=CALC">फ़ॉर्म नेविगेशन पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0214.html?DbPAR=CALC">क्वैरी डिज़ाइन पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0226.html?DbPAR=CALC">फ़ॉर्म डिज़ाइन औज़ारपट्टी</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Functions Types and Operators</label><ul>\
    <li><a target="_top" href="hi/text/scalc/01/04060000.html?DbPAR=CALC">फंक्शन विजार्ड</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060100.html?DbPAR=CALC">Functions by Category</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060107.html?DbPAR=CALC">Array Functions</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060120.html?DbPAR=CALC">Bit Operation Functions</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060101.html?DbPAR=CALC">डाटाबेस फंक्शन्स</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060102.html?DbPAR=CALC">Date & Time Functions</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060103.html?DbPAR=CALC">सांख्यिकीय फ़ंक्शन भाग तीन</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060119.html?DbPAR=CALC">सांख्यिकीय फ़ंक्शन भाग तीन</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060118.html?DbPAR=CALC">सांख्यिकीय फ़ंक्शन भाग तीन</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060104.html?DbPAR=CALC">Information Functions</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060105.html?DbPAR=CALC">Logical Functions</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060106.html?DbPAR=CALC">Mathematical Functions</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060108.html?DbPAR=CALC">Statistics Functions</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060181.html?DbPAR=CALC">सांख्यिकीय फ़ंक्शन भाग एक</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060182.html?DbPAR=CALC">सांख्यिकीय फ़ंक्शन भाग दो</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060183.html?DbPAR=CALC">सांख्यिकीय फ़ंक्शन भाग तीन</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060184.html?DbPAR=CALC">सांख्यिकीय फ़ंक्शन भाग चार</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060185.html?DbPAR=CALC">सांख्यिकीय फ़ंक्शन भाग पांच</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060109.html?DbPAR=CALC">Spreadsheet Functions</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060110.html?DbPAR=CALC">Text Functions</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060111.html?DbPAR=CALC">Add-in Functions</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060115.html?DbPAR=CALC">Add-in Functions, List of Analysis Functions Part One</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060116.html?DbPAR=CALC">Add-in Functions, List of Analysis Functions Part Two</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/04060199.html?DbPAR=CALC">Operators in LibreOffice Calc</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/userdefined_function.html?DbPAR=CALC">उपयोक्ता द्वारा पारिभाषित फ़ंक्शन</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/webquery.html?DbPAR=CALC">तालिका में बाहरी डाटा प्रविष्ट करना (वेब-क्वैरी)</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/html_doc.html?DbPAR=CALC">शीटों को एचटीएमएल में सहेजना व खोलना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/csv_formula.html?DbPAR=CALC">पाठ फ़ाइलें आयात तथा निर्यात करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">फ़ॉर्मेट किया जा रहा है</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/text_rotate.html?DbPAR=CALC">पाठ को घुमाना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/text_wrap.html?DbPAR=CALC">बहुपंक्ति पाठ लिखना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/text_numbers.html?DbPAR=CALC">संख्याओं को पाठ के रूप में फ़ॉर्मेट करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/super_subscript.html?DbPAR=CALC">पाठ सबस्क्रिप्ट / सुपरस्क्रिप्ट</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/row_height.html?DbPAR=CALC">पंक्ति ऊंचाई या स्तम्भ चौड़ाई बदलना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">शर्तयुक्त फ़ॉर्मेटिंग लागू करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">ऋणात्मक संख्याएँ उभारना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">सूत्र के द्वारा फ़ॉर्मेट निर्दिष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">लीडिंग शून्य के साथ संख्या प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/format_table.html?DbPAR=CALC">स्प्रेडशीट्स फ़ॉर्मेट करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/format_value.html?DbPAR=CALC">संख्या को दशमलव के साथ फ़ॉर्मेट करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/value_with_name.html?DbPAR=CALC">कक्षों को नाम देना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/table_rotate.html?DbPAR=CALC">तालिकाएँ घुमाना (ट्रांसपोज़ करना)</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/rename_table.html?DbPAR=CALC">शीटों के नाम बदलना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx वर्ष</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">राउण्डेड ऑफ संख्या इस्तेमाल करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/currency_format.html?DbPAR=CALC">करंसी फ़ॉर्मेट में कक्ष</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/autoformat.html?DbPAR=CALC">तालिका के लिए स्वतःफ़ॉर्मेट इस्तेमाल करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/note_insert.html?DbPAR=CALC">Inserting and Editing Comments</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/design.html?DbPAR=CALC">शीट के लिए प्रसंग चुनना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/fraction_enter.html?DbPAR=CALC">भिन्न प्रविष्ट करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtering and Sorting</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/filters.html?DbPAR=CALC">फिल्टर लगाना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/autofilter.html?DbPAR=CALC">ऑटो-फ़िल्टर लागू करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/sorted_list.html?DbPAR=CALC">छांटने की सूची लागू करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Printing</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/print_title_row.html?DbPAR=CALC">प्रत्येक पृष्ठ पर स्तम्भ या पंक्ति छापना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/print_landscape.html?DbPAR=CALC">शीटों को आड़े फ़ॉर्मेट में छापना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/print_details.html?DbPAR=CALC">शीट विवरण छापना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/print_exact.html?DbPAR=CALC">छपाई के लिए पृष्ठों की संख्या निर्धारित करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Data Ranges</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/database_define.html?DbPAR=CALC">डाटाबेस दायरा पारिभाषित करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtering Cell Ranges</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/database_sort.html?DbPAR=CALC">Sorting Data</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Pivot Table</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/datapilot.html?DbPAR=CALC">PivotTable</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">डाटा-पायलट तालिका बनाना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">डाटा-पायलट तालिका मिटाना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">डाटा-पायलट तालिका का संपादन करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">डाटा-पायलट तालिका को फ़िल्टर करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">डाटा-पायलट आउटपुट दायरा चुनना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">डाटा-पायलट तालिका अद्यतन करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivot Chart</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Scenarios</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/scenario.html?DbPAR=CALC">Using Scenarios</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotals</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">References</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">पता तथा संदर्भ, सापेक्ष तथा निरपेक्ष</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/cellreferences.html?DbPAR=CALC">कक्ष को अन्य दस्तावेज़ में संदर्भित करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">अन्य शीट का संदर्भ तथा संदर्भित करने वाला यूआरएल</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">खींचकर-व-छोड़कर कक्षों में संदर्भ देना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/address_auto.html?DbPAR=CALC">नाम को पता के रूप में पहचानना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Viewing, Selecting, Copying</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/table_view.html?DbPAR=CALC">तालिका दृश्य बदलना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/formula_value.html?DbPAR=CALC">मूल्य या सूत्र प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/line_fix.html?DbPAR=CALC">पंक्तियों और स्तंभों को शीर्षक के रुप में फ़्रीज करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/multi_tables.html?DbPAR=CALC">शीट टैब में नेविगेट करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/edit_multitables.html?DbPAR=CALC">बहुल शीट में नक़ल करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/cellcopy.html?DbPAR=CALC">सिर्फ दिखाई देने वाले कक्षों को नक़ल करें</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/mark_cells.html?DbPAR=CALC">बहुल कक्ष चुनना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formulas and Calculations</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/formulas.html?DbPAR=CALC">सूत्रों के साथ गणना करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/formula_copy.html?DbPAR=CALC">सूत्र नक़ल करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/formula_enter.html?DbPAR=CALC">Entering Formulas</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/formula_value.html?DbPAR=CALC">मूल्य या सूत्र प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/calculate.html?DbPAR=CALC">स्प्रेडशीट में गणनाएँ</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/calc_date.html?DbPAR=CALC">तिथियों तथा समय के द्वारा गणना करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/calc_series.html?DbPAR=CALC">श्रेणियाँ स्वचालित गणना करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">समय अंतर की गणना करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/matrixformula.html?DbPAR=CALC">माट्रिक्स सूत्र प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">सुरक्षा</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/cell_protect.html?DbPAR=CALC">कक्षों को परिवर्तनों से संरक्षित करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">कक्षों से सुरक्षा हटाना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Writing Calc Macros</label><ul>\
    <li><a target="_top" href="hi/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="hi/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatting Borders in Calc with Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">विविध</label><ul>\
    <li><a target="_top" href="hi/text/scalc/guide/auto_off.html?DbPAR=CALC">स्वचालित परिवर्तनों को अक्रिय करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/consolidate.html?DbPAR=CALC">डाटा एकत्र करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/goalseek.html?DbPAR=CALC">गोल सीक लागू करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/01/solver.html?DbPAR=CALC">Solver</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/multioperation.html?DbPAR=CALC">बहुल ऑपरेशन लागू करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/multitables.html?DbPAR=CALC">बहुत सारे शीट लागू करना</a></li>\
    <li><a target="_top" href="hi/text/scalc/guide/validity.html?DbPAR=CALC">कक्ष सामग्रियों की वैधता</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentations (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="hi/text/simpress/main0000.html?DbPAR=IMPRESS">Welcome to the LibreOffice Impress Help</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0503.html?DbPAR=IMPRESS">LibreOffice Impress Features</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Using Shortcut Keys in LibreOffice Impress</a></li>\
    <li><a target="_top" href="hi/text/simpress/04/01020000.html?DbPAR=IMPRESS">LibreOffice इम्प्रेस के लिए फंक्शन कुंजियाँ</a></li>\
    <li><a target="_top" href="hi/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Keyboard Shortcuts</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/main.html?DbPAR=IMPRESS">LibreOffice इम्प्रेस इस्तेमाल करने हेतु निर्देश</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">मेन्यू</label><ul>\
    <li><a target="_top" href="hi/text/simpress/main0100.html?DbPAR=IMPRESS">मेनू</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0101.html?DbPAR=IMPRESS">फ़ाइल</a></li>\
    <li><a target="_top" href="hi/text/simpress/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0103.html?DbPAR=IMPRESS">दृश्य</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0104.html?DbPAR=IMPRESS">प्रविष्ट</a></li>\
    <li><a target="_top" href="hi/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="hi/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0114.html?DbPAR=IMPRESS">स्लाइड शो</a></li>\
    <li><a target="_top" href="hi/text/simpress/main_tools.html?DbPAR=IMPRESS">Tools</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0107.html?DbPAR=IMPRESS">विंडो</a></li>\
    <li><a target="_top" href="hi/text/shared/main0108.html?DbPAR=IMPRESS">मदद</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">औज़ार पट्टियाँ</label><ul>\
    <li><a target="_top" href="hi/text/simpress/main0200.html?DbPAR=IMPRESS">औज़ार पट्टियाँ</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0210.html?DbPAR=IMPRESS">ड्राइंग पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0227.html?DbPAR=IMPRESS">बिंदु पट्टी संपादन</a></li>\
    <li><a target="_top" href="hi/text/shared/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="hi/text/shared/main0226.html?DbPAR=IMPRESS">फ़ॉर्म डिज़ाइन औज़ारपट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0213.html?DbPAR=IMPRESS">फ़ॉर्म नेविगेशन पट्टी</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0214.html?DbPAR=IMPRESS">Image Bar</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0202.html?DbPAR=IMPRESS">Line and Filling Bar</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0213.html?DbPAR=IMPRESS">विकल्प पट्टी</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0211.html?DbPAR=IMPRESS">रुपरेखा पट्टी</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0209.html?DbPAR=IMPRESS">मापक</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0212.html?DbPAR=IMPRESS">स्लाइड छंटाई पट्टी</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0204.html?DbPAR=IMPRESS">स्लाइड दृश्य पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0201.html?DbPAR=IMPRESS">मानक पट्टी</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0206.html?DbPAR=IMPRESS">स्थिति पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0204.html?DbPAR=IMPRESS">तालिका पट्टी</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0203.html?DbPAR=IMPRESS">पाठ फॉर्मेटिंग पट्टी</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="hi/text/simpress/guide/html_export.html?DbPAR=IMPRESS">एचटीएमएल फ़ॉर्मेट में प्रेज़ेन्टेशन सहेजना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/html_import.html?DbPAR=IMPRESS">एचटीएमएल पृष्ठों को प्रेज़ेन्टेशन में आयात करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">एनीमेशन को जीआईएफ़ फ़ॉर्मेट में निर्यात करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">स्लाइडों में स्प्रेडशीट शामिल करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">छवियाँ प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">फ़ॉर्मेट किया जा रहा है</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">लाइन तथा तीर शैलियाँ लोड करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">मनपसंद रंग निर्धारित करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">ग्रेडिएंट फिल तैयार करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">रंग बदलना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">वस्तुओं को जमानना, पंक्तिबद्ध करना तथा वितरित करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/background.html?DbPAR=IMPRESS">स्लाइड पृष्ठभूमि भराव बदलना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/footer.html?DbPAR=IMPRESS">सभी स्लाइडों में शीर्ष-टिप्पणी या पाद-टिप्पणी डालना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/move_object.html?DbPAR=IMPRESS">वस्तुओं को खिसकाना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Printing</label><ul>\
    <li><a target="_top" href="hi/text/simpress/guide/printing.html?DbPAR=IMPRESS">प्रेज़ेन्टेशन की छपाई</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">कागज के आकार में फ़िट होने लायक स्लाइड छापना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">प्रभाव</label><ul>\
    <li><a target="_top" href="hi/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">एनीमेशन को जीआईएफ़ फ़ॉर्मेट में निर्यात करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">वस्तुओं को प्रेज़ेन्टेशन स्लाइडों में एनीमेट करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">स्लाइड ट्रांजीशन एनीमेट करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">दो वस्तुओं को क्रास-फेड करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">एनीमेटेड जीआईएफ़ छवियाँ बनाना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objects, Graphics, and Bitmaps</label><ul>\
    <li><a target="_top" href="hi/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">वस्तुओं को जोड़ना तथा आकार बनाना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/groups.html?DbPAR=IMPRESS">वस्तुओं को समूह में रखना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">खण्ड तथा भाग ड्रा करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">वस्तु की अनुकृति बनाना</a></li>\
    <li><a target="_top" href="hi/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformations</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">वस्तु घुमाना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">त्रिआयामी वस्तुएँ तैयार करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">लाइनें जोड़ना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">पाठ अक्षरों को ड्राइंग वस्तुओं में बदलना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">बिटमैप चित्रों को वेक्टर ग्राफ़िक्स में बदलना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">2डी वस्तुओं को वक्र, बहुभुज तथा 3डी वस्तुओं में बदलना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">लाइन तथा तीर शैलियाँ लोड करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">वक्र ड्रा करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">वक्र संपादन</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">छवियाँ प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">स्लाइडों में स्प्रेडशीट शामिल करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/move_object.html?DbPAR=IMPRESS">वस्तुओं को खिसकाना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/select_object.html?DbPAR=IMPRESS">अंडरलाइंग वस्तुएँ चुनना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">फ्लोचार्ट बनाना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text in Presentations</label><ul>\
    <li><a target="_top" href="hi/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">पाठ जोड़ना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">पाठ अक्षरों को ड्राइंग वस्तुओं में बदलना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Viewing</label><ul>\
    <li><a target="_top" href="hi/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">स्लाइड अनुक्रम बदलना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">कुंजीपट के साथ ज़ूम करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Slide Shows</label><ul>\
    <li><a target="_top" href="hi/text/simpress/guide/show.html?DbPAR=IMPRESS">स्लाइड शो के दौरान</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/individual.html?DbPAR=IMPRESS">मनपसंद स्लाइड शो बनाना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">स्लाइड परिवर्तन का रीहर्स टाइमिंग</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Drawings (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="hi/text/sdraw/main0000.html?DbPAR=DRAW">LibreOffice ड्रा मदद में आपका स्वागत है</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main0503.html?DbPAR=DRAW">LibreOffice Draw Features</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/keyboard.html?DbPAR=DRAW">ड्राइंग वस्तुओं के लिए शॉर्टकट कुंजियाँ</a></li>\
    <li><a target="_top" href="hi/text/sdraw/04/01020000.html?DbPAR=DRAW">Shortcut Keys for Drawings</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/main.html?DbPAR=DRAW">LibreOffice ड्रा इस्तेमाल करने हेतु निर्देश</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menus</label><ul>\
    <li><a target="_top" href="hi/text/sdraw/main0100.html?DbPAR=DRAW">मेनू</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main0101.html?DbPAR=DRAW">फ़ाइल</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main0103.html?DbPAR=DRAW">View (menu in Draw)</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main_insert.html?DbPAR=DRAW">Insert</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main_tools.html?DbPAR=DRAW">Tools</a></li>\
    <li><a target="_top" href="hi/text/simpress/main0107.html?DbPAR=DRAW">विंडो</a></li>\
    <li><a target="_top" href="hi/text/shared/main0108.html?DbPAR=DRAW">मदद</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Toolbars</label><ul>\
    <li><a target="_top" href="hi/text/sdraw/main0200.html?DbPAR=DRAW">औज़ार पट्टियाँ</a></li>\
    <li><a target="_top" href="hi/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D-Settings</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main0210.html?DbPAR=DRAW">ड्राइंग पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0227.html?DbPAR=DRAW">बिंदु पट्टी संपादन</a></li>\
    <li><a target="_top" href="hi/text/shared/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="hi/text/shared/main0226.html?DbPAR=DRAW">फ़ॉर्म डिज़ाइन औज़ारपट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0213.html?DbPAR=DRAW">फ़ॉर्म नेविगेशन पट्टी</a></li>\
    <li><a target="_top" href="hi/text/sdraw/main0213.html?DbPAR=DRAW">विकल्प पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0201.html?DbPAR=DRAW">मानक पट्टी</a></li>\
    <li><a target="_top" href="hi/text/shared/main0204.html?DbPAR=DRAW">तालिका पट्टी</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Loading, Saving, Importing, and Exporting</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">छवियाँ प्रविष्ट करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatting</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">लाइन तथा तीर शैलियाँ लोड करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/color_define.html?DbPAR=DRAW">मनपसंद रंग निर्धारित करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/gradient.html?DbPAR=DRAW">ग्रेडिएंट फिल तैयार करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">रंग बदलना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">वस्तुओं को जमानना, पंक्तिबद्ध करना तथा वितरित करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/background.html?DbPAR=DRAW">स्लाइड पृष्ठभूमि भराव बदलना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/move_object.html?DbPAR=DRAW">वस्तुओं को खिसकाना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Printing</label><ul>\
    <li><a target="_top" href="hi/text/simpress/guide/printing.html?DbPAR=DRAW">प्रेज़ेन्टेशन की छपाई</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/print_tofit.html?DbPAR=DRAW">कागज के आकार में फ़िट होने लायक स्लाइड छापना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effects</label><ul>\
    <li><a target="_top" href="hi/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">दो वस्तुओं को क्रास-फेड करना</a></li>\
    <li><a target="_top" href="hi/text/shared/01/05350000.html?DbPAR=DRAW">3डी प्रभाव</a></li>\
    <li><a target="_top" href="hi/text/simpress/02/10030000.html?DbPAR=DRAW">Transformations</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objects, Graphics, and Bitmaps</label><ul>\
    <li><a target="_top" href="hi/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">वस्तुओं को जोड़ना तथा आकार बनाना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">खण्ड तथा भाग ड्रा करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">वस्तु की अनुकृति बनाना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">वस्तु घुमाना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">त्रिआयामी वस्तुएँ तैयार करना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/join_objects.html?DbPAR=DRAW">लाइनें जोड़ना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/text2curve.html?DbPAR=DRAW">पाठ अक्षरों को ड्राइंग वस्तुओं में बदलना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/vectorize.html?DbPAR=DRAW">बिटमैप चित्रों को वेक्टर ग्राफ़िक्स में बदलना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/3d_create.html?DbPAR=DRAW">2डी वस्तुओं को वक्र, बहुभुज तथा 3डी वस्तुओं में बदलना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">लाइन तथा तीर शैलियाँ लोड करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/line_draw.html?DbPAR=DRAW">वक्र ड्रा करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/line_edit.html?DbPAR=DRAW">वक्र संपादन</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">छवियाँ प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/table_insert.html?DbPAR=DRAW">स्लाइडों में स्प्रेडशीट शामिल करना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/move_object.html?DbPAR=DRAW">वस्तुओं को खिसकाना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/select_object.html?DbPAR=DRAW">अंडरलाइंग वस्तुएँ चुनना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/orgchart.html?DbPAR=DRAW">फ्लोचार्ट बनाना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Groups and Layers</label><ul>\
    <li><a target="_top" href="hi/text/sdraw/guide/groups.html?DbPAR=DRAW">वस्तुओं को समूह में रखना</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserting Layers</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="hi/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text in Drawings</label><ul>\
    <li><a target="_top" href="hi/text/sdraw/guide/text_enter.html?DbPAR=DRAW">पाठ जोड़ना</a></li>\
    <li><a target="_top" href="hi/text/simpress/guide/text2curve.html?DbPAR=DRAW">पाठ अक्षरों को ड्राइंग वस्तुओं में बदलना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Viewing</label><ul>\
    <li><a target="_top" href="hi/text/simpress/guide/change_scale.html?DbPAR=DRAW">कुंजीपट के साथ ज़ूम करना</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Database Functionality (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">General Information</label><ul>\
    <li><a target="_top" href="hi/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/database_main.html?DbPAR=BASE">डाटाबेस ओवरव्यू</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_new.html?DbPAR=BASE">नया डाटाबेस तैयार करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_tables.html?DbPAR=BASE">तालिकाओँ के साथ कार्य करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_queries.html?DbPAR=BASE">क्वैरीज़ के साथ कार्य करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_forms.html?DbPAR=BASE">फ़ॉर्म्स के साथ कार्य करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_reports.html?DbPAR=BASE">Creating Reports</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_register.html?DbPAR=BASE">डाटाबेस पंजीकरण करना तथा मिटाना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_im_export.html?DbPAR=BASE">पाठ फ़ॉर्मेट में डाटा आयात तथा निर्यात करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_enter_sql.html?DbPAR=BASE">एसक्यूएल कमांड्स चलाना</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formulas (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="hi/text/smath/main0000.html?DbPAR=MATH">Welcome to the LibreOffice Math Help</a></li>\
    <li><a target="_top" href="hi/text/smath/main0503.html?DbPAR=MATH">LibreOffice Math Features</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formula Elements</label><ul>\
    <li><a target="_top" href="hi/text/smath/01/03090100.html?DbPAR=MATH">यूनेरी/बाइनरी ऑपरेटर्स</a></li>\
    <li><a target="_top" href="hi/text/smath/01/03090200.html?DbPAR=MATH">सम्बन्ध:</a></li>\
    <li><a target="_top" href="hi/text/smath/01/03090800.html?DbPAR=MATH">ऑपरेशन्स सेट करें</a></li>\
    <li><a target="_top" href="hi/text/smath/01/03090400.html?DbPAR=MATH">भिन्न</a></li>\
    <li><a target="_top" href="hi/text/smath/01/03090300.html?DbPAR=MATH">ऑपरेटर</a></li>\
    <li><a target="_top" href="hi/text/smath/01/03090600.html?DbPAR=MATH">गुण</a></li>\
    <li><a target="_top" href="hi/text/smath/01/03090500.html?DbPAR=MATH">कोष्ठक</a></li>\
    <li><a target="_top" href="hi/text/smath/01/03090700.html?DbPAR=MATH">फ़ॉर्मेट</a></li>\
    <li><a target="_top" href="hi/text/smath/01/03091600.html?DbPAR=MATH">अन्य प्रतीक</a></li>\
      </ul></li>\
    <li><a target="_top" href="hi/text/smath/guide/main.html?DbPAR=MATH">LibreOffice मैथ इस्तेमाल करने हेतु निर्देश</a></li>\
    <li><a target="_top" href="hi/text/smath/guide/keyboard.html?DbPAR=MATH">शॉर्टकट (LibreOffice मैथ पहुँच)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Command and Menu Reference</label><ul>\
    <li><a target="_top" href="hi/text/smath/main0100.html?DbPAR=MATH">मेनू</a></li>\
    <li><a target="_top" href="hi/text/smath/main0200.html?DbPAR=MATH">औज़ार पट्टियाँ</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Working with Formulas</label><ul>\
    <li><a target="_top" href="hi/text/smath/guide/align.html?DbPAR=MATH">सूत्र भागों को हस्तचालित क्रमबद्ध करना</a></li>\
    <li><a target="_top" href="hi/text/smath/guide/color.html?DbPAR=MATH">Applying Color to Formula Parts</a></li>\
    <li><a target="_top" href="hi/text/smath/guide/attributes.html?DbPAR=MATH">डिफ़ॉल्ट गुणों को बदलना</a></li>\
    <li><a target="_top" href="hi/text/smath/guide/brackets.html?DbPAR=MATH">सूत्र भागों को कोष्ठकों में मिलाना</a></li>\
    <li><a target="_top" href="hi/text/smath/guide/comment.html?DbPAR=MATH">टिप्पणियाँ प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/smath/guide/newline.html?DbPAR=MATH">लाइन ब्रेक प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/smath/guide/parentheses.html?DbPAR=MATH">कोष्ठक प्रविष्ट करना</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Charts and Diagrams</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">General Information</label><ul>\
    <li><a target="_top" href="hi/text/schart/main0000.html?DbPAR=CHART">LibreOffice में चार्ट</a></li>\
    <li><a target="_top" href="hi/text/schart/main0503.html?DbPAR=CHART">LibreOffice Chart Features</a></li>\
    <li><a target="_top" href="hi/text/schart/04/01020000.html?DbPAR=CHART">चार्ट के लिए शॉर्टकट</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Macros and Scripting</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="hi/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice बेसिक आईडीई</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01000000.html?DbPAR=BASIC">LibreOffice बेसिक के साथ प्रोग्रामिंग</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basic Glossary</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01010210.html?DbPAR=BASIC">बेसिक्स</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01020000.html?DbPAR=BASIC">Syntax</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice बेसिक आईडीई</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01030100.html?DbPAR=BASIC">आईडीई समग्रदृश्य</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01030200.html?DbPAR=BASIC">बेसिक संपादक</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01050100.html?DbPAR=BASIC">विंडो देखें</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/main0211.html?DbPAR=BASIC">मॅक्रो औज़ार पट्टी</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/05060700.html?DbPAR=BASIC">मॅक्रो</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Command Reference</label><ul>\
    <li><a target="_top" href="hi/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01020500.html?DbPAR=BASIC">लाइब्रेरी, मॉड्यूल तथा संवाद</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Functions, Statements and Operators</label><ul>\
    <li><a target="_top" href="hi/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100000.html?DbPAR=BASIC">चर</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03060000.html?DbPAR=BASIC">लॉजिकल ऑपरेटर्स</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120000.html?DbPAR=BASIC">वाक्यांश</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030000.html?DbPAR=BASIC">तारीख़ तथा समय फंक्शन</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03070000.html?DbPAR=BASIC">Mathematical Operators</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080000.html?DbPAR=BASIC">न्यूमेरिक फंक्शन्स</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080100.html?DbPAR=BASIC">त्रिकोणमितीय फंक्शन्स</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010000.html?DbPAR=BASIC">स्क्रीन I/O फंक्शन</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020000.html?DbPAR=BASIC">File I/O Functions</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090000.html?DbPAR=BASIC">प्रोग्राम चलाना नियंत्रित करना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03050000.html?DbPAR=BASIC">Error-Handling Functions</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03130000.html?DbPAR=BASIC">अन्य कमांड</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080300.html?DbPAR=BASIC">रेण्डम संख्याएँ तैयार करना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090400.html?DbPAR=BASIC">Further Statements</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alphabetic List of Functions, Statements and Operators</label><ul>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03050000.html?DbPAR=BASIC">Error-Handling Functions</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080000.html?DbPAR=BASIC">न्यूमेरिक फंक्शन्स</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080400.html?DbPAR=BASIC">वर्ग मूल की गणना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write Statement</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03120300.html?DbPAR=BASIC">स्ट्रिंग सामग्री संपादन</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01020100.html?DbPAR=BASIC">वेरिएबल्स इस्तेमाल करना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Advanced Basic Libraries</label><ul>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard Library</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Library</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForge Library</label><ul>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge Libraries</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guides</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/macro_recording.html?DbPAR=BASIC">मेक्रो रेकॉर्ड करना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/guide/control_properties.html?DbPAR=BASIC">संवाद संपादक में नियंत्रक के गुणों को बदलना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/guide/insert_control.html?DbPAR=BASIC">संवाद संपादक में नियंत्रक तैयार करना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/guide/sample_code.html?DbPAR=BASIC">संवाद संपादक में नियंत्रक के लिए प्रोग्रामिंग उदाहरण</a></li>\
    <li><a target="_top" href="hi/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="hi/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">बेसिक संवाद तैयार करना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01030400.html?DbPAR=BASIC">लाइब्रेरी तथा मॉड्यूल व्यवस्थित करना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01020100.html?DbPAR=BASIC">वेरिएबल्स इस्तेमाल करना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01020200.html?DbPAR=BASIC">Using Objects</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01030300.html?DbPAR=BASIC">बेसिक प्रोग्राम डिबग करना</a></li>\
    <li><a target="_top" href="hi/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="hi/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="hi/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic to Python</a></li>\
    <li><a target="_top" href="hi/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python Scripts Help</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="hi/text/sbasic/python/main0000.html?DbPAR=BASIC">Python Scripts</a></li>\
    <li><a target="_top" href="hi/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE for Python</a></li>\
    <li><a target="_top" href="hi/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="hi/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programming with Python</label><ul>\
    <li><a target="_top" href="hi/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="hi/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python examples</a></li>\
    <li><a target="_top" href="hi/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Script Development Tools</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice Installation</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">माइक्रोसॉफ़्ट ऑफ़िस दस्तावेज़ क़िस्मों की संबद्धता को बदलना</a></li>\
    <li><a target="_top" href="hi/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Safe Mode</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Common Help Topics</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">General Information</label><ul>\
    <li><a target="_top" href="hi/text/shared/main0400.html?DbPAR=SHARED">शॉर्टकट कुंजियाँ</a></li>\
    <li><a target="_top" href="hi/text/shared/00/00000005.html?DbPAR=SHARED">सामान्य शब्द संग्रह</a></li>\
    <li><a target="_top" href="hi/text/shared/00/00000002.html?DbPAR=SHARED">इंटरनेट से संबंधित शब्दकोश</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/accessibility.html?DbPAR=SHARED">LibreOffice में एक्सेसिबिलिटी</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/keyboard.html?DbPAR=SHARED">शॉर्टकट (LibreOffice एक्सेसिबिलिटी)</a></li>\
    <li><a target="_top" href="hi/text/shared/04/01010000.html?DbPAR=SHARED">LibreOffice में सामान्य शॉर्टकट कुंजियाँ</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/version_number.html?DbPAR=SHARED">संस्करण व बिल्ड क्रमांक</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice and Microsoft Office</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/ms_user.html?DbPAR=SHARED">माइक्रोसॉफ़्ट ऑफ़िस तथा LibreOffice इस्तेमाल करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">माइक्रोसॉफ़्ट ऑफ़िस तथा LibreOffice के शब्द/वाक्यांशों में तुलना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">माइक्रोसॉफ़्ट ऑफ़िस दस्तावेज़ परिवर्तन के बारे में</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">माइक्रोसॉफ़्ट ऑफ़िस दस्तावेज़ क़िस्मों की संबद्धता को बदलना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice Options</label><ul>\
    <li><a target="_top" href="hi/text/shared/optionen/01000000.html?DbPAR=SHARED">विकल्प</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01010100.html?DbPAR=SHARED">उपयोक्ता डाटा</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01010200.html?DbPAR=SHARED">सामान्य</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01010800.html?DbPAR=SHARED">दृश्य</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01010900.html?DbPAR=SHARED">छपाई विकल्प</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01010300.html?DbPAR=SHARED">पथ</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01010700.html?DbPAR=SHARED">फ़ॉन्ट</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01030300.html?DbPAR=SHARED">सुरक्षा</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01012000.html?DbPAR=SHARED">Application Colors</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01013000.html?DbPAR=SHARED">पहुँच</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/java.html?DbPAR=SHARED">Advanced</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01010400.html?DbPAR=SHARED">लेखन सहायक</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01010600.html?DbPAR=SHARED">सामान्य</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01020000.html?DbPAR=SHARED">Load/Save options</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01030000.html?DbPAR=SHARED">Internet options</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01040000.html?DbPAR=SHARED">पाठ दस्तावेज़ विकल्प</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01050000.html?DbPAR=SHARED">एचटीएमएल दस्तावेज़ विकल्प</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01060000.html?DbPAR=SHARED">स्प्रेडशीट विकल्प</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01070000.html?DbPAR=SHARED">प्रेज़ेन्टेशन विकल्प</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01080000.html?DbPAR=SHARED">ड्राइंग विकल्प</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01090000.html?DbPAR=SHARED">सूत्र</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01110000.html?DbPAR=SHARED">Chart options</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01130100.html?DbPAR=SHARED">वीबीए गुण</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01130200.html?DbPAR=SHARED">माइक्रोसॉफ्ट ऑफिस</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01150000.html?DbPAR=SHARED">Language Setting Options</a></li>\
    <li><a target="_top" href="hi/text/shared/optionen/01160000.html?DbPAR=SHARED">Data sources options</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Wizards</label><ul>\
    <li><a target="_top" href="hi/text/shared/autopi/01000000.html?DbPAR=SHARED">विज़ॉर्ड</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Letter Wizard</label><ul>\
    <li><a target="_top" href="hi/text/shared/autopi/01010000.html?DbPAR=SHARED">Letter Wizard</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Fax Wizard</label><ul>\
    <li><a target="_top" href="hi/text/shared/autopi/01020000.html?DbPAR=SHARED">Fax Wizard</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Agenda Wizard</label><ul>\
    <li><a target="_top" href="hi/text/shared/autopi/01040000.html?DbPAR=SHARED">Agenda Wizard</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML Export Wizard</label><ul>\
    <li><a target="_top" href="hi/text/shared/autopi/01110000.html?DbPAR=SHARED">HTML Export</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Document Converter Wizard</label><ul>\
    <li><a target="_top" href="hi/text/shared/autopi/01130000.html?DbPAR=SHARED">Document Converter</a></li>\
      </ul></li>\
    <li><a target="_top" href="hi/text/shared/autopi/01150000.html?DbPAR=SHARED">Euro Converter Wizard</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configuring LibreOffice</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/configure_overview.html?DbPAR=SHARED">LibreOffice को कॉन्फ़िगर करना</a></li>\
    <li><a target="_top" href="hi/text/shared/01/packagemanager.html?DbPAR=SHARED">Extension Manager</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/flat_icons.html?DbPAR=SHARED">प्रतीक दृश्य बदलना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Adding Buttons to Toolbars</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/workfolder.html?DbPAR=SHARED">Changing Your Working Directory</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_addressbook.html?DbPAR=SHARED">पता किताब पंजीकृत करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/formfields.html?DbPAR=SHARED">बटन प्रविष्ट करना या संपादित करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Working with the User Interface</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">किसी वस्तु पर तत्काल पहुँचने के लिए नेविगेशन</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/navigator.html?DbPAR=SHARED">दस्तावेज़ के समग्रदृश्य हेतु नेविगेटर</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/autohide.html?DbPAR=SHARED">विंडो को दिखाना, डॉक करना तथा छुपाना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/textmode_change.html?DbPAR=SHARED">प्रविष्ट तथा मिटाकर मोड के बीच स्विच करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">औज़ार पट्टियाँ इस्तेमाल करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digital Signatures</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/digital_signatures.html?DbPAR=SHARED">About Digital Signatures</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Applying Digital Signatures</a></li>\
    <li><a target="_top" href="hi/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="hi/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="hi/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="hi/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="hi/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Printing, Faxing, Sending</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/labels_database.html?DbPAR=SHARED">पता लेबल छापना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">काला और सफेद में छापना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/fax.html?DbPAR=SHARED">फ़ैक्स भेजना तथा LibreOffice को फ़ैक्स के लिए कॉन्फ़िगर करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Drag & Drop</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/dragdrop.html?DbPAR=SHARED">LibreOffice दस्तावेज़ के भीतर खींचकर छोड़ना</a></li>\
    <li><a target="_top" href="hi/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">दस्तावेज़ों में पाठ खिसकाना व नक़ल करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">स्प्रेडशीट क्षेत्रों को पाठ दस्तावेज़ में नक़ल करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">दस्तावेज़ों में चित्र नक़ल करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">गैलरी से चित्र नक़ल करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">डाटा स्रोत दृश्य के जरिए खींच कर छोड़ना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copy and Paste</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">अन्य दस्तावेज़ों में ड्राइंग वस्तु नक़ल करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">दस्तावेज़ों में चित्र नक़ल करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">गैलरी से चित्र नक़ल करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">स्प्रेडशीट क्षेत्रों को पाठ दस्तावेज़ में नक़ल करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Charts and Diagrams</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/chart_insert.html?DbPAR=SHARED">चार्ट प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/schart/main0000.html?DbPAR=SHARED">LibreOffice में चार्ट</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Load, Save, Import, Export, PDF</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/doc_open.html?DbPAR=SHARED">दस्तावेज़ खोलना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/import_ms.html?DbPAR=SHARED">अन्य फ़ॉर्मेट में सहेजे गए दस्तावेज़ों को खोलना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/doc_save.html?DbPAR=SHARED">दस्तावेज़ों को सहेजना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/doc_autosave.html?DbPAR=SHARED">दस्तावेज़ों को स्वचालित सहेजना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/export_ms.html?DbPAR=SHARED">अन्य फ़ॉर्मेट में दस्तावेज़ों को सहेजना</a></li>\
    <li><a target="_top" href="hi/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">पीडीएफ में निर्यात करें</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">पाठ फ़ॉर्मेट में डाटा आयात तथा निर्यात करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Links and References</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">हायपरलिंक्स प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">सापेक्ष तथा निरपेक्ष कड़ियाँ</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">हायपरलिंक्स संपादित करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Document Version Tracking</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">दस्तावेज़ के संस्करणों की तुलना करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">संस्करण मिलाना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/redlining_enter.html?DbPAR=SHARED">परिवर्तन रेकॉर्ड करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/redlining.html?DbPAR=SHARED">परिवर्तनों को रेकॉर्ड करना या प्रदर्शित करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/redlining_accept.html?DbPAR=SHARED">परिवर्तनों को स्वीकारना या नकारना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/redlining_versions.html?DbPAR=SHARED">संस्करण प्रबन्धन</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Labels and Business Cards</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/labels.html?DbPAR=SHARED">लेबल तथा व्यापारिक कार्ड बनाना तथा छापना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Inserting External Data</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/copytable2application.html?DbPAR=SHARED">स्प्रेडशीट से डेटा प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/copytext2application.html?DbPAR=SHARED">पाठ दस्तावेज़ से डाटा प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">बिटमैप प्रविष्ट करना, संपादित करना या सहेजना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">गैलरी में चित्र जोड़ना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automatic Functions</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/autocorr_url.html?DbPAR=SHARED">स्वचालित यूआरएल पहचानना बन्द करना</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Searching and Replacing</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/data_search2.html?DbPAR=SHARED">फ़ॉर्म फ़िल्टर के साथ ढूंढना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_search.html?DbPAR=SHARED">फ़ॉर्म दस्तावेज़ तथा तालिका ढूंढना</a></li>\
    <li><a target="_top" href="hi/text/shared/01/02100001.html?DbPAR=SHARED">नियमित एक्सप्रेशन की सूची</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guides</label><ul>\
    <li><a target="_top" href="hi/text/shared/guide/linestyles.html?DbPAR=SHARED">लाइन शैलियाँ लागू करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/text_color.html?DbPAR=SHARED">पाठ का रंग बदलना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/change_title.html?DbPAR=SHARED">दस्तावेज का शीर्षक बदलना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/round_corner.html?DbPAR=SHARED">गोल किनारे बनाना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/background.html?DbPAR=SHARED">पृष्ठभूमि रंग तथा पृष्ठभूमि चित्र निर्धारित करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/linestyle_define.html?DbPAR=SHARED">लाइन शैलियाँ पारिभाषित करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Editing Graphic Objects</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/line_intext.html?DbPAR=SHARED">पाठ में लाइन ड्रा करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/aaa_start.html?DbPAR=SHARED">प्रथम चरण</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/gallery_insert.html?DbPAR=SHARED">गैलरी से वस्तुएँ प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">विशिष्ट अक्षर प्रविष्ट करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/tabs.html?DbPAR=SHARED">टैब रोक प्रविष्ट करना या संपादित करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Using Remote Files</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/protection.html?DbPAR=SHARED">Protecting Content in LibreOffice</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/redlining_protect.html?DbPAR=SHARED">रेकॉर्ड सुरक्षित करना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/pageformat_max.html?DbPAR=SHARED">पृष्ठ पर छापने योग्य अधिकतम क्षेत्र चुनना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/measurement_units.html?DbPAR=SHARED">मापक इकाई चुनना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/language_select.html?DbPAR=SHARED">दस्तावेज़ की भाषा चुनना</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">तालिका डिज़ाइन</a></li>\
    <li><a target="_top" href="hi/text/shared/guide/numbering_stop.html?DbPAR=SHARED">व्यक्तिगत अनुच्छेद के लिए बुलेट तथा क्रमांकन बन्द करना</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
