document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Dokumenty tekstowe (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Informacje ogólne i korzystanie z interfejsu użytkownika</label><ul>\
    <li><a target="_top" href="pl/text/swriter/main0000.html?DbPAR=WRITER">Witaj w systemie pomocy programu LibreOffice Writer</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0503.html?DbPAR=WRITER">Właściwości programu LibreOffice Writer</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/main.html?DbPAR=WRITER">Instrukcje dotyczące używania LibreOffice Writer</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Dokowanie i zmiana rozmiaru okien</a></li>\
    <li><a target="_top" href="pl/text/swriter/04/01020000.html?DbPAR=WRITER">Skróty klawiaturowe w LibreOffice Writer</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/words_count.html?DbPAR=WRITER">Liczenie słów</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/keyboard.html?DbPAR=WRITER">Korzystanie ze skrótów klawiaturowych (dostępność w LibreOffice Writer)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Lista poleceń i menu</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menu</label><ul>\
    <li><a target="_top" href="pl/text/swriter/main0100.html?DbPAR=WRITER">Menu</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0101.html?DbPAR=WRITER">Plik</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0102.html?DbPAR=WRITER">Edycja</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0103.html?DbPAR=WRITER">Widok</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0104.html?DbPAR=WRITER">Wstaw</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0105.html?DbPAR=WRITER">Format</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0115.html?DbPAR=WRITER">Style (menu)</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0110.html?DbPAR=WRITER">Tabela</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0120.html?DbPAR=WRITER">Menu Formularz</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0106.html?DbPAR=WRITER">Narzędzia</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0107.html?DbPAR=WRITER">Okno</a></li>\
    <li><a target="_top" href="pl/text/shared/main0108.html?DbPAR=WRITER">Pomoc</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Paski narzędzi</label><ul>\
    <li><a target="_top" href="pl/text/swriter/main0200.html?DbPAR=WRITER">Paski narzędzi</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0206.html?DbPAR=WRITER">Pasek wypunktowania i numeracji</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0205.html?DbPAR=WRITER">Pasek właściwości obiektów rysunkowych</a></li>\
    <li><a target="_top" href="pl/text/shared/find_toolbar.html?DbPAR=WRITER">Pasek wyszukiwania</a></li>\
    <li><a target="_top" href="pl/text/shared/main0226.html?DbPAR=WRITER">Pasek projektu formularza</a></li>\
    <li><a target="_top" href="pl/text/shared/main0213.html?DbPAR=WRITER">Pasek nawigacji formularza</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0202.html?DbPAR=WRITER">Pasek formatowania</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0214.html?DbPAR=WRITER">Pasek formuły</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0215.html?DbPAR=WRITER">Pasek ramki</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0203.html?DbPAR=WRITER">Pasek obrazu</a></li>\
    <li><a target="_top" href="pl/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Pasek narzędzi LibreLogo</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0216.html?DbPAR=WRITER">Pasek obiektu OLE</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0210.html?DbPAR=WRITER">Pasek podglądu wydruku (Writer)</a></li>\
    <li><a target="_top" href="pl/text/shared/main0214.html?DbPAR=WRITER">Pasek projektu kwerendy</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0213.html?DbPAR=WRITER">Linijki</a></li>\
    <li><a target="_top" href="pl/text/shared/main0201.html?DbPAR=WRITER">Pasek standardowy</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0208.html?DbPAR=WRITER">Pasek stanu (Writer)</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0204.html?DbPAR=WRITER">Pasek tabeli</a></li>\
    <li><a target="_top" href="pl/text/shared/main0212.html?DbPAR=WRITER">Pasek Dane tabeli</a></li>\
    <li><a target="_top" href="pl/text/swriter/main0220.html?DbPAR=WRITER">Pasek obiektów tekstowych</a></li>\
    <li><a target="_top" href="pl/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Pasek narzędzi śledzenia zmian</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Poruszanie się po dokumentach tekstowych</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Poruszanie się i zaznaczanie przy pomocy klawiatury</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Przenoszenie i kopiowanie tekstu w dokumentach</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Zmiana układu dokumentu poprzez Nawigatora</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Wstawianie hiperłączy za pomocą Nawigatora</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/navigator.html?DbPAR=WRITER">Nawigator dokumentów tekstowych</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Korzystanie z kursora bezpośredniego</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatowanie dokumentów tekstowych</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Zmiana orientacji strony</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/text_capital.html?DbPAR=WRITER">Zmiana wielkości liter</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Ukrywanie tekstu</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definiowanie innych główek i stopek</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Wstawianie nazwy i numeru rozdziału w główce lub stopce</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Formatowanie tekstu podczas pisania</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/reset_format.html?DbPAR=WRITER">Przywracanie atrybutów znaków</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Ustawianie stylów przy pomocy wypełniania formatem</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/wrap.html?DbPAR=WRITER">Opływanie obiektów przez tekst</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Korzystanie z ramek do wyrównania tekstu do środka strony</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Wyróżnienie tekstu</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Obracanie tekstu</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/page_break.html?DbPAR=WRITER">Wstawianie i usuwanie podziałów strony</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Tworzenie i stosowanie stylów strony</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/subscript.html?DbPAR=WRITER">Indeksy górne i dolne</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Szablony i style</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Szablony i style</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Zmienne style stron parzystych i nieparzystych</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/change_header.html?DbPAR=WRITER">Tworzenie stylu strony w oparciu o bieżącą stronę</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/load_styles.html?DbPAR=WRITER">Korzystanie ze stylów z innego dokumentu lub z szablonu</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Dodawanie nowych stylów przy użyciu zaznaczenia</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Aktualizacja stylów przy użyciu zaznaczenia</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/standard_template.html?DbPAR=WRITER">Tworzenie i zmiana szablonów domyślnych i niestandardowych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/template_manager.html?DbPAR=WRITER">Menedżer szablonów</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Grafika w dokumentach tekstowych</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Wstawianie grafiki</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Wstawianie grafiki z pliku</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Wstawianie grafiki z galerii metodą "przeciągnij i upuść"</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Wstawianie zeskanowanego obrazu</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Wstawianie wykresu programu Calc do dokumentu tekstowego</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Wstawianie grafiki z LibreOffice Draw lub Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabele w dokumentach tekstowych</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Włączanie i wyłączanie rozpoznawania liczb w tabelach</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/tablemode.html?DbPAR=WRITER">Modyfikacja wierszy i kolumn za pomocą klawiatury</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/table_delete.html?DbPAR=WRITER">Usuwanie tabeli lub zawartości tabeli</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/table_insert.html?DbPAR=WRITER">Wstawianie tabel</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Powtarzanie nagłówka tabeli na nowej stronie</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Zmiana rozmiaru wierszy i kolumn w tabeli</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Obiekty w dokumentach tekstowych</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Pozycjonowanie obiektów</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/wrap.html?DbPAR=WRITER">Opływanie obiektów przez tekst</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sekcje i ramki w dokumentach tekstowych</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/sections.html?DbPAR=WRITER">Sekcje</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/text_frame.html?DbPAR=WRITER">Wstawianie, edytowanie i łączenie ramek</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/section_edit.html?DbPAR=WRITER">Edycja sekcji</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/section_insert.html?DbPAR=WRITER">Wstawianie sekcji</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Spisy treści i indeksy</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numeracja rozdziałów</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Indeksy użytkownika</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Tworzenie spisu treści</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/indices_index.html?DbPAR=WRITER">Tworzenie indeksu alfabetycznego</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Indeksy obejmujące kilka dokumentów</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Tworzenie bibliografii</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Edycja i usuwanie wpisów indeksów i spisów treści</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Aktualizacja, edycja i usuwanie indeksów i spisów treści</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Definiowanie wpisów indeksu lub spisu treści</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formatowanie indeksu lub spisu treści</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Pola w dokumentach tekstowych</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/fields.html?DbPAR=WRITER">Pola</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/fields_date.html?DbPAR=WRITER">Wstawianie pola daty stałej lub zmiennej</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/field_convert.html?DbPAR=WRITER">Konwersja pola na tekst</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Obliczenia w dokumentach tekstowych</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Obliczenia pomiędzy tabelami</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/calculate.html?DbPAR=WRITER">Obliczenia w dokumentach tekstowych</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Obliczanie i wstawianie wyniku formuły w dokumencie tekstowym</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Obliczanie sum komórek w tabelach</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Obliczanie złożonych formuł w dokumentach tekstowych</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Wyświetlanie wyników obliczeń w innej tabeli</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Specjalne elementy tekstowe</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/captions.html?DbPAR=WRITER">Korzystanie z podpisów</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Tekst warunkowy</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Tekst warunkowy przy numeracji stron</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/fields_date.html?DbPAR=WRITER">Wstawianie pola daty stałej lub zmiennej</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Dodawanie pól wprowadzania</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Wstawianie numerów stron na następnych stronach</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Wstawianie numeru strony do stopki</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Ukrywanie tekstu</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definiowanie innych główek i stopek</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Wstawianie nazwy i numeru rozdziału w główce lub stopce</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Pobieranie danych użytkownika w polach lub warunkach</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Wstawianie i edycja przypisów dolnych lub końcowych</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Odstępy pomiędzy przypisami dolnymi</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/header_footer.html?DbPAR=WRITER">Główki i stopki</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formatowanie główek i stopek</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/text_animation.html?DbPAR=WRITER">Tekst animowany</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Tworzenie listu seryjnego</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Funkcje automatyczne</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Dodawanie wyjątków do listy autokorekty</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/autotext.html?DbPAR=WRITER">Korzystanie z funkcji autotekstu</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Tworzenie wyliczeń lub list podczas pisania</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/auto_off.html?DbPAR=WRITER">Wyłączanie autokorekty</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatyczne sprawdzanie pisowni</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Włączanie i wyłączanie rozpoznawania liczb w tabelach</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Dzielenie wyrazów</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numeracja i listy</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Dodawanie numerów rozdziałów do podpisów</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Tworzenie wyliczeń lub list podczas pisania</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numeracja rozdziałów</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Zmiana poziomu listy akapitu listy</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Łączenie list numerowanych</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Dodawanie numeracji wierszy</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modyfikowanie numeracji na liście uporządkowanej</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Definiowanie zakresów numeracji</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Dodawanie numeracji</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Style numeracji i akapitu</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Dodawanie punktorów</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Sprawdzanie pisowni, wyrazy bliskoznaczne i języki</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatyczne sprawdzanie pisowni</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Usuwanie słów ze słownika użytkownika</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Wyrazy bliskoznaczne</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Sprawdzanie pisowni i gramatyki</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Rozwiązywanie problemów</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Wstawianie tekstu przed tabelą na górze strony</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Przejście do określonej zakładki</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Ładowanie, zapisywanie, importowanie, eksportowanie i redagowanie</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/send2html.html?DbPAR=WRITER">Zapisywanie dokumentów tekstowych w formacie HTML</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Wstawianie całego dokumentu tekstowego</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/redaction.html?DbPAR=WRITER">Redagowanie</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatyczne redagowanie</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Dokumenty główne</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Korzystanie z dokumentów głównych i podrzędnych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Łącza i odwołania</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/references.html?DbPAR=WRITER">Wstawianie odsyłaczy</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Wstawianie hiperłączy za pomocą Nawigatora</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Drukowanie</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/print_selection.html?DbPAR=WRITER">Wybór treści do wydrukowania</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Wybór podajnika papieru drukarki</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/print_preview.html?DbPAR=WRITER">Podgląd strony przed wydrukiem</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/print_small.html?DbPAR=WRITER">Drukowanie wielu stron na pojedynczym arkuszu</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Tworzenie i stosowanie stylów strony</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Przeszukiwanie i zastępowanie</label><ul>\
    <li><a target="_top" href="pl/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Korzystanie z wyrażeń regularnych w wyszukiwaniu tekstu</a></li>\
    <li><a target="_top" href="pl/text/shared/01/02100001.html?DbPAR=WRITER">Lista wyrażeń regularnych</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">Dokumenty HTML (Writer Web)</label><ul>\
    <li><a target="_top" href="pl/text/shared/07/09000000.html?DbPAR=WRITER">Szablony HTML</a></li>\
    <li><a target="_top" href="pl/text/shared/02/01170700.html?DbPAR=WRITER">Filtry HTML i formularze</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/send2html.html?DbPAR=WRITER">Zapisywanie dokumentów tekstowych w formacie HTML</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Arkusze kalkulacyjne (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Informacje ogólne i korzystanie z interfejsu użytkownika</label><ul>\
    <li><a target="_top" href="pl/text/scalc/main0000.html?DbPAR=CALC">Witaj w systemie pomocy programu LibreOffice Calc</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0503.html?DbPAR=CALC">Właściwości LibreOffice Calc</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/keyboard.html?DbPAR=CALC">Skróty klawiaturowe (dostępność w LibreOffice Calc)</a></li>\
    <li><a target="_top" href="pl/text/scalc/04/01020000.html?DbPAR=CALC">Skróty klawiaturowe w arkuszach kalkulacyjnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="pl/text/scalc/05/02140000.html?DbPAR=CALC">Kody błędów w programie LibreOffice Calc</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060112.html?DbPAR=CALC">Dodatki programowania w LibreOffice Calc</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/main.html?DbPAR=CALC">Instrukcje dotyczące używania LibreOffice Calc</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Lista poleceń i menu</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menu</label><ul>\
    <li><a target="_top" href="pl/text/scalc/main0100.html?DbPAR=CALC">Menu</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0101.html?DbPAR=CALC">Plik</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0102.html?DbPAR=CALC">Edycja</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0103.html?DbPAR=CALC">Widok</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0104.html?DbPAR=CALC">Wstaw</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0105.html?DbPAR=CALC">Format</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0116.html?DbPAR=CALC">Arkusz</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0112.html?DbPAR=CALC">Dane</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0106.html?DbPAR=CALC">Narzędzia</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0107.html?DbPAR=CALC">Okno</a></li>\
    <li><a target="_top" href="pl/text/shared/main0108.html?DbPAR=CALC">Pomoc</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Paski narzędzi</label><ul>\
    <li><a target="_top" href="pl/text/scalc/main0200.html?DbPAR=CALC">Paski narzędzi</a></li>\
    <li><a target="_top" href="pl/text/shared/find_toolbar.html?DbPAR=CALC">Pasek wyszukiwania</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0202.html?DbPAR=CALC">Pasek formatowania</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0203.html?DbPAR=CALC">Pasek właściwości obiektu rysunkowego</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0205.html?DbPAR=CALC">Pasek formatowania tekstu</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0206.html?DbPAR=CALC">Pasek formuły</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0208.html?DbPAR=CALC">Pasek stanu</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0210.html?DbPAR=CALC">Pasek podglądu wydruku</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0214.html?DbPAR=CALC">Pasek obrazu</a></li>\
    <li><a target="_top" href="pl/text/scalc/main0218.html?DbPAR=CALC">Pasek narzędzi</a></li>\
    <li><a target="_top" href="pl/text/shared/main0201.html?DbPAR=CALC">Pasek standardowy</a></li>\
    <li><a target="_top" href="pl/text/shared/main0212.html?DbPAR=CALC">Pasek Dane tabeli</a></li>\
    <li><a target="_top" href="pl/text/shared/main0213.html?DbPAR=CALC">Pasek nawigacji formularza</a></li>\
    <li><a target="_top" href="pl/text/shared/main0214.html?DbPAR=CALC">Pasek projektu kwerendy</a></li>\
    <li><a target="_top" href="pl/text/shared/main0226.html?DbPAR=CALC">Pasek projektu formularza</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Typy funkcji i operatory</label><ul>\
    <li><a target="_top" href="pl/text/scalc/01/04060000.html?DbPAR=CALC">Kreator funkcji</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060100.html?DbPAR=CALC">Kategorie i funkcje</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060107.html?DbPAR=CALC">Funkcje macierzowe</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060120.html?DbPAR=CALC">Funkcje operacji na bitach</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060101.html?DbPAR=CALC">Funkcje bazy danych</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060102.html?DbPAR=CALC">Funkcje daty i godziny</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060103.html?DbPAR=CALC">Funkcje finansowe część pierwsza</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060119.html?DbPAR=CALC">Funkcje finansowe - część druga</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060118.html?DbPAR=CALC">Funkcje finansowe - część trzecia</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060104.html?DbPAR=CALC">Funkcje informacyjne</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060105.html?DbPAR=CALC">Funkcje logiczne</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060106.html?DbPAR=CALC">Funkcje matematyczne</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060108.html?DbPAR=CALC">Funkcje statystyczne</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060181.html?DbPAR=CALC">Funkcje statystyczne - część pierwsza</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060182.html?DbPAR=CALC">Funkcje statystyczne - część druga</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060183.html?DbPAR=CALC">Funkcje statystyczne - część trzecia</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060184.html?DbPAR=CALC">Funkcje statystyczne - część czwarta</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060185.html?DbPAR=CALC">Funkcje statystyczne - część piąta</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060109.html?DbPAR=CALC">Funkcje arkusza kalkulacyjnego</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060110.html?DbPAR=CALC">Funkcje tekstowe</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060111.html?DbPAR=CALC">Funkcje dodatkowe</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060115.html?DbPAR=CALC">Funkcje dodatkowe, lista funkcji analizy - część pierwsza</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060116.html?DbPAR=CALC">Funkcje dodatkowe, lista funkcji analizy - część druga</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/04060199.html?DbPAR=CALC">Operatory w LibreOffice Calc</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Funkcje użytkownika</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Ładowanie, zapisywanie, importowanie, eksportowanie i redagowanie</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/webquery.html?DbPAR=CALC">Wstawianie danych z tabel zewnętrznych (kwerenda WWW)</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/html_doc.html?DbPAR=CALC">Zapisywanie i otwieranie arkuszy w formacie HTML</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/csv_formula.html?DbPAR=CALC">Import i eksport plików tekstowych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/redaction.html?DbPAR=CALC">Redagowanie</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatyczne redagowanie</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formatowanie</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/text_rotate.html?DbPAR=CALC">Obracanie tekstu</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/text_wrap.html?DbPAR=CALC">Wpisywanie tekstu wielowierszowego</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formatowanie liczb jako tekstu</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/super_subscript.html?DbPAR=CALC">Tekst w indeksie górnym i dolnym</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/row_height.html?DbPAR=CALC">Zmiana wysokości wiersza lub szerokości kolumny</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Stosowanie formatowania warunkowego</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Wyróżnianie liczb ujemnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Przypisywanie formatów przez formułę</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Wprowadzanie liczb z wiodącymi zerami</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/format_table.html?DbPAR=CALC">Formatowanie arkuszy</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/format_value.html?DbPAR=CALC">Formatowanie liczb z miejscami dziesiętnymi</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/value_with_name.html?DbPAR=CALC">Nazywanie komórek</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/table_rotate.html?DbPAR=CALC">Obracanie tabel (transponowanie)</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/rename_table.html?DbPAR=CALC">Zmiana nazw arkuszy</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/year2000.html?DbPAR=CALC">Lata 19xx i 20xx</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Korzystanie z zaokrąglonych liczb</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/currency_format.html?DbPAR=CALC">Komórki w formacie walutowym</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/autoformat.html?DbPAR=CALC">Korzystanie z funkcji autoformatowania w przypadku tabel</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/note_insert.html?DbPAR=CALC">Wstawianie i edycja komentarzy</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/design.html?DbPAR=CALC">Wybieranie motywów dla arkuszy</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Wprowadzanie ułamków</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtrowanie i sortowanie</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/filters.html?DbPAR=CALC">Stosowanie filtrów</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/specialfilter.html?DbPAR=CALC">Stosowanie filtrów zaawansowanych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/autofilter.html?DbPAR=CALC">Stosowanie Autofiltra</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/sorted_list.html?DbPAR=CALC">Stosowanie list sortowania</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Usuwanie zduplikowanych wartości</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Drukowanie</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/print_title_row.html?DbPAR=CALC">Drukowanie wierszy lub kolumn na każdej stronie</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/print_landscape.html?DbPAR=CALC">Drukowanie arkusza w orientacji poziomej</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/print_details.html?DbPAR=CALC">Drukowanie elementów arkuszy</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/print_exact.html?DbPAR=CALC">Określanie liczby stron do wydrukowania</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Zakresy danych</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/database_define.html?DbPAR=CALC">Definiowanie zakresów baz danych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtrowanie zakresów baz danych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/database_sort.html?DbPAR=CALC">Sortowanie danych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Tabela przestawna</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/datapilot.html?DbPAR=CALC">Tabela przestawna</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Tworzenie tabel przestawnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Usuwanie tabel przestawnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Edycja tabel przestawnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtrowanie tabel przestawnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Wybór zakresu wyjściowego tabeli przestawnej</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Aktualizacja tabel przestawnych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Wykres przestawny</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/pivotchart.html?DbPAR=CALC">Wykres przestawny</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Tworzenie wykresów przestawnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Edytowanie wykresów przestawnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtrowanie wykresów przestawnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Aktualizacja wykresu przestawnego</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Usuwanie wykresów przestawnych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Scenariusze</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/scenario.html?DbPAR=CALC">Korzystanie ze scenariuszy</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Sumy częściowe</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Korzystanie z narzędzia sum częściowych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Odwołania</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Adresy i odwołania bezwzględne i względne</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/cellreferences.html?DbPAR=CALC">Tworzenie odwołania do komórki w innym dokumencie</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Odwołania do innych arkuszy kalkulacyjnych i tworzenie odwołań do adresów URL</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Tworzenie odwołań do komórek metodą "przeciągnij i upuść"</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/address_auto.html?DbPAR=CALC">Rozpoznawanie nazw jako adresów</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Przeglądanie, zaznaczanie, kopiowanie</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/table_view.html?DbPAR=CALC">Zmiana widoku tabeli</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/formula_value.html?DbPAR=CALC">Wyświetlanie formuł lub wartości</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/line_fix.html?DbPAR=CALC">Przytwierdzanie wierszy lub kolumn jako nagłówki</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/multi_tables.html?DbPAR=CALC">Poruszanie się między kartami arkuszy</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Kopiowanie do wielu arkuszy</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/cellcopy.html?DbPAR=CALC">Kopiowanie tylko widocznych komórek</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/mark_cells.html?DbPAR=CALC">Zaznaczanie wielu komórek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formuły i obliczenia</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/formulas.html?DbPAR=CALC">Obliczanie za pomocą formuł</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/formula_copy.html?DbPAR=CALC">Kopiowanie formuł</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/formula_enter.html?DbPAR=CALC">Wprowadzanie formuł</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/formula_value.html?DbPAR=CALC">Wyświetlanie formuł lub wartości</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/calculate.html?DbPAR=CALC">Obliczenia w arkuszach kalkulacyjnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/calc_date.html?DbPAR=CALC">Obliczenia dotyczące dat i godzin</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/calc_series.html?DbPAR=CALC">Automatyczne obliczanie serii</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Obliczanie różnic czasowych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/matrixformula.html?DbPAR=CALC">Wprowadzanie formuł macierzy</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/wildcards.html?DbPAR=CALC">Używanie symboli wieloznacznych w formułach</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Ochrona</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/cell_protect.html?DbPAR=CALC">Ochrona komórek przed zmianami</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Wyłączanie ochrony komórek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Pisanie makr Calc</label><ul>\
    <li><a target="_top" href="pl/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Odczytywanie i zapisywanie wartości do zakresów</a></li>\
    <li><a target="_top" href="pl/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatowanie krawędzi w programie Calc za pomocą makr</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Pozostałe</label><ul>\
    <li><a target="_top" href="pl/text/scalc/guide/auto_off.html?DbPAR=CALC">Wyłączanie automatycznych zmian</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/consolidate.html?DbPAR=CALC">Konsolidowanie danych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/goalseek.html?DbPAR=CALC">Szukanie wyniku</a></li>\
    <li><a target="_top" href="pl/text/scalc/01/solver.html?DbPAR=CALC">Solver</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/multioperation.html?DbPAR=CALC">Stosowanie operacji wielokrotnych</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/multitables.html?DbPAR=CALC">Stosowanie wielu arkuszy</a></li>\
    <li><a target="_top" href="pl/text/scalc/guide/validity.html?DbPAR=CALC">Poprawność zawartości komórek</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Prezentacje (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Informacje ogólne i korzystanie z interfejsu użytkownika</label><ul>\
    <li><a target="_top" href="pl/text/simpress/main0000.html?DbPAR=IMPRESS">Witaj w systemie pomocy LibreOffice Impress</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0503.html?DbPAR=IMPRESS">Właściwości programu LibreOffice Impress</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Korzystanie ze skrótów klawiaturowych w LibreOffice Impress</a></li>\
    <li><a target="_top" href="pl/text/simpress/04/01020000.html?DbPAR=IMPRESS">Skróty klawiaturowe w LibreOffice Impress</a></li>\
    <li><a target="_top" href="pl/text/simpress/04/presenter.html?DbPAR=IMPRESS">Skróty klawiaturowe konsoli prezentera</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/main.html?DbPAR=IMPRESS">Używanie LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Lista poleceń i menu</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menu</label><ul>\
    <li><a target="_top" href="pl/text/simpress/main0100.html?DbPAR=IMPRESS">Menu</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0101.html?DbPAR=IMPRESS">Plik</a></li>\
    <li><a target="_top" href="pl/text/simpress/main_edit.html?DbPAR=IMPRESS">Edycja</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0103.html?DbPAR=IMPRESS">Widok</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0104.html?DbPAR=IMPRESS">Wstaw</a></li>\
    <li><a target="_top" href="pl/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="pl/text/simpress/main_slide.html?DbPAR=IMPRESS">Slajd</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0114.html?DbPAR=IMPRESS">Pokaz slajdów</a></li>\
    <li><a target="_top" href="pl/text/simpress/main_tools.html?DbPAR=IMPRESS">Narzędzia</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0107.html?DbPAR=IMPRESS">Okno</a></li>\
    <li><a target="_top" href="pl/text/shared/main0108.html?DbPAR=IMPRESS">Pomoc</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Paski narzędzi</label><ul>\
    <li><a target="_top" href="pl/text/simpress/main0200.html?DbPAR=IMPRESS">Paski narzędzi</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0210.html?DbPAR=IMPRESS">Pasek rysunku</a></li>\
    <li><a target="_top" href="pl/text/shared/main0227.html?DbPAR=IMPRESS">Pasek edycji punktów</a></li>\
    <li><a target="_top" href="pl/text/shared/find_toolbar.html?DbPAR=IMPRESS">Pasek wyszukiwania</a></li>\
    <li><a target="_top" href="pl/text/shared/main0226.html?DbPAR=IMPRESS">Pasek projektu formularza</a></li>\
    <li><a target="_top" href="pl/text/shared/main0213.html?DbPAR=IMPRESS">Pasek nawigacji formularza</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0214.html?DbPAR=IMPRESS">Pasek obrazu</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0202.html?DbPAR=IMPRESS">Pasek Linia i wypełnienie</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0213.html?DbPAR=IMPRESS">Pasek opcji</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0211.html?DbPAR=IMPRESS">Pasek konspektu</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0209.html?DbPAR=IMPRESS">Linijki</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0212.html?DbPAR=IMPRESS">Pasek Sortowania slajdów</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0204.html?DbPAR=IMPRESS">Pasek widoku slajdów</a></li>\
    <li><a target="_top" href="pl/text/shared/main0201.html?DbPAR=IMPRESS">Pasek standardowy</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0206.html?DbPAR=IMPRESS">Pasek stanu</a></li>\
    <li><a target="_top" href="pl/text/shared/main0204.html?DbPAR=IMPRESS">Pasek tabeli</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0203.html?DbPAR=IMPRESS">Pasek formatowania tekstu</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Ładowanie, zapisywanie, importowanie, eksportowanie i redagowanie</label><ul>\
    <li><a target="_top" href="pl/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Zapisywanie prezentacji w formacie HTML</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Importowanie stron HTML do prezentacji</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Ładowanie palet kolorów, gradientów i kreskowania</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Eksport animacji w formacie GIF</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Dołączanie arkusza kalkulacyjnego do slajdów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Wstawianie grafiki</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Wstaw slajd z pliku</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redagowanie</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatyczne redagowanie</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formatowanie</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Ładowanie palet kolorów, gradientów i kreskowania</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Ładowanie stylów linii i strzałek</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Definiowanie kolorów niestandardowych</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Tworzenie wypełnienia gradientowego</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Zamiana kolorów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Rozmieszczenie, wyrównywanie i rozstawienie obiektów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/background.html?DbPAR=IMPRESS">Zmiana tła slajdu</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/footer.html?DbPAR=IMPRESS">Dodawanie główki i stopki do wszystkich slajdów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Zmiana i dodawanie strony głównej</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Przenoszenie obiektów</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Drukowanie</label><ul>\
    <li><a target="_top" href="pl/text/simpress/guide/printing.html?DbPAR=IMPRESS">Drukowanie prezentacji</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Drukowanie slajdów dopasowanych do wielkości papieru</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Efekty</label><ul>\
    <li><a target="_top" href="pl/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Eksport animacji w formacie GIF</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animacja obiektów na slajdach prezentacji</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animacja przejścia slajdów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Przenikanie obiektów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Tworzenie animowanych obrazków GIF</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Obiekty, grafiki i mapy bitowe</label><ul>\
    <li><a target="_top" href="pl/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Łączenie obiektów i tworzenie figur</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Grupowanie obiektów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Rysowanie wycinków i fragmentów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplikowanie obiektów</a></li>\
    <li><a target="_top" href="pl/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformacje</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Obracanie obiektów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Łączenie obiektów 3D</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Łączenie linii</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Konwersja znaków tekstowych na obiekty rysunkowe</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Konwertowanie obrazów bitmapowych na grafikę wektorową</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Konwersja obiektów 2D na krzywe, wielokąty i obiekty 3D</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Ładowanie stylów linii i strzałek</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Rysowanie krzywych</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Edycja krzywych</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Wstawianie grafiki</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Dołączanie arkusza kalkulacyjnego do slajdów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Przenoszenie obiektów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Zaznaczanie zasłoniętych obiektów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Tworzenie schematów blokowych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Tekst w prezentacjach</label><ul>\
    <li><a target="_top" href="pl/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Dodawanie tekstu</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Konwersja znaków tekstowych na obiekty rysunkowe</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Przeglądanie</label><ul>\
    <li><a target="_top" href="pl/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Zmiana kolejności slajdów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Powiększanie przy użyciu klawiatury</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Pokaz slajdów</label><ul>\
    <li><a target="_top" href="pl/text/simpress/guide/show.html?DbPAR=IMPRESS">Wyświetlenie pokazu slajdów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Korzystanie z konsoli prezentera</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Instrukcja obsługi Impress Remote</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/individual.html?DbPAR=IMPRESS">Tworzenie niestandardowego pokazu slajdów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Próba pokazu z pomiarem czasu</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Rysunki (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Informacje ogólne i korzystanie z interfejsu użytkownika</label><ul>\
    <li><a target="_top" href="pl/text/sdraw/main0000.html?DbPAR=DRAW">Witaj w systemie pomocy LibreOffice Draw</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main0503.html?DbPAR=DRAW">Funkcje programu LibreOffice Draw</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Skróty dla obiektów rysunkowych</a></li>\
    <li><a target="_top" href="pl/text/sdraw/04/01020000.html?DbPAR=DRAW">Skróty klawiaturowe dla rysunków</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/main.html?DbPAR=DRAW">Instrukcje korzystania z programu LibreOffice Draw</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Lista poleceń i menu</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menu</label><ul>\
    <li><a target="_top" href="pl/text/sdraw/main0100.html?DbPAR=DRAW">Menu</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main0101.html?DbPAR=DRAW">Plik</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main_edit.html?DbPAR=DRAW">Edycja</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main0103.html?DbPAR=DRAW">Widok (menu w Draw)</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main_insert.html?DbPAR=DRAW">Wstaw</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main_page.html?DbPAR=DRAW">Strona</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main_shape.html?DbPAR=DRAW">Kształt</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main_tools.html?DbPAR=DRAW">Narzędzia</a></li>\
    <li><a target="_top" href="pl/text/simpress/main0107.html?DbPAR=DRAW">Okno</a></li>\
    <li><a target="_top" href="pl/text/shared/main0108.html?DbPAR=DRAW">Pomoc</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Paski narzędzi</label><ul>\
    <li><a target="_top" href="pl/text/sdraw/main0200.html?DbPAR=DRAW">Paski narzędzi</a></li>\
    <li><a target="_top" href="pl/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">Ustawienia 3D</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main0210.html?DbPAR=DRAW">Pasek rysunku</a></li>\
    <li><a target="_top" href="pl/text/shared/main0227.html?DbPAR=DRAW">Pasek edycji punktów</a></li>\
    <li><a target="_top" href="pl/text/shared/find_toolbar.html?DbPAR=DRAW">Pasek wyszukiwania</a></li>\
    <li><a target="_top" href="pl/text/shared/main0226.html?DbPAR=DRAW">Pasek projektu formularza</a></li>\
    <li><a target="_top" href="pl/text/shared/main0213.html?DbPAR=DRAW">Pasek nawigacji formularza</a></li>\
    <li><a target="_top" href="pl/text/sdraw/main0213.html?DbPAR=DRAW">Pasek opcji</a></li>\
    <li><a target="_top" href="pl/text/shared/main0201.html?DbPAR=DRAW">Pasek standardowy</a></li>\
    <li><a target="_top" href="pl/text/shared/main0204.html?DbPAR=DRAW">Pasek tabeli</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Ładowanie, zapisywanie, importowanie i eksportowanie</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/palette_files.html?DbPAR=DRAW">Ładowanie palet kolorów, gradientów i kreskowania</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Wstawianie grafiki</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatowanie</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/palette_files.html?DbPAR=DRAW">Ładowanie palet kolorów, gradientów i kreskowania</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Ładowanie stylów linii i strzałek</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/color_define.html?DbPAR=DRAW">Definiowanie kolorów niestandardowych</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/gradient.html?DbPAR=DRAW">Tworzenie wypełnienia gradientowego</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Zamiana kolorów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Rozmieszczenie, wyrównywanie i rozstawienie obiektów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/background.html?DbPAR=DRAW">Zmiana tła slajdu</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/masterpage.html?DbPAR=DRAW">Zmiana i dodawanie strony głównej</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/move_object.html?DbPAR=DRAW">Przenoszenie obiektów</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Drukowanie</label><ul>\
    <li><a target="_top" href="pl/text/simpress/guide/printing.html?DbPAR=DRAW">Drukowanie prezentacji</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Drukowanie slajdów dopasowanych do wielkości papieru</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Efekty</label><ul>\
    <li><a target="_top" href="pl/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Przenikanie obiektów</a></li>\
    <li><a target="_top" href="pl/text/shared/01/05350000.html?DbPAR=DRAW">Efekty 3D</a></li>\
    <li><a target="_top" href="pl/text/simpress/02/10030000.html?DbPAR=DRAW">Transformacje</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Obiekty, grafiki i mapy bitowe</label><ul>\
    <li><a target="_top" href="pl/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Łączenie obiektów i tworzenie figur</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Rysowanie wycinków i fragmentów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplikowanie obiektów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Obracanie obiektów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Łączenie obiektów 3D</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Łączenie linii</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/text2curve.html?DbPAR=DRAW">Konwersja znaków tekstowych na obiekty rysunkowe</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/vectorize.html?DbPAR=DRAW">Konwertowanie obrazów bitmapowych na grafikę wektorową</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/3d_create.html?DbPAR=DRAW">Konwersja obiektów 2D na krzywe, wielokąty i obiekty 3D</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Ładowanie stylów linii i strzałek</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/line_draw.html?DbPAR=DRAW">Rysowanie krzywych</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/line_edit.html?DbPAR=DRAW">Edycja krzywych</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Wstawianie grafiki</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/table_insert.html?DbPAR=DRAW">Dołączanie arkusza kalkulacyjnego do slajdów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/move_object.html?DbPAR=DRAW">Przenoszenie obiektów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/select_object.html?DbPAR=DRAW">Zaznaczanie zasłoniętych obiektów</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/orgchart.html?DbPAR=DRAW">Tworzenie schematów blokowych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Grupy i warstwy</label><ul>\
    <li><a target="_top" href="pl/text/sdraw/guide/groups.html?DbPAR=DRAW">Grupowanie obiektów</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/layers.html?DbPAR=DRAW">Informacje o warstwach</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Wstawianie warstw</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Praca z warstwami</a></li>\
    <li><a target="_top" href="pl/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Przenoszenie obiektów na inną warstwę</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Tekst w rysunkach</label><ul>\
    <li><a target="_top" href="pl/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Dodawanie tekstu</a></li>\
    <li><a target="_top" href="pl/text/simpress/guide/text2curve.html?DbPAR=DRAW">Konwersja znaków tekstowych na obiekty rysunkowe</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Przeglądanie</label><ul>\
    <li><a target="_top" href="pl/text/simpress/guide/change_scale.html?DbPAR=DRAW">Powiększanie przy użyciu klawiatury</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Funkcjonalność bazy danych (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Informacje ogólne</label><ul>\
    <li><a target="_top" href="pl/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/database_main.html?DbPAR=BASE">Bazy danych - przegląd</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_new.html?DbPAR=BASE">Tworzenie nowej bazy danych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_tables.html?DbPAR=BASE">Praca z tabelami</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_queries.html?DbPAR=BASE">Praca z kwerendami</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_forms.html?DbPAR=BASE">Praca z formularzami</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_reports.html?DbPAR=BASE">Praca z raportami</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_register.html?DbPAR=BASE">Rejestracja i usuwanie bazy danych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_im_export.html?DbPAR=BASE">Importowanie i eksportowanie danych w programie Base</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Wykonywanie poleceń SQL</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formuły (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Informacje ogólne i korzystanie z interfejsu użytkownika</label><ul>\
    <li><a target="_top" href="pl/text/smath/main0000.html?DbPAR=MATH">Witaj w pomocy LibreOffice Math</a></li>\
    <li><a target="_top" href="pl/text/smath/main0503.html?DbPAR=MATH">Właściwości LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Elementy formuły</label><ul>\
    <li><a target="_top" href="pl/text/smath/01/03090100.html?DbPAR=MATH">Operatory jedno- i dwuargumentowe</a></li>\
    <li><a target="_top" href="pl/text/smath/01/03090200.html?DbPAR=MATH">Relacje</a></li>\
    <li><a target="_top" href="pl/text/smath/01/03090800.html?DbPAR=MATH">Operacje na zbiorach</a></li>\
    <li><a target="_top" href="pl/text/smath/01/03090400.html?DbPAR=MATH">Funkcje</a></li>\
    <li><a target="_top" href="pl/text/smath/01/03090300.html?DbPAR=MATH">Operatory</a></li>\
    <li><a target="_top" href="pl/text/smath/01/03090600.html?DbPAR=MATH">Atrybuty</a></li>\
    <li><a target="_top" href="pl/text/smath/01/03090500.html?DbPAR=MATH">Nawiasy</a></li>\
    <li><a target="_top" href="pl/text/smath/01/03090700.html?DbPAR=MATH">Format</a></li>\
    <li><a target="_top" href="pl/text/smath/01/03091600.html?DbPAR=MATH">Inne symbole</a></li>\
      </ul></li>\
    <li><a target="_top" href="pl/text/smath/guide/main.html?DbPAR=MATH">Wskazówki dotyczące korzystania z programu LibreOffice Math</a></li>\
    <li><a target="_top" href="pl/text/smath/guide/keyboard.html?DbPAR=MATH">Skróty (dostępność LibreOffice Math)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Lista poleceń i menu</label><ul>\
    <li><a target="_top" href="pl/text/smath/main0100.html?DbPAR=MATH">Menu</a></li>\
    <li><a target="_top" href="pl/text/smath/main0200.html?DbPAR=MATH">Paski narzędzi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Praca z formułami</label><ul>\
    <li><a target="_top" href="pl/text/smath/guide/align.html?DbPAR=MATH">Ręczne wyrównywanie części formuł</a></li>\
    <li><a target="_top" href="pl/text/smath/guide/color.html?DbPAR=MATH">Stosowanie koloru do części formuły</a></li>\
    <li><a target="_top" href="pl/text/smath/guide/attributes.html?DbPAR=MATH">Zmiana atrybutów domyślnych</a></li>\
    <li><a target="_top" href="pl/text/smath/guide/brackets.html?DbPAR=MATH">Scalanie części formuł w nawiasy</a></li>\
    <li><a target="_top" href="pl/text/smath/guide/comment.html?DbPAR=MATH">Wprowadzanie komentarzy</a></li>\
    <li><a target="_top" href="pl/text/smath/guide/newline.html?DbPAR=MATH">Wprowadzanie podziałów wierszy</a></li>\
    <li><a target="_top" href="pl/text/smath/guide/parentheses.html?DbPAR=MATH">Wstawianie nawiasów</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Wykresy i diagramy</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Informacje ogólne</label><ul>\
    <li><a target="_top" href="pl/text/schart/main0000.html?DbPAR=CHART">Wykresy w LibreOffice</a></li>\
    <li><a target="_top" href="pl/text/schart/main0503.html?DbPAR=CHART">Właściwości LibreOffice Chart</a></li>\
    <li><a target="_top" href="pl/text/schart/04/01020000.html?DbPAR=CHART">Skróty klawiaturowe dla wykresów</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makra i skrypty</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Informacje ogólne i korzystanie z interfejsu użytkownika</label><ul>\
    <li><a target="_top" href="pl/text/sbasic/shared/main0601.html?DbPAR=BASIC">Pomoc LibreOffice Basic</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programowanie w LibreOffice Basic</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/00000002.html?DbPAR=BASIC">Słownik LibreOffice Basic</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01010210.html?DbPAR=BASIC">Podstawy</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01020000.html?DbPAR=BASIC">Składnia</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01030100.html?DbPAR=BASIC">Przegląd środowiska IDE</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01030200.html?DbPAR=BASIC">Edytor Basic</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01050100.html?DbPAR=BASIC">Okno czujki</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/main0211.html?DbPAR=BASIC">Pasek narzędziowy Makro</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makro</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Wsparcie dla makr VBA</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Lista poleceń</label><ul>\
    <li><a target="_top" href="pl/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01020500.html?DbPAR=BASIC">Biblioteki, moduły i okna dialogowe</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funkcje, instrukcje i operatory</label><ul>\
    <li><a target="_top" href="pl/text/sbasic/shared/03040000.html?DbPAR=BASIC">Stałe Basic</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100000.html?DbPAR=BASIC">Zmienne</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03060000.html?DbPAR=BASIC">Operatory logiczne</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120000.html?DbPAR=BASIC">Łańcuchy</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030000.html?DbPAR=BASIC">Funkcje daty i czasu</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03070000.html?DbPAR=BASIC">Operatory matematyczne</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funkcje numeryczne</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080100.html?DbPAR=BASIC">Funkcje trygonometryczne</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010000.html?DbPAR=BASIC">Funkcje wejścia/wyjścia ekranu</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020000.html?DbPAR=BASIC">Funkcje wejścia/wyjścia plików</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090000.html?DbPAR=BASIC">Sterowanie wykonywaniem programu</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funkcje obsługi błędów</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03130000.html?DbPAR=BASIC">Pozostałe polecenia</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080300.html?DbPAR=BASIC">Generowanie liczb losowych</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Ekskluzywne funkcje VBA</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090400.html?DbPAR=BASIC">Dodatkowe instrukcje</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alfabetyczna lista funkcji, instrukcji i operatorów</label><ul>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080601.html?DbPAR=BASIC">Funkcja Abs</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03060100.html?DbPAR=BASIC">Operator AND</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03104200.html?DbPAR=BASIC">Funkcja Array</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120101.html?DbPAR=BASIC">Funkcja Asc</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120111.html?DbPAR=BASIC">Funkcja AscW</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080101.html?DbPAR=BASIC">Funkcja Atn</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03130100.html?DbPAR=BASIC">Instrukcja Beep</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010301.html?DbPAR=BASIC">Funkcja Blue</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090401.html?DbPAR=BASIC">Instrukcja Call</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100100.html?DbPAR=BASIC">Funkcja CBool</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120105.html?DbPAR=BASIC">Funkcja CByte</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100050.html?DbPAR=BASIC">Funkcja CCur</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030116.html?DbPAR=BASIC">Funkcja CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030115.html?DbPAR=BASIC">Funkcja CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030114.html?DbPAR=BASIC">Funkcja CDateFromUnoTime</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030113.html?DbPAR=BASIC">Funkcja CDateToUnoTime</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030112.html?DbPAR=BASIC">Funkcja CDateFromUnoDate</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030111.html?DbPAR=BASIC">Funkcja CDateToUnoDate</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030108.html?DbPAR=BASIC">Funkcja CDateFromIso</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030107.html?DbPAR=BASIC">Funkcja CDateToIso</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100300.html?DbPAR=BASIC">Funkcja CDate</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100400.html?DbPAR=BASIC">Funkcja CDbl</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100060.html?DbPAR=BASIC">Funkcja CDec</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020401.html?DbPAR=BASIC">Instrukcja ChDir</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020402.html?DbPAR=BASIC">Instrukcja ChDrive</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090402.html?DbPAR=BASIC">Instrukcja Choose</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120102.html?DbPAR=BASIC">Funkcja Chr</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100500.html?DbPAR=BASIC">Funkcja CInt</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100600.html?DbPAR=BASIC">Funkcja CLng</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020101.html?DbPAR=BASIC">Instrukcja Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100700.html?DbPAR=BASIC">Instrukcja Const</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120313.html?DbPAR=BASIC">Funkcja ConvertFromURL</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120312.html?DbPAR=BASIC">Funkcja ConvertToUrl</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080102.html?DbPAR=BASIC">Funkcja Cos</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03132400.html?DbPAR=BASIC">Funkcja CreateObject</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03131800.html?DbPAR=BASIC">Funkcja CreateUnoDialog</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03132000.html?DbPAR=BASIC">Funkcja CreateUnoListener</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03131600.html?DbPAR=BASIC">Funkcja CreateUnoService</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03131500.html?DbPAR=BASIC">Funkcja CreateUnoStruct</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03132300.html?DbPAR=BASIC">Funkcja CreateUnoValue</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100900.html?DbPAR=BASIC">Funkcja CSng</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101000.html?DbPAR=BASIC">Funkcja CStr</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020403.html?DbPAR=BASIC">Funkcja CurDir</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100070.html?DbPAR=BASIC">Funkcja CVar</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03100080.html?DbPAR=BASIC">Funkcja CVErr</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030110.html?DbPAR=BASIC">Funkcja DateAdd</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030120.html?DbPAR=BASIC">Funkcja DateDiff</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030130.html?DbPAR=BASIC">Funkcja DatePart</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030101.html?DbPAR=BASIC">Funkcja DateSerial</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030102.html?DbPAR=BASIC">Funkcja DateValue</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030103.html?DbPAR=BASIC">Funkcja Day</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090403.html?DbPAR=BASIC">Intrukcja Declare</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101100.html?DbPAR=BASIC">Instrukcja DefBool</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101110.html?DbPAR=BASIC">Instrukcja DefCur</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101300.html?DbPAR=BASIC">Instrukcja DefDate</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101400.html?DbPAR=BASIC">Instrukcja DefDbl</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101120.html?DbPAR=BASIC">Instrukcja DefErr</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101500.html?DbPAR=BASIC">Instrukcja DefInt</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101600.html?DbPAR=BASIC">Instrukcja DefLng</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101700.html?DbPAR=BASIC">Instrukcja DefObj</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101130.html?DbPAR=BASIC">Instrukcja DefSng</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03101140.html?DbPAR=BASIC">Instrukcja DefStr</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102000.html?DbPAR=BASIC">Instrukcja DefVar</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03104300.html?DbPAR=BASIC">Funkcja DimArray</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102100.html?DbPAR=BASIC">Instrukcja Dim</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020404.html?DbPAR=BASIC">Funkcja Dir</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090404.html?DbPAR=BASIC">Instrukcja End</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03130800.html?DbPAR=BASIC">Funkcja Environ</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020301.html?DbPAR=BASIC">Funkcja Eof</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03104600.html?DbPAR=BASIC">Funkcja EqualUnoObjects</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03060200.html?DbPAR=BASIC">Operator Eqv</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03050100.html?DbPAR=BASIC">Funkcja Erl</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03050200.html?DbPAR=BASIC">Funkcja Err</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03050300.html?DbPAR=BASIC">Funkcja błędu</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funkcje obsługi błędów</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090412.html?DbPAR=BASIC">Instrukcja Exit</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080201.html?DbPAR=BASIC">Funkcja Exp</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020405.html?DbPAR=BASIC">Funkcja FileAttr</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020406.html?DbPAR=BASIC">Deklaracja FileCopy</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020407.html?DbPAR=BASIC">Funkcja FileDateTime</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020415.html?DbPAR=BASIC">Funkcja FileExists</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020408.html?DbPAR=BASIC">Funkcja FileLen</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103800.html?DbPAR=BASIC">Funkcja FindObject</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103900.html?DbPAR=BASIC">Funkcja FindPropertyObject</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080501.html?DbPAR=BASIC">Funkcja Fix</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120301.html?DbPAR=BASIC">Funkcja Format</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03150000.html?DbPAR=BASIC">Funkcja FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020102.html?DbPAR=BASIC">Funkcja FreeFile</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090405.html?DbPAR=BASIC">Funkcja FreeLibrary</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090406.html?DbPAR=BASIC">Instrukcja Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020409.html?DbPAR=BASIC">Funkcja GetAttr</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03132500.html?DbPAR=BASIC">Funkcja GetDefaultContext</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03132100.html?DbPAR=BASIC">Funkcja GetGuiType</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03131700.html?DbPAR=BASIC">Funkcja GetProcessServiceManager</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03131000.html?DbPAR=BASIC">Funkcja GetSolarVersion</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03130700.html?DbPAR=BASIC">Funkcja GetSystemTicks</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020201.html?DbPAR=BASIC">Instrukcja Get</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103450.html?DbPAR=BASIC">Instrukcja Global</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090301.html?DbPAR=BASIC">Instrukcja GoSub...Return</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090302.html?DbPAR=BASIC">Instrukcja GoTo</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010302.html?DbPAR=BASIC">Funkcja Green</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03104400.html?DbPAR=BASIC">Funkcja HasUnoInterfaces</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080801.html?DbPAR=BASIC">Funkcja Hex</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030201.html?DbPAR=BASIC">Funkcja Hour</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090101.html?DbPAR=BASIC">Instrukcja If...Then...Else</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03060300.html?DbPAR=BASIC">Operator Imp</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120401.html?DbPAR=BASIC">Funkcja InStr</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120411.html?DbPAR=BASIC">Funkcja InStrRev [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03160000.html?DbPAR=BASIC">Funkcja Input [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010201.html?DbPAR=BASIC">Funkcja InputBox</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020202.html?DbPAR=BASIC">Instrukcja Input#</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080502.html?DbPAR=BASIC">Funkcja Int</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140002.html?DbPAR=BASIC">Funkcja IPmt [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102200.html?DbPAR=BASIC">Funkcja IsArray</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102300.html?DbPAR=BASIC">Funkcja IsDate</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102400.html?DbPAR=BASIC">Funkcja IsEmpty</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102450.html?DbPAR=BASIC">Funkcja IsError</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03104000.html?DbPAR=BASIC">Funkcja IsMissing</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102600.html?DbPAR=BASIC">Funkcja IsNull</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102700.html?DbPAR=BASIC">Funkcja IsNumeric</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102800.html?DbPAR=BASIC">Funkcja IsObject</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03104500.html?DbPAR=BASIC">Funkcja IsUnoStruct</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120315.html?DbPAR=BASIC">Funkcja Join</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020410.html?DbPAR=BASIC">Instrukcja Kill</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120302.html?DbPAR=BASIC">Funkcja LCase</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120304.html?DbPAR=BASIC">Instrukcja LSet</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120305.html?DbPAR=BASIC">Funkcja LTrim</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120303.html?DbPAR=BASIC">Funkcja Left</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120402.html?DbPAR=BASIC">Funkcja Len</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103100.html?DbPAR=BASIC">Instrukcja Let</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020302.html?DbPAR=BASIC">Funkcja Loc</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020303.html?DbPAR=BASIC">Funkcja Lof</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080202.html?DbPAR=BASIC">Funkcja Log</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120306.html?DbPAR=BASIC">Funkcja Mid, instrukcja Mid</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030202.html?DbPAR=BASIC">Funkcja Minute</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140004.html?DbPAR=BASIC">Funkcja MIRR [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020411.html?DbPAR=BASIC">Instrukcja MkDir</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03070600.html?DbPAR=BASIC">Operator Mod</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030104.html?DbPAR=BASIC">Funkcja Month</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03150002.html?DbPAR=BASIC">Funkcja MonthName [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010102.html?DbPAR=BASIC">Funkcja MsgBox</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010101.html?DbPAR=BASIC">Instrukcja MsgBox</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020412.html?DbPAR=BASIC">Instrukcja Name</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03060400.html?DbPAR=BASIC">Operator Not</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030203.html?DbPAR=BASIC">Funkcja Now</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140005.html?DbPAR=BASIC">Funkcja NPer [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140006.html?DbPAR=BASIC">Funkcja NPV [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funkcje numeryczne</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080802.html?DbPAR=BASIC">Funkcja Oct</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03050500.html?DbPAR=BASIC">Instrukcja On Error GoTo ... Resume</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090303.html?DbPAR=BASIC">Instrukcja On...GoSub; On...GoTo</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020103.html?DbPAR=BASIC">Instrukcja Open</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103200.html?DbPAR=BASIC">Instrukcja Option Base</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103300.html?DbPAR=BASIC">Instrukcja Option Explicit</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103350.html?DbPAR=BASIC">Instrukcja Option VBASupport</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (w instrukcji Function)</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03060500.html?DbPAR=BASIC">Operator Or</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140007.html?DbPAR=BASIC">Funkcja Pmt [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140008.html?DbPAR=BASIC">Funkcja PPmt [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103400.html?DbPAR=BASIC">Instrukcja Public</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140009.html?DbPAR=BASIC">Funkcja PV [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010304.html?DbPAR=BASIC">Funkcja QBColor</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140010.html?DbPAR=BASIC">Funkcja Rate [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080301.html?DbPAR=BASIC">Instrukcja Randomize</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03102101.html?DbPAR=BASIC">Instrukcja ReDim</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010303.html?DbPAR=BASIC">Funkcja Red</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090407.html?DbPAR=BASIC">Instrukcja Rem</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020104.html?DbPAR=BASIC">Instrukcja Reset</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010305.html?DbPAR=BASIC">Funkcja RGB</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120307.html?DbPAR=BASIC">Funkcja Right</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020413.html?DbPAR=BASIC">Instrukcja RmDir</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080302.html?DbPAR=BASIC">Funkcja Rnd</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03170000.html?DbPAR=BASIC">Funkcja Round [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120308.html?DbPAR=BASIC">Instrukcja RSet</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120309.html?DbPAR=BASIC">Funkcja RTrim</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030204.html?DbPAR=BASIC">Funkcja Second</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020304.html?DbPAR=BASIC">Funkcja Seek</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020414.html?DbPAR=BASIC">Instrukcja SetAttr</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103700.html?DbPAR=BASIC">Instrukcja Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080701.html?DbPAR=BASIC">Funkcja Sgn</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03130500.html?DbPAR=BASIC">Funkcja Shell</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080103.html?DbPAR=BASIC">Funkcja Sin</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120314.html?DbPAR=BASIC">Funkcja Split</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080401.html?DbPAR=BASIC">Funkcja Sqr</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080400.html?DbPAR=BASIC">Obliczanie pierwiastka kwadratowego</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103500.html?DbPAR=BASIC">Instrukcja Static</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090408.html?DbPAR=BASIC">Instrukcja Stop</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120403.html?DbPAR=BASIC">Funkcja StrComp</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120103.html?DbPAR=BASIC">Funkcja Str</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120412.html?DbPAR=BASIC">Funkcja StrReverse [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120202.html?DbPAR=BASIC">Funkcja String</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090409.html?DbPAR=BASIC">Instrukcja Sub</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090410.html?DbPAR=BASIC">Funkcja Switch</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03140012.html?DbPAR=BASIC">Funkcja SYD [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03080104.html?DbPAR=BASIC">Funkcja Tan</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030205.html?DbPAR=BASIC">Funkcja TimeSerial</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030206.html?DbPAR=BASIC">Funkcja TimeValue</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030303.html?DbPAR=BASIC">Funkcja Time</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120311.html?DbPAR=BASIC">Funkcja Trim</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03131300.html?DbPAR=BASIC">Funkcja TwipsPerPixelX</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03131400.html?DbPAR=BASIC">Funkcja TwipsPerPixelY</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090413.html?DbPAR=BASIC">Instrukcja Type</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103600.html?DbPAR=BASIC">Funkcja TypeName; funkcja VarType</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03103000.html?DbPAR=BASIC">Funkcja UBound</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120310.html?DbPAR=BASIC">Funkcja UCase</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120104.html?DbPAR=BASIC">Funkcja Val</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03130600.html?DbPAR=BASIC">Instrukcja Wait</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030105.html?DbPAR=BASIC">Funkcja WeekDay</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03150001.html?DbPAR=BASIC">Funkcja WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090203.html?DbPAR=BASIC">Instrukcja While...Wend</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03090411.html?DbPAR=BASIC">Instrukcja With</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03020205.html?DbPAR=BASIC">Instrukcja Write</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03060600.html?DbPAR=BASIC">Operator XOR</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03030106.html?DbPAR=BASIC">Funkcja Year</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03070100.html?DbPAR=BASIC">Operator "-"</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03070200.html?DbPAR=BASIC">Operator "*"</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03070300.html?DbPAR=BASIC">Operator "+"</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03070400.html?DbPAR=BASIC">Operator "/"</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03120300.html?DbPAR=BASIC">Edycja zawartości ciągu</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01020100.html?DbPAR=BASIC">Korzystanie ze zmiennych</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Zaawansowane biblioteki Basic</label><ul>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Biblioteka narzędziowa</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Biblioteka DEPOT</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Biblioteka EURO</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Biblioteka FORMWIZARD</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Biblioteka GIMMICKS</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">Biblioteka ImportWizard</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Biblioteka SCHEDULE</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Biblioteka SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Biblioteka TEMPLATE</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">Biblioteka WikiEditor</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">Biblioteka ScriptForge</label><ul>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">Biblioteki ScriptForge</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Tworzenie skryptów w języku Python za pomocą ScriptForge</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">Usługa ScriptForge.Array (SF_Array)</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Przewodniki</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/macro_recording.html?DbPAR=BASIC">Rejestrowanie makra</a></li>\
    <li><a target="_top" href="pl/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Zmiana właściwości formantów w edytorze okien dialogowych</a></li>\
    <li><a target="_top" href="pl/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Tworzenie formantów w edytorze okien dialogowych</a></li>\
    <li><a target="_top" href="pl/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Przykłady programowania dla formantów w edytorze okien dialogowych</a></li>\
    <li><a target="_top" href="pl/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Otwieranie okna dialogowego za pomocą Basic</a></li>\
    <li><a target="_top" href="pl/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Tworzenie okien dialogowych</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01030400.html?DbPAR=BASIC">Organizowanie bibliotek i modułów</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01020100.html?DbPAR=BASIC">Korzystanie ze zmiennych</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01020200.html?DbPAR=BASIC">Korzystanie z obiektów</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01030300.html?DbPAR=BASIC">Debugowanie programu Basic</a></li>\
    <li><a target="_top" href="pl/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="pl/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Przykłady programowania w języku Basic</a></li>\
    <li><a target="_top" href="pl/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic do Pythona</a></li>\
    <li><a target="_top" href="pl/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Pomoc skryptów w języku Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Informacje ogólne i korzystanie z interfejsu użytkownika</label><ul>\
    <li><a target="_top" href="pl/text/sbasic/python/main0000.html?DbPAR=BASIC">Skrypty w Pythonie</a></li>\
    <li><a target="_top" href="pl/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE dla Pythona</a></li>\
    <li><a target="_top" href="pl/text/sbasic/python/python_locations.html?DbPAR=BASIC">Organizacja skryptów Pythona</a></li>\
    <li><a target="_top" href="pl/text/sbasic/python/python_shell.html?DbPAR=BASIC">Interaktywna powłoka Pythona</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programowanie w Python</label><ul>\
    <li><a target="_top" href="pl/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python: Programowanie w Pythonie</a></li>\
    <li><a target="_top" href="pl/text/sbasic/python/python_examples.html?DbPAR=BASIC">Przykłady Pythona</a></li>\
    <li><a target="_top" href="pl/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python do Basic</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Narzędzia do tworzenia skryptów</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/dev_tools.html?DbPAR=BASIC">Narzędzia programistyczne</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Instalacja LibreOffice</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Zmiana przypisania plików Microsoft Office</a></li>\
    <li><a target="_top" href="pl/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Tryb awaryjny</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Tematy pomocy wspólne dla wszystkich aplikacji</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Informacje ogólne</label><ul>\
    <li><a target="_top" href="pl/text/shared/main0400.html?DbPAR=SHARED">Skróty klawiaturowe</a></li>\
    <li><a target="_top" href="pl/text/shared/00/00000005.html?DbPAR=SHARED">Słownik ogólny</a></li>\
    <li><a target="_top" href="pl/text/shared/00/00000002.html?DbPAR=SHARED">Słownik wyrażeń związanych z Internetem</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/accessibility.html?DbPAR=SHARED">Dostępność w LibreOffice</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/keyboard.html?DbPAR=SHARED">Skróty klawiaturowe (dostępność w LibreOffice)</a></li>\
    <li><a target="_top" href="pl/text/shared/04/01010000.html?DbPAR=SHARED">Ogólne skróty klawiaturowe w LibreOffice</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/version_number.html?DbPAR=SHARED">Numery wersji i kompilacji</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice i Microsoft Office</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/ms_user.html?DbPAR=SHARED">Korzystanie z dokumentów Microsoft Office w pakiecie LibreOffice</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Porównanie pakietów Microsoft Office i LibreOffice</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Konwersja dokumentów Microsoft Office</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Zmiana przypisania plików Microsoft Office</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Opcje LibreOffice</label><ul>\
    <li><a target="_top" href="pl/text/shared/optionen/01000000.html?DbPAR=SHARED">Opcje</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01010100.html?DbPAR=SHARED">Dane użytkownika</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01010200.html?DbPAR=SHARED">Ogólne</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01010800.html?DbPAR=SHARED">Widok</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01010900.html?DbPAR=SHARED">Drukowanie</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01010300.html?DbPAR=SHARED">Ścieżki / Pliki</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01010700.html?DbPAR=SHARED">Czcionki</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01030300.html?DbPAR=SHARED">Bezpieczeństwo</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01012000.html?DbPAR=SHARED">Kolory aplikacji</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01013000.html?DbPAR=SHARED">Dostępność</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/java.html?DbPAR=SHARED">Zaawansowane</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Konfiguracja eksperta</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">IDE Basic</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01010400.html?DbPAR=SHARED">Pisownia</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01010600.html?DbPAR=SHARED">Ogólne</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01020000.html?DbPAR=SHARED">Opcje ładowania/zapisywania</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01030000.html?DbPAR=SHARED">Opcje internetowe</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01040000.html?DbPAR=SHARED">Opcje dokumentów tekstowych</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01050000.html?DbPAR=SHARED">Opcje dokumentów HTML</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01060000.html?DbPAR=SHARED">Opcje arkusza kalkulacyjnego</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01070000.html?DbPAR=SHARED">Opcje prezentacji</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01080000.html?DbPAR=SHARED">Opcje rysunku</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01090000.html?DbPAR=SHARED">Formuła</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01110000.html?DbPAR=SHARED">Opcje wykresu</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01130100.html?DbPAR=SHARED">Właściwości VBA</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01140000.html?DbPAR=SHARED">Języki (opcje)</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01150000.html?DbPAR=SHARED">Opcje ustawień języka</a></li>\
    <li><a target="_top" href="pl/text/shared/optionen/01160000.html?DbPAR=SHARED">Opcje źródeł danych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Kreatory</label><ul>\
    <li><a target="_top" href="pl/text/shared/autopi/01000000.html?DbPAR=SHARED">Kreator</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Kreator listu</label><ul>\
    <li><a target="_top" href="pl/text/shared/autopi/01010000.html?DbPAR=SHARED">Kreator listu</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Kreator faksu</label><ul>\
    <li><a target="_top" href="pl/text/shared/autopi/01020000.html?DbPAR=SHARED">Kreator faksu</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Kreator agendy</label><ul>\
    <li><a target="_top" href="pl/text/shared/autopi/01040000.html?DbPAR=SHARED">Kreator agendy</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Kreator eksportu do HTML</label><ul>\
    <li><a target="_top" href="pl/text/shared/autopi/01110000.html?DbPAR=SHARED">Eksport HTML</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Kreator konwertera dokumentu</label><ul>\
    <li><a target="_top" href="pl/text/shared/autopi/01130000.html?DbPAR=SHARED">Konwerter dokumentów</a></li>\
      </ul></li>\
    <li><a target="_top" href="pl/text/shared/autopi/01150000.html?DbPAR=SHARED">Kreator konwersji euro</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Konfigurowanie LibreOffice</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/configure_overview.html?DbPAR=SHARED">Konfiguracja pakietu LibreOffice</a></li>\
    <li><a target="_top" href="pl/text/shared/01/packagemanager.html?DbPAR=SHARED">Menedżer rozszerzeń</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/flat_icons.html?DbPAR=SHARED">Zmiana widoku ikon</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Dostosowywanie pasków narzędzi</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/workfolder.html?DbPAR=SHARED">Zmiana katalogu roboczego</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/standard_template.html?DbPAR=SHARED">Tworzenie i zmiana szablonów domyślnych i niestandardowych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Rejestracja książki adresowej</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/formfields.html?DbPAR=SHARED">Wstawianie i edycja przycisków</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Praca z interfejsem użytkownika</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Szybki dostęp do obiektów</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/navigator.html?DbPAR=SHARED">Nawigator przeglądu dokumentu</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/autohide.html?DbPAR=SHARED">Wyświetlanie, dokowanie i ukrywanie okien</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/textmode_change.html?DbPAR=SHARED">Przełączanie między trybem wstawiania i nadpisywania</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Korzystanie z pasków narzędzi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Podpisy cyfrowe</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Korzystanie z podpisów cyfrowych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Stosowanie podpisów cyfrowych</a></li>\
    <li><a target="_top" href="pl/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="pl/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="pl/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="pl/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="pl/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Drukowanie, faksowanie, wysyłanie</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/labels_database.html?DbPAR=SHARED">Drukowanie etykiet adresowych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Drukowanie czarno-białe</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/email.html?DbPAR=SHARED">Wysyłanie dokumentów jako wiadomości e-mail</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/fax.html?DbPAR=SHARED">Wysyłanie faksów oraz konfigurowanie pakietu LibreOffice pod kątem faksowania</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Przeciągnij i upuść</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/dragdrop.html?DbPAR=SHARED">Przeciąganie i upuszczanie elementów w dokumencie LibreOffice</a></li>\
    <li><a target="_top" href="pl/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Przenoszenie i kopiowanie tekstu w dokumentach</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kopiowanie obszarów arkusza kalkulacyjnego do dokumentów tekstowych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kopiowanie elementów graficznych między dokumentami</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kopiowanie elementów graficznych z Galerii</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Funkcja "przeciągnij i upuść" w widoku źródła danych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Kopiuj i wklej</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Kopiowanie obiektów rysunkowych do innych dokumentów</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kopiowanie elementów graficznych między dokumentami</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kopiowanie elementów graficznych z Galerii</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kopiowanie obszarów arkusza kalkulacyjnego do dokumentów tekstowych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Wykresy i diagramy</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/chart_insert.html?DbPAR=SHARED">Wstawianie wykresów</a></li>\
    <li><a target="_top" href="pl/text/schart/main0000.html?DbPAR=SHARED">Wykresy w LibreOffice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Załaduj, zapisz, importuj, eksportuj, PDF</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/doc_open.html?DbPAR=SHARED">Otwieranie dokumentów</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/import_ms.html?DbPAR=SHARED">Otwieranie dokumentów zapisanych w innych formatach</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/doc_save.html?DbPAR=SHARED">Zapisywanie dokumentów</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Automatyczne zapisywanie dokumentów</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/export_ms.html?DbPAR=SHARED">Zapisywanie dokumentów w innych formatach</a></li>\
    <li><a target="_top" href="pl/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Eksportuj jako PDF</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Importowanie i eksportowanie danych w formacie tekstowym</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Łącza i odwołania</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Wstawianie hiperłączy</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Łącza względne i bezwzględne</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Edycja hiperłączy</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Śledzenie wersji dokumentu</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Porównywanie wersji dokumentu</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Scalanie wersji</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Rejestrowanie zmian</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/redlining.html?DbPAR=SHARED">Rejestrowanie i wyświetlanie zmian</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Akceptowanie lub odrzucanie zmian</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Zarządzanie wersjami</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etykiety i wizytówki</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/labels.html?DbPAR=SHARED">Tworzenie i drukowanie etykiet i wizytówek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Wstawianie danych zewnętrznych</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/copytable2application.html?DbPAR=SHARED">Wstawianie danych z arkuszy kalkulacyjnych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/copytext2application.html?DbPAR=SHARED">Wstawianie danych z dokumentów tekstowych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Wstawianie, edycja i zapisywanie map bitowych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Dodawanie elementów graficznych do Galerii</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Funkcje automatyczne</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Wyłączanie automatycznego rozpoznawania adresów URL</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Przeszukiwanie i zastępowanie</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/data_search2.html?DbPAR=SHARED">Wyszukiwanie z użyciem filtru formularza</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_search.html?DbPAR=SHARED">Przeszukiwanie dokumentów z tabelami i formularzami</a></li>\
    <li><a target="_top" href="pl/text/shared/01/02100001.html?DbPAR=SHARED">Lista wyrażeń regularnych</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Przewodniki</label><ul>\
    <li><a target="_top" href="pl/text/shared/guide/linestyles.html?DbPAR=SHARED">Stosowanie stylów linii</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/text_color.html?DbPAR=SHARED">Zmiana koloru tekstu</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/change_title.html?DbPAR=SHARED">Zmiana tytułu dokumentu</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/round_corner.html?DbPAR=SHARED">Tworzenie zaokrąglonych rogów</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/background.html?DbPAR=SHARED">Definiowanie kolorów lub grafiki tła</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/palette_files.html?DbPAR=SHARED">Ładowanie palet kolorów, gradientów i kreskowania</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/lineend_define.html?DbPAR=SHARED">Definiowanie stylów strzałek</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Definiowanie stylów linii</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Tworzenie obiektów graficznych za pomocą funkcji rysowania</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/line_intext.html?DbPAR=SHARED">Rysowanie linii w tekście</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/aaa_start.html?DbPAR=SHARED">Pierwsze kroki</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Wstawianie obiektów z Galerii</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Wstawianie spacji nierozdzielających, łączników i miękkich łączników</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Wstawianie znaków specjalnych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/tabs.html?DbPAR=SHARED">Wstawianie i edycja tabulatorów</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Korzystanie z plików zdalnych</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/protection.html?DbPAR=SHARED">Ochrona zawartości w pakiecie LibreOffice</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Ochrona rekordów</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Wybieranie maksymalnego obszaru drukowania strony</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/measurement_units.html?DbPAR=SHARED">Wybór jednostki miary</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/language_select.html?DbPAR=SHARED">Wybieranie języka dokumentu</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Projekt tabeli</a></li>\
    <li><a target="_top" href="pl/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Wyłączanie wypunktowania i numerowania poszczególnych akapitów</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
