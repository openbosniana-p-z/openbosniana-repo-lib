document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Textdokument (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Allmän information och användning av användargränssnitt</label><ul>\
    <li><a target="_top" href="sv/text/swriter/main0000.html?DbPAR=WRITER">Välkommen till LibreOffice Writer-hjälpen</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0503.html?DbPAR=WRITER">Funktioner i LibreOffice Writer</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/main.html?DbPAR=WRITER">Instruktioner för hur du använder LibreOffice Writer</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Förankra och ändra storlek på fönster</a></li>\
    <li><a target="_top" href="sv/text/swriter/04/01020000.html?DbPAR=WRITER">Kortkommandon för LibreOffice Writer</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/words_count.html?DbPAR=WRITER">Räknar ord</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/keyboard.html?DbPAR=WRITER">Använda kortkommandon (tillgänglighet i LibreOffice Writer)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Kommando- och menyreferens</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menyer</label><ul>\
    <li><a target="_top" href="sv/text/swriter/main0100.html?DbPAR=WRITER">Menyer</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0101.html?DbPAR=WRITER">Arkiv</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0102.html?DbPAR=WRITER">Redigera</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0103.html?DbPAR=WRITER">Visa</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0104.html?DbPAR=WRITER">Infoga</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0105.html?DbPAR=WRITER">Format</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0115.html?DbPAR=WRITER">Styles (menu)</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0110.html?DbPAR=WRITER">Tabell</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0120.html?DbPAR=WRITER">Form Menu</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0106.html?DbPAR=WRITER">Verktyg</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0107.html?DbPAR=WRITER">Fönster</a></li>\
    <li><a target="_top" href="sv/text/shared/main0108.html?DbPAR=WRITER">Hjälp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Verktygsrader</label><ul>\
    <li><a target="_top" href="sv/text/swriter/main0200.html?DbPAR=WRITER">Verktygsrader</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0206.html?DbPAR=WRITER">Verktygsraden Punktuppställningstecken</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0205.html?DbPAR=WRITER">Verktygsraden Egenskaper för ritobjekt</a></li>\
    <li><a target="_top" href="sv/text/shared/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="sv/text/shared/main0226.html?DbPAR=WRITER">Verktygsraden Formulärdesign</a></li>\
    <li><a target="_top" href="sv/text/shared/main0213.html?DbPAR=WRITER">Verktygsraden Formulär</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0202.html?DbPAR=WRITER">Textobjektrad</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0214.html?DbPAR=WRITER">Formelrad</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0215.html?DbPAR=WRITER">Verktygsraden Ram</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0203.html?DbPAR=WRITER">Bildobjektrad</a></li>\
    <li><a target="_top" href="sv/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Verktygsraden LibreLogo</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0216.html?DbPAR=WRITER">OLE Object Bar</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0210.html?DbPAR=WRITER">Print Preview Bar (Writer)</a></li>\
    <li><a target="_top" href="sv/text/shared/main0214.html?DbPAR=WRITER">Verktygsraden Sökningsutkast</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0213.html?DbPAR=WRITER">Linjaler</a></li>\
    <li><a target="_top" href="sv/text/shared/main0201.html?DbPAR=WRITER">Standardrad</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0208.html?DbPAR=WRITER">Status Bar (Writer)</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0204.html?DbPAR=WRITER">Verktygsraden Tabell</a></li>\
    <li><a target="_top" href="sv/text/shared/main0212.html?DbPAR=WRITER">Verktygsraden Tabelldata</a></li>\
    <li><a target="_top" href="sv/text/swriter/main0220.html?DbPAR=WRITER">Verktygsraden Textobjekt</a></li>\
    <li><a target="_top" href="sv/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Track Changes Toolbar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navigera i textdokument</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navigera och välja med tangentbordet</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Flytta och kopiera text i dokument</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Ordna om ett dokument med Navigator</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Infoga hyperlänkar med Navigator</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/navigator.html?DbPAR=WRITER">Navigator för textdokument</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Använda direktmarkören</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatera textdokument</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Ändra sidorienteringen (liggande eller stående)</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/text_capital.html?DbPAR=WRITER">Ändra skiftläget i en text</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Dölja text</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definiera olika sidhuvuden och sidfötter</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Infoga kapitelnamn och kapitelnummer i ett sidhuvud eller en sidfot</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Använda textformatering medan du skriver</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/reset_format.html?DbPAR=WRITER">Återställa teckenattribut</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Använda formatmallar med hjälp av tilldelningsläget</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/wrap.html?DbPAR=WRITER">Skriva text kring objekt</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Centrera text på en sida genom att använda en ram</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Framhäva text</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Rotera text</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/page_break.html?DbPAR=WRITER">Infoga och radera sidbrytningar</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Skapa och använda sidformatmallar</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/subscript.html?DbPAR=WRITER">Använda upphöjd eller nedsänkt text</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Mallar och formatmallar</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Dokumentmallar och formatmallar</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Använd olika sidformatmallar på udda och jämna sidor</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/change_header.html?DbPAR=WRITER">Skapa en sidformatmall baserad på aktuell sida</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/load_styles.html?DbPAR=WRITER">Använda formatmallar från andra dokument eller dokumentmallar</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Skapa nya formatmallar från markeringar</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Uppdatera formatmallar från markeringar</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/template_manager.html?DbPAR=WRITER">Template Manager</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Grafik i textdokument</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Infoga grafik</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Infoga grafik från en fil</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Infoga grafik från galleriet med dra-och-släpp</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Infoga en skannad bild</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Infoga ett Calc-diagram i ett textdokument</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Infoga grafik från LibreOffice Draw eller Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabeller i textdokument</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Sätta på och stänga av taligenkänning i tabeller</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/tablemode.html?DbPAR=WRITER">Ändra rader och kolumner med tangentbordet</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/table_delete.html?DbPAR=WRITER">Ta bort tabeller eller innehållet i en tabell</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/table_insert.html?DbPAR=WRITER">Infoga tabeller</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Upprepa en tabellrubrik på en ny sida</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Ändra storlek på rader och kolumner i en texttabell</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objekt i textdokument</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Placera objekt</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/wrap.html?DbPAR=WRITER">Skriva text kring objekt</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Områden och ramar i textdokument</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/sections.html?DbPAR=WRITER">Använda områden</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/section_edit.html?DbPAR=WRITER">Redigera områden</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/section_insert.html?DbPAR=WRITER">Infoga avsnitt</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Innehållsförteckning och register</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Användardefinierade förteckningar</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Skapa en innehållsförteckning</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/indices_index.html?DbPAR=WRITER">Skapa sakregister</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Förteckningar som täcker flera dokument</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Skapa en litteraturförteckning</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Redigera eller ta bort poster i förteckningar</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Uppdatera, redigera och ta bort förteckningar</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Definiera poster i innehållsförteckningar och andra förteckningar</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formatera en förteckning</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Fält i textdokument</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/fields.html?DbPAR=WRITER">Om fält</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/fields_date.html?DbPAR=WRITER">Infoga ett fast eller variabelt datumfält</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/field_convert.html?DbPAR=WRITER">Konvertera ett fältkommando till text</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Beräkning i textdokument</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Beräkna över tabeller</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/calculate.html?DbPAR=WRITER">Beräkning i textdokument</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Beräkna och klistra in resultat av en formel i ett textdokument</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Beräkna summan av celler i tabeller</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Beräkna komplicerade formler i textdokument</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Visa resultatet av en tabellberäkning i en annan tabell</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Särskilda textelement</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/captions.html?DbPAR=WRITER">Använda bildtexter</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Villkorlig text</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Villkorlig text för sidnumrering</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/fields_date.html?DbPAR=WRITER">Infoga ett fast eller variabelt datumfält</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Lägga till inmatningsfält</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Infoga sidnummer för följande sidor</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Infoga sidnummer i sidfötter</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Dölja text</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definiera olika sidhuvuden och sidfötter</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Infoga kapitelnamn och kapitelnummer i ett sidhuvud eller en sidfot</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Söka användardata i fält eller villkor</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Infoga och redigera fotnoter eller slutnoter</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Avstånd mellan fotnoter</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/header_footer.html?DbPAR=WRITER">Om sidhuvuden och sidfötter</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formatera sidhuvuden och sidfötter</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/text_animation.html?DbPAR=WRITER">Animera text</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Skapa ett standardbrev</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automatiska funktioner</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Lägga till undantag i autokorrigeringslistan</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/autotext.html?DbPAR=WRITER">Använda autotext</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Skapa punktlistor eller numrerade listor medan du skriver</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/auto_off.html?DbPAR=WRITER">Stänga av Autokorrigering</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatisk stavningskontroll</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Sätta på och stänga av taligenkänning i tabeller</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Avstavning</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numrering och listor</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Lägga till kapitelnummer till bildtexter</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Skapa punktlistor eller numrerade listor medan du skriver</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Kombinera numrerade listor</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Lägga till radnummer</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Definiera nummersekvenser</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Lägga till numrering</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Lägga till punktuppställning</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Stavningskontroll, synonymordbok och språk</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatisk stavningskontroll</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Ta bort ord från en användarordlista</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Synonymordlista</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Kontrollera stavning och grammatik</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Problemlösningstips</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Infoga text före en tabell i början av en sida</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Hoppa till ett visst bokmärke</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Läsa in, spara, importera, exportera och redigera</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/send2html.html?DbPAR=WRITER">Spara textdokument i HTML-format</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Infoga ett helt textdokument</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Samlingsdokument</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Samlingsdokument och deldokument</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Länkar och referenser</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/references.html?DbPAR=WRITER">Infoga korshänvisningar</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Infoga hyperlänkar med Navigator</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Utskrifter</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selecting What to Print</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Välja pappersmagasin på skrivaren</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/print_preview.html?DbPAR=WRITER">Förhandsgranska en sida före utskrift</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/print_small.html?DbPAR=WRITER">Skriva ut flera sidor på ett ark</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Skapa och använda sidformatmallar</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Att söka och ersätta</label><ul>\
    <li><a target="_top" href="sv/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="sv/text/shared/01/02100001.html?DbPAR=WRITER">Lista med reguljära uttryck</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML-dokument (Writer Web)</label><ul>\
    <li><a target="_top" href="sv/text/shared/07/09000000.html?DbPAR=WRITER">Webbsidor</a></li>\
    <li><a target="_top" href="sv/text/shared/02/01170700.html?DbPAR=WRITER">HTML-filter och -formulär</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/send2html.html?DbPAR=WRITER">Spara textdokument i HTML-format</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Kalkylark (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Allmän information och användning av användargränssnitt</label><ul>\
    <li><a target="_top" href="sv/text/scalc/main0000.html?DbPAR=CALC">Välkommen till LibreOffice Calc-hjälpen</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0503.html?DbPAR=CALC">LibreOffice Calc-funktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/keyboard.html?DbPAR=CALC">Kortkommandon (tillgänglighet i LibreOffice Calc)</a></li>\
    <li><a target="_top" href="sv/text/scalc/04/01020000.html?DbPAR=CALC">Kortkommandon för tabeller</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="sv/text/scalc/05/02140000.html?DbPAR=CALC">Felkoder i LibreOffice Calc</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060112.html?DbPAR=CALC">Tillägg för programmering i LibreOffice Calc</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/main.html?DbPAR=CALC">Instruktioner till LibreOffice Calc</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Kommando- och menyreferens</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menyer</label><ul>\
    <li><a target="_top" href="sv/text/scalc/main0100.html?DbPAR=CALC">Menyer</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0101.html?DbPAR=CALC">Arkiv</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0102.html?DbPAR=CALC">Redigera</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0103.html?DbPAR=CALC">Visa</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0104.html?DbPAR=CALC">Infoga</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0105.html?DbPAR=CALC">Format</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0116.html?DbPAR=CALC">Blad</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0112.html?DbPAR=CALC">Data</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0106.html?DbPAR=CALC">Verktyg</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0107.html?DbPAR=CALC">Fönster</a></li>\
    <li><a target="_top" href="sv/text/shared/main0108.html?DbPAR=CALC">Hjälp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Verktygsrader</label><ul>\
    <li><a target="_top" href="sv/text/scalc/main0200.html?DbPAR=CALC">Verktygsrader</a></li>\
    <li><a target="_top" href="sv/text/shared/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0202.html?DbPAR=CALC">Verktygsraden Formatering</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0203.html?DbPAR=CALC">Verktygsraden Egenskaper för ritobjekt</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0205.html?DbPAR=CALC">Verktygsraden Textformatering</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0206.html?DbPAR=CALC">Formelrad</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0208.html?DbPAR=CALC">Statusrad</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0210.html?DbPAR=CALC">Verktygsraden Förhandsgranskning</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0214.html?DbPAR=CALC">Verktygsraden Bild</a></li>\
    <li><a target="_top" href="sv/text/scalc/main0218.html?DbPAR=CALC">Verktygsraden Verktyg</a></li>\
    <li><a target="_top" href="sv/text/shared/main0201.html?DbPAR=CALC">Standardrad</a></li>\
    <li><a target="_top" href="sv/text/shared/main0212.html?DbPAR=CALC">Verktygsraden Tabelldata</a></li>\
    <li><a target="_top" href="sv/text/shared/main0213.html?DbPAR=CALC">Verktygsraden Formulär</a></li>\
    <li><a target="_top" href="sv/text/shared/main0214.html?DbPAR=CALC">Verktygsraden Sökningsutkast</a></li>\
    <li><a target="_top" href="sv/text/shared/main0226.html?DbPAR=CALC">Verktygsraden Formulärdesign</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Funktionstyper och operatorer</label><ul>\
    <li><a target="_top" href="sv/text/scalc/01/04060000.html?DbPAR=CALC">Funktionsguiden</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060100.html?DbPAR=CALC">Funktioner per kategori</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060107.html?DbPAR=CALC">Matrisfunktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060120.html?DbPAR=CALC">Bithanteringsfunktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060101.html?DbPAR=CALC">Databasfunktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060102.html?DbPAR=CALC">Datum- och tidsfunktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060103.html?DbPAR=CALC">Finansfunktioner del ett</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060119.html?DbPAR=CALC">Finansfunktioner del två</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060118.html?DbPAR=CALC">Finansfunktioner del tre</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060104.html?DbPAR=CALC">Informationsfunktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060105.html?DbPAR=CALC">Logiska funktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060106.html?DbPAR=CALC">Matematiska funktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060108.html?DbPAR=CALC">Statistikfunktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060181.html?DbPAR=CALC">Statistikfunktioner del ett</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060182.html?DbPAR=CALC">Statistikfunktioner del två</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060183.html?DbPAR=CALC">Statistikfunktioner del tre</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060184.html?DbPAR=CALC">Statistikfunktioner del fyra</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060185.html?DbPAR=CALC">Statistikfunktioner del fem</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060109.html?DbPAR=CALC">Kalkylbladsfunktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060110.html?DbPAR=CALC">Textfunktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060111.html?DbPAR=CALC">Tilläggsfunktioner</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060115.html?DbPAR=CALC">Tilläggsfunktioner, lista över analysfunktioner del ett</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060116.html?DbPAR=CALC">Tilläggsfunktioner, Lista över analysfunktioner del två</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/04060199.html?DbPAR=CALC">Operatorer i LibreOffice Calc</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Användardefinierade funktioner</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Läsa in, spara, importera och redigera</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/webquery.html?DbPAR=CALC">Infoga externa data i tabeller (WebQuery)</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/html_doc.html?DbPAR=CALC">Spara och öppna tabeller i HTML</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/csv_formula.html?DbPAR=CALC">Importera och exportera textfiler</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formatering</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/text_rotate.html?DbPAR=CALC">Rotera text</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/text_wrap.html?DbPAR=CALC">Skriva text på flera rader</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formatera tal som text</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/super_subscript.html?DbPAR=CALC">Upphöjd/nedsänkt text</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/row_height.html?DbPAR=CALC">Ändra radhöjd eller kolumnbredd</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Tillämpa villkorlig formatering</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Markera negativa tal</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Tilldela format med formler</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Skriva tal med inledande nollor</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/format_table.html?DbPAR=CALC">Formatera kalkylblad</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/format_value.html?DbPAR=CALC">Formatera tal med decimaler</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/value_with_name.html?DbPAR=CALC">Namnge celler</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/table_rotate.html?DbPAR=CALC">Rotera tabeller (transponera)</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/rename_table.html?DbPAR=CALC">Byta namn på tabeller</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx år</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Använda avrundade tal</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/currency_format.html?DbPAR=CALC">Celler i valutaformat</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/autoformat.html?DbPAR=CALC">Använda autoformat på tabeller</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/note_insert.html?DbPAR=CALC">Infoga och redigera kommentarer</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/design.html?DbPAR=CALC">Välja teman för tabeller</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Mata in bråk</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtrering och sortering</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/filters.html?DbPAR=CALC">Använda filter</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/autofilter.html?DbPAR=CALC">Använda Autofilter</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/sorted_list.html?DbPAR=CALC">Använda sorteringslistor</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Utskrifter</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/print_title_row.html?DbPAR=CALC">Skriva ut rader eller kolumner på varje sida</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/print_landscape.html?DbPAR=CALC">Skriva ut tabeller i liggande format</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/print_details.html?DbPAR=CALC">Skriva ut tabellinformation</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/print_exact.html?DbPAR=CALC">Definiera antal sidor som ska skrivas ut</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Dataområden</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/database_define.html?DbPAR=CALC">Definiera databasområden</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtrera cellområden</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/database_sort.html?DbPAR=CALC">Sortera data</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Pivottabell</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/datapilot.html?DbPAR=CALC">Pivottabell</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Skapa pivottabeller</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Ta bort pivottabeller</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Redigera pivottabeller</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtrera pivottabeller</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Välja var pivottabellen placeras</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Uppdatera pivottabeller</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivotdiagram</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Scenarier</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/scenario.html?DbPAR=CALC">Använda scenarier</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Delsummor</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Referenser</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Adresser och referenser, absoluta och relativa</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/cellreferences.html?DbPAR=CALC">Referera till en cell i ett annat dokument</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Referenser till andra tabeller och referera till URL-adresser</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Referera till celler genom att dra och släppa</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/address_auto.html?DbPAR=CALC">Identifiera namn och adressering</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Visning, markering, kopiering</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/table_view.html?DbPAR=CALC">Ändra tabellvyer</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/formula_value.html?DbPAR=CALC">Visa formler eller värden</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/line_fix.html?DbPAR=CALC">Fixera rader eller kolumner som rubriker</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navigera genom tabellflikar</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Kopiera till flera tabeller</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/cellcopy.html?DbPAR=CALC">Kopiera bara synliga celler</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/mark_cells.html?DbPAR=CALC">Markera flera celler</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formler och beräkningar</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/formulas.html?DbPAR=CALC">Beräkna med formler</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/formula_copy.html?DbPAR=CALC">Kopiera formler</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/formula_enter.html?DbPAR=CALC">Ange formler</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/formula_value.html?DbPAR=CALC">Visa formler eller värden</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/calculate.html?DbPAR=CALC">Beräkna i kalkylblad</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/calc_date.html?DbPAR=CALC">Beräkna med datum och tid</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/calc_series.html?DbPAR=CALC">Beräkna serier automatiskt</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Beräkna tidsskillnader</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/matrixformula.html?DbPAR=CALC">Skriva matrisformler</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Skydd</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/cell_protect.html?DbPAR=CALC">Skydda celler från ändringar</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Ta bort skydd från celler</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Skapa Calc-makron</label><ul>\
    <li><a target="_top" href="sv/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="sv/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatting Borders in Calc with Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Diverse</label><ul>\
    <li><a target="_top" href="sv/text/scalc/guide/auto_off.html?DbPAR=CALC">Deaktivera automatiska ändringar</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/consolidate.html?DbPAR=CALC">Konsolidera data</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/goalseek.html?DbPAR=CALC">Använda målsökning</a></li>\
    <li><a target="_top" href="sv/text/scalc/01/solver.html?DbPAR=CALC">Problemlösaren</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/multioperation.html?DbPAR=CALC">Använda flera operationer</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/multitables.html?DbPAR=CALC">Använda flera tabeller</a></li>\
    <li><a target="_top" href="sv/text/scalc/guide/validity.html?DbPAR=CALC">Validera cellinnehåll</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentationer (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Allmän information och användning av användargränssnitt</label><ul>\
    <li><a target="_top" href="sv/text/simpress/main0000.html?DbPAR=IMPRESS">Välkommen till LibreOffice Impress-hjälpen</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0503.html?DbPAR=IMPRESS">Funktioner i LibreOffice Impress</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Använda kortkommandon i LibreOffice Impress</a></li>\
    <li><a target="_top" href="sv/text/simpress/04/01020000.html?DbPAR=IMPRESS">Kortkommandon för LibreOffice Impress</a></li>\
    <li><a target="_top" href="sv/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Keyboard Shortcuts</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/main.html?DbPAR=IMPRESS">Instruktioner för hur du använder LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Kommando- och menyreferens</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menyer</label><ul>\
    <li><a target="_top" href="sv/text/simpress/main0100.html?DbPAR=IMPRESS">Menyer</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0101.html?DbPAR=IMPRESS">Arkiv</a></li>\
    <li><a target="_top" href="sv/text/simpress/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0103.html?DbPAR=IMPRESS">Vy</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0104.html?DbPAR=IMPRESS">Infoga</a></li>\
    <li><a target="_top" href="sv/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="sv/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0114.html?DbPAR=IMPRESS">Bildskärmspresentation</a></li>\
    <li><a target="_top" href="sv/text/simpress/main_tools.html?DbPAR=IMPRESS">Tools</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0107.html?DbPAR=IMPRESS">Fönster</a></li>\
    <li><a target="_top" href="sv/text/shared/main0108.html?DbPAR=IMPRESS">Hjälp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Verktygsrader</label><ul>\
    <li><a target="_top" href="sv/text/simpress/main0200.html?DbPAR=IMPRESS">Verktygsrader</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0210.html?DbPAR=IMPRESS">Verktygsraden Ritverktyg</a></li>\
    <li><a target="_top" href="sv/text/shared/main0227.html?DbPAR=IMPRESS">Verktygsraden Redigera punkter</a></li>\
    <li><a target="_top" href="sv/text/shared/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="sv/text/shared/main0226.html?DbPAR=IMPRESS">Verktygsraden Formulärdesign</a></li>\
    <li><a target="_top" href="sv/text/shared/main0213.html?DbPAR=IMPRESS">Verktygsraden Formulär</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0214.html?DbPAR=IMPRESS">Verktygsraden Bild</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0202.html?DbPAR=IMPRESS">Raden Linje och fyllning</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0213.html?DbPAR=IMPRESS">Verktygsraden Alternativ</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0211.html?DbPAR=IMPRESS">Verktygsraden Disposition</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0209.html?DbPAR=IMPRESS">Linjaler</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0212.html?DbPAR=IMPRESS">Verktygsraden Bildsortering</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0204.html?DbPAR=IMPRESS">Objektraden i Bildvy</a></li>\
    <li><a target="_top" href="sv/text/shared/main0201.html?DbPAR=IMPRESS">Standardrad</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0206.html?DbPAR=IMPRESS">Statusraden</a></li>\
    <li><a target="_top" href="sv/text/shared/main0204.html?DbPAR=IMPRESS">Verktygsraden Tabell</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0203.html?DbPAR=IMPRESS">Verktygsraden Textformatering</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Läsa in, spara, importera, exportera och redigera</label><ul>\
    <li><a target="_top" href="sv/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Spara en presentation i HTML-format</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Importera HTML-sidor till presentationer</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportera animationer i GIF-format</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Infoga kalkylblad på bilder</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Infoga grafik</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formatering</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Läs in linje- och pilstilar</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Definiera egna färger</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Skapa gradientfyllningar</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Byta ut färger</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Placera, justera och fördela objekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/background.html?DbPAR=IMPRESS">Ändra bakgrundsfyllningen för en sida</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/footer.html?DbPAR=IMPRESS">Lägga till ett sidhuvud eller sidfot i alla bilder</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Flytta objekt</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Utskrifter</label><ul>\
    <li><a target="_top" href="sv/text/simpress/guide/printing.html?DbPAR=IMPRESS">Skriva ut presentationer</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Anpassa utskriften till ett visst pappersformat</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Effekter</label><ul>\
    <li><a target="_top" href="sv/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportera animationer i GIF-format</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animera objekt i presentationsbilder</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animerade bildväxlingar</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Tona över två objekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Skapa animerade GIF-bilder</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objekt, grafik och bitmappar</label><ul>\
    <li><a target="_top" href="sv/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Kombinera objekt och skapa former</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Gruppera objekt</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Rita sektorer och segment</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplicera objekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformations</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Rotera objekt</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Samla ihop 3D-objekt</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Förbinda linjer</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Konvertera texttecken till ritobjekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Konvertera bitmapbilder till vektorgrafik</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Konvertera 2D-objekt till kurvor, polygoner och 3D-objekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Läs in linje- och pilstilar</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Rita kurvor</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Redigera kurvor</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Infoga grafik</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Infoga kalkylblad på bilder</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Flytta objekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Markera underliggande objekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Skapa ett flödesschema</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text i presentationer</label><ul>\
    <li><a target="_top" href="sv/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Lägga till text</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Konvertera texttecken till ritobjekt</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Visning</label><ul>\
    <li><a target="_top" href="sv/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Ändra bildordningen</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Zooma med tangentbordet</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Bildspel</label><ul>\
    <li><a target="_top" href="sv/text/simpress/guide/show.html?DbPAR=IMPRESS">Visar bilderna</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/individual.html?DbPAR=IMPRESS">Skapa en anpassad presentation</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Visa en presentation med tidtagning</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Ritningar (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Allmän information och användning av användargränssnitt</label><ul>\
    <li><a target="_top" href="sv/text/sdraw/main0000.html?DbPAR=DRAW">Välkommen till LibreOffice Draw-hjälpen</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main0503.html?DbPAR=DRAW">Funktioner i LibreOffice Draw</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Snabbkommandon för ritobjekt</a></li>\
    <li><a target="_top" href="sv/text/sdraw/04/01020000.html?DbPAR=DRAW">Snabbkommandon för ritobjekt</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/main.html?DbPAR=DRAW">Instruktioner till LibreOffice Draw</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Kommando- och menyreferens</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menyer</label><ul>\
    <li><a target="_top" href="sv/text/sdraw/main0100.html?DbPAR=DRAW">Menyer</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main0101.html?DbPAR=DRAW">Arkiv</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main0103.html?DbPAR=DRAW">View (menu in Draw)</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main_insert.html?DbPAR=DRAW">Insert</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main_tools.html?DbPAR=DRAW">Tools</a></li>\
    <li><a target="_top" href="sv/text/simpress/main0107.html?DbPAR=DRAW">Fönster</a></li>\
    <li><a target="_top" href="sv/text/shared/main0108.html?DbPAR=DRAW">Hjälp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Verktygsfält</label><ul>\
    <li><a target="_top" href="sv/text/sdraw/main0200.html?DbPAR=DRAW">Verktygsrader</a></li>\
    <li><a target="_top" href="sv/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D-Settings</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main0210.html?DbPAR=DRAW">Verktygsraden Ritverktyg</a></li>\
    <li><a target="_top" href="sv/text/shared/main0227.html?DbPAR=DRAW">Verktygsraden Redigera punkter</a></li>\
    <li><a target="_top" href="sv/text/shared/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="sv/text/shared/main0226.html?DbPAR=DRAW">Verktygsraden Formulärdesign</a></li>\
    <li><a target="_top" href="sv/text/shared/main0213.html?DbPAR=DRAW">Verktygsraden Formulär</a></li>\
    <li><a target="_top" href="sv/text/sdraw/main0213.html?DbPAR=DRAW">Verktygsraden Alternativ</a></li>\
    <li><a target="_top" href="sv/text/shared/main0201.html?DbPAR=DRAW">Standardrad</a></li>\
    <li><a target="_top" href="sv/text/shared/main0204.html?DbPAR=DRAW">Verktygsraden Tabell</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Läsa in, spara, importera och exportera</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Infoga grafik</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatera</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Läs in linje- och pilstilar</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/color_define.html?DbPAR=DRAW">Definiera egna färger</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/gradient.html?DbPAR=DRAW">Skapa gradientfyllningar</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Byta ut färger</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Placera, justera och fördela objekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/background.html?DbPAR=DRAW">Ändra bakgrundsfyllningen för en sida</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/move_object.html?DbPAR=DRAW">Flytta objekt</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Skriva ut</label><ul>\
    <li><a target="_top" href="sv/text/simpress/guide/printing.html?DbPAR=DRAW">Skriva ut presentationer</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Anpassa utskriften till ett visst pappersformat</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effekter</label><ul>\
    <li><a target="_top" href="sv/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Tona över två objekt</a></li>\
    <li><a target="_top" href="sv/text/shared/01/05350000.html?DbPAR=DRAW">3D-effekter</a></li>\
    <li><a target="_top" href="sv/text/simpress/02/10030000.html?DbPAR=DRAW">Transformations</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objekt, grafik och bitmappsbilder</label><ul>\
    <li><a target="_top" href="sv/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Kombinera objekt och skapa former</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Rita sektorer och segment</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplicera objekt</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Rotera objekt</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Samla ihop 3D-objekt</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Förbinda linjer</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/text2curve.html?DbPAR=DRAW">Konvertera texttecken till ritobjekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/vectorize.html?DbPAR=DRAW">Konvertera bitmapbilder till vektorgrafik</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/3d_create.html?DbPAR=DRAW">Konvertera 2D-objekt till kurvor, polygoner och 3D-objekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Läs in linje- och pilstilar</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/line_draw.html?DbPAR=DRAW">Rita kurvor</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/line_edit.html?DbPAR=DRAW">Redigera kurvor</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Infoga grafik</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/table_insert.html?DbPAR=DRAW">Infoga kalkylblad på bilder</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/move_object.html?DbPAR=DRAW">Flytta objekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/select_object.html?DbPAR=DRAW">Markera underliggande objekt</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/orgchart.html?DbPAR=DRAW">Skapa ett flödesschema</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Grupper och lager</label><ul>\
    <li><a target="_top" href="sv/text/sdraw/guide/groups.html?DbPAR=DRAW">Gruppera objekt</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserting Layers</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="sv/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text i ritningar</label><ul>\
    <li><a target="_top" href="sv/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Lägga till text</a></li>\
    <li><a target="_top" href="sv/text/simpress/guide/text2curve.html?DbPAR=DRAW">Konvertera texttecken till ritobjekt</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Visning</label><ul>\
    <li><a target="_top" href="sv/text/simpress/guide/change_scale.html?DbPAR=DRAW">Zooma med tangentbordet</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Databasfunktionalitet (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Generell information</label><ul>\
    <li><a target="_top" href="sv/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/database_main.html?DbPAR=BASE">Databasöversikt</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_new.html?DbPAR=BASE">Skapa en ny databas</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_tables.html?DbPAR=BASE">Arbeta med tabeller</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_queries.html?DbPAR=BASE">Arbeta med sökningar</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_forms.html?DbPAR=BASE">Arbeta med formulär</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_reports.html?DbPAR=BASE">Skapa rapporter</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_register.html?DbPAR=BASE">Registrera och radera databaser</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_im_export.html?DbPAR=BASE">Importera och exportera data i Base</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Köra SQL-kommandon</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formler (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Allmän information och användning av användargränssnitt</label><ul>\
    <li><a target="_top" href="sv/text/smath/main0000.html?DbPAR=MATH">Välkommen till LibreOffice Math-hjälpen</a></li>\
    <li><a target="_top" href="sv/text/smath/main0503.html?DbPAR=MATH">Funktioner i LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formelelement</label><ul>\
    <li><a target="_top" href="sv/text/smath/01/03090100.html?DbPAR=MATH">Unära och binära operatorer</a></li>\
    <li><a target="_top" href="sv/text/smath/01/03090200.html?DbPAR=MATH">Relationer</a></li>\
    <li><a target="_top" href="sv/text/smath/01/03090800.html?DbPAR=MATH">Mängdoperationer</a></li>\
    <li><a target="_top" href="sv/text/smath/01/03090400.html?DbPAR=MATH">Funktioner</a></li>\
    <li><a target="_top" href="sv/text/smath/01/03090300.html?DbPAR=MATH">Operatorer</a></li>\
    <li><a target="_top" href="sv/text/smath/01/03090600.html?DbPAR=MATH">Attribut</a></li>\
    <li><a target="_top" href="sv/text/smath/01/03090500.html?DbPAR=MATH">Parenteser</a></li>\
    <li><a target="_top" href="sv/text/smath/01/03090700.html?DbPAR=MATH">Format</a></li>\
    <li><a target="_top" href="sv/text/smath/01/03091600.html?DbPAR=MATH">Andra symboler</a></li>\
      </ul></li>\
    <li><a target="_top" href="sv/text/smath/guide/main.html?DbPAR=MATH">Instruktioner till LibreOffice Math</a></li>\
    <li><a target="_top" href="sv/text/smath/guide/keyboard.html?DbPAR=MATH">Genvägar (tillgänglighet i LibreOfficeMath)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Kommando- och menyreferens</label><ul>\
    <li><a target="_top" href="sv/text/smath/main0100.html?DbPAR=MATH">Menyer</a></li>\
    <li><a target="_top" href="sv/text/smath/main0200.html?DbPAR=MATH">Verktygsrader</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Arbeta med formler</label><ul>\
    <li><a target="_top" href="sv/text/smath/guide/align.html?DbPAR=MATH">Justera formeldelar manuellt</a></li>\
    <li><a target="_top" href="sv/text/smath/guide/color.html?DbPAR=MATH">Applying Color to Formula Parts</a></li>\
    <li><a target="_top" href="sv/text/smath/guide/attributes.html?DbPAR=MATH">Ändra standardattribut</a></li>\
    <li><a target="_top" href="sv/text/smath/guide/brackets.html?DbPAR=MATH">Sammanfoga formeldelar i en parentes</a></li>\
    <li><a target="_top" href="sv/text/smath/guide/comment.html?DbPAR=MATH">Skriva kommentarer</a></li>\
    <li><a target="_top" href="sv/text/smath/guide/newline.html?DbPAR=MATH">Infoga radbrytningar</a></li>\
    <li><a target="_top" href="sv/text/smath/guide/parentheses.html?DbPAR=MATH">Infoga parentes</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Grafer och diagram</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Allmän information</label><ul>\
    <li><a target="_top" href="sv/text/schart/main0000.html?DbPAR=CHART">Diagram i LibreOffice</a></li>\
    <li><a target="_top" href="sv/text/schart/main0503.html?DbPAR=CHART">Diagramfunktioner i LibreOffice</a></li>\
    <li><a target="_top" href="sv/text/schart/04/01020000.html?DbPAR=CHART">Kortkommandon för diagram</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makron och skripting</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Allmän information och användning av användargränssnitt</label><ul>\
    <li><a target="_top" href="sv/text/sbasic/shared/main0601.html?DbPAR=BASIC">Hjälp för LibreOffice Basic</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programmera med LibreOffice Basic</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/00000002.html?DbPAR=BASIC">Ordlista för LibreOffice Basic</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01010210.html?DbPAR=BASIC">Basics</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01020000.html?DbPAR=BASIC">Syntax</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01030100.html?DbPAR=BASIC">IDE - Översikt</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01030200.html?DbPAR=BASIC">Basic-redigeringsfönstret</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01050100.html?DbPAR=BASIC">Bevakare</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/main0211.html?DbPAR=BASIC">Verktygsraden Makro</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makro</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Kommandoreferens</label><ul>\
    <li><a target="_top" href="sv/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01020500.html?DbPAR=BASIC">Bibliotek, moduler och dialogrutor</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funktioner, uttryck och operatorer</label><ul>\
    <li><a target="_top" href="sv/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variabler</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03060000.html?DbPAR=BASIC">Logiska operatorer</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120000.html?DbPAR=BASIC">Strängar</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030000.html?DbPAR=BASIC">Datum- och tidsfunktioner</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03070000.html?DbPAR=BASIC">Matematiska operatorer</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numeriska funktioner</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080100.html?DbPAR=BASIC">Trigonometriska funktioner</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010000.html?DbPAR=BASIC">In- och utmatningsfunktioner för bildskärm</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020000.html?DbPAR=BASIC">In- och utmatningsfunktioner för filer</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090000.html?DbPAR=BASIC">Styra programkörningen</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03050000.html?DbPAR=BASIC">Felhanteringsfunktioner</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03130000.html?DbPAR=BASIC">Andra kommandon</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080300.html?DbPAR=BASIC">Generera slumptal</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090400.html?DbPAR=BASIC">Ytterligare uttryck</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alfabetisk lista över funktioner, uttryck och operatorer</label><ul>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blå funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir-uttryck</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive-uttryck</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020101.html?DbPAR=BASIC">Stäng uttryck</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir-funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir-funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof-funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03050000.html?DbPAR=BASIC">Felhanteringsfunktioner</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr-funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile-funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020201.html?DbPAR=BASIC">Hämta uttryck</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010302.html?DbPAR=BASIC">Grön funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox-funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020202.html?DbPAR=BASIC">Inmatnings# Uttryck</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc-funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof-funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox-Funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox-uttryck</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numeriska funktioner</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020103.html?DbPAR=BASIC">Öppna uttryck</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010304.html?DbPAR=BASIC">QB-färg funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010303.html?DbPAR=BASIC">Röd funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020104.html?DbPAR=BASIC">Återställ uttryck</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB-funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020304.html?DbPAR=BASIC">Sök funktion</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080400.html?DbPAR=BASIC">Beräkningar av kvadratrot</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03020205.html?DbPAR=BASIC">Skrivuttryck</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03120300.html?DbPAR=BASIC">Ändra innehållet i strängar</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01020100.html?DbPAR=BASIC">Använda variabler</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Avancerade Basic-bibliotek</label><ul>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard Library</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Library</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForge-bibliotek</label><ul>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge Libraries</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guider</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/macro_recording.html?DbPAR=BASIC">Spela in ett makro</a></li>\
    <li><a target="_top" href="sv/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Ändra egenskaper för kontroller i dialogredigeraren</a></li>\
    <li><a target="_top" href="sv/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Skapa kontroller i dialogredigeraren</a></li>\
    <li><a target="_top" href="sv/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Programmeringsexempel för kontroller i dialogredigeraren</a></li>\
    <li><a target="_top" href="sv/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="sv/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Skapa en dialogruta i Basic</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01030400.html?DbPAR=BASIC">Strukturera bibliotek och moduler</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01020100.html?DbPAR=BASIC">Använda variabler</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01020200.html?DbPAR=BASIC">Använda objekt</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01030300.html?DbPAR=BASIC">Felsöka Basic-program</a></li>\
    <li><a target="_top" href="sv/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="sv/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="sv/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic till Python</a></li>\
    <li><a target="_top" href="sv/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python-skript hjälp</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Allmän information och användning av användargränssnitt</label><ul>\
    <li><a target="_top" href="sv/text/sbasic/python/main0000.html?DbPAR=BASIC">Python script</a></li>\
    <li><a target="_top" href="sv/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE for Python</a></li>\
    <li><a target="_top" href="sv/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="sv/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programmering med Python</label><ul>\
    <li><a target="_top" href="sv/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="sv/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python examples</a></li>\
    <li><a target="_top" href="sv/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Skript-utvecklingsverktyg</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice installation</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Ändra associationen till dokumenttyper i Microsoft Office</a></li>\
    <li><a target="_top" href="sv/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Felsäkert läge</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Vanliga hjälpavsnitt</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Allmän information</label><ul>\
    <li><a target="_top" href="sv/text/shared/main0400.html?DbPAR=SHARED">Kortkommandon</a></li>\
    <li><a target="_top" href="sv/text/shared/00/00000005.html?DbPAR=SHARED">Allmän ordlista</a></li>\
    <li><a target="_top" href="sv/text/shared/00/00000002.html?DbPAR=SHARED">Ordlista med Internet-termer</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/accessibility.html?DbPAR=SHARED">Tillgänglighet i LibreOffice</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/keyboard.html?DbPAR=SHARED">Kortkommandon (tillgänglighet i LibreOffice)</a></li>\
    <li><a target="_top" href="sv/text/shared/04/01010000.html?DbPAR=SHARED">Allmänna kortkommandon i LibreOffice</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/version_number.html?DbPAR=SHARED">Versioner och versionsnummer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice och Microsoft Office</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/ms_user.html?DbPAR=SHARED">Använda Microsoft Office och LibreOffice</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Jämföra termer i Microsoft Office och LibreOffice</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Om konvertering av Microsoft Office dokument</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Ändra associationen till dokumenttyper i Microsoft Office</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice alternativ</label><ul>\
    <li><a target="_top" href="sv/text/shared/optionen/01000000.html?DbPAR=SHARED">Alternativ</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01010100.html?DbPAR=SHARED">Användardata</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01010200.html?DbPAR=SHARED">Allmänt</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01010800.html?DbPAR=SHARED">Visa</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01010900.html?DbPAR=SHARED">Utskriftsalternativ</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01010300.html?DbPAR=SHARED">Sökvägar</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01010700.html?DbPAR=SHARED">Teckensnitt</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01030300.html?DbPAR=SHARED">Säkerhet</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01012000.html?DbPAR=SHARED">Application Colors</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01013000.html?DbPAR=SHARED">Tillgänglighet</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/java.html?DbPAR=SHARED">Avancerat</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01010400.html?DbPAR=SHARED">Lingvistik</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01010600.html?DbPAR=SHARED">Allmänt</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01020000.html?DbPAR=SHARED">Alternativ för att läsa in/spara</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01030000.html?DbPAR=SHARED">Internet-alternativ</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01040000.html?DbPAR=SHARED">Textdokumentalternativ</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01050000.html?DbPAR=SHARED">Alternativ för HTML dokument</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01060000.html?DbPAR=SHARED">Alternativ för kalkylblad</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01070000.html?DbPAR=SHARED">Presentationsalternativ</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01080000.html?DbPAR=SHARED">Ritalternativ</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01090000.html?DbPAR=SHARED">Formel</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01110000.html?DbPAR=SHARED">Diagramalternativ</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA-egenskaper</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01150000.html?DbPAR=SHARED">Alternativ för språkinställningar</a></li>\
    <li><a target="_top" href="sv/text/shared/optionen/01160000.html?DbPAR=SHARED">Alternativ för datakällor</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Guider</label><ul>\
    <li><a target="_top" href="sv/text/shared/autopi/01000000.html?DbPAR=SHARED">Guide</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Brevguiden</label><ul>\
    <li><a target="_top" href="sv/text/shared/autopi/01010000.html?DbPAR=SHARED">Brevguiden</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Faxguiden</label><ul>\
    <li><a target="_top" href="sv/text/shared/autopi/01020000.html?DbPAR=SHARED">Faxguiden</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Agendaguiden</label><ul>\
    <li><a target="_top" href="sv/text/shared/autopi/01040000.html?DbPAR=SHARED">Guiden Agenda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML-exportguide</label><ul>\
    <li><a target="_top" href="sv/text/shared/autopi/01110000.html?DbPAR=SHARED">HTML-export</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Dokumentkonverteringsguide</label><ul>\
    <li><a target="_top" href="sv/text/shared/autopi/01130000.html?DbPAR=SHARED">Dokumentkonverteraren</a></li>\
      </ul></li>\
    <li><a target="_top" href="sv/text/shared/autopi/01150000.html?DbPAR=SHARED">Guide för Eurokonverteraren</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Konfigurera LibreOffice</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/configure_overview.html?DbPAR=SHARED">Konfigurera LibreOffice</a></li>\
    <li><a target="_top" href="sv/text/shared/01/packagemanager.html?DbPAR=SHARED">Tillägg</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/flat_icons.html?DbPAR=SHARED">Ändra ikonvyer</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Lägga till knappar på verktygsrader</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/workfolder.html?DbPAR=SHARED">Ändra arbetskatalog</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Registrera en adressbok</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/formfields.html?DbPAR=SHARED">Infoga och redigera knappar</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Arbeta med användargränssnittet</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navigera för att snabbt flytta till objekt</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/navigator.html?DbPAR=SHARED">Navigator för dokumentöversikt</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/autohide.html?DbPAR=SHARED">Visa, förankra och dölja fönster</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/textmode_change.html?DbPAR=SHARED">Växla mellan infognings- och överskrivningsläge</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Använda verktygsrader</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digitala signaturer</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Om digitala signaturer</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Använda digitala signaturer</a></li>\
    <li><a target="_top" href="sv/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="sv/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="sv/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="sv/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="sv/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Utskrift, fax, skicka</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/labels_database.html?DbPAR=SHARED">Skriva ut adressetiketter</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Skriva ut i svartvitt</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/fax.html?DbPAR=SHARED">Skicka fax och konfigurera LibreOffice för faxmeddelanden</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Dra och släpp</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/dragdrop.html?DbPAR=SHARED">Dra-och-släppa inom ett LibreOffice dokument</a></li>\
    <li><a target="_top" href="sv/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Flytta och kopiera text i dokument</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kopiera tabellområden till textdokument</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kopiera grafik mellan dokument</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kopiera grafik från galleriet</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Dra-och-släpp med datakällvyn</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Kopiera och klistra in</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Kopiera ritobjekt till andra dokument</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kopiera grafik mellan dokument</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kopiera grafik från galleriet</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kopiera tabellområden till textdokument</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Grafer och diagram</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/chart_insert.html?DbPAR=SHARED">Infoga diagram</a></li>\
    <li><a target="_top" href="sv/text/schart/main0000.html?DbPAR=SHARED">Diagram i LibreOffice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Läsa in, spara, importera, exportera, PDF</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/doc_open.html?DbPAR=SHARED">Öppna dokument</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/import_ms.html?DbPAR=SHARED">Öppna dokument som sparats med ett annat format</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/doc_save.html?DbPAR=SHARED">Spara dokument</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Spara dokument automatiskt</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/export_ms.html?DbPAR=SHARED">Spara dokument i andra format</a></li>\
    <li><a target="_top" href="sv/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Exportera som PDF</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Importera och exportera data i textformat</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Länkar och referenser</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Infoga hyperlänkar</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Relativa och absoluta länkar</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Redigera hyperlänkar</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Spåra dokumentändringar</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Jämföra dokumentversioner</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Koppla versioner</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Registrera ändringar</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/redlining.html?DbPAR=SHARED">Registrera och visa ändringar</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Godkänna och ignorera ändringar</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Versionshantering</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etiketter och visitkort</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/labels.html?DbPAR=SHARED">Skapa och skriva ut etiketter och visitkort</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Infoga extern data</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/copytable2application.html?DbPAR=SHARED">Infoga data från kalkylblad</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/copytext2application.html?DbPAR=SHARED">Infoga data från textdokument</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Infoga, redigera och spara bitmappar</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Lägga till grafik i galleriet</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automatiska funktioner</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Stänga av automatisk URL-igenkänning</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Att söka och ersätta</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/data_search2.html?DbPAR=SHARED">Söka med ett formulärfilter</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_search.html?DbPAR=SHARED">Söka i tabeller och formulärdokument</a></li>\
    <li><a target="_top" href="sv/text/shared/01/02100001.html?DbPAR=SHARED">Lista med reguljära uttryck</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guider</label><ul>\
    <li><a target="_top" href="sv/text/shared/guide/linestyles.html?DbPAR=SHARED">Tillämpa linjestilar</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/text_color.html?DbPAR=SHARED">Ändra textfärg</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/change_title.html?DbPAR=SHARED">Ändra ett dokuments rubrik</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/round_corner.html?DbPAR=SHARED">Skapa runda hörn</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/background.html?DbPAR=SHARED">Definiera bakgrundsfärger eller bakgrundsgrafik</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Definiera linjestilar</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Redigera grafiska objekt</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/line_intext.html?DbPAR=SHARED">Rita linjer i text</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/aaa_start.html?DbPAR=SHARED">De första stegen</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Infoga objekt från galleriet</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Infoga specialtecken</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/tabs.html?DbPAR=SHARED">Infoga och redigera tabbstopp</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Using Remote Files</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/protection.html?DbPAR=SHARED">Skydda innehåll i LibreOffice</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Skydda poster</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Ange maximalt utskriftsområde på en sida</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/measurement_units.html?DbPAR=SHARED">Välja måttenheter</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/language_select.html?DbPAR=SHARED">Välja dokumentspråk</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Tabellutkast</a></li>\
    <li><a target="_top" href="sv/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Stänga av punktuppställningstecken för enskilda stycken</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
