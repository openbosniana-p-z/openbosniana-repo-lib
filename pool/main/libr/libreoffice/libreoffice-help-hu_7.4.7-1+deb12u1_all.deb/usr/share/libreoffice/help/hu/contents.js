document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Szöveges dokumentumok (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Általános információk és a felhasználói felület használata</label><ul>\
    <li><a target="_top" href="hu/text/swriter/main0000.html?DbPAR=WRITER">Üdvözöljük a LibreOffice Writer Súgójában</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0503.html?DbPAR=WRITER">A LibreOffice Writer funkciói</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/main.html?DbPAR=WRITER">A LibreOffice Writer használati utasítása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Ablakok dokkolása és átméretezése</a></li>\
    <li><a target="_top" href="hu/text/swriter/04/01020000.html?DbPAR=WRITER">A LibreOffice Writer gyorsbillentyűi</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/words_count.html?DbPAR=WRITER">Szavak számlálása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/keyboard.html?DbPAR=WRITER">Gyorsbillentyűk használata (LibreOffice Writer kisegítő lehetőségei)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Parancs- és menüreferencia</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menük</label><ul>\
    <li><a target="_top" href="hu/text/swriter/main0100.html?DbPAR=WRITER">Menük</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0101.html?DbPAR=WRITER">Fájl</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0102.html?DbPAR=WRITER">Szerkesztés</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0103.html?DbPAR=WRITER">Nézet</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0104.html?DbPAR=WRITER">Beszúrás</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0105.html?DbPAR=WRITER">Formátum</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0115.html?DbPAR=WRITER">Stílusok (menü)</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0110.html?DbPAR=WRITER">Táblázat</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0120.html?DbPAR=WRITER">Űrlap menü</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0106.html?DbPAR=WRITER">Eszközök</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0107.html?DbPAR=WRITER">Ablak</a></li>\
    <li><a target="_top" href="hu/text/shared/main0108.html?DbPAR=WRITER">Súgó</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Eszköztárak</label><ul>\
    <li><a target="_top" href="hu/text/swriter/main0200.html?DbPAR=WRITER">Eszköztárak</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0206.html?DbPAR=WRITER">Felsorolás és számozás eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0205.html?DbPAR=WRITER">Rajzobjektum tulajdonságai eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="hu/text/shared/main0226.html?DbPAR=WRITER">Űrlaptervező eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0213.html?DbPAR=WRITER">Űrlapnavigáció eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0202.html?DbPAR=WRITER">Formázás eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0214.html?DbPAR=WRITER">Képlet eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0215.html?DbPAR=WRITER">Keret eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0203.html?DbPAR=WRITER">Kép eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0216.html?DbPAR=WRITER">OLE-objektum eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0210.html?DbPAR=WRITER">Nyomtatási kép eszköztár (Writer)</a></li>\
    <li><a target="_top" href="hu/text/shared/main0214.html?DbPAR=WRITER">Lekérdezéstervező eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0213.html?DbPAR=WRITER">Vonalzók</a></li>\
    <li><a target="_top" href="hu/text/shared/main0201.html?DbPAR=WRITER">Standard eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0208.html?DbPAR=WRITER">Állapotsor (Writer)</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0204.html?DbPAR=WRITER">Táblázat eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0212.html?DbPAR=WRITER">Táblaadatok eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/main0220.html?DbPAR=WRITER">Szövegobjektum eszköztár</a></li>\
    <li><a target="_top" href="hu/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Változások követése eszköztár</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navigálás szöveges dokumentumokban</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navigálás és kijelölés a billentyűzet segítségével</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Szöveg áthelyezése és másolása dokumentumokban</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Dokumentum újrarendezése a Navigátorral</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Hiperhivatkozások beszúrása a Navigátorral</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/navigator.html?DbPAR=WRITER">Navigátor a szöveges dokumentumokhoz</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Közvetlen kurzor használata</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Szöveges dokumentumok formázása</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Oldal tájolásának módosítása (Fekvő vagy Álló)</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/text_capital.html?DbPAR=WRITER">Szöveg betűinek módosítása nagy- vagy kisbetűsre</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Szöveg elrejtése</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Különböző élőfejek és élőlábak megadása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Fejezetnév és fejezetszám beszúrása élőfejbe és élőlábba</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Szövegformázás alkalmazása gépelés közben</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/reset_format.html?DbPAR=WRITER">Betűjellemzők alapállapotba állítása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Stílusok alkalmazása a Kitöltés formátummal módban</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/wrap.html?DbPAR=WRITER">Szöveg körbefuttatása objektumok körül</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Keret használata szöveg oldalon történő középre igazításához</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Szöveg kiemelése</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Szöveg forgatása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/page_break.html?DbPAR=WRITER">Oldaltörések beszúrása és törlése</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Oldalstílusok létrehozása és alkalmazása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/subscript.html?DbPAR=WRITER">Szöveg áthelyezése felső vagy alsó indexbe</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Sablonok és stílusok</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Sablonok és stílusok</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Páros és páratlan sorszámú oldalak különböző oldalstílussal</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/change_header.html?DbPAR=WRITER">Oldalstílus létrehozása az aktuális oldal alapján</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/load_styles.html?DbPAR=WRITER">Stílusok használata más dokumentumból vagy sablonból</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Új stílusok létrehozása kijelölésből</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Stílusok frissítése kijelölésből</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/template_manager.html?DbPAR=WRITER">Template Manager</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Grafikák szöveges dokumentumokban</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Képek beszúrása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Kép beszúrása fájlból</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Kép beszúrása a Képtárból áthúzással</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Beolvasott kép beszúrása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Calc-diagram beszúrása szöveges dokumentumba</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Kép beszúrása a LibreOffice Draw vagy Impress programból</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Táblázatok szöveges dokumentumokban</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Számfelismerés be- és kikapcsolása táblázatokban</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/tablemode.html?DbPAR=WRITER">Sorok és oszlopok módosítása billentyűzettel</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/table_delete.html?DbPAR=WRITER">Táblázatok vagy táblázatok tartalmának törlése</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/table_insert.html?DbPAR=WRITER">Táblázatok beszúrása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Táblázatfejléc megismétlése egy új oldalon</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Szöveges táblázat sorainak és oszlopainak átméretezése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objektumok szöveges dokumentumokban</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Objektumok pozicionálása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/wrap.html?DbPAR=WRITER">Szöveg körbefuttatása objektumok körül</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Szakaszok és keretek szöveges dokumentumokban</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/sections.html?DbPAR=WRITER">Szakaszok használata</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/section_edit.html?DbPAR=WRITER">Szakaszok szerkesztése</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/section_insert.html?DbPAR=WRITER">Szakaszok beszúrása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Tartalomjegyzékek és tárgymutatók</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Egyéni jegyzékek</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Tartalomjegyzék létrehozása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/indices_index.html?DbPAR=WRITER">Betűrendes tárgymutatók létrehozása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Több dokumentumot lefedő jegyzékek</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Irodalomjegyzék létrehozása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Jegyzék- vagy táblázatbejegyzés szerkesztése és törlése</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Tárgymutatók és Tartalomjegyzékek frissítése, szerkesztése és törlése</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Tárgymutató- vagy tartalomjegyzék-bejegyzések megadása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/indices_form.html?DbPAR=WRITER">A tárgymutató és a tartalomjegyzék formázása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Mezők szöveges dokumentumokban</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/fields.html?DbPAR=WRITER">A mezőkről általában</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/fields_date.html?DbPAR=WRITER">Rögzített vagy változó dátum beszúrása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/field_convert.html?DbPAR=WRITER">Mező átalakítása szöveggé</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Számítások szöveges dokumentumokban</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Táblázatokban végzett számítások</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/calculate.html?DbPAR=WRITER">Számítások szöveges dokumentumokban</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Képlet kiszámítása és eredményének beillesztése szöveges dokumentumba</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Cellaösszegek számítása táblázatokban</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Összetett képletek kiszámítása szöveges dokumentumokban</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Egy táblázatszámítás eredményének megjelenítése egy másik táblázatban</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Speciális szövegelemek</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/captions.html?DbPAR=WRITER">Feliratok használata</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Feltételes szöveg</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Feltételes szöveg oldalak számához</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/fields_date.html?DbPAR=WRITER">Rögzített vagy változó dátum beszúrása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Beviteli mezők hozzáadása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Folytatólagos oldalak oldalszámának beszúrása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Oldalszámok beszúrása élőlábba</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Szöveg elrejtése</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Különböző élőfejek és élőlábak megadása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Fejezetnév és fejezetszám beszúrása élőfejbe és élőlábba</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Felhasználói adatok lekérdezése mezőkben és feltételekben</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Lábjegyzetek és végjegyzetek beszúrása és szerkesztése</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Térköz a lábjegyzetek között</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/header_footer.html?DbPAR=WRITER">Az élőfejekről és élőlábakról</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Élőfejek és élőlábak formázása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/text_animation.html?DbPAR=WRITER">Szöveg animálása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Körlevél létrehozása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automatikus függvények</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Kivételek hozzáadása az Automatikus javítás listájához</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/autotext.html?DbPAR=WRITER">Szövegblokk használata</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Számozást vagy Felsorolást tartalmazó lista létrehozása gépelés közben</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/auto_off.html?DbPAR=WRITER">Automatikus javítás kikapcsolása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatikus helyesírás-ellenőrzés</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Számfelismerés be- és kikapcsolása táblázatokban</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Elválasztás</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Számozás és listák</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Fejezetszámok hozzáadása feliratokhoz</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Számozást vagy Felsorolást tartalmazó lista létrehozása gépelés közben</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Számozott listák összevonása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Sorszámok hozzáadása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Számtartományok megadása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Számozás hozzáadása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Felsorolásjelek hozzáadása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Helyesírás-ellenőrzés, szinonimaszótár és nyelvek</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatikus helyesírás-ellenőrzés</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Szavak törlése egyéni szótárból</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Szókincstár</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Helyesírás és nyelvhelyesség ellenőrzése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Hibaelhárítási tippek</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Szöveg beszúrása egy oldal tetején lévő táblázat elé</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Ugrás egy megadott könyvjelzőre</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Betöltés, mentés, importálás, exportálás és anonimizálás</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/send2html.html?DbPAR=WRITER">Szöveges dokumentumok mentése HTML formátumban</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Teljes szöveges dokumentum beszúrása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Fődokumentumok</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Fődokumentumok és aldokumentumok</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Hivatkozások és referenciák</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/references.html?DbPAR=WRITER">Kereszthivatkozások beszúrása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Hiperhivatkozások beszúrása a Navigátorral</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Nyomtatás</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/print_selection.html?DbPAR=WRITER">A nyomtatandó anyagok kijelölése</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Nyomtató papírtálcájának kiválasztása</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/print_preview.html?DbPAR=WRITER">Oldal előnézetének megtekintése nyomtatás előtt</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/print_small.html?DbPAR=WRITER">Több oldal nyomtatása egy lapra</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Oldalstílusok létrehozása és alkalmazása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Keresés és csere</label><ul>\
    <li><a target="_top" href="hu/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="hu/text/shared/01/02100001.html?DbPAR=WRITER">Reguláris kifejezések listája</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML-dokumentumok (Writer Web)</label><ul>\
    <li><a target="_top" href="hu/text/shared/07/09000000.html?DbPAR=WRITER">Weboldalak</a></li>\
    <li><a target="_top" href="hu/text/shared/02/01170700.html?DbPAR=WRITER">HTML-szűrők és űrlapok</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/send2html.html?DbPAR=WRITER">Szöveges dokumentumok mentése HTML formátumban</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Táblázatok (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Általános információk és a felhasználói felület használata</label><ul>\
    <li><a target="_top" href="hu/text/scalc/main0000.html?DbPAR=CALC">Üdvözöljük a LibreOffice Calc Súgójában</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0503.html?DbPAR=CALC">A LibreOffice Calc funkciói</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/keyboard.html?DbPAR=CALC">Gyorsbillentyűk (LibreOffice Calc kisegítő lehetőségei)</a></li>\
    <li><a target="_top" href="hu/text/scalc/04/01020000.html?DbPAR=CALC">Gyorsbillentyűk munkafüzetekhez</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Számítási pontosság</a></li>\
    <li><a target="_top" href="hu/text/scalc/05/02140000.html?DbPAR=CALC">Hibakódok a LibreOffice Calc programban</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060112.html?DbPAR=CALC">Kiegészítők programozása a LibreOffice Calc programban</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/main.html?DbPAR=CALC">A LibreOffice Calc használati utasítása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Parancs- és menüreferencia</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menük</label><ul>\
    <li><a target="_top" href="hu/text/scalc/main0100.html?DbPAR=CALC">Menük</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0101.html?DbPAR=CALC">Fájl</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0102.html?DbPAR=CALC">Szerkesztés</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0103.html?DbPAR=CALC">Nézet</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0104.html?DbPAR=CALC">Beszúrás</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0105.html?DbPAR=CALC">Formátum</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0116.html?DbPAR=CALC">Munkalap</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0112.html?DbPAR=CALC">Adatok</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0106.html?DbPAR=CALC">Eszközök</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0107.html?DbPAR=CALC">Ablak</a></li>\
    <li><a target="_top" href="hu/text/shared/main0108.html?DbPAR=CALC">Súgó</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Eszköztárak</label><ul>\
    <li><a target="_top" href="hu/text/scalc/main0200.html?DbPAR=CALC">Eszköztárak</a></li>\
    <li><a target="_top" href="hu/text/shared/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0202.html?DbPAR=CALC">Formázás eszköztár</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0203.html?DbPAR=CALC">Rajzobjektum tulajdonságai eszköztár</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0205.html?DbPAR=CALC">Szövegformázás eszköztár</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0206.html?DbPAR=CALC">Képlet eszköztár</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0208.html?DbPAR=CALC">Állapotsor</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0210.html?DbPAR=CALC">Nyomtatási kép eszköztár</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0214.html?DbPAR=CALC">Kép eszköztár</a></li>\
    <li><a target="_top" href="hu/text/scalc/main0218.html?DbPAR=CALC">Eszközök eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0201.html?DbPAR=CALC">Standard eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0212.html?DbPAR=CALC">Táblaadatok eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0213.html?DbPAR=CALC">Űrlapnavigáció eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0214.html?DbPAR=CALC">Lekérdezéstervező eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0226.html?DbPAR=CALC">Űrlaptervező eszköztár</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Függvénytípusok és operátorok</label><ul>\
    <li><a target="_top" href="hu/text/scalc/01/04060000.html?DbPAR=CALC">Függvénytündér</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060100.html?DbPAR=CALC">Függvények kategória szerint</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060107.html?DbPAR=CALC">Tömbfüggvények</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060120.html?DbPAR=CALC">Bitműveletek függvényei</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060101.html?DbPAR=CALC">Adatbázis-függvények</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060102.html?DbPAR=CALC">Dátum- és időfüggvények</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060103.html?DbPAR=CALC">Pénzügyi függvények - első rész</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060119.html?DbPAR=CALC">Pénzügyi függvények - második rész</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060118.html?DbPAR=CALC">Pénzügyi függvények - harmadik rész</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060104.html?DbPAR=CALC">Információs függvények</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060105.html?DbPAR=CALC">Logikai függvények</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060106.html?DbPAR=CALC">Matematikai függvények</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060108.html?DbPAR=CALC">Statisztikai függvények</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060181.html?DbPAR=CALC">Statisztikai függvények - első rész</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060182.html?DbPAR=CALC">Statisztikai függvények - második rész</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060183.html?DbPAR=CALC">Statisztikai függvények - harmadik rész</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060184.html?DbPAR=CALC">Statisztikai függvények - negyedik rész</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060185.html?DbPAR=CALC">Statisztikai függvények - ötödik rész</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060109.html?DbPAR=CALC">Munkafüzetfüggvények</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060110.html?DbPAR=CALC">Szövegfüggvények</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060111.html?DbPAR=CALC">Kiegészítő függvények</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060115.html?DbPAR=CALC">Kiegészítő függvények; Műszaki függvények listája - első rész</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060116.html?DbPAR=CALC">Kiegészítő függvények; Műszaki függvények listája - második rész</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/04060199.html?DbPAR=CALC">Operátorok a LibreOffice Calc programban</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Egyéni függvények</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Betöltés, mentés, importálás, exportálás és anonimizálás</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/webquery.html?DbPAR=CALC">Külső adat beszúrása táblázatba (WebQuery)</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/html_doc.html?DbPAR=CALC">Munkalapok mentése és megnyitása HTML formátumban</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/csv_formula.html?DbPAR=CALC">Szövegfájlok importálása és exportálása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formázás</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/text_rotate.html?DbPAR=CALC">Szöveg forgatása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/text_wrap.html?DbPAR=CALC">Többsoros szöveg írása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/text_numbers.html?DbPAR=CALC">Számok formázása szövegként</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/super_subscript.html?DbPAR=CALC">Szöveg felső és alsó indexben</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/row_height.html?DbPAR=CALC">Sormagasság vagy oszlopszélesség módosítása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Feltételes formázás alkalmazása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Negatív számok kiemelése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Formátumok hozzárendelése képlet alapján</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Kezdő nullákkal rendelkező szám megadása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/format_table.html?DbPAR=CALC">Munkafüzetek formázása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/format_value.html?DbPAR=CALC">Számok formázása tizedesekkel</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/value_with_name.html?DbPAR=CALC">Cellák elnevezése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/table_rotate.html?DbPAR=CALC">Táblázatok forgatása (transzponálás)</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/rename_table.html?DbPAR=CALC">Munkalapok átnevezése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx évek</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Lekerekített számok használata</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/currency_format.html?DbPAR=CALC">Cellák pénznem-formátumban</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/autoformat.html?DbPAR=CALC">Automatikus formázás használata táblázatokhoz</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/note_insert.html?DbPAR=CALC">Megjegyzések beírása és szerkesztése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/design.html?DbPAR=CALC">Témák kiválasztása munkalapokhoz</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Törtek megadása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Szűrés és rendezés</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/filters.html?DbPAR=CALC">Szűrők alkalmazása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/autofilter.html?DbPAR=CALC">Automatikus szűrő alkalmazása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/sorted_list.html?DbPAR=CALC">Rendezett listák alkalmazása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Nyomtatás</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/print_title_row.html?DbPAR=CALC">Sorok és oszlopok nyomtatása az összes oldalra</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/print_landscape.html?DbPAR=CALC">Munkalapok nyomtatása fekvő formátumban</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/print_details.html?DbPAR=CALC">Munkalap részleteinek nyomtatása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/print_exact.html?DbPAR=CALC">Nyomtatandó oldalak számának meghatározása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Adattartományok</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/database_define.html?DbPAR=CALC">Adatbázis-tartományok megadása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/database_filter.html?DbPAR=CALC">Cellatartományok szűrése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/database_sort.html?DbPAR=CALC">Adatok rendezése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Kimutatástábla</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/datapilot.html?DbPAR=CALC">Kimutatástábla</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Kimutatástáblák létrehozása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Kimutatástáblák törlése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Kimutatástáblák szerkesztése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Kimutatástáblák szűrése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Kimutatástábla kimeneti tartományainak kiválasztása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Kimutatástáblák frissítése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Kimutatásdiagram</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/pivotchart.html?DbPAR=CALC">Kimutatásdiagram</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Esetek</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/scenario.html?DbPAR=CALC">Esetek használata</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Részösszegek</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Hivatkozások</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Címek és hivatkozások, abszolút és relatív</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/cellreferences.html?DbPAR=CALC">Hivatkozás egy másik dokumentumban lévő cellára</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Hivatkozás más munkalapokra és URL-ekre</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Hivatkozás cellákra „fogd és vidd” módszerrel</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/address_auto.html?DbPAR=CALC">Nevek felismerése címzésként</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Megjelenítés, kijelölés, másolás</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/table_view.html?DbPAR=CALC">Táblázatnézetek megváltoztatása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/formula_value.html?DbPAR=CALC">Képletek vagy értékek megjelenítése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/line_fix.html?DbPAR=CALC">Sorok és oszlopok fejlécként való rögzítése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navigálás munkalapfüleken keresztül</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Másolás több munkalapra</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/cellcopy.html?DbPAR=CALC">Csak látható cellák másolása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/mark_cells.html?DbPAR=CALC">Több cella kijelölése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Képletek és számítások</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/formulas.html?DbPAR=CALC">Számítás képletekkel</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/formula_copy.html?DbPAR=CALC">Képletek másolása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/formula_enter.html?DbPAR=CALC">Képletek megadása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/formula_value.html?DbPAR=CALC">Képletek vagy értékek megjelenítése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/calculate.html?DbPAR=CALC">Számítás munkafüzetekben</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/calc_date.html?DbPAR=CALC">Számolás dátumokkal és idővel</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/calc_series.html?DbPAR=CALC">Sorozatok automatikus számítása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Időkülönbségek számítása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/matrixformula.html?DbPAR=CALC">Mátrixok megadása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Védelem</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/cell_protect.html?DbPAR=CALC">Cellák módosításokkal szembeni védelme</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Cellavédelem megszüntetése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Calc-makrók írása</label><ul>\
    <li><a target="_top" href="hu/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="hu/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatting Borders in Calc with Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Egyebek</label><ul>\
    <li><a target="_top" href="hu/text/scalc/guide/auto_off.html?DbPAR=CALC">Automatikus módosítások kikapcsolása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/consolidate.html?DbPAR=CALC">Adatok összesítése</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/goalseek.html?DbPAR=CALC">Célértékkeresés alkalmazása</a></li>\
    <li><a target="_top" href="hu/text/scalc/01/solver.html?DbPAR=CALC">Megoldó</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/multioperation.html?DbPAR=CALC">Többszörös műveletek alkalmazása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/multitables.html?DbPAR=CALC">Több munkalap alkalmazása</a></li>\
    <li><a target="_top" href="hu/text/scalc/guide/validity.html?DbPAR=CALC">Cellatartalmak érvényessége</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Bemutatók (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Általános információk és a felhasználói felület használata</label><ul>\
    <li><a target="_top" href="hu/text/simpress/main0000.html?DbPAR=IMPRESS">Üdvözöljük a LibreOffice Impress Súgójában</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0503.html?DbPAR=IMPRESS">A LibreOffice Impress funkciói</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Gyorsbillentyűk használata a LibreOffice Impressben</a></li>\
    <li><a target="_top" href="hu/text/simpress/04/01020000.html?DbPAR=IMPRESS">A LibreOffice Impress gyorsbillentyűi</a></li>\
    <li><a target="_top" href="hu/text/simpress/04/presenter.html?DbPAR=IMPRESS">Az Előadói konzol billentyűparancsai</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/main.html?DbPAR=IMPRESS">A LibreOffice Impress használati utasítása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Parancs- és menüreferencia</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menük</label><ul>\
    <li><a target="_top" href="hu/text/simpress/main0100.html?DbPAR=IMPRESS">Menük</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0101.html?DbPAR=IMPRESS">Fájl</a></li>\
    <li><a target="_top" href="hu/text/simpress/main_edit.html?DbPAR=IMPRESS">Szerkesztés</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0103.html?DbPAR=IMPRESS">Nézet</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0104.html?DbPAR=IMPRESS">Beszúrás</a></li>\
    <li><a target="_top" href="hu/text/simpress/main_format.html?DbPAR=IMPRESS">Formátum</a></li>\
    <li><a target="_top" href="hu/text/simpress/main_slide.html?DbPAR=IMPRESS">Dia</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0114.html?DbPAR=IMPRESS">Diavetítés</a></li>\
    <li><a target="_top" href="hu/text/simpress/main_tools.html?DbPAR=IMPRESS">Eszközök</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0107.html?DbPAR=IMPRESS">Ablak</a></li>\
    <li><a target="_top" href="hu/text/shared/main0108.html?DbPAR=IMPRESS">Súgó</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Eszköztárak</label><ul>\
    <li><a target="_top" href="hu/text/simpress/main0200.html?DbPAR=IMPRESS">Eszköztárak</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0210.html?DbPAR=IMPRESS">Rajz eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0227.html?DbPAR=IMPRESS">Pontok szerkesztése eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="hu/text/shared/main0226.html?DbPAR=IMPRESS">Űrlaptervező eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0213.html?DbPAR=IMPRESS">Űrlapnavigáció eszköztár</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0214.html?DbPAR=IMPRESS">Kép eszköztár</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0202.html?DbPAR=IMPRESS">Vonal és kitöltés eszköztár</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0213.html?DbPAR=IMPRESS">Beállítások eszköztár</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0211.html?DbPAR=IMPRESS">Vázlat eszköztár</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0209.html?DbPAR=IMPRESS">Vonalzók</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0212.html?DbPAR=IMPRESS">Diarendező eszköztár</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0204.html?DbPAR=IMPRESS">Dia nézet eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0201.html?DbPAR=IMPRESS">Standard eszköztár</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0206.html?DbPAR=IMPRESS">Állapotsor</a></li>\
    <li><a target="_top" href="hu/text/shared/main0204.html?DbPAR=IMPRESS">Táblázat eszköztár</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0203.html?DbPAR=IMPRESS">Szövegformázás eszköztár</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Betöltés, mentés, importálás, exportálás és anonimizálás</label><ul>\
    <li><a target="_top" href="hu/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Bemutató mentése HTML formátumba</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/html_import.html?DbPAR=IMPRESS">HTML-oldalak importálása bemutatókba</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Animációk exportálása GIF formátumba</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Munkafüzetek beillesztése diákba</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Képek beszúrása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formázás</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Vonal- és nyílstílusok betöltése</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Egyéni színek meghatározása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Színátmenetek készítése</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Színek cseréje</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Elrendezés, objektumok igazítása és elosztása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/background.html?DbPAR=IMPRESS">A dia háttérkitöltésének módosítása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/footer.html?DbPAR=IMPRESS">Élőfej és élőláb hozzáadása minden diához</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Objektumok áthelyezése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Nyomtatás</label><ul>\
    <li><a target="_top" href="hu/text/simpress/guide/printing.html?DbPAR=IMPRESS">Bemutatók nyomtatása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Dia nyomtatása a papírnak megfelelő méretben</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Hatások</label><ul>\
    <li><a target="_top" href="hu/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Animációk exportálása GIF formátumba</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Objektumok animálása bemutatók diáiban</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Diaátmenet animálása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Két objektum átúsztatása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Animált GIF-képek létrehozása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objektumok, grafikák és bitképek</label><ul>\
    <li><a target="_top" href="hu/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Objektumok összevonása és alakzatok létrehozása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Objektumok csoportosítása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Körcikkek és -szeletek rajzolása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Objektumok megkettőzése</a></li>\
    <li><a target="_top" href="hu/text/simpress/02/10030000.html?DbPAR=IMPRESS">Átalakítások</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Objektumok forgatása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Térbeli objektum összeállítása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Vonalak összekötése</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Szövegkarakterek átalakítása rajzobjektumokká</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Bitképek átalakítása vektorgrafikává</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Síkbeli objektumok görbékké, sokszögekké és térbeli objektumokká alakítása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Vonal- és nyílstílusok betöltése</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Görbék rajzolása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Görbék szerkesztése</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Képek beszúrása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Munkafüzetek beillesztése diákba</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Objektumok áthelyezése</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Alul levő objektumok kijelölése</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Folyamatábra létrehozása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Szöveg bemutatókban</label><ul>\
    <li><a target="_top" href="hu/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Szöveg hozzáadása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Szövegkarakterek átalakítása rajzobjektumokká</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Megjelenítés</label><ul>\
    <li><a target="_top" href="hu/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Diák sorrendjének módosítása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Nagyítás a numerikus billentyűzet segítségével</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Diavetítések</label><ul>\
    <li><a target="_top" href="hu/text/simpress/guide/show.html?DbPAR=IMPRESS">Diavetítés elindítása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/individual.html?DbPAR=IMPRESS">Egyéni diavetítés létrehozása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Diaváltások időzítésének kipróbálása</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Rajzok (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Általános információk és a felhasználói felület használata</label><ul>\
    <li><a target="_top" href="hu/text/sdraw/main0000.html?DbPAR=DRAW">Üdvözöljük a LibreOffice Draw Súgójában</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main0503.html?DbPAR=DRAW">A LibreOffice Draw funkciói</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Rajzobjektumok gyorsbillentyűi</a></li>\
    <li><a target="_top" href="hu/text/sdraw/04/01020000.html?DbPAR=DRAW">Rajzok gyorsbillentyűi</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/main.html?DbPAR=DRAW">Útmutatás a LibreOffice Draw használatához</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Parancs- és menüreferencia</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menük</label><ul>\
    <li><a target="_top" href="hu/text/sdraw/main0100.html?DbPAR=DRAW">Menük</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main0101.html?DbPAR=DRAW">Fájl</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main_edit.html?DbPAR=DRAW">Szerkesztés</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main0103.html?DbPAR=DRAW">View (menu in Draw)</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main_insert.html?DbPAR=DRAW">Beszúrás</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main_format.html?DbPAR=DRAW">Formátum</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main_page.html?DbPAR=DRAW">Oldal</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main_shape.html?DbPAR=DRAW">Alakzat</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main_tools.html?DbPAR=DRAW">Eszközök</a></li>\
    <li><a target="_top" href="hu/text/simpress/main0107.html?DbPAR=DRAW">Ablak</a></li>\
    <li><a target="_top" href="hu/text/shared/main0108.html?DbPAR=DRAW">Súgó</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Eszköztárak</label><ul>\
    <li><a target="_top" href="hu/text/sdraw/main0200.html?DbPAR=DRAW">Eszköztárak</a></li>\
    <li><a target="_top" href="hu/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">Térbeli beállítások</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main0210.html?DbPAR=DRAW">Rajz eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0227.html?DbPAR=DRAW">Pontok szerkesztése eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="hu/text/shared/main0226.html?DbPAR=DRAW">Űrlaptervező eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0213.html?DbPAR=DRAW">Űrlapnavigáció eszköztár</a></li>\
    <li><a target="_top" href="hu/text/sdraw/main0213.html?DbPAR=DRAW">Beállítások eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0201.html?DbPAR=DRAW">Standard eszköztár</a></li>\
    <li><a target="_top" href="hu/text/shared/main0204.html?DbPAR=DRAW">Táblázat eszköztár</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Betöltés, mentés, importálás és exportálás</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Képek beszúrása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formázás</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Vonal- és nyílstílusok betöltése</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/color_define.html?DbPAR=DRAW">Egyéni színek meghatározása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/gradient.html?DbPAR=DRAW">Színátmenetek készítése</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Színek cseréje</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Elrendezés, objektumok igazítása és elosztása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/background.html?DbPAR=DRAW">A dia háttérkitöltésének módosítása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/move_object.html?DbPAR=DRAW">Objektumok áthelyezése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Nyomtatás</label><ul>\
    <li><a target="_top" href="hu/text/simpress/guide/printing.html?DbPAR=DRAW">Bemutatók nyomtatása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Dia nyomtatása a papírnak megfelelő méretben</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Hatások</label><ul>\
    <li><a target="_top" href="hu/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Két objektum átúsztatása</a></li>\
    <li><a target="_top" href="hu/text/shared/01/05350000.html?DbPAR=DRAW">Térhatás</a></li>\
    <li><a target="_top" href="hu/text/simpress/02/10030000.html?DbPAR=DRAW">Átalakítások</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objektumok, grafikák és bitképek</label><ul>\
    <li><a target="_top" href="hu/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Objektumok összevonása és alakzatok létrehozása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Körcikkek és -szeletek rajzolása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Objektumok megkettőzése</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Objektumok forgatása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Térbeli objektum összeállítása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Vonalak összekötése</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/text2curve.html?DbPAR=DRAW">Szövegkarakterek átalakítása rajzobjektumokká</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/vectorize.html?DbPAR=DRAW">Bitképek átalakítása vektorgrafikává</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/3d_create.html?DbPAR=DRAW">Síkbeli objektumok görbékké, sokszögekké és térbeli objektumokká alakítása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Vonal- és nyílstílusok betöltése</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/line_draw.html?DbPAR=DRAW">Görbék rajzolása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/line_edit.html?DbPAR=DRAW">Görbék szerkesztése</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Képek beszúrása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/table_insert.html?DbPAR=DRAW">Munkafüzetek beillesztése diákba</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/move_object.html?DbPAR=DRAW">Objektumok áthelyezése</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/select_object.html?DbPAR=DRAW">Alul levő objektumok kijelölése</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/orgchart.html?DbPAR=DRAW">Folyamatábra létrehozása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Csoportok és rétegek</label><ul>\
    <li><a target="_top" href="hu/text/sdraw/guide/groups.html?DbPAR=DRAW">Objektumok csoportosítása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/layers.html?DbPAR=DRAW">Rétegek</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Rétegek beszúrása</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Rétegek használata</a></li>\
    <li><a target="_top" href="hu/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Objektumok áthelyezése más rétegre</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Szöveg rajzokban</label><ul>\
    <li><a target="_top" href="hu/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Szöveg hozzáadása</a></li>\
    <li><a target="_top" href="hu/text/simpress/guide/text2curve.html?DbPAR=DRAW">Szövegkarakterek átalakítása rajzobjektumokká</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Megjelenítés</label><ul>\
    <li><a target="_top" href="hu/text/simpress/guide/change_scale.html?DbPAR=DRAW">Nagyítás a numerikus billentyűzet segítségével</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Adatbázis-funkciók (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Általános információk</label><ul>\
    <li><a target="_top" href="hu/text/sdatabase/main.html?DbPAR=BASE">LibreOffice-adatbázis</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/database_main.html?DbPAR=BASE">Adatbázisok áttekintése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_new.html?DbPAR=BASE">Új adatbázis létrehozása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_tables.html?DbPAR=BASE">Munka a táblákkal</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_queries.html?DbPAR=BASE">Munka a lekérdezésekkel</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_forms.html?DbPAR=BASE">Munka az űrlapokkal</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_reports.html?DbPAR=BASE">Jelentések létrehozása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_register.html?DbPAR=BASE">Adatbázis regisztrálása és törlése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_im_export.html?DbPAR=BASE">Adatok importálása és exportálása a Base-ben</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_enter_sql.html?DbPAR=BASE">SQL-parancsok végrehajtása</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formulák (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Általános információk és a felhasználói felület használata</label><ul>\
    <li><a target="_top" href="hu/text/smath/main0000.html?DbPAR=MATH">Üdvözöljük a LibreOffice Math Súgójában</a></li>\
    <li><a target="_top" href="hu/text/smath/main0503.html?DbPAR=MATH">LibreOffice Math funkciói</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice-képletelemek</label><ul>\
    <li><a target="_top" href="hu/text/smath/01/03090100.html?DbPAR=MATH">Egy- és kétoperandusú operátorok</a></li>\
    <li><a target="_top" href="hu/text/smath/01/03090200.html?DbPAR=MATH">Relációk</a></li>\
    <li><a target="_top" href="hu/text/smath/01/03090800.html?DbPAR=MATH">Halmazműveletek</a></li>\
    <li><a target="_top" href="hu/text/smath/01/03090400.html?DbPAR=MATH">Függvények</a></li>\
    <li><a target="_top" href="hu/text/smath/01/03090300.html?DbPAR=MATH">Operátorok</a></li>\
    <li><a target="_top" href="hu/text/smath/01/03090600.html?DbPAR=MATH">Jellemzők</a></li>\
    <li><a target="_top" href="hu/text/smath/01/03090500.html?DbPAR=MATH">Zárójelek</a></li>\
    <li><a target="_top" href="hu/text/smath/01/03090700.html?DbPAR=MATH">Formátum</a></li>\
    <li><a target="_top" href="hu/text/smath/01/03091600.html?DbPAR=MATH">Egyéb szimbólumok</a></li>\
      </ul></li>\
    <li><a target="_top" href="hu/text/smath/guide/main.html?DbPAR=MATH">A LibreOffice Math használati utasítása</a></li>\
    <li><a target="_top" href="hu/text/smath/guide/keyboard.html?DbPAR=MATH">Gyorsbillentyűk (LibreOffice Math kisegítő lehetőségek)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Parancs- és menüreferencia</label><ul>\
    <li><a target="_top" href="hu/text/smath/main0100.html?DbPAR=MATH">Menük</a></li>\
    <li><a target="_top" href="hu/text/smath/main0200.html?DbPAR=MATH">Eszköztárak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Munka a képletekkel</label><ul>\
    <li><a target="_top" href="hu/text/smath/guide/align.html?DbPAR=MATH">Képletrészletek kézi igazítása</a></li>\
    <li><a target="_top" href="hu/text/smath/guide/color.html?DbPAR=MATH">Applying Color to Formula Parts</a></li>\
    <li><a target="_top" href="hu/text/smath/guide/attributes.html?DbPAR=MATH">Alapértelmezett jellemzők megváltoztatása</a></li>\
    <li><a target="_top" href="hu/text/smath/guide/brackets.html?DbPAR=MATH">Képletrészletek összefűzése zárójelek segítségével</a></li>\
    <li><a target="_top" href="hu/text/smath/guide/comment.html?DbPAR=MATH">Megjegyzések beírása</a></li>\
    <li><a target="_top" href="hu/text/smath/guide/newline.html?DbPAR=MATH">Sortörések beírása</a></li>\
    <li><a target="_top" href="hu/text/smath/guide/parentheses.html?DbPAR=MATH">Zárójelek beszúrása</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Grafikonok és diagramok</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Általános információk</label><ul>\
    <li><a target="_top" href="hu/text/schart/main0000.html?DbPAR=CHART">Diagramok a LibreOffice programban</a></li>\
    <li><a target="_top" href="hu/text/schart/main0503.html?DbPAR=CHART">A LibreOffice Chart funkciói</a></li>\
    <li><a target="_top" href="hu/text/schart/04/01020000.html?DbPAR=CHART">Diagramok gyorsbillentyűi</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makrók és szkriptelés</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Általános információk és a felhasználói felület használata</label><ul>\
    <li><a target="_top" href="hu/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice Basic Súgó</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programozás a LibreOffice Basickel</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basic szószedet</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01010210.html?DbPAR=BASIC">Alapok</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01020000.html?DbPAR=BASIC">Szintaxis</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01030100.html?DbPAR=BASIC">Az IDE áttekintése</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01030200.html?DbPAR=BASIC">A Basic-szerkesztő</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01050100.html?DbPAR=BASIC">Figyelés ablak</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/main0211.html?DbPAR=BASIC">Makró eszköztár</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makró</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Parancsreferencia</label><ul>\
    <li><a target="_top" href="hu/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01020500.html?DbPAR=BASIC">Programkönyvtárak, modulok és párbeszédablakok</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Függvények, utasítások és operátorok</label><ul>\
    <li><a target="_top" href="hu/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic konstansok</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100000.html?DbPAR=BASIC">Változók</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03060000.html?DbPAR=BASIC">Logikai operátorok</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03110100.html?DbPAR=BASIC">Összehasonlító operátorok</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120000.html?DbPAR=BASIC">Karakterláncok</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030000.html?DbPAR=BASIC">Dátum- és időfüggvények</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03070000.html?DbPAR=BASIC">Matematikai operátorok</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numerikus függvények</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080100.html?DbPAR=BASIC">Trigonometriai függvények</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010000.html?DbPAR=BASIC">Képernyő-I/O-függvények</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020000.html?DbPAR=BASIC">Fájl-I/O-függvények</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090000.html?DbPAR=BASIC">A program futásának vezérlése</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03050000.html?DbPAR=BASIC">Hibakezelő függvények</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03130000.html?DbPAR=BASIC">Egyéb parancsok</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080300.html?DbPAR=BASIC">Véletlen számok létrehozása</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090400.html?DbPAR=BASIC">További utasítások</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Futásidejű függvények, utasítások és operátorok ábécé szerinti listája</label><ul>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW függvény [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB függvény [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090404.html?DbPAR=BASIC">End utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03050000.html?DbPAR=BASIC">Hibakezelő függvények</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV függvény [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev függvény [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt függvény [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR függvény [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid függvény, Mid utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numerikus függvények</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub utasítás; On...GoTo utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (Function utasításban)</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080400.html?DbPAR=BASIC">Négyzetgyök számítása</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse függvény [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120202.html?DbPAR=BASIC">String függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName függvény; VarType függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03090411.html?DbPAR=BASIC">With utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write utasítás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year függvény</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03070100.html?DbPAR=BASIC">„-” operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03070200.html?DbPAR=BASIC">„*” operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03070300.html?DbPAR=BASIC">„+” operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03070400.html?DbPAR=BASIC">„/” operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03070500.html?DbPAR=BASIC">„^” operátor</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03120300.html?DbPAR=BASIC">Karakterlánc-tartalmak szerkesztése</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01020100.html?DbPAR=BASIC">Változók használata</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Fejlett Basic programkönyvtárak</label><ul>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools programkönyvtár</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT programkönyvtár</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO programkönyvtár</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD programkönyvtár</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS programkönyvtár</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard Library</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE programkönyvtár</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY programkönyvtár</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE programkönyvtár</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Library</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForge programkönyvtár</label><ul>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge programkönyvtárak</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception szolgáltatás (SF_Exception)</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String szolgáltatás (SF_String)</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest szolgáltatás</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer szolgáltatás</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Segédvonalak</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/macro_recording.html?DbPAR=BASIC">Makró rögzítése</a></li>\
    <li><a target="_top" href="hu/text/sbasic/guide/control_properties.html?DbPAR=BASIC">A vezérlőelemek tulajdonságainak megváltoztatása a párbeszédablak-szerkesztőben</a></li>\
    <li><a target="_top" href="hu/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Vezérlőelemek létrehozása a párbeszédablak-szerkesztő segítségével</a></li>\
    <li><a target="_top" href="hu/text/sbasic/guide/sample_code.html?DbPAR=BASIC">A párbeszédablak-szerkesztő vezérlőelemeinek példaprogramjai</a></li>\
    <li><a target="_top" href="hu/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="hu/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Basic-párbeszédablak létrehozása</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01030400.html?DbPAR=BASIC">Programkönyvtárak és modulok szervezése</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01020100.html?DbPAR=BASIC">Változók használata</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01020200.html?DbPAR=BASIC">Objektumok használata</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01030300.html?DbPAR=BASIC">Basic-programok hibakeresése</a></li>\
    <li><a target="_top" href="hu/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="hu/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="hu/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basicből Pythonba</a></li>\
    <li><a target="_top" href="hu/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python parancsfájlok súgó</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Általános információk és a felhasználói felület használata</label><ul>\
    <li><a target="_top" href="hu/text/sbasic/python/main0000.html?DbPAR=BASIC">Python parancsfájlok</a></li>\
    <li><a target="_top" href="hu/text/sbasic/python/python_ide.html?DbPAR=BASIC">Integrált fejlesztőkörnyezet Pythonhoz</a></li>\
    <li><a target="_top" href="hu/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="hu/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programozás Pythonban</label><ul>\
    <li><a target="_top" href="hu/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="hu/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python példák</a></li>\
    <li><a target="_top" href="hu/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Pythonról Basicre</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Szkriptfejlesztő eszközök</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice telepítés</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office dokumentumtípusok hozzárendelésének módosítása</a></li>\
    <li><a target="_top" href="hu/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Tiszta lap mód</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Általános súgótémák</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Általános információk</label><ul>\
    <li><a target="_top" href="hu/text/shared/main0400.html?DbPAR=SHARED">Billentyűparancsok</a></li>\
    <li><a target="_top" href="hu/text/shared/00/00000005.html?DbPAR=SHARED">Általános kifejezésgyűjtemény</a></li>\
    <li><a target="_top" href="hu/text/shared/00/00000002.html?DbPAR=SHARED">Internetes szakkifejezések gyűjteménye</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/accessibility.html?DbPAR=SHARED">Kisegítő lehetőségek a LibreOffice alkalmazásban</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/keyboard.html?DbPAR=SHARED">Billentyűparancsok (LibreOffice kisegítő lehetőségei)</a></li>\
    <li><a target="_top" href="hu/text/shared/04/01010000.html?DbPAR=SHARED">Általános gyorsbillentyűk a LibreOffice-ban</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/version_number.html?DbPAR=SHARED">Verziószám és az összeépítés (build) száma</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice és a Microsoft Office</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/ms_user.html?DbPAR=SHARED">A Microsoft Office és a LibreOffice használata</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">A Microsoft Office és a LibreOffice által használt kifejezések</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Microsoft Office dokumentumok átalakításáról</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office dokumentumtípusok hozzárendelésének módosítása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">A LibreOffice beállításai</label><ul>\
    <li><a target="_top" href="hu/text/shared/optionen/01000000.html?DbPAR=SHARED">Beállítások</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01010100.html?DbPAR=SHARED">Felhasználó adatai</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01010200.html?DbPAR=SHARED">Általános</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01010800.html?DbPAR=SHARED">Nézet</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01010900.html?DbPAR=SHARED">Nyomtatás beállításai</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01010300.html?DbPAR=SHARED">Útvonalak</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01010700.html?DbPAR=SHARED">Betűkészletek</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01030300.html?DbPAR=SHARED">Biztonság</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01012000.html?DbPAR=SHARED">Alkalmazás színei</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01013000.html?DbPAR=SHARED">Kisegítő lehetőségek</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/java.html?DbPAR=SHARED">Speciális</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Szakértői beállítás</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01010400.html?DbPAR=SHARED">Írástámogatás</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01010600.html?DbPAR=SHARED">Általános</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01020000.html?DbPAR=SHARED">Megnyitás és mentés beállításai</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01030000.html?DbPAR=SHARED">Internet beállításai</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01040000.html?DbPAR=SHARED">Szöveges dokumentum beállításai</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01050000.html?DbPAR=SHARED">HTML-dokumentum beállításai</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01060000.html?DbPAR=SHARED">Munkafüzet beállításai</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01070000.html?DbPAR=SHARED">Bemutató beállításai</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01080000.html?DbPAR=SHARED">Rajzok beállításai</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01090000.html?DbPAR=SHARED">Képlet</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01110000.html?DbPAR=SHARED">Diagram beállításai</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA-beállítások</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01150000.html?DbPAR=SHARED">Nyelvi beállítások</a></li>\
    <li><a target="_top" href="hu/text/shared/optionen/01160000.html?DbPAR=SHARED">Adatforrások beállításai</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Tündérek</label><ul>\
    <li><a target="_top" href="hu/text/shared/autopi/01000000.html?DbPAR=SHARED">Tündér</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Levéltündér</label><ul>\
    <li><a target="_top" href="hu/text/shared/autopi/01010000.html?DbPAR=SHARED">Levéltündér</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Faxtündér</label><ul>\
    <li><a target="_top" href="hu/text/shared/autopi/01020000.html?DbPAR=SHARED">Faxtündér</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Napirend tündér</label><ul>\
    <li><a target="_top" href="hu/text/shared/autopi/01040000.html?DbPAR=SHARED">Napirend tündér</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Exportálás HTML formátumba tündér</label><ul>\
    <li><a target="_top" href="hu/text/shared/autopi/01110000.html?DbPAR=SHARED">Exportálás HTML formátumba</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Dokumentumátalakító tündér</label><ul>\
    <li><a target="_top" href="hu/text/shared/autopi/01130000.html?DbPAR=SHARED">Dokumentumátalakító</a></li>\
      </ul></li>\
    <li><a target="_top" href="hu/text/shared/autopi/01150000.html?DbPAR=SHARED">Euróátváltó tündér</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">A LibreOffice beállítása</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/configure_overview.html?DbPAR=SHARED">A LibreOffice konfigurálása</a></li>\
    <li><a target="_top" href="hu/text/shared/01/packagemanager.html?DbPAR=SHARED">Kiterjesztéskezelő</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/flat_icons.html?DbPAR=SHARED">Ikonok megjelenésének megváltoztatása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Gombok hozzáadása az eszköztárakhoz</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/workfolder.html?DbPAR=SHARED">Munkakönyvtár megváltoztatása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Címjegyzék regisztrálása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/formfields.html?DbPAR=SHARED">Gombok beszúrása és szerkesztése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">A felhasználói felület használata</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navigáció az objektumok gyors eléréséhez</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/navigator.html?DbPAR=SHARED">Navigátor a dokumentum áttekintéséhez</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/autohide.html?DbPAR=SHARED">Ablakok megjelenítése, dokkolása és elrejtése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/textmode_change.html?DbPAR=SHARED">Váltás a beszúró mód és az átíró mód között</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Eszköztárak használata</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digitális aláírások</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/digital_signatures.html?DbPAR=SHARED">A digitális aláírásokról</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Digitális aláírások alkalmazása</a></li>\
    <li><a target="_top" href="hu/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF exportálás - digitális aláírás</a></li>\
    <li><a target="_top" href="hu/text/shared/01/timestampauth.html?DbPAR=SHARED">Időbélyegzés-szolgáltató digitális aláírásokhoz</a></li>\
    <li><a target="_top" href="hu/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Meglévő PDF aláírása</a></li>\
    <li><a target="_top" href="hu/text/shared/01/addsignatureline.html?DbPAR=SHARED">Aláírási sor hozzáadása a dokumentumokhoz</a></li>\
    <li><a target="_top" href="hu/text/shared/01/signsignatureline.html?DbPAR=SHARED">Aláírási sor aláírása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Nyomtatás, faxolás, küldés</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/labels_database.html?DbPAR=SHARED">Címcímkék nyomtatása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Fekete-fehér nyomtatás</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/fax.html?DbPAR=SHARED">Faxok küldése és a LibreOffice beállítása faxoláshoz</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Fogd és vidd</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/dragdrop.html?DbPAR=SHARED">Fogd és vidd módszer egy LibreOffice-dokumentumon belül</a></li>\
    <li><a target="_top" href="hu/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Szöveg áthelyezése és másolása dokumentumokban</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Munkafüzet-területek átmásolása szöveges dokumentumba</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Képek másolása dokumentumok között</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Képek másolása a Képtárból</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Fogd és vidd módszer adatforrás nézetben</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Másolás és beillesztés</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Rajzobjektumok másolása másik dokumentumba</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Képek másolása dokumentumok között</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Képek másolása a Képtárból</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Munkafüzet-területek átmásolása szöveges dokumentumba</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Grafikonok és diagramok</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/chart_insert.html?DbPAR=SHARED">Diagramok beszúrása</a></li>\
    <li><a target="_top" href="hu/text/schart/main0000.html?DbPAR=SHARED">Diagramok a LibreOffice programban</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Betöltés, mentés, importálás, exportálás, PDF</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/doc_open.html?DbPAR=SHARED">Dokumentumok megnyitása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/import_ms.html?DbPAR=SHARED">Más formátumokban mentett dokumentumok megnyitása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/doc_save.html?DbPAR=SHARED">Dokumentumok mentése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Dokumentumok automatikus mentése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/export_ms.html?DbPAR=SHARED">Dokumentumok mentése egyéb formátumokban</a></li>\
    <li><a target="_top" href="hu/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Exportálás PDF-be</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Adatok importálása és exportálása szövegformátumban</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Hivatkozások és referenciák</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Hiperhivatkozások beszúrása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Relatív és abszolút hivatkozások</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Hiperhivatkozások szerkesztése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Dokumentumverzió követése</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Dokumentumverziók összehasonlítása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Verziók összefésülése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Változások követése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/redlining.html?DbPAR=SHARED">Változások követése és megjelenítése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Változások elfogadása vagy elvetése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Verziók kezelése</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Címkék és névjegyek</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/labels.html?DbPAR=SHARED">Címkék és névjegyek készítése és nyomtatása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Külső adatok beszúrása</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/copytable2application.html?DbPAR=SHARED">Adatok beszúrása táblázatból</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/copytext2application.html?DbPAR=SHARED">Adatok beszúrása szöveges dokumentumokból</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Bitképek beszúrása, szerkesztése és mentése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Képek hozzáadása a Képtárhoz</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automatikus függvények</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Automatikus URL-felismerés kikapcsolása</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Keresés és csere</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/data_search2.html?DbPAR=SHARED">Keresés űrlapszűrővel</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_search.html?DbPAR=SHARED">Keresés táblákban és űrlapdokumentumokban</a></li>\
    <li><a target="_top" href="hu/text/shared/01/02100001.html?DbPAR=SHARED">Reguláris kifejezések listája</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Útmutatók</label><ul>\
    <li><a target="_top" href="hu/text/shared/guide/linestyles.html?DbPAR=SHARED">Vonalstílusok alkalmazása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/text_color.html?DbPAR=SHARED">A szöveg színének megváltoztatása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/change_title.html?DbPAR=SHARED">Dokumentum címének változtatása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/round_corner.html?DbPAR=SHARED">Lekerekített sarkok készítése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/background.html?DbPAR=SHARED">Háttérszínek vagy háttérképek meghatározása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Vonalstílusok meghatározása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Grafikus objektumok szerkesztése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/line_intext.html?DbPAR=SHARED">Vonalak rajzolása szövegben</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/aaa_start.html?DbPAR=SHARED">Első lépések</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Objektumok beszúrása a Képtárból</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Nem törő szóközök, kötőjelek és lágy kötőjelek beszúrása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Különleges karakterek beszúrása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/tabs.html?DbPAR=SHARED">Tabulátorok beszúrása és szerkesztése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Using Remote Files</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/protection.html?DbPAR=SHARED">Tartalom védelme a LibreOffice programban</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Változásnapló védelme</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Egy oldalon lévő maximális nyomtatható terület kijelölése</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/measurement_units.html?DbPAR=SHARED">Mértékegységek kiválasztása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/language_select.html?DbPAR=SHARED">Dokumentum nyelvének kiválasztása</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Táblatervezés</a></li>\
    <li><a target="_top" href="hu/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Felsorolásjelek és számozás kikapcsolása egyedi bekezdéseknél</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
