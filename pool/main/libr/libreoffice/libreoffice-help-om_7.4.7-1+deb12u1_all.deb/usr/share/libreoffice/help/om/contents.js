document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Text Documents (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="om/text/swriter/main0000.html?DbPAR=WRITER">Baga Gargartuu Barreessaa LibreOfficetti Nagaan Dhuftan</a></li>\
    <li><a target="_top" href="om/text/swriter/main0503.html?DbPAR=WRITER">Amaloota Barreessaa LibreOffice</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/main.html?DbPAR=WRITER">Barreessaa LibreOffice fayyadamuuf ajaja</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Foddaalee Hidhuu fi Hagamta isaanii jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/swriter/04/01020000.html?DbPAR=WRITER">Barreessaa LibreOffice dhaaf qabduuwwan qaxxaamuraa</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/words_count.html?DbPAR=WRITER">Jechooota lakkaa&#39;uu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/keyboard.html?DbPAR=WRITER">Furtuuwwan qaxxamuraa(Barreeessaa LibreOffice Saaqqatinaa)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Baafattoota</label><ul>\
    <li><a target="_top" href="om/text/swriter/main0100.html?DbPAR=WRITER">Baafatoota</a></li>\
    <li><a target="_top" href="om/text/swriter/main0101.html?DbPAR=WRITER">Faayilii</a></li>\
    <li><a target="_top" href="om/text/swriter/main0102.html?DbPAR=WRITER">Gulaali</a></li>\
    <li><a target="_top" href="om/text/swriter/main0103.html?DbPAR=WRITER">Mul&#39;annoo</a></li>\
    <li><a target="_top" href="om/text/swriter/main0104.html?DbPAR=WRITER">Saagi</a></li>\
    <li><a target="_top" href="om/text/swriter/main0105.html?DbPAR=WRITER">Dhangi&#39;i</a></li>\
    <li><a target="_top" href="om/text/swriter/main0115.html?DbPAR=WRITER">Styles (menu)</a></li>\
    <li><a target="_top" href="om/text/swriter/main0110.html?DbPAR=WRITER">Gabatee</a></li>\
    <li><a target="_top" href="om/text/swriter/main0120.html?DbPAR=WRITER">Form Menu</a></li>\
    <li><a target="_top" href="om/text/swriter/main0106.html?DbPAR=WRITER">Meeshaalee</a></li>\
    <li><a target="_top" href="om/text/swriter/main0107.html?DbPAR=WRITER">Foddaa</a></li>\
    <li><a target="_top" href="om/text/shared/main0108.html?DbPAR=WRITER">Gargaarsa</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Kamshaalee</label><ul>\
    <li><a target="_top" href="om/text/swriter/main0200.html?DbPAR=WRITER">Kamshaalee</a></li>\
    <li><a target="_top" href="om/text/swriter/main0206.html?DbPAR=WRITER">Kabala Rasaasawwan fi Lakkaawwii</a></li>\
    <li><a target="_top" href="om/text/swriter/main0205.html?DbPAR=WRITER">Kabala Amalootaa Wanta Fakkasaa</a></li>\
    <li><a target="_top" href="om/text/shared/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="om/text/shared/main0226.html?DbPAR=WRITER">Kamshaa Saxaxa Unkaa</a></li>\
    <li><a target="_top" href="om/text/shared/main0213.html?DbPAR=WRITER">Naanna&#39;insa Unkaa Irraa</a></li>\
    <li><a target="_top" href="om/text/swriter/main0202.html?DbPAR=WRITER">Kabala Dhangeessuu</a></li>\
    <li><a target="_top" href="om/text/swriter/main0214.html?DbPAR=WRITER">Kabalaa Foormulaa</a></li>\
    <li><a target="_top" href="om/text/swriter/main0215.html?DbPAR=WRITER">Kabala Goodayyaa</a></li>\
    <li><a target="_top" href="om/text/swriter/main0203.html?DbPAR=WRITER">Image Bar</a></li>\
    <li><a target="_top" href="om/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo Toolbar</a></li>\
    <li><a target="_top" href="om/text/swriter/main0216.html?DbPAR=WRITER">OLE Object Bar</a></li>\
    <li><a target="_top" href="om/text/swriter/main0210.html?DbPAR=WRITER">Print Preview Bar (Writer)</a></li>\
    <li><a target="_top" href="om/text/shared/main0214.html?DbPAR=WRITER">Kabala Saxaxa Gaafataa</a></li>\
    <li><a target="_top" href="om/text/swriter/main0213.html?DbPAR=WRITER">Sarartuuwwan</a></li>\
    <li><a target="_top" href="om/text/shared/main0201.html?DbPAR=WRITER">Kabala Durtii</a></li>\
    <li><a target="_top" href="om/text/swriter/main0208.html?DbPAR=WRITER">Status Bar (Writer)</a></li>\
    <li><a target="_top" href="om/text/swriter/main0204.html?DbPAR=WRITER">Kabala Gabatee</a></li>\
    <li><a target="_top" href="om/text/shared/main0212.html?DbPAR=WRITER">Kabala Deetaa Gabatee</a></li>\
    <li><a target="_top" href="om/text/swriter/main0220.html?DbPAR=WRITER">Kabala Wanta Barruu</a></li>\
    <li><a target="_top" href="om/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Track Changes Toolbar</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navigating Text Documents</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Gabateecuqootiin Naanna&#39;uu fi Filuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Galmeewwaan keessa Barruu Garagalchuu fi Siiqsuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Naanneessaa fayyadamuudhaan Galmee Qiqindeessuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Geessituu naanna&#39;aa waliin saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/navigator.html?DbPAR=WRITER">Naanna&#39;aa barruu Galmeewwanii</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Qaree Kalatii fayyadamuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatting Text Documents</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Qaabachiisa Fuulaa Jijjiiruu(Dalgeessa ykn Dhaabbattaa)</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/text_capital.html?DbPAR=WRITER">Guddiinaa fi Xinneenya Qubee Barruu jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Barruu Dhoksuun</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Olaantoota fi Jalaantoota Gara Garaa Hiikuun</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Maqaa fi Lakkoofsa Boqoonnaa olaantoo ykn Gadaantoo Keessaatti Saaguun</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Yennaa barreessitu dhangii barruu fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/reset_format.html?DbPAR=WRITER">Amaloota Bocquu Haaromsuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Akkaataa Moodii dhangii guutu fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/wrap.html?DbPAR=WRITER">Barruu Marsaa Wantawwan Naannoo</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Barruu tokko irraa Barruu Wiirtessuuf Goodayyaa fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Barruu Shooluu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Barruu Marsuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/page_break.html?DbPAR=WRITER">Qurxiinsa fuulaa saaguu fi haquu.</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Haalataalee fuulaa uumuu fi fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/subscript.html?DbPAR=WRITER">Barruu, Irrarfii yk Jalarfii gochuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Qajojiiwwanii fi Akkaataalee</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Qajojiiwwanii fi Akkaataalee</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Fuulota guutuuf Mangoo irratti Akkaataa fuula garagaltuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/change_header.html?DbPAR=WRITER">Fuula Ammaa irratti Hundaa&#39;uun Akkaataa Fuula uumuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/load_styles.html?DbPAR=WRITER">Akkaataa galmee biroo ykn qajojii fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Filannoowwan irraa akkaataawwan haarawa uumu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Filannoowwan Irraa Akkaataawwan  Haaromsuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="om/text/shared/guide/template_manager.html?DbPAR=WRITER">Template Manager</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Graphics in Text Documents</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Saxaatoo Saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Faayilii irraa saxaatoo saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Saxaatoo Kuusaa Faayaa Harkisuu-fi-Kaa&#39;uu waliinii irraa Saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Calaqqee Ka&#39;e Saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Galmee Barruu keessatti Taattoo Calc Saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Saxaatoota fakkaasa ykn maxxansa LibreOffice irraa saaguu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tables in Text Documents</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Lakkoofsa Beekkamaa gabatee keessaa Banuun ykn dhaamsuun jijjiruu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/tablemode.html?DbPAR=WRITER">Gabateecuqootiin, Tarreewwanii fi Tarjaawwan haarmsuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/table_delete.html?DbPAR=WRITER">Gabateewwan ykn Qabeentoota Gabatee haquu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/table_insert.html?DbPAR=WRITER">Barruuwwan Saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Mataduree Gabatee, Fuula Haaraa irrattis irra deebi&#39;uu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Gabatee Barruu keessatti, Tarreewwanii fi Tarjaawwanii hagamtaa jijjiiruu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objects in Text Documents</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Wanta Qubachiisaa</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/wrap.html?DbPAR=WRITER">Barruu Marsaa Wantawwan Naannoo</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sections and Frames in Text Documents</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/sections.html?DbPAR=WRITER">Kutaalee Fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/section_edit.html?DbPAR=WRITER">Kutaalee Gulaaluu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/section_insert.html?DbPAR=WRITER">Kutaalee Saaguu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Tables of Contents and Indexes</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Kasaawwan Hiika-Fayyadamaa</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Gabatee Qabiiyyeewwanii Uumuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/indices_index.html?DbPAR=WRITER">Kasaawwan Tartiiba qubeen Uumuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Kasaawwan Galmeewwan Hedduu Kabeebsan</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Tarrobarroo Uumuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Galchiiwwan Kasaa fi Gabatee Gulaaluu ykn Haquu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Haaressuu, kasaawwan fi gabatee qabiiyyeewwanii Gulaaluu fi Haquu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Galchiiwwan Kasaa ykn Gabatee Qabiyyeewwanii Hiikuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/indices_form.html?DbPAR=WRITER">Kasaa ykn Gabatee Qabiyyeewwanii Dhangeessuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Fields in Text Documents</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/fields.html?DbPAR=WRITER">Waa&#39;ee Dirroolee</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/fields_date.html?DbPAR=WRITER">Dirree Guyyaa jijjiiramaa ykn Dhaabbataa Saagu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/field_convert.html?DbPAR=WRITER">Dirree gara Barruutti Jijjiiru</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Galmee Barruu keessatti herregu</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Gabatee Gamaa-gamana Herregi</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/calculate.html?DbPAR=WRITER">Galmee Barruu keessatti herregu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Galmee barrutti bu&#39;aa foormulaa herreguf maxxansi</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Gabatee irratti ida&#39;amaa man&#39;ee herregu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Galmee Barruu irratti Foormulaa Xaxamoo Herregi</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Bu&#39;aa Herrega Gabatee, Gabatee Garagara irratti Agarsiisu.</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Special Text Elements</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/captions.html?DbPAR=WRITER">Goodayyootaa Fayadamu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Barruu Otoola</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Lakkoofsa Fuulaaf Barruu Otoola</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/fields_date.html?DbPAR=WRITER">Dirree Guyyaa jijjiiramaa ykn Dhaabbataa Saagu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Dirreewwan Naqa Ida&#39;uu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Fuula Lakkoofsota itti fufinsa fuulaa saguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Lakkoofsota Juulaa Jalaantootti Saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Barruu Dhoksuun</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Olaantoota fi Jalaantoota Gara Garaa Hiikuun</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Maqaa fi Lakkoofsa Boqoonnaa olaantoo ykn Gadaantoo Keessaatti Saaguun</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Fayyadamaa Deetaa Dirreewwan ykn Haaloota irra Gaafata</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Miiljalee ykn Ibsa Dabalataa Gulaaluu fi Saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Miiljaloota gidduu addaan faffageessi</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/header_footer.html?DbPAR=WRITER">Waa&#39;ee Irraantotaa fi Jalaantotaa</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Jalaantota ykn olaantota Dhangeessuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/text_animation.html?DbPAR=WRITER">Barruu Sochii Fakkeessuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Unka Qubee uumuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automatic Functions</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Tarree OfiinSirreessaatti, Quxaaloota ida&#39;uu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/autotext.html?DbPAR=WRITER">BarruuUfmaa Fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Yeroo Barreessuu, Lakkaawwii ykn Rasaasawwan Uumuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/auto_off.html?DbPAR=WRITER">OfDhangi&#39;aa fi OfiinSirreessaa Dhaamsuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Ufmaan Qubeeffannoo Mirkaneessuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Lakkoofsa Beekkamaa gabatee keessaa Banuun ykn dhaamsuun jijjiruu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Murfisa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numbering and Lists</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Lakkoofsa Boqannaa Qabiiwwanitti Ida&#39;uu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Yeroo Barreessuu, Lakkaawwii ykn Rasaasawwan Uumuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Tarreewwan lakkaawwame makuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Sararaa Lakkoofsota Dabalii</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Hangiiwwan Lakkoofsa Hiiki</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Lakkaawwii Ida&#39;uu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Rasaasawwan Ida&#39;uu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Spellchecking, Thesaurus, and Languages</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Ufmaan Qubeeffannoo Mirkaneessuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Hiika Fayyadamaa Jechikaa irra Jechoota Haquu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Tarree Moggoolee</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Hojaarkaan qubee mirkaneessuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Troubleshooting Tips</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Barruu gabatee gubbaa fuulaa dursanii saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Gara Toorbarruu Murta&#39;aati Deemuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/send2html.html?DbPAR=WRITER">Dhangii HTML tiin Galmeewwan Barruu Olkaa&#39;uu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Xumuura Galmee Barruu Saaguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="om/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Master Documents</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Galmee Hundataa fi Gariigalmeewwanii</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Links and References</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/references.html?DbPAR=WRITER">Waabeffannoowwan Saaguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Geessituu naanna&#39;aa waliin saaguu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Maxxansuu</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/print_selection.html?DbPAR=WRITER">Selecting What to Print</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Irkootiiwwan waraqaa maxxansaa filachuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/print_preview.html?DbPAR=WRITER">Maxxansuun dura fuuloota durarguu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/print_small.html?DbPAR=WRITER">Wardii tokko irratti fuulota baay&#39;ee maxxansuu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Haalataalee fuulaa uumuu fi fayyadamuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Searching and Replacing</label><ul>\
    <li><a target="_top" href="om/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="om/text/shared/01/02100001.html?DbPAR=WRITER">Himannoowwan Idilee Tarree</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML Documents (Writer Web)</label><ul>\
    <li><a target="_top" href="om/text/shared/07/09000000.html?DbPAR=WRITER">Fuuloota Saphaphuu</a></li>\
    <li><a target="_top" href="om/text/shared/02/01170700.html?DbPAR=WRITER">Gingilchaa fi unkaawwan HTML</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/send2html.html?DbPAR=WRITER">Dhangii HTML tiin Galmeewwan Barruu Olkaa&#39;uu</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Spreadsheets (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="om/text/scalc/main0000.html?DbPAR=CALC">Baga Gargaarsa Calc LibreOfficetti Nagaan Dhufte</a></li>\
    <li><a target="_top" href="om/text/scalc/main0503.html?DbPAR=CALC">Amaloota Calcii LibreOffice</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/keyboard.html?DbPAR=CALC">Furtuuwwan Qaxxaamuraa (Gaheenya LibreOffice Calc)</a></li>\
    <li><a target="_top" href="om/text/scalc/04/01020000.html?DbPAR=CALC">Furtuu qaxxaamura Wardiif</a></li>\
    <li><a target="_top" href="om/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="om/text/scalc/05/02140000.html?DbPAR=CALC">Dogogora lakaddaa LibreOffice Calc keessatti</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060112.html?DbPAR=CALC">Idaatuu Progiramingii LibreOffice Calc keesaatif</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/main.html?DbPAR=CALC">Qajeelfamoota LibreOffice Calc fayyadamuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Baafattoota</label><ul>\
    <li><a target="_top" href="om/text/scalc/main0100.html?DbPAR=CALC">Baafatoota</a></li>\
    <li><a target="_top" href="om/text/scalc/main0101.html?DbPAR=CALC">Faayilii</a></li>\
    <li><a target="_top" href="om/text/scalc/main0102.html?DbPAR=CALC">Gulaali</a></li>\
    <li><a target="_top" href="om/text/scalc/main0103.html?DbPAR=CALC">Mul&#39;isi</a></li>\
    <li><a target="_top" href="om/text/scalc/main0104.html?DbPAR=CALC">Saagi</a></li>\
    <li><a target="_top" href="om/text/scalc/main0105.html?DbPAR=CALC">Dhangi&#39;i</a></li>\
    <li><a target="_top" href="om/text/scalc/main0116.html?DbPAR=CALC">Sheet</a></li>\
    <li><a target="_top" href="om/text/scalc/main0112.html?DbPAR=CALC">Deetaa</a></li>\
    <li><a target="_top" href="om/text/scalc/main0106.html?DbPAR=CALC">Meeshaalee</a></li>\
    <li><a target="_top" href="om/text/scalc/main0107.html?DbPAR=CALC">Foddaa</a></li>\
    <li><a target="_top" href="om/text/shared/main0108.html?DbPAR=CALC">Gargaarsa</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Kamshaalee</label><ul>\
    <li><a target="_top" href="om/text/scalc/main0200.html?DbPAR=CALC">Kamshaalee</a></li>\
    <li><a target="_top" href="om/text/shared/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="om/text/scalc/main0202.html?DbPAR=CALC">Kabala Dhangeessuu</a></li>\
    <li><a target="_top" href="om/text/scalc/main0203.html?DbPAR=CALC">Kabala Amala Wantaa Fakkasaa</a></li>\
    <li><a target="_top" href="om/text/scalc/main0205.html?DbPAR=CALC">Kabala Barruu Dhangeessuu</a></li>\
    <li><a target="_top" href="om/text/scalc/main0206.html?DbPAR=CALC">Kabala Foormulaa</a></li>\
    <li><a target="_top" href="om/text/scalc/main0208.html?DbPAR=CALC">Kabala Haalojii</a></li>\
    <li><a target="_top" href="om/text/scalc/main0210.html?DbPAR=CALC">Kabala Durargii Fuulaa</a></li>\
    <li><a target="_top" href="om/text/scalc/main0214.html?DbPAR=CALC">Image Bar</a></li>\
    <li><a target="_top" href="om/text/scalc/main0218.html?DbPAR=CALC">Kabala Meeshaalee</a></li>\
    <li><a target="_top" href="om/text/shared/main0201.html?DbPAR=CALC">Kabala Durtii</a></li>\
    <li><a target="_top" href="om/text/shared/main0212.html?DbPAR=CALC">Kabala Deetaa Gabatee</a></li>\
    <li><a target="_top" href="om/text/shared/main0213.html?DbPAR=CALC">Naanna&#39;insa Unkaa Irraa</a></li>\
    <li><a target="_top" href="om/text/shared/main0214.html?DbPAR=CALC">Kabala Saxaxa Gaafataa</a></li>\
    <li><a target="_top" href="om/text/shared/main0226.html?DbPAR=CALC">Kamshaa Saxaxa Unkaa</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Functions Types and Operators</label><ul>\
    <li><a target="_top" href="om/text/scalc/01/04060000.html?DbPAR=CALC">Masaka Faankishinii</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060100.html?DbPAR=CALC">Faankishinoota Akaakuudhaan</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060107.html?DbPAR=CALC">Faankishinoota Waraantoo</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060120.html?DbPAR=CALC">Bit Operation Functions</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060101.html?DbPAR=CALC">Faankishinoota Kuusdeetaa</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060102.html?DbPAR=CALC">Guyyaa Fi faankishinoota yeroo</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060103.html?DbPAR=CALC">Galii faankishiniin qaama tokko</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060119.html?DbPAR=CALC">Fankishinoota Maallaqaa kutaa lama</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060118.html?DbPAR=CALC">Fankishinoota Maallaqaa kutaa sadi</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060104.html?DbPAR=CALC">Faankishinoota Odeeffannoo</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060105.html?DbPAR=CALC">Faankishinii sirna yaadaa</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060106.html?DbPAR=CALC">Faankishinii herreegaa</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060108.html?DbPAR=CALC">Faankishinoota Istaatistiksii</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060181.html?DbPAR=CALC">Fankishinoota Istaatistiksii Kutaa Tokko</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060182.html?DbPAR=CALC">Fankishinoota Istaatistiksii Kutaa Lama</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060183.html?DbPAR=CALC">Fankishinoota Istaatistiksii Kutaa Sadi</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060184.html?DbPAR=CALC">Fankishinoota Istaatistiksii Kutaa Afur</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060185.html?DbPAR=CALC">Fankishinoota Istaatistiksii Kutaa Shan</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060109.html?DbPAR=CALC">Faankishinoota Wardii</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060110.html?DbPAR=CALC">Faankishinoota Barruu</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060111.html?DbPAR=CALC">Faankishinoota Add-in</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060115.html?DbPAR=CALC">Fankishiiniiwwan Idaatu,Kutaa Lammaffaa Tarree Xiinxala Fankishinii</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060116.html?DbPAR=CALC">Fankishiiniiwwan Idaatu,Kutaa Lammaffaa Tarree Xiinxala Fankishinii</a></li>\
    <li><a target="_top" href="om/text/scalc/01/04060199.html?DbPAR=CALC">Ogeejjiiwwan LibreOffice Calc keessaa</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Dalagaalee Fayyadamaan qindaa&#39;an</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/webquery.html?DbPAR=CALC">Deetaa alaa gabatee keessatti saaguu(GaafataSaaphaphuu)</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/html_doc.html?DbPAR=CALC">Wardiilee HTML keessatti Olkaa&#39;uu fi Banuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/csv_formula.html?DbPAR=CALC">Faayiloota Barruu Alaaguu fi Alerguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="om/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Dhangeessuu</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/text_rotate.html?DbPAR=CALC">Barruu Naannessuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/text_wrap.html?DbPAR=CALC">Barruu Sarar-baay&#39;ee Barreessuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/text_numbers.html?DbPAR=CALC">Lakkoofsa akka Barruutti Dhangeessuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/super_subscript.html?DbPAR=CALC">Irrarfii/ Jalarfii Barruu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/row_height.html?DbPAR=CALC">Hojjaa Tarree ykn Dalga Sarjaa jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Dhangeessuu Otoolaa Raawwachuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Lakkoofsota Negaatiivii Shooluu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Dhangiiwwan Foormulaadhaan Ramaduu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Lakkoofsa zeeroowwan dursan galchuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/format_table.html?DbPAR=CALC">Wardiilee Dhangeessuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/format_value.html?DbPAR=CALC">Lakkoofsota Deesiimaaliidhaan Dhangeessuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/value_with_name.html?DbPAR=CALC">Maadheelee moggaasuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/table_rotate.html?DbPAR=CALC">Gabateewwan Naannessuu(Transposing)</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/rename_table.html?DbPAR=CALC">Wardiilee Maqaa jijjiiri</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/year2000.html?DbPAR=CALC">Baroota 19xx/20xx</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Lakkoofsota Sissiqanitti Fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/currency_format.html?DbPAR=CALC">Maadheelee Dhangii Maallaqaa</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/autoformat.html?DbPAR=CALC">Gabateewwaniif dhangii ufmaa fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/note_insert.html?DbPAR=CALC">Yaadota Saaguu fi Gulaaluu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/design.html?DbPAR=CALC">Wardiileef dhamsoota filachuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Firaakshinoota galchuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtering and Sorting</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/filters.html?DbPAR=CALC">Gingilcha Ufmaa raawwachuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/autofilter.html?DbPAR=CALC">Gingilcha ufmaa raawwachuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/sorted_list.html?DbPAR=CALC">Tarreewwan Fo&#39;uu Raawwachuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Maxxansuu</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/print_title_row.html?DbPAR=CALC">Tarreewwanii fi sarjaawwan fuula mara irraa maxxansuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/print_landscape.html?DbPAR=CALC">Wardiilee dhangii dalgeessaatiin maxxansuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/print_details.html?DbPAR=CALC">Waa&#39;ee Wardii Maxxansaa</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/print_exact.html?DbPAR=CALC">Lakkoofsa fuulaa maxxansaaf qindeessuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Data Ranges</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/database_define.html?DbPAR=CALC">Hammangaa Kuusaa deetaa Qindeessuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/database_filter.html?DbPAR=CALC">Hammangaawwam Man&#39;ee Gingilchuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/database_sort.html?DbPAR=CALC">Deetaa Foo&#39;uu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Pivot Table</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/datapilot.html?DbPAR=CALC">Gabatee Qiinxaa</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Ganateewwan DataPilot uumuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Gabateewwan DataPilot uumuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Gabateewwan DataPilot gulaaluu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Gabateewwan DataPilot gingilchuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Hammangaawwan bahaa DataPilot filachuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Ganateewwan DataPilot fooyyessuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivot Chart</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Mul&#39;inoota</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/scenario.html?DbPAR=CALC">Mul&#39;inatti fayyadamuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotals</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">References</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Teessoowwanii fi Wabiilee, Of danda&#39;aa fi Hirkataa</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/cellreferences.html?DbPAR=CALC">Maadhee galmee biraa keessatti wabeeffadhu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Wabiilee gara wardiilee biraa fi URL wabeeffaman</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Maadheelee harkisaa-fi-kaayuun wabeeffachuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/address_auto.html?DbPAR=CALC">Maqaalee akka teessessuutti beekuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Viewing, Selecting, Copying</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/table_view.html?DbPAR=CALC">Argiiwwan Gabatee Jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/formula_value.html?DbPAR=CALC">Foormulaawwan ykn Gatiiwwan Mul&#39;isuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/line_fix.html?DbPAR=CALC">Tarreewwanii fi Sarjaalee akka Irraantotaa Dhaabuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/multi_tables.html?DbPAR=CALC">Caancaloota Wardiilee keessa Daddarbuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Wardiilee Baay&#39;eetti Garagalchuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/cellcopy.html?DbPAR=CALC">Maadheele mul&#39;atana qofa garagalchi</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/mark_cells.html?DbPAR=CALC">Maadheelee Danuu Filachuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formulas and Calculations</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/formulas.html?DbPAR=CALC">Foormulaawwaniin Shallaguu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/formula_copy.html?DbPAR=CALC">Foormulaawwan Garagalchuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/formula_enter.html?DbPAR=CALC">Foormulaawwan Galchuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/formula_value.html?DbPAR=CALC">Foormulaawwan ykn Gatiiwwan Mul&#39;isuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/calculate.html?DbPAR=CALC">Wardiilee keessatti shallaguu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/calc_date.html?DbPAR=CALC">Guyyootaa fi yeroodhaan shallaguu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/calc_series.html?DbPAR=CALC">Walfaannee shallaguu ufmaa</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Garaagarummaa yeroo shallaguu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/matrixformula.html?DbPAR=CALC">Foormulaawwan Tarreentaa Galchuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Hayyisa</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/cell_protect.html?DbPAR=CALC">Maadheelee jijjiirraa irraa dhorkuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Man&#39;ee dhorkuu dhiisuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Writing Calc Macros</label><ul>\
    <li><a target="_top" href="om/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Reading and Writing values to Ranges</a></li>\
    <li><a target="_top" href="om/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatting Borders in Calc with Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Wal makaa</label><ul>\
    <li><a target="_top" href="om/text/scalc/guide/auto_off.html?DbPAR=CALC">Jijjiirraa ufmaa kaka&#39;a ala gochuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/consolidate.html?DbPAR=CALC">Deetaa Cimsuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/goalseek.html?DbPAR=CALC">Barbaacha Kaayyoo Raawwachuu</a></li>\
    <li><a target="_top" href="om/text/scalc/01/solver.html?DbPAR=CALC">Furaa</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/multioperation.html?DbPAR=CALC">Dalagaalee baay&#39;ee raawwachuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/multitables.html?DbPAR=CALC">Wardiilee Baay&#39;ee Raawwachuu</a></li>\
    <li><a target="_top" href="om/text/scalc/guide/validity.html?DbPAR=CALC">Sirrummaa qabiyyeewwan maadhee</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentations (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="om/text/simpress/main0000.html?DbPAR=IMPRESS">Baga gara Gargaarsa Toleessaatti LibreOffice Nagaan Dhufte</a></li>\
    <li><a target="_top" href="om/text/simpress/main0503.html?DbPAR=IMPRESS">Amalawwan Impress LibreOffice</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Impressi LibreOffice keessatti furtuulee qaxxaamura fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/simpress/04/01020000.html?DbPAR=IMPRESS">Furtuuwwan Qaxxaamuraa LibreOffice Impreessiif</a></li>\
    <li><a target="_top" href="om/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Keyboard Shortcuts</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/main.html?DbPAR=IMPRESS">Ajajoota Impress LibreOffice fayyadamuuf fayyadan</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Baafattoota</label><ul>\
    <li><a target="_top" href="om/text/simpress/main0100.html?DbPAR=IMPRESS">Baafatoota</a></li>\
    <li><a target="_top" href="om/text/simpress/main0101.html?DbPAR=IMPRESS">Faayilii</a></li>\
    <li><a target="_top" href="om/text/simpress/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="om/text/simpress/main0103.html?DbPAR=IMPRESS">Mul&#39;isi</a></li>\
    <li><a target="_top" href="om/text/simpress/main0104.html?DbPAR=IMPRESS">Saagi</a></li>\
    <li><a target="_top" href="om/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="om/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="om/text/simpress/main0114.html?DbPAR=IMPRESS">Agarsiisa Islaayidii</a></li>\
    <li><a target="_top" href="om/text/simpress/main_tools.html?DbPAR=IMPRESS">Tools</a></li>\
    <li><a target="_top" href="om/text/simpress/main0107.html?DbPAR=IMPRESS">Foddaa</a></li>\
    <li><a target="_top" href="om/text/shared/main0108.html?DbPAR=IMPRESS">Gargaarsa</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Kamshaalee</label><ul>\
    <li><a target="_top" href="om/text/simpress/main0200.html?DbPAR=IMPRESS">Kamshaalee</a></li>\
    <li><a target="_top" href="om/text/simpress/main0210.html?DbPAR=IMPRESS">Kabala Fakkasaa</a></li>\
    <li><a target="_top" href="om/text/shared/main0227.html?DbPAR=IMPRESS">Kabala Tuqaalee Gulaali</a></li>\
    <li><a target="_top" href="om/text/shared/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="om/text/shared/main0226.html?DbPAR=IMPRESS">Kamshaa Saxaxa Unkaa</a></li>\
    <li><a target="_top" href="om/text/shared/main0213.html?DbPAR=IMPRESS">Naanna&#39;insa Unkaa Irraa</a></li>\
    <li><a target="_top" href="om/text/simpress/main0214.html?DbPAR=IMPRESS">Image Bar</a></li>\
    <li><a target="_top" href="om/text/simpress/main0202.html?DbPAR=IMPRESS">Sararaa fi Kabala Rigdoo</a></li>\
    <li><a target="_top" href="om/text/simpress/main0213.html?DbPAR=IMPRESS">Kabala Dirqalootaa</a></li>\
    <li><a target="_top" href="om/text/simpress/main0211.html?DbPAR=IMPRESS">Kabala Toorii</a></li>\
    <li><a target="_top" href="om/text/simpress/main0209.html?DbPAR=IMPRESS">Sarartuuwwan</a></li>\
    <li><a target="_top" href="om/text/simpress/main0212.html?DbPAR=IMPRESS">Kabala Foo&#39;aa Islaayidii</a></li>\
    <li><a target="_top" href="om/text/simpress/main0204.html?DbPAR=IMPRESS">Kabala Mul&#39;annoo Islaayidii</a></li>\
    <li><a target="_top" href="om/text/shared/main0201.html?DbPAR=IMPRESS">Kabala Durtii</a></li>\
    <li><a target="_top" href="om/text/simpress/main0206.html?DbPAR=IMPRESS">Kabala Haalojii</a></li>\
    <li><a target="_top" href="om/text/shared/main0204.html?DbPAR=IMPRESS">Kabala Gabatee</a></li>\
    <li><a target="_top" href="om/text/simpress/main0203.html?DbPAR=IMPRESS">Kabala Barruu Dhangeessuu</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="om/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Dhangii HTML keessatti pirezanteeshiini Olkaa&#39;u</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Fuuloota HTML gara pirezenteshiinotatti alaaguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Dhangii GLF keessatti sochii fakkii Alerguu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Wardiilee Islaaydii keessaa Dabalatee</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Aburaa Saaguu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="om/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="om/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatic Redaction</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Dhangeessuu</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Sararaa fi Halatoota Xiyyaa Fe&#39;u</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Haalluuwan Baraman Hiikuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Guutuu Gargaartoo Uumuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Halluuwwan bakka buusuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Wantoota Gurmeessuu,Hiriirsuu fi Raabsuu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/background.html?DbPAR=IMPRESS">Guttinsa Duubbee Islaayidii Jiijjiruuf</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/footer.html?DbPAR=IMPRESS">Islaayidoota Hundaaf iraatoo ykn Jalaantoo ida&#39;u</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Wantoota Siqsu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Maxxansuu</label><ul>\
    <li><a target="_top" href="om/text/simpress/guide/printing.html?DbPAR=IMPRESS">Pirezenteshiinoota maxxansu.</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Hamamtaa waraqaa waliin walsimsuuf islaayidii maxxansu.</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Galteewwan</label><ul>\
    <li><a target="_top" href="om/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Dhangii GLF keessatti sochii fakkii Alerguu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Islaayidii Pirezanteshiini keessatti sochii fakkina Wantootaa hojjachu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Cehumsoota Islaayidii Fakkeessu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Qaxxaamur - Laba&#39;uu Wantoota Lamaa</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Calqqeewwan GIF sochii Fakkeefaman Uumuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objects, Graphics, and Bitmaps</label><ul>\
    <li><a target="_top" href="om/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Wantoota Walittimakuu fi Boca kaasuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Wantoota Ramaduu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Seektaroota fi hirmaata qaamaa fakaasuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Wantoota Baayyisuu.</a></li>\
    <li><a target="_top" href="om/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformations</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Wantota Naanneessuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Wantoota G-3 walitti qabuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Sararawwan wal qunnamsiisuu.</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Arfiilee Barruu gara wantoota Fakkasaatti Jijjiiru</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Calaqqeewwan suurxiqqoo gara Saxaatoo Vecterit jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Wantoota G-2 gara Qonyootti, Rogabaay&#39;ee fi wantoota G-3 tti jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Sararaa fi Halatoota Xiyyaa Fe&#39;u</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Qonyoota Fakkasaa</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Qonyoota Gulaaluu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Aburaa Saaguu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Wardiilee Islaaydii keessaa Dabalatee</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Wantoota Siqsu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Wantoota Jala Sararaman Filadhu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Taafoloo yaa&#39;aa uumuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text in Presentations</label><ul>\
    <li><a target="_top" href="om/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Barrefama Ida&#39;uu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Arfiilee Barruu gara wantoota Fakkasaatti Jijjiiru</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Viewing</label><ul>\
    <li><a target="_top" href="om/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Tartiiba Islaayidii Jijjiiru</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Cuqoo Hakkoofsaatiin Guddisi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Slide Shows</label><ul>\
    <li><a target="_top" href="om/text/simpress/guide/show.html?DbPAR=IMPRESS">Agarsiisa Islaayidii Agarsiisuu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/individual.html?DbPAR=IMPRESS">Maamiloo agarsiisa islaayidii uumu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Yeroo yaalii islaayidii jijjiiruu</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Drawings (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="om/text/sdraw/main0000.html?DbPAR=DRAW">Baga Gargaarsa Fakkasaatti LibreOffice Nagaan Dhuftan</a></li>\
    <li><a target="_top" href="om/text/sdraw/main0503.html?DbPAR=DRAW">Amalawwan Fakkasaa LibreOffice</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Wantoota Fakaafamaniif furtuu qammaamuraa</a></li>\
    <li><a target="_top" href="om/text/sdraw/04/01020000.html?DbPAR=DRAW">Furtuuwwan Qaxxaamuraa Fakkafamawwaniif</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/main.html?DbPAR=DRAW">ajajawwaan kaafama $ ( office name)fayyadamuuf</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menus</label><ul>\
    <li><a target="_top" href="om/text/sdraw/main0100.html?DbPAR=DRAW">Baafatawwan</a></li>\
    <li><a target="_top" href="om/text/sdraw/main0101.html?DbPAR=DRAW">Faayilii</a></li>\
    <li><a target="_top" href="om/text/sdraw/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="om/text/sdraw/main0103.html?DbPAR=DRAW">View (menu in Draw)</a></li>\
    <li><a target="_top" href="om/text/sdraw/main_insert.html?DbPAR=DRAW">Insert</a></li>\
    <li><a target="_top" href="om/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="om/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="om/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="om/text/sdraw/main_tools.html?DbPAR=DRAW">Tools</a></li>\
    <li><a target="_top" href="om/text/simpress/main0107.html?DbPAR=DRAW">Foddaa</a></li>\
    <li><a target="_top" href="om/text/shared/main0108.html?DbPAR=DRAW">Gargaarsa</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Toolbars</label><ul>\
    <li><a target="_top" href="om/text/sdraw/main0200.html?DbPAR=DRAW">Kamshaalee</a></li>\
    <li><a target="_top" href="om/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D-Settings</a></li>\
    <li><a target="_top" href="om/text/sdraw/main0210.html?DbPAR=DRAW">Kabala Fakkasaa</a></li>\
    <li><a target="_top" href="om/text/shared/main0227.html?DbPAR=DRAW">Kabala Tuqaalee Gulaali</a></li>\
    <li><a target="_top" href="om/text/shared/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="om/text/shared/main0226.html?DbPAR=DRAW">Kamshaa Saxaxa Unkaa</a></li>\
    <li><a target="_top" href="om/text/shared/main0213.html?DbPAR=DRAW">Naanna&#39;insa Unkaa Irraa</a></li>\
    <li><a target="_top" href="om/text/sdraw/main0213.html?DbPAR=DRAW">Kabala Dirqalaawwanii</a></li>\
    <li><a target="_top" href="om/text/shared/main0201.html?DbPAR=DRAW">Kabala Durtii</a></li>\
    <li><a target="_top" href="om/text/shared/main0204.html?DbPAR=DRAW">Kabala Gabatee</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Loading, Saving, Importing, and Exporting</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Aburaa Saaguu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatting</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Sararaa fi Halatoota Xiyyaa Fe&#39;u</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/color_define.html?DbPAR=DRAW">Haalluuwan Baraman Hiikuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/gradient.html?DbPAR=DRAW">Guutuu Gargaartoo Uumuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Halluuwwan bakka buusuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Wantoota Gurmeessuu,Hiriirsuu fi Raabsuu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/background.html?DbPAR=DRAW">Guttinsa Duubbee Islaayidii Jiijjiruuf</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/move_object.html?DbPAR=DRAW">Wantoota Siqsu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Printing</label><ul>\
    <li><a target="_top" href="om/text/simpress/guide/printing.html?DbPAR=DRAW">Pirezenteshiinoota maxxansu.</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Hamamtaa waraqaa waliin walsimsuuf islaayidii maxxansu.</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effects</label><ul>\
    <li><a target="_top" href="om/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Qaxxaamur - Laba&#39;uu Wantoota Lamaa</a></li>\
    <li><a target="_top" href="om/text/shared/01/05350000.html?DbPAR=DRAW">Galteewwan 3D</a></li>\
    <li><a target="_top" href="om/text/simpress/02/10030000.html?DbPAR=DRAW">Transformations</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objects, Graphics, and Bitmaps</label><ul>\
    <li><a target="_top" href="om/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Wantoota Walittimakuu fi Boca kaasuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Seektaroota fi hirmaata qaamaa fakaasuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Wantoota Baayyisuu.</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Wantota Naanneessuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Wantoota G-3 walitti qabuu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Sararawwan wal qunnamsiisuu.</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/text2curve.html?DbPAR=DRAW">Arfiilee Barruu gara wantoota Fakkasaatti Jijjiiru</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/vectorize.html?DbPAR=DRAW">Calaqqeewwan suurxiqqoo gara Saxaatoo Vecterit jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/3d_create.html?DbPAR=DRAW">Wantoota G-2 gara Qonyootti, Rogabaay&#39;ee fi wantoota G-3 tti jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Sararaa fi Halatoota Xiyyaa Fe&#39;u</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/line_draw.html?DbPAR=DRAW">Qonyoota Fakkasaa</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/line_edit.html?DbPAR=DRAW">Qonyoota Gulaaluu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Aburaa Saaguu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/table_insert.html?DbPAR=DRAW">Wardiilee Islaaydii keessaa Dabalatee</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/move_object.html?DbPAR=DRAW">Wantoota Siqsu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/select_object.html?DbPAR=DRAW">Wantoota Jala Sararaman Filadhu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/orgchart.html?DbPAR=DRAW">Taafoloo yaa&#39;aa uumuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Groups and Layers</label><ul>\
    <li><a target="_top" href="om/text/sdraw/guide/groups.html?DbPAR=DRAW">Wantoota Ramaduu</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserting Layers</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="om/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text in Drawings</label><ul>\
    <li><a target="_top" href="om/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Barrefama Ida&#39;uu</a></li>\
    <li><a target="_top" href="om/text/simpress/guide/text2curve.html?DbPAR=DRAW">Arfiilee Barruu gara wantoota Fakkasaatti Jijjiiru</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Viewing</label><ul>\
    <li><a target="_top" href="om/text/simpress/guide/change_scale.html?DbPAR=DRAW">Cuqoo Hakkoofsaatiin Guddisi</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Database Functionality (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">General Information</label><ul>\
    <li><a target="_top" href="om/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="om/text/shared/guide/database_main.html?DbPAR=BASE">Ilaalcha Gubbaa Kuusdeetaa</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_new.html?DbPAR=BASE">Kuusdeetaa Haaraa Uumuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_tables.html?DbPAR=BASE">Gabateewwaniin Hojjechuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_queries.html?DbPAR=BASE">Gaafattootaan Hojjechuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_forms.html?DbPAR=BASE">Unkootaan Hojjechuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_reports.html?DbPAR=BASE">Gabaasota Uumuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_register.html?DbPAR=BASE">Kuusdeetaa Galmeessuu fi Haquu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_im_export.html?DbPAR=BASE">Bu&#39;ura keessaa Deetaa Alaaguu fi Alerguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Ajajoota SQL Hojjoomuu</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formulas (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="om/text/smath/main0000.html?DbPAR=MATH">Gara Gargarsa Herregaatti LibreOffice baga naggaan dhufte</a></li>\
    <li><a target="_top" href="om/text/smath/main0503.html?DbPAR=MATH">Amaloota Herregduu LibreOffice</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formula Elements</label><ul>\
    <li><a target="_top" href="om/text/smath/01/03090100.html?DbPAR=MATH">Ogeejjii Tokkee/Lamee</a></li>\
    <li><a target="_top" href="om/text/smath/01/03090200.html?DbPAR=MATH">Hariiroo</a></li>\
    <li><a target="_top" href="om/text/smath/01/03090800.html?DbPAR=MATH">Tuuta Dalagaalee</a></li>\
    <li><a target="_top" href="om/text/smath/01/03090400.html?DbPAR=MATH">Fankishinootas</a></li>\
    <li><a target="_top" href="om/text/smath/01/03090300.html?DbPAR=MATH">Ogeejjiilee</a></li>\
    <li><a target="_top" href="om/text/smath/01/03090600.html?DbPAR=MATH">Amaloota</a></li>\
    <li><a target="_top" href="om/text/smath/01/03090500.html?DbPAR=MATH">Sadallaa</a></li>\
    <li><a target="_top" href="om/text/smath/01/03090700.html?DbPAR=MATH">Dhangii</a></li>\
    <li><a target="_top" href="om/text/smath/01/03091600.html?DbPAR=MATH">Mallattoole kabiroo</a></li>\
      </ul></li>\
    <li><a target="_top" href="om/text/smath/guide/main.html?DbPAR=MATH">Ajajoota LibreOffice Math fayyadamuuf</a></li>\
    <li><a target="_top" href="om/text/smath/guide/keyboard.html?DbPAR=MATH">Qaxxaamura (LibreOffice Math Gaheenya)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Command and Menu Reference</label><ul>\
    <li><a target="_top" href="om/text/smath/main0100.html?DbPAR=MATH">Baafatoota</a></li>\
    <li><a target="_top" href="om/text/smath/main0200.html?DbPAR=MATH">Kamshaalee</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Working with Formulas</label><ul>\
    <li><a target="_top" href="om/text/smath/guide/align.html?DbPAR=MATH">Kutaale Foormulaa Hujeekan Hiriirsa Jira</a></li>\
    <li><a target="_top" href="om/text/smath/guide/color.html?DbPAR=MATH">Applying Color to Formula Parts</a></li>\
    <li><a target="_top" href="om/text/smath/guide/attributes.html?DbPAR=MATH">Amaloota Durtii jijjiira Jira</a></li>\
    <li><a target="_top" href="om/text/smath/guide/brackets.html?DbPAR=MATH">Kutaale Foormulaa sadallaa keessatti makaa jira</a></li>\
    <li><a target="_top" href="om/text/smath/guide/comment.html?DbPAR=MATH">Yaadota Galchaa Jira</a></li>\
    <li><a target="_top" href="om/text/smath/guide/newline.html?DbPAR=MATH">Cita Sararaa Saaga jira</a></li>\
    <li><a target="_top" href="om/text/smath/guide/parentheses.html?DbPAR=MATH">Sadallaa Saaga Jira</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Charts and Diagrams</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">General Information</label><ul>\
    <li><a target="_top" href="om/text/schart/main0000.html?DbPAR=CHART">Taattoota LibreOffice keessaa</a></li>\
    <li><a target="_top" href="om/text/schart/main0503.html?DbPAR=CHART">Amalawwan Chart LibreOffice</a></li>\
    <li><a target="_top" href="om/text/schart/04/01020000.html?DbPAR=CHART">Taattoowwaniif Qaxxaamuroota</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Macros and Scripting</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="om/text/sbasic/shared/main0601.html?DbPAR=BASIC">Gargaarsa LibreOffice Basic</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01000000.html?DbPAR=BASIC">Bu`uura LibreOffice wajjin saganteessu</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/00000002.html?DbPAR=BASIC">Jibsoo Basic LibreOffice</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01010210.html?DbPAR=BASIC">Bu`uurota</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01020000.html?DbPAR=BASIC">Caasimaa:</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01050000.html?DbPAR=BASIC">Bu`uura IDE LibreOffice</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01030100.html?DbPAR=BASIC">Ilaalcha gubbaa IDE</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01030200.html?DbPAR=BASIC">Bu`uura gulaalaa</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01050100.html?DbPAR=BASIC">Foddaa Ilaali</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/main0211.html?DbPAR=BASIC">Kamshaalee Maakroo</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/05060700.html?DbPAR=BASIC">Maakroo</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Command Reference</label><ul>\
    <li><a target="_top" href="om/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01020500.html?DbPAR=BASIC">Manbarroo, Mojuulii fi Qaaqalee</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Functions, Statements and Operators</label><ul>\
    <li><a target="_top" href="om/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100000.html?DbPAR=BASIC">Jijjiiramtoota</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03060000.html?DbPAR=BASIC">ogejjii yaayaa</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120000.html?DbPAR=BASIC">Diraawwan</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030000.html?DbPAR=BASIC">Faankishinii Guyyaa fi yeroo</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03070000.html?DbPAR=BASIC">Yaayaa Herreegaa</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080000.html?DbPAR=BASIC">Faankishinoota lakkofsaa</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080100.html?DbPAR=BASIC">Faankishinoota Triigoomeetrikii</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010000.html?DbPAR=BASIC">Faankishinoota I/O argii</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020000.html?DbPAR=BASIC">Faankishinoota I/O Faayilii</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090000.html?DbPAR=BASIC">Too&#39;annaa Sagantaa Raawwii</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03050000.html?DbPAR=BASIC">Fankishinii Qabannoo Dogogora</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03130000.html?DbPAR=BASIC">Ajajawwan Biroo</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080300.html?DbPAR=BASIC">Lakkoofsota tasa uumuu</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090400.html?DbPAR=BASIC">Himoota Dabalataa</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alphabetic List of Functions, Statements and Operators</label><ul>\
    <li><a target="_top" href="om/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03050000.html?DbPAR=BASIC">Fankishinii Qabannoo Dogogora</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080000.html?DbPAR=BASIC">Faankishinoota lakkofsaa</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080400.html?DbPAR=BASIC">Shallaggii iskuweer ruuttii</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write Statement</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03120300.html?DbPAR=BASIC">Qabiyyeewwan Diraa Gulaaluu</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01020100.html?DbPAR=BASIC">Jijjiiramoota gargaaramuu</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Advanced Basic Libraries</label><ul>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard Library</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Library</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForge Library</label><ul>\
    <li><a target="_top" href="om/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge Libraries</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guides</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/macro_recording.html?DbPAR=BASIC">Maakroo tokko kuufachuu</a></li>\
    <li><a target="_top" href="om/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Amaloota too&#39;annoota Qaaqa Gulaalaa keessaa jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Gulaalaa Qaaqaa keessaatti Too&#39;annoota uumuu</a></li>\
    <li><a target="_top" href="om/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Gulaalaa Qaaqicha keessaa Too&#39;annootaaf Fakkeenyoota Saganteessuu</a></li>\
    <li><a target="_top" href="om/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="om/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Qaaqa Bu&#39;uuraa uumu</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01030400.html?DbPAR=BASIC">Qindeessuu Manbarroo fi Mojuulii</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01020100.html?DbPAR=BASIC">Jijjiiramoota gargaaramuu</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01020200.html?DbPAR=BASIC">Wantoota gargaaramuu</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01030300.html?DbPAR=BASIC">Sagantaa Bu`uura Qulqulleessuu</a></li>\
    <li><a target="_top" href="om/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="om/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="om/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic to Python</a></li>\
    <li><a target="_top" href="om/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python Scripts Help</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="om/text/sbasic/python/main0000.html?DbPAR=BASIC">Python Scripts</a></li>\
    <li><a target="_top" href="om/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE for Python</a></li>\
    <li><a target="_top" href="om/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="om/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programming with Python</label><ul>\
    <li><a target="_top" href="om/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="om/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python examples</a></li>\
    <li><a target="_top" href="om/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Script Development Tools</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice Installation</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Firoomina Akaakuuwwan Galmee Maayikroosoofti Offisii jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Safe Mode</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Common Help Topics</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">General Information</label><ul>\
    <li><a target="_top" href="om/text/shared/main0400.html?DbPAR=SHARED">Qabduuwwan Qaxxaamuraa</a></li>\
    <li><a target="_top" href="om/text/shared/00/00000005.html?DbPAR=SHARED">Jibsoo Waliigalaa</a></li>\
    <li><a target="_top" href="om/text/shared/00/00000002.html?DbPAR=SHARED">Jibsoo Jechoota Intarneetii</a></li>\
    <li><a target="_top" href="om/text/shared/guide/accessibility.html?DbPAR=SHARED">Gaheenya LibreOffice keessaa</a></li>\
    <li><a target="_top" href="om/text/shared/guide/keyboard.html?DbPAR=SHARED">Qaxxaamuroota (Gaheenya LibreOffice)</a></li>\
    <li><a target="_top" href="om/text/shared/04/01010000.html?DbPAR=SHARED">Furtuuwwan Qaxxaamuraa waliigala LibreOffice keessaa</a></li>\
    <li><a target="_top" href="om/text/shared/guide/version_number.html?DbPAR=SHARED">Fooyya&#39;oota fi Ijaari Lakkoofsaa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice and Microsoft Office</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/ms_user.html?DbPAR=SHARED">Maykiroosoftii Ofiisii fi LibreOffice fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Waliin madaallii Maayikroosooftii Ofiis fi wantoota LibreOffice</a></li>\
    <li><a target="_top" href="om/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Waa&#39;ee Galmeewwan Maaykiroosoofti Offisii Jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Firoomina Akaakuuwwan Galmee Maayikroosoofti Offisii jijjiiruu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice Options</label><ul>\
    <li><a target="_top" href="om/text/shared/optionen/01000000.html?DbPAR=SHARED">Dirqaalaalee</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01010100.html?DbPAR=SHARED">Deetaa Fayyadamaa</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01010200.html?DbPAR=SHARED">Dimshaasha</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01010800.html?DbPAR=SHARED">Argi</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01010900.html?DbPAR=SHARED">Dirqaalaalee Maxxansaa</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01010300.html?DbPAR=SHARED">Daandiilee</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01010700.html?DbPAR=SHARED">Bocquuwwan</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01030300.html?DbPAR=SHARED">Ittisa</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01012000.html?DbPAR=SHARED">Application Colors</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01013000.html?DbPAR=SHARED">Gaheenya</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/java.html?DbPAR=SHARED">Advanced</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01010400.html?DbPAR=SHARED">Gargaarsa barreessuu</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01010600.html?DbPAR=SHARED">Dimshaasha</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01020000.html?DbPAR=SHARED">Dirqaalaalee Fe&#39;i/Olkaa&#39;i</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01030000.html?DbPAR=SHARED">Dirqaalaalee interneetii</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01040000.html?DbPAR=SHARED">Dirqaalaalee galmee barruu</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01050000.html?DbPAR=SHARED">Dirqaalaalee galmee HTML</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01060000.html?DbPAR=SHARED">Dirqaalaalee wardii</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01070000.html?DbPAR=SHARED">Dirqaalaalee dhiyeessaa</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01080000.html?DbPAR=SHARED">Dirqaalaalee Fakkisaa</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01090000.html?DbPAR=SHARED">Foormulaa</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01110000.html?DbPAR=SHARED">Dirqaalaalee taattoo</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01130100.html?DbPAR=SHARED">Amaloota VBA</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01130200.html?DbPAR=SHARED">Maaykiroosooft office</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01150000.html?DbPAR=SHARED">Dirqaalaalee qindaa&#39;ina afaanii</a></li>\
    <li><a target="_top" href="om/text/shared/optionen/01160000.html?DbPAR=SHARED">Dirqaalaalee madda deetaa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Wizards</label><ul>\
    <li><a target="_top" href="om/text/shared/autopi/01000000.html?DbPAR=SHARED">Masaka</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Masakaa Xalayaa</label><ul>\
    <li><a target="_top" href="om/text/shared/autopi/01010000.html?DbPAR=SHARED">Masakaa Xalayaa</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Masakaa Fakasii</label><ul>\
    <li><a target="_top" href="om/text/shared/autopi/01020000.html?DbPAR=SHARED">Masakaa Fakasii</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Masaka Ajandaa</label><ul>\
    <li><a target="_top" href="om/text/shared/autopi/01040000.html?DbPAR=SHARED">Masaka Ajandaa</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML Export Wizard</label><ul>\
    <li><a target="_top" href="om/text/shared/autopi/01110000.html?DbPAR=SHARED">HTML Alerguu</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Document Converter Wizard</label><ul>\
    <li><a target="_top" href="om/text/shared/autopi/01130000.html?DbPAR=SHARED">Jijjiirtuu Galmee</a></li>\
      </ul></li>\
    <li><a target="_top" href="om/text/shared/autopi/01150000.html?DbPAR=SHARED">Masaka jijjiirtuu Euro</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configuring LibreOffice</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/configure_overview.html?DbPAR=SHARED">LibreOffice qindeessuu</a></li>\
    <li><a target="_top" href="om/text/shared/01/packagemanager.html?DbPAR=SHARED">Taliiga Dheertoo</a></li>\
    <li><a target="_top" href="om/text/shared/guide/flat_icons.html?DbPAR=SHARED">Mul&#39;annoowwan Sajoo Jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Kamshaawwanitti qabduu Ida&#39;uu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/workfolder.html?DbPAR=SHARED">Galeeloo Hojii Kee Jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Yaadannoo Teessoo Galmeessuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/formfields.html?DbPAR=SHARED">Qabduu Saaguu fi Gulaaluu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Working with the User Interface</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Naanna&#39;insa Ariitiin Waantoota bira Qaqqabuuf</a></li>\
    <li><a target="_top" href="om/text/shared/guide/navigator.html?DbPAR=SHARED">Naanna&#39;aa ilaalcha gubbaa galmee</a></li>\
    <li><a target="_top" href="om/text/shared/guide/autohide.html?DbPAR=SHARED">Foddaawwan Agarsisuu, Hidhuu fi Dhoksuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/textmode_change.html?DbPAR=SHARED">Haalata Saagii fi Haalata Irrabaa Gidduu Jijijjiiruu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Kamshaawwan Fayyadamuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digital Signatures</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Waa&#39;ee Mallattoowwan Lakqurxaawaa</a></li>\
    <li><a target="_top" href="om/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Mallattoowwan Lakqurxaawaa Fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="om/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="om/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="om/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="om/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="om/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Printing, Faxing, Sending</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/labels_database.html?DbPAR=SHARED">Teessoo Asxaalee maxxansuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Gurraacha fi Adiitiin Maxxansuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="om/text/shared/guide/fax.html?DbPAR=SHARED">Faaksii gochuuf LibreOffice Qindeessuu fi  Faaksiiwwan erguu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Drag & Drop</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/dragdrop.html?DbPAR=SHARED">Galmee LibreOffice Keessaa Harkisanii Kaa&#39;uu</a></li>\
    <li><a target="_top" href="om/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Galmeewwaan keessa Barruu Garagalchuu fi Siiqsuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Naannoowwan Wardii gara Galmeewwan Barruutti Garagalchuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Saxaatoo Galmeewwan Gidduu Garagalchuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kuusaa faayaa Irraa Saxaatoo Garagalchuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Mul&#39;annoo Madda Deetaatiin Harkisii Kaa&#39;i</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copy and Paste</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Wantoota Fakkaasa Garakeessa Galmeewwan Birootti Garagalchuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Saxaatoo Galmeewwan Gidduu Garagalchuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kuusaa faayaa Irraa Saxaatoo Garagalchuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Naannoowwan Wardii gara Galmeewwan Barruutti Garagalchuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Charts and Diagrams</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/chart_insert.html?DbPAR=SHARED">Taattoowwan Saagu</a></li>\
    <li><a target="_top" href="om/text/schart/main0000.html?DbPAR=SHARED">Taattoota LibreOffice keessaa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Load, Save, Import, Export, PDF</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/doc_open.html?DbPAR=SHARED">Galmeewwan Banuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/import_ms.html?DbPAR=SHARED">Galmeewwan dhangiiwwan birootiin ol kaa&#39;aman banuu.</a></li>\
    <li><a target="_top" href="om/text/shared/guide/doc_save.html?DbPAR=SHARED">Galmeewwan Ol kaa&#39;uu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Galmeewwan Ofumaan Ol kaa&#39;uu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/export_ms.html?DbPAR=SHARED">Galmeewwan Dhangiiwwan birootiin Ol kaa&#39;uu</a></li>\
    <li><a target="_top" href="om/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Akka PDF tti Aleergi</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Deetaa Dhangii Barruu tiin Alaaguu fi Alerguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Links and References</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Geessitoota Saaguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Geessitoota Sadhaatawaa fi Haqaa</a></li>\
    <li><a target="_top" href="om/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Geessitoota Gulaaluu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Document Version Tracking</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Fooyya`oota Galmee Walmadaalsisuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Makinsa Fooyya`oota</a></li>\
    <li><a target="_top" href="om/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Jijjiirraa Kuusuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/redlining.html?DbPAR=SHARED">Kuusuu fi agarsiisuu Jijjiirraa</a></li>\
    <li><a target="_top" href="om/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Jijjiirraa fudhuu ykn Gatuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Taliigaa Fooyya`aa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Labels and Business Cards</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/labels.html?DbPAR=SHARED">Asxaalee fi Kaardota Bunaqaa Uumuu fi Maxxansuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Inserting External Data</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/copytable2application.html?DbPAR=SHARED">Deetaa Wardiiwwan Irraa Saaguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/copytext2application.html?DbPAR=SHARED">Galmeewwan Barruu Irraa Deetaa Saaguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Suurxiqqoo Saaguu, Gulaaluu, Olkaa&#39;uu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Kuusaa faayaatti Saxaatoo Ida&#39;uu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automatic Functions</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Beekommii URL ofumaan dhaamsuu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Searching and Replacing</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/data_search2.html?DbPAR=SHARED">Gingilchaa Unkaatiin Barbaaduu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_search.html?DbPAR=SHARED">Gabateewwanii fi Galmeewwan Unkaa Barbaaduu</a></li>\
    <li><a target="_top" href="om/text/shared/01/02100001.html?DbPAR=SHARED">Himannoowwan Idilee Tarree</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guides</label><ul>\
    <li><a target="_top" href="om/text/shared/guide/linestyles.html?DbPAR=SHARED">Akkaataalee Sarara Fayyadamuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/text_color.html?DbPAR=SHARED">Halluu Barruu Jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/change_title.html?DbPAR=SHARED">Mataduree Galmee Jijjiiruu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/round_corner.html?DbPAR=SHARED">Karaa Xiyyoolee Uumuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/background.html?DbPAR=SHARED">Halluuwwan Duubbee yookiin Saxaatoo Duubbee Qindeessuu.</a></li>\
    <li><a target="_top" href="om/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="om/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="om/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Akkaataalee Sarara Hiikuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Wantoota Saxaatoo Gulaaluu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/line_intext.html?DbPAR=SHARED">Barruu keessatti sararoota fakkasuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/aaa_start.html?DbPAR=SHARED">Ejjatoowwan Tokkoffaa</a></li>\
    <li><a target="_top" href="om/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Kuusaa faayaa Irraa Wantoota Saaguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="om/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Arfiiwwan Addaa Saaguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/tabs.html?DbPAR=SHARED">Dhaabataalee Caancalaa Saaguu fi Gulaaluu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Using Remote Files</a></li>\
    <li><a target="_top" href="om/text/shared/guide/protection.html?DbPAR=SHARED">Qabiyyee LibreOffice keessaa Eeguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Kuusaawwan Eeguu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Fuula irraa Naannoo Maxansaamuu Danda&#39;an Keessaa isa Olaantoo Filuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/measurement_units.html?DbPAR=SHARED">Safartuuwwan Filuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/language_select.html?DbPAR=SHARED">Galmee Afaanii filuu</a></li>\
    <li><a target="_top" href="om/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Saxaxa Gabatee</a></li>\
    <li><a target="_top" href="om/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Keewwatoota Kophaaf Rasaasaalee fi Lakkaawwii dhaamsuu</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
