document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Testu-dokumentuak (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Informazio orokorra eta erabiltzaile-interfazearen erabilera</label><ul>\
    <li><a target="_top" href="eu/text/swriter/main0000.html?DbPAR=WRITER">Ongi etorri LibreOffice Writerren laguntzara</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0503.html?DbPAR=WRITER">LibreOffice Writerren eginbideak</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/main.html?DbPAR=WRITER">LibreOffice Writer erabiltzeko argibideak</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Leihoak atrakatzea eta tamainaz aldatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/04/01020000.html?DbPAR=WRITER">LibreOffice Writerreko laster-teklak</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/words_count.html?DbPAR=WRITER">Hitzak zenbatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/keyboard.html?DbPAR=WRITER">Laster-teklak erabiltzea (LibreOffice Writerreko erabilerraztasuna)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Komandoen eta menuen erreferentzia</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menuak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/main0100.html?DbPAR=WRITER">Menuak</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0101.html?DbPAR=WRITER">Fitxategia</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0102.html?DbPAR=WRITER">Editatu</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0103.html?DbPAR=WRITER">Ikusi</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0104.html?DbPAR=WRITER">Txertatu</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0105.html?DbPAR=WRITER">Formatua</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0115.html?DbPAR=WRITER">Estiloak (menua)</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0110.html?DbPAR=WRITER">Taula</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0120.html?DbPAR=WRITER">Inprimakia menua</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0106.html?DbPAR=WRITER">Tresnak</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0107.html?DbPAR=WRITER">Leihoa</a></li>\
    <li><a target="_top" href="eu/text/shared/main0108.html?DbPAR=WRITER">Laguntza</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Tresna-barrak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/main0200.html?DbPAR=WRITER">Tresna-barrak</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0206.html?DbPAR=WRITER">&#39;Buletak eta zenbakitzea&#39; barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0205.html?DbPAR=WRITER">Marrazki-objektuen propietateen barra</a></li>\
    <li><a target="_top" href="eu/text/shared/find_toolbar.html?DbPAR=WRITER">&#39;Bilatu&#39; barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0226.html?DbPAR=WRITER">Inprimaki-diseinuaren tresna-barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0213.html?DbPAR=WRITER">Inprimaki-nabigazioaren barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0202.html?DbPAR=WRITER">Formatua barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0214.html?DbPAR=WRITER">Formula barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0215.html?DbPAR=WRITER">Markoa barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0203.html?DbPAR=WRITER">Irudia barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo tresna-barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0216.html?DbPAR=WRITER">OLE objektua barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0210.html?DbPAR=WRITER">Inprimatze-aurrebistaren barra (Writer)</a></li>\
    <li><a target="_top" href="eu/text/shared/main0214.html?DbPAR=WRITER">Kontsulta-diseinuaren barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0213.html?DbPAR=WRITER">Erregelak</a></li>\
    <li><a target="_top" href="eu/text/shared/main0201.html?DbPAR=WRITER">Estandarra barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0208.html?DbPAR=WRITER">Egoera-barra (Writer)</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0204.html?DbPAR=WRITER">Taula barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0212.html?DbPAR=WRITER">Taula-datuen barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/main0220.html?DbPAR=WRITER">Testu-objektua barra</a></li>\
    <li><a target="_top" href="eu/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">&#39;Aldaketen jarraipena&#39; tresna-barra</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Testu-dokumentuetan nabigatzea</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Teklatuaren bidez nabigatzea eta hautatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Dokumentuetan testua lekuz aldatzea eta kopiatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Dokumentua nabigatzailearen bidez berrantolatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Hiperestekak nabigatzailearen bidez txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/navigator.html?DbPAR=WRITER">Testu-dokumentuentzako nabigatzailea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Zuzeneko kurtsorea erabiltzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Testu dokumentuei formatua ematea</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Orrialde-orientazioa aldatzea (horizontala edo bertikala)</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/text_capital.html?DbPAR=WRITER">Testuko maiuskulak eta minuskulak aldatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Testua ezkutatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Goiburuko eta orri-oin ezberdinak definitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Goiburukoan edo orri-oinean kapitulu-izena edo -zenbakia txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Testu-formatua aplikatzea idazten duzun bitartean</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/reset_format.html?DbPAR=WRITER">Karaktere-atributuak berrezartzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Estiloak formatu interaktiboaren moduan aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/wrap.html?DbPAR=WRITER">Testua objektuen inguruan egokitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Markoak erabiltzea testua orrialdean zentratzeko</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Testua nabarmentzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Testua biratzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/page_break.html?DbPAR=WRITER">Orrialde-jauziak txertatzea eta ezabatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Orrialde-estiloak sortzea eta aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/subscript.html?DbPAR=WRITER">Testua goi-indize edo azpiindize bihurtzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Txantiloiak eta estiloak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Txantiloiak eta estiloak</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Orrialde-estiloak orrialde bakoiti eta bikoitien artean txandakatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/change_header.html?DbPAR=WRITER">Uneko orrialdean oinarritutako orrialde-estiloa sortzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/load_styles.html?DbPAR=WRITER">Beste dokumentu edo txantiloi bateko estiloak erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Estilo berriak hautapenetik sortzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Estiloak hautapenetatik eguneratzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/standard_template.html?DbPAR=WRITER">Txantiloi lehenetsiak eta pertsonalizatuak sortzea eta aldatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/template_manager.html?DbPAR=WRITER">Txantiloi-kudeatzailea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Grafikoak testu-dokumentuetan</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Grafikoak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Grafikoa fitxategitik txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Grafikoak galeriatik txertatzea arrastatu eta jareginen bidez</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Eskaneatutako irudiak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Calc diagramak testu-dokumentuan txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Grafikoak LibreOffice Draw edo Impressetik txertatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Taulak testu-dokumentuetan</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Zenbaki-ezagutzea aktibatzea edo desaktibatzea tauletan</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/tablemode.html?DbPAR=WRITER">Errenkadak eta zutabeak teklatuaren bidez aldatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/table_delete.html?DbPAR=WRITER">Taulak edo taulen edukia ezabatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/table_insert.html?DbPAR=WRITER">Taulak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Taularen goiburukoa beste orrialde batean errepikatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Testu-tauletako errenkada eta zutabeei tamaina aldatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objektuak testu-dokumentuetan</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Objektuak kokatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/wrap.html?DbPAR=WRITER">Testua objektuen inguruan egokitzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sekzioak eta markoak testu-dokumentuetan</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/sections.html?DbPAR=WRITER">Sekzioak erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/text_frame.html?DbPAR=WRITER">Markoak txertatzea, editatzea eta estekatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/section_edit.html?DbPAR=WRITER">Sekzioak editatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/section_insert.html?DbPAR=WRITER">Sekzioak txertatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Aurkibideak eta indizeak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Kapitulu-zenbakitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Erabiltzaileak definitutako indizeak</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Aurkibideak sortzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/indices_index.html?DbPAR=WRITER">Indize alfabetikoak sortzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Hainbat dokumentu barne hartzen dituzten indizeak</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Bibliografiak sortzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Indize eta tauletako sarrerak editatzea edo ezabatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Indize eta taulen edukiak eguneratzea, editatzea eta ezabatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Indize edo aurkibideetako sarrerak definitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/indices_form.html?DbPAR=WRITER">Indize edo aurkibideei formatua ematea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Eremuak testu-dokumentuetan</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/fields.html?DbPAR=WRITER">Eremuei buruz</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/fields_date.html?DbPAR=WRITER">Data-eremu finkoak edo aldakorrak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/field_convert.html?DbPAR=WRITER">Eremuak testu bihurtzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Testu-dokumentuetan kalkulatzea</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Taula anitzekin kalkulatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/calculate.html?DbPAR=WRITER">Testu-dokumentuetan kalkulatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Formulen emaitzak testu-dokumentuan kalkulatzea eta itsastea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Tauletan gelaxketako batuketak egitea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Testu-dokumentuetan formula konplexuak kalkulatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Taulako kalkuluaren emaitza beste taula batean bistaratzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Testu-elementu bereziak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/captions.html?DbPAR=WRITER">Epigrafeak erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Baldintzapeko testua</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Baldintzapeko testua orrialde kopuruarentzat</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/fields_date.html?DbPAR=WRITER">Data-eremu finkoak edo aldakorrak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Sarrera-eremuak gehitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Hurrengo orrialdeen orrialde-zenbakiak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Orrialde-zenbakiak orri-oinean txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Testua ezkutatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Goiburuko eta orri-oin ezberdinak definitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Goiburukoan edo orri-oinean kapitulu-izena edo -zenbakia txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Erabiltzaile-datuak eremu edo baldintzetan kontsultatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Oin-oharrak edo amaiera-oharrak txertatzea eta editatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Oin-oharren arteko tartea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/header_footer.html?DbPAR=WRITER">Goiburuko eta orri-oinei buruz</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Goiburukoei edo orri-oinei formatua ematea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/text_animation.html?DbPAR=WRITER">Testua animatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Gutun-ereduak sortzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Funtzio automatikoak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Autozuzenketaren zerrendari salbuespenak gehitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/autotext.html?DbPAR=WRITER">Autotestua erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Zenbakitutako edo buletdun zerrendak sortzea idaztean</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/auto_off.html?DbPAR=WRITER">Autozuzenketa desaktibatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Ortografia automatikoki egiaztatu</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Zenbaki-ezagutzea aktibatzea edo desaktibatzea tauletan</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Hitz-zatiketa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Zenbakitzea eta zerrendak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Epigrafeei kapitulu-zenbakiak gehitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Zenbakitutako edo buletdun zerrendak sortzea idaztean</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Kapitulu-zenbakitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Zerrenda-paragrafo baten zerrenda-maila aldatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Zenbakitutako zerrendak konbinatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Lerro-zenbakiak gehitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Ordenatutako zerrenda baten zenbakitzea aldatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Zenbaki-barrutiak zehaztea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Zenbakitzea gehitzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Zenbakitzea eta paragrafo-estiloak</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Buletak gehitzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Ortografia-egiaztatzea, sinonimoen hiztegiak eta hizkuntzak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Ortografia automatikoki egiaztatu</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Hitzak erabiltzaileak definitutako hiztegitik kentzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Sinonimoak</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Ortografia eta gramatika egiaztatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Erroreak konpontzeko aholkuak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Orrialdearen goian dagoen taularen aurretik testua txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Laster-marka zehatzera joatea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Kargatzea, gordetzea, inportatzea, esportatzea eta estaltzea</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/send2html.html?DbPAR=WRITER">Testu-dokumentuak HTML formatuan gordetzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Testu-dokumentu osoa txertatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/redaction.html?DbPAR=WRITER">Estaltzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/auto_redact.html?DbPAR=WRITER">Estaltze automatikoa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Dokumentu maisuak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Dokumentu maisuak eta azpidokumentuak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Estekak eta erreferentziak</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/references.html?DbPAR=WRITER">Erreferentzia gurutzatuak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Hiperestekak nabigatzailearen bidez txertatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Inprimatzea</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/print_selection.html?DbPAR=WRITER">Hautatu zer inprimatuko den</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Inprimatzeko paper-erretiluak hautatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/print_preview.html?DbPAR=WRITER">Orrialdea inprimatu aurretik ikustea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/print_small.html?DbPAR=WRITER">Hainbat orrialde orri bakarrean inprimatzea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Orrialde-estiloak sortzea eta aplikatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Bilatzea eta ordeztea</label><ul>\
    <li><a target="_top" href="eu/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Adierazpen erregularrak erabiltzea testu-bilaketetan</a></li>\
    <li><a target="_top" href="eu/text/shared/01/02100001.html?DbPAR=WRITER">Adierazpen erregularren zerrenda</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML dokumentuak (Writer Web)</label><ul>\
    <li><a target="_top" href="eu/text/shared/07/09000000.html?DbPAR=WRITER">Web orriak</a></li>\
    <li><a target="_top" href="eu/text/shared/02/01170700.html?DbPAR=WRITER">HTML iragazkiak eta inprimakiak</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/send2html.html?DbPAR=WRITER">Testu-dokumentuak HTML formatuan gordetzea</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Kalkulu-orriak (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Informazio orokorra eta erabiltzaile-interfazearen erabilera</label><ul>\
    <li><a target="_top" href="eu/text/scalc/main0000.html?DbPAR=CALC">Ongi etorri LibreOffice Calc-en laguntzara</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0503.html?DbPAR=CALC">LibreOffice Cal-en ezaugarriak</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/keyboard.html?DbPAR=CALC">Laster-teklak (LibreOffice Calc-eko erabilerraztasuna)</a></li>\
    <li><a target="_top" href="eu/text/scalc/04/01020000.html?DbPAR=CALC">Kalkulu-orrietako laster-teklak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Kalkuluaren zehaztasuna</a></li>\
    <li><a target="_top" href="eu/text/scalc/05/02140000.html?DbPAR=CALC">LibreOffice Calc-eko errore-kodeak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060112.html?DbPAR=CALC">LibreOffice Calc-en programatzeko osagarria</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/main.html?DbPAR=CALC">LibreOffice Calc erabiltzeko argibideak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Komandoen eta menuen erreferentzia</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menuak</label><ul>\
    <li><a target="_top" href="eu/text/scalc/main0100.html?DbPAR=CALC">Menuak</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0101.html?DbPAR=CALC">Fitxategia</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0102.html?DbPAR=CALC">Editatu</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0103.html?DbPAR=CALC">Ikusi</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0104.html?DbPAR=CALC">Txertatu</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0105.html?DbPAR=CALC">Formatua</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0116.html?DbPAR=CALC">Orria</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0112.html?DbPAR=CALC">Datuak</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0106.html?DbPAR=CALC">Tresnak</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0107.html?DbPAR=CALC">Leihoa</a></li>\
    <li><a target="_top" href="eu/text/shared/main0108.html?DbPAR=CALC">Laguntza</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Tresna-barrak</label><ul>\
    <li><a target="_top" href="eu/text/scalc/main0200.html?DbPAR=CALC">Tresna-barrak</a></li>\
    <li><a target="_top" href="eu/text/shared/find_toolbar.html?DbPAR=CALC">&#39;Bilatu&#39; barra</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0202.html?DbPAR=CALC">Formatu-barra</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0203.html?DbPAR=CALC">Marrazki-objektuen propietateen barra</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0205.html?DbPAR=CALC">&#39;Testu-formatua&#39; barra</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0206.html?DbPAR=CALC">Formula-barra</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0208.html?DbPAR=CALC">Egoera barra</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0210.html?DbPAR=CALC">Inprimatzeko aurrebistaren barra</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0214.html?DbPAR=CALC">Irudia barra</a></li>\
    <li><a target="_top" href="eu/text/scalc/main0218.html?DbPAR=CALC">Tresna-barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0201.html?DbPAR=CALC">Estandarra barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0212.html?DbPAR=CALC">Taula-datuen barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0213.html?DbPAR=CALC">Inprimaki-nabigazioaren barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0214.html?DbPAR=CALC">Kontsulta-diseinuaren barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0226.html?DbPAR=CALC">Inprimaki-diseinuaren tresna-barra</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Funtzio motak eta eragileak</label><ul>\
    <li><a target="_top" href="eu/text/scalc/01/04060000.html?DbPAR=CALC">Funtzioen morroia</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060100.html?DbPAR=CALC">Funtzioak kategoriaren arabera</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060107.html?DbPAR=CALC">Matrize-funtzioak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060120.html?DbPAR=CALC">Bit mailako eragiketen funtzioak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060101.html?DbPAR=CALC">Datu-baseen funtzioak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060102.html?DbPAR=CALC">Data eta orduaren funtzioak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060103.html?DbPAR=CALC">Finantza-funtzioak. Lehen zatia</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060119.html?DbPAR=CALC">Finantza Funtzioak. Bigarren zatia</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060118.html?DbPAR=CALC">Finantza-funtzioak. Hirugarren zatia</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060104.html?DbPAR=CALC">Informazio-funtzioak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060105.html?DbPAR=CALC">Funtzio logikoak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060106.html?DbPAR=CALC">Funtzio matematikoak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060108.html?DbPAR=CALC">Funtzio estatistikoak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060181.html?DbPAR=CALC">Estatistika-funtzioak. Lehen zatia.</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060182.html?DbPAR=CALC">Estatistika-funtzioak. Bigarren zatia.</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060183.html?DbPAR=CALC">Estatistika-funtzioak. Hirugarren zatia.</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060184.html?DbPAR=CALC">Estatistika-funtzioak. Laugarren zatia.</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060185.html?DbPAR=CALC">Estatistika-funtzioak. Bosgarren zatia.</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060109.html?DbPAR=CALC">Kalkulu-orrietako funtzioak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060110.html?DbPAR=CALC">Testu-funtzioak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060111.html?DbPAR=CALC">Osagarri-funtzioak</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060115.html?DbPAR=CALC">Osagarri-funtzioak, analisi-funtzioen zerrendaren lehen zatia</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060116.html?DbPAR=CALC">Osagarri-funtzioak, analisi-funtzioen zerrendaren bigarren zatia</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/04060199.html?DbPAR=CALC">LibreOffice Calc-eko eragileak</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Erabiltzaileak definitutako funtzioak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Kargatzea, gordetzea, inportatzea, esportatzea eta estaltzea</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/webquery.html?DbPAR=CALC">Kanpoko datuak txertatzea taulan (web kontsulta)</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/html_doc.html?DbPAR=CALC">Orriak HTML gisa gorde eta irekitzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/csv_formula.html?DbPAR=CALC">Testu fitxategiak inportatzea eta esportatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/redaction.html?DbPAR=CALC">Estaltzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/auto_redact.html?DbPAR=CALC">Estaltze automatikoa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formatua</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/text_rotate.html?DbPAR=CALC">Testua biratzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/text_wrap.html?DbPAR=CALC">Lerro anitzeko testua idaztea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/text_numbers.html?DbPAR=CALC">Zenbakiak testu gisa formateatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/super_subscript.html?DbPAR=CALC">Testuaren goi-indizea / azpiindizea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/row_height.html?DbPAR=CALC">Errenkaden altuera edo zutabeen zabalera aldatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Baldintzapeko formatua aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Zenbaki negatiboak nabarmentzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Formatua formula bidez esleitzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Ezkerreko zeroak dituzten zenbakiak sartzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/format_table.html?DbPAR=CALC">Kalkulu-orriak formateatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/format_value.html?DbPAR=CALC">Dezimalak dituzten zenbakiak formateatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/value_with_name.html?DbPAR=CALC">Gelaxkei izena jartzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/table_rotate.html?DbPAR=CALC">Taulak biratzea (iraultzea)</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/rename_table.html?DbPAR=CALC">Orrien izena aldatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx urteak</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Zenbaki biribilduak erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/currency_format.html?DbPAR=CALC">Moneta-formatuko gelaxkak</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/autoformat.html?DbPAR=CALC">Tauletan autoformatua erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/note_insert.html?DbPAR=CALC">Iruzkinak txertatzea eta editatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/design.html?DbPAR=CALC">Orrietarako azalak hautatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Zatikiak sartzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Iragaztea eta ordenatzea</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/filters.html?DbPAR=CALC">Iragazkiak aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/specialfilter.html?DbPAR=CALC">Iragazki aurreratuak aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/autofilter.html?DbPAR=CALC">Iragazki automatikoa aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/sorted_list.html?DbPAR=CALC">Ordenatze-zerrendak aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Balio bikoiztuak kentzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Inprimatzea</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/print_title_row.html?DbPAR=CALC">Errenkadak edo zutabeak orrialde guztietan inprimatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/print_landscape.html?DbPAR=CALC">Orriak formatu horizontalean inprimatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/print_details.html?DbPAR=CALC">Orriaren xehetasunak inprimatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/print_exact.html?DbPAR=CALC">Inprimatu beharreko orri kopurua definitzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Datu-barrutiak</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/database_define.html?DbPAR=CALC">Datu-baseen barrutiak definitzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/database_filter.html?DbPAR=CALC">Gelaxka-barrutiak iragaztea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/database_sort.html?DbPAR=CALC">Datuak ordenatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Taula dinamikoa</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/datapilot.html?DbPAR=CALC">Taula dinamikoa</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Taula dinamikoak sortzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Taula dinamikoak ezabatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Taula dinamikoak editatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Taula dinamikoak iragaztea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Taula dinamikoaren emaitza-barrutiak hautatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Taulak dinamikoak eguneratzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Diagrama dinamikoa</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/pivotchart.html?DbPAR=CALC">Diagrama dinamikoa</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Diagrama dinamikoak sortzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Diagrama dinamikoak editatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Diagrama dinamikoak iragaztea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Diagrama dinamikoen eguneratzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Diagrama dinamikoak ezabatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Agertokiak</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/scenario.html?DbPAR=CALC">Agertokiak erabiltzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotalak</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Subtotalen tresna erabiltzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Erreferentziak</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Helbideak eta Erreferentziak, Absolutuak eta Erlatiboak</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/cellreferences.html?DbPAR=CALC">Beste dokumentu bateko gelaxka baten erreferentzia</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Beste orri batzuen erreferentziak eta URLak erreferentziatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Gelaxkak Arrastatu eta Jareginez erreferentziatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/address_auto.html?DbPAR=CALC">Izenak erreferentziatzat hartzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Ikustea, hautatzea, kopiatzea</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/table_view.html?DbPAR=CALC">Taula-ikuspegiak aldatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/formula_value.html?DbPAR=CALC">Formulak edo balioak bistaratzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/line_fix.html?DbPAR=CALC">Errenkadak edo zutabeak goiburuko gisa finkatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/multi_tables.html?DbPAR=CALC">Orri-fitxetan nabigatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Orri anitzetara kopiatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/cellcopy.html?DbPAR=CALC">Gelaxka ikusgaiak bakarrik kopiatu</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/mark_cells.html?DbPAR=CALC">Hainbat gelaxka hautatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formulak eta kalkuluak</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/formulas.html?DbPAR=CALC">Formulekin kalkuluak egitea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/formula_copy.html?DbPAR=CALC">Formulak kopiatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/formula_enter.html?DbPAR=CALC">Formulak sartzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/formula_value.html?DbPAR=CALC">Formulak edo balioak bistaratzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/calculate.html?DbPAR=CALC">Kalkulu-orrietan kalkuluak egitea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/calc_date.html?DbPAR=CALC">Data eta ordua kalkulatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/calc_series.html?DbPAR=CALC">Serieak automatikoki kalkulatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Ordu-diferentziak kalkulatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/matrixformula.html?DbPAR=CALC">Matrize-formulak sartzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/wildcards.html?DbPAR=CALC">Formuletan komodinak erabiltzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Babesa</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/cell_protect.html?DbPAR=CALC">Gelaxkak aldaketen aurka babestea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Gelaxkei babesa kentzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Calc makroak idaztea</label><ul>\
    <li><a target="_top" href="eu/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Barrutietako balioak irakurtzea eta idaztea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Calc aplikazioan ertzei formatua ematea makroen bidez</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Hainbat</label><ul>\
    <li><a target="_top" href="eu/text/scalc/guide/auto_off.html?DbPAR=CALC">Aldaketa automatikoak desaktibatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/consolidate.html?DbPAR=CALC">Datuak kontsolidatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/goalseek.html?DbPAR=CALC">Xede-bilaketa aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/01/solver.html?DbPAR=CALC">Ebazlea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/multioperation.html?DbPAR=CALC">Eragiketa anizkoitzak aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/multitables.html?DbPAR=CALC">Orri anitzi aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/scalc/guide/validity.html?DbPAR=CALC">Gelaxka-edukien baliozkotasuna</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Aurkezpenak (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Informazio orokorra eta erabiltzaile-interfazearen erabilera</label><ul>\
    <li><a target="_top" href="eu/text/simpress/main0000.html?DbPAR=IMPRESS">Ongi etorri LibreOffice Impressen laguntzara</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0503.html?DbPAR=IMPRESS">LibreOffice Impresseko eginbideak</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Laster-teklak erabiltzea LibreOffice Impressen</a></li>\
    <li><a target="_top" href="eu/text/simpress/04/01020000.html?DbPAR=IMPRESS">LibreOffice Impresseko laster-teklak</a></li>\
    <li><a target="_top" href="eu/text/simpress/04/presenter.html?DbPAR=IMPRESS">Aurkezle-kontsolako teklatu-lasterbideak</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/main.html?DbPAR=IMPRESS">LibreOffice Impress erabiltzeko argibideak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Komandoen eta menuen erreferentzia</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menuak</label><ul>\
    <li><a target="_top" href="eu/text/simpress/main0100.html?DbPAR=IMPRESS">Menuak</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0101.html?DbPAR=IMPRESS">Fitxategia</a></li>\
    <li><a target="_top" href="eu/text/simpress/main_edit.html?DbPAR=IMPRESS">Editatu</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0103.html?DbPAR=IMPRESS">Ikusi</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0104.html?DbPAR=IMPRESS">Txertatu</a></li>\
    <li><a target="_top" href="eu/text/simpress/main_format.html?DbPAR=IMPRESS">Formatua</a></li>\
    <li><a target="_top" href="eu/text/simpress/main_slide.html?DbPAR=IMPRESS">Diapositiba</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0114.html?DbPAR=IMPRESS">Diapositiba-aurkezpena</a></li>\
    <li><a target="_top" href="eu/text/simpress/main_tools.html?DbPAR=IMPRESS">Tresnak</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0107.html?DbPAR=IMPRESS">Leihoa</a></li>\
    <li><a target="_top" href="eu/text/shared/main0108.html?DbPAR=IMPRESS">Laguntza</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Tresna-barrak</label><ul>\
    <li><a target="_top" href="eu/text/simpress/main0200.html?DbPAR=IMPRESS">Tresna-barrak</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0210.html?DbPAR=IMPRESS">Marrazkia barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0227.html?DbPAR=IMPRESS">Editatu Puntuak barra</a></li>\
    <li><a target="_top" href="eu/text/shared/find_toolbar.html?DbPAR=IMPRESS">&#39;Bilatu&#39; barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0226.html?DbPAR=IMPRESS">Inprimaki-diseinuaren tresna-barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0213.html?DbPAR=IMPRESS">Inprimaki-nabigazioaren barra</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0214.html?DbPAR=IMPRESS">Irudia barra</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0202.html?DbPAR=IMPRESS">Marra eta betetzea barra</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0213.html?DbPAR=IMPRESS">Aukerak barra</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0211.html?DbPAR=IMPRESS">Eskema-barra</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0209.html?DbPAR=IMPRESS">Erregelak</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0212.html?DbPAR=IMPRESS">Diapositiba-sailkatzailea barra</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0204.html?DbPAR=IMPRESS">Diapositiba-ikuspegia barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0201.html?DbPAR=IMPRESS">Estandarra barra</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0206.html?DbPAR=IMPRESS">Egoera barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0204.html?DbPAR=IMPRESS">Taula barra</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0203.html?DbPAR=IMPRESS">&#39;Testu-formatua&#39; barra</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Kargatzea, gordetzea, inportatzea, esportatzea eta estaltzea</label><ul>\
    <li><a target="_top" href="eu/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Aurkezpena HTML formatuan gordetzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/html_import.html?DbPAR=IMPRESS">HTML orrialdeak aurkezpenetara inportatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Koloreen, gradienteen eta itzaleztaduren paletak kargatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Animazioak GIF formatuan esportatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Kalkulu-orriak diapositibetan sartzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Grafikoak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Txertatu diapositiba fitxategitik</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/redaction.html?DbPAR=IMPRESS">Estaltzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Estaltze automatikoa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formatua</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Koloreen, gradienteen eta itzaleztaduren paletak kargatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Marra- eta gezi-estiloak kargatzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Kolore pertsonalizatuak definitzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Gradiente-betegarriak sortzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Koloreak ordeztea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Objektuak antolatzea, lerrokatzea eta banatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/background.html?DbPAR=IMPRESS">Diapositibaren atzeko planoko betegarria aldatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/footer.html?DbPAR=IMPRESS">Diapositiba guztiei goiburukoa edo orri-oina gehitzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Orrialde maisua aldatzea eta gehitzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Objektuak lekuz aldatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Inprimatzea</label><ul>\
    <li><a target="_top" href="eu/text/simpress/guide/printing.html?DbPAR=IMPRESS">Aurkezpenak inprimatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Diapositiba inprimatzea orrialde-tamainari doitzeko</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Efektuak</label><ul>\
    <li><a target="_top" href="eu/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Animazioak GIF formatuan esportatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Objektuak animatzea aurkezpen-diapositibetan</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Diapositiba-trantsizioa animatzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Bi objekturen arteko iraungitze kateatua</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">GIF irudi animatuak sortzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objektuak, grafikoak eta bit-mapak</label><ul>\
    <li><a target="_top" href="eu/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Objektuak konbinatzea eta formak sortzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Objektuak elkartzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Sektoreak eta segmentuak marraztea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Objektuak bikoiztea</a></li>\
    <li><a target="_top" href="eu/text/simpress/02/10030000.html?DbPAR=IMPRESS">Eraldaketak</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Objektuak biratzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">3D objektuak biltzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Marrak konektatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Testu-karaktereak marrazki-objektu bihurtzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Bit-maparen irudiak bektore-grafikoak bihurtzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">2D objektuak kurba, poligono eta 3D objektu bihurtzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Marra- eta gezi-estiloak kargatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Kurbak marraztea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Kurbak editatzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Grafikoak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Kalkulu-orriak diapositibetan sartzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Objektuak lekuz aldatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Azpiko objektuak hautatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Fluxu-diagrama sortzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Testua aurkezpenetan</label><ul>\
    <li><a target="_top" href="eu/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Testua gehitzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Testu-karaktereak marrazki-objektu bihurtzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Ikustea</label><ul>\
    <li><a target="_top" href="eu/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Diapositiben ordena aldatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Teklatuaren bidez handiagotzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Diapositiba-aurkezpenak</label><ul>\
    <li><a target="_top" href="eu/text/simpress/guide/show.html?DbPAR=IMPRESS">Diapositiba-aurkezpena erakustea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Aurkezle-kontsola erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote gida</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/individual.html?DbPAR=IMPRESS">Diapositiba-aurkezpen pertsonalizatua sortzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Diapositiba aldaketen aurkezpen kronometratua</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Marrazkiak (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Informazio orokorra eta erabiltzaile-interfazearen erabilera</label><ul>\
    <li><a target="_top" href="eu/text/sdraw/main0000.html?DbPAR=DRAW">Ongi etorri LibreOffice Drawen laguntzara</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main0503.html?DbPAR=DRAW">LibreOffice Drawen eginbideak</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Marrazki-objektuetarako laster-teklak</a></li>\
    <li><a target="_top" href="eu/text/sdraw/04/01020000.html?DbPAR=DRAW">Marrazkietarako laster-teklak</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/main.html?DbPAR=DRAW">LibreOffice Draw erabiltzeko argibideak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Komandoen eta menuen erreferentzia</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menuak</label><ul>\
    <li><a target="_top" href="eu/text/sdraw/main0100.html?DbPAR=DRAW">Menuak</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main0101.html?DbPAR=DRAW">Fitxategia</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main_edit.html?DbPAR=DRAW">Editatu</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main0103.html?DbPAR=DRAW">Ikusi (Draw aplikazioko menua)</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main_insert.html?DbPAR=DRAW">Txertatu</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main_format.html?DbPAR=DRAW">Formatua</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main_page.html?DbPAR=DRAW">Orrialdea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main_shape.html?DbPAR=DRAW">Forma</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main_tools.html?DbPAR=DRAW">Tresnak</a></li>\
    <li><a target="_top" href="eu/text/simpress/main0107.html?DbPAR=DRAW">Leihoa</a></li>\
    <li><a target="_top" href="eu/text/shared/main0108.html?DbPAR=DRAW">Laguntza</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Tresna-barrak</label><ul>\
    <li><a target="_top" href="eu/text/sdraw/main0200.html?DbPAR=DRAW">Tresna-barrak</a></li>\
    <li><a target="_top" href="eu/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D ezarpenak</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main0210.html?DbPAR=DRAW">Marrazkia barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0227.html?DbPAR=DRAW">Editatu Puntuak barra</a></li>\
    <li><a target="_top" href="eu/text/shared/find_toolbar.html?DbPAR=DRAW">&#39;Bilatu&#39; barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0226.html?DbPAR=DRAW">Inprimaki-diseinuaren tresna-barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0213.html?DbPAR=DRAW">Inprimaki-nabigazioaren barra</a></li>\
    <li><a target="_top" href="eu/text/sdraw/main0213.html?DbPAR=DRAW">Aukerak barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0201.html?DbPAR=DRAW">Estandarra barra</a></li>\
    <li><a target="_top" href="eu/text/shared/main0204.html?DbPAR=DRAW">Taula barra</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Kargatzea, gordetzea, inportatzea eta esportatzea</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/palette_files.html?DbPAR=DRAW">Koloreen, gradienteen eta itzaleztaduren paletak kargatzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Grafikoak txertatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatua</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/palette_files.html?DbPAR=DRAW">Koloreen, gradienteen eta itzaleztaduren paletak kargatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Marra- eta gezi-estiloak kargatzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/color_define.html?DbPAR=DRAW">Kolore pertsonalizatuak definitzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/gradient.html?DbPAR=DRAW">Gradiente-betegarriak sortzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Koloreak ordeztea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Objektuak antolatzea, lerrokatzea eta banatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/background.html?DbPAR=DRAW">Diapositibaren atzeko planoko betegarria aldatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/masterpage.html?DbPAR=DRAW">Orrialde maisua aldatzea eta gehitzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/move_object.html?DbPAR=DRAW">Objektuak lekuz aldatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Inprimatzea</label><ul>\
    <li><a target="_top" href="eu/text/simpress/guide/printing.html?DbPAR=DRAW">Aurkezpenak inprimatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Diapositiba inprimatzea orrialde-tamainari doitzeko</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Efektuak</label><ul>\
    <li><a target="_top" href="eu/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Bi objekturen arteko iraungitze kateatua</a></li>\
    <li><a target="_top" href="eu/text/shared/01/05350000.html?DbPAR=DRAW">3D Efektuak</a></li>\
    <li><a target="_top" href="eu/text/simpress/02/10030000.html?DbPAR=DRAW">Eraldaketak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objektuak, grafikoak eta bit-mapak</label><ul>\
    <li><a target="_top" href="eu/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Objektuak konbinatzea eta formak sortzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Sektoreak eta segmentuak marraztea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Objektuak bikoiztea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Objektuak biratzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">3D objektuak biltzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Marrak konektatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/text2curve.html?DbPAR=DRAW">Testu-karaktereak marrazki-objektu bihurtzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/vectorize.html?DbPAR=DRAW">Bit-maparen irudiak bektore-grafikoak bihurtzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/3d_create.html?DbPAR=DRAW">2D objektuak kurba, poligono eta 3D objektu bihurtzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Marra- eta gezi-estiloak kargatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/line_draw.html?DbPAR=DRAW">Kurbak marraztea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/line_edit.html?DbPAR=DRAW">Kurbak editatzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Grafikoak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/table_insert.html?DbPAR=DRAW">Kalkulu-orriak diapositibetan sartzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/move_object.html?DbPAR=DRAW">Objektuak lekuz aldatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/select_object.html?DbPAR=DRAW">Azpiko objektuak hautatzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/orgchart.html?DbPAR=DRAW">Fluxu-diagrama sortzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Taldeak eta geruzak</label><ul>\
    <li><a target="_top" href="eu/text/sdraw/guide/groups.html?DbPAR=DRAW">Objektuak elkartzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/layers.html?DbPAR=DRAW">Geruzei buruz</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Geruzak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Geruzekin lan egitea</a></li>\
    <li><a target="_top" href="eu/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Objektuak beste geruza batera eramatea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Testua marrazkietan</label><ul>\
    <li><a target="_top" href="eu/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Testua gehitzea</a></li>\
    <li><a target="_top" href="eu/text/simpress/guide/text2curve.html?DbPAR=DRAW">Testu-karaktereak marrazki-objektu bihurtzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Ikustea</label><ul>\
    <li><a target="_top" href="eu/text/simpress/guide/change_scale.html?DbPAR=DRAW">Teklatuaren bidez handiagotzea</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Datu-baseen funtzionaltasuna (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Informazio orokorra</label><ul>\
    <li><a target="_top" href="eu/text/sdatabase/main.html?DbPAR=BASE">LibreOffice datu-basea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/database_main.html?DbPAR=BASE">Datu-baseen ikuspegi orokorra</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_new.html?DbPAR=BASE">Datu-base berria sortzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_tables.html?DbPAR=BASE">Taulekin lan egitea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_queries.html?DbPAR=BASE">Kontsultekin lan egitea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_forms.html?DbPAR=BASE">Inprimakiekin lan egitea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_reports.html?DbPAR=BASE">Txostenak sortzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_register.html?DbPAR=BASE">Datu-baseak erregistratzea eta ezabatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_im_export.html?DbPAR=BASE">Base aplikazioko datuak inportatzea eta esportatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_enter_sql.html?DbPAR=BASE">SQL komandoak exekutatzea</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formulak (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Informazio orokorra eta erabiltzaile-interfazearen erabilera</label><ul>\
    <li><a target="_top" href="eu/text/smath/main0000.html?DbPAR=MATH">Ongi etorri LibreOffice Math aplikazioaren laguntzara</a></li>\
    <li><a target="_top" href="eu/text/smath/main0503.html?DbPAR=MATH">LibreOffice Math aplikazioko eginbideak</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formula elementuak</label><ul>\
    <li><a target="_top" href="eu/text/smath/01/03090100.html?DbPAR=MATH">Eragile unarioak/bitarrak</a></li>\
    <li><a target="_top" href="eu/text/smath/01/03090200.html?DbPAR=MATH">Erlazioak</a></li>\
    <li><a target="_top" href="eu/text/smath/01/03090800.html?DbPAR=MATH">Multzo-eragiketak</a></li>\
    <li><a target="_top" href="eu/text/smath/01/03090400.html?DbPAR=MATH">Funtzioak</a></li>\
    <li><a target="_top" href="eu/text/smath/01/03090300.html?DbPAR=MATH">Eragileak</a></li>\
    <li><a target="_top" href="eu/text/smath/01/03090600.html?DbPAR=MATH">Atributuak</a></li>\
    <li><a target="_top" href="eu/text/smath/01/03090500.html?DbPAR=MATH">Parentesiak</a></li>\
    <li><a target="_top" href="eu/text/smath/01/03090700.html?DbPAR=MATH">Formatua</a></li>\
    <li><a target="_top" href="eu/text/smath/01/03091600.html?DbPAR=MATH">Beste ikur batzuk</a></li>\
      </ul></li>\
    <li><a target="_top" href="eu/text/smath/guide/main.html?DbPAR=MATH">LibreOffice Math erabiltzeko argibideak</a></li>\
    <li><a target="_top" href="eu/text/smath/guide/keyboard.html?DbPAR=MATH">Laster-teklak (LibreOffice Math erabilerraztasuna)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Komandoen eta menuen erreferentzia</label><ul>\
    <li><a target="_top" href="eu/text/smath/main0100.html?DbPAR=MATH">Menuak</a></li>\
    <li><a target="_top" href="eu/text/smath/main0200.html?DbPAR=MATH">Tresna-barrak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Formulekin lan egitea</label><ul>\
    <li><a target="_top" href="eu/text/smath/guide/align.html?DbPAR=MATH">Formularen zati batzuk eskuz lerrokatzea</a></li>\
    <li><a target="_top" href="eu/text/smath/guide/color.html?DbPAR=MATH">Kolorea aplikatzea formula-zatiei</a></li>\
    <li><a target="_top" href="eu/text/smath/guide/attributes.html?DbPAR=MATH">Atributu lehenetsiak aldatzea</a></li>\
    <li><a target="_top" href="eu/text/smath/guide/brackets.html?DbPAR=MATH">Formulen zatiak parentesietan batzea</a></li>\
    <li><a target="_top" href="eu/text/smath/guide/comment.html?DbPAR=MATH">Iruzkinak sartzea</a></li>\
    <li><a target="_top" href="eu/text/smath/guide/newline.html?DbPAR=MATH">Lerro-jauziak sartzea</a></li>\
    <li><a target="_top" href="eu/text/smath/guide/parentheses.html?DbPAR=MATH">Parentesiak txertatzea</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Diagramak</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Informazio orokorra</label><ul>\
    <li><a target="_top" href="eu/text/schart/main0000.html?DbPAR=CHART">LibreOffice aplikazioko diagramak</a></li>\
    <li><a target="_top" href="eu/text/schart/main0503.html?DbPAR=CHART">LibreOffice Chart aplikazioaren ezaugarriak</a></li>\
    <li><a target="_top" href="eu/text/schart/04/01020000.html?DbPAR=CHART">Diagramen laster-teklak</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makroak eta scriptak</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Informazio orokorra eta erabiltzaile-interfazearen erabilera</label><ul>\
    <li><a target="_top" href="eu/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice Basic-en laguntza</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01000000.html?DbPAR=BASIC">LibreOffice Basic-ekin programatzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basic glosarioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01010210.html?DbPAR=BASIC">Oinarrizkoak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01020000.html?DbPAR=BASIC">Sintaxia</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDEa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01030100.html?DbPAR=BASIC">IDEaren ikuspegi orokorra</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01030200.html?DbPAR=BASIC">Basic editorea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01050100.html?DbPAR=BASIC">Ikuskapenaren leihoa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/main0211.html?DbPAR=BASIC">Makroen tresna-barra</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makroa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">VBA makroetarako euskarria</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Komandoen erreferentzia</label><ul>\
    <li><a target="_top" href="eu/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Konpilatzaile-aukerak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01020300.html?DbPAR=BASIC">Prozedurak, funtzioak edo propietateak erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01020500.html?DbPAR=BASIC">Liburutegiak, moduluak eta elkarrizketa-koadroak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/conventions.html?DbPAR=BASIC">Sintaxi-diagramak</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funtzioak, instrukzioak eta eragileak</label><ul>\
    <li><a target="_top" href="eu/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic konstanteak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100000.html?DbPAR=BASIC">Aldagaiak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03060000.html?DbPAR=BASIC">Eragile logikoak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03110100.html?DbPAR=BASIC">Konparazio-eragileak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120000.html?DbPAR=BASIC">Kateak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030000.html?DbPAR=BASIC">Data eta orduaren funtzioak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03070000.html?DbPAR=BASIC">Eragile matematikoak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080000.html?DbPAR=BASIC">Zenbakizko funtzioak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080100.html?DbPAR=BASIC">Funtzio trigonometrikoak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010000.html?DbPAR=BASIC">Pantailako S/I funtzioak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020000.html?DbPAR=BASIC">Fitxategien S/I funtzioak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090000.html?DbPAR=BASIC">Programen exekuzioa kontrolatzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03050000.html?DbPAR=BASIC">Erroreak maneiatzeko funtzioak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03130000.html?DbPAR=BASIC">Beste komando batzuk</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080300.html?DbPAR=BASIC">Ausazko zenbakiak sortzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO objektuak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Calc funtzioak makroetan erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">VBA funtzio esklusiboak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090400.html?DbPAR=BASIC">Beste instrukzio batzuk</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Funtzioen, instrukzioen eta eragileen zerrenda alfabetikoa</label><ul>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection objektua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090404.html?DbPAR=BASIC">End instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA objektua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03050000.html?DbPAR=BASIC">Erroreak maneiatzeko funtzioak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid funtzioa, Mid instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080000.html?DbPAR=BASIC">Zenbakizko funtzioak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub instrukzioa; On...GoTo instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (Function instrukzioan)</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/property.html?DbPAR=BASIC">Property instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space eta Spc funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space eta Spc funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080400.html?DbPAR=BASIC">Erro karratuak kalkulatzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop objektua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120202.html?DbPAR=BASIC">String funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent objektua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument objektua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName funtzioa; VarType funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName funtzioa [VBA]</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03090411.html?DbPAR=BASIC">With instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write instrukzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year funtzioa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" eragilea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03120300.html?DbPAR=BASIC">Kateen edukia editatzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01020100.html?DbPAR=BASIC">Aldagaiak erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/conventions.html?DbPAR=BASIC">Sintaxi-diagramak</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Basic liburutegi aurreratuak</label><ul>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools liburutegia</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT liburutegia</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO liburutegia</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD liburutegia</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS liburutegia</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">ImportWizard liburutegia</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE liburutegia</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY liburutegia</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE liburutegia</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor liburutegia</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">ScriptForge liburutegia</label><ul>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge liburutegiak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Python scriptak sortzea ScriptForge bidez</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge metodoen sinadurak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array zerbitzua (SF_Array)</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception zerbitzua (SF_Exception)</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String zerbitzua (SF_String)</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest zerbitzua</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer zerbitzua</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Gidak</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/macro_recording.html?DbPAR=BASIC">Makroak grabatzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Elkarrizketa-koadroen editoreko kontrolen propietateak aldatzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Elkarrizketa-koadroen editorean kontrolak sortzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Elkarrizketa-koadroen editoreko kontrolak programatzeko adibideak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Elkarrizketa-koadro bat irekitzea Basic bidez</a></li>\
    <li><a target="_top" href="eu/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Basic elkarrizketa-koadroa sortzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01030400.html?DbPAR=BASIC">Liburutegiak eta moduluak antolatzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01020100.html?DbPAR=BASIC">Aldagaiak erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01020200.html?DbPAR=BASIC">Objektuak erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01030300.html?DbPAR=BASIC">Basic programak araztea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/shared/01040000.html?DbPAR=BASIC">Dokumentuetako gertaerek gidatutako makroak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic programazio-adibideak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic lengoaiatik Pythonera</a></li>\
    <li><a target="_top" href="eu/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python scripten laguntza</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Informazio orokorra eta erabiltzaile-interfazearen erabilera</label><ul>\
    <li><a target="_top" href="eu/text/sbasic/python/main0000.html?DbPAR=BASIC">Python scriptak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/python/python_ide.html?DbPAR=BASIC">Pythonerako IDEa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python scripten antolaketa</a></li>\
    <li><a target="_top" href="eu/text/sbasic/python/python_shell.html?DbPAR=BASIC">Pythonen kontsola interaktiboa</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Pythonekin programatzea</label><ul>\
    <li><a target="_top" href="eu/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Pythonekin programatzea</a></li>\
    <li><a target="_top" href="eu/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python adibideak</a></li>\
    <li><a target="_top" href="eu/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Pythonetik Basic lengoaiara</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Scriptak garatzeko tresnak</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/dev_tools.html?DbPAR=BASIC">Garapen-tresnak</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice aplikazioaren instalazioa</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office dokumentu moten elkartzea aldatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Modu segurua</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Laguntza-gai arruntak</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Informazio orokorra</label><ul>\
    <li><a target="_top" href="eu/text/shared/main0400.html?DbPAR=SHARED">Laster-teklak</a></li>\
    <li><a target="_top" href="eu/text/shared/00/00000005.html?DbPAR=SHARED">Glosario orokorra</a></li>\
    <li><a target="_top" href="eu/text/shared/00/00000002.html?DbPAR=SHARED">Interneteko terminoen glosarioa</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/accessibility.html?DbPAR=SHARED">LibreOffice aplikazioko erabilerraztasuna</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/keyboard.html?DbPAR=SHARED">Lasterbideak (LibreOffice erabilerraztasuna)</a></li>\
    <li><a target="_top" href="eu/text/shared/04/01010000.html?DbPAR=SHARED">LibreOfficeko laster-tekla nagusiak</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/version_number.html?DbPAR=SHARED">Bertsioak eta bertsio-zenbakiak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice eta Microsoft Office</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/ms_user.html?DbPAR=SHARED">Microsoft Office eta LibreOffice erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Microsoft Office eta LibreOffice aplikazioetako terminoak konparatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Microsoft Office dokumentuak bihurtzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office dokumentu moten elkartzea aldatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice aukerak</label><ul>\
    <li><a target="_top" href="eu/text/shared/optionen/01000000.html?DbPAR=SHARED">Aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01010100.html?DbPAR=SHARED">Erabiltzaile-datuak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01010200.html?DbPAR=SHARED">Orokorra</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01010800.html?DbPAR=SHARED">Ikusi</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01010900.html?DbPAR=SHARED">Inprimatzeko aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01010300.html?DbPAR=SHARED">Bide-izenak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01010700.html?DbPAR=SHARED">Letra-tipoak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01030300.html?DbPAR=SHARED">Segurtasuna</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01012000.html?DbPAR=SHARED">Aplikazioaren koloreak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01013000.html?DbPAR=SHARED">Erabilerraztasuna</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/java.html?DbPAR=SHARED">Aurreratua</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Konfigurazio aurreratua</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDEa</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01010400.html?DbPAR=SHARED">Idazteko laguntza</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01010600.html?DbPAR=SHARED">Orokorra</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01020000.html?DbPAR=SHARED">Kargatzeko/gordetzeko aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01030000.html?DbPAR=SHARED">Internet-aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01040000.html?DbPAR=SHARED">Testu-dokumentuaren aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01050000.html?DbPAR=SHARED">HTML dokumentuen aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01060000.html?DbPAR=SHARED">Kalkulu-orriaren aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01070000.html?DbPAR=SHARED">Aurkezpen-aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01080000.html?DbPAR=SHARED">Marrazki-aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01090000.html?DbPAR=SHARED">Formula</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01110000.html?DbPAR=SHARED">Diagrama-aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA propietateak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01140000.html?DbPAR=SHARED">Hizkuntzak (aukerak)</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01150000.html?DbPAR=SHARED">Hizkuntza-ezarpenen aukerak</a></li>\
    <li><a target="_top" href="eu/text/shared/optionen/01160000.html?DbPAR=SHARED">Datu-iturburuen aukerak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Morroiak</label><ul>\
    <li><a target="_top" href="eu/text/shared/autopi/01000000.html?DbPAR=SHARED">Morroia</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Gutunen morroia</label><ul>\
    <li><a target="_top" href="eu/text/shared/autopi/01010000.html?DbPAR=SHARED">Gutunen morroia</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Fax morroia</label><ul>\
    <li><a target="_top" href="eu/text/shared/autopi/01020000.html?DbPAR=SHARED">Fax morroia</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Agendaren morroia</label><ul>\
    <li><a target="_top" href="eu/text/shared/autopi/01040000.html?DbPAR=SHARED">Agendaren morroia</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML esportazioko morroia</label><ul>\
    <li><a target="_top" href="eu/text/shared/autopi/01110000.html?DbPAR=SHARED">HTML esportazioa</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Dokumentuak bihurtzeko morroia</label><ul>\
    <li><a target="_top" href="eu/text/shared/autopi/01130000.html?DbPAR=SHARED">Dokumentu-bihurtzailea</a></li>\
      </ul></li>\
    <li><a target="_top" href="eu/text/shared/autopi/01150000.html?DbPAR=SHARED">Euro-bihurtzailearen morroia</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">LibreOffice konfiguratzea</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/configure_overview.html?DbPAR=SHARED">LibreOffice konfiguratzea</a></li>\
    <li><a target="_top" href="eu/text/shared/01/packagemanager.html?DbPAR=SHARED">Hedapenen kudeatzailea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/flat_icons.html?DbPAR=SHARED">Ikonoen ikuspegiak aldatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Tresna-barrei botoiak gehitzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/workfolder.html?DbPAR=SHARED">Laneko direktorioa aldatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/standard_template.html?DbPAR=SHARED">Txantiloi lehenetsiak eta pertsonalizatuak sortzea eta aldatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Helbide-liburuak erregistratzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/formfields.html?DbPAR=SHARED">Botoiak txertatzea eta editatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Erabiltzaile-interfazearekin lan egitea</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Objektuetara azkar heltzeko nabigazioa</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/navigator.html?DbPAR=SHARED">Dokumentuen ikuspegi orokorrerako nabigatzailea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/autohide.html?DbPAR=SHARED">Leihoak erakustea, atrakatzea eta ezkutatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/textmode_change.html?DbPAR=SHARED">Txertatu eta gainidatzi moduen artean txandakatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Tresna-barrak erabiltzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Sinadura digitalak</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Sinadura digitalei buruz</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Sinadura digitalak aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF esportazioaren sinadura digitala</a></li>\
    <li><a target="_top" href="eu/text/shared/01/timestampauth.html?DbPAR=SHARED">Denbora Zigilatzeko Agintzaritzak sinadura digitaletarako</a></li>\
    <li><a target="_top" href="eu/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Sinatu lehendik dagoen PDFa</a></li>\
    <li><a target="_top" href="eu/text/shared/01/addsignatureline.html?DbPAR=SHARED">Sinadura-marra gehitzea dokumentuei</a></li>\
    <li><a target="_top" href="eu/text/shared/01/signsignatureline.html?DbPAR=SHARED">Sinadura-marra sinatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Inprimatzea, faxak bidaltzea</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/labels_database.html?DbPAR=SHARED">Helbide-etiketak inprimatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Zuri-beltzean inprimatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/email.html?DbPAR=SHARED">Dokumentuak posta elektroniko gisa bidaltzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/fax.html?DbPAR=SHARED">Faxak bidaltzea eta LibreOffice faxak bidaltzeko konfiguratzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Arrastatu & jaregin</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/dragdrop.html?DbPAR=SHARED">LibreOffice dokumentuetan arrastatu eta jaregitea</a></li>\
    <li><a target="_top" href="eu/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Dokumentuetan testua lekuz aldatzea eta kopiatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kalkulu-orrietako areak testu-dokumentuetan kopiatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Grafikoak dokumentu artean kopiatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Grafikoak galeriatik kopiatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Arrastatu eta jaregitea datu-iturburuaren ikuspegiarekin</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Kopiatu eta itsatsi</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Marrazki-objektuak beste dokumentu batzuetan kopiatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Grafikoak dokumentu artean kopiatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Grafikoak galeriatik kopiatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kalkulu-orrietako areak testu-dokumentuetan kopiatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Diagramak</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/chart_insert.html?DbPAR=SHARED">Diagramak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/schart/main0000.html?DbPAR=SHARED">LibreOffice aplikazioko diagramak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Kargatu, gorde, inportatu, esportatu, PDFa</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/doc_open.html?DbPAR=SHARED">Dokumentuak irekitzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/import_ms.html?DbPAR=SHARED">Beste formatu batzuetan gordetako dokumentuak irekitzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/doc_save.html?DbPAR=SHARED">Dokumentuak gordetzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Dokumentuak automatikoki gordetzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/export_ms.html?DbPAR=SHARED">Dokumentuak beste formatu batean gordetzea</a></li>\
    <li><a target="_top" href="eu/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Esportatu PDF gisa</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Datuak testu-formatuan inportatzea eta esportatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Estekak eta erreferentziak</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Hiperestekak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Esteka erlatiboak eta absolutuak</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Hiperestekak editatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Dokumentu-bertsioen segimendua</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Dokumentu baten bertsioak konparatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Bertsioak batzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Aldaketak grabatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/redlining.html?DbPAR=SHARED">Aldaketak grabatzea eta bistaratzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Aldaketak onartzea edo baztertzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Bertsio-kudeaketa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etiketak eta bisita-txartelak</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/labels.html?DbPAR=SHARED">Etiketak eta bisita-txartelak sortzea eta inprimatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Kanpoko datuak txertatzea</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/copytable2application.html?DbPAR=SHARED">Kalkulu-orrietako datuak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/copytext2application.html?DbPAR=SHARED">Testu-dokumentuetako datuak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Bit-mapak txertatzea, editatzea, gordetzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Grafikoak galeriari gehitzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Funtzio automatikoak</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/autocorr_url.html?DbPAR=SHARED">URL automatikoki ezagutzeko eginbidea desaktibatzea</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Bilatzea eta ordeztea</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/data_search2.html?DbPAR=SHARED">Inprimaki-iragazkiarekin bilaketak egitea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_search.html?DbPAR=SHARED">Tauletan eta inprimaki-dokumentuetan bilaketak egitea</a></li>\
    <li><a target="_top" href="eu/text/shared/01/02100001.html?DbPAR=SHARED">Adierazpen erregularren zerrenda</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Gidak</label><ul>\
    <li><a target="_top" href="eu/text/shared/guide/linestyles.html?DbPAR=SHARED">Marra-estiloak aplikatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/text_color.html?DbPAR=SHARED">Testuaren kolorea aldatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/change_title.html?DbPAR=SHARED">Dokumentuen titulua aldatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/round_corner.html?DbPAR=SHARED">Izkina biribilak sortzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/background.html?DbPAR=SHARED">Atzeko planoko koloreak edo atzeko planoko grafikoak zehaztea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/palette_files.html?DbPAR=SHARED">Koloreen, gradienteen eta itzaleztaduren paletak kargatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/lineend_define.html?DbPAR=SHARED">Gezi-estiloak definitzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Marra-estiloak definitzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Objektu grafikoak editatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/line_intext.html?DbPAR=SHARED">Testuan marrak marraztea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/aaa_start.html?DbPAR=SHARED">Lehen urratsak</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Galeriako objektuak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Zuriune zatiezinak, hitz-zatiketak eta marratxo bigunak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Karaktere bereziak txertatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/tabs.html?DbPAR=SHARED">Tabulazioak txertatzea eta editatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Urruneko fitxategiak erabiltzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/protection.html?DbPAR=SHARED">LibreOffice aplikazioan edukia babestea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Grabazioak babestea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Orrialdeko area inprimagarri maximoa hautatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/measurement_units.html?DbPAR=SHARED">Neurri-unitateak hautatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/language_select.html?DbPAR=SHARED">Dokumentuen hizkuntza hautatzea</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Taula-diseinua</a></li>\
    <li><a target="_top" href="eu/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Buletak eta zenbakitzea desaktibatzea paragrafo jakinetan</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
