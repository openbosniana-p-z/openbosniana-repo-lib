document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Tekstdokumenter (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Almindelig information og brug af brugergrænseflade</label><ul>\
    <li><a target="_top" href="da/text/swriter/main0000.html?DbPAR=WRITER">Velkommen til LibreOffice Writer Hjælp</a></li>\
    <li><a target="_top" href="da/text/swriter/main0503.html?DbPAR=WRITER">Funktionalitet i LibreOffice Writer</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/main.html?DbPAR=WRITER">Instruktioner i brug af LibreOffice Writer</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Fastgørelse og ændring af vinduesstørrelse</a></li>\
    <li><a target="_top" href="da/text/swriter/04/01020000.html?DbPAR=WRITER">Genvejstaster for LibreOffice Writer</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/words_count.html?DbPAR=WRITER">Tælle ord</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/keyboard.html?DbPAR=WRITER">Brug af genvejstaster (LibreOffice Writer-tilgængelighed)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Kommando- og menureference</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menuer</label><ul>\
    <li><a target="_top" href="da/text/swriter/main0100.html?DbPAR=WRITER">Menuer</a></li>\
    <li><a target="_top" href="da/text/swriter/main0101.html?DbPAR=WRITER">Filer</a></li>\
    <li><a target="_top" href="da/text/swriter/main0102.html?DbPAR=WRITER">Rediger</a></li>\
    <li><a target="_top" href="da/text/swriter/main0103.html?DbPAR=WRITER">Vis</a></li>\
    <li><a target="_top" href="da/text/swriter/main0104.html?DbPAR=WRITER">Indsæt</a></li>\
    <li><a target="_top" href="da/text/swriter/main0105.html?DbPAR=WRITER">Formater</a></li>\
    <li><a target="_top" href="da/text/swriter/main0115.html?DbPAR=WRITER">Typografier (menu)</a></li>\
    <li><a target="_top" href="da/text/swriter/main0110.html?DbPAR=WRITER">Tabel</a></li>\
    <li><a target="_top" href="da/text/swriter/main0120.html?DbPAR=WRITER">Menuen Formater</a></li>\
    <li><a target="_top" href="da/text/swriter/main0106.html?DbPAR=WRITER">Funktioner</a></li>\
    <li><a target="_top" href="da/text/swriter/main0107.html?DbPAR=WRITER">Vindue</a></li>\
    <li><a target="_top" href="da/text/shared/main0108.html?DbPAR=WRITER">Hjælp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Værktøjslinjer</label><ul>\
    <li><a target="_top" href="da/text/swriter/main0200.html?DbPAR=WRITER">Værktøjslinjer</a></li>\
    <li><a target="_top" href="da/text/swriter/main0206.html?DbPAR=WRITER">Punktopstillingslinje</a></li>\
    <li><a target="_top" href="da/text/swriter/main0205.html?DbPAR=WRITER">Tegneobjektegenskabslinje</a></li>\
    <li><a target="_top" href="da/text/shared/find_toolbar.html?DbPAR=WRITER">Søgelinje</a></li>\
    <li><a target="_top" href="da/text/shared/main0226.html?DbPAR=WRITER">Værktøjslinjen Formulardesign</a></li>\
    <li><a target="_top" href="da/text/shared/main0213.html?DbPAR=WRITER">Formularnavigationslinje</a></li>\
    <li><a target="_top" href="da/text/swriter/main0202.html?DbPAR=WRITER">Formateringslinje</a></li>\
    <li><a target="_top" href="da/text/swriter/main0214.html?DbPAR=WRITER">Formellinje</a></li>\
    <li><a target="_top" href="da/text/swriter/main0215.html?DbPAR=WRITER">Rammelinje</a></li>\
    <li><a target="_top" href="da/text/swriter/main0203.html?DbPAR=WRITER">Værktøjslinjen Billede</a></li>\
    <li><a target="_top" href="da/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo værktøjslinje</a></li>\
    <li><a target="_top" href="da/text/swriter/main0216.html?DbPAR=WRITER">OLE-objektlinje</a></li>\
    <li><a target="_top" href="da/text/swriter/main0210.html?DbPAR=WRITER">Værktøjslinjen Vis  udskrift (Writer)</a></li>\
    <li><a target="_top" href="da/text/shared/main0214.html?DbPAR=WRITER">Værktøjslinjen Forespørgselsdesign</a></li>\
    <li><a target="_top" href="da/text/swriter/main0213.html?DbPAR=WRITER">Linealer</a></li>\
    <li><a target="_top" href="da/text/shared/main0201.html?DbPAR=WRITER">Standardlinje</a></li>\
    <li><a target="_top" href="da/text/swriter/main0208.html?DbPAR=WRITER">Statuslinje (Writer)</a></li>\
    <li><a target="_top" href="da/text/swriter/main0204.html?DbPAR=WRITER">Tabellinje</a></li>\
    <li><a target="_top" href="da/text/shared/main0212.html?DbPAR=WRITER">Tabeldatalinjen</a></li>\
    <li><a target="_top" href="da/text/swriter/main0220.html?DbPAR=WRITER">Tekstobjektlinje</a></li>\
    <li><a target="_top" href="da/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Værktøjslinjen Registrer ændringer</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navigator til tekstdokumenter</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navigering og markering med tastaturet</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Flytning og kopiering af tekst i dokumenter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Omarrangering af et dokument ved brug af Navigator</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Indsætte hyperlinks med navigatoren</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/navigator.html?DbPAR=WRITER">Navigator til tekstdokumenter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Brug af direkte-markøren</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatering af tekstdokumenter</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Ændring af sideretning (liggende eller stående)</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/text_capital.html?DbPAR=WRITER">Ændre STORE/små bogstaver i en tekst</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Skjule tekst</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Angivelse af forskellige sidehoveder og -fødder</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Indsættelse af et kapitelnavn og -værdi i et sidehoved eller en sidefod</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Anvendelse af tekstformatering mens du skriver</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/reset_format.html?DbPAR=WRITER">Nulstilling af skrifttypeattributter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Anvendelse af typografier i fyldformattilstand</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/wrap.html?DbPAR=WRITER">Ombrydning af tekst omkring objekter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Brug af en ramme til at centrere tekst på en side</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Fremhævelse af tekst</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Rotering af tekst</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/page_break.html?DbPAR=WRITER">Indsættelse og sletning af sideskift</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Oprette og anvende sidetypografier</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/subscript.html?DbPAR=WRITER">Fremstilling af hævet skrift eller sænket skrift</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Skabeloner og typografier</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Skabeloner og typografier</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Skiftende sidetypografier på ulige og lige sider</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/change_header.html?DbPAR=WRITER">Oprettelse af en sidetypografi baseret på den aktuelle side</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/load_styles.html?DbPAR=WRITER">Brug af typografier fra et andet dokument eller en anden skabelon</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Oprettelse af nye typografier ud fra markeringer</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Opdatering af typografier fra markeringer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/standard_template.html?DbPAR=WRITER">Oprettelse og ændring af standard- og tilpassede skabeloner</a></li>\
    <li><a target="_top" href="da/text/shared/guide/template_manager.html?DbPAR=WRITER">Skabelon-håndtering</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Grafik i tekstdokumenter</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Indsættelse af grafik</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Indsættelse af grafik fra en fil</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Indsættelse af grafik fra Galleri med træk-og-slip</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Indsættelse af et scannet billede</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Indsætning af et Calc diagram i et tekstdokument</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Indsættelse af grafik fra LibreOffice Draw eller Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabeller i tekstdokumenter</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Aktivering eller deaktivering af talgenkendelse i tabeller</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/tablemode.html?DbPAR=WRITER">Modificering af rækker og kolonner med tastaturet</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/table_delete.html?DbPAR=WRITER">Sletning af tabeller eller indholdet af en tabel</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/table_insert.html?DbPAR=WRITER">Indsætning af tabeller</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Gentagelse af en tabeloverskrift på en ny side</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Ændring af række- og kolonnestørrelse i en teksttabel</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objekter i tekstdokumenter</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Placering af objekter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/wrap.html?DbPAR=WRITER">Ombrydning af tekst omkring objekter</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Afsnit og rammer i tekstdokumenter</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/sections.html?DbPAR=WRITER">Brug af sektioner</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/text_frame.html?DbPAR=WRITER">Indsættelse, redigering og sammenkædning af rammer</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/section_edit.html?DbPAR=WRITER">Redigering af sektioner</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/section_insert.html?DbPAR=WRITER">Indsætte sektioner</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Indholdsfortegnelse og stikordsregistre</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Kapitelnummerering</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Brugerdefinerede indekser</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Oprettelse af en indholdsfortegnelse</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/indices_index.html?DbPAR=WRITER">Oprettelse af stikordsregistre</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Indekser der dækker flere dokumenter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Oprettelse af en litteraturliste</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Redigering eller sletning af elementer i indeks og oversigter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Opdatering, redigering og sletning af stikordsregistre og indholdsfortegnelser</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Angivelse af indeks- eller indholdsfortegnelseselementer</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formatering af et indeks eller en indholdsfortegnelse</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Felter i tekstdokumenter</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/fields.html?DbPAR=WRITER">Om felter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/fields_date.html?DbPAR=WRITER">Indsættelse af et fast eller variabelt datofelt</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/field_convert.html?DbPAR=WRITER">Konvertering af et felt til tekst</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Beregning i tekstdokumenter</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Beregning på tværs af tabeller</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/calculate.html?DbPAR=WRITER">Beregning i tekstdokumenter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Beregning og indsættelse af resultatet af en formel i et tekstdokument</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Beregning af celletotaler i tabeller</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Beregning af komplekse formler i tekstdokumenter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Visning af resultatet af en tabelberegning i en anden tabel</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Specielle tekstelementer</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/captions.html?DbPAR=WRITER">Brug af billedtekster</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Betinget tekst</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Betinget tekst til sideantal</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/fields_date.html?DbPAR=WRITER">Indsættelse af et fast eller variabelt datofelt</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Tilføjelse af indtastningsfelter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Indsættelse af sidetal på efterfølgende sider</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Indsættelse af sidetal i sidefødder</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Skjule tekst</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Angivelse af forskellige sidehoveder og -fødder</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Indsættelse af et kapitelnavn og -værdi i et sidehoved eller en sidefod</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Forespørgsel på brugerdata i felter eller betingelser</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Indsættelse og redigering af fodnoter eller slutnoter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Afstand mellem fodnoter</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/header_footer.html?DbPAR=WRITER">Om sidehoveder og -fødder</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formatering af sidehoveder eller sidefødder</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/text_animation.html?DbPAR=WRITER">Animation af tekst</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Oprettelse af et formularbrev</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automatiske funktioner</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Tilføjelse af undtagelser til Autokorrekturliste</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/autotext.html?DbPAR=WRITER">Brug af Autotekst</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Oprettelse af punktopstillede lister, mens du skriver</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/auto_off.html?DbPAR=WRITER">Deaktivering af Autokorrektur</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatisk kontrol af stavning</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Aktivering eller deaktivering af talgenkendelse i tabeller</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Orddeling</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Nummerering og lister</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Tilføjelse af kapitelnumre til billedtekster</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Oprettelse af punktopstillede lister, mens du skriver</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Kapitelnummerering</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Ændring af et listeafsnits listeniveau</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Kombinering af nummererede lister</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Tilføjelse af linjenumre</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Ændring af nummerering på en sorteret liste</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Angivelse af værdiområder</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Tilføjelse af nummerering</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Nummerering og afsnitstypografier</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Tilføjelse af punkttegn</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Stavekontrol, synonymordbog og sprog</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatisk kontrol af stavning</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Fjerne ord fra en brugerdefineret ordbog</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Synonymordbog</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Kontroller stavning og grammatik</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Problemløsningstips</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Indsættelse af tekst før en tabel øverst på en side</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Gå til bestemt bogmærke</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Indlæse, gemme, importere, eksportere og sløring</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/send2html.html?DbPAR=WRITER">Gem tekstdokumenter i HTML-format</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Indsættelse af et helt tekstdokument</a></li>\
    <li><a target="_top" href="da/text/shared/guide/redaction.html?DbPAR=WRITER">Maskering</a></li>\
    <li><a target="_top" href="da/text/shared/guide/auto_redact.html?DbPAR=WRITER">Automatisk maskering</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Hoveddokumenter</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Hoveddokumenter og underdokumenter</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Links og henvisninger</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/references.html?DbPAR=WRITER">Indsætte krydshenvisninger</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Indsætte hyperlinks med navigatoren</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Udskrivning</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/print_selection.html?DbPAR=WRITER">Vælg hvad, der skal udskrives</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Valg af papirbakker i printeren</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/print_preview.html?DbPAR=WRITER">Forhåndsvisning af en side før udskrivning</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/print_small.html?DbPAR=WRITER">Udskrivning af flere sider på et ark</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Oprette og anvende sidetypografier</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">At søge og erstatte</label><ul>\
    <li><a target="_top" href="da/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Brug af regulære udtryk i tekstsøgninger</a></li>\
    <li><a target="_top" href="da/text/shared/01/02100001.html?DbPAR=WRITER">Liste over regulære udtryk</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML-dokumenter (Writer Web)</label><ul>\
    <li><a target="_top" href="da/text/shared/07/09000000.html?DbPAR=WRITER">Websider</a></li>\
    <li><a target="_top" href="da/text/shared/02/01170700.html?DbPAR=WRITER">HTML-filtre og formularer</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/send2html.html?DbPAR=WRITER">Gem tekstdokumenter i HTML-format</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Regneark (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Almindelig information og brug af brugergrænseflade</label><ul>\
    <li><a target="_top" href="da/text/scalc/main0000.html?DbPAR=CALC">Velkommen til LibreOffice Calc Hjælp</a></li>\
    <li><a target="_top" href="da/text/scalc/main0503.html?DbPAR=CALC">Funktionalitet i LibreOffice Calc</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/keyboard.html?DbPAR=CALC">Genvejstaster (LibreOffice Calc tilgængelighed)</a></li>\
    <li><a target="_top" href="da/text/scalc/04/01020000.html?DbPAR=CALC">Genvejstaster til regneark</a></li>\
    <li><a target="_top" href="da/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Beregningsnøjagtighed</a></li>\
    <li><a target="_top" href="da/text/scalc/05/02140000.html?DbPAR=CALC">Fejlkoder i LibreOffice Calc</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060112.html?DbPAR=CALC">Tilføjelsesfunktioner til programmering i LibreOffice Calc</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/main.html?DbPAR=CALC">Instruktioner i brug af LibreOffice Calc</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Kommando- og menureference</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menuer</label><ul>\
    <li><a target="_top" href="da/text/scalc/main0100.html?DbPAR=CALC">Menuer</a></li>\
    <li><a target="_top" href="da/text/scalc/main0101.html?DbPAR=CALC">Filer</a></li>\
    <li><a target="_top" href="da/text/scalc/main0102.html?DbPAR=CALC">Rediger</a></li>\
    <li><a target="_top" href="da/text/scalc/main0103.html?DbPAR=CALC">Vis</a></li>\
    <li><a target="_top" href="da/text/scalc/main0104.html?DbPAR=CALC">Indsæt</a></li>\
    <li><a target="_top" href="da/text/scalc/main0105.html?DbPAR=CALC">Formater</a></li>\
    <li><a target="_top" href="da/text/scalc/main0116.html?DbPAR=CALC">Ark</a></li>\
    <li><a target="_top" href="da/text/scalc/main0112.html?DbPAR=CALC">Data</a></li>\
    <li><a target="_top" href="da/text/scalc/main0106.html?DbPAR=CALC">Funktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/main0107.html?DbPAR=CALC">Vindue</a></li>\
    <li><a target="_top" href="da/text/shared/main0108.html?DbPAR=CALC">Hjælp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Værktøjslinjer</label><ul>\
    <li><a target="_top" href="da/text/scalc/main0200.html?DbPAR=CALC">Værktøjslinjer</a></li>\
    <li><a target="_top" href="da/text/shared/find_toolbar.html?DbPAR=CALC">Søgelinje</a></li>\
    <li><a target="_top" href="da/text/scalc/main0202.html?DbPAR=CALC">Formateringslinje</a></li>\
    <li><a target="_top" href="da/text/scalc/main0203.html?DbPAR=CALC">Tegneobjektegenskabslinje</a></li>\
    <li><a target="_top" href="da/text/scalc/main0205.html?DbPAR=CALC">Tekstformateringslinje</a></li>\
    <li><a target="_top" href="da/text/scalc/main0206.html?DbPAR=CALC">Formellinje</a></li>\
    <li><a target="_top" href="da/text/scalc/main0208.html?DbPAR=CALC">Statuslinje</a></li>\
    <li><a target="_top" href="da/text/scalc/main0210.html?DbPAR=CALC">Udskriftsvisningslinje</a></li>\
    <li><a target="_top" href="da/text/scalc/main0214.html?DbPAR=CALC">Værktøjslinjen Billeder</a></li>\
    <li><a target="_top" href="da/text/scalc/main0218.html?DbPAR=CALC">Værktøjslinjen Funktioner</a></li>\
    <li><a target="_top" href="da/text/shared/main0201.html?DbPAR=CALC">Standardlinje</a></li>\
    <li><a target="_top" href="da/text/shared/main0212.html?DbPAR=CALC">Tabeldatalinjen</a></li>\
    <li><a target="_top" href="da/text/shared/main0213.html?DbPAR=CALC">Formularnavigationslinje</a></li>\
    <li><a target="_top" href="da/text/shared/main0214.html?DbPAR=CALC">Værktøjslinjen Forespørgselsdesign</a></li>\
    <li><a target="_top" href="da/text/shared/main0226.html?DbPAR=CALC">Værktøjslinjen Formulardesign</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Funktionstyper og operatorer</label><ul>\
    <li><a target="_top" href="da/text/scalc/01/04060000.html?DbPAR=CALC">Funktionsguide</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060100.html?DbPAR=CALC">Funktioner efter kategori</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060107.html?DbPAR=CALC">Matrixfunktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060120.html?DbPAR=CALC">Bitoprationsfunktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060101.html?DbPAR=CALC">Databasefunktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060102.html?DbPAR=CALC">Dato- og klokkeslætsfunktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060103.html?DbPAR=CALC">Finansfunktioner del et</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060119.html?DbPAR=CALC">Finansfunktioner del to</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060118.html?DbPAR=CALC">Finansfunktioner del tre</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060104.html?DbPAR=CALC">Informationsfunktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060105.html?DbPAR=CALC">Logiske funktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060106.html?DbPAR=CALC">Matematiske funktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060108.html?DbPAR=CALC">Statistikfunktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060181.html?DbPAR=CALC">Statistiske funktioner del et</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060182.html?DbPAR=CALC">Statistiske funktioner del to</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060183.html?DbPAR=CALC">Statistiske funktioner del tre</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060184.html?DbPAR=CALC">Statistiske funktioner del fire</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060185.html?DbPAR=CALC">Statistiske funktioner del fem</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060109.html?DbPAR=CALC">Regnearksfunktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060110.html?DbPAR=CALC">Tekstfunktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060111.html?DbPAR=CALC">Tilføjelsesfunktioner</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060115.html?DbPAR=CALC">Tilføjelsesfunktioner, Liste over analysefunktioner, del et</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060116.html?DbPAR=CALC">Tilføjelsesfunktioner, Liste over analysefunktioner, del to</a></li>\
    <li><a target="_top" href="da/text/scalc/01/04060199.html?DbPAR=CALC">Operatorer i LibreOffice Calc</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Brugerdefinerede funktioner</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Indlæse, gemme, importere, eksportere og sløring</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/webquery.html?DbPAR=CALC">Indsæt eksterne data i tabel (webforespørgsel)</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/html_doc.html?DbPAR=CALC">Gem og åbn ark i HTML</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/csv_formula.html?DbPAR=CALC">Importere og eksportere tekstfiler</a></li>\
    <li><a target="_top" href="da/text/shared/guide/redaction.html?DbPAR=CALC">Maskering</a></li>\
    <li><a target="_top" href="da/text/shared/guide/auto_redact.html?DbPAR=CALC">Automatisk maskering</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formatering</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/text_rotate.html?DbPAR=CALC">Rotere tekst</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/text_wrap.html?DbPAR=CALC">Skrive tekst på flere linjer</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formatering af tal som tekst</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/super_subscript.html?DbPAR=CALC">Hævet skrift / sænket skrift</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/row_height.html?DbPAR=CALC">Ændr Rækkehøjde eller Kolonnebredde</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Anvendelse af betinget formatering</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Fremhævelse af negative tal</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Tildeling af formateringer med formel</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Indtastning af en værdi med foranstillede nuller</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/format_table.html?DbPAR=CALC">Formatering af regneark</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/format_value.html?DbPAR=CALC">Formatering af tal med decimaler</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/value_with_name.html?DbPAR=CALC">Navngivning af celler</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/table_rotate.html?DbPAR=CALC">Rotere tabeller (Transponere)</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/rename_table.html?DbPAR=CALC">Omdøbning af ark</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx år</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Brug af afrundede tal</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/currency_format.html?DbPAR=CALC">Celler i valutaformat</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/autoformat.html?DbPAR=CALC">Brug af Autoformat til tabeller</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/note_insert.html?DbPAR=CALC">Indsættelse og redigering af kommentarer</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/design.html?DbPAR=CALC">Valg af temaer til ark</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Indtastning af brøker</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtrering og sortering</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/filters.html?DbPAR=CALC">Anvende filtre</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/specialfilter.html?DbPAR=CALC">Anvendelse af avancerede filtre</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/autofilter.html?DbPAR=CALC">Anvende Autofilter</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/sorted_list.html?DbPAR=CALC">Anvende sorteringslister</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Fjernelse af dubletværdier</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Udskrivning</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/print_title_row.html?DbPAR=CALC">Udskrive rækker eller kolonner på alle sider</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/print_landscape.html?DbPAR=CALC">Udskrive ark i liggende format</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/print_details.html?DbPAR=CALC">Udskriv arkdetaljer</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/print_exact.html?DbPAR=CALC">Angiv antal sider til udskrivning</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Dataområder</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/database_define.html?DbPAR=CALC">Angiv databaseområder</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtrere celleområder</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/database_sort.html?DbPAR=CALC">Sortering af data</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Pivottabel</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/datapilot.html?DbPAR=CALC">Pivottabel</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Oprettelse af pivottabeller</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Sletning af pivottabeller</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Redigering af pivottabeller</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtrering af pivottabeller</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Vælg målområder for pivottabel</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Opdatering af pivottabeller</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivotdiagram</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivotdiagram</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Oprettelse af pivotdiagrammer</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Redigering af pivotdiagrammer</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtrering af pivotfiagrammer</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Opdatering af pivotdiagrammer</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Sletning af pivottdiagrammer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Scenarier</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/scenario.html?DbPAR=CALC">Brug af scenarier</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotaler</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Brug værktøjet Subtotaler</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Henvisninger</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Adresser og referencer, absolutte og relative</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/cellreferences.html?DbPAR=CALC">Reference til en celle i et andet dokument</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Henvisninger til andre regneark og reference til URL&#39;er</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Referere celler ved hjælp af træk-og-slip</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/address_auto.html?DbPAR=CALC">Genkender Navne som adressering</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Visning, valg og kopiering</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/table_view.html?DbPAR=CALC">Ændre tabelvisninger</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/formula_value.html?DbPAR=CALC">Visning af formler eller værdier</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/line_fix.html?DbPAR=CALC">Fastfryse rækker eller kolonner som sidehoveder</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navigering gennem arkfaner</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Kopiering til flere ark</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/cellcopy.html?DbPAR=CALC">Kopier kun synlige celler</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/mark_cells.html?DbPAR=CALC">Markering af flere celler</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formler og beregninger</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/formulas.html?DbPAR=CALC">Beregninger med formler</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/formula_copy.html?DbPAR=CALC">Kopiering af formler</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/formula_enter.html?DbPAR=CALC">Indtastning af formler</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/formula_value.html?DbPAR=CALC">Visning af formler eller værdier</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/calculate.html?DbPAR=CALC">Beregninger i regneark</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/calc_date.html?DbPAR=CALC">Beregninger med dato og tid.</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/calc_series.html?DbPAR=CALC">Automatisk beregning af serier</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Beregning af tidsforskelle</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/matrixformula.html?DbPAR=CALC">Indtastning af matrixformler</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/wildcards.html?DbPAR=CALC">Brug af jokertegn i formler</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Beskyttelse</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/cell_protect.html?DbPAR=CALC">Beskyt celler mod ændringer</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Ophævelse af cellebeskyttelse</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Skrivning af Calc-makroer</label><ul>\
    <li><a target="_top" href="da/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Læsning og Skrivning af værdier til områder</a></li>\
    <li><a target="_top" href="da/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Formatering af kanter i Calc med makroer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Diverse</label><ul>\
    <li><a target="_top" href="da/text/scalc/guide/auto_off.html?DbPAR=CALC">Deaktivere automatiske ændringer</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/consolidate.html?DbPAR=CALC">Konsolidering af data</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/goalseek.html?DbPAR=CALC">Anvend Målsøgning</a></li>\
    <li><a target="_top" href="da/text/scalc/01/solver.html?DbPAR=CALC">Problemløser</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/multioperation.html?DbPAR=CALC">Anvend Multioperationer</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/multitables.html?DbPAR=CALC">Anvende flere ark</a></li>\
    <li><a target="_top" href="da/text/scalc/guide/validity.html?DbPAR=CALC">Validitet af celleindhold</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Præsentationer (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Generel information og brug af brugergrænseflade</label><ul>\
    <li><a target="_top" href="da/text/simpress/main0000.html?DbPAR=IMPRESS">Velkommen til LibreOffice Impress Hjælp</a></li>\
    <li><a target="_top" href="da/text/simpress/main0503.html?DbPAR=IMPRESS">Funktionalitet i LibreOffice Impress</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Brug af genvejstaster i LibreOffice Impress</a></li>\
    <li><a target="_top" href="da/text/simpress/04/01020000.html?DbPAR=IMPRESS">Genvejstaster for LibreOffice Impress</a></li>\
    <li><a target="_top" href="da/text/simpress/04/presenter.html?DbPAR=IMPRESS">Tastaturgenveje i præsentationskonsollen</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/main.html?DbPAR=IMPRESS">Instruktioner i brug af LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Kommando- og menureference</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menuer</label><ul>\
    <li><a target="_top" href="da/text/simpress/main0100.html?DbPAR=IMPRESS">Menuer</a></li>\
    <li><a target="_top" href="da/text/simpress/main0101.html?DbPAR=IMPRESS">Filer</a></li>\
    <li><a target="_top" href="da/text/simpress/main_edit.html?DbPAR=IMPRESS">Rediger</a></li>\
    <li><a target="_top" href="da/text/simpress/main0103.html?DbPAR=IMPRESS">Vis</a></li>\
    <li><a target="_top" href="da/text/simpress/main0104.html?DbPAR=IMPRESS">Indsæt</a></li>\
    <li><a target="_top" href="da/text/simpress/main_format.html?DbPAR=IMPRESS">Formater</a></li>\
    <li><a target="_top" href="da/text/simpress/main_slide.html?DbPAR=IMPRESS">Dias</a></li>\
    <li><a target="_top" href="da/text/simpress/main0114.html?DbPAR=IMPRESS">Præsentation</a></li>\
    <li><a target="_top" href="da/text/simpress/main_tools.html?DbPAR=IMPRESS">Funktioner</a></li>\
    <li><a target="_top" href="da/text/simpress/main0107.html?DbPAR=IMPRESS">Vindue</a></li>\
    <li><a target="_top" href="da/text/shared/main0108.html?DbPAR=IMPRESS">Hjælp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Værktøjslinjer</label><ul>\
    <li><a target="_top" href="da/text/simpress/main0200.html?DbPAR=IMPRESS">Værktøjslinjer</a></li>\
    <li><a target="_top" href="da/text/simpress/main0210.html?DbPAR=IMPRESS">Værktøjslinjen Tegning</a></li>\
    <li><a target="_top" href="da/text/shared/main0227.html?DbPAR=IMPRESS">Værktøjslinjen Rediger punkter</a></li>\
    <li><a target="_top" href="da/text/shared/find_toolbar.html?DbPAR=IMPRESS">Søgelinje</a></li>\
    <li><a target="_top" href="da/text/shared/main0226.html?DbPAR=IMPRESS">Værktøjslinjen Formulardesign</a></li>\
    <li><a target="_top" href="da/text/shared/main0213.html?DbPAR=IMPRESS">Formularnavigationslinje</a></li>\
    <li><a target="_top" href="da/text/simpress/main0214.html?DbPAR=IMPRESS">Værktøjslinjen Billede</a></li>\
    <li><a target="_top" href="da/text/simpress/main0202.html?DbPAR=IMPRESS">Værktøjslinjen Streg og fyld</a></li>\
    <li><a target="_top" href="da/text/simpress/main0213.html?DbPAR=IMPRESS">Indstillingslinje</a></li>\
    <li><a target="_top" href="da/text/simpress/main0211.html?DbPAR=IMPRESS">Dispositionslinje</a></li>\
    <li><a target="_top" href="da/text/simpress/main0209.html?DbPAR=IMPRESS">Linealer</a></li>\
    <li><a target="_top" href="da/text/simpress/main0212.html?DbPAR=IMPRESS">Diassorteringslinje</a></li>\
    <li><a target="_top" href="da/text/simpress/main0204.html?DbPAR=IMPRESS">Diasvisningslinje</a></li>\
    <li><a target="_top" href="da/text/shared/main0201.html?DbPAR=IMPRESS">Standardlinje</a></li>\
    <li><a target="_top" href="da/text/simpress/main0206.html?DbPAR=IMPRESS">Statuslinje</a></li>\
    <li><a target="_top" href="da/text/shared/main0204.html?DbPAR=IMPRESS">Værktøjslinjen Tabel</a></li>\
    <li><a target="_top" href="da/text/simpress/main0203.html?DbPAR=IMPRESS">Tekstformateringslinje</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Indlæse, gemme, importere, eksportere og sløring</label><ul>\
    <li><a target="_top" href="da/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Gem en præsentation i HTML-format</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Importer HTML-sider ind i præsentationer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Eksportere animationer i GIF-format</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Indsætte regneark i dias</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Indsættelse af grafik</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Indsæt dias fra fil</a></li>\
    <li><a target="_top" href="da/text/shared/guide/redaction.html?DbPAR=IMPRESS">Maskering</a></li>\
    <li><a target="_top" href="da/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Automatisk maskering</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formatering</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Indlæsning af linje- og piletyper</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Definering af brugerdefinerede farver</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Oprettelse af farveovergangs-udfyldninger</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Erstatning af farver</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Arrangere, justere og fordele objekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/background.html?DbPAR=IMPRESS">Ændring af diassets baggrundsfyld</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/footer.html?DbPAR=IMPRESS">Føje et sidehoved eller en sidefod til alle dias</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Ændring og tilføjelse af en Masterside</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Flytning af objekter</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Udskrivning</label><ul>\
    <li><a target="_top" href="da/text/simpress/guide/printing.html?DbPAR=IMPRESS">Udskrivning af præsentationer</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Udskrivning af et dias der er tilpasset papirstørrelsen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Effekter</label><ul>\
    <li><a target="_top" href="da/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Eksportere animationer i GIF-format</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animere objekter i præsentationsdias</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animering af diasovergange</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Ton over mellem to objekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Oprettelse af animerede GIF-billeder</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objekter, billeder og bitmaps</label><ul>\
    <li><a target="_top" href="da/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Kombination af objekter og konstruktion af figurer</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Gruppering af objekter</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Tegning af sektorer og segmenter</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplikering af objekter</a></li>\
    <li><a target="_top" href="da/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformationer</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Rotering af objekter</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Samling af 3D-objekter</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Forbinde linjer</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Konvertering af teksttegn til tegneobjekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Konvertering af bitmapbilleder til vektorgrafik</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Konvertering af 2D-objekter til kurver, polygoner og 3D-objekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Indlæsning af linje- og piletyper</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Tegning af kurver</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Redigering af kurver</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Indsættelse af grafik</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Indsætte regneark i dias</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Flytning af objekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Markering af underliggende objekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Oprettelse af et rutediagram</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Tekst i præsentationer</label><ul>\
    <li><a target="_top" href="da/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Tilføjelse af tekst</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Konvertering af teksttegn til tegneobjekter</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Visning</label><ul>\
    <li><a target="_top" href="da/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Ændring af diasrækkefølgen</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Forstørrelse med tastaturet</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Præsentationer</label><ul>\
    <li><a target="_top" href="da/text/simpress/guide/show.html?DbPAR=IMPRESS">Vise en præsentation</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Bruger præsentationskonsollen</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress fjernbetjening</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/individual.html?DbPAR=IMPRESS">Oprettelse af en brugerdefineret præsentation</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Tidtagning på diasskift</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Tegninger (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Almindelig information og brug af brugergrænseflade</label><ul>\
    <li><a target="_top" href="da/text/sdraw/main0000.html?DbPAR=DRAW">Velkommen til LibreOffice Draw Hjælp</a></li>\
    <li><a target="_top" href="da/text/sdraw/main0503.html?DbPAR=DRAW">Funktionalitet i LibreOffice Draw</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Genvejstaster for tegneobjekter</a></li>\
    <li><a target="_top" href="da/text/sdraw/04/01020000.html?DbPAR=DRAW">Genvejstaster for tegninger</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/main.html?DbPAR=DRAW">Instruktioner i brug af LibreOffice Draw</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Kommando- og menureference</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menuer</label><ul>\
    <li><a target="_top" href="da/text/sdraw/main0100.html?DbPAR=DRAW">Menuer</a></li>\
    <li><a target="_top" href="da/text/sdraw/main0101.html?DbPAR=DRAW">Filer</a></li>\
    <li><a target="_top" href="da/text/sdraw/main_edit.html?DbPAR=DRAW">Rediger</a></li>\
    <li><a target="_top" href="da/text/sdraw/main0103.html?DbPAR=DRAW">Vis (menu i Draw)</a></li>\
    <li><a target="_top" href="da/text/sdraw/main_insert.html?DbPAR=DRAW">Indsæt</a></li>\
    <li><a target="_top" href="da/text/sdraw/main_format.html?DbPAR=DRAW">Formater</a></li>\
    <li><a target="_top" href="da/text/sdraw/main_page.html?DbPAR=DRAW">Side</a></li>\
    <li><a target="_top" href="da/text/sdraw/main_shape.html?DbPAR=DRAW">Figur</a></li>\
    <li><a target="_top" href="da/text/sdraw/main_tools.html?DbPAR=DRAW">Funktioner</a></li>\
    <li><a target="_top" href="da/text/simpress/main0107.html?DbPAR=DRAW">Vindue</a></li>\
    <li><a target="_top" href="da/text/shared/main0108.html?DbPAR=DRAW">Hjælp</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Værktøjslinjer</label><ul>\
    <li><a target="_top" href="da/text/sdraw/main0200.html?DbPAR=DRAW">Værktøjslinjer</a></li>\
    <li><a target="_top" href="da/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D-indstillinger</a></li>\
    <li><a target="_top" href="da/text/sdraw/main0210.html?DbPAR=DRAW">Værktøjslinjen Tegning</a></li>\
    <li><a target="_top" href="da/text/shared/main0227.html?DbPAR=DRAW">Værktøjslinjen Rediger punkter</a></li>\
    <li><a target="_top" href="da/text/shared/find_toolbar.html?DbPAR=DRAW">Søgelinje</a></li>\
    <li><a target="_top" href="da/text/shared/main0226.html?DbPAR=DRAW">Værktøjslinjen Formulardesign</a></li>\
    <li><a target="_top" href="da/text/shared/main0213.html?DbPAR=DRAW">Formularnavigationslinje</a></li>\
    <li><a target="_top" href="da/text/sdraw/main0213.html?DbPAR=DRAW">Indstillingslinje</a></li>\
    <li><a target="_top" href="da/text/shared/main0201.html?DbPAR=DRAW">Standardlinje</a></li>\
    <li><a target="_top" href="da/text/shared/main0204.html?DbPAR=DRAW">Værktøjslinjen Tabel</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Indlæsning, lagring, import og eksport</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Indsættelse af grafik</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatering</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Indlæsning af linje- og piletyper</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/color_define.html?DbPAR=DRAW">Definering af brugerdefinerede farver</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/gradient.html?DbPAR=DRAW">Oprettelse af farveovergangs-udfyldninger</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Erstatning af farver</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Arrangere, justere og fordele objekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/background.html?DbPAR=DRAW">Ændring af diassets baggrundsfyld</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/masterpage.html?DbPAR=DRAW">Ændring og tilføjelse af en Masterside</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/move_object.html?DbPAR=DRAW">Flytning af objekter</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Udskriver</label><ul>\
    <li><a target="_top" href="da/text/simpress/guide/printing.html?DbPAR=DRAW">Udskrivning af præsentationer</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Udskrivning af et dias der er tilpasset papirstørrelsen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effekter</label><ul>\
    <li><a target="_top" href="da/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Ton over mellem to objekter</a></li>\
    <li><a target="_top" href="da/text/shared/01/05350000.html?DbPAR=DRAW">3D-effekter</a></li>\
    <li><a target="_top" href="da/text/simpress/02/10030000.html?DbPAR=DRAW">Transformationer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objekter, billeder og bitmaps</label><ul>\
    <li><a target="_top" href="da/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Kombination af objekter og konstruktion af figurer</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Tegning af sektorer og segmenter</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplikering af objekter</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Rotering af objekter</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Samling af 3D-objekter</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Forbinde linjer</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/text2curve.html?DbPAR=DRAW">Konvertering af teksttegn til tegneobjekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/vectorize.html?DbPAR=DRAW">Konvertering af bitmapbilleder til vektorgrafik</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/3d_create.html?DbPAR=DRAW">Konvertering af 2D-objekter til kurver, polygoner og 3D-objekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Indlæsning af linje- og piletyper</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/line_draw.html?DbPAR=DRAW">Tegning af kurver</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/line_edit.html?DbPAR=DRAW">Redigering af kurver</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Indsættelse af grafik</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/table_insert.html?DbPAR=DRAW">Indsætte regneark i dias</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/move_object.html?DbPAR=DRAW">Flytning af objekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/select_object.html?DbPAR=DRAW">Markering af underliggende objekter</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/orgchart.html?DbPAR=DRAW">Oprettelse af et rutediagram</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Grupper og lag</label><ul>\
    <li><a target="_top" href="da/text/sdraw/guide/groups.html?DbPAR=DRAW">Gruppering af objekter</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/layers.html?DbPAR=DRAW">Om lag</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Indsætte lag</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Arbejde med lag</a></li>\
    <li><a target="_top" href="da/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Flytter objekter til et andet lag</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Tekst i tegninger</label><ul>\
    <li><a target="_top" href="da/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Tilføjelse af tekst</a></li>\
    <li><a target="_top" href="da/text/simpress/guide/text2curve.html?DbPAR=DRAW">Konvertering af teksttegn til tegneobjekter</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Visning</label><ul>\
    <li><a target="_top" href="da/text/simpress/guide/change_scale.html?DbPAR=DRAW">Forstørrelse med tastaturet</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Databasefunktionalitet (base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Generel information</label><ul>\
    <li><a target="_top" href="da/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="da/text/shared/guide/database_main.html?DbPAR=BASE">Databaseoversigt</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_new.html?DbPAR=BASE">Oprette en ny Database</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_tables.html?DbPAR=BASE">Arbejde med tabeller</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_queries.html?DbPAR=BASE">Arbejde med forespørgsler</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_forms.html?DbPAR=BASE">Arbejde med formularer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_reports.html?DbPAR=BASE">Oprette rapporter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_register.html?DbPAR=BASE">Registrere og slette en database</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_im_export.html?DbPAR=BASE">Importere og eksportere data i Base</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Udføre SQL-kommandoer</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formler (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Almindelig information og brug af brugergrænseflade</label><ul>\
    <li><a target="_top" href="da/text/smath/main0000.html?DbPAR=MATH">Velkommen til LibreOffice Math Hjælp</a></li>\
    <li><a target="_top" href="da/text/smath/main0503.html?DbPAR=MATH">Funktionalitet i LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formularelementer</label><ul>\
    <li><a target="_top" href="da/text/smath/01/03090100.html?DbPAR=MATH">Unære/binære operatorer</a></li>\
    <li><a target="_top" href="da/text/smath/01/03090200.html?DbPAR=MATH">Relationer</a></li>\
    <li><a target="_top" href="da/text/smath/01/03090800.html?DbPAR=MATH">Mængdeoperationer</a></li>\
    <li><a target="_top" href="da/text/smath/01/03090400.html?DbPAR=MATH">Funktioner</a></li>\
    <li><a target="_top" href="da/text/smath/01/03090300.html?DbPAR=MATH">Operatorer</a></li>\
    <li><a target="_top" href="da/text/smath/01/03090600.html?DbPAR=MATH">Attributter</a></li>\
    <li><a target="_top" href="da/text/smath/01/03090500.html?DbPAR=MATH">Parenteser</a></li>\
    <li><a target="_top" href="da/text/smath/01/03090700.html?DbPAR=MATH">Formater</a></li>\
    <li><a target="_top" href="da/text/smath/01/03091600.html?DbPAR=MATH">Andre symboler</a></li>\
      </ul></li>\
    <li><a target="_top" href="da/text/smath/guide/main.html?DbPAR=MATH">Instruktioner i brug af LibreOffice Math</a></li>\
    <li><a target="_top" href="da/text/smath/guide/keyboard.html?DbPAR=MATH">Genveje (LibreOffice Math tilgængelighed)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Kommando- og menureference</label><ul>\
    <li><a target="_top" href="da/text/smath/main0100.html?DbPAR=MATH">Menuer</a></li>\
    <li><a target="_top" href="da/text/smath/main0200.html?DbPAR=MATH">Værktøjslinjer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Arbejde med formler</label><ul>\
    <li><a target="_top" href="da/text/smath/guide/align.html?DbPAR=MATH">Manuel justering af dele af en formel</a></li>\
    <li><a target="_top" href="da/text/smath/guide/color.html?DbPAR=MATH">Brug af farve på dele af formler</a></li>\
    <li><a target="_top" href="da/text/smath/guide/attributes.html?DbPAR=MATH">Ændring af standardattributter</a></li>\
    <li><a target="_top" href="da/text/smath/guide/brackets.html?DbPAR=MATH">Samling af dele af en formel med parenteser</a></li>\
    <li><a target="_top" href="da/text/smath/guide/comment.html?DbPAR=MATH">Indtastning af kommentarer</a></li>\
    <li><a target="_top" href="da/text/smath/guide/newline.html?DbPAR=MATH">Indtastning af linjeskift</a></li>\
    <li><a target="_top" href="da/text/smath/guide/parentheses.html?DbPAR=MATH">Indsætte parenteser</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Grafer og diagrammer</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Generelle oplysninger</label><ul>\
    <li><a target="_top" href="da/text/schart/main0000.html?DbPAR=CHART">Diagrammer i LibreOffice</a></li>\
    <li><a target="_top" href="da/text/schart/main0503.html?DbPAR=CHART">Funktionalitet i LibreOffice-diagrammer</a></li>\
    <li><a target="_top" href="da/text/schart/04/01020000.html?DbPAR=CHART">Genveje til diagrammer</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makroer og Script-sprog</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice Basic</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Almindelig information og brug af brugergrænseflade</label><ul>\
    <li><a target="_top" href="da/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice Basic Hjælp</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programmering med LibreOffice Basic</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basis-ordliste</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01010210.html?DbPAR=BASIC">Grundbegreber</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01020000.html?DbPAR=BASIC">Syntaks</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic-IDE</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01030100.html?DbPAR=BASIC">IDE Oversigt</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01030200.html?DbPAR=BASIC">Basic-editoren</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01050100.html?DbPAR=BASIC">Observatørvindue</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/main0211.html?DbPAR=BASIC">Værktøjslinjen Makro</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makro</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Understøttelse for VBA-makroer</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Kommandohenvisning</label><ul>\
    <li><a target="_top" href="da/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Kompiler-indstillinger</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01020300.html?DbPAR=BASIC">Brug af procedurer, funktioner eller egenskaber</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01020500.html?DbPAR=BASIC">Biblioteker, moduler og dialoger</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntaksdiagrammer</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funktioner, udtryk og operatorer</label><ul>\
    <li><a target="_top" href="da/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic-konstanter</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variable</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03060000.html?DbPAR=BASIC">Logiske operatorer</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03110100.html?DbPAR=BASIC">Sammenligningsoperatorer</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120000.html?DbPAR=BASIC">Tekststrenge</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030000.html?DbPAR=BASIC">Dato- og klokkeslætsfunktioner</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03070000.html?DbPAR=BASIC">Matematiske operatorer</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numeriske funktioner</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080100.html?DbPAR=BASIC">Trigonometriske funktioner</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010000.html?DbPAR=BASIC">Skærm I/O funktioner</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020000.html?DbPAR=BASIC">Fil I/O funktioner</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090000.html?DbPAR=BASIC">Styring af programudførelse</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03050000.html?DbPAR=BASIC">Fejlhåndteringsfunktioner</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03130000.html?DbPAR=BASIC">Andre kommandoer</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080300.html?DbPAR=BASIC">Generering af tilfældige tal</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO-objekter</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Brug af Calc-funktioner i makroer</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Eksklusive VBA-funktioner</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090400.html?DbPAR=BASIC">Flere sætninger</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alfabetisk liste over funktioner, udtryk og operatorer</label><ul>\
    <li><a target="_top" href="da/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blå-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName (funktion)</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateTolso-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020101.html?DbPAR=BASIC">Lukkeerklæring</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/collection.html?DbPAR=BASIC">Samlingsobjekt</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const-erklæring</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100070.html?DbPAR=BASIC">Cvar-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030301.html?DbPAR=BASIC">Funktionen Dato</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030102.html?DbPAR=BASIC">DataValue-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101110.html?DbPAR=BASIC">DefCur-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101400.html?DbPAR=BASIC">defDbl-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101120.html?DbPAR=BASIC">DefErr-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101500.html?DbPAR=BASIC">defInt-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101130.html?DbPAR=BASIC">DefSng-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03101140.html?DbPAR=BASIC">DefStr-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090404.html?DbPAR=BASIC">End-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020301.html?DbPAR=BASIC">EOF-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03104700.html?DbPAR=BASIC">Udtrykket Erase</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03050000.html?DbPAR=BASIC">Fejlhåndteringsfunktioner</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080503.html?DbPAR=BASIC">Brøk-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020102.html?DbPAR=BASIC">Freefile-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010302.html?DbPAR=BASIC">Grøn-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090103.html?DbPAR=BASIC">Funktionen IIf</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03060300.html?DbPAR=BASIC">imp-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120401.html?DbPAR=BASIC">Instr-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input#-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt-funkion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Operatoren Is (er)</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120304.html?DbPAR=BASIC">Lset-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120305.html?DbPAR=BASIC">Ltrim-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid-funktion, Mid-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020411.html?DbPAR=BASIC">MK-Dir-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03070600.html?DbPAR=BASIC">Rest-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New (operator) (ny)</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numeriske funktioner</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub-udtryk; On...GoTo-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function-udtryk)</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt-fuktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010103.html?DbPAR=BASIC">Udtrykket Print#</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/property.html?DbPAR=BASIC">udtrykket Egenskab</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020204.html?DbPAR=BASIC">udtrykket Put</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010303.html?DbPAR=BASIC">Rød-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/replace.html?DbPAR=BASIC">ERSTAT-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/Resume.html?DbPAR=BASIC">Udtrykket Resume</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB (funktion) [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020305.html?DbPAR=BASIC">udtrykket Seek#</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space- og Spc-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space- og Spc-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080400.html?DbPAR=BASIC">Kvadratrodsberegning</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">objektet StarDesktop</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/strconv.html?DbPAR=BASIC">Funktionen StrConv [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120202.html?DbPAR=BASIC">String-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03132200.html?DbPAR=BASIC">Objektet ThisComponent</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">Objektet ThisDatabaseDocument</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030302.html?DbPAR=BASIC">Funktionen KLokkeslæt</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName-funktion; VarType-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil (kommando)</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName-funktion [VBA]</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03090411.html?DbPAR=BASIC">With-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write-udtryk</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year-funktion</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-"-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*"-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+"-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/"-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^"-operator</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03120300.html?DbPAR=BASIC">Redigering af strengindhold</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01020100.html?DbPAR=BASIC">Brug af variable</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntaksdiagrammer</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Advancerede Basic-bibioteker</label><ul>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Biblioteket Tools</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Biblioteket DEPOT</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Biblioteket EURO</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Biblioteket FORMWIZARD</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Biblioteket GIMMICKS</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">Biblioteket ImportWizard</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Biblioteket SCHEDULE</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Biblioteket SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Biblioteket TEMPLATE</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">Biblioteket WikiEditor</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">Biblioteket ScriptForge</label><ul>\
    <li><a target="_top" href="da/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">ScriptForge-biblioteker</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Oprettelse af Python-scripts med ScriptForge</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge metodesignaturer</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array service (SF_Array)</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">Tjenesten SFDocuments.Base</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">tjenesten ScriptForge.Basic</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">Tjenesten SFDocuments.Calc</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">tjenesten SFDocuments.Chart</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">Tjenesten SFDatabases.Database</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">Tjenesten SFDialogs.Dialog</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">Tjenesten SFDialogs.DialogControl</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">Tjenesten ScriptForge.Dictionary</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">Tjenesten SFDocuments.Document</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">Tjenesten ScriptForge.Exception (SF_Exception)</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">Tjenesten ScriptForge.FileSystem</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">Tjenesten SFDocuments.Form</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">Tjenesten SFDocuments.FormControl</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">Tjenesten ScriptForge.L10N</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">Tjenesten SFWidgets.Menu</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">Tjenesten ScriptForge.Platform</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">Tjenesten SFWidgets.PopupMenu</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">Tjenesten ScriptForge.Services</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">Tjenesten ScriptForge.Session</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">Tjenesten ScriptForge.String (SF_String)</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">Tjenesten ScriptForge.TextStream (tekst-strøm)</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">Tjenesten ScriptForge.Timer (stopur)</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">Tjenesten ScriptForge.UI</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">Tjenesten  SFDocuments.Writer</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Hjælpelinjer</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/macro_recording.html?DbPAR=BASIC">Optagelse af en makro</a></li>\
    <li><a target="_top" href="da/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Ændring af egenskaberne for kontrolelementer i dialogeditoren</a></li>\
    <li><a target="_top" href="da/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Oprettelse af kontrolelementer i dialogeditoren</a></li>\
    <li><a target="_top" href="da/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Programmeringseksempler for kontrolelementer i dialogeditoren</a></li>\
    <li><a target="_top" href="da/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Åbning af en dialog med Basic</a></li>\
    <li><a target="_top" href="da/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Oprettelse af en Basic-dialog</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01030400.html?DbPAR=BASIC">Administation af biblioteker og moduler</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01020100.html?DbPAR=BASIC">Brug af variable</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01020200.html?DbPAR=BASIC">Brug af objekter</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01030300.html?DbPAR=BASIC">Fejlsøgning i et Basic-program</a></li>\
    <li><a target="_top" href="da/text/sbasic/shared/01040000.html?DbPAR=BASIC">Hændelsesdrevne dokument-makroer</a></li>\
    <li><a target="_top" href="da/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programmeringseksempler</a></li>\
    <li><a target="_top" href="da/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic til Python</a></li>\
    <li><a target="_top" href="da/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Hjælp til Pythonscripts</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Almindelig information og brug af brugergrænseflade</label><ul>\
    <li><a target="_top" href="da/text/sbasic/python/main0000.html?DbPAR=BASIC">Pythonscripts</a></li>\
    <li><a target="_top" href="da/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE til Python</a></li>\
    <li><a target="_top" href="da/text/sbasic/python/python_locations.html?DbPAR=BASIC">Adminstration af Python-scripts.</a></li>\
    <li><a target="_top" href="da/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python inaktiv skal</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programmering med Python</label><ul>\
    <li><a target="_top" href="da/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python: Programmering med Python</a></li>\
    <li><a target="_top" href="da/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python-eksempler</a></li>\
    <li><a target="_top" href="da/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python til Basic</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Script-udviklingsværktøjer</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/dev_tools.html?DbPAR=BASIC">Udviklingsværktøjer</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice-installation</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Ændring af filtilknytning for Microsoft Office-dokumenttyper</a></li>\
    <li><a target="_top" href="da/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Sikker tilstand</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Almindelige emner i Hjælp</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Generel information</label><ul>\
    <li><a target="_top" href="da/text/shared/main0400.html?DbPAR=SHARED">Genvejstaster</a></li>\
    <li><a target="_top" href="da/text/shared/00/00000005.html?DbPAR=SHARED">Generel ordliste</a></li>\
    <li><a target="_top" href="da/text/shared/00/00000002.html?DbPAR=SHARED">Ordliste med internetbegreber</a></li>\
    <li><a target="_top" href="da/text/shared/guide/accessibility.html?DbPAR=SHARED">Tilgængelighed i LibreOffice</a></li>\
    <li><a target="_top" href="da/text/shared/guide/keyboard.html?DbPAR=SHARED">Genveje (LibreOffice Tilgængelighed)</a></li>\
    <li><a target="_top" href="da/text/shared/04/01010000.html?DbPAR=SHARED">Generelle genvejstaster i LibreOffice</a></li>\
    <li><a target="_top" href="da/text/shared/guide/version_number.html?DbPAR=SHARED">Versioner og frigivelser</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice og Microsoft Office</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/ms_user.html?DbPAR=SHARED">Brug af Microsoft Office og LibreOffice</a></li>\
    <li><a target="_top" href="da/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Sammenligning af begreber i Microsoft Office og LibreOffice</a></li>\
    <li><a target="_top" href="da/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Om konvertering af Microsoft Office-dokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Ændring af filtilknytning for Microsoft Office-dokumenttyper</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice valgmuligheder</label><ul>\
    <li><a target="_top" href="da/text/shared/optionen/01000000.html?DbPAR=SHARED">Indstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01010100.html?DbPAR=SHARED">Brugerdata</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01010200.html?DbPAR=SHARED">Generelt</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01010800.html?DbPAR=SHARED">Visning</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01010900.html?DbPAR=SHARED">Udskriftsindstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01010300.html?DbPAR=SHARED">Stier</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01010700.html?DbPAR=SHARED">Skrifttyper</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01030300.html?DbPAR=SHARED">Sikkerhed</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01012000.html?DbPAR=SHARED">Programfarver</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01013000.html?DbPAR=SHARED">Tilgængelighed</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/java.html?DbPAR=SHARED">Avanceret</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Ekspertkonfiguration</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01010400.html?DbPAR=SHARED">Skrivehjælp</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01010600.html?DbPAR=SHARED">Generelt</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01020000.html?DbPAR=SHARED">Indlæs/gem indstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01030000.html?DbPAR=SHARED">Internetindstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01040000.html?DbPAR=SHARED">Tekstdokumentindstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01050000.html?DbPAR=SHARED">HTML-dokumentindstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01060000.html?DbPAR=SHARED">Regnearksindstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01070000.html?DbPAR=SHARED">Præsentationsindstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01080000.html?DbPAR=SHARED">Tegningsindstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01090000.html?DbPAR=SHARED">Formel</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01110000.html?DbPAR=SHARED">Diagramindstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA-egenskaber</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01140000.html?DbPAR=SHARED">Sprog (Indstillinger)</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01150000.html?DbPAR=SHARED">Sprogindstillinger</a></li>\
    <li><a target="_top" href="da/text/shared/optionen/01160000.html?DbPAR=SHARED">Indstillinger for datakilder</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Guider</label><ul>\
    <li><a target="_top" href="da/text/shared/autopi/01000000.html?DbPAR=SHARED">Guide</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Brevguide</label><ul>\
    <li><a target="_top" href="da/text/shared/autopi/01010000.html?DbPAR=SHARED">Brevguide</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Faxguide</label><ul>\
    <li><a target="_top" href="da/text/shared/autopi/01020000.html?DbPAR=SHARED">Faxguide</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Dagsordensguide</label><ul>\
    <li><a target="_top" href="da/text/shared/autopi/01040000.html?DbPAR=SHARED">Dagsordensguide</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML-eksportguide</label><ul>\
    <li><a target="_top" href="da/text/shared/autopi/01110000.html?DbPAR=SHARED">HTML-eksport</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Guide til dokumentkonvertering</label><ul>\
    <li><a target="_top" href="da/text/shared/autopi/01130000.html?DbPAR=SHARED">Dokumentkonvertering</a></li>\
      </ul></li>\
    <li><a target="_top" href="da/text/shared/autopi/01150000.html?DbPAR=SHARED">Guiden Euro-omregner</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Indstilling af LibreOffice</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/configure_overview.html?DbPAR=SHARED">Tilpasning af LibreOffice</a></li>\
    <li><a target="_top" href="da/text/shared/01/packagemanager.html?DbPAR=SHARED">Udvidelsesadministration</a></li>\
    <li><a target="_top" href="da/text/shared/guide/flat_icons.html?DbPAR=SHARED">Ændre ikonvisninger</a></li>\
    <li><a target="_top" href="da/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Tilføje knapper til værktøjslinjer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/workfolder.html?DbPAR=SHARED">Ændre dit arbejdskatalog</a></li>\
    <li><a target="_top" href="da/text/shared/guide/standard_template.html?DbPAR=SHARED">Oprettelse og ændring af standard- og tilpassede skabeloner</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Registrering af en adressebog</a></li>\
    <li><a target="_top" href="da/text/shared/guide/formfields.html?DbPAR=SHARED">Indsættelse og redigering af knapper</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Arbejde med brugergrænsefladen</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Hurtig navigation til objekter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/navigator.html?DbPAR=SHARED">Navigator til dokumentoversigt</a></li>\
    <li><a target="_top" href="da/text/shared/guide/autohide.html?DbPAR=SHARED">Vise, fastgøre og skjule vinduer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/textmode_change.html?DbPAR=SHARED">Skift mellem indsætningstilstand og overskrivningstilstand</a></li>\
    <li><a target="_top" href="da/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Brug af værktøjslinjer</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digitale signaturer</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Om digitale signaturer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Anvende digitale signaturer</a></li>\
    <li><a target="_top" href="da/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Eksporter digital underskrift</a></li>\
    <li><a target="_top" href="da/text/shared/01/timestampauth.html?DbPAR=SHARED">Tidsstemplings-autoriteter til digitale signaturer</a></li>\
    <li><a target="_top" href="da/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Underskrivelse af eksisterende PDF...</a></li>\
    <li><a target="_top" href="da/text/shared/01/addsignatureline.html?DbPAR=SHARED">Tilføjelse af Signaturlinje på dokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/01/signsignatureline.html?DbPAR=SHARED">Underskrivelse på signaturlinjen</a></li>\
    <li><a target="_top" href="da/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Udskrive, faxe og sende</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/labels_database.html?DbPAR=SHARED">Udskrive adresseetiketter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Udskrivning i sort-hvid</a></li>\
    <li><a target="_top" href="da/text/shared/guide/email.html?DbPAR=SHARED">Sende dokumenter som e-mail</a></li>\
    <li><a target="_top" href="da/text/shared/guide/fax.html?DbPAR=SHARED">Afsendelse af fax og konfigurering af LibreOffice for fax</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Træk og slip</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/dragdrop.html?DbPAR=SHARED">Træk og slip i et LibreOffice-dokument</a></li>\
    <li><a target="_top" href="da/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Flytning og kopiering af tekst i dokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kopiering af regnearksområder til tekstdokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kopiering af grafik mellem dokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kopiering af grafik fra galleriet</a></li>\
    <li><a target="_top" href="da/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Træk og slip med datakildevisningen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Kopier og indsæt</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Kopier tegneobjekter til andre dokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kopiering af grafik mellem dokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kopiering af grafik fra galleriet</a></li>\
    <li><a target="_top" href="da/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kopiering af regnearksområder til tekstdokumenter</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Grafer og diagrammer</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/chart_insert.html?DbPAR=SHARED">Indsætte diagrammer</a></li>\
    <li><a target="_top" href="da/text/schart/main0000.html?DbPAR=SHARED">Diagrammer i LibreOffice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Indlæs, gem, import, eksport, PDF</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/doc_open.html?DbPAR=SHARED">Åbne Dokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/import_ms.html?DbPAR=SHARED">Åbner dokumenter gemte i andre formater</a></li>\
    <li><a target="_top" href="da/text/shared/guide/doc_save.html?DbPAR=SHARED">Gem dokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Gemme dokumenter automatisk</a></li>\
    <li><a target="_top" href="da/text/shared/guide/export_ms.html?DbPAR=SHARED">Gem dokumenter i andre formater</a></li>\
    <li><a target="_top" href="da/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Eksporter som PDF</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Import og eksport af data i tekstformat</a></li>\
    <li><a target="_top" href="da/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Links og henvisninger</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Indsætte hyperlinks</a></li>\
    <li><a target="_top" href="da/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Relative og absolutte referencer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Redigering af hyperlinks</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Spore dokumentversion</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Sammenligning af versioner af et dokument</a></li>\
    <li><a target="_top" href="da/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Fletning af versioner</a></li>\
    <li><a target="_top" href="da/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Registrering af ændringer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/redlining.html?DbPAR=SHARED">Registrering og visning af ændringer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Godkendelse eller afvisning af ændringer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Versionsadministration</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etiketter og visitkort</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/labels.html?DbPAR=SHARED">Opret og udskriv etiketter og visitkort</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Indsætte eksterne data</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/copytable2application.html?DbPAR=SHARED">Indsættelse af data fra regneark</a></li>\
    <li><a target="_top" href="da/text/shared/guide/copytext2application.html?DbPAR=SHARED">Indsæt data fra tekstdokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Indsætte, redigere og gemme bitmaps</a></li>\
    <li><a target="_top" href="da/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Tilføjelse af grafik til Galleri</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automatiske funktioner</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Deaktivering af automatisk URL-genkendelse</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">At søge og erstatte</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/data_search2.html?DbPAR=SHARED">Søge med et formularfilter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_search.html?DbPAR=SHARED">Søgning i tabeller og formulardokumenter</a></li>\
    <li><a target="_top" href="da/text/shared/01/02100001.html?DbPAR=SHARED">Liste over regulære udtryk</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Vejledninger</label><ul>\
    <li><a target="_top" href="da/text/shared/guide/linestyles.html?DbPAR=SHARED">Anvende stregtyper</a></li>\
    <li><a target="_top" href="da/text/shared/guide/text_color.html?DbPAR=SHARED">Ændring af tekstfarven</a></li>\
    <li><a target="_top" href="da/text/shared/guide/change_title.html?DbPAR=SHARED">Skift titlen på et dokument</a></li>\
    <li><a target="_top" href="da/text/shared/guide/round_corner.html?DbPAR=SHARED">Oprette runde hjørner</a></li>\
    <li><a target="_top" href="da/text/shared/guide/background.html?DbPAR=SHARED">Angiv baggrundsfarver eller baggrundsgrafik</a></li>\
    <li><a target="_top" href="da/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="da/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="da/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Angive stregtyper</a></li>\
    <li><a target="_top" href="da/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Redigere grafikobjekter</a></li>\
    <li><a target="_top" href="da/text/shared/guide/line_intext.html?DbPAR=SHARED">Tegne linjer i tekst</a></li>\
    <li><a target="_top" href="da/text/shared/guide/aaa_start.html?DbPAR=SHARED">Første trin</a></li>\
    <li><a target="_top" href="da/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Indsætte objekter fra Galleri</a></li>\
    <li><a target="_top" href="da/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Indsæt hårde mellemrum, bindestreger og bløde bindestreger</a></li>\
    <li><a target="_top" href="da/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Indsæt specialtegn</a></li>\
    <li><a target="_top" href="da/text/shared/guide/tabs.html?DbPAR=SHARED">Indsættelse og redigering af tabulatorstop</a></li>\
    <li><a target="_top" href="da/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Bruge eksterne filer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/protection.html?DbPAR=SHARED">Beskyt indhold i LibreOffice</a></li>\
    <li><a target="_top" href="da/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Beskytte ændringer</a></li>\
    <li><a target="_top" href="da/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Markere det maksimale udskrivningsområde på en side</a></li>\
    <li><a target="_top" href="da/text/shared/guide/measurement_units.html?DbPAR=SHARED">Valg af målenheder</a></li>\
    <li><a target="_top" href="da/text/shared/guide/language_select.html?DbPAR=SHARED">Valg af sprog for dokumentet</a></li>\
    <li><a target="_top" href="da/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Tabeldesign</a></li>\
    <li><a target="_top" href="da/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Slå punktopstilling fra i de individuelle afsnit.</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
