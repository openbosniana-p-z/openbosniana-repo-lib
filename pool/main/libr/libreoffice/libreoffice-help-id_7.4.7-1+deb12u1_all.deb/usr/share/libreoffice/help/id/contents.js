document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Dokumen Teks (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Informasi Umum dan Penggunaan Antar Muka Pengguna</label><ul>\
    <li><a target="_top" href="id/text/swriter/main0000.html?DbPAR=WRITER">Selamat datang di Bantuan LibreOffice Writer</a></li>\
    <li><a target="_top" href="id/text/swriter/main0503.html?DbPAR=WRITER">Fitur LibreOffice Writer</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/main.html?DbPAR=WRITER">Instruksi untuk Menggunakan LibreOffice Writer</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Melekatkan dan Mengubah Ukuran Jendela</a></li>\
    <li><a target="_top" href="id/text/swriter/04/01020000.html?DbPAR=WRITER">Tombol Pintas untuk LibreOffice Writer</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/words_count.html?DbPAR=WRITER">Menghitung Kata</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/keyboard.html?DbPAR=WRITER">Menggunakan Tombol Pintas (LibreOffice Aksesibilitas Penulis)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Rujukan Menu dan Perintah</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menu</label><ul>\
    <li><a target="_top" href="id/text/swriter/main0100.html?DbPAR=WRITER">Menu</a></li>\
    <li><a target="_top" href="id/text/swriter/main0101.html?DbPAR=WRITER">Berkas</a></li>\
    <li><a target="_top" href="id/text/swriter/main0102.html?DbPAR=WRITER">Sunting</a></li>\
    <li><a target="_top" href="id/text/swriter/main0103.html?DbPAR=WRITER">Tampilan</a></li>\
    <li><a target="_top" href="id/text/swriter/main0104.html?DbPAR=WRITER">Sisip</a></li>\
    <li><a target="_top" href="id/text/swriter/main0105.html?DbPAR=WRITER">Format</a></li>\
    <li><a target="_top" href="id/text/swriter/main0115.html?DbPAR=WRITER">Gaya (menu)</a></li>\
    <li><a target="_top" href="id/text/swriter/main0110.html?DbPAR=WRITER">Tabel</a></li>\
    <li><a target="_top" href="id/text/swriter/main0120.html?DbPAR=WRITER">Menu Formulir</a></li>\
    <li><a target="_top" href="id/text/swriter/main0106.html?DbPAR=WRITER">Perkakas</a></li>\
    <li><a target="_top" href="id/text/swriter/main0107.html?DbPAR=WRITER">Jendela</a></li>\
    <li><a target="_top" href="id/text/shared/main0108.html?DbPAR=WRITER">Bantuan</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Bilah Alat</label><ul>\
    <li><a target="_top" href="id/text/swriter/main0200.html?DbPAR=WRITER">Bilah Alat</a></li>\
    <li><a target="_top" href="id/text/swriter/main0206.html?DbPAR=WRITER">Bilah Bulatan dan Penomoran</a></li>\
    <li><a target="_top" href="id/text/swriter/main0205.html?DbPAR=WRITER">Bilah Properti Objek Menggambar</a></li>\
    <li><a target="_top" href="id/text/shared/find_toolbar.html?DbPAR=WRITER">Find Bar</a></li>\
    <li><a target="_top" href="id/text/shared/main0226.html?DbPAR=WRITER">Bilah Alat Desain Formulir</a></li>\
    <li><a target="_top" href="id/text/shared/main0213.html?DbPAR=WRITER">Baris Navigasi Formulir</a></li>\
    <li><a target="_top" href="id/text/swriter/main0202.html?DbPAR=WRITER">Bilah Pemformatan</a></li>\
    <li><a target="_top" href="id/text/swriter/main0214.html?DbPAR=WRITER">Bilah Rumus</a></li>\
    <li><a target="_top" href="id/text/swriter/main0215.html?DbPAR=WRITER">Bilah Bingkai</a></li>\
    <li><a target="_top" href="id/text/swriter/main0203.html?DbPAR=WRITER">Bilah Citra</a></li>\
    <li><a target="_top" href="id/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Bilah Alat LibreLogo</a></li>\
    <li><a target="_top" href="id/text/swriter/main0216.html?DbPAR=WRITER">Bilah Objek OLE</a></li>\
    <li><a target="_top" href="id/text/swriter/main0210.html?DbPAR=WRITER">Bilah Pratinjau Cetak (Writer)</a></li>\
    <li><a target="_top" href="id/text/shared/main0214.html?DbPAR=WRITER">Bilah Desain Kueri</a></li>\
    <li><a target="_top" href="id/text/swriter/main0213.html?DbPAR=WRITER">Penggaris</a></li>\
    <li><a target="_top" href="id/text/shared/main0201.html?DbPAR=WRITER">Baris Standar</a></li>\
    <li><a target="_top" href="id/text/swriter/main0208.html?DbPAR=WRITER">Bilah Status (Writer)</a></li>\
    <li><a target="_top" href="id/text/swriter/main0204.html?DbPAR=WRITER">Bilah Tabel</a></li>\
    <li><a target="_top" href="id/text/shared/main0212.html?DbPAR=WRITER">Bilah Data Tabel</a></li>\
    <li><a target="_top" href="id/text/swriter/main0220.html?DbPAR=WRITER">Bilah Objek Teks</a></li>\
    <li><a target="_top" href="id/text/swriter/track_changes_toolbar.html?DbPAR=WRITER">Bilah Alat Lacak Perubahan</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Menavigasi Dokumen Teks</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Menavigasi dan Memilih Dengan Keyboard</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Memindahkan dan Menyalin Teks di Dokumen</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Menyusun Ulang Dokumen dengan Memakai Navigator</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Memasukkan Hyperlink Dengan Navigator</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/navigator.html?DbPAR=WRITER">Navigator untuk Dokumen Teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Menggunakan Kursor Langsung</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Memformat Dokumen Teks</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Mengubah Orientasi Halaman (Lanskap atau Potret)</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/text_capital.html?DbPAR=WRITER">Mengubah Besar/kecil Teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/hidden_text.html?DbPAR=WRITER">menyembunyikan teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Mendefinisikan Perbedaan Tajuk dan Catatan Kaki</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Memasukkan Nama dan Nomor Bab dalam Header atau Footer</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Menerapkan Format Teks Saat Anda Mengetik</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/reset_format.html?DbPAR=WRITER">Mengatur ulang atribut fonta.</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Menerapkan Gaya dalam Mode Format Isi</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/wrap.html?DbPAR=WRITER">Membungkus Teks Di Sekitar Objek</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Menggunakan Frame untuk Memusatkan Teks pada Halaman</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Menegaskan Teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Memutar Teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/page_break.html?DbPAR=WRITER">Memasukkan dan Menghapus Halaman Jeda</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Membuat dan Menerapkan Gaya Halaman</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/subscript.html?DbPAR=WRITER">Membuat Teks Superskrip atau Subskrip</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="021201"><label for="021201">Templat dan Gaya</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Templat dan Gaya</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Gaya Halaman Alternatif pada Halaman Ganjil dan Genap</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/change_header.html?DbPAR=WRITER">Membuat Gaya Halaman Berdasarkan Halaman Saat Ini</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/load_styles.html?DbPAR=WRITER">Menggunakan Gaya Dari Dokumen atau Templat Lain</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Membuat Gaya Baru Dari Pilihan</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Memperbarui Gaya Dari Pilihan</a></li>\
    <li><a target="_top" href="id/text/shared/guide/standard_template.html?DbPAR=WRITER">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="id/text/shared/guide/template_manager.html?DbPAR=WRITER">Manajer Templat</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Grafis dalam Dokumen Teks</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Menyisipkan Grafis</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Menyisipkan Grafis dari Berkas</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Memasukkan Grafik Dari Galeri Dengan Seret-dan-Lepaskan</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Menyisipkan Citra Hasil Pindaian</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Memasukkan Grafik Calc ke Dokumen Teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Memasukkan Grafik Dari LibreOffice Gambar atau Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabel dalam Dokumen Teks</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Menghidupkan atau Mematikan Pengenalan Angka di Tabel</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/tablemode.html?DbPAR=WRITER">Memodifikasi Baris dan Kolom dengan Papan tik</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/table_delete.html?DbPAR=WRITER">Menghapus Tabel atau Isi Tabel</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/table_insert.html?DbPAR=WRITER">Menyisipkan Tabel</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Mengulang Tajuk Tabel pada Halaman Baru</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Mengubah Ukuran dan Kolom dalam sebuah Tabel Teks</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objek dalam Dokumen Teks</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Memposisikan Objek</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/wrap.html?DbPAR=WRITER">Membungkus Teks Di Sekitar Objek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Seksi dan Bingkai dalam Dokumen Teks</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/sections.html?DbPAR=WRITER">Menyunting Seksi</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/section_edit.html?DbPAR=WRITER">Menyunting Seksi</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/section_insert.html?DbPAR=WRITER">Menyisipkan Seksi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Daftar Isi dan Indeks</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Penomoran Bab</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Indeks Buatan Pengguna</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Membuat Daftar Isi</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/indices_index.html?DbPAR=WRITER">Membuat Indeks Alfabet</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Indeks yang Meliputi Beberapa Dokumen</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Membuat Bibliografi</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Mengedit atau Menghapus Masukan Indeks dan Tabel</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Memperbarui, Mengedit dan Menghapus Indeks dan Daftar Isi</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Menentukan Entri Indeks atau Daftar Isi</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/indices_form.html?DbPAR=WRITER">Memformat Indeks atau Daftar Isi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Ruas dalam Dokumen Teks</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/fields.html?DbPAR=WRITER">Tentang Ruas</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/fields_date.html?DbPAR=WRITER">Menyisipkan sebuah Ruas tetap atau Ruas Variabel Tanggal</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/field_convert.html?DbPAR=WRITER">Mengubah Ruas menjadi Teks</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Menghitung dalam Dokumen Teks</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Menghitung Lintas Tabel</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/calculate.html?DbPAR=WRITER">Menghitung dalam Dokumen Teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Menghitung dan Menempelkan Hasil dari suatu Rumus dalam sebuah Dokumen Teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Menghitung Total Sel dalam Tabel</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Menghitung Rumus Rumit dalam Dokumen Teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Menampilkan Hasil dari Perhitungan Tabel dalam Tabel Lain</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Elemen Teks Spesial</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/captions.html?DbPAR=WRITER">Menyunting Seksi</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Teks Bersyarat</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Teks Bersyarat untuk Penghitungan Halaman</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/fields_date.html?DbPAR=WRITER">Menyisipkan sebuah Ruas tetap atau Ruas Variabel Tanggal</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Menambahkan Ruas Masukan</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Menyisipkan Nomor Halaman dari Halaman Lanjutan.</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Menyisipkan Nomor Halaman dalam Kaki.</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/hidden_text.html?DbPAR=WRITER">menyembunyikan teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Mendefinisikan Perbedaan Tajuk dan Catatan Kaki</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Memasukkan Nama dan Nomor Bab dalam Header atau Footer</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Kueri Data Pengguna dalam Ruas atau Persyaratan</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Menyisipkan dan Menyunting Catatan Kaki atau Catatan Akhir.</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Jaral Antar Catatan Kaki</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/header_footer.html?DbPAR=WRITER">Tentang Tajuk dan Catatan Kaki</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Memformat Kepala atau Kaki</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/text_animation.html?DbPAR=WRITER">Menganimasikan Teks</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Membuat Surat Formulir</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Fungsi Otomatis</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Menambahkan Pengecualian ke Daftar OtoKoreksi</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/autotext.html?DbPAR=WRITER">Menggunakan Teks Otomatis</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Untuk Membuat Penomoran atau Daftar Berbulatan Sembari Mengetik</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/auto_off.html?DbPAR=WRITER">Mematikan OtoKoreksi</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Otomatis Memeriksa Ejaan</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Menghidupkan atau Mematikan Pengenalan Angka di Tabel</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Pemenggalan Kata</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Penomoran dan Daftar</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Menambahkan Nomor Bab ke Takarir</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Untuk Membuat Penomoran atau Daftar Berbulatan Sembari Mengetik</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Penomoran Bab</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the List Level of a List Paragraph</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Menggabungkan Daftar Bernomor</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Menambahkan Nomor Baris</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modifying Numbering in an Ordered List</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Menentukan Kisaran Angka</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Menambahkan Penomoran</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numbering and Paragraph Styles</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Menambahkan Bulatan</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Pemeriksaan Ejaan, Tesaurus, dan Bahasa</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Otomatis Memeriksa Ejaan</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Menghapus Kata-Kata Dari Kamus Yang Ditentukan Pengguna</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Kelompok kata.</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Memeriksa Ejaan dan Tata Bahasa</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Tips Penelusuran Masalah</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Memasukkan Teks Sebelum Tabel di Atas Halaman</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Pergi ke Markah Buku Tertentu</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Memuat, Menyimpan, Mengimpor, Mengekspor, dan Menyensor</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/send2html.html?DbPAR=WRITER">Menyimpan Dokumen Teks dalam Format HTML</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Menyisipkan Seluruh Dokumen Teks</a></li>\
    <li><a target="_top" href="id/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
    <li><a target="_top" href="id/text/shared/guide/auto_redact.html?DbPAR=WRITER">Otomatis Redaksi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Dokumen Induk</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Dokumen Master dan Subdokumen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Taut dan Rererensi</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/references.html?DbPAR=WRITER">Memperbarui Rujukan Silang</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Memasukkan Hyperlink Dengan Navigator</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Mencetak</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/print_selection.html?DbPAR=WRITER">Memilih yang akan Dicetak</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Memilih baki kertas pencetak</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/print_preview.html?DbPAR=WRITER">Pratinjau Halaman Sebelum Mencetak</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/print_small.html?DbPAR=WRITER">Mencetak Banyak Halaman dalam Satu Lembar</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Membuat dan Menerapkan Gaya Halaman</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Mencari dan Mengganti</label><ul>\
    <li><a target="_top" href="id/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="id/text/shared/01/02100001.html?DbPAR=WRITER">Daftar Ekspresi Reguler</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">Dokumen HTML (Writer Web)</label><ul>\
    <li><a target="_top" href="id/text/shared/07/09000000.html?DbPAR=WRITER">Halaman Web</a></li>\
    <li><a target="_top" href="id/text/shared/02/01170700.html?DbPAR=WRITER">Filter dan Formulir HTML</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/send2html.html?DbPAR=WRITER">Menyimpan Dokumen Teks dalam Format HTML</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Lembar Sebar (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Informasi Umum dan Penggunaan Antar Muka Pengguna</label><ul>\
    <li><a target="_top" href="id/text/scalc/main0000.html?DbPAR=CALC">Selamat datang di Bantuan LibreOffice Calc</a></li>\
    <li><a target="_top" href="id/text/scalc/main0503.html?DbPAR=CALC">Fitur LibreOffice Calc</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/keyboard.html?DbPAR=CALC">Tombol Pintasan (LibreOffice Aksesibilitas Calc)</a></li>\
    <li><a target="_top" href="id/text/scalc/04/01020000.html?DbPAR=CALC">Tombol Pintas untuk Lembar Sebar</a></li>\
    <li><a target="_top" href="id/text/scalc/01/calculation_accuracy.html?DbPAR=CALC">Calculation Accuracy</a></li>\
    <li><a target="_top" href="id/text/scalc/05/02140000.html?DbPAR=CALC">Kode Kesalahan dalam LibreOffice Calc</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060112.html?DbPAR=CALC">Tambahan bagi Pemrograman LibreOffice Calc</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/main.html?DbPAR=CALC">Instruksi dalam Menggunakan LibreOffice Calc</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Rujukan Menu dan Perintah</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menu</label><ul>\
    <li><a target="_top" href="id/text/scalc/main0100.html?DbPAR=CALC">Menu</a></li>\
    <li><a target="_top" href="id/text/scalc/main0101.html?DbPAR=CALC">Berkas</a></li>\
    <li><a target="_top" href="id/text/scalc/main0102.html?DbPAR=CALC">Sunting</a></li>\
    <li><a target="_top" href="id/text/scalc/main0103.html?DbPAR=CALC">Tampilan</a></li>\
    <li><a target="_top" href="id/text/scalc/main0104.html?DbPAR=CALC">Sisip</a></li>\
    <li><a target="_top" href="id/text/scalc/main0105.html?DbPAR=CALC">Format</a></li>\
    <li><a target="_top" href="id/text/scalc/main0116.html?DbPAR=CALC">Lembar</a></li>\
    <li><a target="_top" href="id/text/scalc/main0112.html?DbPAR=CALC">Data</a></li>\
    <li><a target="_top" href="id/text/scalc/main0106.html?DbPAR=CALC">Perkakas</a></li>\
    <li><a target="_top" href="id/text/scalc/main0107.html?DbPAR=CALC">Jendela</a></li>\
    <li><a target="_top" href="id/text/shared/main0108.html?DbPAR=CALC">Bantuan</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Bilah alat</label><ul>\
    <li><a target="_top" href="id/text/scalc/main0200.html?DbPAR=CALC">Bilah Alat</a></li>\
    <li><a target="_top" href="id/text/shared/find_toolbar.html?DbPAR=CALC">Find Bar</a></li>\
    <li><a target="_top" href="id/text/scalc/main0202.html?DbPAR=CALC">Bilah Pemformatan</a></li>\
    <li><a target="_top" href="id/text/scalc/main0203.html?DbPAR=CALC">Bilah Properti Objek Menggambar</a></li>\
    <li><a target="_top" href="id/text/scalc/main0205.html?DbPAR=CALC">Bilah Pemformatan Teks</a></li>\
    <li><a target="_top" href="id/text/scalc/main0206.html?DbPAR=CALC">Bilah Rumus</a></li>\
    <li><a target="_top" href="id/text/scalc/main0208.html?DbPAR=CALC">Bilah Status</a></li>\
    <li><a target="_top" href="id/text/scalc/main0210.html?DbPAR=CALC">Bilah Pratinjau Cetak</a></li>\
    <li><a target="_top" href="id/text/scalc/main0214.html?DbPAR=CALC">Bilah Citra</a></li>\
    <li><a target="_top" href="id/text/scalc/main0218.html?DbPAR=CALC">Bilah Perkakas</a></li>\
    <li><a target="_top" href="id/text/shared/main0201.html?DbPAR=CALC">Baris Standar</a></li>\
    <li><a target="_top" href="id/text/shared/main0212.html?DbPAR=CALC">Bilah Data Tabel</a></li>\
    <li><a target="_top" href="id/text/shared/main0213.html?DbPAR=CALC">Baris Navigasi Formulir</a></li>\
    <li><a target="_top" href="id/text/shared/main0214.html?DbPAR=CALC">Bilah Desain Kueri</a></li>\
    <li><a target="_top" href="id/text/shared/main0226.html?DbPAR=CALC">Bilah Alat Desain Formulir</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Jenis-jenis Fungsi dan Operator</label><ul>\
    <li><a target="_top" href="id/text/scalc/01/04060000.html?DbPAR=CALC">Wisaya Fungsi</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060100.html?DbPAR=CALC">Fungsi oleh Kategori</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060107.html?DbPAR=CALC">Fungsi Susunan</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060120.html?DbPAR=CALC">Fungsi</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060101.html?DbPAR=CALC">Fungsi Basis Data</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060102.html?DbPAR=CALC">Fungsi Tanggal & Waktu</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060103.html?DbPAR=CALC">Fungsi Finansial Bagian Satu</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060119.html?DbPAR=CALC">Fungsi Finansial Bagian Dua</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060118.html?DbPAR=CALC">Fungsi Finansial Bagian Tiga</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060104.html?DbPAR=CALC">Fungsi Informasi</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060105.html?DbPAR=CALC">Fungsi Logika</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060106.html?DbPAR=CALC">Fungsi Matematika</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060108.html?DbPAR=CALC">Fungsi Statistik</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060181.html?DbPAR=CALC">Fungsi Statistika Bagian Satu</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060182.html?DbPAR=CALC">Fungsi Statistika Bagian Dua</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060183.html?DbPAR=CALC">Fungsi Statistika Bagian Tiga</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060184.html?DbPAR=CALC">Fungsi Statistika Bagian Empat</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060185.html?DbPAR=CALC">Fungsi Statistika Bagian Lima</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060109.html?DbPAR=CALC">Fungsi Lembar Sebar</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060110.html?DbPAR=CALC">Fungsi Teks</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060111.html?DbPAR=CALC">Fungsi Tambahan</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060115.html?DbPAR=CALC">Add-in Functions, Daftar Fungsi Analisis Bagian Satu</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060116.html?DbPAR=CALC">Add-in Functions, Daftar Fungsi Analisis Bagian Dua</a></li>\
    <li><a target="_top" href="id/text/scalc/01/04060199.html?DbPAR=CALC">Operator di LibreOffice Calc</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Fungsi Buatan Pengguna</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Memuat, Menyimpan, Mengimpor, Mengekspor dan Menyusun</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/webquery.html?DbPAR=CALC">Memasukkan Data Luar di Tabel (WebQuery)</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/html_doc.html?DbPAR=CALC">Menyimpan dan Membuka Lembar dalam HTML</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/csv_formula.html?DbPAR=CALC">Mengimpor dan Mengekspor Dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
    <li><a target="_top" href="id/text/shared/guide/auto_redact.html?DbPAR=CALC">Otomatis Redaksi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Memformat</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/text_rotate.html?DbPAR=CALC">Memutar Teks</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/text_wrap.html?DbPAR=CALC">Menulis Teks Multi-baris</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/text_numbers.html?DbPAR=CALC">Memformat Angka sebagai Teks</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/super_subscript.html?DbPAR=CALC">Teks Superskrip / Subskrip</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/row_height.html?DbPAR=CALC">Mengubah Tinggi Baris atau Lebar Kolom</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Menerapkan Pemformatan Kondisional</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Soroti Nomor Negatif</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Menetapkan Format dengan Rumus</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Memasukkan Bilangan dengan Awalan Nol</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/format_table.html?DbPAR=CALC">Memformat Lembar Sebar</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/format_value.html?DbPAR=CALC">Memformat Angka Dengan Desimal</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/value_with_name.html?DbPAR=CALC">Menamai Sel</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/table_rotate.html?DbPAR=CALC">Memutar Tabel (Mentranspos)</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/rename_table.html?DbPAR=CALC">Mengganti Nama Lembar</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/year2000.html?DbPAR=CALC">Tahun 19xx/20xx</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Menggunakan Angka Pembulatan</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/currency_format.html?DbPAR=CALC">Sel dalam Format Mata Uang</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/autoformat.html?DbPAR=CALC">Menggunakan Format Otomatis pada Tabel</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/note_insert.html?DbPAR=CALC">Memasukkan dan Mengedit Komentar</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/design.html?DbPAR=CALC">Memilih tema untuk lembar</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Memasukkan Pecahan</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Menyaring dan Mengurut</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/filters.html?DbPAR=CALC">Menerapkan Penapis</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/specialfilter.html?DbPAR=CALC">Applying Advanced Filters</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/autofilter.html?DbPAR=CALC">Menerapkan Saring Otomatis</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/sorted_list.html?DbPAR=CALC">Menerapkan Daftar Urut</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/remove_duplicates.html?DbPAR=CALC">Removing Duplicate Values</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Mencetak</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/print_title_row.html?DbPAR=CALC">Mencetak Baris atau Kolom di Setiap Halaman</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/print_landscape.html?DbPAR=CALC">Mencetak Lembar dalam Format Pemandangan</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/print_details.html?DbPAR=CALC">Rincian Lembar Pencetakan</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/print_exact.html?DbPAR=CALC">Menentukan Jumlah Halaman untuk Dicetak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Rentang Data</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/database_define.html?DbPAR=CALC">Menetapkan Rentang Basis Data</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/database_filter.html?DbPAR=CALC">Menyaring Rentang Sel</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/database_sort.html?DbPAR=CALC">Menyortir Data</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Pivot Tabel</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/datapilot.html?DbPAR=CALC">Bagi Tabel</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Membuat Nama</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Menghapus Isi</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Menyunting Tabel di dalam Teks</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Penyaringan data</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Memilih Rentang Basis Data</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Menyunting Tabel di dalam Teks</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivot Bagan</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/pivotchart.html?DbPAR=CALC">Skema Pivot</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Membuat Skema Pivot</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Menyunting Bagan Pivot</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Penyaringan Bagan Pivot</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pembaruan Bagan Pivot</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Menghapus Skema Pivot</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Skenario</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/scenario.html?DbPAR=CALC">Menggunakan Skenario</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotal</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Rujukan</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Alamat dan Referensi, Mutlak dan Relatif</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/cellreferences.html?DbPAR=CALC">Mereferensi sebuah Sel di Dokumen Lain</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Referensi ke Lembar Lain dan Mereferensikan URL</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Mereferensi Sel dengan Seret-dan-Lepaskan.</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/address_auto.html?DbPAR=CALC">Mengenali Nama sebagai Pengalamatan</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Melihat, Memilh, Menyalin</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/table_view.html?DbPAR=CALC">Mengubah Tampilan Tabel</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/formula_value.html?DbPAR=CALC">Menampilkan Rumus atau Nilai.</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/line_fix.html?DbPAR=CALC">Membekukan Baris atau Kolom sebagai Tajuk</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/multi_tables.html?DbPAR=CALC">Menavigasi Melalui Tab Lembar</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Menerapkan Banyak Operasi</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/cellcopy.html?DbPAR=CALC">Hanya Salin Sel yang Terlihat</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/mark_cells.html?DbPAR=CALC">Memilih Banyak Sel</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Rumus dan Kalkukasi</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/formulas.html?DbPAR=CALC">Menghitung dengan Rumus.</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/formula_copy.html?DbPAR=CALC">Menyalin Rumus</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/formula_enter.html?DbPAR=CALC">Memasukkan Rumus.</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/formula_value.html?DbPAR=CALC">Menampilkan Rumus atau Nilai.</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/calculate.html?DbPAR=CALC">Perhitungan dalam Lembar Sebar</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/calc_date.html?DbPAR=CALC">Menghitung dengan Tanggal dan Waktu</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/calc_series.html?DbPAR=CALC">Menghitung Seri Secara Otomatis</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Menghitung Perbedaan Waktu</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/matrixformula.html?DbPAR=CALC">Memasuki Rumus Matriks</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/wildcards.html?DbPAR=CALC">Using Wildcards in Formulas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Perlindungan</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/cell_protect.html?DbPAR=CALC">Melindungi Sel dari Perubahan</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Mencabut Proteksi terhadap Sel</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Menulis Makro Calc</label><ul>\
    <li><a target="_top" href="id/text/sbasic/guide/read_write_values.html?DbPAR=CALC">Membaca dan Menulis nilai ke Rentang</a></li>\
    <li><a target="_top" href="id/text/sbasic/guide/calc_borders.html?DbPAR=CALC">Pemformatan Batas di Calc dengan Macros</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0816"><label for="0816">Lain-lain</label><ul>\
    <li><a target="_top" href="id/text/scalc/guide/auto_off.html?DbPAR=CALC">Menonaktifkan Perubahan Otomatis</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/consolidate.html?DbPAR=CALC">Konsolidasi Data</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/goalseek.html?DbPAR=CALC">Menerapkan Pencarian Tujuan</a></li>\
    <li><a target="_top" href="id/text/scalc/01/solver.html?DbPAR=CALC">Solver</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/multioperation.html?DbPAR=CALC">Menerapkan Banyak Operasi</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/multitables.html?DbPAR=CALC">Menerapkan Banyak Operasi</a></li>\
    <li><a target="_top" href="id/text/scalc/guide/validity.html?DbPAR=CALC">Keabsahan Konten Sel.</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentasi (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Informasi Umum dan Penggunaan Antar Muka Pengguna</label><ul>\
    <li><a target="_top" href="id/text/simpress/main0000.html?DbPAR=IMPRESS">Selamat datang di Bantuan LibreOffice Impress</a></li>\
    <li><a target="_top" href="id/text/simpress/main0503.html?DbPAR=IMPRESS">Fitur LibreOffice Impress</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Menggunakan Tombol Pintas di LibreOffice Impress</a></li>\
    <li><a target="_top" href="id/text/simpress/04/01020000.html?DbPAR=IMPRESS">Tombol Pintas untuk LibreOffice Impress</a></li>\
    <li><a target="_top" href="id/text/simpress/04/presenter.html?DbPAR=IMPRESS">Pintasan Papan Ketik Konsol Penyaji</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/main.html?DbPAR=IMPRESS">Instruksi bagi Penggunaan LibreOffice Impress</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Rujukan Menu dan Perintah</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menu</label><ul>\
    <li><a target="_top" href="id/text/simpress/main0100.html?DbPAR=IMPRESS">Menu</a></li>\
    <li><a target="_top" href="id/text/simpress/main0101.html?DbPAR=IMPRESS">Berkas</a></li>\
    <li><a target="_top" href="id/text/simpress/main_edit.html?DbPAR=IMPRESS">Sunting</a></li>\
    <li><a target="_top" href="id/text/simpress/main0103.html?DbPAR=IMPRESS">Tampilan</a></li>\
    <li><a target="_top" href="id/text/simpress/main0104.html?DbPAR=IMPRESS">Sisip</a></li>\
    <li><a target="_top" href="id/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="id/text/simpress/main_slide.html?DbPAR=IMPRESS">Salindia</a></li>\
    <li><a target="_top" href="id/text/simpress/main0114.html?DbPAR=IMPRESS">Pertunjukan Salindia</a></li>\
    <li><a target="_top" href="id/text/simpress/main_tools.html?DbPAR=IMPRESS">Perkakas</a></li>\
    <li><a target="_top" href="id/text/simpress/main0107.html?DbPAR=IMPRESS">Jendela</a></li>\
    <li><a target="_top" href="id/text/shared/main0108.html?DbPAR=IMPRESS">Bantuan</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Bilah Alat</label><ul>\
    <li><a target="_top" href="id/text/simpress/main0200.html?DbPAR=IMPRESS">Bilah Alat</a></li>\
    <li><a target="_top" href="id/text/simpress/main0210.html?DbPAR=IMPRESS">Bilah Menggambar</a></li>\
    <li><a target="_top" href="id/text/shared/main0227.html?DbPAR=IMPRESS">Baris Sunting Titik</a></li>\
    <li><a target="_top" href="id/text/shared/find_toolbar.html?DbPAR=IMPRESS">Find Bar</a></li>\
    <li><a target="_top" href="id/text/shared/main0226.html?DbPAR=IMPRESS">Bilah Alat Desain Formulir</a></li>\
    <li><a target="_top" href="id/text/shared/main0213.html?DbPAR=IMPRESS">Baris Navigasi Formulir</a></li>\
    <li><a target="_top" href="id/text/simpress/main0214.html?DbPAR=IMPRESS">Bilah Citra</a></li>\
    <li><a target="_top" href="id/text/simpress/main0202.html?DbPAR=IMPRESS">Bilah Garis dan Isi</a></li>\
    <li><a target="_top" href="id/text/simpress/main0213.html?DbPAR=IMPRESS">Bilah Opsi</a></li>\
    <li><a target="_top" href="id/text/simpress/main0211.html?DbPAR=IMPRESS">Bilah Kerangka</a></li>\
    <li><a target="_top" href="id/text/simpress/main0209.html?DbPAR=IMPRESS">Penggaris</a></li>\
    <li><a target="_top" href="id/text/simpress/main0212.html?DbPAR=IMPRESS">Bilah Penyusun Salindia</a></li>\
    <li><a target="_top" href="id/text/simpress/main0204.html?DbPAR=IMPRESS">Bilah Tampilan Salindia</a></li>\
    <li><a target="_top" href="id/text/shared/main0201.html?DbPAR=IMPRESS">Baris Standar</a></li>\
    <li><a target="_top" href="id/text/simpress/main0206.html?DbPAR=IMPRESS">Bilah Status</a></li>\
    <li><a target="_top" href="id/text/shared/main0204.html?DbPAR=IMPRESS">Baris Tabel</a></li>\
    <li><a target="_top" href="id/text/simpress/main0203.html?DbPAR=IMPRESS">Bilah Pemformatan Teks</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Memuat, Menyimpan, Mengimpor, Mengekspor dan Menyusun</label><ul>\
    <li><a target="_top" href="id/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Menyimpan Presentasi dalam Bentuk HTML</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Mengimpor Halaman HTML ke Bentuk Presentasi</a></li>\
    <li><a target="_top" href="id/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Mengekspor Animasi dalam Bentuk GIF</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Mengikutkan Lembar Sebar dalam Salindia</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Menyisipkan Grafis</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Insert Slide from File</a></li>\
    <li><a target="_top" href="id/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
    <li><a target="_top" href="id/text/shared/guide/auto_redact.html?DbPAR=IMPRESS">Otomatis Redaksi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Memformat</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/palette_files.html?DbPAR=IMPRESS">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Memuat Gaya Garis dan Panah</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Menentukan Warna Ubahan</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Membuat Isi Bergradien</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Menggantikan Warna</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Menyusun, Meratakan, dan Mendistribusikan Objek</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/background.html?DbPAR=IMPRESS">Mengubah Isi Latar Belakang Salindia</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/footer.html?DbPAR=IMPRESS">Menambahkan Kepala atau Kaki pada Semua Salindia</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Mengubah dan Menambahkan suatu Halaman Induk</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Memindahkan Objek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Mencetak</label><ul>\
    <li><a target="_top" href="id/text/simpress/guide/printing.html?DbPAR=IMPRESS">Mencetak Presentasi</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Mencetak Salindia Agar Pas Ukuran Kertas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Efek</label><ul>\
    <li><a target="_top" href="id/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Mengekspor Animasi dalam Bentuk GIF</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Menganimasikan Objek dalam Salindia Presentasi</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Menganimasikan Transisi Salindia</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Pudar-Silang Dua Objek</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Membuat Citra GIF Bergerak</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objek, Grafis, dan Bitmap</label><ul>\
    <li><a target="_top" href="id/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Menggabungkan Objek dan Membangun Bentuk</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Mengelompokkan Objek</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Menggambar Sektor dan Segmen</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Menggandakan Objek</a></li>\
    <li><a target="_top" href="id/text/simpress/02/10030000.html?DbPAR=IMPRESS">Transformasi</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Memutar Objek</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Merakit Objek 3D</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Menghubungkan Garis</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Mengonversi Karakter Teks ke dalam Objek Menggambar</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Mengonversi Citra Bitmap ke dalam Grafik Vektor</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Mengonversi Objek 2D ke Kurva, Poligon, dan Objek 3D</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Memuat Gaya Garis dan Panah</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Menggambar Kurva</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Menyunting Kurva</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Menyisipkan Grafis</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Mengikutkan Lembar Sebar dalam Salindia</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Memindahkan Objek</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Memilih Objek Yang Mendasari</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Membuat Bagan Alur</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Teks pada Presentasi</label><ul>\
    <li><a target="_top" href="id/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Menambahkan Teks</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Mengonversi Karakter Teks ke dalam Objek Menggambar</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Menampilkan</label><ul>\
    <li><a target="_top" href="id/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Mengubah Urutan Salindia</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Mengubah Tampilan dengan Tombol Kibor</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Pertunjukan Salindia</label><ul>\
    <li><a target="_top" href="id/text/simpress/guide/show.html?DbPAR=IMPRESS">Menampilkan suatu Pertunjukan Salindia</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Menggunakan Konsol Presenter</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Petunjuk Impress Remote</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/individual.html?DbPAR=IMPRESS">Membuat Pertunjukan Salindia Ubahan</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Berlatih Mengatur Waktu Perubahan Salindia</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Gambar (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Informasi Umum dan Penggunaan Antar Muka Pengguna</label><ul>\
    <li><a target="_top" href="id/text/sdraw/main0000.html?DbPAR=DRAW">Selamat datang di Bantuan LibreOffice Draw</a></li>\
    <li><a target="_top" href="id/text/sdraw/main0503.html?DbPAR=DRAW">Fitur LibreOffice Draw</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Tombol Pintas untuk Objek Menggambar</a></li>\
    <li><a target="_top" href="id/text/sdraw/04/01020000.html?DbPAR=DRAW">Tombol Pintas untuk Menggambar</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/main.html?DbPAR=DRAW">Instruksi untuk Menggunakan LibreOffice Draw</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Rujukan Menu dan Perintah</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menu</label><ul>\
    <li><a target="_top" href="id/text/sdraw/main0100.html?DbPAR=DRAW">Menu</a></li>\
    <li><a target="_top" href="id/text/sdraw/main0101.html?DbPAR=DRAW">Berkas</a></li>\
    <li><a target="_top" href="id/text/sdraw/main_edit.html?DbPAR=DRAW">Sunting</a></li>\
    <li><a target="_top" href="id/text/sdraw/main0103.html?DbPAR=DRAW">View (menu in Draw)</a></li>\
    <li><a target="_top" href="id/text/sdraw/main_insert.html?DbPAR=DRAW">Sisipkan</a></li>\
    <li><a target="_top" href="id/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="id/text/sdraw/main_page.html?DbPAR=DRAW">Halaman</a></li>\
    <li><a target="_top" href="id/text/sdraw/main_shape.html?DbPAR=DRAW">Bentuk</a></li>\
    <li><a target="_top" href="id/text/sdraw/main_tools.html?DbPAR=DRAW">Perkakas</a></li>\
    <li><a target="_top" href="id/text/simpress/main0107.html?DbPAR=DRAW">Jendela</a></li>\
    <li><a target="_top" href="id/text/shared/main0108.html?DbPAR=DRAW">Bantuan</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Bilah Alat</label><ul>\
    <li><a target="_top" href="id/text/sdraw/main0200.html?DbPAR=DRAW">Baris Alat</a></li>\
    <li><a target="_top" href="id/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D-Pengaturan</a></li>\
    <li><a target="_top" href="id/text/sdraw/main0210.html?DbPAR=DRAW">Baris Menggambar</a></li>\
    <li><a target="_top" href="id/text/shared/main0227.html?DbPAR=DRAW">Baris Sunting Titik</a></li>\
    <li><a target="_top" href="id/text/shared/find_toolbar.html?DbPAR=DRAW">Find Bar</a></li>\
    <li><a target="_top" href="id/text/shared/main0226.html?DbPAR=DRAW">Bilah Alat Desain Formulir</a></li>\
    <li><a target="_top" href="id/text/shared/main0213.html?DbPAR=DRAW">Baris Navigasi Formulir</a></li>\
    <li><a target="_top" href="id/text/sdraw/main0213.html?DbPAR=DRAW">Baris Opsi</a></li>\
    <li><a target="_top" href="id/text/shared/main0201.html?DbPAR=DRAW">Baris Standar</a></li>\
    <li><a target="_top" href="id/text/shared/main0204.html?DbPAR=DRAW">Baris Tabel</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Memuat, Menyimpan, Mengimpor, dan Mengekspor</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Menyisipkan Grafis</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Pemformatan</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/palette_files.html?DbPAR=DRAW">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Memuat Gaya Garis dan Panah</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/color_define.html?DbPAR=DRAW">Menentukan Warna Ubahan</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/gradient.html?DbPAR=DRAW">Membuat Isi Bergradien</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Menggantikan Warna</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Menyusun, Meratakan, dan Mendistribusikan Objek</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/background.html?DbPAR=DRAW">Mengubah Isi Latar Belakang Salindia</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/masterpage.html?DbPAR=DRAW">Mengubah dan Menambahkan suatu Halaman Induk</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/move_object.html?DbPAR=DRAW">Memindahkan Objek</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Pencetakan</label><ul>\
    <li><a target="_top" href="id/text/simpress/guide/printing.html?DbPAR=DRAW">Mencetak Presentasi</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Mencetak Salindia Agar Pas Ukuran Kertas</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Efek</label><ul>\
    <li><a target="_top" href="id/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Pudar-Silang Dua Objek</a></li>\
    <li><a target="_top" href="id/text/shared/01/05350000.html?DbPAR=DRAW">Efek 3D</a></li>\
    <li><a target="_top" href="id/text/simpress/02/10030000.html?DbPAR=DRAW">Transformasi</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objek, Grafis, dan Bitmap</label><ul>\
    <li><a target="_top" href="id/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Menggabungkan Objek dan Membangun Bentuk</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Menggambar Sektor dan Segmen</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Menggandakan Objek</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Memutar Objek</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Merakit Objek 3D</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Menghubungkan Garis</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/text2curve.html?DbPAR=DRAW">Mengonversi Karakter Teks ke dalam Objek Menggambar</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/vectorize.html?DbPAR=DRAW">Mengonversi Citra Bitmap ke dalam Grafik Vektor</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/3d_create.html?DbPAR=DRAW">Mengonversi Objek 2D ke Kurva, Poligon, dan Objek 3D</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Memuat Gaya Garis dan Panah</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/line_draw.html?DbPAR=DRAW">Menggambar Kurva</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/line_edit.html?DbPAR=DRAW">Menyunting Kurva</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Menyisipkan Grafis</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/table_insert.html?DbPAR=DRAW">Mengikutkan Lembar Sebar dalam Salindia</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/move_object.html?DbPAR=DRAW">Memindahkan Objek</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/select_object.html?DbPAR=DRAW">Memilih Objek Yang Mendasari</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/orgchart.html?DbPAR=DRAW">Membuat Bagan Alur</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Grup dan Lapisan</label><ul>\
    <li><a target="_top" href="id/text/sdraw/guide/groups.html?DbPAR=DRAW">Mengelompokkan Objek</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/layers.html?DbPAR=DRAW">Tentang Lapisan</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Menyisipkan Lapisan</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Bekerja Dengan Lapisan</a></li>\
    <li><a target="_top" href="id/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Memindahkan Objek ke Lapisan yang Berbeda</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Teks dalam Gambar</label><ul>\
    <li><a target="_top" href="id/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Menambahkan Teks</a></li>\
    <li><a target="_top" href="id/text/simpress/guide/text2curve.html?DbPAR=DRAW">Mengonversi Karakter Teks ke dalam Objek Menggambar</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Menampilkan</label><ul>\
    <li><a target="_top" href="id/text/simpress/guide/change_scale.html?DbPAR=DRAW">Mengubah Tampilan dengan Tombol Kibor</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Fungsionalitas Basis Data (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Informasi Umum</label><ul>\
    <li><a target="_top" href="id/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="id/text/shared/guide/database_main.html?DbPAR=BASE">Ikhtisar Basis Data</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_new.html?DbPAR=BASE">Membuat sebuah Basis Data Baru</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_tables.html?DbPAR=BASE">Bekerja dengan tabel</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_queries.html?DbPAR=BASE">Bekerja dengan Pertanyaan</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_forms.html?DbPAR=BASE">Bekerja dengan Formulir</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_reports.html?DbPAR=BASE">Membuat Laporan</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_register.html?DbPAR=BASE">Mendaftarkan dan Menghapus Basis Data</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_im_export.html?DbPAR=BASE">Mengimpor dan Mengekspor Data dalam Base</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Menjalankan Perintah SQL</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Rumus (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Informasi Umum dan Penggunaan Antar Muka Pengguna</label><ul>\
    <li><a target="_top" href="id/text/smath/main0000.html?DbPAR=MATH">Selamat datang di Bantuan LibreOffice Math</a></li>\
    <li><a target="_top" href="id/text/smath/main0503.html?DbPAR=MATH">Fitur LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Elemen Formula</label><ul>\
    <li><a target="_top" href="id/text/smath/01/03090100.html?DbPAR=MATH">Operator Unari/Biner</a></li>\
    <li><a target="_top" href="id/text/smath/01/03090200.html?DbPAR=MATH">Relasi</a></li>\
    <li><a target="_top" href="id/text/smath/01/03090800.html?DbPAR=MATH">Operasi Himpunan</a></li>\
    <li><a target="_top" href="id/text/smath/01/03090400.html?DbPAR=MATH">Fungsi</a></li>\
    <li><a target="_top" href="id/text/smath/01/03090300.html?DbPAR=MATH">Operator</a></li>\
    <li><a target="_top" href="id/text/smath/01/03090600.html?DbPAR=MATH">Atribut</a></li>\
    <li><a target="_top" href="id/text/smath/01/03090500.html?DbPAR=MATH">Tanda Kurung</a></li>\
    <li><a target="_top" href="id/text/smath/01/03090700.html?DbPAR=MATH">Format</a></li>\
    <li><a target="_top" href="id/text/smath/01/03091600.html?DbPAR=MATH">Simbol Lainnya</a></li>\
      </ul></li>\
    <li><a target="_top" href="id/text/smath/guide/main.html?DbPAR=MATH">Petunjuk Menggunakan LibreOffice Math</a></li>\
    <li><a target="_top" href="id/text/smath/guide/keyboard.html?DbPAR=MATH">Tombol Pintas (Aksesibilitas LibreOffice Math)</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Rujukan Menu dan Perintah</label><ul>\
    <li><a target="_top" href="id/text/smath/main0100.html?DbPAR=MATH">Menu</a></li>\
    <li><a target="_top" href="id/text/smath/main0200.html?DbPAR=MATH">Bilah Alat</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Bekerja dengan Rumus</label><ul>\
    <li><a target="_top" href="id/text/smath/guide/align.html?DbPAR=MATH">Meratakan Bagian-bagian Rumus secara Manual</a></li>\
    <li><a target="_top" href="id/text/smath/guide/color.html?DbPAR=MATH">Menerapkan Warna ke Bagian Rumus</a></li>\
    <li><a target="_top" href="id/text/smath/guide/attributes.html?DbPAR=MATH">Mengubah Atribut Baku</a></li>\
    <li><a target="_top" href="id/text/smath/guide/brackets.html?DbPAR=MATH">Menggabungkan Bagian-bagian Rumus di dalam Tanda Kurung</a></li>\
    <li><a target="_top" href="id/text/smath/guide/comment.html?DbPAR=MATH">Menambahkan Komentar</a></li>\
    <li><a target="_top" href="id/text/smath/guide/newline.html?DbPAR=MATH">Memasukkan Pemutus Baris</a></li>\
    <li><a target="_top" href="id/text/smath/guide/parentheses.html?DbPAR=MATH">Memasukkan Tanda Kurung</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Bagan dan Diagram</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Informasi Umum</label><ul>\
    <li><a target="_top" href="id/text/schart/main0000.html?DbPAR=CHART">Bagan dalam LibreOffice</a></li>\
    <li><a target="_top" href="id/text/schart/main0503.html?DbPAR=CHART">Fitur LibreOffice Bagan</a></li>\
    <li><a target="_top" href="id/text/schart/04/01020000.html?DbPAR=CHART">Shortcuts untuk Diagram</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makro dan Skripting</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Informasi Umum dan Penggunaan Antarmuka Pengguna</label><ul>\
    <li><a target="_top" href="id/text/sbasic/shared/main0601.html?DbPAR=BASIC">Bantuan LibreOffice Basic</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01000000.html?DbPAR=BASIC">Pemrograman dengan LibreOffice Basic</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/00000002.html?DbPAR=BASIC">Glosarium Basic LibreOffice</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01010210.html?DbPAR=BASIC">Dasar</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01020000.html?DbPAR=BASIC">Sintaksis</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01050000.html?DbPAR=BASIC">IDE LibreOffice Basic</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01030100.html?DbPAR=BASIC">Ikhtisar IDE</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01030200.html?DbPAR=BASIC">Editor Basic</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01050100.html?DbPAR=BASIC">Jendela Pengawas</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/main0211.html?DbPAR=BASIC">Bilah Alat Makro</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makro</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Referensi Perintah</label><ul>\
    <li><a target="_top" href="id/text/sbasic/shared/Compiler_options.html?DbPAR=BASIC">Compiler Options</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01020300.html?DbPAR=BASIC">Menggunakan Prosedur, Fungsi atau Properti</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01020500.html?DbPAR=BASIC">Pustaka, Modul, dan Dialog</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Fungsi, Pernyataan, dan Operator</label><ul>\
    <li><a target="_top" href="id/text/sbasic/shared/03040000.html?DbPAR=BASIC">Konstanta Dasar</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variabel</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03060000.html?DbPAR=BASIC">Operator Logika</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03110100.html?DbPAR=BASIC">Operator Pembanding</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120000.html?DbPAR=BASIC">String</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030000.html?DbPAR=BASIC">Fungsi Tanggal dan Waktu</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03070000.html?DbPAR=BASIC">Operator Matematika</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080000.html?DbPAR=BASIC">Fungsi Numerik</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080100.html?DbPAR=BASIC">Fungsi Triginometri</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010000.html?DbPAR=BASIC">Fungski Layar I/O</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020000.html?DbPAR=BASIC">Fungsi File I/O</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090000.html?DbPAR=BASIC">Mengontrol Eksekusi Program</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03050000.html?DbPAR=BASIC">Fungsi Penanganan Kesalahan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03130000.html?DbPAR=BASIC">Perintah Lainnya</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080300.html?DbPAR=BASIC">Menghasilkan Angka Acak</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">Obyek UNO</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Using Calc Functions in Macros</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Fungsi VBA ekslusif</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090400.html?DbPAR=BASIC">Pernyataan Further</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Senarai Abjad Fungsi, Pernyataan, dan Operator</label><ul>\
    <li><a target="_top" href="id/text/sbasic/shared/03080601.html?DbPAR=BASIC">Fungsi Abs</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03060100.html?DbPAR=BASIC">Operator AND</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03104200.html?DbPAR=BASIC">Fungsi Array</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120101.html?DbPAR=BASIC">Fungsi Asc</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120111.html?DbPAR=BASIC">Fungsi AscW</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080101.html?DbPAR=BASIC">Fungsi Atn</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03130100.html?DbPAR=BASIC">Pernyataan Beep</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010301.html?DbPAR=BASIC">Fungsi Blue</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090401.html?DbPAR=BASIC">Pernyataan Call</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/CallByName.html?DbPAR=BASIC">CallByName Function</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090102.html?DbPAR=BASIC">Pernyataan Select...Case</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100100.html?DbPAR=BASIC">Fungsi CBool</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120105.html?DbPAR=BASIC">Fungsi CByte</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100050.html?DbPAR=BASIC">Fungsi CCur</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030116.html?DbPAR=BASIC">Fungsi CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030115.html?DbPAR=BASIC">Fungsi CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030114.html?DbPAR=BASIC">Fungsi CDateFromUnoTime</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030113.html?DbPAR=BASIC">Fungsi CDateToUnoTime</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030112.html?DbPAR=BASIC">Fungsi CDateFromUnoDate</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030111.html?DbPAR=BASIC">Fungsi CDateToUnoDate</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030108.html?DbPAR=BASIC">Fungsi CDateFromlso</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030107.html?DbPAR=BASIC">Fungsi CDateToIso</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100300.html?DbPAR=BASIC">Fungsi CDate</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100400.html?DbPAR=BASIC">Fungsi CDbl</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100060.html?DbPAR=BASIC">Fungsi CDec</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Pernyataan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Pernyataan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090402.html?DbPAR=BASIC">Fungsi Choose</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120102.html?DbPAR=BASIC">Fungsi Chr</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120112.html?DbPAR=BASIC">Fungsi ChrW [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100500.html?DbPAR=BASIC">Fungsi CInt</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100600.html?DbPAR=BASIC">Fungsi CLng</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020101.html?DbPAR=BASIC">Pernyataan Penutup</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/collection.html?DbPAR=BASIC">Collection Object</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100700.html?DbPAR=BASIC">Pernyataan Const</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120313.html?DbPAR=BASIC">Fungsi ConvertFromURL</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120312.html?DbPAR=BASIC">Fungsi ConvertToURL</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080102.html?DbPAR=BASIC">Fungsi Cos</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03132400.html?DbPAR=BASIC">Fungsi CreateObject</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03131800.html?DbPAR=BASIC">Fungsi CreateUnoDialog</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03132000.html?DbPAR=BASIC">Fungsi CreateUnoListener</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03131600.html?DbPAR=BASIC">Fungsi CreateUnoService</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03131500.html?DbPAR=BASIC">Fungsi CreateUnoStruct</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03132300.html?DbPAR=BASIC">Fungsi CreateUnoValue</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100900.html?DbPAR=BASIC">Fungsi CSng</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101000.html?DbPAR=BASIC">Fungsi CStr</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Fungsi</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100070.html?DbPAR=BASIC">Fungsi CVar</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03100080.html?DbPAR=BASIC">Fungsi CVErr</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Function</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030110.html?DbPAR=BASIC">Fungsi DateAdd</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030120.html?DbPAR=BASIC">Fungsi DateDiff</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030130.html?DbPAR=BASIC">Fungsi DatePart</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030101.html?DbPAR=BASIC">Fungsi DateSerial</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030102.html?DbPAR=BASIC">Fungsi DateValue</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030103.html?DbPAR=BASIC">Fungsi Day</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140000.html?DbPAR=BASIC">Fungsi DDB [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090403.html?DbPAR=BASIC">Pernyataan Declare</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101100.html?DbPAR=BASIC">Pernyataan DefBool</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101110.html?DbPAR=BASIC">Pernyataan DefCur</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101300.html?DbPAR=BASIC">Pernyataan DefDate</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101400.html?DbPAR=BASIC">Pernyataan DefDbl</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101120.html?DbPAR=BASIC">Pernyataan DefErr</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101500.html?DbPAR=BASIC">Pernyataan DefInt</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101600.html?DbPAR=BASIC">Pernyataan DefLng</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101700.html?DbPAR=BASIC">Pernyataan DefObj</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101130.html?DbPAR=BASIC">Pernyataan DefSng</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03101140.html?DbPAR=BASIC">Pernyataan DefStr</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102000.html?DbPAR=BASIC">Pernyataan DefVar</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03104300.html?DbPAR=BASIC">Fungsi DimArray</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102100.html?DbPAR=BASIC">Pernyataan Dim</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Fungsi</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090201.html?DbPAR=BASIC">Pernyataan Do...Loop</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090404.html?DbPAR=BASIC">Pernyataan End</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/enum.html?DbPAR=BASIC">Pernyataan Enumerasi</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03130800.html?DbPAR=BASIC">Fungsi Environ</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020301.html?DbPAR=BASIC">Fungsi Eof</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03104600.html?DbPAR=BASIC">Fungsi EqualUnoObjects</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03060200.html?DbPAR=BASIC">Operator Eqv</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03050100.html?DbPAR=BASIC">Fungsi Erl</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03050200.html?DbPAR=BASIC">Fungsi Err</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03050300.html?DbPAR=BASIC">Fungsi Error</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03050000.html?DbPAR=BASIC">Fungsi Penanganan Kesalahan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090412.html?DbPAR=BASIC">Pernyataan Exit</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080201.html?DbPAR=BASIC">Fungsi Exp</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020405.html?DbPAR=BASIC">Fungsi FileAttr</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020406.html?DbPAR=BASIC">Pernyataan FileCopy</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020407.html?DbPAR=BASIC">Fungsi FileDateTime</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020415.html?DbPAR=BASIC">Fungsi FileExists</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020408.html?DbPAR=BASIC">Fungsi FileLen</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103800.html?DbPAR=BASIC">Fungsi FindObject</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103900.html?DbPAR=BASIC">Fungsi FindPropertyObject</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fungsi Fix</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Pernyataan selanjutnya</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Pernyataan selanjutnya</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120301.html?DbPAR=BASIC">Fungsi Format</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03150000.html?DbPAR=BASIC">Fungsi FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03170010.html?DbPAR=BASIC">Fungsi FormatNumber [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080503.html?DbPAR=BASIC">Fungsi Frac</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020102.html?DbPAR=BASIC">Fungsi FreeFile</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090405.html?DbPAR=BASIC">Fungsi FreeLibrary</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090406.html?DbPAR=BASIC">Pernyataan Fungsi</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140001.html?DbPAR=BASIC">Fungsi FV [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020409.html?DbPAR=BASIC">Fungsi GetAttr</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03132500.html?DbPAR=BASIC">Fungsi GetDefaultContext</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03132100.html?DbPAR=BASIC">Fungsi GetGuiType</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03131700.html?DbPAR=BASIC">Fungsi GetProcessServiceManager</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03131000.html?DbPAR=BASIC">Fungsi GetSolarVersion</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03130700.html?DbPAR=BASIC">Fungsi GetSystemTicks</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020201.html?DbPAR=BASIC">Mendapatkan Pernyataan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103450.html?DbPAR=BASIC">Pernyataan Global</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090301.html?DbPAR=BASIC">Pernyataan GoSub...Return</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090302.html?DbPAR=BASIC">Pernyataan GoTo</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010302.html?DbPAR=BASIC">Fungsi Green</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03104400.html?DbPAR=BASIC">Fungsi HasUnoInterfaces</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080801.html?DbPAR=BASIC">Fungsi Hex</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030201.html?DbPAR=BASIC">fungsi jam</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Function</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090101.html?DbPAR=BASIC">Pernyataan If...Maka...Else</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03060300.html?DbPAR=BASIC">Operator Imp</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120401.html?DbPAR=BASIC">Fungsi InStr</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120411.html?DbPAR=BASIC">Fungsi InStrRev [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03160000.html?DbPAR=BASIC">Fungsi Input [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010201.html?DbPAR=BASIC">Fungsi InputBox</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020202.html?DbPAR=BASIC">Pernyataan Input#</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080502.html?DbPAR=BASIC">Fungsi Int</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140002.html?DbPAR=BASIC">Fungsi IPmt [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140003.html?DbPAR=BASIC">Fungsi IRR [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/is_keyword.html?DbPAR=BASIC">Is Operator</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102200.html?DbPAR=BASIC">Fungsi IsArray</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102300.html?DbPAR=BASIC">Fungsi IsDate</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102400.html?DbPAR=BASIC">Fungsi IsEmpty</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102450.html?DbPAR=BASIC">Fungsi IsError</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03104000.html?DbPAR=BASIC">Fungsi IsMissing</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102600.html?DbPAR=BASIC">Fungsi IsNull</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102700.html?DbPAR=BASIC">Fungsi IsNumeric</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102800.html?DbPAR=BASIC">Fungsi IsObject</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03104500.html?DbPAR=BASIC">Fungsi IsUnoStruct</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120315.html?DbPAR=BASIC">Fungsi Join</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020410.html?DbPAR=BASIC">Pernyataan Kill</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102900.html?DbPAR=BASIC">Fungsi LBound</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120302.html?DbPAR=BASIC">Fungsi LCase</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120304.html?DbPAR=BASIC">Pernyataan LSet</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120305.html?DbPAR=BASIC">Fungsi LTrim</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120303.html?DbPAR=BASIC">Fungsi Left</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120402.html?DbPAR=BASIC">Fungsi Len</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103100.html?DbPAR=BASIC">Pernyataan Let</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input# Statement</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020302.html?DbPAR=BASIC">Fungsi Lokasi</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020303.html?DbPAR=BASIC">Fungsi Lof</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080202.html?DbPAR=BASIC">Fungsi Log</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120306.html?DbPAR=BASIC">Fungsi Mid, Pernyataan Mid</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030202.html?DbPAR=BASIC">Fungsi Menit</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140004.html?DbPAR=BASIC">Fungsi MIRR [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020411.html?DbPAR=BASIC">Pernyataan MkDir</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03070600.html?DbPAR=BASIC">Operator Mod</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030104.html?DbPAR=BASIC">Fungsi Month</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03150002.html?DbPAR=BASIC">Fungsi MonthName [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010102.html?DbPAR=BASIC">Fungsi MsgBox</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010101.html?DbPAR=BASIC">Pernyataan MsgBox</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020412.html?DbPAR=BASIC">Pernyataan Nama</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/new_keyword.html?DbPAR=BASIC">New Operator</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03060400.html?DbPAR=BASIC">Operator Not</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030203.html?DbPAR=BASIC">Fungsi Sekarang</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140005.html?DbPAR=BASIC">Fungsi NPer [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140006.html?DbPAR=BASIC">Fungsi NPV [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080000.html?DbPAR=BASIC">Fungsi Numerik</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080802.html?DbPAR=BASIC">Fungsi Oct</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03050500.html?DbPAR=BASIC">Pada Galat GoTo ... Pernyataan Resume</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090303.html?DbPAR=BASIC">Pernyataan On...GoSub; Pernyataan On...GoTo</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020103.html?DbPAR=BASIC">Buka Pernyataan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103200.html?DbPAR=BASIC">Pernyataan Basis Opsi</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103300.html?DbPAR=BASIC">Opsi Pernyataan Eksplisit</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103350.html?DbPAR=BASIC">Opsi Pernyataan Dukungan VBAS</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03104100.html?DbPAR=BASIC">Pilihan (dalam Tanda Fungsi)</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03060500.html?DbPAR=BASIC">Operator Or</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140007.html?DbPAR=BASIC">Fungsi Pmt [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140008.html?DbPAR=BASIC">Fungsi PPmt [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print# Statement</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103400.html?DbPAR=BASIC">Pernyataan Umum</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put# Statement</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140009.html?DbPAR=BASIC">Fungsi PV [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010304.html?DbPAR=BASIC">Fungsi QBColor</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140010.html?DbPAR=BASIC">Fungsi Rate [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080301.html?DbPAR=BASIC">Pernyataan Randomize</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03102101.html?DbPAR=BASIC">Pernyataan ReDim</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010303.html?DbPAR=BASIC">Fungsi Red</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090407.html?DbPAR=BASIC">Pernyataan Rem</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Pernyataan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010305.html?DbPAR=BASIC">Fungsi RGB</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03010306.html?DbPAR=BASIC">RGB Function [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120307.html?DbPAR=BASIC">Fungsi Right</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020413.html?DbPAR=BASIC">Pernyataan RmDir</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080302.html?DbPAR=BASIC">Fungsi Rnd</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03170000.html?DbPAR=BASIC">Fungsi Round [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120308.html?DbPAR=BASIC">Pernyataan RSet</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120309.html?DbPAR=BASIC">Fungsi RTrim</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030204.html?DbPAR=BASIC">Fungsi Detik</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020304.html?DbPAR=BASIC">Carilah Fungsi</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek# Statement</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090102.html?DbPAR=BASIC">Pernyataan Select...Case</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020414.html?DbPAR=BASIC">Pernyataan SetAttr</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103700.html?DbPAR=BASIC">Tetapkan Pernyataan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080701.html?DbPAR=BASIC">Fungsi Sgn</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03130500.html?DbPAR=BASIC">Fungsi Shell</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080103.html?DbPAR=BASIC">Fungsi Sin</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140011.html?DbPAR=BASIC">Fungsi SLN [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120201.html?DbPAR=BASIC">Spasi dan Fungsi Spc</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120201.html?DbPAR=BASIC">Spasi dan Fungsi Spc</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120314.html?DbPAR=BASIC">Fungsi Split</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080401.html?DbPAR=BASIC">Fungsi Sqr</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080400.html?DbPAR=BASIC">Penghitungan Akar</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103500.html?DbPAR=BASIC">Pernyataan Statis</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090408.html?DbPAR=BASIC">Pernyataan Stop</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120403.html?DbPAR=BASIC">Fungsi StrComp</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/strconv.html?DbPAR=BASIC">StrConv Function [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120103.html?DbPAR=BASIC">Fungsi Str</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120412.html?DbPAR=BASIC">Fungsi StrReverse [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120202.html?DbPAR=BASIC">Fungsi String</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090409.html?DbPAR=BASIC">Pernyataan Sub</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090410.html?DbPAR=BASIC">Fungsi Switch</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03140012.html?DbPAR=BASIC">Fungsi SYD [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03080104.html?DbPAR=BASIC">Fungsi Tan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/thisdbdoc.html?DbPAR=BASIC">ThisDatabaseDocument object</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030205.html?DbPAR=BASIC">Fungsi TimeSerial</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030206.html?DbPAR=BASIC">Fungsi TimeValue</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Function</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030303.html?DbPAR=BASIC">Fungsi Timer</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120311.html?DbPAR=BASIC">Fungsi Trim</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03131300.html?DbPAR=BASIC">Fungsi TwipsPerPixelX</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03131400.html?DbPAR=BASIC">Fungsi TwipsPerPixelY</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090413.html?DbPAR=BASIC">Pernyataan Type</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103600.html?DbPAR=BASIC">Fungsi TypeName; Fungsi VarType</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03103000.html?DbPAR=BASIC">Fungsi UBound</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120310.html?DbPAR=BASIC">Fungsi UCase</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120104.html?DbPAR=BASIC">Fungsi Val</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03130600.html?DbPAR=BASIC">Pernyataan Wait</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03130610.html?DbPAR=BASIC">Pernyataan Tunggu Hingga</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030105.html?DbPAR=BASIC">Fungsi WeekDay</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03150001.html?DbPAR=BASIC">Fungsi WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090203.html?DbPAR=BASIC">Pernyataan While...Wend</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03090411.html?DbPAR=BASIC">Dengan Pernyataan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03020205.html?DbPAR=BASIC">Tulis Pernyataan</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03060600.html?DbPAR=BASIC">Operator XOR</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03030106.html?DbPAR=BASIC">Fungsi Year</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03070100.html?DbPAR=BASIC">Operator "-"</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03070200.html?DbPAR=BASIC">Operator "*"</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03070300.html?DbPAR=BASIC">Operator "+"</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03070400.html?DbPAR=BASIC">Operator "/"</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03070700.html?DbPAR=BASIC">"\" Operator</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03070500.html?DbPAR=BASIC">Operator "^"</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03120300.html?DbPAR=BASIC">Mengedit konten String</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01020100.html?DbPAR=BASIC">Menggunakan Variabel</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/conventions.html?DbPAR=BASIC">Syntax Diagrams</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Pustaka Basic Lanjutan</label><ul>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Alat-alat Pustaka</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Pustaka DEPOT</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Pustaka EURO</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Pustaka FORMWIZARD</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Pustaka GIMMICKS</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_importwiz.html?DbPAR=BASIC">Pustaka Wahana Pandu Impor</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">JADWAL Pustaka</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Pustaka SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Pustaka  TEMPLATE</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_wikieditor.html?DbPAR=BASIC">WikiEditor Pustaka</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="07010305"><label for="07010305">Pustaka ScriptForge</label><ul>\
    <li><a target="_top" href="id/text/sbasic/shared/03/lib_ScriptForge.html?DbPAR=BASIC">Pustaka ScriptForge</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_intro.html?DbPAR=BASIC">Creating Python Scripts with ScriptForge</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_methods.html?DbPAR=BASIC">ScriptForge Method Signatures</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_array.html?DbPAR=BASIC">ScriptForge.Array servis (SF_Array)</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_base.html?DbPAR=BASIC">SFDocuments.Base service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_basic.html?DbPAR=BASIC">ScriptForge.Basic service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_calc.html?DbPAR=BASIC">SFDocuments.Calc service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_chart.html?DbPAR=BASIC">SFDocuments.Chart service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_database.html?DbPAR=BASIC">SFDatabases.Database service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_dialog.html?DbPAR=BASIC">SFDialogs.Dialog service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_dialogcontrol.html?DbPAR=BASIC">SFDialogs.DialogControl service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_dictionary.html?DbPAR=BASIC">ScriptForge.Dictionary service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_document.html?DbPAR=BASIC">SFDocuments.Document service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_exception.html?DbPAR=BASIC">ScriptForge.Exception service (SF_Exception)</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_filesystem.html?DbPAR=BASIC">ScriptForge.FileSystem service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_form.html?DbPAR=BASIC">SFDocuments.Form service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_formcontrol.html?DbPAR=BASIC">SFDocuments.FormControl service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_l10n.html?DbPAR=BASIC">ScriptForge.L10N service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_menu.html?DbPAR=BASIC">SFWidgets.Menu service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_platform.html?DbPAR=BASIC">ScriptForge.Platform service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_popupmenu.html?DbPAR=BASIC">SFWidgets.PopupMenu service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_region.html?DbPAR=BASIC">ScriptForge.Region service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_services.html?DbPAR=BASIC">ScriptForge.Services service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_session.html?DbPAR=BASIC">ScriptForge.Session service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_string.html?DbPAR=BASIC">ScriptForge.String service (SF_String)</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_textstream.html?DbPAR=BASIC">ScriptForge.TextStream service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_timer.html?DbPAR=BASIC">ScriptForge.Timer service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_ui.html?DbPAR=BASIC">ScriptForge.UI service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_unittest.html?DbPAR=BASIC">SFUnitTests.UnitTest service</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/03/sf_writer.html?DbPAR=BASIC">SFDocuments.Writer service</a></li>\
          </ul></li>\
      </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Panduan</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/macro_recording.html?DbPAR=BASIC">Merekam Makro</a></li>\
    <li><a target="_top" href="id/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Mengubah Properti Kontrol dalam Editor Dialog</a></li>\
    <li><a target="_top" href="id/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Membuat Kontrol pada Editor Dialog</a></li>\
    <li><a target="_top" href="id/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Contoh Pemrograman untuk Kontrol di Editor Dialog</a></li>\
    <li><a target="_top" href="id/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Membuka Dialog Dengan Basic</a></li>\
    <li><a target="_top" href="id/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Membuat Dialog Dasar</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01030400.html?DbPAR=BASIC">Mengorganisasikan Pustaka dan Modul</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01020100.html?DbPAR=BASIC">Menggunakan Variabel</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01020200.html?DbPAR=BASIC">Menggunakan Objek</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01030300.html?DbPAR=BASIC">Awakutu Program Basic</a></li>\
    <li><a target="_top" href="id/text/sbasic/shared/01040000.html?DbPAR=BASIC">Document Event-Driven Macros</a></li>\
    <li><a target="_top" href="id/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Contoh Pemograman Dasar</a></li>\
    <li><a target="_top" href="id/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Dasar untuk Python</a></li>\
    <li><a target="_top" href="id/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Bantuan Skrip Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Informasi Umum dan Penggunaan Antar Muka Pengguna</label><ul>\
    <li><a target="_top" href="id/text/sbasic/python/main0000.html?DbPAR=BASIC">Skrip Python</a></li>\
    <li><a target="_top" href="id/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE untuk Python</a></li>\
    <li><a target="_top" href="id/text/sbasic/python/python_locations.html?DbPAR=BASIC">Organisasi Skrip Python</a></li>\
    <li><a target="_top" href="id/text/sbasic/python/python_shell.html?DbPAR=BASIC">Shell Interaktif Python</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Pemrograman dengan Python</label><ul>\
    <li><a target="_top" href="id/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Pemrograman dengan Python</a></li>\
    <li><a target="_top" href="id/text/sbasic/python/python_examples.html?DbPAR=BASIC">Contoh python</a></li>\
    <li><a target="_top" href="id/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python ke Basic</a></li>\
      </ul></li>\
    </ul></li>\
    <li><input type="checkbox" id="0703"><label for="0703">Perkakas Pengembangan Skrip</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/dev_tools.html?DbPAR=BASIC">Development Tools</a></li>\
    </ul></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Pemasangan LibreOffice</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Mengubah Asosiasi Jenis Dokumen Microsoft Office</a></li>\
    <li><a target="_top" href="id/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Mode Aman</a></li>\
  </ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Topik Bantuan Umum</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Informasi Umum</label><ul>\
    <li><a target="_top" href="id/text/shared/main0400.html?DbPAR=SHARED">Tombol Pintas</a></li>\
    <li><a target="_top" href="id/text/shared/00/00000005.html?DbPAR=SHARED">Daftar Kata Umum</a></li>\
    <li><a target="_top" href="id/text/shared/00/00000002.html?DbPAR=SHARED">Daftar istilah Internet</a></li>\
    <li><a target="_top" href="id/text/shared/guide/accessibility.html?DbPAR=SHARED">Aksesibilitas dalam LibreOffice</a></li>\
    <li><a target="_top" href="id/text/shared/guide/keyboard.html?DbPAR=SHARED">Pintasan (LibreOffice Accessibility)</a></li>\
    <li><a target="_top" href="id/text/shared/04/01010000.html?DbPAR=SHARED">Tombol Pintas Umum dalam LibreOffice</a></li>\
    <li><a target="_top" href="id/text/shared/guide/version_number.html?DbPAR=SHARED">Veris dan Nomor Bangun</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice dan Microsoft Office</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/ms_user.html?DbPAR=SHARED">Menggunakan Microsoft Office dan LibreOffice</a></li>\
    <li><a target="_top" href="id/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Membandingkan Microsoft Office dan Ketentuan LibreOffice</a></li>\
    <li><a target="_top" href="id/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Tentang Mengonversi Dokumen Microsoft Office</a></li>\
    <li><a target="_top" href="id/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Mengubah Asosiasi Jenis Dokumen Microsoft Office</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Opsi LibreOffice</label><ul>\
    <li><a target="_top" href="id/text/shared/optionen/01000000.html?DbPAR=SHARED">Pilihan</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01010100.html?DbPAR=SHARED">Data Pengguna</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01010200.html?DbPAR=SHARED">Umum</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01010800.html?DbPAR=SHARED">Tampilan</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01010900.html?DbPAR=SHARED">Pilihan Cetak</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01010300.html?DbPAR=SHARED">Jalur</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01010700.html?DbPAR=SHARED">Huruf</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01030300.html?DbPAR=SHARED">Keamanan</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01012000.html?DbPAR=SHARED">Warna Aplikasi</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01013000.html?DbPAR=SHARED">Aksesibilitas</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/java.html?DbPAR=SHARED">Lanjut</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Konfigurasi Pakar</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">IDE Basic</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01010400.html?DbPAR=SHARED">Bantuan Menulis</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01010600.html?DbPAR=SHARED">Umum</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01020000.html?DbPAR=SHARED">Muat/Simpan opsi</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01030000.html?DbPAR=SHARED">Opsi Internet</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01040000.html?DbPAR=SHARED">Pilihan Dokumen Teks</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01050000.html?DbPAR=SHARED">Pilihan Dokumen HTML</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01060000.html?DbPAR=SHARED">Pilihan Lembar Sebar</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01070000.html?DbPAR=SHARED">Opsi Presentasi</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01080000.html?DbPAR=SHARED">Opsi Gambar</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01090000.html?DbPAR=SHARED">Rumus</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01110000.html?DbPAR=SHARED">Pilihan Grafik</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01130100.html?DbPAR=SHARED">Properti VBA</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01140000.html?DbPAR=SHARED">Languages (Options)</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01150000.html?DbPAR=SHARED">Pilihan Pengaturan Bahasa</a></li>\
    <li><a target="_top" href="id/text/shared/optionen/01160000.html?DbPAR=SHARED">Opsi sumber data</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Wisaya</label><ul>\
    <li><a target="_top" href="id/text/shared/autopi/01000000.html?DbPAR=SHARED">Wahana Pandu</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Wisaya Surat</label><ul>\
    <li><a target="_top" href="id/text/shared/autopi/01010000.html?DbPAR=SHARED">Wahana Pandu Surat</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Wisaya Faks</label><ul>\
    <li><a target="_top" href="id/text/shared/autopi/01020000.html?DbPAR=SHARED">Wisaya Faks</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Wisaya Agenda</label><ul>\
    <li><a target="_top" href="id/text/shared/autopi/01040000.html?DbPAR=SHARED">Wisaya Agenda</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Wisaya Ekspor HTML</label><ul>\
    <li><a target="_top" href="id/text/shared/autopi/01110000.html?DbPAR=SHARED">Ekspor HTML</a></li>\
      </ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Wisaya Pengonversi Dokumen</label><ul>\
    <li><a target="_top" href="id/text/shared/autopi/01130000.html?DbPAR=SHARED">Konverter Dokumen</a></li>\
      </ul></li>\
    <li><a target="_top" href="id/text/shared/autopi/01150000.html?DbPAR=SHARED">Wisaya Konverter Euro</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Menata LibreOffice</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/configure_overview.html?DbPAR=SHARED">Mengonfigurasi LibreOffice</a></li>\
    <li><a target="_top" href="id/text/shared/01/packagemanager.html?DbPAR=SHARED">Manajer Ekstensi</a></li>\
    <li><a target="_top" href="id/text/shared/guide/flat_icons.html?DbPAR=SHARED">Mengubah Tampilan Ikon</a></li>\
    <li><a target="_top" href="id/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Menambahkan Tombol ke Toolbar</a></li>\
    <li><a target="_top" href="id/text/shared/guide/workfolder.html?DbPAR=SHARED">Mengubah Direktori Kerja Anda</a></li>\
    <li><a target="_top" href="id/text/shared/guide/standard_template.html?DbPAR=SHARED">Creating and Changing Default and Custom Templates</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Mendaftarkan Buku Alamat</a></li>\
    <li><a target="_top" href="id/text/shared/guide/formfields.html?DbPAR=SHARED">Menyisipkan dan Mengubah Tombol</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Bekerja dengan Antar Muka Pengguna</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navigasi ke Cepat Mencapai Objek</a></li>\
    <li><a target="_top" href="id/text/shared/guide/navigator.html?DbPAR=SHARED">Navigator untuk Tinjauan Dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/guide/autohide.html?DbPAR=SHARED">Menampilkan, Perkaitan dan Jendela</a></li>\
    <li><a target="_top" href="id/text/shared/guide/textmode_change.html?DbPAR=SHARED">Beralih antara Mode Sisip dan Mode Timpa</a></li>\
    <li><a target="_top" href="id/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Menggunakan Bilah Alat</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Tanda Tangan Digital</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Tentang Tanda Tangan Digital</a></li>\
    <li><a target="_top" href="id/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Menerapkan Tanga Tangan Digital</a></li>\
    <li><a target="_top" href="id/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">Tanda Tangan Digital Ekspor PDF</a></li>\
    <li><a target="_top" href="id/text/shared/01/timestampauth.html?DbPAR=SHARED">Time Stamp Authorities for Digital Signatures</a></li>\
    <li><a target="_top" href="id/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Menandatangani PDF yang ada</a></li>\
    <li><a target="_top" href="id/text/shared/01/addsignatureline.html?DbPAR=SHARED">Menambahkan Baris Tanda Tangan dalam Dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/01/signsignatureline.html?DbPAR=SHARED">Menandatangani Baris Tanda Tangan</a></li>\
    <li><a target="_top" href="id/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Mencetak, Mengefaks, Mengirim</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/labels_database.html?DbPAR=SHARED">Mencetak Label Alamat</a></li>\
    <li><a target="_top" href="id/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Mencetak dalam Hitam dan Putih</a></li>\
    <li><a target="_top" href="id/text/shared/guide/email.html?DbPAR=SHARED">Sending Documents as Email</a></li>\
    <li><a target="_top" href="id/text/shared/guide/fax.html?DbPAR=SHARED">Sending Faxes and Configuring LibreOffice Untuk tipe facx</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Seret & Jatuhkan</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/dragdrop.html?DbPAR=SHARED">Menyeret dan Menjatuhkan di dalam LibreOffice Dokumen</a></li>\
    <li><a target="_top" href="id/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Memindahkan dan Menyalin Teks di Dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Menyalin Wilayah Lembar Sebar ke Dokumen Teks</a></li>\
    <li><a target="_top" href="id/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Menyalin Grafik Antar Dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Menyalin Grafik Dari Galeri</a></li>\
    <li><a target="_top" href="id/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Seret-dan-Jatuhkan Dengan Tampilan Sumber Data</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Salin dan Tempel</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Menyalin Objek Gambar Ke Dalam Dokumen Lain</a></li>\
    <li><a target="_top" href="id/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Menyalin Grafik Antar Dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Menyalin Grafik Dari Galeri</a></li>\
    <li><a target="_top" href="id/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Menyalin Wilayah Lembar Sebar ke Dokumen Teks</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Bagan dan Diagram</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/chart_insert.html?DbPAR=SHARED">Memasukkan Bagan</a></li>\
    <li><a target="_top" href="id/text/schart/main0000.html?DbPAR=SHARED">Bagan dalam LibreOffice</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Muat, Simpan, Impor, Expor, PDF</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/doc_open.html?DbPAR=SHARED">Membuka dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/guide/import_ms.html?DbPAR=SHARED">Membuka dokumen yang tersimpan di format lain</a></li>\
    <li><a target="_top" href="id/text/shared/guide/doc_save.html?DbPAR=SHARED">Menyimpan Dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Penyimpanan Dokumen secara Otomatis</a></li>\
    <li><a target="_top" href="id/text/shared/guide/export_ms.html?DbPAR=SHARED">Menyimpan Dokumen dalam Format Lain</a></li>\
    <li><a target="_top" href="id/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Ekspor sebagai PDF</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Impor dan Ekspor Data di Format Teks</a></li>\
    <li><a target="_top" href="id/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Taut dan Referensi</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Menyisipkan Pranala</a></li>\
    <li><a target="_top" href="id/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Tautan Relatif dan Absolut</a></li>\
    <li><a target="_top" href="id/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Menyunting Taut</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Pelacakan Versi Dokumen</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Membandingkan Versi Dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Versi penggabungan</a></li>\
    <li><a target="_top" href="id/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Merekam Perubahan</a></li>\
    <li><a target="_top" href="id/text/shared/guide/redlining.html?DbPAR=SHARED">Merekam dan Menampilkan Perubahan</a></li>\
    <li><a target="_top" href="id/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Menerima atau Menolak Perubahan</a></li>\
    <li><a target="_top" href="id/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Versi manajemen</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Label dan Kartu Nama</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/labels.html?DbPAR=SHARED">Membuat dan Mencetak Label dan Kartu Nama</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Menyisipkan Data Luar</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/copytable2application.html?DbPAR=SHARED">Menyisipkan Data dari Lembar Sebar</a></li>\
    <li><a target="_top" href="id/text/shared/guide/copytext2application.html?DbPAR=SHARED">Menyisipkan Data Dari Dokumen Teks</a></li>\
    <li><a target="_top" href="id/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Menyisipkan, Mengubah, Menyimpan Bitmaps</a></li>\
    <li><a target="_top" href="id/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Menambahkan Grafik ke Galeri</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Fungsi Otomatis</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Mematikan Pengenalan URL Otomatis</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Mencari dan Mengganti</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/data_search2.html?DbPAR=SHARED">Mencari Dengan Formulir Penyaring</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_search.html?DbPAR=SHARED">Mencari Dokumen Tabel dan Formulir</a></li>\
    <li><a target="_top" href="id/text/shared/01/02100001.html?DbPAR=SHARED">Daftar Ekspresi Reguler</a></li>\
    </ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Panduan</label><ul>\
    <li><a target="_top" href="id/text/shared/guide/linestyles.html?DbPAR=SHARED">Menerapkan Gaya Baris</a></li>\
    <li><a target="_top" href="id/text/shared/guide/text_color.html?DbPAR=SHARED">Mengubah Warna Teks.</a></li>\
    <li><a target="_top" href="id/text/shared/guide/change_title.html?DbPAR=SHARED">Mengubah Judul Dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/guide/round_corner.html?DbPAR=SHARED">Membuat Round Corners</a></li>\
    <li><a target="_top" href="id/text/shared/guide/background.html?DbPAR=SHARED">Menentukan Warna atau Gambar Latar Belakang</a></li>\
    <li><a target="_top" href="id/text/shared/guide/palette_files.html?DbPAR=SHARED">Loading Color, Gradient, and Hatching Palettes</a></li>\
    <li><a target="_top" href="id/text/shared/guide/lineend_define.html?DbPAR=SHARED">Defining Arrow Styles</a></li>\
    <li><a target="_top" href="id/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Menentukan Gaya Garis</a></li>\
    <li><a target="_top" href="id/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Mengedit Objek Grafik</a></li>\
    <li><a target="_top" href="id/text/shared/guide/line_intext.html?DbPAR=SHARED">Menggambar Garis dalam Teks</a></li>\
    <li><a target="_top" href="id/text/shared/guide/aaa_start.html?DbPAR=SHARED">Langkah Pertama</a></li>\
    <li><a target="_top" href="id/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Menyisipkan Obyek dari Galeri</a></li>\
    <li><a target="_top" href="id/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Menyisipkan Spasi Tak-putus, Tanda Hubung dan Tanda Hubung Lembut</a></li>\
    <li><a target="_top" href="id/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Memasukkan Karakter Khusus</a></li>\
    <li><a target="_top" href="id/text/shared/guide/tabs.html?DbPAR=SHARED">Menyisipkan dan Menyunting Perhentian Tab</a></li>\
    <li><a target="_top" href="id/text/shared/guide/cmis-remote-files.html?DbPAR=SHARED">Menggunakan File Remote</a></li>\
    <li><a target="_top" href="id/text/shared/guide/protection.html?DbPAR=SHARED">Melindungi Konten di LibreOffice</a></li>\
    <li><a target="_top" href="id/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Melindungi Catatan</a></li>\
    <li><a target="_top" href="id/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Memilih Wilayah Cetak Maksimum pada Halaman</a></li>\
    <li><a target="_top" href="id/text/shared/guide/measurement_units.html?DbPAR=SHARED">Memilih Satuan Pengukuran</a></li>\
    <li><a target="_top" href="id/text/shared/guide/language_select.html?DbPAR=SHARED">Memilih Bahasa Dokumen</a></li>\
    <li><a target="_top" href="id/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Desain Tabel...</a></li>\
    <li><a target="_top" href="id/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Mematikan Peluru dan Penomoran untuk Paragraf Perorangan</a></li>\
    </ul></li>\
  </ul></li></ul>\
';
