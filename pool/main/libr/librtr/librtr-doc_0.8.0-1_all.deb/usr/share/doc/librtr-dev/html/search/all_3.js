var searchData=
[
  ['pfx_5fduplicate_5frecord_14',['PFX_DUPLICATE_RECORD',['../group__mod__pfx__h.html#ggacb1f5563c9a0bcfb6a7be631a0e8f15aa575f72a26ad782aac4720c8a25d763c1',1,'pfx.h']]],
  ['pfx_5ferror_15',['PFX_ERROR',['../group__mod__pfx__h.html#ggacb1f5563c9a0bcfb6a7be631a0e8f15aa22e5a2c063ffe08b1a02f650703631a0',1,'pfx.h']]],
  ['pfx_5ffor_5feach_5ffp_16',['pfx_for_each_fp',['../group__mod__pfx__h.html#ga48478a61dc1cd09f646631b1691ff707',1,'pfx.h']]],
  ['pfx_5frecord_17',['pfx_record',['../structpfx__record.html',1,'']]],
  ['pfx_5frecord_5fnot_5ffound_18',['PFX_RECORD_NOT_FOUND',['../group__mod__pfx__h.html#ggacb1f5563c9a0bcfb6a7be631a0e8f15aaf8b6a635062ca6ca493836c2f4d1fa03',1,'pfx.h']]],
  ['pfx_5frtvals_19',['pfx_rtvals',['../group__mod__pfx__h.html#gacb1f5563c9a0bcfb6a7be631a0e8f15a',1,'pfx.h']]],
  ['pfx_5fsuccess_20',['PFX_SUCCESS',['../group__mod__pfx__h.html#ggacb1f5563c9a0bcfb6a7be631a0e8f15aa390c4d5cd921fb06fd7548f6099c6800',1,'pfx.h']]],
  ['pfx_5ftable_21',['pfx_table',['../structpfx__table.html',1,'']]],
  ['pfx_5ftable_5fadd_22',['pfx_table_add',['../group__mod__pfx__h.html#gaae469c2eac68b697dfa4128e1c2ff792',1,'pfx.h']]],
  ['pfx_5ftable_5ffor_5feach_5fipv4_5frecord_23',['pfx_table_for_each_ipv4_record',['../group__mod__pfx__h.html#gac22895fe1d7d1de65003de76399be48d',1,'pfx.h']]],
  ['pfx_5ftable_5ffor_5feach_5fipv6_5frecord_24',['pfx_table_for_each_ipv6_record',['../group__mod__pfx__h.html#ga06d1f95df3a8952bced60588d52bc51e',1,'pfx.h']]],
  ['pfx_5ftable_5ffree_25',['pfx_table_free',['../group__mod__pfx__h.html#gaf31f339bbca6180da436a43d0bd17d10',1,'pfx.h']]],
  ['pfx_5ftable_5finit_26',['pfx_table_init',['../group__mod__pfx__h.html#ga1c2751808568eef03338a9905a0735ff',1,'pfx.h']]],
  ['pfx_5ftable_5fremove_27',['pfx_table_remove',['../group__mod__pfx__h.html#ga2f03e320b7d228e7861413b8007e8648',1,'pfx.h']]],
  ['pfx_5ftable_5fsrc_5fremove_28',['pfx_table_src_remove',['../group__mod__pfx__h.html#gabcdf5278a027b9e6e1051eb1ecfac782',1,'pfx.h']]],
  ['pfx_5ftable_5fvalidate_29',['pfx_table_validate',['../group__mod__pfx__h.html#ga24a6236cd78f9708c089793c02eb693f',1,'pfx.h']]],
  ['pfx_5ftable_5fvalidate_5fr_30',['pfx_table_validate_r',['../group__mod__pfx__h.html#gadc7e5454793c8c69724a72a14ffe0f3b',1,'pfx.h']]],
  ['pfx_5fupdate_5ffp_31',['pfx_update_fp',['../group__mod__trie__pfx__h.html#gafcc9cb0377b569f364b373c82d5d2d3c',1,'trie-pfx.h']]],
  ['pfxv_5fstate_32',['pfxv_state',['../group__mod__pfx__h.html#ga9f87b27f024a9db70884c3981e030aa0',1,'pfx.h']]],
  ['prefix_20validation_20table_33',['Prefix validation table',['../group__mod__pfx__h.html',1,'']]]
];
