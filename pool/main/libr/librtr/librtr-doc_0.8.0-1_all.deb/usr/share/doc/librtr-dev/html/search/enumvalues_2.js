var searchData=
[
  ['pfx_5fduplicate_5frecord_169',['PFX_DUPLICATE_RECORD',['../group__mod__pfx__h.html#ggacb1f5563c9a0bcfb6a7be631a0e8f15aa575f72a26ad782aac4720c8a25d763c1',1,'pfx.h']]],
  ['pfx_5ferror_170',['PFX_ERROR',['../group__mod__pfx__h.html#ggacb1f5563c9a0bcfb6a7be631a0e8f15aa22e5a2c063ffe08b1a02f650703631a0',1,'pfx.h']]],
  ['pfx_5frecord_5fnot_5ffound_171',['PFX_RECORD_NOT_FOUND',['../group__mod__pfx__h.html#ggacb1f5563c9a0bcfb6a7be631a0e8f15aaf8b6a635062ca6ca493836c2f4d1fa03',1,'pfx.h']]],
  ['pfx_5fsuccess_172',['PFX_SUCCESS',['../group__mod__pfx__h.html#ggacb1f5563c9a0bcfb6a7be631a0e8f15aa390c4d5cd921fb06fd7548f6099c6800',1,'pfx.h']]]
];
