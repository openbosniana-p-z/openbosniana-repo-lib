var searchData=
[
  ['tr_5fclosed_192',['TR_CLOSED',['../group__mod__transport__h.html#gga4493c1dcecd61a8f10a71912f29d2087a347014cc5da178db6cc3970d6e160694',1,'transport.h']]],
  ['tr_5ferror_193',['TR_ERROR',['../group__mod__transport__h.html#gga4493c1dcecd61a8f10a71912f29d2087a073c7a28c0dd674b0635178112536a2f',1,'transport.h']]],
  ['tr_5fintr_194',['TR_INTR',['../group__mod__transport__h.html#gga4493c1dcecd61a8f10a71912f29d2087a15019d7ece9eed5882a70243bbdfc0d8',1,'transport.h']]],
  ['tr_5fsuccess_195',['TR_SUCCESS',['../group__mod__transport__h.html#gga4493c1dcecd61a8f10a71912f29d2087afbed3f5722747b105d734585aa0fcba2',1,'transport.h']]],
  ['tr_5fwouldblock_196',['TR_WOULDBLOCK',['../group__mod__transport__h.html#gga4493c1dcecd61a8f10a71912f29d2087a9cb0eee91bb5e932bbe89c2f12daadb5',1,'transport.h']]]
];
