//
// Copyright RIME Developers
// Distributed under the BSD License
//
#ifndef RIME_CONFIG_H_
#define RIME_CONFIG_H_

#include <rime/config/config_component.h>
#include <rime/config/config_types.h>

#endif  // RIME_CONFIG_H_
