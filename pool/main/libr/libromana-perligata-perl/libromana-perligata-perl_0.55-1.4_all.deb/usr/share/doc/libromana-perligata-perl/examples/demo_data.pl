#!/usr/bin/perl -w
use Lingua::Romana::Perligata
# 'converte',
# 'discribe'
# 'investiga',
;

dum perlegementum nuntio fac sic             
	scribe egresso hoc.             
cis                                     
					
finis                                   
post                                    
hoc                                     
ergo                                    
propter                                 
hoc                                     
