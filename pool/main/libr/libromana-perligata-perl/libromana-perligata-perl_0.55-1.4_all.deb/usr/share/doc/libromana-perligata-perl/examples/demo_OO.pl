#!/usr/bin/perl -w
use Lingua::Romana::Perligata
# 'converte',
# 'discribe'
# 'investiga',
;

	domus Specimen.                        

	meis datis.

        newere                                      
        sic                                         
            meis datibus.                           
	    counto intra Specimen postincresce.                       
	    preincrescemento no intra Max datorum
		intra Specimen intra Max da I.
            redde datibus nullimum horum benedictum.        
        cis

        printere                                    
        sic                                         
	    meo selfo his decapitamentum da.
            modus tum indefinitus tum haec inquementum carpe. 
        cis

        domus princeps.                             

        meo objecto da newementum apud Specimen.

        I tum III printe apud objectum.
        I printe apud objectum.
	et tum cetera inquementum printe apud Specimen.
