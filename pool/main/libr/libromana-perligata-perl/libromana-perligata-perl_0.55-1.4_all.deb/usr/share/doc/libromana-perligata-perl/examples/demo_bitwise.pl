#!/usr/bin/perl -w
use Lingua::Romana::Perligata;

dum unum fac sic
	dictum sic X: cis tum lacunam egresso scribe.
	xo vestibulo perlegementum da.
	xo xum tum nullum addementum da.
	dictum sic Y: cis tum lacunam egresso scribe.
	yo vestibulo perlegementum da.
	xo xum tum nullum addementum da.
	dictum sic and: cis tum lacunam tum cum xum tum yum consociamentum
		tum novumversum scribe egresso.
	dictum sic  or: cis tum lacunam tum cum xum tum yum intersecamentum
		tum novumversum scribe egresso.
	dictum sic xor: cis tum lacunam tum cum xum tum yum discernementum
		tum novumversum scribe egresso.
cis
