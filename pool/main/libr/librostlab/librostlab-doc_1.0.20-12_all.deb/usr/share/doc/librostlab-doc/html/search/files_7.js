var searchData=
[
  ['umask_5fresource_2eh_110',['umask_resource.h',['../umask__resource_8h.html',1,'']]]
];
