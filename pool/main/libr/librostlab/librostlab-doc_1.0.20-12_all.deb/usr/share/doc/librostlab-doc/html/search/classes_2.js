var searchData=
[
  ['fasta_85',['fasta',['../classrostlab_1_1bio_1_1fmt_1_1fasta.html',1,'rostlab::bio::fmt']]],
  ['file_5flock_5fresource_86',['file_lock_resource',['../classrostlab_1_1file__lock__resource.html',1,'rostlab']]]
];
