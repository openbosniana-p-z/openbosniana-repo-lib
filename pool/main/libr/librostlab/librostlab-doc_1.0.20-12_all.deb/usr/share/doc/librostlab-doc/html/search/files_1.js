var searchData=
[
  ['blosum62_2eh_99',['blosum62.h',['../blosum62_8h.html',1,'']]]
];
