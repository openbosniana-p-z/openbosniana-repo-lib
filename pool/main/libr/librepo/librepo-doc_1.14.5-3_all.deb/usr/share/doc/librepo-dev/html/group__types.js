var group__types =
[
    [ "LR_YUM_BASEDB", "group__types.html#ga2d45e184b7dc6debfa5e73b29c66f983", null ],
    [ "LR_YUM_BASEXML", "group__types.html#ga18a495d889bf3a074e97e9ea0d8e0003", null ],
    [ "LR_YUM_FULL", "group__types.html#ga342c5f5cff5ba7a8c2546c14ce17ef49", null ],
    [ "LR_YUM_HAWKEY", "group__types.html#ga5e1109f2842114721815c5683379568e", null ],
    [ "LR_YUM_REPOMDONLY", "group__types.html#ga52612f3b7778e052273f9b880e00da06", null ],
    [ "LrEndCb", "group__types.html#ga0d348c8a5e049834cde0c225fcffa2be", null ],
    [ "LrFastestMirrorCb", "group__types.html#ga3ebeaedc0a3008ef33b10694f9c3492d", null ],
    [ "LrHandleMirrorFailureCb", "group__types.html#ga8c303f3be7e5ef047713832afe2e8897", null ],
    [ "LrMirrorFailureCb", "group__types.html#ga6f7430f38a1642a6ecb5751e65eec3f9", null ],
    [ "LrProgressCb", "group__types.html#ga73aea37e261b795084283245de2457b1", null ],
    [ "LrAuth", "group__types.html#gacbf985d77fd222f127c563e7711da35b", [
      [ "LR_AUTH_NONE", "group__types.html#ggacbf985d77fd222f127c563e7711da35ba5dbbcf4a03e0377a759bc945ab5d7dc5", null ],
      [ "LR_AUTH_BASIC", "group__types.html#ggacbf985d77fd222f127c563e7711da35ba1229a0b497e7fa4ecc4a95bc3fec3da8", null ],
      [ "LR_AUTH_DIGEST", "group__types.html#ggacbf985d77fd222f127c563e7711da35ba327ddb79d06d7c2412c34a8f850a26d1", null ],
      [ "LR_AUTH_NEGOTIATE", "group__types.html#ggacbf985d77fd222f127c563e7711da35ba1b50e10ff75cb8b017b7c65bc1a4d10e", null ],
      [ "LR_AUTH_NTLM", "group__types.html#ggacbf985d77fd222f127c563e7711da35ba02457e7775ac65e34b7f32687427a47f", null ],
      [ "LR_AUTH_DIGEST_IE", "group__types.html#ggacbf985d77fd222f127c563e7711da35baf303ca568e24188578e8bccb39018039", null ],
      [ "LR_AUTH_NTLM_WB", "group__types.html#ggacbf985d77fd222f127c563e7711da35baa5995723aeb67679551e59f250cc619a", null ],
      [ "LR_AUTH_ONLY", "group__types.html#ggacbf985d77fd222f127c563e7711da35bae7a616f9c3120fff2f10a7b85948521f", null ],
      [ "LR_AUTH_ANY", "group__types.html#ggacbf985d77fd222f127c563e7711da35ba14d3df981d228e1d7099155936cd21bd", null ]
    ] ],
    [ "LrCbReturnCode_e", "group__types.html#gac5f904cd80c91f0ad171c8dcb763cb87", [
      [ "LR_CB_OK", "group__types.html#ggac5f904cd80c91f0ad171c8dcb763cb87abd513b39d23247d9f08d43a759feadab", null ],
      [ "LR_CB_ABORT", "group__types.html#ggac5f904cd80c91f0ad171c8dcb763cb87a27c807a21d468c6100015729df563b64", null ],
      [ "LR_CB_ERROR", "group__types.html#ggac5f904cd80c91f0ad171c8dcb763cb87a513f5eef229c918544334e204cfc6299", null ]
    ] ],
    [ "LrChecks", "group__types.html#gaed13b9f5ea00c1f4469bdddb19d36f00", [
      [ "LR_CHECK_GPG", "group__types.html#ggaed13b9f5ea00c1f4469bdddb19d36f00ad84d2ba5c0600aef3908a1b55fc356ae", null ],
      [ "LR_CHECK_CHECKSUM", "group__types.html#ggaed13b9f5ea00c1f4469bdddb19d36f00ae196e88e2e3a58d7c786648464f7ac67", null ]
    ] ],
    [ "LrFastestMirrorStages", "group__types.html#ga9be6592c55a975d72709d435a7d83b6c", [
      [ "LR_FMSTAGE_INIT", "group__types.html#gga9be6592c55a975d72709d435a7d83b6caa39b235618103b66f6e022eb5dcd7786", null ],
      [ "LR_FMSTAGE_CACHELOADING", "group__types.html#gga9be6592c55a975d72709d435a7d83b6ca3cca5e86817a150fd053da97b1e100d2", null ],
      [ "LR_FMSTAGE_CACHELOADINGSTATUS", "group__types.html#gga9be6592c55a975d72709d435a7d83b6ca85da43440367032bca85a84634b896dc", null ],
      [ "LR_FMSTAGE_DETECTION", "group__types.html#gga9be6592c55a975d72709d435a7d83b6caba99e63c3246e24a543e8b20d7d20bf3", null ],
      [ "LR_FMSTAGE_FINISHING", "group__types.html#gga9be6592c55a975d72709d435a7d83b6ca74d57192f26735516ba2ce29812e2da3", null ],
      [ "LR_FMSTAGE_STATUS", "group__types.html#gga9be6592c55a975d72709d435a7d83b6ca51bc0a6ff1b687ada1f8f61d988020a5", null ]
    ] ],
    [ "LrIpResolveType", "group__types.html#ga244932bfe1c66b50a694e63680775d52", [
      [ "LR_IPRESOLVE_WHATEVER", "group__types.html#gga244932bfe1c66b50a694e63680775d52a2543004f2d57c35b26ee3ef7e5552dc9", null ],
      [ "LR_IPRESOLVE_V4", "group__types.html#gga244932bfe1c66b50a694e63680775d52a2324b3666dad2358110726b45ba62689", null ],
      [ "LR_IPRESOLVE_V6", "group__types.html#gga244932bfe1c66b50a694e63680775d52a8a4f3d11e5823b58bc167116a50d1643", null ]
    ] ],
    [ "LrProxyType", "group__types.html#gae1f6dad2c7cbbc8ef03707191d7a3f2a", [
      [ "LR_PROXY_HTTP", "group__types.html#ggae1f6dad2c7cbbc8ef03707191d7a3f2aa17b54e1a3bcb11901f78c04bc054852f", null ],
      [ "LR_PROXY_HTTP_1_0", "group__types.html#ggae1f6dad2c7cbbc8ef03707191d7a3f2aab3ef78be475a1f0ff368f5e15ff9f1a4", null ],
      [ "LR_PROXY_SOCKS4", "group__types.html#ggae1f6dad2c7cbbc8ef03707191d7a3f2aab1a0582e2ca2cd155b759862ee76146f", null ],
      [ "LR_PROXY_SOCKS5", "group__types.html#ggae1f6dad2c7cbbc8ef03707191d7a3f2aa3e71e810345ed95a3bd42e51841c6cda", null ],
      [ "LR_PROXY_SOCKS4A", "group__types.html#ggae1f6dad2c7cbbc8ef03707191d7a3f2aae2085b6c7b18f89077aa79ead0e33ded", null ],
      [ "LR_PROXY_SOCKS5_HOSTNAME", "group__types.html#ggae1f6dad2c7cbbc8ef03707191d7a3f2aa7df1d1bb18958c5eef0e5321cc058f23", null ]
    ] ],
    [ "LrRepotype", "group__types.html#gadc1faf16e4a8750d0084f1d3228f587c", [
      [ "LR_YUMREPO", "group__types.html#ggadc1faf16e4a8750d0084f1d3228f587cae08f48ce8a7df9e459de5167561d957e", null ],
      [ "LR_SUSEREPO", "group__types.html#ggadc1faf16e4a8750d0084f1d3228f587ca32b3f4543899aec5d770a11f48e814c5", null ],
      [ "LR_DEBREPO", "group__types.html#ggadc1faf16e4a8750d0084f1d3228f587ca6dded8856e2aae3db5dc566afe1868d2", null ]
    ] ],
    [ "LrTransferStatus", "group__types.html#ga02d589319488fa57e80dd56b0e06eada", null ]
];