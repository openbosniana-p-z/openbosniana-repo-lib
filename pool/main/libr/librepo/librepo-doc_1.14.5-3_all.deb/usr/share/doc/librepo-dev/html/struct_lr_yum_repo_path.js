var struct_lr_yum_repo_path =
[
    [ "path", "struct_lr_yum_repo_path.html#a44196e6a5696d10442c29e639437196e", null ],
    [ "type", "struct_lr_yum_repo_path.html#a23506fc4821ab6d9671f3e6222591a96", null ]
];