var searchData=
[
  ['url_0',['url',['../struct_lr_metalink_url.html#ab135e5154c1828bef226a3df98ee3333',1,'LrMetalinkUrl::url()'],['../struct_lr_yum_repo.html#ab135e5154c1828bef226a3df98ee3333',1,'LrYumRepo::url()']]],
  ['urls_1',['urls',['../struct_lr_metalink.html#afb6642bfbfd3b93368dfddd37e7c9dd5',1,'LrMetalink']]],
  ['use_5fzchunk_2',['use_zchunk',['../struct_lr_yum_repo.html#a1727e8c26399aedb0746f7698e62b432',1,'LrYumRepo']]],
  ['userdata_3',['userdata',['../struct_cb_data__s.html#afd0ffb02780e738d4c0a10ab833b7834',1,'CbData_s']]],
  ['utility_20functions_20and_20macros_4',['Utility functions and macros',['../group__util.html',1,'']]]
];
