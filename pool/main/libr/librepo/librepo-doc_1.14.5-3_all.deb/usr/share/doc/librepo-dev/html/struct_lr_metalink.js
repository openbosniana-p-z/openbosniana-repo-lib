var struct_lr_metalink =
[
    [ "alternates", "struct_lr_metalink.html#a84bddeb7b659a6a5cb1402679223bf0f", null ],
    [ "filename", "struct_lr_metalink.html#aeac90097f29f7529968697163cea5c18", null ],
    [ "hashes", "struct_lr_metalink.html#ae676574993cc9425158662c72e3a8a4f", null ],
    [ "size", "struct_lr_metalink.html#a1111ba0f179621a37312c9ce27dcde18", null ],
    [ "timestamp", "struct_lr_metalink.html#a9bb83d96497361faeb548a46075af5a8", null ],
    [ "urls", "struct_lr_metalink.html#afb6642bfbfd3b93368dfddd37e7c9dd5", null ]
];