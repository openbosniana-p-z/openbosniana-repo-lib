var struct_lr_var =
[
    [ "val", "struct_lr_var.html#a1d80a43cb41e5b550d4563dd10d302bc", null ],
    [ "var", "struct_lr_var.html#a7ab41949c7fcaab36a79a7418f4b6f62", null ]
];