var group__url__substitution =
[
    [ "LrVar", "struct_lr_var.html", [
      [ "val", "struct_lr_var.html#a1d80a43cb41e5b550d4563dd10d302bc", null ],
      [ "var", "struct_lr_var.html#a7ab41949c7fcaab36a79a7418f4b6f62", null ]
    ] ],
    [ "LrUrlVars", "group__url__substitution.html#gad518063673c1f221dcd73649283c39c5", null ],
    [ "lr_url_substitute", "group__url__substitution.html#gad5d37dfb54509c8d802d3a874e942b87", null ],
    [ "lr_urlvars_free", "group__url__substitution.html#ga79862b2cd30eb207a544afba2080113c", null ],
    [ "lr_urlvars_set", "group__url__substitution.html#ga180c05b3bbc4482bc3b0789da622346e", null ]
];