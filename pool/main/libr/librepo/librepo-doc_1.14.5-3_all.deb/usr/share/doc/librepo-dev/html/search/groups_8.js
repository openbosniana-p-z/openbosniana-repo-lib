var searchData=
[
  ['substitution_20of_20variables_20in_20url_0',['Substitution of variables in url',['../group__url__substitution.html',1,'']]]
];
