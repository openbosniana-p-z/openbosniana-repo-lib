var struct_lr_package_target =
[
    [ "base_url", "struct_lr_package_target.html#a20348a7f021e5548823037f53ddd7bd0", null ],
    [ "byterangeend", "struct_lr_package_target.html#ac2a1c45631efca6a187d6f4d2fa2f304", null ],
    [ "byterangestart", "struct_lr_package_target.html#ae92e9374dd5e04545489c0bb043edd26", null ],
    [ "cbdata", "struct_lr_package_target.html#aeacc5f966b497442ee824193a64b7322", null ],
    [ "checksum", "struct_lr_package_target.html#a5d9958844b3ea0a3cb642d69272b96c3", null ],
    [ "checksum_type", "struct_lr_package_target.html#ae27edc07b01983dc9d86ee0362f2d6e7", null ],
    [ "chunk", "struct_lr_package_target.html#a633d338e3452fa7079e14e7233a3f7c2", null ],
    [ "dest", "struct_lr_package_target.html#a21b0374bf8175befbde3cf5ad4831c04", null ],
    [ "endcb", "struct_lr_package_target.html#a76605c0917e1bd9d1ab9c22d170666f5", null ],
    [ "err", "struct_lr_package_target.html#a838a5b5da6ce426d8ff53c3031ebcd0f", null ],
    [ "expectedsize", "struct_lr_package_target.html#ac099d0c6c9bd6a29ad7b5f700f15351c", null ],
    [ "handle", "struct_lr_package_target.html#a53bfe16fb68d2773d6305bae6ba2b3ec", null ],
    [ "local_path", "struct_lr_package_target.html#ab0a494e2b70de2fefd96b3d9927a9687", null ],
    [ "mirrorfailurecb", "struct_lr_package_target.html#a94349dd7a03713fbbfa1f17bebc24a75", null ],
    [ "progresscb", "struct_lr_package_target.html#aed766179d6978e5563052a865478f90c", null ],
    [ "relative_url", "struct_lr_package_target.html#a16b6bfa7718e3ab847b69798ac7d2dde", null ],
    [ "resume", "struct_lr_package_target.html#a3c9a2377c7fc433bbd6b0cb4827097ba", null ]
];