var group__util =
[
    [ "LR_CURL_VERSION_CHECK", "group__util.html#gac024aac0a45e08b2ea5d334091aa2622", null ],
    [ "lr_best_checksum", "group__util.html#ga567cd355cbeb6e54bd6147512ad93428", null ],
    [ "lr_copy_content", "group__util.html#gaeb7b755980392a121ec7d1cb23ddaa02", null ],
    [ "lr_free", "group__util.html#ga91ece618173ddd19865b0935449edb24", null ],
    [ "lr_gettmpdir", "group__util.html#ga8bc760f153f0ae20fd55d2ab2a75def0", null ],
    [ "lr_gettmpfile", "group__util.html#ga6bf4f9e4c9e5d304caccb710a3e2eabf", null ],
    [ "lr_global_init", "group__util.html#ga3a8f3d0bfc72e9843e626798bb65274e", null ],
    [ "lr_is_local_path", "group__util.html#gacf9300744ece14a17689a7c4997d0fa7", null ],
    [ "lr_key_file_save_to_file", "group__util.html#ga41d4eb7bc345f6c8c6aedb416ab9d86e", null ],
    [ "lr_log_librepo_summary", "group__util.html#gad57be9f3b6fe1a983507ccaa255ad93f", null ],
    [ "lr_malloc", "group__util.html#ga9efe7eb5e467efa91d761a6f7557b9c7", null ],
    [ "lr_malloc0", "group__util.html#ga03d1d0adeaaec7544b6db993b304798f", null ],
    [ "lr_out_of_memory", "group__util.html#ga49799e3502e5c984f1b38b74da1e7c6c", null ],
    [ "lr_pathconcat", "group__util.html#gaff877c23c30d3c1aee30dfa1e58a985f", null ],
    [ "lr_prepend_url_protocol", "group__util.html#gae15be4a862d9608b77e38f09a741c700", null ],
    [ "lr_realloc", "group__util.html#ga480f31e5f9781c70bc7ef104194fb896", null ],
    [ "lr_remove_dir", "group__util.html#ga641b7d62b8f44eefe164a8107052dee5", null ],
    [ "lr_string_chunk_insert", "group__util.html#ga2103b60738876288c27ab09644189b61", null ],
    [ "lr_strv_dup", "group__util.html#ga63ff30eeb50f9540a028b3441aa6e52d", null ],
    [ "lr_url_without_path", "group__util.html#gabbba3cf91f0e24b5bc4ff4a19f1981c9", null ],
    [ "lr_xml_parser_warning_logger", "group__util.html#ga4897c23f6a8e957810118816bc17e1aa", null ]
];