var searchData=
[
  ['gpg_20signature_20verification_0',['GPG signature verification',['../group__gpg.html',1,'']]]
];
