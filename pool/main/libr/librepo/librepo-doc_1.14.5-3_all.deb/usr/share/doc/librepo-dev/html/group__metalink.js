var group__metalink =
[
    [ "LrMetalinkHash", "struct_lr_metalink_hash.html", [
      [ "type", "struct_lr_metalink_hash.html#a23506fc4821ab6d9671f3e6222591a96", null ],
      [ "value", "struct_lr_metalink_hash.html#a4e9aec275e566b978a3ccb4e043d8c61", null ]
    ] ],
    [ "LrMetalinkUrl", "struct_lr_metalink_url.html", [
      [ "location", "struct_lr_metalink_url.html#a6a0d5603410d5eda93c0ff341966cce1", null ],
      [ "preference", "struct_lr_metalink_url.html#af151bd446b2746614fe5b1e863b79960", null ],
      [ "protocol", "struct_lr_metalink_url.html#adadace6756d999cbf32a3aceea744df2", null ],
      [ "type", "struct_lr_metalink_url.html#a23506fc4821ab6d9671f3e6222591a96", null ],
      [ "url", "struct_lr_metalink_url.html#ab135e5154c1828bef226a3df98ee3333", null ]
    ] ],
    [ "LrMetalinkAlternate", "struct_lr_metalink_alternate.html", [
      [ "hashes", "struct_lr_metalink_alternate.html#ae676574993cc9425158662c72e3a8a4f", null ],
      [ "size", "struct_lr_metalink_alternate.html#a1111ba0f179621a37312c9ce27dcde18", null ],
      [ "timestamp", "struct_lr_metalink_alternate.html#a9bb83d96497361faeb548a46075af5a8", null ]
    ] ],
    [ "LrMetalink", "struct_lr_metalink.html", [
      [ "alternates", "struct_lr_metalink.html#a84bddeb7b659a6a5cb1402679223bf0f", null ],
      [ "filename", "struct_lr_metalink.html#aeac90097f29f7529968697163cea5c18", null ],
      [ "hashes", "struct_lr_metalink.html#ae676574993cc9425158662c72e3a8a4f", null ],
      [ "size", "struct_lr_metalink.html#a1111ba0f179621a37312c9ce27dcde18", null ],
      [ "timestamp", "struct_lr_metalink.html#a9bb83d96497361faeb548a46075af5a8", null ],
      [ "urls", "struct_lr_metalink.html#afb6642bfbfd3b93368dfddd37e7c9dd5", null ]
    ] ],
    [ "lr_metalink_free", "group__metalink.html#ga01737af57ae240d82aec2aab5354ebf7", null ],
    [ "lr_metalink_init", "group__metalink.html#ga918a33347041036f1695008e78aada78", null ],
    [ "lr_metalink_parse_file", "group__metalink.html#gac7995ccd4220709efd64cca06dfb77eb", null ]
];