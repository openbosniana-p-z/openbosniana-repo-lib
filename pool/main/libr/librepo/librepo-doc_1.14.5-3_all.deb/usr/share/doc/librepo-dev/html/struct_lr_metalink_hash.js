var struct_lr_metalink_hash =
[
    [ "type", "struct_lr_metalink_hash.html#a23506fc4821ab6d9671f3e6222591a96", null ],
    [ "value", "struct_lr_metalink_hash.html#a4e9aec275e566b978a3ccb4e043d8c61", null ]
];