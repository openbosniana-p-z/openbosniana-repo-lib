var struct_lr_yum_repo =
[
    [ "destdir", "struct_lr_yum_repo.html#a5a87bd483fb8895b6183267bb19de614", null ],
    [ "metalink", "struct_lr_yum_repo.html#a70f4a65bd0e7c84b40f405d3744e3afa", null ],
    [ "mirrorlist", "struct_lr_yum_repo.html#afd548bd331f4222b6d360c682c95104c", null ],
    [ "paths", "struct_lr_yum_repo.html#a0d38d90116670b2723466547a9ee0055", null ],
    [ "repomd", "struct_lr_yum_repo.html#a9fe557c75081378626373b01c6915248", null ],
    [ "signature", "struct_lr_yum_repo.html#a671b803cae38ef222103cb0e1c7aba8a", null ],
    [ "url", "struct_lr_yum_repo.html#ab135e5154c1828bef226a3df98ee3333", null ],
    [ "use_zchunk", "struct_lr_yum_repo.html#a1727e8c26399aedb0746f7698e62b432", null ]
];