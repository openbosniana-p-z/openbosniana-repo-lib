var struct_lr_metalink_alternate =
[
    [ "hashes", "struct_lr_metalink_alternate.html#ae676574993cc9425158662c72e3a8a4f", null ],
    [ "size", "struct_lr_metalink_alternate.html#a1111ba0f179621a37312c9ce27dcde18", null ],
    [ "timestamp", "struct_lr_metalink_alternate.html#a9bb83d96497361faeb548a46075af5a8", null ]
];