var group__version =
[
    [ "LR_VERSION", "group__version.html#ga45d9d4d47e9436dd3984bb2a9a00886e", null ],
    [ "LR_VERSION_CHECK", "group__version.html#ga48682a37f1d95b221912724cd51551e6", null ],
    [ "LR_VERSION_MAJOR", "group__version.html#ga334f61b2ae7f0d705669c98e22b4c461", null ],
    [ "LR_VERSION_MINOR", "group__version.html#gaddfb150229837a6abef5a9ce4f93360b", null ],
    [ "LR_VERSION_PATCH", "group__version.html#ga1b9afa9b13321745b535b2a58278ee82", null ]
];