var modules =
[
    [ "Checksum calculation and checking", "group__checksum.html", "group__checksum" ],
    [ "GPG signature verification", "group__gpg.html", "group__gpg" ],
    [ "Librepo Handle", "group__handle.html", "group__handle" ],
    [ "Metalink parser", "group__metalink.html", "group__metalink" ],
    [ "Package downloading", "group__package__downloader.html", "group__package__downloader" ],
    [ "Error/Return codes", "group__rcodes.html", "group__rcodes" ],
    [ "Repomd (repomd.xml) parser", "group__repomd.html", "group__repomd" ],
    [ "Yum repo high level function", "group__repoutil__yum.html", "group__repoutil__yum" ],
    [ "Result object", "group__result.html", "group__result" ],
    [ "Basic types and constants", "group__types.html", "group__types" ],
    [ "Substitution of variables in url", "group__url__substitution.html", "group__url__substitution" ],
    [ "Utility functions and macros", "group__util.html", "group__util" ],
    [ "Library version constatnts and check macros", "group__version.html", "group__version" ],
    [ "Common stuff for XML parsers in Librepo (datatypes, etc.)", "group__xmlparser.html", "group__xmlparser" ],
    [ "Yum repo manipulation", "group__yum.html", "group__yum" ]
];