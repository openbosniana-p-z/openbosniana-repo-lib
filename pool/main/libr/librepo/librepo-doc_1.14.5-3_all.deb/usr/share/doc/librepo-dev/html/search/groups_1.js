var searchData=
[
  ['checksum_20calculation_20and_20checking_0',['Checksum calculation and checking',['../group__checksum.html',1,'']]],
  ['common_20stuff_20for_20xml_20parsers_20in_20librepo_20_28datatypes_2c_20etc_2e_29_1',['Common stuff for XML parsers in Librepo (datatypes, etc.)',['../group__xmlparser.html',1,'']]]
];
