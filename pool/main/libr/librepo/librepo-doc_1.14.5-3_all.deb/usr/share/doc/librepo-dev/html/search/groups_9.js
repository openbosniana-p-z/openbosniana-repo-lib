var searchData=
[
  ['utility_20functions_20and_20macros_0',['Utility functions and macros',['../group__util.html',1,'']]]
];
