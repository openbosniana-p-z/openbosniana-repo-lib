var searchData=
[
  ['library_20version_20constatnts_20and_20check_20macros_0',['Library version constatnts and check macros',['../group__version.html',1,'']]],
  ['librepo_20handle_1',['Librepo Handle',['../group__handle.html',1,'']]]
];
