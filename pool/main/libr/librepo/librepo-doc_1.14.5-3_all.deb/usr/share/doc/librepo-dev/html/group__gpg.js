var group__gpg =
[
    [ "lr_gpg_check_signature", "group__gpg.html#gaee11f6e9ded3239705247118a1a56e97", null ],
    [ "lr_gpg_check_signature_fd", "group__gpg.html#ga3613da4b7285bd7b71ab55b8577f4d28", null ],
    [ "lr_gpg_import_key", "group__gpg.html#gaf401aea646014f8b9ae40ad666857257", null ]
];