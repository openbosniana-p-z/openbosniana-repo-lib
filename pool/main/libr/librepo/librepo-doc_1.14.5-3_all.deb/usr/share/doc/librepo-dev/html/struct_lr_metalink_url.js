var struct_lr_metalink_url =
[
    [ "location", "struct_lr_metalink_url.html#a6a0d5603410d5eda93c0ff341966cce1", null ],
    [ "preference", "struct_lr_metalink_url.html#af151bd446b2746614fe5b1e863b79960", null ],
    [ "protocol", "struct_lr_metalink_url.html#adadace6756d999cbf32a3aceea744df2", null ],
    [ "type", "struct_lr_metalink_url.html#a23506fc4821ab6d9671f3e6222591a96", null ],
    [ "url", "struct_lr_metalink_url.html#ab135e5154c1828bef226a3df98ee3333", null ]
];