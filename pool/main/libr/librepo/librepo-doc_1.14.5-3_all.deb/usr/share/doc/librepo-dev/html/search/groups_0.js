var searchData=
[
  ['basic_20types_20and_20constants_0',['Basic types and constants',['../group__types.html',1,'']]]
];
