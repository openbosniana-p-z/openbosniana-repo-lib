var group__xmlparser =
[
    [ "LR_CB_RET_ERR", "group__xmlparser.html#ga611497504566c9d4e03c5ae8ca40c2f4", null ],
    [ "LR_CB_RET_OK", "group__xmlparser.html#ga24f8dcceb9c66375c33e8f0b98704489", null ],
    [ "LrXmlParserWarningCb", "group__xmlparser.html#ga889b606d9f2539ade0130029cf06d462", null ],
    [ "LrXmlParserWarningType", "group__xmlparser.html#ga2a7e8661f6017ed102544cb7425753b0", [
      [ "LR_XML_WARNING_UNKNOWNTAG", "group__xmlparser.html#gga2a7e8661f6017ed102544cb7425753b0acd2807250441b2803eaa262fa1e19148", null ],
      [ "LR_XML_WARNING_MISSINGATTR", "group__xmlparser.html#gga2a7e8661f6017ed102544cb7425753b0a7b7076923a6d3a0ce5730245c4b64fda", null ],
      [ "LR_XML_WARNING_UNKNOWNVAL", "group__xmlparser.html#gga2a7e8661f6017ed102544cb7425753b0ab8993e2a3e965f5a2f81a032d7d62bfa", null ],
      [ "LR_XML_WARNING_BADATTRVAL", "group__xmlparser.html#gga2a7e8661f6017ed102544cb7425753b0a950f25acf075ae7565c82827682e461e", null ],
      [ "LR_XML_WARNING_MISSINGVAL", "group__xmlparser.html#gga2a7e8661f6017ed102544cb7425753b0aeb52c23ce9ee92041f5ded6c1c355ccb", null ]
    ] ]
];