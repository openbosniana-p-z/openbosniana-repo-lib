var group__yum =
[
    [ "LrYumRepoPath", "struct_lr_yum_repo_path.html", [
      [ "path", "struct_lr_yum_repo_path.html#a44196e6a5696d10442c29e639437196e", null ],
      [ "type", "struct_lr_yum_repo_path.html#a23506fc4821ab6d9671f3e6222591a96", null ]
    ] ],
    [ "LrYumRepo", "struct_lr_yum_repo.html", [
      [ "destdir", "struct_lr_yum_repo.html#a5a87bd483fb8895b6183267bb19de614", null ],
      [ "metalink", "struct_lr_yum_repo.html#a70f4a65bd0e7c84b40f405d3744e3afa", null ],
      [ "mirrorlist", "struct_lr_yum_repo.html#afd548bd331f4222b6d360c682c95104c", null ],
      [ "paths", "struct_lr_yum_repo.html#a0d38d90116670b2723466547a9ee0055", null ],
      [ "repomd", "struct_lr_yum_repo.html#a9fe557c75081378626373b01c6915248", null ],
      [ "signature", "struct_lr_yum_repo.html#a671b803cae38ef222103cb0e1c7aba8a", null ],
      [ "url", "struct_lr_yum_repo.html#ab135e5154c1828bef226a3df98ee3333", null ],
      [ "use_zchunk", "struct_lr_yum_repo.html#a1727e8c26399aedb0746f7698e62b432", null ]
    ] ],
    [ "CbData_s", "struct_cb_data__s.html", [
      [ "cbdata", "struct_cb_data__s.html#aeacc5f966b497442ee824193a64b7322", null ],
      [ "hmfcb", "struct_cb_data__s.html#ac3238a2790a73ecd3af10aee22de3d6e", null ],
      [ "metadata", "struct_cb_data__s.html#ace70beae1a71187d5961a8d7c0dafb7b", null ],
      [ "progresscb", "struct_cb_data__s.html#aed766179d6978e5563052a865478f90c", null ],
      [ "userdata", "struct_cb_data__s.html#afd0ffb02780e738d4c0a10ab833b7834", null ]
    ] ],
    [ "CbData", "group__yum.html#gae5b00260ddb3ee99e5ce1c9150895938", null ],
    [ "hmfcb", "group__yum.html#ga88aba7f0a8823cca2e6f63ff2309d277", null ],
    [ "lr_copy_metalink_content", "group__yum.html#gaa4bc6fbb629bbdc4bcbf5eb8cfdd1677", null ],
    [ "lr_get_best_checksum", "group__yum.html#ga09e29138c35e56c0579301d782e55903", null ],
    [ "lr_get_metadata_failure_callback", "group__yum.html#ga418522985c268a38d8802d5511479b93", null ],
    [ "lr_prepare_repodata_dir", "group__yum.html#ga8a8a9d2e7fe58c3fc72af292e847cb5d", null ],
    [ "lr_prepare_repomd_xml_file", "group__yum.html#ga352d5f4430340a4fa6b9712c0f484151", null ],
    [ "lr_store_mirrorlist_files", "group__yum.html#ga0b99de6426f035507f65b989e76db681", null ],
    [ "lr_yum_download_repos", "group__yum.html#gaa94bab3f6b0c9440475ab7ab9af8712e", null ],
    [ "lr_yum_repo_free", "group__yum.html#gaa3d997c77120e70ce51e382f0466ce79", null ],
    [ "lr_yum_repo_init", "group__yum.html#ga692b6ae7fe32570c3d1a6544f8998bb4", null ],
    [ "lr_yum_repo_path", "group__yum.html#ga4dc490579b35dcfb4628dcffed44f290", null ]
];