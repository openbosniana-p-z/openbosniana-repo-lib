var group__result =
[
    [ "LrResult", "group__result.html#gadef5849192cc74a3c0a3c537695672de", null ],
    [ "LrResultInfoOption", "group__result.html#ga28035d5ee9daaaffea018d358c6a296b", [
      [ "LRR_YUM_REPO", "group__result.html#gga28035d5ee9daaaffea018d358c6a296bae6cdd49e0bcc590b09ce037d3239f955", null ],
      [ "LRR_YUM_REPOMD", "group__result.html#gga28035d5ee9daaaffea018d358c6a296ba8f9bfc17204812a9ae4006cf1dc946a1", null ],
      [ "LRR_YUM_TIMESTAMP", "group__result.html#gga28035d5ee9daaaffea018d358c6a296ba12510c32a7c54a3b0c872318c4290bb2", null ],
      [ "LRR_RPMMD_REPO", "group__result.html#gga28035d5ee9daaaffea018d358c6a296ba0a739d633dc6061e4cb9d12fdcc482c1", null ],
      [ "LRR_RPMMD_REPOMD", "group__result.html#gga28035d5ee9daaaffea018d358c6a296ba805e39ab780b1a34a033d8297d47f87d", null ],
      [ "LRR_RPMMD_TIMESTAMP", "group__result.html#gga28035d5ee9daaaffea018d358c6a296ba8ff3ac4b9603bb6405d4c148a667f8b4", null ]
    ] ],
    [ "lr_result_clear", "group__result.html#ga051af0f1842ac073fffdc3e9f90315e6", null ],
    [ "lr_result_free", "group__result.html#ga24b1b6acc22776a2ec3d68f061542210", null ],
    [ "lr_result_getinfo", "group__result.html#ga77a4f921988fc923224634123fc56554", null ],
    [ "lr_result_init", "group__result.html#gab60b5fb96875daa832cc3bdb15d29d0f", null ]
];