var struct_lr_yum_distro_tag =
[
    [ "cpeid", "struct_lr_yum_distro_tag.html#ad39aee156ba30d27bb9e2c50159b2256", null ],
    [ "tag", "struct_lr_yum_distro_tag.html#a7bb5e40c10df6a41df64bda1f4bb3e26", null ]
];