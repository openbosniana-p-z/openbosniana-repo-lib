/**************************************************************************\
 ibtk (Insomnia's Basic ToolKit)

  By Insomnia (Steaphan Greene)
  (insomnia@core.binghamton.edu)

  Copyright (C) 1999 Steaphan Greene

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111, USA.

\**************************************************************************/

#ifndef ILISTBOX_H
#define ILISTBOX_H

#include <X11/X.h>   
#include <X11/Xlib.h>
#include "idodad.h"
#include "iwindow.h"
#include <time.h>

class IListBox : public IDoDad  {
public:
  IListBox(char **txt, int n, IWindow *w, int xp, int yp, int xs, int ys);
  virtual ~IListBox();
  virtual int Type()  { return DODAD_LISTBOX; };
  virtual void Redraw();
  virtual void Rebuild();
  virtual int Press(int b, int x, int y);
  virtual int Release(int b, int x, int y);
  char *GetSelection(int n) { return text[sel[n]]; };
  int SelNum(int n) { return sel[n]; };
  int NumSelections();
  void SetDCCallback(void (*cb)(IDoDad *, IDoDad *, int));
  void SetSelCallback(void (*cb)(IDoDad *, IDoDad *, int));
  void SetDeselCallback(void (*cb)(IDoDad *, IDoDad *, int));
  void Select(int);
protected:
  IListBox() {};
  void Init(char **txt, int n, IWindow *w, int xp, int yp, int xs, int ys);
  Pixmap Img, *Wrk;
  int *wx, *wy;
  int xpos, ypos, xsize, ysize;
  int nent, dy, lines;
  int *sel, selmax, selmin;
  char **text;
  time_t lastclick;
  void (*dccallback)(IDoDad *, IDoDad *, int);
  void (*selcallback)(IDoDad *, IDoDad *, int);
  void (*deselcallback)(IDoDad *, IDoDad *, int);
  };

#endif
