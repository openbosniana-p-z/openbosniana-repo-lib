/**************************************************************************\
 ibtk (Insomnia's Basic ToolKit)

  By Insomnia (Steaphan Greene)
  (insomnia@core.binghamton.edu)

  Copyright (C) 1999 Steaphan Greene

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111, USA.

\**************************************************************************/
#ifndef IVERSION_H
#define IVERSION_H

#ifdef __cplusplus
extern "C" {
#endif


#define IBTK_MAJOR_VERSION       0
#define IBTK_MINOR_VERSION       0
#define IBTK_SUB_VERSION         14
#define IBTK_PRE_VERSION         0
#define IBTK_VERSION_STRING      "0.0.14"
#define IBTK_FULL_VERSION_STRING "0.0.14"

char *get_ibtk_version(void);
char *get_ibtk_version_string(void);
char *get_ibtk_full_version_string(void);
int ibtk_required_version(char*);

#ifdef __cplusplus
}
#endif


#endif
