package
Boo;

$Boo::VERSION = '2.01';

sub boo {
  return "Hello from Boo";
}

1;
