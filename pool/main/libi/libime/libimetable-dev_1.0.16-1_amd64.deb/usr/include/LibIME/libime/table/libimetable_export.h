
#ifndef LIBIMETABLE_EXPORT_H
#define LIBIMETABLE_EXPORT_H

#ifdef LIBIMETABLE_STATIC_DEFINE
#  define LIBIMETABLE_EXPORT
#  define LIBIMETABLE_NO_EXPORT
#else
#  ifndef LIBIMETABLE_EXPORT
#    ifdef IMETable_EXPORTS
        /* We are building this library */
#      define LIBIMETABLE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBIMETABLE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBIMETABLE_NO_EXPORT
#    define LIBIMETABLE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBIMETABLE_DEPRECATED
#  define LIBIMETABLE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBIMETABLE_DEPRECATED_EXPORT
#  define LIBIMETABLE_DEPRECATED_EXPORT LIBIMETABLE_EXPORT LIBIMETABLE_DEPRECATED
#endif

#ifndef LIBIMETABLE_DEPRECATED_NO_EXPORT
#  define LIBIMETABLE_DEPRECATED_NO_EXPORT LIBIMETABLE_NO_EXPORT LIBIMETABLE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBIMETABLE_NO_DEPRECATED
#    define LIBIMETABLE_NO_DEPRECATED
#  endif
#endif

#endif /* LIBIMETABLE_EXPORT_H */
