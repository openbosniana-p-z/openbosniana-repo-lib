
#ifndef LIBIMECORE_EXPORT_H
#define LIBIMECORE_EXPORT_H

#ifdef LIBIMECORE_STATIC_DEFINE
#  define LIBIMECORE_EXPORT
#  define LIBIMECORE_NO_EXPORT
#else
#  ifndef LIBIMECORE_EXPORT
#    ifdef IMECore_EXPORTS
        /* We are building this library */
#      define LIBIMECORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBIMECORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBIMECORE_NO_EXPORT
#    define LIBIMECORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBIMECORE_DEPRECATED
#  define LIBIMECORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBIMECORE_DEPRECATED_EXPORT
#  define LIBIMECORE_DEPRECATED_EXPORT LIBIMECORE_EXPORT LIBIMECORE_DEPRECATED
#endif

#ifndef LIBIMECORE_DEPRECATED_NO_EXPORT
#  define LIBIMECORE_DEPRECATED_NO_EXPORT LIBIMECORE_NO_EXPORT LIBIMECORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBIMECORE_NO_DEPRECATED
#    define LIBIMECORE_NO_DEPRECATED
#  endif
#endif

#endif /* LIBIMECORE_EXPORT_H */
