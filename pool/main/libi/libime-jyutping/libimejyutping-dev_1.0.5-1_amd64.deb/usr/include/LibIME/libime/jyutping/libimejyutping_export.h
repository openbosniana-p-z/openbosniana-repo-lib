
#ifndef LIBIMEJYUTPING_EXPORT_H
#define LIBIMEJYUTPING_EXPORT_H

#ifdef LIBIMEJYUTPING_STATIC_DEFINE
#  define LIBIMEJYUTPING_EXPORT
#  define LIBIMEJYUTPING_NO_EXPORT
#else
#  ifndef LIBIMEJYUTPING_EXPORT
#    ifdef IMEJyutping_EXPORTS
        /* We are building this library */
#      define LIBIMEJYUTPING_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBIMEJYUTPING_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBIMEJYUTPING_NO_EXPORT
#    define LIBIMEJYUTPING_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBIMEJYUTPING_DEPRECATED
#  define LIBIMEJYUTPING_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBIMEJYUTPING_DEPRECATED_EXPORT
#  define LIBIMEJYUTPING_DEPRECATED_EXPORT LIBIMEJYUTPING_EXPORT LIBIMEJYUTPING_DEPRECATED
#endif

#ifndef LIBIMEJYUTPING_DEPRECATED_NO_EXPORT
#  define LIBIMEJYUTPING_DEPRECATED_NO_EXPORT LIBIMEJYUTPING_NO_EXPORT LIBIMEJYUTPING_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBIMEJYUTPING_NO_DEPRECATED
#    define LIBIMEJYUTPING_NO_DEPRECATED
#  endif
#endif

#endif /* LIBIMEJYUTPING_EXPORT_H */
