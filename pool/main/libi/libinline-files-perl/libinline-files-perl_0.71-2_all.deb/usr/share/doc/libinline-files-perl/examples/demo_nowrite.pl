use Inline::Files;

print VIRTUAL "This shouldn't work";

__VIRTUAL__
This should be inviolate
