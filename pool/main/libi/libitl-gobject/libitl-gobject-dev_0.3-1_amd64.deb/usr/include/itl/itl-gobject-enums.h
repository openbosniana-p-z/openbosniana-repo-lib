
/* Generated data (by glib-mkenums) */

#if !defined(ITL_GOBJECT_INSIDE) && !defined(ITL_GOBJECT_COMPILATION)
#error "Only <st/st.h> can be included directly.h"
#endif

#ifndef __ST_ENUM_TYPES_H__
#define __ST_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS
/* enumerations from "itl-gobject.h" */
GType itl_mathhab_get_type (void) G_GNUC_CONST;
#define ITL_TYPE_MATHHAB (itl_mathhab_get_type())
GType itl_round_method_get_type (void) G_GNUC_CONST;
#define ITL_TYPE_ROUND_METHOD (itl_round_method_get_type())
GType itl_method_get_type (void) G_GNUC_CONST;
#define ITL_TYPE_METHOD (itl_method_get_type())
GType itl_extreme_method_get_type (void) G_GNUC_CONST;
#define ITL_TYPE_EXTREME_METHOD (itl_extreme_method_get_type())
G_END_DECLS

#endif /* !__ST_ENUM_TYPES_H__ */

/* Generated data ends here */

