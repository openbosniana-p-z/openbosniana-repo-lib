#ifndef __RESOURCE__inf_gtk_H__
#define __RESOURCE__inf_gtk_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *_inf_gtk_get_resource (void);
#endif
