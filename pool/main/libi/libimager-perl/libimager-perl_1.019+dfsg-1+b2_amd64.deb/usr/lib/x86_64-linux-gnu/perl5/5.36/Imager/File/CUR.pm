package Imager::File::CUR;
use 5.006;
use strict;
our $VERSION = "1.000";

# all the work is done by Imager::File::ICO
use Imager::File::ICO;

1;
