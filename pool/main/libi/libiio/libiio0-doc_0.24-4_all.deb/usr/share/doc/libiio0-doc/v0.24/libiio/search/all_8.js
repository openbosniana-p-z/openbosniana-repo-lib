var searchData=
[
  ['scale_0',['scale',['../structiio__data__format.html#a55125a0f81f90be70428076b426f50e2',1,'iio_data_format']]],
  ['shift_1',['shift',['../structiio__data__format.html#ab56ee226f46a755a6745e08d9d934804',1,'iio_data_format']]]
];
