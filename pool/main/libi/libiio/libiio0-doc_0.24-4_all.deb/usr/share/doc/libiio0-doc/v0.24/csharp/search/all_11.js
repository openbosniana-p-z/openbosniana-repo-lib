var searchData=
[
  ['write_0',['write',['../classiio_1_1Attr.html#a3f36d81a93bd2266e5303e9e8c41dfdc',1,'iio.Attr.write(string val)'],['../classiio_1_1Attr.html#afc52dcef6eae8b3cc85426cceec74a37',1,'iio.Attr.write(bool val)'],['../classiio_1_1Attr.html#aeeaf6279e288303bd38e1cd1e23fd7d0',1,'iio.Attr.write(long val)'],['../classiio_1_1Attr.html#a58573a3615314d89e2110fa85f4c5e80',1,'iio.Attr.write(double val)'],['../classiio_1_1Channel.html#a7eda7ca0cbf91d49d52d7ea8bef0151c',1,'iio.Channel.write()']]]
];
