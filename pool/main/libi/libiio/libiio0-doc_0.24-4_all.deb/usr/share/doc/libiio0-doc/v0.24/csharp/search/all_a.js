var searchData=
[
  ['modifier_0',['modifier',['../classiio_1_1Channel.html#ade4aa6fcb830ef383db4695e8b65ade0',1,'iio::Channel']]]
];
