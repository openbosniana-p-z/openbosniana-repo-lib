var classiio_1_1Device =
[
    [ "find_attribute", "classiio_1_1Device.html#a896da3d065f48f2629caa500a73e91ff", null ],
    [ "find_buffer_attribute", "classiio_1_1Device.html#a03130c752e898b7fb81706ed82207639", null ],
    [ "find_channel", "classiio_1_1Device.html#a1984d9df28ff05c5171f77f4d84c01f0", null ],
    [ "find_debug_attribute", "classiio_1_1Device.html#a8cf4d34965b05de495857a8e5f29e6f4", null ],
    [ "get_channel", "classiio_1_1Device.html#ab7f441c0264fa93c34106df969221d89", null ],
    [ "get_context", "classiio_1_1Device.html#aecb809422163d179c3b501bbadaa1ae7", null ],
    [ "get_sample_size", "classiio_1_1Device.html#a8fcf659b560ffae54b8e5e3181d7988f", null ],
    [ "get_trigger", "classiio_1_1Device.html#a0d6bcb4c98aa71895c5c9476bb2e7285", null ],
    [ "identify_filename", "classiio_1_1Device.html#ac68bcd5fa0278c23f2db0d7e35a28dce", null ],
    [ "reg_read", "classiio_1_1Device.html#a2b67eb64e1094bca59468f177f6c039e", null ],
    [ "reg_write", "classiio_1_1Device.html#aa02e1587a188ed02956a033b488576d1", null ],
    [ "set_kernel_buffers_count", "classiio_1_1Device.html#a9005ab45349aa4c98a6717847001d6fd", null ],
    [ "set_trigger", "classiio_1_1Device.html#a5cf653e285c685648dfc66a5119595d4", null ],
    [ "attrs", "classiio_1_1Device.html#ae2176fa2b6259f9c120a825f518c4066", null ],
    [ "channels", "classiio_1_1Device.html#a060ce06a0516ccc7468196e44fb30b00", null ],
    [ "debug_attrs", "classiio_1_1Device.html#aef585bea3015cda66fbce397d0323794", null ],
    [ "id", "classiio_1_1Device.html#a5d206eae4628dc18fdfac1e515674cdc", null ],
    [ "name", "classiio_1_1Device.html#ab1cd5f216aed88ebe52f17556a4488f0", null ],
    [ "buffer_attrs", "classiio_1_1Device.html#af886c74c8e341cb7140ba9474dbd2340", null ],
    [ "hwmon", "classiio_1_1Device.html#a0c8992763f1c21715d03775a0e37321e", null ],
    [ "label", "classiio_1_1Device.html#a3342153fd26e43b710dd33b17cb126fc", null ]
];