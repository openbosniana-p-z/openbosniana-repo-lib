var group__Context =
[
    [ "iio_context", "structiio__context.html", null ],
    [ "iio_context_clone", "group__Context.html#ga66a50315a009eaffdd713343917174b2", null ],
    [ "iio_context_destroy", "group__Context.html#ga75de8dae515c539818e52b408830d3ba", null ],
    [ "iio_context_find_device", "group__Context.html#ga1064109f031d8fff82ac1149a4db3096", null ],
    [ "iio_context_get_attr", "group__Context.html#ga477dfddaefe0acda401f600247e13fc7", null ],
    [ "iio_context_get_attr_value", "group__Context.html#gaea89eda9bb3353806da493721db0d8b7", null ],
    [ "iio_context_get_attrs_count", "group__Context.html#ga91e0c4ed91d760b411d4cbea28c993da", null ],
    [ "iio_context_get_description", "group__Context.html#ga066ade48426ec4e31a57fa6d0dc1e6a3", null ],
    [ "iio_context_get_device", "group__Context.html#ga87dc44c9f69b4a9ecdb9133d686447ee", null ],
    [ "iio_context_get_devices_count", "group__Context.html#gab4fc2a93fd5824f3c9e06aa81e8097d1", null ],
    [ "iio_context_get_name", "group__Context.html#gab615489ef6bd068f15de2f338f712019", null ],
    [ "iio_context_get_version", "group__Context.html#ga342bf90d946e7ed3815372db22c4d3a6", null ],
    [ "iio_context_get_xml", "group__Context.html#ga6260d0b454389fec2de1f7dc646c5f10", null ],
    [ "iio_context_set_timeout", "group__Context.html#gaba3f4c4f9f885f41a6c0b9ac79b7f28d", null ],
    [ "iio_create_context_from_uri", "group__Context.html#ga5ee67ad3d58fec29e8be4b88b743a19a", null ],
    [ "iio_create_default_context", "group__Context.html#ga0576b11941ec067f6a5ac0d9b018e2ab", null ],
    [ "iio_create_local_context", "group__Context.html#ga4442159e69e1e51a0d75def49be55f11", null ],
    [ "iio_create_network_context", "group__Context.html#ga68895de9c0079f6f5352b90b4fdd4ce4", null ],
    [ "iio_create_xml_context", "group__Context.html#gae24f011210515a5acf5a82aa80af2e3a", null ],
    [ "iio_create_xml_context_mem", "group__Context.html#ga7f5dd36f1d50849c98919fc43c80da43", null ]
];