var searchData=
[
  ['get_5fchannel_0',['get_channel',['../classiio_1_1Device.html#ab7f441c0264fa93c34106df969221d89',1,'iio::Device']]],
  ['get_5fcontext_1',['get_context',['../classiio_1_1Device.html#aecb809422163d179c3b501bbadaa1ae7',1,'iio::Device']]],
  ['get_5fdevice_2',['get_device',['../classiio_1_1Channel.html#a942e10b2242e296bf75f183ea4b841a5',1,'iio.Channel.get_device()'],['../classiio_1_1Context.html#aec3175f0ba17f5e1e378e764a1cc7ce2',1,'iio.Context.get_device()'],['../classiio_1_1IOBuffer.html#a56e996c52498ce2a91dad07f9e535f6d',1,'iio.IOBuffer.get_device()']]],
  ['get_5fdns_5fsd_5fbackend_5fcontexts_3',['get_dns_sd_backend_contexts',['../classiio_1_1ScanContext.html#a482304ac3f9fffa1ba3b1c502ef172eb',1,'iio::ScanContext']]],
  ['get_5findex_4',['get_index',['../classiio_1_1Channel.html#a89d5dc152580f8bf83597832e073df42',1,'iio::Channel']]],
  ['get_5flocal_5fbackend_5fcontexts_5',['get_local_backend_contexts',['../classiio_1_1ScanContext.html#a87b5e19366d385131f833c51d11d242c',1,'iio::ScanContext']]],
  ['get_5fpoll_5ffd_6',['get_poll_fd',['../classiio_1_1IOBuffer.html#a70243ca0b0ae463181af421905525e6d',1,'iio::IOBuffer']]],
  ['get_5frate_7',['get_rate',['../classiio_1_1Trigger.html#a6ad460b6af12673c305862c1d83eb894',1,'iio::Trigger']]],
  ['get_5fsample_5fsize_8',['get_sample_size',['../classiio_1_1Device.html#a8fcf659b560ffae54b8e5e3181d7988f',1,'iio::Device']]],
  ['get_5ftrigger_9',['get_trigger',['../classiio_1_1Device.html#a0d6bcb4c98aa71895c5c9476bb2e7285',1,'iio.Device.get_trigger()'],['../classiio_1_1Trigger.html#a9e5ece91f51e1faf5785ebbd4da0ccba',1,'iio.Trigger.get_trigger()']]],
  ['get_5fusb_5fbackend_5fcontexts_10',['get_usb_backend_contexts',['../classiio_1_1ScanContext.html#a06778eabc49c2f94e110bd81bd24efac',1,'iio::ScanContext']]]
];
