var searchData=
[
  ['debug_5fattrs_0',['debug_attrs',['../classiio_1_1Device.html#aef585bea3015cda66fbce397d0323794',1,'iio::Device']]],
  ['description_1',['description',['../classiio_1_1Context.html#ac2612db1cb43a09f4d2f5cb7940a89cf',1,'iio::Context']]],
  ['device_2',['Device',['../classiio_1_1Device.html',1,'iio']]],
  ['devices_3',['devices',['../classiio_1_1Context.html#ad5fc9205417a8a2daacdb3cc9832995c',1,'iio::Context']]],
  ['disable_4',['disable',['../classiio_1_1Channel.html#a525ca933e1fb97de56a0fe862385b18b',1,'iio::Channel']]],
  ['dispose_5',['Dispose',['../classiio_1_1Context.html#adc35e6f453bdb4e4209d9e7dee76c0cc',1,'iio.Context.Dispose()'],['../classiio_1_1IOBuffer.html#ab2056e50d032c13abb3f8a2f6cbb6753',1,'iio.IOBuffer.Dispose()']]]
];
