var searchData=
[
  ['channel_0',['Channel',['../classiio_1_1Channel.html',1,'iio']]],
  ['context_1',['Context',['../classiio_1_1Context.html',1,'iio']]]
];
