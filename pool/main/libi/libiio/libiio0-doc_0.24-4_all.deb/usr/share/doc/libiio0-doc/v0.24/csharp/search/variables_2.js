var searchData=
[
  ['debug_5fattrs_0',['debug_attrs',['../classiio_1_1Device.html#aef585bea3015cda66fbce397d0323794',1,'iio::Device']]],
  ['description_1',['description',['../classiio_1_1Context.html#ac2612db1cb43a09f4d2f5cb7940a89cf',1,'iio::Context']]],
  ['devices_2',['devices',['../classiio_1_1Context.html#ad5fc9205417a8a2daacdb3cc9832995c',1,'iio::Context']]]
];
