var searchData=
[
  ['cancel_0',['cancel',['../classiio_1_1IOBuffer.html#ab78a5b13a284f30c4980df8917ae3ec9',1,'iio::IOBuffer']]],
  ['clone_1',['clone',['../classiio_1_1Context.html#a2a39fa7c5e3b7fe684d68a479608f341',1,'iio::Context']]],
  ['context_2',['Context',['../classiio_1_1Context.html#ad8a25052729c766e84f35084901929e9',1,'iio.Context.Context(string uri)'],['../classiio_1_1Context.html#ab2a18c05d5455eb3cca59b38953fadf8',1,'iio.Context.Context()']]],
  ['convert_3',['convert',['../classiio_1_1Channel.html#a30cc0d41bf46de22bd6401f7bda61122',1,'iio::Channel']]],
  ['convert_5finverse_4',['convert_inverse',['../classiio_1_1Channel.html#ad2a951ac21bc0e05c4176aae4287dd77',1,'iio::Channel']]]
];
