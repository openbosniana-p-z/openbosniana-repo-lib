var structiio__data__format =
[
    [ "bits", "structiio__data__format.html#ac0749cd625e020fca8a77095261acdf2", null ],
    [ "is_be", "structiio__data__format.html#a1c1775c482b9b4c3f1dfa0b67ad6fbaa", null ],
    [ "is_fully_defined", "structiio__data__format.html#a86c382f0ff1dcf40f68f261d2d81caf5", null ],
    [ "is_signed", "structiio__data__format.html#a173f2fb6931c4215e53d934667f0dc3f", null ],
    [ "length", "structiio__data__format.html#a80a90d327d93ba59c4717f2fcf420930", null ],
    [ "repeat", "structiio__data__format.html#a6db4ae39ce3e564aac2b31d0948a1efe", null ],
    [ "scale", "structiio__data__format.html#a55125a0f81f90be70428076b426f50e2", null ],
    [ "shift", "structiio__data__format.html#ab56ee226f46a755a6745e08d9d934804", null ],
    [ "with_scale", "structiio__data__format.html#a1def0aacbe62d0cf3c6b350d47b9c623", null ]
];