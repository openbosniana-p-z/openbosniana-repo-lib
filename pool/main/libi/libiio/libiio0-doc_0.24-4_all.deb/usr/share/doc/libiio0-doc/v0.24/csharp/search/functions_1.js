var searchData=
[
  ['disable_0',['disable',['../classiio_1_1Channel.html#a525ca933e1fb97de56a0fe862385b18b',1,'iio::Channel']]],
  ['dispose_1',['Dispose',['../classiio_1_1Context.html#adc35e6f453bdb4e4209d9e7dee76c0cc',1,'iio.Context.Dispose()'],['../classiio_1_1IOBuffer.html#ab2056e50d032c13abb3f8a2f6cbb6753',1,'iio.IOBuffer.Dispose()']]]
];
