var group__TopLevel =
[
    [ "iio_get_backend", "group__TopLevel.html#ga7a4a9dadfeb40b1a38af2b7f8a98e519", null ],
    [ "iio_get_backends_count", "group__TopLevel.html#gabe08d9f1e10801b0334575063a66a56c", null ],
    [ "iio_has_backend", "group__TopLevel.html#ga8cf6a3818d471333f4115f3d0d8d95a2", null ],
    [ "iio_library_get_version", "group__TopLevel.html#gaaa29e5bac86d00a1cef6e2d00b0ea24c", null ],
    [ "iio_strerror", "group__TopLevel.html#ga4a117b0ac02e97aeda92e33c063f7cf0", null ]
];