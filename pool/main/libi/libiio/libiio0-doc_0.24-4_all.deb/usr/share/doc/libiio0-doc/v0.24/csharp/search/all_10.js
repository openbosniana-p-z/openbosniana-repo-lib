var searchData=
[
  ['trigger_0',['Trigger',['../classiio_1_1Trigger.html',1,'iio']]],
  ['type_1',['type',['../classiio_1_1Channel.html#a0a8e7a2aef01d07302fdc71975d274d2',1,'iio::Channel']]]
];
