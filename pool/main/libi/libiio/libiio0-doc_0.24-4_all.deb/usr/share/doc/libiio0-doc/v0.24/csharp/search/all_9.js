var searchData=
[
  ['label_0',['label',['../classiio_1_1Device.html#a3342153fd26e43b710dd33b17cb126fc',1,'iio::Device']]],
  ['library_5fversion_1',['library_version',['../classiio_1_1Context.html#abbd75cb9945ab472fdf95a02c4657354',1,'iio::Context']]]
];
