var classiio_1_1ScanContext =
[
    [ "get_dns_sd_backend_contexts", "classiio_1_1ScanContext.html#a482304ac3f9fffa1ba3b1c502ef172eb", null ],
    [ "get_local_backend_contexts", "classiio_1_1ScanContext.html#a87b5e19366d385131f833c51d11d242c", null ],
    [ "get_usb_backend_contexts", "classiio_1_1ScanContext.html#a06778eabc49c2f94e110bd81bd24efac", null ]
];