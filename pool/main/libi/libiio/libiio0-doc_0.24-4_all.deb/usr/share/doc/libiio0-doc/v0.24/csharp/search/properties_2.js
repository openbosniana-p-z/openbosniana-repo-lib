var searchData=
[
  ['format_0',['format',['../classiio_1_1Channel.html#a1b9214d70d53b882c863908754c39887',1,'iio::Channel']]]
];
