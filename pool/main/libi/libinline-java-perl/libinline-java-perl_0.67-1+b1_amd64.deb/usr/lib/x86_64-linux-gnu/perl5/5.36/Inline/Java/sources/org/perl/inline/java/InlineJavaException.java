package org.perl.inline.java ;

public class InlineJavaException extends Exception { 
	public InlineJavaException(String s) {
		super(s) ;
	}
}
