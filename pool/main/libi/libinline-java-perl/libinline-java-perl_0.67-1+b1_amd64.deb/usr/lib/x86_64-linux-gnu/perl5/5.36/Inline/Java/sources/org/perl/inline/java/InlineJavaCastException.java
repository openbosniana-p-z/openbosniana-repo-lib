package org.perl.inline.java ;

class InlineJavaCastException extends InlineJavaException {
	InlineJavaCastException(String m){
		super(m) ;
	}
}
