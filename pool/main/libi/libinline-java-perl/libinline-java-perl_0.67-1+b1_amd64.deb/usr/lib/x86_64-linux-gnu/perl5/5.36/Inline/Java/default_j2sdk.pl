# This file is created by the Makefile.PL for Inline::Java
# You can modify it if you wish
use strict ;

# The default J2SDK to use for Inline::Java. You can change
# it if this value becomes invalid.
sub Inline::Java::get_default_j2sdk {
	return '/usr/lib/jvm/default-java' ;
}
1 ;
sub Inline::Java::get_default_j2sdk_so_dirs {
	return (
		'/usr/lib/jvm/default-java/lib/server',
	) ;
}

1 ;
