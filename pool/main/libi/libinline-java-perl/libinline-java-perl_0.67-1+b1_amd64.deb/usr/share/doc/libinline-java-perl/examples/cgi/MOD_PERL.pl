use lib "/home/patrickl/DEV/Inline-Java" ;

1 ;
