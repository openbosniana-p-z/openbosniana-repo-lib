use strict;
use warnings;

return [
  {
    'class_description' => 'generated from LCDd.conf',
    'element' => [
      'lircrc',
      {
        'description' => 'Specify an alternative location of the lircrc file ',
        'type' => 'leaf',
        'upstream_default' => '~/.lircrc',
        'value_type' => 'uniline'
      },
      'prog',
      {
        'description' => 'Must be the same as in your lircrc',
        'type' => 'leaf',
        'upstream_default' => 'lcdd',
        'value_type' => 'uniline'
      }
    ],
    'name' => 'LCDd::lirc'
  }
]
;

