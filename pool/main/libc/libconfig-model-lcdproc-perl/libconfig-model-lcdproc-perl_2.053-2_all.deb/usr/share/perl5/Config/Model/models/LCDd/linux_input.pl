use strict;
use warnings;

return [
  {
    'class_description' => 'generated from LCDd.conf',
    'element' => [
      'Device',
      {
        'description' => 'Select the input device to use ',
        'type' => 'leaf',
        'upstream_default' => '/dev/input/event0',
        'value_type' => 'uniline'
      },
      'key',
      {
        'cargo' => {
          'type' => 'leaf',
          'value_type' => 'uniline'
        },
        'type' => 'list'
      }
    ],
    'name' => 'LCDd::linux_input'
  }
]
;

