use strict;
use warnings;

return [
  {
    'class_description' => 'generated from LCDd.conf',
    'element' => [
      'Font',
      {
        'default' => '-*-terminus-*-r-*-*-*-320-*-*-*-*-*',
        'description' => 'X font to use, in XLFD format, as given by "xfontsel"',
        'type' => 'leaf',
        'value_type' => 'uniline'
      },
      'Offset',
      {
        'description' => 'Offset in pixels from the top-left corner of the monitor ',
        'type' => 'leaf',
        'upstream_default' => '0x0',
        'value_type' => 'uniline'
      },
      'Size',
      {
        'description' => 'set display size ',
        'type' => 'leaf',
        'upstream_default' => '20x4',
        'value_type' => 'uniline'
      }
    ],
    'name' => 'LCDd::xosd'
  }
]
;

