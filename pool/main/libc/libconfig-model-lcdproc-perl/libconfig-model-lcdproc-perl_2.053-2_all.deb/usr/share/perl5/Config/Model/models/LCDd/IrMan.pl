use strict;
use warnings;

return [
  {
    'class_description' => 'generated from LCDd.conf',
    'element' => [
      'Config',
      {
        'description' => 'Select the configuration file to use',
        'type' => 'leaf',
        'upstream_default' => '/etc/irman.cfg',
        'value_type' => 'uniline'
      },
      'Device',
      {
        'description' => 'in case of trouble with IrMan, try the Lirc emulator for IrMan
Select the input device to use',
        'type' => 'leaf',
        'upstream_default' => '/dev/irman',
        'value_type' => 'uniline'
      }
    ],
    'name' => 'LCDd::IrMan'
  }
]
;

