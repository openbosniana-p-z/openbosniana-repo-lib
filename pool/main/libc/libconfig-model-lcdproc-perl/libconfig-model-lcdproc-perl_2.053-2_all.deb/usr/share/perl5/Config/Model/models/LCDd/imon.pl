use strict;
use warnings;

return [
  {
    'class_description' => 'generated from LCDd.conf',
    'element' => [
      'CharMap',
      {
        'choice' => [
          'none',
          'hd44780_euro',
          'upd16314',
          'hd44780_koi8_r',
          'hd44780_cp1251',
          'hd44780_8859_5'
        ],
        'description' => 'Character map to to map ISO-8859-1 to the displays character set.
 (upd16314, hd44780_koi8_r,
hd44780_cp1251, hd44780_8859_5 are possible if compiled with additional
charmaps)',
        'type' => 'leaf',
        'upstream_default' => 'none',
        'value_type' => 'enum'
      },
      'Device',
      {
        'compute' => {
          'allow_override' => '1',
          'formula' => 'my $l = \'/dev/lcd-imon\'; -e $l ? $l : \'/dev/lcd0\';',
          'use_eval' => '1'
        },
        'description' => 'select the device to use',
        'type' => 'leaf',
        'value_type' => 'uniline',
        'warn_unless' => {
          'found_device_file' => {
            'code' => 'defined $_ ? -e : 1',
            'fix' => '$_ = undef;',
            'msg' => 'missing imon device file'
          },
          'use_lcd_imon' => {
            'code' => 'my $l = \'/dev/lcd-imon\'; not -e $l or $_ eq $l ;',
            'fix' => '$_ = undef;',
            'msg' => 'imon device does not use /dev/lcd-imon link.'
          }
        }
      },
      'Size',
      {
        'default' => '16x2',
        'description' => 'display dimensions',
        'type' => 'leaf',
        'value_type' => 'uniline'
      }
    ],
    'name' => 'LCDd::imon'
  }
]
;

