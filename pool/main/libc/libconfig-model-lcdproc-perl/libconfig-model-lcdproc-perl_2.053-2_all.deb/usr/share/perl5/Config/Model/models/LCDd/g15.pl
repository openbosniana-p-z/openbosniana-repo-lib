use strict;
use warnings;

return [
  {
    'class_description' => 'generated from LCDd.conf',
    'element' => [
      'size',
      {
        'default' => '20x5',
        'description' => 'Display size (currently unused)',
        'type' => 'leaf',
        'value_type' => 'uniline'
      }
    ],
    'name' => 'LCDd::g15'
  }
]
;

