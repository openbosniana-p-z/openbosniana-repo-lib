use strict;
use warnings;

return [
  {
    'class_description' => 'generated from LCDd.conf',
    'element' => [
      'Device',
      {
        'description' => 'Select the output device to use ',
        'type' => 'leaf',
        'upstream_default' => '/dev/hiddev0',
        'value_type' => 'uniline'
      },
      'WaitAfterRefresh',
      {
        'description' => 'Time to wait in ms after the refresh screen has been sent ',
        'type' => 'leaf',
        'upstream_default' => '1000',
        'value_type' => 'uniline'
      }
    ],
    'name' => 'LCDd::mx5000'
  }
]
;

