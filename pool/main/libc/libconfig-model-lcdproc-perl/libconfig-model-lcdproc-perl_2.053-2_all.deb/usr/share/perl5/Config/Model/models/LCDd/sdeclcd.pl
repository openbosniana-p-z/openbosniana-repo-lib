use strict;
use warnings;

return [
  {
    'class_description' => 'generated from LCDd.conf',
    'name' => 'LCDd::sdeclcd'
  }
]
;

