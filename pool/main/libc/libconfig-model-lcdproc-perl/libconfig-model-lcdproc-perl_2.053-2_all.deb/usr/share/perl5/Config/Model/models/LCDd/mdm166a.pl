use strict;
use warnings;

return [
  {
    'class_description' => 'generated from LCDd.conf',
    'element' => [
      'Clock',
      {
        'choice' => [
          'no',
          'small',
          'big'
        ],
        'description' => 'Show self-running clock after LCDd shutdown
Possible values: ',
        'type' => 'leaf',
        'upstream_default' => 'no',
        'value_type' => 'enum'
      },
      'Dimming',
      {
        'description' => 'Dim display, no dimming gives full brightness ',
        'type' => 'leaf',
        'upstream_default' => 'no,legal:yes,no',
        'value_type' => 'uniline'
      },
      'OffDimming',
      {
        'description' => 'Dim display in case LCDd is inactive ',
        'type' => 'leaf',
        'upstream_default' => 'no,legal:yes,no',
        'value_type' => 'uniline'
      }
    ],
    'name' => 'LCDd::mdm166a'
  }
]
;

