use strict;
use warnings;

return [
  {
    'class_description' => 'generated from LCDd.conf',
    'element' => [
      'Device',
      {
        'description' => 'Select the output device to use ',
        'type' => 'leaf',
        'upstream_default' => '/dev/ttyUSB0',
        'value_type' => 'uniline'
      }
    ],
    'name' => 'LCDd::vlsys_m428'
  }
]
;

