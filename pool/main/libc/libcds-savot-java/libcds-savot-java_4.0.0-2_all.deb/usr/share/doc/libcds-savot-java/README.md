Savot
=====

This repository contains the CDS Savot library, the *Simple Access to VOTable* parser.

Current release:
- Savot 4.0.0 (beta release)

Author, Co-Author:  Andre Schaaff (CDS), Laurent Bourges (JMMC)


License
=======

GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007

See LICENSE

