
#ifndef CIFPP_EXPORT_H
#define CIFPP_EXPORT_H

#ifdef CIFPP_STATIC_DEFINE
#  define CIFPP_EXPORT
#  define CIFPP_NO_EXPORT
#else
#  ifndef CIFPP_EXPORT
#    ifdef cifpp_EXPORTS
        /* We are building this library */
#      define CIFPP_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define CIFPP_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef CIFPP_NO_EXPORT
#    define CIFPP_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef CIFPP_DEPRECATED
#  define CIFPP_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef CIFPP_DEPRECATED_EXPORT
#  define CIFPP_DEPRECATED_EXPORT CIFPP_EXPORT CIFPP_DEPRECATED
#endif

#ifndef CIFPP_DEPRECATED_NO_EXPORT
#  define CIFPP_DEPRECATED_NO_EXPORT CIFPP_NO_EXPORT CIFPP_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef CIFPP_NO_DEPRECATED
#    define CIFPP_NO_DEPRECATED
#  endif
#endif

#endif /* CIFPP_EXPORT_H */
