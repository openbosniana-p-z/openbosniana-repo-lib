var searchData=
[
  ['constructor_0',['constructor',['../structCOMPS__ObjectInfo.html#a3705ff4617c1572f57ec3bfd7209ab3a',1,'COMPS_ObjectInfo']]],
  ['copy_1',['copy',['../structCOMPS__ObjectInfo.html#a35e59dd0f3b165fc74d825d72b500b76',1,'COMPS_ObjectInfo']]]
];
