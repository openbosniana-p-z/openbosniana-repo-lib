var searchData=
[
  ['head_5fcomps_5fdoc_5faddobjdict_0',['HEAD_COMPS_DOC_ADDOBJDICT',['../group__COMPS__Doc__adders.html#ga1f7b7ad77dcdaf78465a61141ed74450',1,'comps_doc.h']]],
  ['head_5fcomps_5fdoc_5faddobjlist_1',['HEAD_COMPS_DOC_ADDOBJLIST',['../group__COMPS__Doc__adders.html#ga8a20823fc33d37719d0c2f6a71a319a1',1,'comps_doc.h']]]
];
