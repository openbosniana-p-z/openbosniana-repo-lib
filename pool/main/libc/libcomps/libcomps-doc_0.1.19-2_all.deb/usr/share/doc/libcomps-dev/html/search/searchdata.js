var indexSectionsWithContent =
{
  0: "bcdefghlnoprtv",
  1: "c",
  2: "c",
  3: "ch",
  4: "bcdefglnoprtv",
  5: "c",
  6: "c",
  7: "c",
  8: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "defines",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Macros",
  7: "Modules",
  8: "Pages"
};

