var searchData=
[
  ['name_0',['name',['../structCOMPS__DocGroupId.html#ab0db3c264e590123362c7aa3a819e543',1,'COMPS_DocGroupId::name()'],['../structCOMPS__DocGroupPackage.html#aec9eb0fa9f73679e1883adb96bcb3f62',1,'COMPS_DocGroupPackage::name()']]],
  ['name_5fby_5flang_1',['name_by_lang',['../structCOMPS__DocCategory.html#a617ef410d6634c43bc246eb92f618e85',1,'COMPS_DocCategory::name_by_lang()'],['../structCOMPS__DocGroup.html#a1eb5e2a671689cdc21243df8741710ae',1,'COMPS_DocGroup::name_by_lang()'],['../structCOMPS__DocEnv.html#a12e9b9b4b453a2e859a3b1267ff9c6b6',1,'COMPS_DocEnv::name_by_lang()']]]
];
