var searchData=
[
  ['group_5fids_0',['group_ids',['../structCOMPS__DocCategory.html#afd72f16cbe534aa5a8a57da46748553d',1,'COMPS_DocCategory']]],
  ['group_5flist_1',['group_list',['../structCOMPS__DocEnv.html#a20dc578d8d5a50a2a6420cb8b6ae077f',1,'COMPS_DocEnv']]]
];
