var searchData=
[
  ['packages_0',['packages',['../structCOMPS__DocGroup.html#a98cb7d4ffefe55acffbed90ccfb44e66',1,'COMPS_DocGroup']]],
  ['properties_1',['properties',['../structCOMPS__DocCategory.html#a5c318ee0a6140ca3d30875bd2452b9ce',1,'COMPS_DocCategory::properties()'],['../structCOMPS__DocGroup.html#aac5033d920bdf7fde9f14a540763ce7a',1,'COMPS_DocGroup::properties()'],['../structCOMPS__DocEnv.html#aab431086e08ab3f094795c6d9ae9e98d',1,'COMPS_DocEnv::properties()']]]
];
