var searchData=
[
  ['encoding_0',['encoding',['../structCOMPS__Doc.html#a7aded289a3cc8dba87ca1d38779953a1',1,'COMPS_Doc']]]
];
