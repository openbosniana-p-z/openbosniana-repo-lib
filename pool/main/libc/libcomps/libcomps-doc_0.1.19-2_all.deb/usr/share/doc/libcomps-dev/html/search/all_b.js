var searchData=
[
  ['ref_5fcount_0',['ref_count',['../structCOMPS__RefC.html#aa10407da05bd5466577c0b77166d3632',1,'COMPS_RefC']]],
  ['refc_1',['refc',['../structCOMPS__Object.html#a5e59b8de4c32134a9ccfd7e159ab3fa1',1,'COMPS_Object']]]
];
