var searchData=
[
  ['client_20example_0',['Client example',['../client.html',1,'']]],
  ['communi_20_2d_20a_20cross_2dplatform_20irc_20framework_20written_20with_20_25qt_1',['Communi - a cross-platform IRC framework written with %Qt',['../index.html',1,'']]]
];
