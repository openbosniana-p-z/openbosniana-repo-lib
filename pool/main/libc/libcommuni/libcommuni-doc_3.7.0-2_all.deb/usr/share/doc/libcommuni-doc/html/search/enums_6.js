var searchData=
[
  ['sortmethod_0',['SortMethod',['../classIrc.html#a48baa7f4f30068211f5f6ce24ebdd31c',1,'Irc']]],
  ['spanformat_1',['SpanFormat',['../classIrcTextFormat.html#aeca804b0ccf6406b0143749b3a6e5af2',1,'IrcTextFormat']]],
  ['status_2',['Status',['../classIrcConnection.html#a2268d1374f4cd68db874dbff6c554c37',1,'IrcConnection']]]
];
