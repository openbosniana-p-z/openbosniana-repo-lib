var searchData=
[
  ['code_0',['Code',['../classIrc.html#acf555f67db1797b90309b3cee8614dfc',1,'Irc']]],
  ['color_1',['Color',['../classIrc.html#a5aea193cadaa533ed9656b29eff84744',1,'Irc']]]
];
