var searchData=
[
  ['ircv3_20support_0',['IRCv3 support',['../ircv3.html',1,'']]]
];
