var searchData=
[
  ['irc_5fversion_0',['IRC_VERSION',['../ircglobal_8h.html#a79816192a19c0614179f8ab388b2afcb',1,'ircglobal.h']]],
  ['irc_5fversion_5fstr_1',['IRC_VERSION_STR',['../ircglobal_8h.html#a8ab5f4192d77ec1bb95690e7a4402dcd',1,'ircglobal.h']]]
];
