var searchData=
[
  ['debugging_20techniques_0',['Debugging techniques',['../debugging.html',1,'']]],
  ['deprecated_20list_1',['Deprecated List',['../deprecated.html',1,'']]]
];
