var searchData=
[
  ['datarole_0',['DataRole',['../classIrc.html#a922118abe6ae2382daa68deefddecbc3',1,'Irc']]],
  ['detail_1',['Detail',['../classIrcCommandParser.html#ab42cf2c9a334a0834384c747b5879e4e',1,'IrcCommandParser']]]
];
