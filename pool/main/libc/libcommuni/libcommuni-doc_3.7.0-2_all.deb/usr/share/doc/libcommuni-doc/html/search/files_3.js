var searchData=
[
  ['main_2ecpp_0',['main.cpp',['../bot_2main_8cpp.html',1,'(Global Namespace)'],['../client_2main_8cpp.html',1,'(Global Namespace)'],['../minimal_2main_8cpp.html',1,'(Global Namespace)'],['../qmlbot_2main_8cpp.html',1,'(Global Namespace)'],['../quick_2main_8cpp.html',1,'(Global Namespace)']]],
  ['main_2eqml_1',['main.qml',['../qmlbot_2qml_2main_8qml.html',1,'(Global Namespace)'],['../quick_2qml_2main_8qml.html',1,'(Global Namespace)']]],
  ['messageformatter_2eqml_2',['MessageFormatter.qml',['../MessageFormatter_8qml.html',1,'']]]
];
