var searchData=
[
  ['version_0',['version',['../classIrc.html#ad9bc1ad1365a92b2bac6c3f676d30c7c',1,'Irc']]]
];
