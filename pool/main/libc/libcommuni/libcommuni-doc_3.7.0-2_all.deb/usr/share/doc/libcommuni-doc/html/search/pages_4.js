var searchData=
[
  ['minimal_20example_0',['Minimal example',['../minimal.html',1,'']]]
];
