var searchData=
[
  ['yellow_0',['yellow',['../classIrcPalette.html#ac078ba2fa5e6d5505272a23bc5f9b437',1,'IrcPalette']]]
];
