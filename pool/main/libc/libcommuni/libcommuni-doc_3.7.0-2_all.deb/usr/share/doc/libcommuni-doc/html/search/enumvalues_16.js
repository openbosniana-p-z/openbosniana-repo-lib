var searchData=
[
  ['yellow_0',['Yellow',['../classIrc.html#a5aea193cadaa533ed9656b29eff84744ae034faf9297a5ff5d9eec3b1643092a3',1,'Irc']]]
];
