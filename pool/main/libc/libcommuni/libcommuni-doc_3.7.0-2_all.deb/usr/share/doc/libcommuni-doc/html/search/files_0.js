var searchData=
[
  ['bufferlistview_2eqml_0',['BufferListView.qml',['../BufferListView_8qml.html',1,'']]]
];
