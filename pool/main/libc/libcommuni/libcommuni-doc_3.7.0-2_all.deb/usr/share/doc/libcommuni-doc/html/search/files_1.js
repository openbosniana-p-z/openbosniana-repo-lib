var searchData=
[
  ['chatpage_2eqml_0',['ChatPage.qml',['../ChatPage_8qml.html',1,'']]],
  ['connectpage_2eqml_1',['ConnectPage.qml',['../ConnectPage_8qml.html',1,'']]]
];
