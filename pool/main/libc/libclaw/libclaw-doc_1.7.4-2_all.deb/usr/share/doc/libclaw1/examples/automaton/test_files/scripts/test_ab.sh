#!/bin/sh

./ex-automaton "test_files/automaton_file/ab.txt" ababababababa ababab bababa bababab a b ""
