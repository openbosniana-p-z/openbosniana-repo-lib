#include "morpion_main.hpp"

int main()
{
  morpion_main jeu;
  return 0;
}

