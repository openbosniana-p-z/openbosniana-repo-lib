#!/bin/sh

./ex-dynamic_library in_program nowhere first_function second_function
./ex-dynamic_library nowhere first_function second_function
