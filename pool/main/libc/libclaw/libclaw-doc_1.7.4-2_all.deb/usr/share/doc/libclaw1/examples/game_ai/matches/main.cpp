#include "matches_main.hpp"

int main()
{
  matches_main game;
  return 0;
}
