#!/bin/sh

./ex-application -b --string="my string" one two three
