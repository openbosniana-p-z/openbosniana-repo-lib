#!/bin/sh

./ex-automaton ./test_files/automaton_file/inc_numbers.txt 0123456789 01243456789 0143456789 1234567890
