#!/bin/sh

./ex-application -h
./ex-application --help
