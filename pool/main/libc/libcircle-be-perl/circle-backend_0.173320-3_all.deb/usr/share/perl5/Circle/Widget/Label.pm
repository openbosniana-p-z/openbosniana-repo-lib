#  You may distribute under the terms of the GNU General Public License
#
#  (C) Paul Evans, 2008-2010 -- leonerd@leonerd.org.uk

package Circle::Widget::Label;

use strict;
use warnings;
use base qw( Circle::Widget );

our $VERSION = '0.173320';

0x55AA;
