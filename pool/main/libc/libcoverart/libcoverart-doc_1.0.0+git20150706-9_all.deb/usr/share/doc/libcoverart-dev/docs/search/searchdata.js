var indexSectionsWithContent =
{
  0: "cet",
  1: "c",
  2: "c",
  3: "c",
  4: "t",
  5: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "enums",
  5: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Enumerations",
  5: "Enumerator"
};

