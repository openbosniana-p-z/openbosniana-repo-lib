var searchData=
[
  ['tcoverartresult_72',['tCoverArtResult',['../caa__c_8h.html#ac6a59ab309b305d93675e16f92063a21',1,'caa_c.h']]],
  ['timagesize_73',['tImageSize',['../caa__c_8h.html#a8fc91f426aeb8d42f364ea9d6cef8ca2',1,'caa_c.h']]]
];
