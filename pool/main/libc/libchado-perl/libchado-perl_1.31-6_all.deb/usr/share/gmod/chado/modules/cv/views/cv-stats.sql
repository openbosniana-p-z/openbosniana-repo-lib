CREATE VIEW avg_number_of_paths_to_root AS
 SELECT 
