var searchData=
[
  ['data_5foffset_148',['data_offset',['../structcyaml__schema__field.html#a2d959050017129171bd0bea9c59fec63',1,'cyaml_schema_field']]],
  ['data_5fsize_149',['data_size',['../structcyaml__schema__value.html#a44390c28f3b86cda63beab88e5388520',1,'cyaml_schema_value']]]
];
