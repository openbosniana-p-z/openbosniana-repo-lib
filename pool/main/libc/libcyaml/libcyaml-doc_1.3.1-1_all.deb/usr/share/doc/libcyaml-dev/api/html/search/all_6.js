var searchData=
[
  ['libcyaml_3a_20schema_2dbased_20yaml_20parsing_20and_20serialisation_155',['LibCYAML: Schema-based YAML parsing and serialisation',['../index.html',1,'']]],
  ['libcyaml_3a_20tutorial_156',['LibCYAML: Tutorial',['../md_docs_guide.html',1,'']]],
  ['log_5fctx_157',['log_ctx',['../structcyaml__config.html#a681d99879fdb097ba6f666358753c193',1,'cyaml_config']]],
  ['log_5ffn_158',['log_fn',['../structcyaml__config.html#a0746d73aef2e9717259415fe057324ad',1,'cyaml_config']]],
  ['log_5flevel_159',['log_level',['../structcyaml__config.html#acb18d12bb3863e90673e68ebbdeabee8',1,'cyaml_config']]]
];
