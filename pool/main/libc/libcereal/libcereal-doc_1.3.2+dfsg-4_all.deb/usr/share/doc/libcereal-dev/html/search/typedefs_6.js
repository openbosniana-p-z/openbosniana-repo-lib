var searchData=
[
  ['uniqueserializer_0',['UniqueSerializer',['../structcereal_1_1detail_1_1InputBindingMap.html#a429d50a04386c8de48e99723564bfbeb',1,'cereal::detail::InputBindingMap']]],
  ['unused_1',['unused',['../structcereal_1_1detail_1_1polymorphic__serialization__support.html#af32ebd1e93fee3dbed819bf1cfbfd073',1,'cereal::detail::polymorphic_serialization_support']]]
];
