var searchData=
[
  ['miscellaneous_20types_20support_0',['Miscellaneous Types Support',['../group__OtherTypes.html',1,'']]]
];
