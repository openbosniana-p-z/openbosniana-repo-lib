var searchData=
[
  ['sfinae_0',['sfinae',['../traits_8hpp.html#aafd74e5beca7e112de8b2e20ef41d973',1,'cereal::traits::detail']]],
  ['specialization_1',['specialization',['../group__Access.html#gac28bb730353e53b3066cc679e63bb108',1,'cereal::specialize']]]
];
