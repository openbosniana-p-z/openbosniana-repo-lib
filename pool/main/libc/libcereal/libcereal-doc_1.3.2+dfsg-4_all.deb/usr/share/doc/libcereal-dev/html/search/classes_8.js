var searchData=
[
  ['jsoninputarchive_0',['JSONInputArchive',['../classcereal_1_1JSONInputArchive.html',1,'cereal']]],
  ['jsonoutputarchive_1',['JSONOutputArchive',['../classcereal_1_1JSONOutputArchive.html',1,'cereal']]]
];
