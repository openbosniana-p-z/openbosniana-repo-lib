var searchData=
[
  ['indentchar_0',['IndentChar',['../classcereal_1_1JSONOutputArchive_1_1Options.html#abf98703312edbd7e053fe71acb737cdf',1,'cereal::JSONOutputArchive::Options']]]
];
