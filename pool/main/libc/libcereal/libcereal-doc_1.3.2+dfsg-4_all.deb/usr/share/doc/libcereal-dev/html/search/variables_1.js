var searchData=
[
  ['data_0',['data',['../structcereal_1_1BinaryData.html#a0bac12b9a4e870dfb89a73d6731f9109',1,'cereal::BinaryData']]]
];
