var searchData=
[
  ['variant_5fsave_5fvisitor_0',['variant_save_visitor',['../structcereal_1_1boost__variant__detail_1_1variant__save__visitor.html',1,'cereal::boost_variant_detail::variant_save_visitor&lt; Archive &gt;'],['../structcereal_1_1variant__detail_1_1variant__save__visitor.html',1,'cereal::variant_detail::variant_save_visitor&lt; Archive &gt;']]],
  ['version_1',['Version',['../structcereal_1_1detail_1_1Version.html',1,'cereal::detail']]],
  ['versions_2',['Versions',['../structcereal_1_1detail_1_1Versions.html',1,'cereal::detail']]],
  ['virtual_5fbase_5fclass_3',['virtual_base_class',['../structcereal_1_1virtual__base__class.html',1,'cereal']]]
];
