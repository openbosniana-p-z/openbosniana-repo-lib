var searchData=
[
  ['standard_20library_20support_0',['Standard Library Support',['../group__STLSupport.html',1,'']]],
  ['support_20for_20serializing_20various_20types_1',['Support for Serializing Various Types',['../group__TypeSupport.html',1,'']]]
];
