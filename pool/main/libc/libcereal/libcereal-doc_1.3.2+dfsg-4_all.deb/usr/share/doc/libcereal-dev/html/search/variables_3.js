var searchData=
[
  ['name_0',['name',['../structcereal_1_1XMLOutputArchive_1_1NodeInfo.html#aba4e8217e142a36fbfc4dbbdca28a398',1,'cereal::XMLOutputArchive::NodeInfo::name()'],['../structcereal_1_1XMLInputArchive_1_1NodeInfo.html#a68a6f48ae6af46e113b7e4618a1992ee',1,'cereal::XMLInputArchive::NodeInfo::name()']]],
  ['node_1',['node',['../structcereal_1_1XMLOutputArchive_1_1NodeInfo.html#a240a9b7d14c064a1c43925a4fd43a6c6',1,'cereal::XMLOutputArchive::NodeInfo::node()'],['../structcereal_1_1XMLInputArchive_1_1NodeInfo.html#a98d18a1207a14f5b3f279f58d82ab9e9',1,'cereal::XMLInputArchive::NodeInfo::node()']]]
];
