var searchData=
[
  ['xmlinputarchive_0',['XMLInputArchive',['../classcereal_1_1XMLInputArchive.html',1,'cereal']]],
  ['xmloutputarchive_1',['XMLOutputArchive',['../classcereal_1_1XMLOutputArchive.html',1,'cereal']]]
];
