var searchData=
[
  ['endianness_0',['Endianness',['../classcereal_1_1PortableBinaryOutputArchive_1_1Options.html#ae2a21b6c39ca3520f070c8484c40f534',1,'cereal::PortableBinaryOutputArchive::Options::Endianness()'],['../classcereal_1_1PortableBinaryInputArchive_1_1Options.html#ae81663827b6e75d37a19c616e1abba6c',1,'cereal::PortableBinaryInputArchive::Options::Endianness()']]]
];
