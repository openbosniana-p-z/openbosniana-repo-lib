var searchData=
[
  ['unregistered_5fpolymorphic_5fcast_5fexception_0',['UNREGISTERED_POLYMORPHIC_CAST_EXCEPTION',['../polymorphic__impl_8hpp.html#aebe09f7b847560c8d63b9224008001df',1,'polymorphic_impl.hpp']]],
  ['unregistered_5fpolymorphic_5fexception_1',['UNREGISTERED_POLYMORPHIC_EXCEPTION',['../polymorphic_8hpp.html#a6a90af3fca239017978477a753225101',1,'polymorphic.hpp']]]
];
