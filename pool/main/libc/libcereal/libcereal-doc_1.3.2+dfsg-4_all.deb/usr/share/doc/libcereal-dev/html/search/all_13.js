var searchData=
[
  ['unique_5fptr_0',['unique_ptr',['../structcereal_1_1detail_1_1OutputBindingMap_1_1Serializers.html#ab4c2f8544bdbe179ef4664de9589f825',1,'cereal::detail::OutputBindingMap::Serializers::unique_ptr()'],['../structcereal_1_1detail_1_1InputBindingMap_1_1Serializers.html#a94620847674f5398454cbdb9660b8532',1,'cereal::detail::InputBindingMap::Serializers::unique_ptr()']]],
  ['uniqueserializer_1',['UniqueSerializer',['../structcereal_1_1detail_1_1InputBindingMap.html#a429d50a04386c8de48e99723564bfbeb',1,'cereal::detail::InputBindingMap']]],
  ['unordered_5fmap_2ehpp_2',['unordered_map.hpp',['../unordered__map_8hpp.html',1,'']]],
  ['unordered_5fset_2ehpp_3',['unordered_set.hpp',['../unordered__set_8hpp.html',1,'']]],
  ['unregistered_5fpolymorphic_5fcast_5fexception_4',['UNREGISTERED_POLYMORPHIC_CAST_EXCEPTION',['../polymorphic__impl_8hpp.html#aebe09f7b847560c8d63b9224008001df',1,'polymorphic_impl.hpp']]],
  ['unregistered_5fpolymorphic_5fexception_5',['UNREGISTERED_POLYMORPHIC_EXCEPTION',['../polymorphic_8hpp.html#a6a90af3fca239017978477a753225101',1,'polymorphic.hpp']]],
  ['unused_6',['unused',['../structcereal_1_1detail_1_1polymorphic__serialization__support.html#af32ebd1e93fee3dbed819bf1cfbfd073',1,'cereal::detail::polymorphic_serialization_support']]],
  ['upcast_7',['upcast',['../structcereal_1_1detail_1_1PolymorphicCaster.html#a771ea4d4bdc3e5e8992f3cb4ffeb5022',1,'cereal::detail::PolymorphicCaster::upcast()'],['../structcereal_1_1detail_1_1PolymorphicVirtualCaster.html#a0ccc43b1887c37ac639b585e42ad319e',1,'cereal::detail::PolymorphicVirtualCaster::upcast(std::shared_ptr&lt; void &gt; const &amp;ptr) const override'],['../structcereal_1_1detail_1_1PolymorphicVirtualCaster.html#acaf2413d8bd17dfd83d1f7abef0a8cf0',1,'cereal::detail::PolymorphicVirtualCaster::upcast(void *const ptr) const override'],['../structcereal_1_1detail_1_1PolymorphicCasters.html#abc39a0e05acd42d553215303f1101007',1,'cereal::detail::PolymorphicCasters::upcast(std::shared_ptr&lt; Derived &gt; const &amp;dptr, std::type_info const &amp;baseInfo)'],['../structcereal_1_1detail_1_1PolymorphicCasters.html#aab705357ea4e0494c91a09d14c33efba',1,'cereal::detail::PolymorphicCasters::upcast(Derived *const dptr, std::type_info const &amp;baseInfo)'],['../structcereal_1_1detail_1_1PolymorphicCaster.html#a0343cafc5560566a81cf7216d1adf96f',1,'cereal::detail::PolymorphicCaster::upcast()']]],
  ['util_2ehpp_8',['util.hpp',['../util_8hpp.html',1,'']]],
  ['utility_20functionality_9',['Utility Functionality',['../group__Utility.html',1,'']]],
  ['utility_2ehpp_10',['utility.hpp',['../utility_8hpp.html',1,'']]]
];
