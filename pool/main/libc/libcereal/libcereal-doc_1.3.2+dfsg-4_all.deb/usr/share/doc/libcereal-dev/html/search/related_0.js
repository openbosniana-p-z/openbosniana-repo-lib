var searchData=
[
  ['construct_0',['Construct',['../classcereal_1_1InputArchive.html#a41750b871b4e635565f892e4abfb20b0',1,'cereal::InputArchive']]]
];
