var searchData=
[
  ['type_0',['type',['../bitset_8hpp.html#a4f5825a3267dd05e798bed76cf7e29cc',1,'cereal::bitset_detail']]]
];
