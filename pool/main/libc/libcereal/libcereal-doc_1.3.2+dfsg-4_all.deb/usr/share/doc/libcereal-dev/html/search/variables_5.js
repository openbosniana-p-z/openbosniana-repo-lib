var searchData=
[
  ['unique_5fptr_0',['unique_ptr',['../structcereal_1_1detail_1_1OutputBindingMap_1_1Serializers.html#ab4c2f8544bdbe179ef4664de9589f825',1,'cereal::detail::OutputBindingMap::Serializers::unique_ptr()'],['../structcereal_1_1detail_1_1InputBindingMap_1_1Serializers.html#a94620847674f5398454cbdb9660b8532',1,'cereal::detail::InputBindingMap::Serializers::unique_ptr()']]]
];
