var searchData=
[
  ['child_0',['child',['../structcereal_1_1XMLInputArchive_1_1NodeInfo.html#a0bfbad4de0c4509b402410b3201903bd',1,'cereal::XMLInputArchive::NodeInfo']]],
  ['counter_1',['counter',['../structcereal_1_1XMLOutputArchive_1_1NodeInfo.html#ac7786637d9acb060450d67fcbab4cd04',1,'cereal::XMLOutputArchive::NodeInfo']]]
];
