var searchData=
[
  ['process_5fif_0',['PROCESS_IF',['../cereal_8hpp.html#abf30af3781b2cd7bd163e408dc6cc04d',1,'PROCESS_IF():&#160;cereal.hpp'],['../cereal_8hpp.html#abf30af3781b2cd7bd163e408dc6cc04d',1,'PROCESS_IF():&#160;cereal.hpp']]]
];
