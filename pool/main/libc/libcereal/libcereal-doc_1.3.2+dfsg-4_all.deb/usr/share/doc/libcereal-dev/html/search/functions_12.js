var searchData=
[
  ['xmlinputarchive_0',['XMLInputArchive',['../classcereal_1_1XMLInputArchive.html#ab641ded4033d8e998e41dd002ece9184',1,'cereal::XMLInputArchive']]],
  ['xmloutputarchive_1',['XMLOutputArchive',['../classcereal_1_1XMLOutputArchive.html#a38f4d3926118a014c72a56b1d7547dac',1,'cereal::XMLOutputArchive']]]
];
