var searchData=
[
  ['is_5floading_0',['is_loading',['../classcereal_1_1OutputArchive.html#a8f3be4fe8a965bbce4eb1cf36068e611',1,'cereal::OutputArchive::is_loading()'],['../classcereal_1_1InputArchive.html#adeb555e9b25f21391e4cc9eca9f04dbd',1,'cereal::InputArchive::is_loading()']]],
  ['is_5fsaving_1',['is_saving',['../classcereal_1_1OutputArchive.html#ad48175118ea9b931ef42a74f8efd0389',1,'cereal::OutputArchive::is_saving()'],['../classcereal_1_1InputArchive.html#af90a8d1dc2c9163367765817f7b704d4',1,'cereal::InputArchive::is_saving()']]]
];
