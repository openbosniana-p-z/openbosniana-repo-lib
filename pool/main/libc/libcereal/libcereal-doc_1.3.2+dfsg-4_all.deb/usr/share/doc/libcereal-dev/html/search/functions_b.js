var searchData=
[
  ['namevaluepair_0',['NameValuePair',['../classcereal_1_1NameValuePair.html#ada17c8f6c9895a9d2d7fa7859e48537c',1,'cereal::NameValuePair']]],
  ['noindent_1',['NoIndent',['../classcereal_1_1JSONOutputArchive_1_1Options.html#a288d513a2bdbfbe0bdf2573146972432',1,'cereal::JSONOutputArchive::Options']]]
];
