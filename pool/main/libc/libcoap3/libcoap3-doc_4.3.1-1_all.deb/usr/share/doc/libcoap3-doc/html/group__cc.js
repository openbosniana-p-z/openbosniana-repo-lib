var group__cc =
[
    [ "COAP_DEFAULT_ACK_RANDOM_FACTOR", "group__cc.html#ga4fcd70b1558aeb7fea1cd734a53589e0", null ],
    [ "COAP_DEFAULT_ACK_TIMEOUT", "group__cc.html#ga94c99a6160d08f8c3b79a1c31b712ea0", null ],
    [ "COAP_DEFAULT_DEFAULT_LEISURE", "group__cc.html#ga9aa94369a041f067db2ee94a08e6a24f", null ],
    [ "COAP_DEFAULT_MAX_LATENCY", "group__cc.html#ga4754a1601eaf6dbea030292438e2d2b5", null ],
    [ "COAP_DEFAULT_MAX_RETRANSMIT", "group__cc.html#ga7574b8b96be63292723bab49f11386bc", null ],
    [ "COAP_DEFAULT_NSTART", "group__cc.html#ga9d5bcf0eaa2f8b5d0c8f0c7b0e76aac9", null ],
    [ "COAP_DEFAULT_PROBING_RATE", "group__cc.html#gab3d07985e09ef5016fa0178093e30134", null ],
    [ "coap_session_get_ack_random_factor", "group__cc.html#ga487c51e2072ca39fb2b9a660f1a2bf07", null ],
    [ "coap_session_get_ack_timeout", "group__cc.html#gae9f9c2857a65930b86f565657fc73312", null ],
    [ "coap_session_get_default_leisure", "group__cc.html#ga2c371b4bcbf414eb16b64ea81b471a4d", null ],
    [ "coap_session_get_max_retransmit", "group__cc.html#ga6b0af7bfe268217629060ccd5c82d631", null ],
    [ "coap_session_get_nstart", "group__cc.html#gaded5c57ed69a4b6414dd988551f4b528", null ],
    [ "coap_session_get_probing_rate", "group__cc.html#ga7b094d82df49b541b59313d36ca63b4f", null ],
    [ "coap_session_set_ack_random_factor", "group__cc.html#ga45feb3b133d2673839723a8ecf6d547c", null ],
    [ "coap_session_set_ack_timeout", "group__cc.html#ga9b9cd625815481afa130fa086362dfe1", null ],
    [ "coap_session_set_default_leisure", "group__cc.html#gacd4381217bd89f040e70f4c295112533", null ],
    [ "coap_session_set_max_retransmit", "group__cc.html#ga2f8e64fa42fc8a3ed495fc78b837b7ac", null ],
    [ "coap_session_set_nstart", "group__cc.html#gaadaad02bd89579d92d6ff0de76db47e7", null ],
    [ "coap_session_set_probing_rate", "group__cc.html#gac7ee3c3231930220798a7c0bbca69e25", null ]
];