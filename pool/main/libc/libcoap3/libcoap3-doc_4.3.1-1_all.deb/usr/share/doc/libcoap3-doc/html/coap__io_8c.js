var coap__io_8c =
[
    [ "in6_pktinfo", "structin6__pktinfo.html", "structin6__pktinfo" ],
    [ "in_pktinfo", "structin__pktinfo.html", "structin__pktinfo" ],
    [ "iov_len_t", "coap__io_8c.html#ac9eebbef7851c960b14178bc27b2e083", null ],
    [ "MSG_NOSIGNAL", "coap__io_8c.html#a9f55d0e90dc8cc6b2287312435cdde48", null ],
    [ "SIN6", "coap__io_8c.html#a95d3fb172d041a6a70f3a5c7ae742b7e", null ],
    [ "SOL_IP", "coap__io_8c.html#a68cc6215788f9cdd08a1ba436f3cb726", null ],
    [ "coap_io_prepare_epoll", "group__app__io__internal.html#ga3be92476a2c2c12d68c0cd07795c7e34", null ],
    [ "coap_io_prepare_io", "group__app__io__internal.html#gaf0cbbb00a6f2f8ac885f0e1575534e34", null ],
    [ "coap_io_process", "group__app__io.html#ga082f7bbf15d3f37c31c2a0a5e78ea4cf", null ],
    [ "coap_io_process_with_fds", "group__app__io.html#ga2758ed5fdd6ce79ec95ea8dbf72a5644", null ],
    [ "coap_network_read", "coap__io_8c.html#a9b8fa856db7113a97f74c726219c4be4", null ],
    [ "coap_network_send", "coap__io_8c.html#a9e9bc78d20872c6ea9cb8dddfcea45ad", null ],
    [ "coap_packet_get_memmapped", "coap__io_8c.html#a4bc4949c9ad150282ec082c99510046b", null ],
    [ "coap_socket_bind_udp", "coap__io_8c.html#a9d1deb43ee288c60730c3c8c5df8ec73", null ],
    [ "coap_socket_close", "coap__io_8c.html#a2de382e7795c908d1a376da8c338386d", null ],
    [ "coap_socket_format_errno", "coap__io_8c.html#a198ae48fdbe1762be87328d3a5f5f4b2", null ],
    [ "coap_socket_read", "coap__io_8c.html#a2bbd598665f98a1e2f899b475f01618b", null ],
    [ "coap_socket_send", "coap__io_8c.html#a3728d8a61188dd4b3afd1aff807109f7", null ],
    [ "coap_socket_strerror", "coap__io_8c.html#a3d4397c1a2ce78e64c19fdcd25256737", null ],
    [ "coap_socket_write", "coap__io_8c.html#a53d8fd138fc5bf331c2bf71d72ac4848", null ]
];