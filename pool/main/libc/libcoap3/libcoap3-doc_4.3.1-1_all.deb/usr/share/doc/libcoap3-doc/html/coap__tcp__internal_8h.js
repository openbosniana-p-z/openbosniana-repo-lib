var coap__tcp__internal_8h =
[
    [ "coap_socket_accept_tcp", "group__tcp.html#gaac7a863c20dfbbabaa56cddd2c4109f9", null ],
    [ "coap_socket_bind_tcp", "group__tcp.html#ga1c01bf1b3043f11f948e4f3aff1b7823", null ],
    [ "coap_socket_connect_tcp1", "group__tcp.html#ga85ec542c39fda4a6a5346c7801bf0ecd", null ],
    [ "coap_socket_connect_tcp2", "group__tcp.html#gae591a90d6202a1b7f82b1aa688614520", null ]
];