var coap__resource__internal_8h =
[
    [ "RESOURCES_ADD", "group__coap__resource__internal.html#ga15958c8e0206576186380e783bca59f3", null ],
    [ "RESOURCES_DELETE", "group__coap__resource__internal.html#gaf3a9ffcab8f22609f9786d0b63098009", null ],
    [ "RESOURCES_FIND", "group__coap__resource__internal.html#ga922414123af335d7015cc68ca1cfc765", null ],
    [ "RESOURCES_ITER", "group__coap__resource__internal.html#gafbf6d1376ab4eec0d503f47281877f4c", null ],
    [ "coap_delete_all_resources", "group__coap__resource__internal.html#ga1fae3046ad94fce85a7ea23455328958", null ],
    [ "coap_delete_attr", "group__coap__resource__internal.html#ga37883d9c8bafdd59fd1bd57dcb82e908", null ],
    [ "coap_print_wellknown", "group__coap__resource__internal.html#ga194acce318d2db725214f7194f32e167", null ]
];