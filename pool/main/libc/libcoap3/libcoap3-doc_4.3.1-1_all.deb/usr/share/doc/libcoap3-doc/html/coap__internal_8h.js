var coap__internal_8h =
[
    [ "COAP_CLIENT_SUPPORT", "coap__internal_8h.html#ad61b5a6d3278d2e2e682d75b98965221", null ],
    [ "COAP_SERVER_SUPPORT", "coap__internal_8h.html#a0fd37be5c6bb6a9760460133ae0d5383", null ]
];