var coap__riot_8h =
[
    [ "LIBCOAP_MAX_SOCKETS", "coap__riot_8h.html#ac2a7c2cd1b4fe1d2b7232ee3caf4637f", null ],
    [ "LIBCOAP_MSG_QUEUE_SIZE", "coap__riot_8h.html#aabe2a1ef57c8943a14de566bf5695fdf", null ],
    [ "coap_riot_startup", "coap__riot_8h.html#aeb8721a167439140b7c24576f5c52c8b", null ]
];