var group__app__io =
[
    [ "COAP_IO_NO_WAIT", "group__app__io.html#ga8cdde699b060a89e5f6433b61cf0a0eb", null ],
    [ "COAP_IO_WAIT", "group__app__io.html#gaaf3b35c7e5cf130a712198ffd54fc5b1", null ],
    [ "coap_io_process", "group__app__io.html#ga082f7bbf15d3f37c31c2a0a5e78ea4cf", null ],
    [ "coap_io_process_with_fds", "group__app__io.html#ga2758ed5fdd6ce79ec95ea8dbf72a5644", null ]
];