var coap__event_8c =
[
    [ "coap_clear_event_handler", "coap__event_8c.html#a367cc9ec0671025c04c37ab74908e1ea", null ],
    [ "coap_register_event_handler", "group__events.html#ga8627af857afa4c69502e6c6131c0b344", null ],
    [ "coap_set_event_handler", "coap__event_8c.html#a7491f18fe04844094e7425780f9ba4df", null ]
];