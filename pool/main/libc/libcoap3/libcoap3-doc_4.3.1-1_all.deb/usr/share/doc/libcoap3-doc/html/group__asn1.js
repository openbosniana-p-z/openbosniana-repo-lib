var group__asn1 =
[
    [ "asn1_validate", "group__asn1.html#gad120db234636c7ec88391a8cafe60994", null ],
    [ "coap_asn1_tag_t", "group__asn1.html#gabeb87f9ab79d2e6fce946e03346c2d52", [
      [ "COAP_ASN1_NONE", "group__asn1.html#ggabeb87f9ab79d2e6fce946e03346c2d52a86a2b13c640c426a7f42f993db000a2c", null ],
      [ "COAP_ASN1_INTEGER", "group__asn1.html#ggabeb87f9ab79d2e6fce946e03346c2d52ad05f97cc0b61e461477fecadfc1f92ca", null ],
      [ "COAP_ASN1_BITSTRING", "group__asn1.html#ggabeb87f9ab79d2e6fce946e03346c2d52ad938430301cf5886da44f907f3ba8570", null ],
      [ "COAP_ASN1_OCTETSTRING", "group__asn1.html#ggabeb87f9ab79d2e6fce946e03346c2d52a8dd4dc58699c2025716608252c147040", null ],
      [ "COAP_ASN1_IDENTIFIER", "group__asn1.html#ggabeb87f9ab79d2e6fce946e03346c2d52ae24d66878aafb5f3d9661abe791149c9", null ]
    ] ],
    [ "asn1_len", "group__asn1.html#gab0b2cdf4081790ee762743d5557c2706", null ],
    [ "asn1_tag_c", "group__asn1.html#ga811fd8d69e813fdfcc12d2ab4e5795c0", null ],
    [ "get_asn1_tag", "group__asn1.html#ga2651414d8dfa01e3dca3ca076730bdfd", null ]
];