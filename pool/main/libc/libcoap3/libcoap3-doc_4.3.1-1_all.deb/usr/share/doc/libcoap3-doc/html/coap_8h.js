var coap_8h =
[
    [ "LIBCOAP_PACKAGE_BUGREPORT", "coap_8h.html#ab991fa4611effdfc8c14412e78bf5b97", null ],
    [ "LIBCOAP_PACKAGE_NAME", "coap_8h.html#a237e0957221aece821b002730c691820", null ],
    [ "LIBCOAP_PACKAGE_STRING", "coap_8h.html#a9371b7eeb1f3f0ba6056d20347f46d16", null ],
    [ "LIBCOAP_PACKAGE_URL", "coap_8h.html#a8290d24830ddd9641d91ce65653d7244", null ],
    [ "LIBCOAP_PACKAGE_VERSION", "coap_8h.html#a3c50c13a070d4f983fc5a921823a5390", null ],
    [ "LIBCOAP_VERSION", "coap_8h.html#a79c226cfd48fdaabbd54b51d02f7df91", null ]
];