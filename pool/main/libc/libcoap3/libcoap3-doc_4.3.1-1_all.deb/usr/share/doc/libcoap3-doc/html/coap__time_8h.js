var coap__time_8h =
[
    [ "COAP_TICKS_PER_SECOND", "group__clock.html#gabf672e8aaf725f9ccbc4fc0aa202a5bb", null ],
    [ "coap_tick_diff_t", "group__clock.html#ga2dd35de82321ad2466dab00275914544", null ],
    [ "coap_tick_t", "group__clock.html#ga97ff1502e211b4ee6c3f15a598833438", null ],
    [ "coap_time_t", "group__clock.html#ga3f27196958c88d1edc17911f5f39ef82", null ],
    [ "coap_clock_init", "group__clock.html#ga4722a7e40ba99c4d3feba19de1b980be", null ],
    [ "coap_ticks", "group__clock.html#ga350826988e63ff446a2a84034ecdf43d", null ],
    [ "coap_ticks_from_rt_us", "group__clock.html#ga0e2d5d4667e8b7a44c375cdb378b8d1b", null ],
    [ "coap_ticks_to_rt", "group__clock.html#gaaa7cb35533d86c8f87eac2ad42de0323", null ],
    [ "coap_ticks_to_rt_us", "group__clock.html#gaefd1d943d41dc7a8c32188741bad4844", null ],
    [ "coap_time_le", "group__clock.html#gabd0a10d70e913cfb419648c910565694", null ],
    [ "coap_time_lt", "group__clock.html#ga9b6406a84eca7917db0bb39cd8cb44ab", null ]
];