var coap__subscribe_8h =
[
    [ "COAP_OBSERVE_CANCEL", "group__observe.html#ga51750fd894c457a4fe45f06c96641b2f", null ],
    [ "COAP_OBSERVE_ESTABLISH", "group__observe.html#ga8f172a982abdbb1c45fc5bdb90a23da4", null ],
    [ "coap_resource_notify_observers", "group__observe.html#ga0a053626d2f222a32cc96c4a3dd9902f", null ],
    [ "coap_resource_set_get_observable", "group__observe.html#ga6717daf379770ae060e6c0f800ac7482", null ]
];