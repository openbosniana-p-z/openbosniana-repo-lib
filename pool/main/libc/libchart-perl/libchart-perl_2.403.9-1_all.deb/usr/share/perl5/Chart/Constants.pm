
# set up initial constant values

use v5.12;

package Chart::Constants;
our $VERSION = 'v2.403.9';

use constant PI => 4 * atan2( 1, 1 );


1; # be a good module
