package Crypt::RSA::Parse::Parser::MathBigInt;

use parent qw(Crypt::RSA::Parse::Parser);

sub _TEMPLATE_TYPE { 'INTEGER' };

1;
