---
has_children: true
has_toc: true
nav_order: 5
---

# Contributing

We welcome contributions - just send us a pull request!

libcu++ uses the [Apache License v2.0 with LLVM Exceptions].


[Apache License v2.0 with LLVM Exceptions]: https://llvm.org/LICENSE.txt
