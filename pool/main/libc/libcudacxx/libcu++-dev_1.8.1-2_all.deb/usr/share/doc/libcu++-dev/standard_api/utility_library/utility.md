---
grand_parent: Standard API
parent: Utility Library
nav_order: 1
---

# `<cuda/std/utility>`

## Omissions

Only `pair` is available at this time.
There is no inherent challenge in providing many of the things in `<utility>`;
  they simply have not been our highest priority.

