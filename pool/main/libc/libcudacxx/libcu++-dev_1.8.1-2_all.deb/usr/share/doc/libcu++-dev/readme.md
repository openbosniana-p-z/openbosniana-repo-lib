libcu++ documentation
===

To build and serve the documentation as a website to `http://localhost:4000` just execute the following from libcudacxx root directory:

```shell
./docs/serve
```

