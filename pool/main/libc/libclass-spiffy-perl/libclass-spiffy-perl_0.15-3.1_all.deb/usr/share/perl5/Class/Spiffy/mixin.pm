package Class::Spiffy::mixin;
1;
