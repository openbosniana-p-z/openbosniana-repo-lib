#! /usr/bin/perl -w

use minimalapp;

my $app = minimalapp->new();
$app->run();
