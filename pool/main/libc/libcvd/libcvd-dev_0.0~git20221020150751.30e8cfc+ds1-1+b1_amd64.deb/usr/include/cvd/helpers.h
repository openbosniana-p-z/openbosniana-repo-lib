
#ifdef __GNUC__
#warning This file is oddly named and now deprecated. Use cvd/image_io.h
#else //elif defined(which ever compilers support this)
#pragma warning "This file is oddly named and now deprecated. Use cvd/image_io.h"
#endif

#include <cvd/image_io.h>
