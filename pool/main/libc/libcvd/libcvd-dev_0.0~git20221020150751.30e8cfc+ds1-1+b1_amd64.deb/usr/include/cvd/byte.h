#ifndef __CVD_BYTE_H
#define __CVD_BYTE_H

namespace CVD
{
/// An 8-bit datatype
/// @ingroup gImage
typedef unsigned char byte;
}

#endif
