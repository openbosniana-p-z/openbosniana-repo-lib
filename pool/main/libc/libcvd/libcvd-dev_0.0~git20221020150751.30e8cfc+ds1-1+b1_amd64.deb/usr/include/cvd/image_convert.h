#ifdef _MSC_VER
#pragma message("This file is deprecated, please use convert_image.h")
#else
#warning "This file is deprecated, please use convert_image.h"
#endif
#include <cvd/convert_image.h>
