/* cvd/config.h.  Generated from config.h.in by configure.  */
/* cvd/config.h.in.  Generated from configure.ac by autoheader.  */

/* Define if building universal (internal helper macro) */
/* #undef AC_APPLE_UNIVERSAL_BUILD */

/* Description */
#define CVD_HAVE_ASSEMBLER /**/

/* Description */
#define CVD_HAVE_DC1394V2 /**/

/* Description */
#define CVD_HAVE_FENV_H /**/

/* Description */
#define CVD_HAVE_FFMPEG /**/

/* Description */
#define CVD_HAVE_INLINE_ASM /**/

/* Description */
#define CVD_HAVE_JPEG /**/

/* Description */
#define CVD_HAVE_LIBUVC /**/

/* Description */
#define CVD_HAVE_MMX /**/

/* Description */
#define CVD_HAVE_MMXEXT /**/

/* Description */
#define CVD_HAVE_PNG /**/

/* Description */
#define CVD_HAVE_SSE /**/

/* Description */
#define CVD_HAVE_SSE2 /**/

/* Description */
#define CVD_HAVE_SSE3 /**/

/* Description */
#define CVD_HAVE_TIFF /**/

/* Description */
#define CVD_HAVE_TOON /**/

/* Description */
#define CVD_HAVE_V4L2BUFFER /**/

/* Description */
#define CVD_HAVE_VIDEODISPLAY /**/

/* Description */
#define CVD_MAJOR_VERSION /**/

/* Description */
#define CVD_MINOR_VERSION /**/

/* define if the compiler supports basic C++17 syntax */
#define HAVE_CXX17 1

/* Define to 1 if you have the <dc1394/dc1394.h> header file. */
#define HAVE_DC1394_DC1394_H 1

/* Define to 1 if you have the <GL/glu.h> header file. */
#define HAVE_GL_GLU_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <jpeglib.h> header file. */
#define HAVE_JPEGLIB_H 1

/* Define to 1 if you have the `avcodec' library (-lavcodec). */
#define HAVE_LIBAVCODEC 1

/* Define to 1 if you have the `avdevice' library (-lavdevice). */
#define HAVE_LIBAVDEVICE 1

/* Define to 1 if you have the `avformat' library (-lavformat). */
#define HAVE_LIBAVFORMAT 1

/* Define to 1 if you have the `avutil' library (-lavutil). */
#define HAVE_LIBAVUTIL 1

/* Define to 1 if you have the `dc1394' library (-ldc1394). */
#define HAVE_LIBDC1394 1

/* Define to 1 if you have the `GL' library (-lGL). */
#define HAVE_LIBGL 1

/* Define to 1 if you have the `GLU' library (-lGLU). */
#define HAVE_LIBGLU 1

/* Define to 1 if you have the `jpeg' library (-ljpeg). */
#define HAVE_LIBJPEG 1

/* Define to 1 if you have the `png' library (-lpng). */
#define HAVE_LIBPNG 1

/* Define to 1 if you have the `pthread' library (-lpthread). */
#define HAVE_LIBPTHREAD 1

/* Define to 1 if you have the `swscale' library (-lswscale). */
#define HAVE_LIBSWSCALE 1

/* Define to 1 if you have the `tiff' library (-ltiff). */
#define HAVE_LIBTIFF 1

/* Define to 1 if you have the `uvc' library (-luvc). */
/* #undef HAVE_LIBUVC */

/* Define to 1 if you have the <libuvc/libuvc.h> header file. */
/* #undef HAVE_LIBUVC_LIBUVC_H */

/* Define to 1 if you have the <png.h> header file. */
#define HAVE_PNG_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <tiffio.h> header file. */
#define HAVE_TIFFIO_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "CVD"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "CVD 2.1"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "cvd"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.1"

/* The size of `void*', as computed by sizeof. */
#define SIZEOF_VOIDP 8

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Define WORDS_BIGENDIAN to 1 if your processor stores words with the most
   significant byte first (like Motorola and SPARC, unlike Intel). */
#if defined AC_APPLE_UNIVERSAL_BUILD
# if defined __BIG_ENDIAN__
#  define WORDS_BIGENDIAN 1
# endif
#else
# ifndef WORDS_BIGENDIAN
/* #  undef WORDS_BIGENDIAN */
# endif
#endif
