var searchData=
[
  ['section_0',['section',['../unioncfg__value__t.html#a6d27d8470954ed35947dfcf3bcc52796',1,'cfg_value_t']]],
  ['simple_5fvalue_1',['simple_value',['../structcfg__opt__t.html#a74cd795bf14bcbc4fd5f8993e1ec241a',1,'cfg_opt_t']]],
  ['string_2',['string',['../unioncfg__value__t.html#a7406159ddee3574d8ded326af1ab0764',1,'cfg_value_t::string()'],['../structcfg__defvalue__t.html#a80df4364da2c5ac1c2c063343cc4e7e5',1,'cfg_defvalue_t::string()']]],
  ['subopts_3',['subopts',['../structcfg__opt__t.html#aa3361a9b809e83d22e911b32e10387d9',1,'cfg_opt_t']]]
];
