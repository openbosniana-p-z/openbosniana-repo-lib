var searchData=
[
  ['boolean_0',['boolean',['../unioncfg__value__t.html#a9213cfe5b50eb6d2c5fec1e0a1ff3c8a',1,'cfg_value_t::boolean()'],['../structcfg__defvalue__t.html#aaaed19d35087bff1882ddf6873146624',1,'cfg_defvalue_t::boolean()']]]
];
