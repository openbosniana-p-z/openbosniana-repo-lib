var searchData=
[
  ['title_0',['title',['../structcfg__t.html#a74db29ce5d3b2d4cf99b9db1f6f5139d',1,'cfg_t']]],
  ['type_1',['type',['../structcfg__opt__t.html#a0cdd99a97da9f62a6876421571842c5a',1,'cfg_opt_t']]]
];
