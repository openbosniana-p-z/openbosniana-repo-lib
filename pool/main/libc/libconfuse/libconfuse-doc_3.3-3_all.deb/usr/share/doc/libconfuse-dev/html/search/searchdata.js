var indexSectionsWithContent =
{
  0: "bcdeflnopstv",
  1: "c",
  2: "c",
  3: "c",
  4: "bcdeflnopstv",
  5: "c",
  6: "c",
  7: "c",
  8: "c",
  9: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

