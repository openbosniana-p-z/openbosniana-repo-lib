var searchData=
[
  ['cfg_5fbool_5ft_0',['cfg_bool_t',['../confuse_8h.html#a4bce4b6aed9b07489d6a5c70321907e4',1,'confuse.h']]],
  ['cfg_5ftype_5ft_1',['cfg_type_t',['../confuse_8h.html#a9c62155b0deae0e1831507520a2ff7c7',1,'confuse.h']]]
];
