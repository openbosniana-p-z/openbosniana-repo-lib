var searchData=
[
  ['validcb_0',['validcb',['../structcfg__opt__t.html#a99bfdb357aca5b75254352a54fd6f9be',1,'cfg_opt_t']]],
  ['validcb2_1',['validcb2',['../structcfg__opt__t.html#a8a6eefc8e2c0efe76587fef68c5c3331',1,'cfg_opt_t']]],
  ['values_2',['values',['../structcfg__opt__t.html#aed01618b386409cdd2305ba2ec3b5028',1,'cfg_opt_t']]]
];
