var searchData=
[
  ['errfunc_0',['errfunc',['../structcfg__t.html#a63b77129d671d1a7b2179c2aeb52ad10',1,'cfg_t']]]
];
