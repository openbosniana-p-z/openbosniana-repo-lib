var searchData=
[
  ['opts_0',['opts',['../structcfg__t.html#a2afb9c3a1087ff2cecd893ff7ab65123',1,'cfg_t']]]
];
