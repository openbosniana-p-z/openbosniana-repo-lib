var searchData=
[
  ['name_0',['name',['../structcfg__t.html#a725fb2555ab71a36eb8f5c461c731e64',1,'cfg_t::name()'],['../structcfg__opt__t.html#a0754fed6c0e415e12d7fe4ecfd2b3295',1,'cfg_opt_t::name()']]],
  ['number_1',['number',['../unioncfg__value__t.html#aa72899aba82866c330379808f5a92b82',1,'cfg_value_t::number()'],['../structcfg__defvalue__t.html#a068568c644c8991d477c3d2793d5556a',1,'cfg_defvalue_t::number()']]],
  ['nvalues_2',['nvalues',['../structcfg__opt__t.html#af6c23c379f0c391d665faeaaf9c49d64',1,'cfg_opt_t']]]
];
