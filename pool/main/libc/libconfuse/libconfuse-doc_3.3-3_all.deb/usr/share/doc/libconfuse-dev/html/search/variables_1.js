var searchData=
[
  ['comment_0',['comment',['../structcfg__t.html#ab4be96e6713f164062c07b4e2a2c51b2',1,'cfg_t::comment()'],['../structcfg__opt__t.html#a8eac503e744faf87c8ec1cdb7f6d8648',1,'cfg_opt_t::comment()']]]
];
