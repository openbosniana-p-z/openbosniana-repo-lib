// Copyright (c) 2006-2018 Maxim Khizhinsky
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef CDSLIB_OS_HPUX_TIMER_H
#define CDSLIB_OS_HPUX_TIMER_H

#include <cds/os/sunos/timer.h>

#endif // #ifndef CDSLIB_OS_HPUX_TIMER_H
