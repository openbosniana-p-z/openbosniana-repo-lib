#ifndef _LIBHX_INIT_H
#define _LIBHX_INIT_H 1

#ifdef __cplusplus
extern "C" {
#endif

extern int HX_init(void);
extern void HX_exit(void);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* _LIBHX_INIT_H */
