package HTML::Prototype::Js;

use strict;

open(DATA, '<', '/usr/share/javascript/prototype/prototype.js');

1;

=head1 NAME

HTML::Prototype::Js - prototype library, embedded in perl

=head1 SYNOPSIS

    our $prototype = do { package HTML::Prototype::Js; local $/; <DATA> };

=head1 DESCRIPTION

This is the actual Prototype library embedded in a perl __DATA__
section, for easy inclusion in L<HTML::Prototype>.


=head1 NEW SYNTAX

The prototype library  provides some functions and classes which effectively
change the basic syntax of the JavaScript you write.

=over 4

=item $(element)

This function takes an element / element list and gets all string elements
using document.getElementbyId. This is probably one of the most common
functions when using javascript for web development, so it will save you
a lot of typing.

=item Class

This uses fucntion references to allow namespace-like Class structures
in javascript.

=item Object.extend

Simple inheritance for javacsript. Will set all properties of the child
in the parent.

=item Function.bind

Allow function refs to be full object method references, through the use
of extend and apply


=item  Try.these

Simple try/catch for a list of functions, will return the return value
of the first that doesn't throw an exception.

=item Array.push

implement push for arrays. returns number of elements in result.

=item Function.apply

Call a function on a given object, using eval.

=back

=head1 JS OBJECTS

The Prototype library provides a number of classes you can use
to improve interaction with the end user.

=over 4

=item Ajax

Provides one useful function, getTransport. This function
will return a XMLHttpRequest object suitable for your browser.

=item Ajax.Base

An abstract base class for the Ajax objects described below. Sets
some common options for Ajax objects;
  B<method:> http method, defaults to post.
  B<asynchronous:> process in the background, true/false, defaults to true.
  B<parameters:> extra parameters, defaults to blank.

=item Ajax.Updater

a subclass of Ajax.Base, this class uses Ajax.Request to populate
a container in your web page. Takes container, url and Ajax.Base
options as parameters.

=item Ajax.Request

This object represents a plain ajax request. It extends base to
add a constructor, as well as some events to handle events.
The constructor takes  an url, as well as the options described
in Ajax.Base.
Currently handles the following events:
  'Uninitialized', 'Loading', 'Loaded', 'Interactive', 'Complete'

=item Effect.Appear

Takes an element, and makes that element appear through a fade.

=item Effect.ContentZoom

Takes an element, and zooms the content of that element.

=item Effect.Fade

Takes an element, and makes that element fade out and disappear.

=item Effect.Highlight

Takes an element, and does a highlight of that element.

=item Effect.Puff

Takes an element, and makes that element "blow up" and disappear.
(As in disappear in a puff of smoke).

=item Effect.Scale

Takes an element, and a size, in percent, and scales that element to
the given size. If it's a div, the initial size will have to be given
in EM. No such restrictions for pictures.

=item Effect.Squish

Takes an element, and shrinks that element until it disappears.

=item Element

A collection of functions related to basic elements. takes one or more elements.
  B<toggle:> Toggles the element display style.
  B<hide:> Turns off the element's display style.
  B<show:> Turns on the element's display style.
  B<remove:> Delete this element from the DOM.
  B<getHeight:> Get the element height.

Also provides a convenience object, Toggle, with one method display which aliases to toggle,
so you can call it as
  Toggle.display(element)

=item Field

Adds some useful functions to HTML Fields with several elements:
  B<clear:> remove all content.
  B<focus:> Give the element focus.
  B<present:> returns true if all arguments are filled in, false otherwise.
  B<select(element):> Select the given element in a form.
  B<activate(element):> give the selected element focus, and select it.

=item Form

Some useful utilies for HTML Forms. all of these take a form element
as sole argument.
  B<serialize:> returns a URL serialized version of a given form.
  B<getElements:> returns all elements in the form.
  B<disable:> blurs and disables every element in the form.
  B<focusFirstElement:> Give first element in the form focus.
  B<reset:> reset all form elements.

=item Form.Element

Some useful objects for Form Field Elements. These take an element
as the sole argument.
  B<serialize:> url encode the element for use in a URI string.
  B<getValue:> returns the value of the given element.

=item Form.Element.Observer

=item Form.Element.Serializers

Serializers for various element types. Takes the input element as
argument.
  B<input:> determines the element type, and chooses the right serializer.
  B<inputSelector:> serialize checkbox/radio.

=item Form.Element.Observer

=item Insertion

This can be used in place of a innerHTML, to insert the content into
the dom.

=item Insertion.Before

Puts content before a given dom node.

=item Insertion.Top

Puts content at the top of a given dom node.

=item Insertion.Bottom

Puts content at the bottom of a given dom node.

=item Insertion.After

Puts content after a given dom node.

=item PeriodicalExecuter

This object takes two parameters, a reference to a callback
function, and a frequency in seconds. It will execute the callback
every <frequency> second.

=back

=head1 SEE ALSO

L<HTML::Prototype>, L<Catalyst::Plugin::Prototype>
L<http://prototype.conio.net/>

=head1 AUTHOR

Sebastian Riedel, C<sri@oook.de>
Marcus Ramberg, C<mramberg@cpan.org>

Built around Prototype by Sam Stephenson.
Much code is ported from Ruby on Rails javascript helpers.

=head1 LICENSE

This library is free software. You can redistribute it and/or modify it under
the same terms as perl itself.

=cut
