package HTML::Prototype::DragDrop;

use strict;

open(DATA, '<', '/usr/share/javascript/scriptaculous/dragdrop.js');

1;

=head1 NAME

HTML::Prototype::DragDrop - script.aculo.us dragdrop library, embedded in perl

=head1 SYNOPSIS

    our $dragdrop = do { package HTML::Prototype::DragDrop; local $/; <DATA> };

=head1 DESCRIPTION

This is the script.aculo.us dragdrop library embedded in a perl __DATA__
section, for easy inclusion in L<HTML::Prototype>.

=head1 SEE ALSO

L<HTML::Prototype>, L<Catalyst::Plugin::Prototype>
L<http://prototype.conio.net/>

=head1 AUTHOR

Sebastian Riedel, C<sri@oook.de>

dragdrop.js by Thomas Fuchs

=head1 LICENSE

This library is free software. You can redistribute it and/or modify it under
the same terms as perl itself.

=cut
