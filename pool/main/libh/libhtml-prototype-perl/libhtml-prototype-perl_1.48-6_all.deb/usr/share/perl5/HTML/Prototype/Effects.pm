package HTML::Prototype::Effects;

use strict;

open(DATA, '<', '/usr/share/javascript/scriptaculous/effects.js');

1;

=head1 NAME

HTML::Prototype::Effects - script.aculo.us effects library, embedded in perl

=head1 SYNOPSIS

    our $effects= do { package HTML::Prototype::Effects; local $/; <DATA> };

=head1 DESCRIPTION

This is the script.aculo.us effects library embedded in a perl __DATA__
section, for easy inclusion in L<HTML::Prototype>.

=head1 SEE ALSO

L<HTML::Prototype>, L<Catalyst::Plugin::Prototype>
L<http://prototype.conio.net/>

=head1 AUTHOR

Sebastian Riedel, C<sri@oook.de>

effects.js by Thomas Fuchs

=head1 LICENSE

This library is free software. You can redistribute it and/or modify it under
the same terms as perl itself.

=cut
