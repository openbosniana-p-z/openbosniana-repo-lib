Readme for HBA API


****************************************************************
History
****************************************************************
03/04/02 - Up to date with Version 18 of the Phase II doc, now on to T11
01/01/01 - Working copy of HBA API distribution for comments
11/11/01 - Rev 2 work ready for review, SNIA license installed
11/14/01 - Rev 2 work is is branched off of the V1_1 tag at SourceForge
11/27/01 - Rev 2 - Updates for Win32 from Veritas


****************************************************************
Version Control (this section of the file is now on SNIA ftp site):
****************************************************************

The SNIA HBA API uses CVS as its software version control mechanism.
The CVS repository for the SNIA HBA API is hosted at SourceForge.net.
Go to http://hbaapi.sourceforge.net/, click on "Source".

To checkout a copy of the HBA API development kit, you must have CVS
installed on your workstation.  From the command line, you must first
log in:

  cvs -d:pserver:anonymous@cvs.hbaapi.sourceforge.net:/cvsroot/hbaapi \
  login

When prompted for a password, simply press the Enter key.  Then
checkout the the latest revision in the main branch with:

  cvs -z3 \
  -d:pserver:anonymous@cvs.hbaapi.sourceforge.net:/cvsroot/hbaapi \
  co hbaapi

Developers may want a development branch of the main branch:

  cvs -z3 \
  -d:pserver:anonymous@cvs.hbaapi.sourceforge.net:/cvsroot/hbaapi \
  co -r V2_0_development hbaapi


The development version of Rev 2 of the HBA API is branched off of the
1.1 version (Symbolically known as V1_1). When it is ready for
release, it will be merged back into the main branch and the revision
will be tagged as V2_0.

    V10
     |
   V1_1
     | \
     |   \
     |   V2_0_development
     |    /
     |  /
    V2_0



*****************************************************************
Build Notes:
****************************************************************

Notes:
) Remember to set POSIX_THREAD in the makefile if you have them.
> It is assumed that WIN32 does not have POSIX_THREADS, but uses 
  the "Critical Section" metaphore.
) See "debuglevel" in hba.conf for runtime diagnostics

To make the NT version:

nmake /f makefile.nt

To make the Solaris version:
(need GNU make)

make -f makefile.solaris

