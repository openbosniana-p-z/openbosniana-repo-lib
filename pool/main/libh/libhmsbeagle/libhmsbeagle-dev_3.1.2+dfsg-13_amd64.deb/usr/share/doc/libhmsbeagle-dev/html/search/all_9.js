var searchData=
[
  ['supportflags_0',['supportFlags',['../struct_beagle_resource.html#a114a8e272a9b10d6e2b1629c3ba62fcd',1,'BeagleResource::supportFlags()'],['../struct_beagle_benchmarked_resource.html#a0b810fec1cbbfbc4e788cf2bf6be0e55',1,'BeagleBenchmarkedResource::supportFlags()']]]
];
