var searchData=
[
  ['partition_0',['partition',['../struct_beagle_operation_by_partition.html#ae9ef88e6e83e1c14015aed04299e13b5',1,'BeagleOperationByPartition']]],
  ['performanceratio_1',['performanceRatio',['../struct_beagle_benchmarked_resource.html#a3191e08e52826ea1d7db0ff76e0e533e',1,'BeagleBenchmarkedResource']]]
];
