var searchData=
[
  ['requiredflags_0',['requiredFlags',['../struct_beagle_resource.html#a84d561923dd65e9bec5a22f2e782a89d',1,'BeagleResource::requiredFlags()'],['../struct_beagle_benchmarked_resource.html#ab569ea3a0212822ff56ecced501bff74',1,'BeagleBenchmarkedResource::requiredFlags()']]],
  ['resourcename_1',['resourceName',['../struct_beagle_instance_details.html#a2f95e32bd70ddef33d3676673e1403ff',1,'BeagleInstanceDetails']]],
  ['resourcenumber_2',['resourceNumber',['../struct_beagle_instance_details.html#a62da477128f3d7d56b58a97445e5c777',1,'BeagleInstanceDetails']]],
  ['returncode_3',['returnCode',['../struct_beagle_benchmarked_resource.html#a4bfdf5eee969369c31e875dc51f148b7',1,'BeagleBenchmarkedResource']]]
];
