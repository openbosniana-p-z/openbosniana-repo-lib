var searchData=
[
  ['description_0',['description',['../struct_beagle_resource.html#a529ec0036f2af507febd15940dc0575b',1,'BeagleResource::description()'],['../struct_beagle_benchmarked_resource.html#aba7569221390a6bb571a68ceaac9c5d6',1,'BeagleBenchmarkedResource::description()']]],
  ['destinationpartials_1',['destinationPartials',['../struct_beagle_operation.html#a7b71c663c3ebcd2fd1bcfcc1862cca51',1,'BeagleOperation::destinationPartials()'],['../struct_beagle_operation_by_partition.html#ab51a7ae44e04d715e5c4c9397547be7f',1,'BeagleOperationByPartition::destinationPartials()']]],
  ['destinationscaleread_2',['destinationScaleRead',['../struct_beagle_operation.html#aa43026ee69fb4af3784704e6ca558708',1,'BeagleOperation::destinationScaleRead()'],['../struct_beagle_operation_by_partition.html#a6950b75470f4b0a32a900101523602c5',1,'BeagleOperationByPartition::destinationScaleRead()']]],
  ['destinationscalewrite_3',['destinationScaleWrite',['../struct_beagle_operation.html#a0e51bf8a58fbb2d25a5fff1d4baa39b7',1,'BeagleOperation::destinationScaleWrite()'],['../struct_beagle_operation_by_partition.html#a683df9935e76b2cbe9aef87e1fc639e0',1,'BeagleOperationByPartition::destinationScaleWrite()']]]
];
