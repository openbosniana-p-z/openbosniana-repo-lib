var searchData=
[
  ['impldescription_0',['implDescription',['../struct_beagle_instance_details.html#a06dd93495752717d4a55a75b3f4452d5',1,'BeagleInstanceDetails']]],
  ['implname_1',['implName',['../struct_beagle_instance_details.html#a05420095a96892a7da9ca33ec737c4a2',1,'BeagleInstanceDetails::implName()'],['../struct_beagle_benchmarked_resource.html#acac744cad6104dd317b4352c0f4929ff',1,'BeagleBenchmarkedResource::implName()']]]
];
