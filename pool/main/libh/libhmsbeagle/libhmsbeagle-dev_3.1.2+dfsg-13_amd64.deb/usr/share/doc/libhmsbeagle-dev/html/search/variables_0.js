var searchData=
[
  ['benchedflags_0',['benchedFlags',['../struct_beagle_benchmarked_resource.html#abb82d15c1b9311565f7944b78a6a452c',1,'BeagleBenchmarkedResource']]],
  ['benchmarkresult_1',['benchmarkResult',['../struct_beagle_benchmarked_resource.html#a5cf04af8e2c44d66263f5c038270d2ba',1,'BeagleBenchmarkedResource']]]
];
