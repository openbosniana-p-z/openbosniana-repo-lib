var searchData=
[
  ['beaglebenchmarkflags_0',['BeagleBenchmarkFlags',['../beagle_8h.html#ace6c4a818d2ba92d592ea248c6f2c3d3',1,'beagle.h']]],
  ['beagleflags_1',['BeagleFlags',['../beagle_8h.html#a3f3abf6b7c463b689a26ec83fb14bdde',1,'beagle.h']]],
  ['beagleopcodes_2',['BeagleOpCodes',['../beagle_8h.html#a2487a1c99f4214cd3a70468d0ccac55c',1,'beagle.h']]],
  ['beaglereturncodes_3',['BeagleReturnCodes',['../beagle_8h.html#a9e61de870cc34893168a88fe6823dfce',1,'beagle.h']]]
];
