var searchData=
[
  ['beaglebenchmarkedresource_0',['BeagleBenchmarkedResource',['../struct_beagle_benchmarked_resource.html',1,'']]],
  ['beaglebenchmarkedresourcelist_1',['BeagleBenchmarkedResourceList',['../struct_beagle_benchmarked_resource_list.html',1,'']]],
  ['beagleinstancedetails_2',['BeagleInstanceDetails',['../struct_beagle_instance_details.html',1,'']]],
  ['beagleoperation_3',['BeagleOperation',['../struct_beagle_operation.html',1,'']]],
  ['beagleoperationbypartition_4',['BeagleOperationByPartition',['../struct_beagle_operation_by_partition.html',1,'']]],
  ['beagleresource_5',['BeagleResource',['../struct_beagle_resource.html',1,'']]],
  ['beagleresourcelist_6',['BeagleResourceList',['../struct_beagle_resource_list.html',1,'']]]
];
