var searchData=
[
  ['flags_0',['flags',['../struct_beagle_instance_details.html#a73d2211c0f0d5b730d7a768155ff0be4',1,'BeagleInstanceDetails']]]
];
