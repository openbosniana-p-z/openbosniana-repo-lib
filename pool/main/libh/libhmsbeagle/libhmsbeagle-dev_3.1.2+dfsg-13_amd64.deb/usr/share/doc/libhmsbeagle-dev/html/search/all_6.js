var searchData=
[
  ['name_0',['name',['../struct_beagle_resource.html#adc4f25e6c9f6b62c0ca00d41fd5e99f7',1,'BeagleResource::name()'],['../struct_beagle_benchmarked_resource.html#ad3e5c07a61338220695400193af7e988',1,'BeagleBenchmarkedResource::name()']]],
  ['number_1',['number',['../struct_beagle_benchmarked_resource.html#a8c83b06e3f9dfc595badc804cc84d959',1,'BeagleBenchmarkedResource']]]
];
