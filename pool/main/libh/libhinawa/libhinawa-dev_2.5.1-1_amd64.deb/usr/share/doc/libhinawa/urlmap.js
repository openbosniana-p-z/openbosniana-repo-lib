baseURLs = [
    [ 'GLib', 'https://docs.gtk.org/glib/' ],
    [ 'GObject', 'https://docs.gtk.org/gobject/' ],
    [ 'Hitaki', 'http://alsa-project.github.io/gobject-introspection-docs/hitaki' ],
]
