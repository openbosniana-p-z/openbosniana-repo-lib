
#ifndef KEDUVOCDOCUMENT_EXPORT_H
#define KEDUVOCDOCUMENT_EXPORT_H

#ifdef KEDUVOCDOCUMENT_STATIC_DEFINE
#  define KEDUVOCDOCUMENT_EXPORT
#  define KEDUVOCDOCUMENT_NO_EXPORT
#else
#  ifndef KEDUVOCDOCUMENT_EXPORT
#    ifdef KEduVocDocument_EXPORTS
        /* We are building this library */
#      define KEDUVOCDOCUMENT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KEDUVOCDOCUMENT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KEDUVOCDOCUMENT_NO_EXPORT
#    define KEDUVOCDOCUMENT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KEDUVOCDOCUMENT_DEPRECATED
#  define KEDUVOCDOCUMENT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KEDUVOCDOCUMENT_DEPRECATED_EXPORT
#  define KEDUVOCDOCUMENT_DEPRECATED_EXPORT KEDUVOCDOCUMENT_EXPORT KEDUVOCDOCUMENT_DEPRECATED
#endif

#ifndef KEDUVOCDOCUMENT_DEPRECATED_NO_EXPORT
#  define KEDUVOCDOCUMENT_DEPRECATED_NO_EXPORT KEDUVOCDOCUMENT_NO_EXPORT KEDUVOCDOCUMENT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KEDUVOCDOCUMENT_NO_DEPRECATED
#    define KEDUVOCDOCUMENT_NO_DEPRECATED
#  endif
#endif

#endif /* KEDUVOCDOCUMENT_EXPORT_H */
