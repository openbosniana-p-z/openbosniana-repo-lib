
#ifndef KCOMPACTDISC_EXPORT_H
#define KCOMPACTDISC_EXPORT_H

#ifdef KCOMPACTDISC_STATIC_DEFINE
#  define KCOMPACTDISC_EXPORT
#  define KCOMPACTDISC_NO_EXPORT
#else
#  ifndef KCOMPACTDISC_EXPORT
#    ifdef KCompactDisc_EXPORTS
        /* We are building this library */
#      define KCOMPACTDISC_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KCOMPACTDISC_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KCOMPACTDISC_NO_EXPORT
#    define KCOMPACTDISC_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KCOMPACTDISC_DEPRECATED
#  define KCOMPACTDISC_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KCOMPACTDISC_DEPRECATED_EXPORT
#  define KCOMPACTDISC_DEPRECATED_EXPORT KCOMPACTDISC_EXPORT KCOMPACTDISC_DEPRECATED
#endif

#ifndef KCOMPACTDISC_DEPRECATED_NO_EXPORT
#  define KCOMPACTDISC_DEPRECATED_NO_EXPORT KCOMPACTDISC_NO_EXPORT KCOMPACTDISC_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KCOMPACTDISC_NO_DEPRECATED
#    define KCOMPACTDISC_NO_DEPRECATED
#  endif
#endif

#endif /* KCOMPACTDISC_EXPORT_H */
