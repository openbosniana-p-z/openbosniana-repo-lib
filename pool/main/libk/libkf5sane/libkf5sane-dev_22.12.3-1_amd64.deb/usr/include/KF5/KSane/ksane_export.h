
#ifndef KSANE_EXPORT_H
#define KSANE_EXPORT_H

#ifdef KSANE_STATIC_DEFINE
#  define KSANE_EXPORT
#  define KSANE_NO_EXPORT
#else
#  ifndef KSANE_EXPORT
#    ifdef KF5Sane_EXPORTS
        /* We are building this library */
#      define KSANE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KSANE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KSANE_NO_EXPORT
#    define KSANE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KSANE_DEPRECATED
#  define KSANE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KSANE_DEPRECATED_EXPORT
#  define KSANE_DEPRECATED_EXPORT KSANE_EXPORT KSANE_DEPRECATED
#endif

#ifndef KSANE_DEPRECATED_NO_EXPORT
#  define KSANE_DEPRECATED_NO_EXPORT KSANE_NO_EXPORT KSANE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KSANE_NO_DEPRECATED
#    define KSANE_NO_DEPRECATED
#  endif
#endif

#endif /* KSANE_EXPORT_H */
