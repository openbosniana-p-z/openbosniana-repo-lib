
#ifndef KSCREENDPMS_EXPORT_H
#define KSCREENDPMS_EXPORT_H

#ifdef KSCREENDPMS_STATIC_DEFINE
#  define KSCREENDPMS_EXPORT
#  define KSCREENDPMS_NO_EXPORT
#else
#  ifndef KSCREENDPMS_EXPORT
#    ifdef KF5ScreenDpms_EXPORTS
        /* We are building this library */
#      define KSCREENDPMS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KSCREENDPMS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KSCREENDPMS_NO_EXPORT
#    define KSCREENDPMS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KSCREENDPMS_DEPRECATED
#  define KSCREENDPMS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KSCREENDPMS_DEPRECATED_EXPORT
#  define KSCREENDPMS_DEPRECATED_EXPORT KSCREENDPMS_EXPORT KSCREENDPMS_DEPRECATED
#endif

#ifndef KSCREENDPMS_DEPRECATED_NO_EXPORT
#  define KSCREENDPMS_DEPRECATED_NO_EXPORT KSCREENDPMS_NO_EXPORT KSCREENDPMS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KSCREENDPMS_NO_DEPRECATED
#    define KSCREENDPMS_NO_DEPRECATED
#  endif
#endif

#endif /* KSCREENDPMS_EXPORT_H */
