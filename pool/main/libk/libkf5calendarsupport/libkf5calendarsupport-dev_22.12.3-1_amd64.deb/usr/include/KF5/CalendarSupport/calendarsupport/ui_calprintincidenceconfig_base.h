#include <klocalizedstring.h>

/*
Configuration page for printing incidences.
*/

/********************************************************************************
** Form generated from reading UI file 'calprintincidenceconfig_base.ui'
**
** Created by: Qt User Interface Compiler version 5.15.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALPRINTINCIDENCECONFIG_BASE_H
#define UI_CALPRINTINCIDENCECONFIG_BASE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CalPrintIncidenceConfig_Base
{
public:
    QVBoxLayout *vboxLayout;
    QLabel *label;
    QGroupBox *mIncludeInfoGroup;
    QVBoxLayout *verticalLayout_2;
    QCheckBox *mShowDetails;
    QCheckBox *mShowAttendees;
    QCheckBox *mShowSubitemsNotes;
    QCheckBox *mShowAttachments;
    QGroupBox *mGeneralGroup;
    QVBoxLayout *verticalLayout;
    QCheckBox *mShowNoteLines;
    QCheckBox *mColors;
    QCheckBox *mPrintFooter;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *CalPrintIncidenceConfig_Base)
    {
        if (CalPrintIncidenceConfig_Base->objectName().isEmpty())
            CalPrintIncidenceConfig_Base->setObjectName(QString::fromUtf8("CalPrintIncidenceConfig_Base"));
        vboxLayout = new QVBoxLayout(CalPrintIncidenceConfig_Base);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        vboxLayout->setContentsMargins(-1, -1, 0, -1);
        label = new QLabel(CalPrintIncidenceConfig_Base);
        label->setObjectName(QString::fromUtf8("label"));

        vboxLayout->addWidget(label);

        mIncludeInfoGroup = new QGroupBox(CalPrintIncidenceConfig_Base);
        mIncludeInfoGroup->setObjectName(QString::fromUtf8("mIncludeInfoGroup"));
        mIncludeInfoGroup->setProperty("selectedId", QVariant(-1));
        verticalLayout_2 = new QVBoxLayout(mIncludeInfoGroup);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        mShowDetails = new QCheckBox(mIncludeInfoGroup);
        mShowDetails->setObjectName(QString::fromUtf8("mShowDetails"));

        verticalLayout_2->addWidget(mShowDetails);

        mShowAttendees = new QCheckBox(mIncludeInfoGroup);
        mShowAttendees->setObjectName(QString::fromUtf8("mShowAttendees"));

        verticalLayout_2->addWidget(mShowAttendees);

        mShowSubitemsNotes = new QCheckBox(mIncludeInfoGroup);
        mShowSubitemsNotes->setObjectName(QString::fromUtf8("mShowSubitemsNotes"));

        verticalLayout_2->addWidget(mShowSubitemsNotes);

        mShowAttachments = new QCheckBox(mIncludeInfoGroup);
        mShowAttachments->setObjectName(QString::fromUtf8("mShowAttachments"));

        verticalLayout_2->addWidget(mShowAttachments);


        vboxLayout->addWidget(mIncludeInfoGroup);

        mGeneralGroup = new QGroupBox(CalPrintIncidenceConfig_Base);
        mGeneralGroup->setObjectName(QString::fromUtf8("mGeneralGroup"));
        verticalLayout = new QVBoxLayout(mGeneralGroup);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        mShowNoteLines = new QCheckBox(mGeneralGroup);
        mShowNoteLines->setObjectName(QString::fromUtf8("mShowNoteLines"));

        verticalLayout->addWidget(mShowNoteLines);

        mColors = new QCheckBox(mGeneralGroup);
        mColors->setObjectName(QString::fromUtf8("mColors"));

        verticalLayout->addWidget(mColors);

        mPrintFooter = new QCheckBox(mGeneralGroup);
        mPrintFooter->setObjectName(QString::fromUtf8("mPrintFooter"));

        verticalLayout->addWidget(mPrintFooter);


        vboxLayout->addWidget(mGeneralGroup);

        verticalSpacer = new QSpacerItem(0, 0, QSizePolicy::Minimum, QSizePolicy::Expanding);

        vboxLayout->addItem(verticalSpacer);


        retranslateUi(CalPrintIncidenceConfig_Base);

        QMetaObject::connectSlotsByName(CalPrintIncidenceConfig_Base);
    } // setupUi

    void retranslateUi(QWidget *CalPrintIncidenceConfig_Base)
    {
        label->setText(tr2i18n("<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">Print incidence options:</span></p></body></html>", nullptr));
        mIncludeInfoGroup->setTitle(tr2i18n("Include Information", nullptr));
#if QT_CONFIG(tooltip)
        mShowDetails->setToolTip(tr2i18n("Print incidence details", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mShowDetails->setWhatsThis(tr2i18n("Check this box if you want to print more details for the incidence, including the visibility and secrecy properties.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mShowDetails->setText(tr2i18n("Detai&ls (visiblility, secrecy, etc.)", nullptr));
#if QT_CONFIG(tooltip)
        mShowAttendees->setToolTip(tr2i18n("Print the attendees", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mShowAttendees->setWhatsThis(tr2i18n("Check this box if you want the attendees list included on the print-out.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mShowAttendees->setText(tr2i18n("&Attendees", nullptr));
#if QT_CONFIG(tooltip)
        mShowSubitemsNotes->setToolTip(tr2i18n("Print the notes", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mShowSubitemsNotes->setWhatsThis(tr2i18n("Check this box if you want the incidence notes included on the print-out.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mShowSubitemsNotes->setText(tr2i18n("&Notes, subitems", nullptr));
#if QT_CONFIG(tooltip)
        mShowAttachments->setToolTip(tr2i18n("Print the attachments", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mShowAttachments->setWhatsThis(tr2i18n("Check this box if you want the attachment information included on the print-out. The attachments themselves are not printed.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mShowAttachments->setText(tr2i18n("Attach&ments", nullptr));
        mGeneralGroup->setTitle(tr2i18n("General", "@title general print settings"));
#if QT_CONFIG(tooltip)
        mShowNoteLines->setToolTip(tr2i18n("Check this option to draw note lines in empty areas.", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mShowNoteLines->setWhatsThis(tr2i18n("Check this box if you want to draw note lines in the empty area of the print. This is useful if you want to hand-write notes on this print-out.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mShowNoteLines->setText(tr2i18n("Show note &lines", nullptr));
#if QT_CONFIG(tooltip)
        mColors->setToolTip(tr2i18n("Print in color", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mColors->setWhatsThis(tr2i18n("If you want to use colors to distinguish certain tags in the printed output, check this option.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mColors->setText(tr2i18n("&Use colors", nullptr));
#if QT_CONFIG(tooltip)
        mPrintFooter->setToolTip(tr2i18n("Print a datetime footer on each page", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mPrintFooter->setWhatsThis(tr2i18n("Check this box if you want to print a small footer on each page that contains the date of the print.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mPrintFooter->setText(tr2i18n("Print &Footer", nullptr));
        (void)CalPrintIncidenceConfig_Base;
    } // retranslateUi

};

namespace Ui {
    class CalPrintIncidenceConfig_Base: public Ui_CalPrintIncidenceConfig_Base {};
} // namespace Ui

QT_END_NAMESPACE

#endif // CALPRINTINCIDENCECONFIG_BASE_H

