
#ifndef CALENDARSUPPORT_EXPORT_H
#define CALENDARSUPPORT_EXPORT_H

#ifdef CALENDARSUPPORT_STATIC_DEFINE
#  define CALENDARSUPPORT_EXPORT
#  define CALENDARSUPPORT_NO_EXPORT
#else
#  ifndef CALENDARSUPPORT_EXPORT
#    ifdef KF5CalendarSupport_EXPORTS
        /* We are building this library */
#      define CALENDARSUPPORT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define CALENDARSUPPORT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef CALENDARSUPPORT_NO_EXPORT
#    define CALENDARSUPPORT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef CALENDARSUPPORT_DEPRECATED
#  define CALENDARSUPPORT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef CALENDARSUPPORT_DEPRECATED_EXPORT
#  define CALENDARSUPPORT_DEPRECATED_EXPORT CALENDARSUPPORT_EXPORT CALENDARSUPPORT_DEPRECATED
#endif

#ifndef CALENDARSUPPORT_DEPRECATED_NO_EXPORT
#  define CALENDARSUPPORT_DEPRECATED_NO_EXPORT CALENDARSUPPORT_NO_EXPORT CALENDARSUPPORT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef CALENDARSUPPORT_NO_DEPRECATED
#    define CALENDARSUPPORT_NO_DEPRECATED
#  endif
#endif

#endif /* CALENDARSUPPORT_EXPORT_H */
