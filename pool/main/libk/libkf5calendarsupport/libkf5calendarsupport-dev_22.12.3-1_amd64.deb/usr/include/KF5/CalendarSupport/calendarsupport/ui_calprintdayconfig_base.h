#include <klocalizedstring.h>

/*
Configuration page for the print day mode.
*/

/********************************************************************************
** Form generated from reading UI file 'calprintdayconfig_base.ui'
**
** Created by: Qt User Interface Compiler version 5.15.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALPRINTDAYCONFIG_BASE_H
#define UI_CALPRINTDAYCONFIG_BASE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "kdatecombobox.h"

QT_BEGIN_NAMESPACE

class Ui_CalPrintDayConfig_Base
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QGroupBox *mDateRangeGroup;
    QGridLayout *gridLayout;
    QLabel *mFromDateLabel;
    KDateComboBox *mFromDate;
    QLabel *mFromTimeLabel;
    QTimeEdit *mFromTime;
    QSpacerItem *spacerItem;
    QLabel *mToDateLabel;
    KDateComboBox *mToDate;
    QLabel *mToTimeLabel;
    QTimeEdit *mToTime;
    QSpacerItem *spacerItem1;
    QCheckBox *mIncludeAllEvents;
    QGroupBox *mPrintType;
    QVBoxLayout *vboxLayout;
    QRadioButton *mPrintTypeFilofax;
    QRadioButton *mPrintTypeTimetable;
    QRadioButton *mPrintTypeSingleTimetable;
    QGroupBox *mSecurity;
    QHBoxLayout *horizontalLayout;
    QCheckBox *mExcludeConfidential;
    QCheckBox *mExcludePrivate;
    QGroupBox *mIncludeInfoGroup;
    QGridLayout *includeInfoLayout;
    QCheckBox *mIncludeDescription;
    QCheckBox *mIncludeCategories;
    QCheckBox *mIncludeTodos;
    QCheckBox *mExcludeTime;
    QGroupBox *mGeneralGroup;
    QVBoxLayout *generalLayout;
    QCheckBox *mSingleLineLimit;
    QCheckBox *mShowNoteLines;
    QCheckBox *mColors;
    QCheckBox *mPrintFooter;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *CalPrintDayConfig_Base)
    {
        if (CalPrintDayConfig_Base->objectName().isEmpty())
            CalPrintDayConfig_Base->setObjectName(QString::fromUtf8("CalPrintDayConfig_Base"));
        verticalLayout = new QVBoxLayout(CalPrintDayConfig_Base);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(-1, -1, 0, -1);
        label = new QLabel(CalPrintDayConfig_Base);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        mDateRangeGroup = new QGroupBox(CalPrintDayConfig_Base);
        mDateRangeGroup->setObjectName(QString::fromUtf8("mDateRangeGroup"));
        gridLayout = new QGridLayout(mDateRangeGroup);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        mFromDateLabel = new QLabel(mDateRangeGroup);
        mFromDateLabel->setObjectName(QString::fromUtf8("mFromDateLabel"));

        gridLayout->addWidget(mFromDateLabel, 0, 0, 1, 1);

        mFromDate = new KDateComboBox(mDateRangeGroup);
        mFromDate->addItem(QString());
        mFromDate->setObjectName(QString::fromUtf8("mFromDate"));
        mFromDate->setFocusPolicy(Qt::StrongFocus);

        gridLayout->addWidget(mFromDate, 0, 1, 1, 1);

        mFromTimeLabel = new QLabel(mDateRangeGroup);
        mFromTimeLabel->setObjectName(QString::fromUtf8("mFromTimeLabel"));

        gridLayout->addWidget(mFromTimeLabel, 0, 2, 1, 1);

        mFromTime = new QTimeEdit(mDateRangeGroup);
        mFromTime->setObjectName(QString::fromUtf8("mFromTime"));
        mFromTime->setTime(QTime(8, 0, 0));

        gridLayout->addWidget(mFromTime, 0, 3, 1, 1);

        spacerItem = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(spacerItem, 0, 4, 1, 1);

        mToDateLabel = new QLabel(mDateRangeGroup);
        mToDateLabel->setObjectName(QString::fromUtf8("mToDateLabel"));

        gridLayout->addWidget(mToDateLabel, 1, 0, 1, 1);

        mToDate = new KDateComboBox(mDateRangeGroup);
        mToDate->addItem(QString());
        mToDate->setObjectName(QString::fromUtf8("mToDate"));
        mToDate->setFocusPolicy(Qt::StrongFocus);

        gridLayout->addWidget(mToDate, 1, 1, 1, 1);

        mToTimeLabel = new QLabel(mDateRangeGroup);
        mToTimeLabel->setObjectName(QString::fromUtf8("mToTimeLabel"));

        gridLayout->addWidget(mToTimeLabel, 1, 2, 1, 1);

        mToTime = new QTimeEdit(mDateRangeGroup);
        mToTime->setObjectName(QString::fromUtf8("mToTime"));
        mToTime->setTime(QTime(18, 0, 0));

        gridLayout->addWidget(mToTime, 1, 3, 1, 1);

        spacerItem1 = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(spacerItem1, 1, 4, 1, 1);

        mIncludeAllEvents = new QCheckBox(mDateRangeGroup);
        mIncludeAllEvents->setObjectName(QString::fromUtf8("mIncludeAllEvents"));

        gridLayout->addWidget(mIncludeAllEvents, 2, 0, 1, 5);


        verticalLayout->addWidget(mDateRangeGroup);

        mPrintType = new QGroupBox(CalPrintDayConfig_Base);
        mPrintType->setObjectName(QString::fromUtf8("mPrintType"));
        vboxLayout = new QVBoxLayout(mPrintType);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        mPrintTypeFilofax = new QRadioButton(mPrintType);
        mPrintTypeFilofax->setObjectName(QString::fromUtf8("mPrintTypeFilofax"));

        vboxLayout->addWidget(mPrintTypeFilofax);

        mPrintTypeTimetable = new QRadioButton(mPrintType);
        mPrintTypeTimetable->setObjectName(QString::fromUtf8("mPrintTypeTimetable"));

        vboxLayout->addWidget(mPrintTypeTimetable);

        mPrintTypeSingleTimetable = new QRadioButton(mPrintType);
        mPrintTypeSingleTimetable->setObjectName(QString::fromUtf8("mPrintTypeSingleTimetable"));

        vboxLayout->addWidget(mPrintTypeSingleTimetable);


        verticalLayout->addWidget(mPrintType);

        mSecurity = new QGroupBox(CalPrintDayConfig_Base);
        mSecurity->setObjectName(QString::fromUtf8("mSecurity"));
        horizontalLayout = new QHBoxLayout(mSecurity);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        mExcludeConfidential = new QCheckBox(mSecurity);
        mExcludeConfidential->setObjectName(QString::fromUtf8("mExcludeConfidential"));

        horizontalLayout->addWidget(mExcludeConfidential);

        mExcludePrivate = new QCheckBox(mSecurity);
        mExcludePrivate->setObjectName(QString::fromUtf8("mExcludePrivate"));

        horizontalLayout->addWidget(mExcludePrivate);


        verticalLayout->addWidget(mSecurity);

        mIncludeInfoGroup = new QGroupBox(CalPrintDayConfig_Base);
        mIncludeInfoGroup->setObjectName(QString::fromUtf8("mIncludeInfoGroup"));
        includeInfoLayout = new QGridLayout(mIncludeInfoGroup);
        includeInfoLayout->setObjectName(QString::fromUtf8("includeInfoLayout"));
        mIncludeDescription = new QCheckBox(mIncludeInfoGroup);
        mIncludeDescription->setObjectName(QString::fromUtf8("mIncludeDescription"));

        includeInfoLayout->addWidget(mIncludeDescription, 0, 0, 1, 1);

        mIncludeCategories = new QCheckBox(mIncludeInfoGroup);
        mIncludeCategories->setObjectName(QString::fromUtf8("mIncludeCategories"));

        includeInfoLayout->addWidget(mIncludeCategories, 0, 1, 1, 1);

        mIncludeTodos = new QCheckBox(mIncludeInfoGroup);
        mIncludeTodos->setObjectName(QString::fromUtf8("mIncludeTodos"));
        mIncludeTodos->setEnabled(false);

        includeInfoLayout->addWidget(mIncludeTodos, 1, 0, 1, 2);

        mExcludeTime = new QCheckBox(mIncludeInfoGroup);
        mExcludeTime->setObjectName(QString::fromUtf8("mExcludeTime"));

        includeInfoLayout->addWidget(mExcludeTime, 2, 0, 1, 2);


        verticalLayout->addWidget(mIncludeInfoGroup);

        mGeneralGroup = new QGroupBox(CalPrintDayConfig_Base);
        mGeneralGroup->setObjectName(QString::fromUtf8("mGeneralGroup"));
        generalLayout = new QVBoxLayout(mGeneralGroup);
        generalLayout->setObjectName(QString::fromUtf8("generalLayout"));
        mSingleLineLimit = new QCheckBox(mGeneralGroup);
        mSingleLineLimit->setObjectName(QString::fromUtf8("mSingleLineLimit"));

        generalLayout->addWidget(mSingleLineLimit);

        mShowNoteLines = new QCheckBox(mGeneralGroup);
        mShowNoteLines->setObjectName(QString::fromUtf8("mShowNoteLines"));

        generalLayout->addWidget(mShowNoteLines);

        mColors = new QCheckBox(mGeneralGroup);
        mColors->setObjectName(QString::fromUtf8("mColors"));

        generalLayout->addWidget(mColors);

        mPrintFooter = new QCheckBox(mGeneralGroup);
        mPrintFooter->setObjectName(QString::fromUtf8("mPrintFooter"));

        generalLayout->addWidget(mPrintFooter);


        verticalLayout->addWidget(mGeneralGroup);

        verticalSpacer = new QSpacerItem(0, 0, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

#if QT_CONFIG(shortcut)
        mFromDateLabel->setBuddy(mFromDate);
        mFromTimeLabel->setBuddy(mFromTime);
        mToDateLabel->setBuddy(mToDate);
        mToTimeLabel->setBuddy(mToTime);
#endif // QT_CONFIG(shortcut)

        retranslateUi(CalPrintDayConfig_Base);

        QMetaObject::connectSlotsByName(CalPrintDayConfig_Base);
    } // setupUi

    void retranslateUi(QWidget *CalPrintDayConfig_Base)
    {
        label->setText(tr2i18n("<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">Print day options:</span></p></body></html>", nullptr));
        mDateRangeGroup->setTitle(tr2i18n("Date && Time Range", nullptr));
#if QT_CONFIG(tooltip)
        mFromDateLabel->setToolTip(tr2i18n("Starting date for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mFromDateLabel->setWhatsThis(tr2i18n("If you want to print more days at once, you can define a range of dates with this option and the <i>End date</i> option. This option is used to define the start date.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mFromDateLabel->setText(tr2i18n("&Start date:", nullptr));
        mFromDate->setItemText(0, tr2i18n("2009-01-19", nullptr));

#if QT_CONFIG(tooltip)
        mFromDate->setToolTip(tr2i18n("Starting date for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mFromDate->setWhatsThis(tr2i18n("If you want to print more days at once, you can define a range of dates with this option and the <i>End date</i> option. This option is used to define the start date.", nullptr));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(tooltip)
        mFromTimeLabel->setToolTip(tr2i18n("Starting time for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mFromTimeLabel->setWhatsThis(tr2i18n("It is possible to print only those events which are inside a given time range. With this time selection box you can define the start of this time range. The end time should be defined with the <i>End time</i> option. Note you can automatically modify these settings if you check <i>Extend time range to include all events</i>.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mFromTimeLabel->setText(tr2i18n("Start &time:", nullptr));
#if QT_CONFIG(tooltip)
        mFromTime->setToolTip(tr2i18n("Starting time for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mFromTime->setWhatsThis(tr2i18n("It is possible to print only those events which are inside a given time range. With this time selection box you can define the start of this time range. The end time should be defined with the <i>End time</i> option. Note you can automatically modify these settings if you check <i>Extend time range to include all events</i>.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mFromTime->setDisplayFormat(tr2i18n("hh:mm", nullptr));
#if QT_CONFIG(tooltip)
        mToDateLabel->setToolTip(tr2i18n("Ending date for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mToDateLabel->setWhatsThis(tr2i18n("If you want to print more days at once, you can define a range of dates with this option and the <i>Start date</i> option. This option is used to define the end date.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mToDateLabel->setText(tr2i18n("&End date:", nullptr));
        mToDate->setItemText(0, tr2i18n("2009-01-19", nullptr));

#if QT_CONFIG(tooltip)
        mToDate->setToolTip(tr2i18n("Ending date for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mToDate->setWhatsThis(tr2i18n("If you want to print more days at once, you can define a range of dates with this option and the <i>Start date</i> option. This option is used to define the end date.", nullptr));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(tooltip)
        mToTimeLabel->setToolTip(tr2i18n("Ending time for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mToTimeLabel->setWhatsThis(tr2i18n("It is possible to print only those events which are inside a given time range. With this time selection box you can define the end of this time range. The start time should be defined with the <i>Start time</i> option. Note you can automatically modify these settings if you check <i>Extend time range to include all events</i>.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mToTimeLabel->setText(tr2i18n("End ti&me:", nullptr));
#if QT_CONFIG(tooltip)
        mToTime->setToolTip(tr2i18n("Ending time for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mToTime->setWhatsThis(tr2i18n("It is possible to print only those events which are inside a given time range. With this time selection box you can define the end of this time range. The start time should be defined with the <i>Start time</i> option. Note you can automatically modify these settings if you check <i>Extend time range to include all events</i>.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mToTime->setDisplayFormat(tr2i18n("hh:mm", nullptr));
#if QT_CONFIG(tooltip)
        mIncludeAllEvents->setToolTip(tr2i18n("Check this option to automatically determine the required time range, so all events will be shown.", nullptr));
#endif // QT_CONFIG(tooltip)
        mIncludeAllEvents->setText(tr2i18n("E&xtend time range to include all events", nullptr));
        mPrintType->setTitle(tr2i18n("Print Layout", nullptr));
#if QT_CONFIG(tooltip)
        mPrintTypeFilofax->setToolTip(tr2i18n("The Filofax format prints the information for the days selected without a timeline.", nullptr));
#endif // QT_CONFIG(tooltip)
        mPrintTypeFilofax->setText(tr2i18n("Print date &range as Filofax format, all on one page", nullptr));
#if QT_CONFIG(tooltip)
        mPrintTypeTimetable->setToolTip(tr2i18n("The timetable print view has the times to the left of the page.", nullptr));
#endif // QT_CONFIG(tooltip)
        mPrintTypeTimetable->setText(tr2i18n("Print as timeta&ble view, one page per day", nullptr));
#if QT_CONFIG(tooltip)
        mPrintTypeSingleTimetable->setToolTip(tr2i18n("The timetable print view has the times to the left of the page. All days are printed as columns in one big timetable.", nullptr));
#endif // QT_CONFIG(tooltip)
        mPrintTypeSingleTimetable->setText(tr2i18n("Print as timetable view, all da&ys on a single page", nullptr));
        mSecurity->setTitle(tr2i18n("Security Exclusions", nullptr));
#if QT_CONFIG(tooltip)
        mExcludeConfidential->setToolTip(tr2i18n("Check this option to exclude items that have their Access level set to \342\200\234Confidential\342\200\235", nullptr));
#endif // QT_CONFIG(tooltip)
        mExcludeConfidential->setText(tr2i18n("Exclude c&onfidential", nullptr));
#if QT_CONFIG(tooltip)
        mExcludePrivate->setToolTip(tr2i18n("Check this option to exclude items that have their Access level set to \342\200\234Private\342\200\235", nullptr));
#endif // QT_CONFIG(tooltip)
        mExcludePrivate->setText(tr2i18n("Exclude pri&vate", nullptr));
        mIncludeInfoGroup->setTitle(tr2i18n("Include Information", nullptr));
#if QT_CONFIG(tooltip)
        mIncludeDescription->setToolTip(tr2i18n("Print item descriptions", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mIncludeDescription->setWhatsThis(tr2i18n("Check this option if you want to see the item descriptions printed.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mIncludeDescription->setText(tr2i18n("&Descriptions", nullptr));
#if QT_CONFIG(tooltip)
        mIncludeCategories->setToolTip(tr2i18n("Print item tags", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mIncludeCategories->setWhatsThis(tr2i18n("Check this option if you want to see the item tags printed.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mIncludeCategories->setText(tr2i18n("Ta&gs", nullptr));
#if QT_CONFIG(tooltip)
        mIncludeTodos->setToolTip(tr2i18n("Print to-dos due within the specified date range", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mIncludeTodos->setWhatsThis(tr2i18n("You should check this option if you want to print to-dos which are due on one of the dates which are in the supplied date range.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mIncludeTodos->setText(tr2i18n("Include to-&dos that are due on the printed day(s)", nullptr));
#if QT_CONFIG(tooltip)
        mExcludeTime->setToolTip(tr2i18n("Check this option to exclude the time in description box", nullptr));
#endif // QT_CONFIG(tooltip)
        mExcludeTime->setText(tr2i18n("Exclude t&ime from timetable detail display items", nullptr));
        mGeneralGroup->setTitle(tr2i18n("General", "@title general print settings"));
#if QT_CONFIG(tooltip)
        mSingleLineLimit->setToolTip(tr2i18n("Print items on one line", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mSingleLineLimit->setWhatsThis(tr2i18n("Check this option to limit events to a single line, truncating as necessary to save space.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mSingleLineLimit->setText(tr2i18n("Limit events in each day to a &single line", nullptr));
#if QT_CONFIG(tooltip)
        mShowNoteLines->setToolTip(tr2i18n("Check this option to draw note lines in empty areas.", nullptr));
#endif // QT_CONFIG(tooltip)
        mShowNoteLines->setText(tr2i18n("Show note &lines in Filofax layout", nullptr));
#if QT_CONFIG(tooltip)
        mColors->setToolTip(tr2i18n("Print in color", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mColors->setWhatsThis(tr2i18n("If you want to use colors to distinguish certain tags in the printed output, check this option.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mColors->setText(tr2i18n("&Use colors", nullptr));
#if QT_CONFIG(tooltip)
        mPrintFooter->setToolTip(tr2i18n("Print a datetime footer on each page", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mPrintFooter->setWhatsThis(tr2i18n("Check this box if you want to print a small footer on each page that contains the date of the print.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mPrintFooter->setText(tr2i18n("Print &Footer", nullptr));
        (void)CalPrintDayConfig_Base;
    } // retranslateUi

};

namespace Ui {
    class CalPrintDayConfig_Base: public Ui_CalPrintDayConfig_Base {};
} // namespace Ui

QT_END_NAMESPACE

#endif // CALPRINTDAYCONFIG_BASE_H

