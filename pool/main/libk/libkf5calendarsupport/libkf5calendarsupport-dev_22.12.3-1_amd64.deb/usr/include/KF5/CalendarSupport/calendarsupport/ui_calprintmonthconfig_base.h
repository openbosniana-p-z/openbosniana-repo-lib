#include <klocalizedstring.h>

/*
Configuration page for the print month mode.
*/

/********************************************************************************
** Form generated from reading UI file 'calprintmonthconfig_base.ui'
**
** Created by: Qt User Interface Compiler version 5.15.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALPRINTMONTHCONFIG_BASE_H
#define UI_CALPRINTMONTHCONFIG_BASE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CalPrintMonthConfig_Base
{
public:
    QVBoxLayout *vboxLayout;
    QLabel *label;
    QGroupBox *mDateRangeGroup;
    QHBoxLayout *hboxLayout;
    QLabel *mFromDateLabel;
    QComboBox *mFromMonth;
    QSpinBox *mFromYear;
    QLabel *mToDateLabel;
    QComboBox *mToMonth;
    QSpinBox *mToYear;
    QSpacerItem *spacerItem;
    QGroupBox *mSecurity;
    QHBoxLayout *horizontalLayout;
    QCheckBox *mExcludeConfidential;
    QCheckBox *mExcludePrivate;
    QGroupBox *mIncludeInfoGroup;
    QGridLayout *includeInfoLayout;
    QCheckBox *mIncludeDescription;
    QCheckBox *mIncludeCategories;
    QCheckBox *mIncludeTodos;
    QCheckBox *mRecurDaily;
    QCheckBox *mRecurWeekly;
    QGroupBox *mGeneralGroup;
    QVBoxLayout *verticalLayout;
    QCheckBox *mWeekNumbers;
    QCheckBox *mSingleLineLimit;
    QCheckBox *mShowNoteLines;
    QCheckBox *mColors;
    QCheckBox *mPrintFooter;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *CalPrintMonthConfig_Base)
    {
        if (CalPrintMonthConfig_Base->objectName().isEmpty())
            CalPrintMonthConfig_Base->setObjectName(QString::fromUtf8("CalPrintMonthConfig_Base"));
        vboxLayout = new QVBoxLayout(CalPrintMonthConfig_Base);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        vboxLayout->setContentsMargins(-1, -1, 0, -1);
        label = new QLabel(CalPrintMonthConfig_Base);
        label->setObjectName(QString::fromUtf8("label"));

        vboxLayout->addWidget(label);

        mDateRangeGroup = new QGroupBox(CalPrintMonthConfig_Base);
        mDateRangeGroup->setObjectName(QString::fromUtf8("mDateRangeGroup"));
        hboxLayout = new QHBoxLayout(mDateRangeGroup);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        mFromDateLabel = new QLabel(mDateRangeGroup);
        mFromDateLabel->setObjectName(QString::fromUtf8("mFromDateLabel"));

        hboxLayout->addWidget(mFromDateLabel);

        mFromMonth = new QComboBox(mDateRangeGroup);
        mFromMonth->setObjectName(QString::fromUtf8("mFromMonth"));

        hboxLayout->addWidget(mFromMonth);

        mFromYear = new QSpinBox(mDateRangeGroup);
        mFromYear->setObjectName(QString::fromUtf8("mFromYear"));
        mFromYear->setMaximum(3000);
        mFromYear->setValue(2007);

        hboxLayout->addWidget(mFromYear);

        mToDateLabel = new QLabel(mDateRangeGroup);
        mToDateLabel->setObjectName(QString::fromUtf8("mToDateLabel"));

        hboxLayout->addWidget(mToDateLabel);

        mToMonth = new QComboBox(mDateRangeGroup);
        mToMonth->setObjectName(QString::fromUtf8("mToMonth"));

        hboxLayout->addWidget(mToMonth);

        mToYear = new QSpinBox(mDateRangeGroup);
        mToYear->setObjectName(QString::fromUtf8("mToYear"));
        mToYear->setMaximum(3000);
        mToYear->setValue(2007);

        hboxLayout->addWidget(mToYear);

        spacerItem = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem);


        vboxLayout->addWidget(mDateRangeGroup);

        mSecurity = new QGroupBox(CalPrintMonthConfig_Base);
        mSecurity->setObjectName(QString::fromUtf8("mSecurity"));
        horizontalLayout = new QHBoxLayout(mSecurity);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        mExcludeConfidential = new QCheckBox(mSecurity);
        mExcludeConfidential->setObjectName(QString::fromUtf8("mExcludeConfidential"));

        horizontalLayout->addWidget(mExcludeConfidential);

        mExcludePrivate = new QCheckBox(mSecurity);
        mExcludePrivate->setObjectName(QString::fromUtf8("mExcludePrivate"));

        horizontalLayout->addWidget(mExcludePrivate);


        vboxLayout->addWidget(mSecurity);

        mIncludeInfoGroup = new QGroupBox(CalPrintMonthConfig_Base);
        mIncludeInfoGroup->setObjectName(QString::fromUtf8("mIncludeInfoGroup"));
        includeInfoLayout = new QGridLayout(mIncludeInfoGroup);
        includeInfoLayout->setObjectName(QString::fromUtf8("includeInfoLayout"));
        mIncludeDescription = new QCheckBox(mIncludeInfoGroup);
        mIncludeDescription->setObjectName(QString::fromUtf8("mIncludeDescription"));

        includeInfoLayout->addWidget(mIncludeDescription, 0, 0, 1, 1);

        mIncludeCategories = new QCheckBox(mIncludeInfoGroup);
        mIncludeCategories->setObjectName(QString::fromUtf8("mIncludeCategories"));

        includeInfoLayout->addWidget(mIncludeCategories, 0, 1, 1, 1);

        mIncludeTodos = new QCheckBox(mIncludeInfoGroup);
        mIncludeTodos->setObjectName(QString::fromUtf8("mIncludeTodos"));
        mIncludeTodos->setEnabled(false);

        includeInfoLayout->addWidget(mIncludeTodos, 1, 0, 1, 2);

        mRecurDaily = new QCheckBox(mIncludeInfoGroup);
        mRecurDaily->setObjectName(QString::fromUtf8("mRecurDaily"));

        includeInfoLayout->addWidget(mRecurDaily, 2, 0, 1, 2);

        mRecurWeekly = new QCheckBox(mIncludeInfoGroup);
        mRecurWeekly->setObjectName(QString::fromUtf8("mRecurWeekly"));

        includeInfoLayout->addWidget(mRecurWeekly, 3, 0, 1, 2);


        vboxLayout->addWidget(mIncludeInfoGroup);

        mGeneralGroup = new QGroupBox(CalPrintMonthConfig_Base);
        mGeneralGroup->setObjectName(QString::fromUtf8("mGeneralGroup"));
        verticalLayout = new QVBoxLayout(mGeneralGroup);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        mWeekNumbers = new QCheckBox(mGeneralGroup);
        mWeekNumbers->setObjectName(QString::fromUtf8("mWeekNumbers"));

        verticalLayout->addWidget(mWeekNumbers);

        mSingleLineLimit = new QCheckBox(mGeneralGroup);
        mSingleLineLimit->setObjectName(QString::fromUtf8("mSingleLineLimit"));

        verticalLayout->addWidget(mSingleLineLimit);

        mShowNoteLines = new QCheckBox(mGeneralGroup);
        mShowNoteLines->setObjectName(QString::fromUtf8("mShowNoteLines"));

        verticalLayout->addWidget(mShowNoteLines);

        mColors = new QCheckBox(mGeneralGroup);
        mColors->setObjectName(QString::fromUtf8("mColors"));

        verticalLayout->addWidget(mColors);

        mPrintFooter = new QCheckBox(mGeneralGroup);
        mPrintFooter->setObjectName(QString::fromUtf8("mPrintFooter"));

        verticalLayout->addWidget(mPrintFooter);


        vboxLayout->addWidget(mGeneralGroup);

        verticalSpacer = new QSpacerItem(0, 0, QSizePolicy::Minimum, QSizePolicy::Expanding);

        vboxLayout->addItem(verticalSpacer);

#if QT_CONFIG(shortcut)
        mFromDateLabel->setBuddy(mToMonth);
        mToDateLabel->setBuddy(mToMonth);
#endif // QT_CONFIG(shortcut)

        retranslateUi(CalPrintMonthConfig_Base);

        QMetaObject::connectSlotsByName(CalPrintMonthConfig_Base);
    } // setupUi

    void retranslateUi(QWidget *CalPrintMonthConfig_Base)
    {
        label->setText(tr2i18n("<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">Print month options:</span></p></body></html>", nullptr));
        mDateRangeGroup->setTitle(tr2i18n("Date && Time Range", nullptr));
#if QT_CONFIG(whatsthis)
        mFromDateLabel->setWhatsThis(tr2i18n("When you want to print more months at once, you can define a month range. This option defines the first month to be printed. Use the option <i>End month</i> to define the last month in this range.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mFromDateLabel->setText(tr2i18n("Sta&rt month:", nullptr));
#if QT_CONFIG(tooltip)
        mFromMonth->setToolTip(tr2i18n("Starting month for printing", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mFromMonth->setWhatsThis(tr2i18n("When you want to print more months at once, you can define a month range. This option defines the first month to be printed. Use the option <i>End month</i> to define the last month in this range.", nullptr));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(tooltip)
        mFromYear->setToolTip(tr2i18n("Starting year for printing", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mFromYear->setWhatsThis(tr2i18n("When you want to print more years at once, you can define a year range. This option defines the first year to be printed. Use the option <i>End year</i> to define the last year in this range.", nullptr));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(whatsthis)
        mToDateLabel->setWhatsThis(tr2i18n("When you want to print more months at once, you can define a month range. This option defines the last month to be printed. Use the option <i>Start month</i> to define the first month in this range.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mToDateLabel->setText(tr2i18n("&End month:", nullptr));
#if QT_CONFIG(tooltip)
        mToMonth->setToolTip(tr2i18n("Ending month for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mToMonth->setWhatsThis(tr2i18n("When you want to print more months at once, you can define a month range. This option defines the last month to be printed. Use the option <i>Start month</i> to define the first month in this range.", nullptr));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(tooltip)
        mToYear->setToolTip(tr2i18n("Ending year for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mToYear->setWhatsThis(tr2i18n("When you want to print more years at once, you can define a year range. This option defines the last year to be printed. Use the option <i>Start year</i> to define the first year in this range.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mSecurity->setTitle(tr2i18n("Security Exclusions", nullptr));
#if QT_CONFIG(tooltip)
        mExcludeConfidential->setToolTip(tr2i18n("Check this option to exclude items that have their Access level set to \342\200\234Confidential\342\200\235", nullptr));
#endif // QT_CONFIG(tooltip)
        mExcludeConfidential->setText(tr2i18n("Exclude c&onfidential", nullptr));
#if QT_CONFIG(tooltip)
        mExcludePrivate->setToolTip(tr2i18n("Check this option to exclude items that have their Access level set to \342\200\234Private\342\200\235", nullptr));
#endif // QT_CONFIG(tooltip)
        mExcludePrivate->setText(tr2i18n("Exclude pri&vate", nullptr));
        mIncludeInfoGroup->setTitle(tr2i18n("Include Information", nullptr));
#if QT_CONFIG(tooltip)
        mIncludeDescription->setToolTip(tr2i18n("Print item descriptions", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mIncludeDescription->setWhatsThis(tr2i18n("Check this option if you want to see the item descriptions printed.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mIncludeDescription->setText(tr2i18n("&Descriptions", nullptr));
#if QT_CONFIG(tooltip)
        mIncludeCategories->setToolTip(tr2i18n("Print item tags", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mIncludeCategories->setWhatsThis(tr2i18n("Check this option if you want to see the item tags printed.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mIncludeCategories->setText(tr2i18n("Ta&gs", nullptr));
#if QT_CONFIG(tooltip)
        mIncludeTodos->setToolTip(tr2i18n("Print to-dos due within the specified date range", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mIncludeTodos->setWhatsThis(tr2i18n("You should check this option if you want to print to-dos which are due on one of the dates which are in the supplied date range.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mIncludeTodos->setText(tr2i18n("Include to-&dos that are due on the printed day(s)", nullptr));
#if QT_CONFIG(tooltip)
        mRecurDaily->setToolTip(tr2i18n("Print daily recurring items", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mRecurDaily->setWhatsThis(tr2i18n("With this option it is possible to leave out the daily recurring to-dos and events in the print. They take a lot of space and make the month view needlessly complicated.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mRecurDaily->setText(tr2i18n("Include daily re&curring to-dos and events", nullptr));
#if QT_CONFIG(tooltip)
        mRecurWeekly->setToolTip(tr2i18n("Print weekly recurring items", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mRecurWeekly->setWhatsThis(tr2i18n("Similar to \"Print daily recurring to-dos and events\". Weekly to-dos and events will be omitted when making a print of the selected month.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mRecurWeekly->setText(tr2i18n("Include weekl&y recurring to-dos and events", nullptr));
        mGeneralGroup->setTitle(tr2i18n("General", "@title general print settings"));
#if QT_CONFIG(tooltip)
        mWeekNumbers->setToolTip(tr2i18n("Print week numbers", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mWeekNumbers->setWhatsThis(tr2i18n("Enable this to print week numbers at the left of each row.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mWeekNumbers->setText(tr2i18n("Print week &numbers", nullptr));
#if QT_CONFIG(tooltip)
        mSingleLineLimit->setToolTip(tr2i18n("Print items on one line", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mSingleLineLimit->setWhatsThis(tr2i18n("Check this option to limit events to a single line, truncating as necessary to save space.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mSingleLineLimit->setText(tr2i18n("Limit events in each day to a &single line", nullptr));
#if QT_CONFIG(tooltip)
        mShowNoteLines->setToolTip(tr2i18n("Check this option to draw note lines in empty areas.", nullptr));
#endif // QT_CONFIG(tooltip)
        mShowNoteLines->setText(tr2i18n("Show note &lines", nullptr));
#if QT_CONFIG(tooltip)
        mColors->setToolTip(tr2i18n("Print in color", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mColors->setWhatsThis(tr2i18n("If you want to use colors to distinguish certain tags in the printed output, check this option.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mColors->setText(tr2i18n("&Use colors", nullptr));
#if QT_CONFIG(tooltip)
        mPrintFooter->setToolTip(tr2i18n("Print a datetime footer on each page", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mPrintFooter->setWhatsThis(tr2i18n("Check this box if you want to print a small footer on each page that contains the date of the print.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mPrintFooter->setText(tr2i18n("Print &Footer", nullptr));
        (void)CalPrintMonthConfig_Base;
    } // retranslateUi

};

namespace Ui {
    class CalPrintMonthConfig_Base: public Ui_CalPrintMonthConfig_Base {};
} // namespace Ui

QT_END_NAMESPACE

#endif // CALPRINTMONTHCONFIG_BASE_H

