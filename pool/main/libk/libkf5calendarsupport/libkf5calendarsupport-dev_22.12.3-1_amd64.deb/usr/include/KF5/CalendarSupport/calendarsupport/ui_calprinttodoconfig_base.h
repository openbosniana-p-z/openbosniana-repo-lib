#include <klocalizedstring.h>

/*
Configuration page for the print todo mode.
*/

/********************************************************************************
** Form generated from reading UI file 'calprinttodoconfig_base.ui'
**
** Created by: Qt User Interface Compiler version 5.15.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALPRINTTODOCONFIG_BASE_H
#define UI_CALPRINTTODOCONFIG_BASE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "kdatecombobox.h"

QT_BEGIN_NAMESPACE

class Ui_CalPrintTodoConfig_Base
{
public:
    QVBoxLayout *vboxLayout;
    QLabel *label;
    QHBoxLayout *hboxLayout;
    QLabel *mTitleLabel;
    QLineEdit *mTitle;
    QGroupBox *mPrintType;
    QVBoxLayout *vboxLayout1;
    QRadioButton *mPrintAll;
    QRadioButton *mPrintUnfinished;
    QRadioButton *mPrintDueRange;
    QHBoxLayout *hboxLayout1;
    QSpacerItem *spacerItem;
    QLabel *mFromDateLabel;
    KDateComboBox *mFromDate;
    QLabel *mToDateLabel;
    KDateComboBox *mToDate;
    QSpacerItem *spacerItem1;
    QGroupBox *mSecurity;
    QHBoxLayout *horizontalLayout_4;
    QCheckBox *mExcludeConfidential;
    QCheckBox *mExcludePrivate;
    QGroupBox *includeInfoBox;
    QGridLayout *includeLayout;
    QCheckBox *mDescription;
    QCheckBox *mCategories;
    QCheckBox *mPriority;
    QCheckBox *mStartDate;
    QCheckBox *mDueDate;
    QCheckBox *mPercentComplete;
    QGroupBox *sortingOptionsBox;
    QHBoxLayout *horizontalLayout_2;
    QHBoxLayout *hboxLayout2;
    QLabel *sortFieldLabel;
    QComboBox *mSortField;
    QHBoxLayout *hboxLayout3;
    QLabel *sortDirectionLabel;
    QComboBox *mSortDirection;
    QGroupBox *mGeneralGroup;
    QVBoxLayout *verticalLayout;
    QCheckBox *mConnectSubTodos;
    QCheckBox *mStrikeOutCompleted;
    QCheckBox *mPrintFooter;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *CalPrintTodoConfig_Base)
    {
        if (CalPrintTodoConfig_Base->objectName().isEmpty())
            CalPrintTodoConfig_Base->setObjectName(QString::fromUtf8("CalPrintTodoConfig_Base"));
        vboxLayout = new QVBoxLayout(CalPrintTodoConfig_Base);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        vboxLayout->setContentsMargins(-1, -1, 0, -1);
        label = new QLabel(CalPrintTodoConfig_Base);
        label->setObjectName(QString::fromUtf8("label"));

        vboxLayout->addWidget(label);

        hboxLayout = new QHBoxLayout();
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        mTitleLabel = new QLabel(CalPrintTodoConfig_Base);
        mTitleLabel->setObjectName(QString::fromUtf8("mTitleLabel"));

        hboxLayout->addWidget(mTitleLabel);

        mTitle = new QLineEdit(CalPrintTodoConfig_Base);
        mTitle->setObjectName(QString::fromUtf8("mTitle"));

        hboxLayout->addWidget(mTitle);


        vboxLayout->addLayout(hboxLayout);

        mPrintType = new QGroupBox(CalPrintTodoConfig_Base);
        mPrintType->setObjectName(QString::fromUtf8("mPrintType"));
        vboxLayout1 = new QVBoxLayout(mPrintType);
        vboxLayout1->setObjectName(QString::fromUtf8("vboxLayout1"));
        mPrintAll = new QRadioButton(mPrintType);
        mPrintAll->setObjectName(QString::fromUtf8("mPrintAll"));
        mPrintAll->setChecked(true);

        vboxLayout1->addWidget(mPrintAll);

        mPrintUnfinished = new QRadioButton(mPrintType);
        mPrintUnfinished->setObjectName(QString::fromUtf8("mPrintUnfinished"));

        vboxLayout1->addWidget(mPrintUnfinished);

        mPrintDueRange = new QRadioButton(mPrintType);
        mPrintDueRange->setObjectName(QString::fromUtf8("mPrintDueRange"));

        vboxLayout1->addWidget(mPrintDueRange);

        hboxLayout1 = new QHBoxLayout();
        hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));
        spacerItem = new QSpacerItem(24, 1, QSizePolicy::Fixed, QSizePolicy::Minimum);

        hboxLayout1->addItem(spacerItem);

        mFromDateLabel = new QLabel(mPrintType);
        mFromDateLabel->setObjectName(QString::fromUtf8("mFromDateLabel"));

        hboxLayout1->addWidget(mFromDateLabel);

        mFromDate = new KDateComboBox(mPrintType);
        mFromDate->addItem(QString());
        mFromDate->setObjectName(QString::fromUtf8("mFromDate"));
        mFromDate->setEnabled(false);
        mFromDate->setFocusPolicy(Qt::StrongFocus);

        hboxLayout1->addWidget(mFromDate);

        mToDateLabel = new QLabel(mPrintType);
        mToDateLabel->setObjectName(QString::fromUtf8("mToDateLabel"));

        hboxLayout1->addWidget(mToDateLabel);

        mToDate = new KDateComboBox(mPrintType);
        mToDate->addItem(QString());
        mToDate->setObjectName(QString::fromUtf8("mToDate"));
        mToDate->setEnabled(false);
        mToDate->setFocusPolicy(Qt::StrongFocus);

        hboxLayout1->addWidget(mToDate);

        spacerItem1 = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout1->addItem(spacerItem1);


        vboxLayout1->addLayout(hboxLayout1);


        vboxLayout->addWidget(mPrintType);

        mSecurity = new QGroupBox(CalPrintTodoConfig_Base);
        mSecurity->setObjectName(QString::fromUtf8("mSecurity"));
        horizontalLayout_4 = new QHBoxLayout(mSecurity);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        mExcludeConfidential = new QCheckBox(mSecurity);
        mExcludeConfidential->setObjectName(QString::fromUtf8("mExcludeConfidential"));

        horizontalLayout_4->addWidget(mExcludeConfidential);

        mExcludePrivate = new QCheckBox(mSecurity);
        mExcludePrivate->setObjectName(QString::fromUtf8("mExcludePrivate"));

        horizontalLayout_4->addWidget(mExcludePrivate);


        vboxLayout->addWidget(mSecurity);

        includeInfoBox = new QGroupBox(CalPrintTodoConfig_Base);
        includeInfoBox->setObjectName(QString::fromUtf8("includeInfoBox"));
        includeInfoBox->setCheckable(false);
        includeLayout = new QGridLayout(includeInfoBox);
        includeLayout->setObjectName(QString::fromUtf8("includeLayout"));
        mDescription = new QCheckBox(includeInfoBox);
        mDescription->setObjectName(QString::fromUtf8("mDescription"));

        includeLayout->addWidget(mDescription, 0, 0, 1, 1);

        mCategories = new QCheckBox(includeInfoBox);
        mCategories->setObjectName(QString::fromUtf8("mCategories"));

        includeLayout->addWidget(mCategories, 0, 1, 1, 1);

        mPriority = new QCheckBox(includeInfoBox);
        mPriority->setObjectName(QString::fromUtf8("mPriority"));
        mPriority->setChecked(true);

        includeLayout->addWidget(mPriority, 0, 2, 1, 1);

        mStartDate = new QCheckBox(includeInfoBox);
        mStartDate->setObjectName(QString::fromUtf8("mStartDate"));

        includeLayout->addWidget(mStartDate, 1, 0, 1, 1);

        mDueDate = new QCheckBox(includeInfoBox);
        mDueDate->setObjectName(QString::fromUtf8("mDueDate"));
        mDueDate->setChecked(true);

        includeLayout->addWidget(mDueDate, 1, 1, 1, 1);

        mPercentComplete = new QCheckBox(includeInfoBox);
        mPercentComplete->setObjectName(QString::fromUtf8("mPercentComplete"));
        mPercentComplete->setChecked(true);

        includeLayout->addWidget(mPercentComplete, 1, 2, 1, 1);

        mDescription->raise();
        mCategories->raise();
        mStartDate->raise();
        mDueDate->raise();
        mPercentComplete->raise();
        mPriority->raise();

        vboxLayout->addWidget(includeInfoBox);

        sortingOptionsBox = new QGroupBox(CalPrintTodoConfig_Base);
        sortingOptionsBox->setObjectName(QString::fromUtf8("sortingOptionsBox"));
        horizontalLayout_2 = new QHBoxLayout(sortingOptionsBox);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        hboxLayout2 = new QHBoxLayout();
        hboxLayout2->setObjectName(QString::fromUtf8("hboxLayout2"));
        sortFieldLabel = new QLabel(sortingOptionsBox);
        sortFieldLabel->setObjectName(QString::fromUtf8("sortFieldLabel"));
        sortFieldLabel->setEnabled(true);

        hboxLayout2->addWidget(sortFieldLabel);

        mSortField = new QComboBox(sortingOptionsBox);
        mSortField->setObjectName(QString::fromUtf8("mSortField"));
        mSortField->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(mSortField->sizePolicy().hasHeightForWidth());
        mSortField->setSizePolicy(sizePolicy);

        hboxLayout2->addWidget(mSortField);


        horizontalLayout_2->addLayout(hboxLayout2);

        hboxLayout3 = new QHBoxLayout();
        hboxLayout3->setObjectName(QString::fromUtf8("hboxLayout3"));
        sortDirectionLabel = new QLabel(sortingOptionsBox);
        sortDirectionLabel->setObjectName(QString::fromUtf8("sortDirectionLabel"));
        sortDirectionLabel->setEnabled(true);

        hboxLayout3->addWidget(sortDirectionLabel);

        mSortDirection = new QComboBox(sortingOptionsBox);
        mSortDirection->setObjectName(QString::fromUtf8("mSortDirection"));
        mSortDirection->setEnabled(true);
        sizePolicy.setHeightForWidth(mSortDirection->sizePolicy().hasHeightForWidth());
        mSortDirection->setSizePolicy(sizePolicy);

        hboxLayout3->addWidget(mSortDirection);


        horizontalLayout_2->addLayout(hboxLayout3);


        vboxLayout->addWidget(sortingOptionsBox);

        mGeneralGroup = new QGroupBox(CalPrintTodoConfig_Base);
        mGeneralGroup->setObjectName(QString::fromUtf8("mGeneralGroup"));
        verticalLayout = new QVBoxLayout(mGeneralGroup);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        mConnectSubTodos = new QCheckBox(mGeneralGroup);
        mConnectSubTodos->setObjectName(QString::fromUtf8("mConnectSubTodos"));
        mConnectSubTodos->setChecked(true);

        verticalLayout->addWidget(mConnectSubTodos);

        mStrikeOutCompleted = new QCheckBox(mGeneralGroup);
        mStrikeOutCompleted->setObjectName(QString::fromUtf8("mStrikeOutCompleted"));
        mStrikeOutCompleted->setChecked(true);

        verticalLayout->addWidget(mStrikeOutCompleted);

        mPrintFooter = new QCheckBox(mGeneralGroup);
        mPrintFooter->setObjectName(QString::fromUtf8("mPrintFooter"));

        verticalLayout->addWidget(mPrintFooter);


        vboxLayout->addWidget(mGeneralGroup);

        verticalSpacer = new QSpacerItem(0, 0, QSizePolicy::Minimum, QSizePolicy::Expanding);

        vboxLayout->addItem(verticalSpacer);

#if QT_CONFIG(shortcut)
        mTitleLabel->setBuddy(mTitle);
        mFromDateLabel->setBuddy(mFromDate);
        mToDateLabel->setBuddy(mToDate);
#endif // QT_CONFIG(shortcut)

        retranslateUi(CalPrintTodoConfig_Base);
        QObject::connect(mPrintDueRange, SIGNAL(toggled(bool)), mFromDateLabel, SLOT(setEnabled(bool)));
        QObject::connect(mPrintDueRange, SIGNAL(toggled(bool)), mToDate, SLOT(setEnabled(bool)));
        QObject::connect(mPrintDueRange, SIGNAL(toggled(bool)), mToDateLabel, SLOT(setEnabled(bool)));
        QObject::connect(mPrintDueRange, SIGNAL(toggled(bool)), mFromDate, SLOT(setEnabled(bool)));

        QMetaObject::connectSlotsByName(CalPrintTodoConfig_Base);
    } // setupUi

    void retranslateUi(QWidget *CalPrintTodoConfig_Base)
    {
        label->setText(tr2i18n("<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">Print to-dos options:</span></p></body></html>", nullptr));
#if QT_CONFIG(tooltip)
        mTitleLabel->setToolTip(tr2i18n("Name for this to-do list", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mTitleLabel->setWhatsThis(tr2i18n("Enter a name for this to-do list that will be put at the top of the print-out", nullptr));
#endif // QT_CONFIG(whatsthis)
        mTitleLabel->setText(tr2i18n("&Title:", nullptr));
#if QT_CONFIG(tooltip)
        mTitle->setToolTip(tr2i18n("Name for this to-do list", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mTitle->setWhatsThis(tr2i18n("Enter a name for this to-do list that will be put at the top of the print-out", nullptr));
#endif // QT_CONFIG(whatsthis)
        mTitle->setText(tr2i18n("To-do List", nullptr));
        mPrintType->setTitle(tr2i18n("To-dos to Print", nullptr));
        mPrintAll->setText(tr2i18n("Print &all to-dos", nullptr));
        mPrintUnfinished->setText(tr2i18n("Print &uncompleted to-dos only", nullptr));
        mPrintDueRange->setText(tr2i18n("Print only to-dos due in the &range:", nullptr));
#if QT_CONFIG(tooltip)
        mFromDateLabel->setToolTip(tr2i18n("Starting date for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mFromDateLabel->setWhatsThis(tr2i18n("If you want to print more days at once, you can define a range of dates with this option and the <i>End date</i> option. This option is used to define the start date.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mFromDateLabel->setText(tr2i18n("&Start date:", nullptr));
        mFromDate->setItemText(0, tr2i18n("2009-01-19", nullptr));

#if QT_CONFIG(tooltip)
        mFromDate->setToolTip(tr2i18n("Starting date for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mFromDate->setWhatsThis(tr2i18n("If you want to print more days at once, you can define a range of dates with this option and the <i>End date</i> option. This option is used to define the start date.", nullptr));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(tooltip)
        mToDateLabel->setToolTip(tr2i18n("Ending date for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mToDateLabel->setWhatsThis(tr2i18n("If you want to print more days at once, you can define a range of dates with this option and the <i>Start date</i> option. This option is used to define the end date.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mToDateLabel->setText(tr2i18n("&End date:", nullptr));
        mToDate->setItemText(0, tr2i18n("2009-01-19", nullptr));

#if QT_CONFIG(tooltip)
        mToDate->setToolTip(tr2i18n("Ending date for the print", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mToDate->setWhatsThis(tr2i18n("If you want to print more days at once, you can define a range of dates with this option and the <i>Start date</i> option. This option is used to define the end date.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mSecurity->setTitle(tr2i18n("Security Exclusions", nullptr));
#if QT_CONFIG(tooltip)
        mExcludeConfidential->setToolTip(tr2i18n("Check this option to exclude items that have their Access level set to \342\200\234Confidential\342\200\235", nullptr));
#endif // QT_CONFIG(tooltip)
        mExcludeConfidential->setText(tr2i18n("Exclude c&onfidential", nullptr));
#if QT_CONFIG(tooltip)
        mExcludePrivate->setToolTip(tr2i18n("Check this option to exclude items that have their Access level set to \342\200\234Private\342\200\235", nullptr));
#endif // QT_CONFIG(tooltip)
        mExcludePrivate->setText(tr2i18n("Exclude pri&vate", nullptr));
        includeInfoBox->setTitle(tr2i18n("Include Information", nullptr));
#if QT_CONFIG(tooltip)
        mDescription->setToolTip(tr2i18n("Print item descriptions", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mDescription->setWhatsThis(tr2i18n("Check this option if you want to see the item descriptions printed.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mDescription->setText(tr2i18n("&Descriptions", nullptr));
#if QT_CONFIG(tooltip)
        mCategories->setToolTip(tr2i18n("Print item tags", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mCategories->setWhatsThis(tr2i18n("Check this option if you want to see the item tags printed.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mCategories->setText(tr2i18n("Ta&gs", nullptr));
#if QT_CONFIG(tooltip)
        mPriority->setToolTip(tr2i18n("Print item priorities", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mPriority->setWhatsThis(tr2i18n("Check this option if you want to see the item priorities printed.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mPriority->setText(tr2i18n("&Priority", nullptr));
#if QT_CONFIG(tooltip)
        mStartDate->setToolTip(tr2i18n("Print item start dates", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mStartDate->setWhatsThis(tr2i18n("Check this option if you want to see the item start dates (when work can begin) printed.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mStartDate->setText(tr2i18n("&Start date", nullptr));
#if QT_CONFIG(tooltip)
        mDueDate->setToolTip(tr2i18n("Print item due dates", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mDueDate->setWhatsThis(tr2i18n("Check this option if you want to see the item due dates printed.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mDueDate->setText(tr2i18n("Du&e date", nullptr));
#if QT_CONFIG(tooltip)
        mPercentComplete->setToolTip(tr2i18n("Print item completion percentage", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mPercentComplete->setWhatsThis(tr2i18n("Check this option if you want to see the item completion percentage printed as a number and bar graph.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mPercentComplete->setText(tr2i18n("Percentage co&mpleted", nullptr));
        sortingOptionsBox->setTitle(tr2i18n("Sorting Options", nullptr));
        sortFieldLabel->setText(tr2i18n("Sort field:", nullptr));
        sortDirectionLabel->setText(tr2i18n("Sort direction:", nullptr));
        mGeneralGroup->setTitle(tr2i18n("General", "@title general print settings"));
        mConnectSubTodos->setText(tr2i18n("Co&nnect sub-to-dos with its parent", nullptr));
        mStrikeOutCompleted->setText(tr2i18n("Stri&ke out completed to-do summaries", nullptr));
#if QT_CONFIG(tooltip)
        mPrintFooter->setToolTip(tr2i18n("Print a datetime footer on each page", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        mPrintFooter->setWhatsThis(tr2i18n("Check this box if you want to print a small footer on each page that contains the date of the print.", nullptr));
#endif // QT_CONFIG(whatsthis)
        mPrintFooter->setText(tr2i18n("Print &Footer", nullptr));
        (void)CalPrintTodoConfig_Base;
    } // retranslateUi

};

namespace Ui {
    class CalPrintTodoConfig_Base: public Ui_CalPrintTodoConfig_Base {};
} // namespace Ui

QT_END_NAMESPACE

#endif // CALPRINTTODOCONFIG_BASE_H

