
#ifndef KSIEVEUI_EXPORT_H
#define KSIEVEUI_EXPORT_H

#ifdef KSIEVEUI_STATIC_DEFINE
#  define KSIEVEUI_EXPORT
#  define KSIEVEUI_NO_EXPORT
#else
#  ifndef KSIEVEUI_EXPORT
#    ifdef KF5KSieveUi_EXPORTS
        /* We are building this library */
#      define KSIEVEUI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KSIEVEUI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KSIEVEUI_NO_EXPORT
#    define KSIEVEUI_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KSIEVEUI_DEPRECATED
#  define KSIEVEUI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KSIEVEUI_DEPRECATED_EXPORT
#  define KSIEVEUI_DEPRECATED_EXPORT KSIEVEUI_EXPORT KSIEVEUI_DEPRECATED
#endif

#ifndef KSIEVEUI_DEPRECATED_NO_EXPORT
#  define KSIEVEUI_DEPRECATED_NO_EXPORT KSIEVEUI_NO_EXPORT KSIEVEUI_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KSIEVEUI_NO_DEPRECATED
#    define KSIEVEUI_NO_DEPRECATED
#  endif
#endif

#endif /* KSIEVEUI_EXPORT_H */
