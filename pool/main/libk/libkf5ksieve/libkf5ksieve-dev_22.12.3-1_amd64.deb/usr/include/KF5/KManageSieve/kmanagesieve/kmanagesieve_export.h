
#ifndef KMANAGESIEVE_EXPORT_H
#define KMANAGESIEVE_EXPORT_H

#ifdef KMANAGESIEVE_STATIC_DEFINE
#  define KMANAGESIEVE_EXPORT
#  define KMANAGESIEVE_NO_EXPORT
#else
#  ifndef KMANAGESIEVE_EXPORT
#    ifdef KF5KManageSieve_EXPORTS
        /* We are building this library */
#      define KMANAGESIEVE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KMANAGESIEVE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KMANAGESIEVE_NO_EXPORT
#    define KMANAGESIEVE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KMANAGESIEVE_DEPRECATED
#  define KMANAGESIEVE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KMANAGESIEVE_DEPRECATED_EXPORT
#  define KMANAGESIEVE_DEPRECATED_EXPORT KMANAGESIEVE_EXPORT KMANAGESIEVE_DEPRECATED
#endif

#ifndef KMANAGESIEVE_DEPRECATED_NO_EXPORT
#  define KMANAGESIEVE_DEPRECATED_NO_EXPORT KMANAGESIEVE_NO_EXPORT KMANAGESIEVE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KMANAGESIEVE_NO_DEPRECATED
#    define KMANAGESIEVE_NO_DEPRECATED
#  endif
#endif

#endif /* KMANAGESIEVE_EXPORT_H */
