/*
    SPDX-FileCopyrightText: 2012 Stefan Majewsky <majewsky@gmx.net>

    SPDX-License-Identifier: LGPL-2.0-only
*/

#ifndef LIBKDEGAMES_CAPABILITIES_H
#define LIBKDEGAMES_CAPABILITIES_H

#define KGAUDIO_BACKEND "openal"
#define KGAUDIO_BACKEND_OPENAL

#endif // LIBKDEGAMES_CAPABILITIES_H
