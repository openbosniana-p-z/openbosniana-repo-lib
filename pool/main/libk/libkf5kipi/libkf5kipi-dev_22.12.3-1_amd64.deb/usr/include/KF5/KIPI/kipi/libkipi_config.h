/*
    SPDX-FileCopyrightText: 2004-2018 Gilles Caulier <caulier dot gilles at gmail dot com>

    SPDX-License-Identifier: GPL-2.0-or-later
*/

#ifndef KIPI_CONFIG_H
#define KIPI_CONFIG_H

static const int kipi_binary_version = 32;

#endif // KIPI_CONFIG_H

