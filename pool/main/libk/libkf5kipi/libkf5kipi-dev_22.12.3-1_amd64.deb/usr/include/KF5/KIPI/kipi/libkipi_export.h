
#ifndef LIBKIPI_EXPORT_H
#define LIBKIPI_EXPORT_H

#ifdef LIBKIPI_STATIC_DEFINE
#  define LIBKIPI_EXPORT
#  define LIBKIPI_NO_EXPORT
#else
#  ifndef LIBKIPI_EXPORT
#    ifdef KF5Kipi_EXPORTS
        /* We are building this library */
#      define LIBKIPI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBKIPI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBKIPI_NO_EXPORT
#    define LIBKIPI_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBKIPI_DEPRECATED
#  define LIBKIPI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBKIPI_DEPRECATED_EXPORT
#  define LIBKIPI_DEPRECATED_EXPORT LIBKIPI_EXPORT LIBKIPI_DEPRECATED
#endif

#ifndef LIBKIPI_DEPRECATED_NO_EXPORT
#  define LIBKIPI_DEPRECATED_NO_EXPORT LIBKIPI_NO_EXPORT LIBKIPI_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBKIPI_NO_DEPRECATED
#    define LIBKIPI_NO_DEPRECATED
#  endif
#endif

#endif /* LIBKIPI_EXPORT_H */
