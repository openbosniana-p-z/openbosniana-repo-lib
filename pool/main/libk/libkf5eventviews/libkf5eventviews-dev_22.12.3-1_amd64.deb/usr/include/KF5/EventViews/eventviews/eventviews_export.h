
#ifndef EVENTVIEWS_EXPORT_H
#define EVENTVIEWS_EXPORT_H

#ifdef EVENTVIEWS_STATIC_DEFINE
#  define EVENTVIEWS_EXPORT
#  define EVENTVIEWS_NO_EXPORT
#else
#  ifndef EVENTVIEWS_EXPORT
#    ifdef KF5EventViews_EXPORTS
        /* We are building this library */
#      define EVENTVIEWS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define EVENTVIEWS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef EVENTVIEWS_NO_EXPORT
#    define EVENTVIEWS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef EVENTVIEWS_DEPRECATED
#  define EVENTVIEWS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef EVENTVIEWS_DEPRECATED_EXPORT
#  define EVENTVIEWS_DEPRECATED_EXPORT EVENTVIEWS_EXPORT EVENTVIEWS_DEPRECATED
#endif

#ifndef EVENTVIEWS_DEPRECATED_NO_EXPORT
#  define EVENTVIEWS_DEPRECATED_NO_EXPORT EVENTVIEWS_NO_EXPORT EVENTVIEWS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef EVENTVIEWS_NO_DEPRECATED
#    define EVENTVIEWS_NO_DEPRECATED
#  endif
#endif

#endif /* EVENTVIEWS_EXPORT_H */
