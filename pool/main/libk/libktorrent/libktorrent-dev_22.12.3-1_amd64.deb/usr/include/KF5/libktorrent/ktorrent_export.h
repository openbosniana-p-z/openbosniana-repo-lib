
#ifndef KTORRENT_EXPORT_H
#define KTORRENT_EXPORT_H

#ifdef KTORRENT_STATIC_DEFINE
#  define KTORRENT_EXPORT
#  define KTORRENT_NO_EXPORT
#else
#  ifndef KTORRENT_EXPORT
#    ifdef KF5Torrent_EXPORTS
        /* We are building this library */
#      define KTORRENT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KTORRENT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KTORRENT_NO_EXPORT
#    define KTORRENT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KTORRENT_DEPRECATED
#  define KTORRENT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KTORRENT_DEPRECATED_EXPORT
#  define KTORRENT_DEPRECATED_EXPORT KTORRENT_EXPORT KTORRENT_DEPRECATED
#endif

#ifndef KTORRENT_DEPRECATED_NO_EXPORT
#  define KTORRENT_DEPRECATED_NO_EXPORT KTORRENT_NO_EXPORT KTORRENT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KTORRENT_NO_DEPRECATED
#    define KTORRENT_NO_DEPRECATED
#  endif
#endif

#endif /* KTORRENT_EXPORT_H */
