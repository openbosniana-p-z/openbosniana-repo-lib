
#ifndef MAILCOMMON_EXPORT_H
#define MAILCOMMON_EXPORT_H

#ifdef MAILCOMMON_STATIC_DEFINE
#  define MAILCOMMON_EXPORT
#  define MAILCOMMON_NO_EXPORT
#else
#  ifndef MAILCOMMON_EXPORT
#    ifdef KF5MailCommon_EXPORTS
        /* We are building this library */
#      define MAILCOMMON_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define MAILCOMMON_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MAILCOMMON_NO_EXPORT
#    define MAILCOMMON_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MAILCOMMON_DEPRECATED
#  define MAILCOMMON_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MAILCOMMON_DEPRECATED_EXPORT
#  define MAILCOMMON_DEPRECATED_EXPORT MAILCOMMON_EXPORT MAILCOMMON_DEPRECATED
#endif

#ifndef MAILCOMMON_DEPRECATED_NO_EXPORT
#  define MAILCOMMON_DEPRECATED_NO_EXPORT MAILCOMMON_NO_EXPORT MAILCOMMON_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MAILCOMMON_NO_DEPRECATED
#    define MAILCOMMON_NO_DEPRECATED
#  endif
#endif

#endif /* MAILCOMMON_EXPORT_H */
