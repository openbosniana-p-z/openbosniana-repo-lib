#pragma once

#include <QList>

Q_DECLARE_METATYPE(QList<qint64>)
