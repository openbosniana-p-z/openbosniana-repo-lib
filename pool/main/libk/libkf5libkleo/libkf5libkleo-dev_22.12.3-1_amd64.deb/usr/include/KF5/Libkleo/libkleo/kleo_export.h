
#ifndef KLEO_EXPORT_H
#define KLEO_EXPORT_H

#ifdef KLEO_STATIC_DEFINE
#  define KLEO_EXPORT
#  define KLEO_NO_EXPORT
#else
#  ifndef KLEO_EXPORT
#    ifdef KF5Libkleo_EXPORTS
        /* We are building this library */
#      define KLEO_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KLEO_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KLEO_NO_EXPORT
#    define KLEO_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KLEO_DEPRECATED
#  define KLEO_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KLEO_DEPRECATED_EXPORT
#  define KLEO_DEPRECATED_EXPORT KLEO_EXPORT KLEO_DEPRECATED
#endif

#ifndef KLEO_DEPRECATED_NO_EXPORT
#  define KLEO_DEPRECATED_NO_EXPORT KLEO_NO_EXPORT KLEO_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KLEO_NO_DEPRECATED
#    define KLEO_NO_DEPRECATED
#  endif
#endif

#endif /* KLEO_EXPORT_H */
