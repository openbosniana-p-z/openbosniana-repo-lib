
#ifndef GRANTLEETHEME_EXPORT_H
#define GRANTLEETHEME_EXPORT_H

#ifdef GRANTLEETHEME_STATIC_DEFINE
#  define GRANTLEETHEME_EXPORT
#  define GRANTLEETHEME_NO_EXPORT
#else
#  ifndef GRANTLEETHEME_EXPORT
#    ifdef KF5GrantleeTheme_EXPORTS
        /* We are building this library */
#      define GRANTLEETHEME_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GRANTLEETHEME_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GRANTLEETHEME_NO_EXPORT
#    define GRANTLEETHEME_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GRANTLEETHEME_DEPRECATED
#  define GRANTLEETHEME_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef GRANTLEETHEME_DEPRECATED_EXPORT
#  define GRANTLEETHEME_DEPRECATED_EXPORT GRANTLEETHEME_EXPORT GRANTLEETHEME_DEPRECATED
#endif

#ifndef GRANTLEETHEME_DEPRECATED_NO_EXPORT
#  define GRANTLEETHEME_DEPRECATED_NO_EXPORT GRANTLEETHEME_NO_EXPORT GRANTLEETHEME_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef GRANTLEETHEME_NO_DEPRECATED
#    define GRANTLEETHEME_NO_DEPRECATED
#  endif
#endif

#endif /* GRANTLEETHEME_EXPORT_H */
