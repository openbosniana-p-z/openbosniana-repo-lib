#include <kcddb/kcddb_export.h>

#if KCDDB_ENABLE_DEPRECATED_SINCE(5, 1)
#   include <kcddb/config.h>
#   if KCDDB_DEPRECATED_WARNINGS_SINCE >= 0x050100
#       pragma message("Deprecated header. Since 5.1, use #include <kcddb/config.h> instead")
#   endif
#else
#   error "Include of deprecated header is disabled"
#endif
