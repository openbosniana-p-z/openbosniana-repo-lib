
#ifndef GRAVATAR_EXPORT_H
#define GRAVATAR_EXPORT_H

#ifdef GRAVATAR_STATIC_DEFINE
#  define GRAVATAR_EXPORT
#  define GRAVATAR_NO_EXPORT
#else
#  ifndef GRAVATAR_EXPORT
#    ifdef KF5Gravatar_EXPORTS
        /* We are building this library */
#      define GRAVATAR_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GRAVATAR_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GRAVATAR_NO_EXPORT
#    define GRAVATAR_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GRAVATAR_DEPRECATED
#  define GRAVATAR_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef GRAVATAR_DEPRECATED_EXPORT
#  define GRAVATAR_DEPRECATED_EXPORT GRAVATAR_EXPORT GRAVATAR_DEPRECATED
#endif

#ifndef GRAVATAR_DEPRECATED_NO_EXPORT
#  define GRAVATAR_DEPRECATED_NO_EXPORT GRAVATAR_NO_EXPORT GRAVATAR_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef GRAVATAR_NO_DEPRECATED
#    define GRAVATAR_NO_DEPRECATED
#  endif
#endif

#endif /* GRAVATAR_EXPORT_H */
