var searchData=
[
  ['idx_0',['idx',['../struct__addrxlat__opt.html#a223a7aee317fb95e85bb44833338522e',1,'_addrxlat_opt::idx()'],['../struct__addrxlat__step.html#a6d9a3993df1a97625f37e45c38dbefc1',1,'_addrxlat_step::idx()'],['../structpfn2idx.html#adc116037d360d3c6396e4bcb52526fcc',1,'pfn2idx::idx()'],['../structpfn2idx__range.html#ab75d1626edcbc640b39330e57ef2d01b',1,'pfn2idx_range::idx()'],['../structphash.html#a9f846fe90f5dcd8707339555454fbe36',1,'phash::idx()']]],
  ['idx3_1',['idx3',['../structpfn__block.html#a23a341494d586f41b95967558afa439c',1,'pfn_block']]],
  ['indirect_2',['indirect',['../structattr__flags.html#aad4695ab8af043de24d076b7088be325',1,'attr_flags']]],
  ['inflight_3',['inflight',['../struct__addrxlat__ctx.html#aaf6dd0ebeb0af58a1c793fe6662c80ed',1,'_addrxlat_ctx::inflight()'],['../structcache.html#a2e5f90c845fa81313e0f9279d00fa931',1,'cache::inflight()']]],
  ['info_4',['info',['../structfcache.html#a72bc2d2bcb64c3cd473d954f19cdfe5c',1,'fcache']]],
  ['init_5',['init',['../structarch__ops.html#ab8d2145c7c05916e78b511e3fe81c446',1,'arch_ops']]],
  ['invalid_6',['invalid',['../structattr__flags.html#a3ef619292df5e58e9196bb04f02aa988',1,'attr_flags']]],
  ['isset_7',['isset',['../structparsed__opts.html#a056aad99d8d4e9b3cdaeb331508bd169',1,'parsed_opts::isset()'],['../structattr__flags.html#ad3a4fc963e47fc1196e3a923824e47ce',1,'attr_flags::isset()']]]
];
