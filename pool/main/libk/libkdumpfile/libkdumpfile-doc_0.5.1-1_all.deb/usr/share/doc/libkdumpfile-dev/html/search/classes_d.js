var searchData=
[
  ['new_5futsname_0',['new_utsname',['../structnew__utsname.html',1,'']]],
  ['nodataexception_1',['NoDataException',['../classkdumpfile_1_1exceptions_1_1NoDataException.html',1,'kdumpfile::exceptions']]],
  ['nokeyexception_2',['NoKeyException',['../classkdumpfile_1_1exceptions_1_1NoKeyException.html',1,'kdumpfile::exceptions']]],
  ['notimplementedexception_3',['NotImplementedException',['../classkdumpfile_1_1exceptions_1_1NotImplementedException.html',1,'kdumpfile::exceptions']]]
];
