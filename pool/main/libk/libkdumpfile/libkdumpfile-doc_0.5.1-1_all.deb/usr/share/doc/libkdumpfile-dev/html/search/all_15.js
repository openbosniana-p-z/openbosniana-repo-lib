var searchData=
[
  ['written_5fblocks_0',['written_blocks',['../structsadump__header.html#a7b210daf0e512a7fc7ab9f7180522a1f',1,'sadump_header']]],
  ['written_5fblocks_5f64_1',['written_blocks_64',['../structsadump__header.html#a79359af9197d6f28d196838259469756',1,'sadump_header']]]
];
