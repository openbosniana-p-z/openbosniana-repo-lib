var searchData=
[
  ['page_5fdesc_0',['page_desc',['../structpage__desc.html',1,'']]],
  ['page_5fio_1',['page_io',['../structpage__io.html',1,'']]],
  ['pagetablemethod_2',['PageTableMethod',['../classaddrxlat_1_1PageTableMethod.html',1,'addrxlat']]],
  ['param_5floc_3',['param_loc',['../structparam__loc.html',1,'']]],
  ['parsed_5fopts_4',['parsed_opts',['../structparsed__opts.html',1,'']]],
  ['pfn2idx_5',['pfn2idx',['../structpfn2idx.html',1,'']]],
  ['pfn2idx_5fmap_6',['pfn2idx_map',['../structpfn2idx__map.html',1,'']]],
  ['pfn2idx_5frange_7',['pfn2idx_range',['../structpfn2idx__range.html',1,'']]],
  ['pfn_5fblock_8',['pfn_block',['../structpfn__block.html',1,'']]],
  ['pfn_5ffile_5fmap_9',['pfn_file_map',['../structpfn__file__map.html',1,'']]],
  ['pfn_5fregion_10',['pfn_region',['../structpfn__region.html',1,'']]],
  ['pgtmeth_5fobject_11',['pgtmeth_object',['../structpgtmeth__object.html',1,'']]],
  ['phash_12',['phash',['../structphash.html',1,'']]],
  ['psw_13',['psw',['../structpsw.html',1,'']]]
];
