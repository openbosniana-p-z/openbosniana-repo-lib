var searchData=
[
  ['object_20lifetime_0',['Object Lifetime',['../md_objects.html',1,'']]]
];
