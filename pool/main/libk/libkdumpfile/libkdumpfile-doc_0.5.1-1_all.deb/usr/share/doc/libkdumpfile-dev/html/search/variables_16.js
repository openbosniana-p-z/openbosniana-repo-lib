var searchData=
[
  ['xen_5fmap_5foffset_0',['xen_map_offset',['../structelfdump__priv.html#a3d221dfa36329d6709f30b4dd0c6d21e',1,'elfdump_priv']]],
  ['xen_5fmfnmap_1',['xen_mfnmap',['../structelfdump__priv.html#abea61e2b307d7601a17e60514f10d06c',1,'elfdump_priv']]],
  ['xen_5fp2m_5fmfn_2',['xen_p2m_mfn',['../structparsed__opts.html#a0b6e123cd458dea4af04323422478a94',1,'parsed_opts']]],
  ['xen_5fpfnmap_3',['xen_pfnmap',['../structelfdump__priv.html#a323dbe0f57268630921736c2222cc282',1,'elfdump_priv']]],
  ['xen_5fxlat_4',['xen_xlat',['../structparsed__opts.html#afc195eb1e8b38c82a5d842e0b6f4b86b',1,'parsed_opts']]],
  ['xlat_5',['xlat',['../struct__kdump__ctx.html#a64bc1c0d4f8b07c6499227fe66f11114',1,'_kdump_ctx']]],
  ['xlat_5fcaps_6',['xlat_caps',['../structkdump__xlat.html#a568f3602b940d5fb3492757a73094370',1,'kdump_xlat']]],
  ['xlat_5flist_7',['xlat_list',['../struct__kdump__ctx.html#a3fd28cac032a6baacbae00eabaadeeb0',1,'_kdump_ctx']]],
  ['xlatcb_8',['xlatcb',['../struct__kdump__ctx.html#a58007bba0bde1813bdf18b0752eb79ec',1,'_kdump_ctx']]],
  ['xlatctx_9',['xlatctx',['../struct__kdump__ctx.html#a3434c7e3ee8328bbfed9ed7d52855e56',1,'_kdump_ctx']]],
  ['xlatsys_10',['xlatsys',['../structkdump__xlat.html#ab9cc47608d1a8dc7b6e4882b7ab00d59',1,'kdump_xlat']]]
];
