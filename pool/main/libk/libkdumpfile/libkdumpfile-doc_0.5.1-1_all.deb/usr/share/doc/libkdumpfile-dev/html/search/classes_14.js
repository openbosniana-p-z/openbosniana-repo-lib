var searchData=
[
  ['xen_5fcrash_5finfo_5f32_0',['xen_crash_info_32',['../structxen__crash__info__32.html',1,'']]],
  ['xen_5fcrash_5finfo_5f64_1',['xen_crash_info_64',['../structxen__crash__info__64.html',1,'']]],
  ['xen_5fcrash_5finfo_5fx86_2',['xen_crash_info_x86',['../structxen__crash__info__x86.html',1,'']]],
  ['xen_5fcrash_5finfo_5fx86_5f64_3',['xen_crash_info_x86_64',['../structxen__crash__info__x86__64.html',1,'']]],
  ['xen_5fdumpcore_5felfnote_5fxen_5fversion_5f32_4',['xen_dumpcore_elfnote_xen_version_32',['../structxen__dumpcore__elfnote__xen__version__32.html',1,'']]],
  ['xen_5fdumpcore_5felfnote_5fxen_5fversion_5f64_5',['xen_dumpcore_elfnote_xen_version_64',['../structxen__dumpcore__elfnote__xen__version__64.html',1,'']]],
  ['xen_5felfnote_5fheader_6',['xen_elfnote_header',['../structxen__elfnote__header.html',1,'']]],
  ['xen_5fp2m_7',['xen_p2m',['../structxen__p2m.html',1,'']]],
  ['xlat_5falt_8',['xlat_alt',['../structxlat__alt.html',1,'']]],
  ['xlat_5fchain_9',['xlat_chain',['../structxlat__chain.html',1,'']]]
];
