var searchData=
[
  ['val_0',['val',['../struct__addrxlat__opt.html#aef439d8b050d4e82cb2e9d7cee9b1a49',1,'_addrxlat_opt::val()'],['../struct__kdump__attr.html#aa0c68d9a564d3d6cdaed3fa903033834',1,'_kdump_attr::val()'],['../structphash.html#aa25b59893cbd1c7b74e769fc37838768',1,'phash::val()']]],
  ['valsz_1',['valsz',['../struct__addrxlat__param__memarr.html#a1721a52a25065cad865242e796cbf98f',1,'_addrxlat_param_memarr']]],
  ['ver_2',['ver',['../structaddrxlat__CAPI.html#a83b97d620856d4895a11800ddbba5000',1,'addrxlat_CAPI']]],
  ['version_5fcode_3',['version_code',['../structparsed__opts.html#a5685c7dc9d4eaf58e812307f54b09ee7',1,'parsed_opts']]],
  ['virt_5fbits_4',['virt_bits',['../structparsed__opts.html#a56b35648d88121746d7d9a701e414de9',1,'parsed_opts']]],
  ['vol_5fid_5',['vol_id',['../structsadump__part__header.html#a6323610d70238c375774a750fc83cd33',1,'sadump_part_header::vol_id()'],['../structdisk__id.html#a5eb881a13cf8aeeafa69de7023654140',1,'disk_id::vol_id()']]],
  ['vol_5finfo_6',['vol_info',['../structsadump__disk__set__header.html#ac73f3c08203469415596700e93d96006',1,'sadump_disk_set_header']]],
  ['vol_5fsize_7',['vol_size',['../structsadump__volume__info.html#a6130a893437ff663e0c641a40ead7809',1,'sadump_volume_info']]]
];
