var searchData=
[
  ['elem_0',['elem',['../struct__addrxlat__step.html#aaf19701702fca9747e8bbd7ae2731a6d',1,'_addrxlat_step']]],
  ['elemsize_1',['elemsize',['../structcache.html#a28948576614f52dfc52b94a6fe0bea72',1,'cache']]],
  ['elemsz_2',['elemsz',['../struct__addrxlat__param__memarr.html#ae39efc2c5b86977c908d20086a141a11',1,'_addrxlat_param_memarr::elemsz()'],['../struct__addrxlat__step.html#a9e5d57f6f1d0b835822bb0bed557d9d6',1,'_addrxlat_step::elemsz()']]],
  ['embed_5ffces_3',['embed_fces',['../structfcache__chunk.html#a37bbc4551bc6de977dc5818990e617ef',1,'fcache_chunk']]],
  ['enable_4',['enable',['../structsadump__part__header.html#aa625fcf6db1b2552a7dbadc0c9219d83',1,'sadump_part_header']]],
  ['end_5fpfn_5',['end_pfn',['../structpfn__file__map.html#a8fa2c07402a0038dfc63bfdc8222fe64',1,'pfn_file_map']]],
  ['endoff_6',['endoff',['../struct__addrxlat__range.html#a448f5cf56f5d7f7232e8281bc0229087',1,'_addrxlat_range::endoff()'],['../struct__addrxlat__param__lookup.html#aa466903add4a8372b54514e2a40b0f68',1,'_addrxlat_param_lookup::endoff()']]],
  ['entry_5fcleanup_7',['entry_cleanup',['../structcache.html#a9da4f671149ac8144255559072ee1b15',1,'cache']]],
  ['eprec_8',['eprec',['../structcache__search.html#ac2b4d22e08dbca8186a7848dc4014843',1,'cache_search']]],
  ['eprobe_9',['eprobe',['../structcache__search.html#a40fdd82ee00a54da2263945d422377ea',1,'cache_search']]],
  ['err_10',['err',['../struct__addrxlat__ctx.html#aaa2be3db22df2ddcbe09e73d5d2f9a20',1,'_addrxlat_ctx::err()'],['../struct__kdump__bmp.html#a6d4b731a0124ca9ce5beebf48e7582a1',1,'_kdump_bmp::err()'],['../struct__kdump__ctx.html#a559a80e8cae7f8d6f713209be79826a8',1,'_kdump_ctx::err()']]],
  ['ext_11',['ext',['../structsadump__priv.html#a8ee09d87226c909644edef09bc68abc3',1,'sadump_priv']]],
  ['extra_5fhdr_5fsize_12',['extra_hdr_size',['../structsadump__header.html#a3d74f455f97b87718aae36a29a69b180',1,'sadump_header']]]
];
