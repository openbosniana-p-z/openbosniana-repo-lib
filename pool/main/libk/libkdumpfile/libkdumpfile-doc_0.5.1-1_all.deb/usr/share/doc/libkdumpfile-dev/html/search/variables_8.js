var searchData=
[
  ['header_5fversion_0',['header_version',['../structsadump__header.html#ac1d466a97d312084108f4ec894f0e031',1,'sadump_header']]],
  ['hits_1',['hits',['../structcache.html#a99c57a9b954475daef396f5851c5a717',1,'cache']]],
  ['hour_2',['hour',['../structefi__time.html#a6bce8e132c76418da6cbca791138302b',1,'efi_time']]]
];
