
#ifndef PIMCOMMON_EXPORT_H
#define PIMCOMMON_EXPORT_H

#ifdef PIMCOMMON_STATIC_DEFINE
#  define PIMCOMMON_EXPORT
#  define PIMCOMMON_NO_EXPORT
#else
#  ifndef PIMCOMMON_EXPORT
#    ifdef KF5PimCommon_EXPORTS
        /* We are building this library */
#      define PIMCOMMON_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define PIMCOMMON_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef PIMCOMMON_NO_EXPORT
#    define PIMCOMMON_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef PIMCOMMON_DEPRECATED
#  define PIMCOMMON_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef PIMCOMMON_DEPRECATED_EXPORT
#  define PIMCOMMON_DEPRECATED_EXPORT PIMCOMMON_EXPORT PIMCOMMON_DEPRECATED
#endif

#ifndef PIMCOMMON_DEPRECATED_NO_EXPORT
#  define PIMCOMMON_DEPRECATED_NO_EXPORT PIMCOMMON_NO_EXPORT PIMCOMMON_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef PIMCOMMON_NO_DEPRECATED
#    define PIMCOMMON_NO_DEPRECATED
#  endif
#endif

#endif /* PIMCOMMON_EXPORT_H */
