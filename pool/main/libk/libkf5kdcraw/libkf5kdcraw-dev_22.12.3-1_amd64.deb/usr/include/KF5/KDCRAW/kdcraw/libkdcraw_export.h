
#ifndef LIBKDCRAW_EXPORT_H
#define LIBKDCRAW_EXPORT_H

#ifdef LIBKDCRAW_STATIC_DEFINE
#  define LIBKDCRAW_EXPORT
#  define LIBKDCRAW_NO_EXPORT
#else
#  ifndef LIBKDCRAW_EXPORT
#    ifdef KDcraw_EXPORTS
        /* We are building this library */
#      define LIBKDCRAW_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBKDCRAW_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBKDCRAW_NO_EXPORT
#    define LIBKDCRAW_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBKDCRAW_DEPRECATED
#  define LIBKDCRAW_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBKDCRAW_DEPRECATED_EXPORT
#  define LIBKDCRAW_DEPRECATED_EXPORT LIBKDCRAW_EXPORT LIBKDCRAW_DEPRECATED
#endif

#ifndef LIBKDCRAW_DEPRECATED_NO_EXPORT
#  define LIBKDCRAW_DEPRECATED_NO_EXPORT LIBKDCRAW_NO_EXPORT LIBKDCRAW_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBKDCRAW_NO_DEPRECATED
#    define LIBKDCRAW_NO_DEPRECATED
#  endif
#endif

#endif /* LIBKDCRAW_EXPORT_H */
