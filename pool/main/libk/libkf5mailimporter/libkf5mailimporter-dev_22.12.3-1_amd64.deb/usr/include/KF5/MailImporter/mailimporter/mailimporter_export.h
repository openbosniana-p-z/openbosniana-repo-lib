
#ifndef MAILIMPORTER_EXPORT_H
#define MAILIMPORTER_EXPORT_H

#ifdef MAILIMPORTER_STATIC_DEFINE
#  define MAILIMPORTER_EXPORT
#  define MAILIMPORTER_NO_EXPORT
#else
#  ifndef MAILIMPORTER_EXPORT
#    ifdef KF5MailImporter_EXPORTS
        /* We are building this library */
#      define MAILIMPORTER_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define MAILIMPORTER_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MAILIMPORTER_NO_EXPORT
#    define MAILIMPORTER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MAILIMPORTER_DEPRECATED
#  define MAILIMPORTER_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MAILIMPORTER_DEPRECATED_EXPORT
#  define MAILIMPORTER_DEPRECATED_EXPORT MAILIMPORTER_EXPORT MAILIMPORTER_DEPRECATED
#endif

#ifndef MAILIMPORTER_DEPRECATED_NO_EXPORT
#  define MAILIMPORTER_DEPRECATED_NO_EXPORT MAILIMPORTER_NO_EXPORT MAILIMPORTER_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MAILIMPORTER_NO_DEPRECATED
#    define MAILIMPORTER_NO_DEPRECATED
#  endif
#endif

#endif /* MAILIMPORTER_EXPORT_H */
