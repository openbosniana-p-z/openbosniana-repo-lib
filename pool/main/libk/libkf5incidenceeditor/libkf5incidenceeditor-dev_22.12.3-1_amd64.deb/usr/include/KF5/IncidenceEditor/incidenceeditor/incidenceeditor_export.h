
#ifndef INCIDENCEEDITOR_EXPORT_H
#define INCIDENCEEDITOR_EXPORT_H

#ifdef INCIDENCEEDITOR_STATIC_DEFINE
#  define INCIDENCEEDITOR_EXPORT
#  define INCIDENCEEDITOR_NO_EXPORT
#else
#  ifndef INCIDENCEEDITOR_EXPORT
#    ifdef KF5IncidenceEditor_EXPORTS
        /* We are building this library */
#      define INCIDENCEEDITOR_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define INCIDENCEEDITOR_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef INCIDENCEEDITOR_NO_EXPORT
#    define INCIDENCEEDITOR_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef INCIDENCEEDITOR_DEPRECATED
#  define INCIDENCEEDITOR_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef INCIDENCEEDITOR_DEPRECATED_EXPORT
#  define INCIDENCEEDITOR_DEPRECATED_EXPORT INCIDENCEEDITOR_EXPORT INCIDENCEEDITOR_DEPRECATED
#endif

#ifndef INCIDENCEEDITOR_DEPRECATED_NO_EXPORT
#  define INCIDENCEEDITOR_DEPRECATED_NO_EXPORT INCIDENCEEDITOR_NO_EXPORT INCIDENCEEDITOR_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef INCIDENCEEDITOR_NO_DEPRECATED
#    define INCIDENCEEDITOR_NO_DEPRECATED
#  endif
#endif

#endif /* INCIDENCEEDITOR_EXPORT_H */
