
#ifndef KGAPICORE_EXPORT_H
#define KGAPICORE_EXPORT_H

#ifdef KGAPICORE_STATIC_DEFINE
#  define KGAPICORE_EXPORT
#  define KGAPICORE_NO_EXPORT
#else
#  ifndef KGAPICORE_EXPORT
#    ifdef KPimGAPICore_EXPORTS
        /* We are building this library */
#      define KGAPICORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KGAPICORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KGAPICORE_NO_EXPORT
#    define KGAPICORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KGAPICORE_DEPRECATED
#  define KGAPICORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KGAPICORE_DEPRECATED_EXPORT
#  define KGAPICORE_DEPRECATED_EXPORT KGAPICORE_EXPORT KGAPICORE_DEPRECATED
#endif

#ifndef KGAPICORE_DEPRECATED_NO_EXPORT
#  define KGAPICORE_DEPRECATED_NO_EXPORT KGAPICORE_NO_EXPORT KGAPICORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KGAPICORE_NO_DEPRECATED
#    define KGAPICORE_NO_DEPRECATED
#  endif
#endif

#endif /* KGAPICORE_EXPORT_H */
