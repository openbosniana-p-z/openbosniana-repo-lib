
#ifndef KGAPILATITUDE_EXPORT_H
#define KGAPILATITUDE_EXPORT_H

#ifdef KGAPILATITUDE_STATIC_DEFINE
#  define KGAPILATITUDE_EXPORT
#  define KGAPILATITUDE_NO_EXPORT
#else
#  ifndef KGAPILATITUDE_EXPORT
#    ifdef KPimGAPILatitude_EXPORTS
        /* We are building this library */
#      define KGAPILATITUDE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KGAPILATITUDE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KGAPILATITUDE_NO_EXPORT
#    define KGAPILATITUDE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KGAPILATITUDE_DEPRECATED
#  define KGAPILATITUDE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KGAPILATITUDE_DEPRECATED_EXPORT
#  define KGAPILATITUDE_DEPRECATED_EXPORT KGAPILATITUDE_EXPORT KGAPILATITUDE_DEPRECATED
#endif

#ifndef KGAPILATITUDE_DEPRECATED_NO_EXPORT
#  define KGAPILATITUDE_DEPRECATED_NO_EXPORT KGAPILATITUDE_NO_EXPORT KGAPILATITUDE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KGAPILATITUDE_NO_DEPRECATED
#    define KGAPILATITUDE_NO_DEPRECATED
#  endif
#endif

#endif /* KGAPILATITUDE_EXPORT_H */
