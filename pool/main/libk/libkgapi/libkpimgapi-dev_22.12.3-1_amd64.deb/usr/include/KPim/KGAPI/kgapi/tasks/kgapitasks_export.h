
#ifndef KGAPITASKS_EXPORT_H
#define KGAPITASKS_EXPORT_H

#ifdef KGAPITASKS_STATIC_DEFINE
#  define KGAPITASKS_EXPORT
#  define KGAPITASKS_NO_EXPORT
#else
#  ifndef KGAPITASKS_EXPORT
#    ifdef KPimGAPITasks_EXPORTS
        /* We are building this library */
#      define KGAPITASKS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KGAPITASKS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KGAPITASKS_NO_EXPORT
#    define KGAPITASKS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KGAPITASKS_DEPRECATED
#  define KGAPITASKS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KGAPITASKS_DEPRECATED_EXPORT
#  define KGAPITASKS_DEPRECATED_EXPORT KGAPITASKS_EXPORT KGAPITASKS_DEPRECATED
#endif

#ifndef KGAPITASKS_DEPRECATED_NO_EXPORT
#  define KGAPITASKS_DEPRECATED_NO_EXPORT KGAPITASKS_NO_EXPORT KGAPITASKS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KGAPITASKS_NO_DEPRECATED
#    define KGAPITASKS_NO_DEPRECATED
#  endif
#endif

#endif /* KGAPITASKS_EXPORT_H */
