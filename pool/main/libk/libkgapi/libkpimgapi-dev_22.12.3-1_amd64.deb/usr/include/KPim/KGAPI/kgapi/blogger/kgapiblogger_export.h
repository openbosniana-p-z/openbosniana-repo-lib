
#ifndef KGAPIBLOGGER_EXPORT_H
#define KGAPIBLOGGER_EXPORT_H

#ifdef KGAPIBLOGGER_STATIC_DEFINE
#  define KGAPIBLOGGER_EXPORT
#  define KGAPIBLOGGER_NO_EXPORT
#else
#  ifndef KGAPIBLOGGER_EXPORT
#    ifdef KPimGAPIBlogger_EXPORTS
        /* We are building this library */
#      define KGAPIBLOGGER_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KGAPIBLOGGER_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KGAPIBLOGGER_NO_EXPORT
#    define KGAPIBLOGGER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KGAPIBLOGGER_DEPRECATED
#  define KGAPIBLOGGER_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KGAPIBLOGGER_DEPRECATED_EXPORT
#  define KGAPIBLOGGER_DEPRECATED_EXPORT KGAPIBLOGGER_EXPORT KGAPIBLOGGER_DEPRECATED
#endif

#ifndef KGAPIBLOGGER_DEPRECATED_NO_EXPORT
#  define KGAPIBLOGGER_DEPRECATED_NO_EXPORT KGAPIBLOGGER_NO_EXPORT KGAPIBLOGGER_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KGAPIBLOGGER_NO_DEPRECATED
#    define KGAPIBLOGGER_NO_DEPRECATED
#  endif
#endif

#endif /* KGAPIBLOGGER_EXPORT_H */
