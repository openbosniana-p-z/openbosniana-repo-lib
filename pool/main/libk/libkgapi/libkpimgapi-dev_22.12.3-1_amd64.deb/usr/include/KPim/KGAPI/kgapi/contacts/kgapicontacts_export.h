
#ifndef KGAPICONTACTS_EXPORT_H
#define KGAPICONTACTS_EXPORT_H

#ifdef KGAPICONTACTS_STATIC_DEFINE
#  define KGAPICONTACTS_EXPORT
#  define KGAPICONTACTS_NO_EXPORT
#else
#  ifndef KGAPICONTACTS_EXPORT
#    ifdef KPimGAPIContacts_EXPORTS
        /* We are building this library */
#      define KGAPICONTACTS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KGAPICONTACTS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KGAPICONTACTS_NO_EXPORT
#    define KGAPICONTACTS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KGAPICONTACTS_DEPRECATED
#  define KGAPICONTACTS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KGAPICONTACTS_DEPRECATED_EXPORT
#  define KGAPICONTACTS_DEPRECATED_EXPORT KGAPICONTACTS_EXPORT KGAPICONTACTS_DEPRECATED
#endif

#ifndef KGAPICONTACTS_DEPRECATED_NO_EXPORT
#  define KGAPICONTACTS_DEPRECATED_NO_EXPORT KGAPICONTACTS_NO_EXPORT KGAPICONTACTS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KGAPICONTACTS_NO_DEPRECATED
#    define KGAPICONTACTS_NO_DEPRECATED
#  endif
#endif

#endif /* KGAPICONTACTS_EXPORT_H */
