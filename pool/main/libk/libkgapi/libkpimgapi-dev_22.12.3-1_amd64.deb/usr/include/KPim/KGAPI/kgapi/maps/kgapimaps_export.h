
#ifndef KGAPIMAPS_EXPORT_H
#define KGAPIMAPS_EXPORT_H

#ifdef KGAPIMAPS_STATIC_DEFINE
#  define KGAPIMAPS_EXPORT
#  define KGAPIMAPS_NO_EXPORT
#else
#  ifndef KGAPIMAPS_EXPORT
#    ifdef KPimGAPIMaps_EXPORTS
        /* We are building this library */
#      define KGAPIMAPS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KGAPIMAPS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KGAPIMAPS_NO_EXPORT
#    define KGAPIMAPS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KGAPIMAPS_DEPRECATED
#  define KGAPIMAPS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KGAPIMAPS_DEPRECATED_EXPORT
#  define KGAPIMAPS_DEPRECATED_EXPORT KGAPIMAPS_EXPORT KGAPIMAPS_DEPRECATED
#endif

#ifndef KGAPIMAPS_DEPRECATED_NO_EXPORT
#  define KGAPIMAPS_DEPRECATED_NO_EXPORT KGAPIMAPS_NO_EXPORT KGAPIMAPS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KGAPIMAPS_NO_DEPRECATED
#    define KGAPIMAPS_NO_DEPRECATED
#  endif
#endif

#endif /* KGAPIMAPS_EXPORT_H */
