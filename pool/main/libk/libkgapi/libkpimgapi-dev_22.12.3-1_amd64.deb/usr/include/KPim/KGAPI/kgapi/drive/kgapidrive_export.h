
#ifndef KGAPIDRIVE_EXPORT_H
#define KGAPIDRIVE_EXPORT_H

#ifdef KGAPIDRIVE_STATIC_DEFINE
#  define KGAPIDRIVE_EXPORT
#  define KGAPIDRIVE_NO_EXPORT
#else
#  ifndef KGAPIDRIVE_EXPORT
#    ifdef KPimGAPIDrive_EXPORTS
        /* We are building this library */
#      define KGAPIDRIVE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KGAPIDRIVE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KGAPIDRIVE_NO_EXPORT
#    define KGAPIDRIVE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KGAPIDRIVE_DEPRECATED
#  define KGAPIDRIVE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KGAPIDRIVE_DEPRECATED_EXPORT
#  define KGAPIDRIVE_DEPRECATED_EXPORT KGAPIDRIVE_EXPORT KGAPIDRIVE_DEPRECATED
#endif

#ifndef KGAPIDRIVE_DEPRECATED_NO_EXPORT
#  define KGAPIDRIVE_DEPRECATED_NO_EXPORT KGAPIDRIVE_NO_EXPORT KGAPIDRIVE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KGAPIDRIVE_NO_DEPRECATED
#    define KGAPIDRIVE_NO_DEPRECATED
#  endif
#endif

#endif /* KGAPIDRIVE_EXPORT_H */
