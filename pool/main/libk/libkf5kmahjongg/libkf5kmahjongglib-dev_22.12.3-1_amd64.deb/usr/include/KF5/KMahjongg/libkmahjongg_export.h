
#ifndef LIBKMAHJONGG_EXPORT_H
#define LIBKMAHJONGG_EXPORT_H

#ifdef LIBKMAHJONGG_STATIC_DEFINE
#  define LIBKMAHJONGG_EXPORT
#  define LIBKMAHJONGG_NO_EXPORT
#else
#  ifndef LIBKMAHJONGG_EXPORT
#    ifdef KMahjongglib_EXPORTS
        /* We are building this library */
#      define LIBKMAHJONGG_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBKMAHJONGG_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBKMAHJONGG_NO_EXPORT
#    define LIBKMAHJONGG_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBKMAHJONGG_DEPRECATED
#  define LIBKMAHJONGG_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBKMAHJONGG_DEPRECATED_EXPORT
#  define LIBKMAHJONGG_DEPRECATED_EXPORT LIBKMAHJONGG_EXPORT LIBKMAHJONGG_DEPRECATED
#endif

#ifndef LIBKMAHJONGG_DEPRECATED_NO_EXPORT
#  define LIBKMAHJONGG_DEPRECATED_NO_EXPORT LIBKMAHJONGG_NO_EXPORT LIBKMAHJONGG_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBKMAHJONGG_NO_DEPRECATED
#    define LIBKMAHJONGG_NO_DEPRECATED
#  endif
#endif

#endif /* LIBKMAHJONGG_EXPORT_H */
