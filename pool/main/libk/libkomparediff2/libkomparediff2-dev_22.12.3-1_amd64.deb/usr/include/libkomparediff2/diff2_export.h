
#ifndef DIFF2_EXPORT_H
#define DIFF2_EXPORT_H

#ifdef DIFF2_STATIC_DEFINE
#  define DIFF2_EXPORT
#  define DIFF2_NO_EXPORT
#else
#  ifndef DIFF2_EXPORT
#    ifdef komparediff2_EXPORTS
        /* We are building this library */
#      define DIFF2_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define DIFF2_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef DIFF2_NO_EXPORT
#    define DIFF2_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef DIFF2_DEPRECATED
#  define DIFF2_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef DIFF2_DEPRECATED_EXPORT
#  define DIFF2_DEPRECATED_EXPORT DIFF2_EXPORT DIFF2_DEPRECATED
#endif

#ifndef DIFF2_DEPRECATED_NO_EXPORT
#  define DIFF2_DEPRECATED_NO_EXPORT DIFF2_NO_EXPORT DIFF2_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef DIFF2_NO_DEPRECATED
#    define DIFF2_NO_DEPRECATED
#  endif
#endif

#endif /* DIFF2_EXPORT_H */
