
#ifndef KDEPIM_EXPORT_H
#define KDEPIM_EXPORT_H

#ifdef KDEPIM_STATIC_DEFINE
#  define KDEPIM_EXPORT
#  define KDEPIM_NO_EXPORT
#else
#  ifndef KDEPIM_EXPORT
#    ifdef KF5Libkdepim_EXPORTS
        /* We are building this library */
#      define KDEPIM_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KDEPIM_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KDEPIM_NO_EXPORT
#    define KDEPIM_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KDEPIM_DEPRECATED
#  define KDEPIM_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KDEPIM_DEPRECATED_EXPORT
#  define KDEPIM_DEPRECATED_EXPORT KDEPIM_EXPORT KDEPIM_DEPRECATED
#endif

#ifndef KDEPIM_DEPRECATED_NO_EXPORT
#  define KDEPIM_DEPRECATED_NO_EXPORT KDEPIM_NO_EXPORT KDEPIM_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KDEPIM_NO_DEPRECATED
#    define KDEPIM_NO_DEPRECATED
#  endif
#endif

#endif /* KDEPIM_EXPORT_H */
