package Mail::SRS::Reversable;
use Carp qw(croak);
croak
	"Please use Mail::SRS::Reversible instead of Mail::SRS::Reversable";
1;
