package Mason::Test::Plugins::Notify;
$Mason::Test::Plugins::Notify::VERSION = '2.24';
use strict;
use warnings;
use base qw(Mason::Plugin);

1;
