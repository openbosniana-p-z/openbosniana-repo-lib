package Mason::Test::RootClass;
$Mason::Test::RootClass::VERSION = '2.24';
use strict;
use warnings;
use base qw(Mason);

1;
