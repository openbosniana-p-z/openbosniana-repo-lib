`MediaWiki::Bot` is unmaintained. Please do not file new issues without a patch.

"Unmaintained" means that we are doing no new development, not even fixing bugs. However,
we will still accept patches and make releases to CPAN. We are aware that the tests are
failing, and we are not going to fix it -- but you are welcome to. Upon submitting a
pull request, you can expect to receive code review feedback within 1 week. Releases to
CPAN are not scheduled, and are done on an as-needed basis. Typically, this means a new
release goes out shortly after a patch is merged, although we may wait for more patches
to land if we expect them to be merged shortly.
