var searchData=
[
  ['one_39',['ONE',['../namespacems_1_1numpress_1_1MSNumpress.html#a830841371fb7c0ba0f810b56536c6b50',1,'ms::numpress::MSNumpress']]],
  ['optimallinearfixedpoint_40',['optimalLinearFixedPoint',['../namespacems_1_1numpress_1_1MSNumpress.html#a3332d228ff74b97e692fbaf4d289abe7',1,'ms::numpress::MSNumpress::optimalLinearFixedPoint()'],['../MSNumpressTest_8cpp.html#abe8fe0faa0b6b0c624ee5062e77b5890',1,'optimalLinearFixedPoint():&#160;MSNumpressTest.cpp']]],
  ['optimallinearfixedpointmass_41',['optimalLinearFixedPointMass',['../namespacems_1_1numpress_1_1MSNumpress.html#ad8c04bcd8e87d16b05d37f2da406032e',1,'ms::numpress::MSNumpress::optimalLinearFixedPointMass()'],['../MSNumpressTest_8cpp.html#a374749ae2aef2508adaf16b356c6c347',1,'optimalLinearFixedPointMass():&#160;MSNumpressTest.cpp']]],
  ['optimalsloffixedpoint_42',['optimalSlofFixedPoint',['../namespacems_1_1numpress_1_1MSNumpress.html#a3ad99f94b29e8e655a184535d30a3ce7',1,'ms::numpress::MSNumpress::optimalSlofFixedPoint()'],['../MSNumpressTest_8cpp.html#a775ae3583dbbfd6fa5a4e4c34b98f355',1,'optimalSlofFixedPoint():&#160;MSNumpressTest.cpp']]]
];
