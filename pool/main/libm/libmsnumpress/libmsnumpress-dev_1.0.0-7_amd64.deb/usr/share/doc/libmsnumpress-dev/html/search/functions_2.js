var searchData=
[
  ['is_5flittle_5fendian_81',['is_little_endian',['../namespacems_1_1numpress_1_1MSNumpress.html#ab363c520a25bd39a836fe67ba20914f6',1,'ms::numpress::MSNumpress']]]
];
