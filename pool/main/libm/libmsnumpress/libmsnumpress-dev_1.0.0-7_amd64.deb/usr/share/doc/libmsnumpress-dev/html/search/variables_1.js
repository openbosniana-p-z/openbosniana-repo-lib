var searchData=
[
  ['is_5flittle_5fendian_88',['IS_LITTLE_ENDIAN',['../namespacems_1_1numpress_1_1MSNumpress.html#a5c7f64062fd19cce531069896dfb9518',1,'ms::numpress::MSNumpress']]]
];
