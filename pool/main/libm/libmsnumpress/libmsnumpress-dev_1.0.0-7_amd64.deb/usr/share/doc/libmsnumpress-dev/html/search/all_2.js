var searchData=
[
  ['is_5flittle_5fendian_31',['IS_LITTLE_ENDIAN',['../namespacems_1_1numpress_1_1MSNumpress.html#a5c7f64062fd19cce531069896dfb9518',1,'ms::numpress::MSNumpress::IS_LITTLE_ENDIAN()'],['../namespacems_1_1numpress_1_1MSNumpress.html#ab363c520a25bd39a836fe67ba20914f6',1,'ms::numpress::MSNumpress::is_little_endian()']]]
];
