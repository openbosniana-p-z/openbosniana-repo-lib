var searchData=
[
  ['enc_5ftwo_5fbyte_5ffixed_5fpoint_14',['ENC_TWO_BYTE_FIXED_POINT',['../MSNumpressTest_8cpp.html#a1b51842e51c4ae08c7bc2b84463ddc72',1,'MSNumpressTest.cpp']]],
  ['encodedecodelinear_15',['encodeDecodeLinear',['../MSNumpressTest_8cpp.html#a73d474fea5d64fd2058ced08fa82a02c',1,'MSNumpressTest.cpp']]],
  ['encodedecodelinear5_16',['encodeDecodeLinear5',['../MSNumpressTest_8cpp.html#a4bf3efb464943c3cf653075ac77ac3b6',1,'MSNumpressTest.cpp']]],
  ['encodedecodelinearstraight_17',['encodeDecodeLinearStraight',['../MSNumpressTest_8cpp.html#a0290eb660c9b073bfcc2159486f3864b',1,'MSNumpressTest.cpp']]],
  ['encodedecodepic_18',['encodeDecodePic',['../MSNumpressTest_8cpp.html#a5f5e54f235ff6cdbcc8aff5ddfaaaa5c',1,'MSNumpressTest.cpp']]],
  ['encodedecodepic5_19',['encodeDecodePic5',['../MSNumpressTest_8cpp.html#aa8909f856967f7843ffba3a7be418801',1,'MSNumpressTest.cpp']]],
  ['encodedecodesafe_20',['encodeDecodeSafe',['../MSNumpressTest_8cpp.html#a03488b207573c1afbaddde1e969a8481',1,'MSNumpressTest.cpp']]],
  ['encodedecodesafestraight_21',['encodeDecodeSafeStraight',['../MSNumpressTest_8cpp.html#aeaac92238c5bc520996ed25a87d39f99',1,'MSNumpressTest.cpp']]],
  ['encodedecodeslof_22',['encodeDecodeSlof',['../MSNumpressTest_8cpp.html#a0bc66b7fb8f4fe1e0a65f38306a28b67',1,'MSNumpressTest.cpp']]],
  ['encodedecodeslof5_23',['encodeDecodeSlof5',['../MSNumpressTest_8cpp.html#a20d436b5904627de0e97e27f5dd8851b',1,'MSNumpressTest.cpp']]],
  ['encodefixedpoint_24',['encodeFixedPoint',['../namespacems_1_1numpress_1_1MSNumpress.html#a07c00c97030e71cc4def405a97b31156',1,'ms::numpress::MSNumpress']]],
  ['encodeint_25',['encodeInt',['../namespacems_1_1numpress_1_1MSNumpress.html#ad52057a26533739c6f9a48635e0b5c1d',1,'ms::numpress::MSNumpress']]],
  ['encodelinear_26',['encodeLinear',['../namespacems_1_1numpress_1_1MSNumpress.html#ad57d879454d424bec0bbfda44dcadb63',1,'ms::numpress::MSNumpress::encodeLinear(const double *data, size_t dataSize, unsigned char *result, double fixedPoint)'],['../namespacems_1_1numpress_1_1MSNumpress.html#a91bd4418b454db0c36725d65319fd527',1,'ms::numpress::MSNumpress::encodeLinear(const std::vector&lt; double &gt; &amp;data, std::vector&lt; unsigned char &gt; &amp;result, double fixedPoint)'],['../MSNumpressTest_8cpp.html#a26266ff99ae028ba492488064753e7d7',1,'encodeLinear():&#160;MSNumpressTest.cpp']]],
  ['encodelinear1_27',['encodeLinear1',['../MSNumpressTest_8cpp.html#ab8a32b2277d7509d1dd6cd51b5875fff',1,'MSNumpressTest.cpp']]],
  ['encodepic_28',['encodePic',['../namespacems_1_1numpress_1_1MSNumpress.html#a25438867f28e56f7ae09439aa1a7ca93',1,'ms::numpress::MSNumpress::encodePic(const double *data, size_t dataSize, unsigned char *result)'],['../namespacems_1_1numpress_1_1MSNumpress.html#a92e37701ccb73f469c2c9c9be7ec78a2',1,'ms::numpress::MSNumpress::encodePic(const std::vector&lt; double &gt; &amp;data, std::vector&lt; unsigned char &gt; &amp;result)']]],
  ['encodesafe_29',['encodeSafe',['../namespacems_1_1numpress_1_1MSNumpress.html#a706009e575d08e367761aa1dd6187bf7',1,'ms::numpress::MSNumpress']]],
  ['encodeslof_30',['encodeSlof',['../namespacems_1_1numpress_1_1MSNumpress.html#a65a2b5be44b93bafe040160d012660b2',1,'ms::numpress::MSNumpress::encodeSlof(const double *data, size_t dataSize, unsigned char *result, double fixedPoint)'],['../namespacems_1_1numpress_1_1MSNumpress.html#a69394874b8d12cf319c14442ed710f5e',1,'ms::numpress::MSNumpress::encodeSlof(const std::vector&lt; double &gt; &amp;data, std::vector&lt; unsigned char &gt; &amp;result, double fixedPoint)']]]
];
