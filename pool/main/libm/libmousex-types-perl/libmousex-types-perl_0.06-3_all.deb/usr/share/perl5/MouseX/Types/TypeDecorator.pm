package MouseX::Types::TypeDecorator;
use strict;
use warnings;

use Carp;

carp(__PACKAGE__ . ' is deprecated, and no longer used anywhere');
1;
