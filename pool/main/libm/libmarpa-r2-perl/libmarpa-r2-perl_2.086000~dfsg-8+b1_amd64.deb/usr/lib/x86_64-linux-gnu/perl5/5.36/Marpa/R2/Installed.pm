# This file is written by Build.PL
# It is not intended to be modified directly

package Marpa::R2::Installed;
use vars qw($VERSION $STRING_VERSION);
$VERSION = '2.086000';
$STRING_VERSION = $VERSION;
$VERSION = eval $VERSION;
1;
