# This file is written by Build.PL
# It is not intended to be modified directly

package Marpa::R2;
use vars qw($TIMESTAMP);
$TIMESTAMP='2022-10-20T09:35:40';
use Scalar::Util 1.21 ();
use List::Util 1.21 ();
use Carp 1.08 ();
use Data::Dumper 2.125 ();
1;
