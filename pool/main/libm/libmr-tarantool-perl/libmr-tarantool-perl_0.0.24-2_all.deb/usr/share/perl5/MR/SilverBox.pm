package MR::SilverBox;
use MR::Tarantool::Box;
use base qw/MR::Tarantool::Box/;

=pod

=head1 NAME

MR::SilverBox - no-op module for backward compatibility

=head1 DESCRIPTION

A backward-compatiblity module. Is it obsolete and is unsupported. Do not use.

=head1 SEE ALSO

L<MR::Tarantool::Box>

=cut

1;
