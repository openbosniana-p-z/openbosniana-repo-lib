The latest source/development version is available at https://github.com/joolswills/mediawikiapi

Please submit any fixes/patches as Pull Requests.

For large changes or feature additions please open an issue and start a discussion first.