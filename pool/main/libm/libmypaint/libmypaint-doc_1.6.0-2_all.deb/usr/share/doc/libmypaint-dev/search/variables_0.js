var searchData=
[
  ['active_460',['active',['../structMyPaintSymmetryData.html#a9ee97642e300e98140a43d5cf2dd1c5f',1,'MyPaintSymmetryData']]],
  ['angle_461',['angle',['../structMyPaintSymmetryState.html#a450f9233334d8f371bf5559f6e1db0a3',1,'MyPaintSymmetryState']]]
];
