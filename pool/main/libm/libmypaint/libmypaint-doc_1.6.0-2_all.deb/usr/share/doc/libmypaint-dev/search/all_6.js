var searchData=
[
  ['g_5fbegin_5fdecls_18',['G_BEGIN_DECLS',['../mypaint-glib-compat_8h.html#a72c1126856454c07c2f9ab131aa7f2a3',1,'mypaint-glib-compat.h']]],
  ['g_5fend_5fdecls_19',['G_END_DECLS',['../mypaint-glib-compat_8h.html#a592df9359e90124ffc0d185505c9d567',1,'mypaint-glib-compat.h']]],
  ['gboolean_20',['gboolean',['../mypaint-glib-compat_8h.html#a3fbd4b724cd3917d53d4b4204a4963e5',1,'mypaint-glib-compat.h']]],
  ['gchar_21',['gchar',['../mypaint-glib-compat_8h.html#a54cda4d0b1b475ae7c855edbf17b4a59',1,'mypaint-glib-compat.h']]],
  ['get_5fcolor_22',['get_color',['../structMyPaintSurface.html#a0c556cf1f828bca5cc11f6347fb6b420',1,'MyPaintSurface']]],
  ['get_5fcolor_5fpigment_23',['get_color_pigment',['../structMyPaintSurface2.html#aecf57b7f569b527beecc5e7878ff7c03',1,'MyPaintSurface2']]],
  ['gint_24',['gint',['../mypaint-glib-compat_8h.html#a94f7fe39540fb07a3c09be37e16112b0',1,'mypaint-glib-compat.h']]],
  ['gpointer_25',['gpointer',['../mypaint-glib-compat_8h.html#a82239d7d1ad8c85a21637b644b4e7832',1,'mypaint-glib-compat.h']]],
  ['guint16_26',['guint16',['../mypaint-glib-compat_8h.html#a3bc4f8eb3fdb8f52c41c3c3d7a05444f',1,'mypaint-glib-compat.h']]]
];
