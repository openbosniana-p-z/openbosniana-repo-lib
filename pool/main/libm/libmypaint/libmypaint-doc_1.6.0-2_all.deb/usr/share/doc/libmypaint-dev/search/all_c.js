var searchData=
[
  ['parent_315',['parent',['../structMyPaintSurface2.html#a324a455ad3a3937543a87def0ebebbdd',1,'MyPaintSurface2::parent()'],['../structMyPaintTiledSurface.html#acc9db0df42d7e283f49c8f95950e6bcc',1,'MyPaintTiledSurface::parent()'],['../structMyPaintTiledSurface2.html#a95a5cfa304fe2511168cdff3288cf607',1,'MyPaintTiledSurface2::parent()']]],
  ['pending_5fchanges_316',['pending_changes',['../structMyPaintSymmetryData.html#acbf67703b3a0d04e1fea031b1b7ea529',1,'MyPaintSymmetryData']]]
];
