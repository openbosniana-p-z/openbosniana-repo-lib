var searchData=
[
  ['save_5fpng_321',['save_png',['../structMyPaintSurface.html#a4f7b3b9c50e5d7c763380b8f1a1ce00d',1,'MyPaintSurface']]],
  ['soft_5fmax_322',['soft_max',['../structMyPaintBrushInputInfo.html#af038a9ea3eb2220c378c5e1da3ee5237',1,'MyPaintBrushInputInfo']]],
  ['soft_5fmin_323',['soft_min',['../structMyPaintBrushInputInfo.html#aa41cfb37064270800aaea39ff6f6bb9d',1,'MyPaintBrushInputInfo']]],
  ['state_5fcurrent_324',['state_current',['../structMyPaintSymmetryData.html#ab09b1a620a1571338ed98980743fd299',1,'MyPaintSymmetryData']]],
  ['state_5fpending_325',['state_pending',['../structMyPaintSymmetryData.html#a1250d36bfdc8a86c7513c881fb8fb2ef',1,'MyPaintSymmetryData']]],
  ['surface_5fcenter_5fx_326',['surface_center_x',['../structMyPaintTiledSurface.html#a5c25fb924e454de0e63d83f1c46e5af8',1,'MyPaintTiledSurface']]],
  ['surface_5fdo_5fsymmetry_327',['surface_do_symmetry',['../structMyPaintTiledSurface.html#a3b4c989bc439fd3df50b7ee3bcb2f20b',1,'MyPaintTiledSurface']]],
  ['symmetry_5fdata_328',['symmetry_data',['../structMyPaintTiledSurface2.html#aafd3ebb4ef551139f9d8b332a753ed54',1,'MyPaintTiledSurface2']]],
  ['symmetry_5fmatrices_329',['symmetry_matrices',['../structMyPaintSymmetryData.html#a7cbf44e4200ba43fbefe1e8c7ca4adaf',1,'MyPaintSymmetryData']]]
];
