var searchData=
[
  ['false_17',['FALSE',['../mypaint-glib-compat_8h.html#aa93f0eb578d23995850d61f7d61c55c1',1,'mypaint-glib-compat.h']]]
];
