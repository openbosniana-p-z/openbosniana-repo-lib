var searchData=
[
  ['hard_5fmax_479',['hard_max',['../structMyPaintBrushInputInfo.html#a1d425bd53de5df5c0884cd280280d845',1,'MyPaintBrushInputInfo']]],
  ['hard_5fmin_480',['hard_min',['../structMyPaintBrushInputInfo.html#abef6dd3eb6ac42845c66e48536176bf0',1,'MyPaintBrushInputInfo']]],
  ['height_481',['height',['../structMyPaintRectangle.html#a2bf54bf765549db346ea326871231fdd',1,'MyPaintRectangle']]]
];
