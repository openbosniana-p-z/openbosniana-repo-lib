var searchData=
[
  ['readonly_317',['readonly',['../structMyPaintTileRequest.html#abcd0508e0d0ad82946557bf2bfe65111',1,'MyPaintTileRequest']]],
  ['rectangles_318',['rectangles',['../structMyPaintRectangles.html#aaaceb25587f5f62a39191a4551d4dc29',1,'MyPaintRectangles']]],
  ['refcount_319',['refcount',['../structMyPaintSurface.html#abda19244bf683971e727d26e9c36837c',1,'MyPaintSurface']]],
  ['rows_320',['rows',['../structMyPaintTransform.html#a487df9988eafaa0f4259dfd7b61a58d0',1,'MyPaintTransform']]]
];
