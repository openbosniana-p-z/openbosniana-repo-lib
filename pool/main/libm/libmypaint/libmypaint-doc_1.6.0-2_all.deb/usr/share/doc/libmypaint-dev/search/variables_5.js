var searchData=
[
  ['get_5fcolor_477',['get_color',['../structMyPaintSurface.html#a0c556cf1f828bca5cc11f6347fb6b420',1,'MyPaintSurface']]],
  ['get_5fcolor_5fpigment_478',['get_color_pigment',['../structMyPaintSurface2.html#aecf57b7f569b527beecc5e7878ff7c03',1,'MyPaintSurface2']]]
];
