var searchData=
[
  ['mypaint_5fmax_5fmipmap_5flevel_681',['MYPAINT_MAX_MIPMAP_LEVEL',['../mypaint-config_8h.html#a9403e175e1fd2ed2efd3821394f6548b',1,'mypaint-config.h']]],
  ['mypaint_5fmax_5fthreads_682',['MYPAINT_MAX_THREADS',['../mypaint-config_8h.html#a5b2af7214d2eddc29eca1c9b0f2e6839',1,'mypaint-config.h']]],
  ['mypaint_5ftile_5fsize_683',['MYPAINT_TILE_SIZE',['../mypaint-config_8h.html#af9e953d80d1a349130871a10aa980159',1,'mypaint-config.h']]]
];
