var searchData=
[
  ['g_5fbegin_5fdecls_679',['G_BEGIN_DECLS',['../mypaint-glib-compat_8h.html#a72c1126856454c07c2f9ab131aa7f2a3',1,'mypaint-glib-compat.h']]],
  ['g_5fend_5fdecls_680',['G_END_DECLS',['../mypaint-glib-compat_8h.html#a592df9359e90124ffc0d185505c9d567',1,'mypaint-glib-compat.h']]]
];
