var searchData=
[
  ['name_485',['name',['../structMyPaintBrushSettingInfo.html#ada8a14bf3ea37c11f943eecb95bf365c',1,'MyPaintBrushSettingInfo::name()'],['../structMyPaintBrushInputInfo.html#a03533ac63827daa3f997a43e474ed3a2',1,'MyPaintBrushInputInfo::name()']]],
  ['normal_486',['normal',['../structMyPaintBrushInputInfo.html#a644e1beb2003fe7befee641c8ec1e5b2',1,'MyPaintBrushInputInfo']]],
  ['num_5fbboxes_487',['num_bboxes',['../structMyPaintTiledSurface2.html#ac21225b7182f57f4a233911108715807',1,'MyPaintTiledSurface2']]],
  ['num_5fbboxes_5fdirtied_488',['num_bboxes_dirtied',['../structMyPaintTiledSurface2.html#a9e3165a3fc144e512c189bfc34f56216',1,'MyPaintTiledSurface2']]],
  ['num_5flines_489',['num_lines',['../structMyPaintSymmetryState.html#a4afa0af66ef6c23a2f299d3035fc523a',1,'MyPaintSymmetryState']]],
  ['num_5frectangles_490',['num_rectangles',['../structMyPaintRectangles.html#a2c1c9509f852f6345eafb8cfcc96d0d4',1,'MyPaintRectangles']]],
  ['num_5fsymmetry_5fmatrices_491',['num_symmetry_matrices',['../structMyPaintSymmetryData.html#a7bb7399dd102032b0aed5c9fb3d9a415',1,'MyPaintSymmetryData']]]
];
