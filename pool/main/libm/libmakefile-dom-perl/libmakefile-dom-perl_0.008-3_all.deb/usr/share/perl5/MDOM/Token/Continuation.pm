package MDOM::Token::Continuation;

use strict;
use base 'MDOM::Token';

sub significant { '' }

1;
