package MDOM::Document;

use strict;
use warnings;

sub new {
}

1;
