/** minc2 definitions*/
#ifndef MINC2_DEFS_H
#define MINC2_DEFS_H
#include <minc_common_defs.h>

#endif /*MINC2_DEFS_H*/

/* kate: indent-mode cstyle; indent-width 2; replace-tabs on; */
