require 'Mu::Tiny';

1;
