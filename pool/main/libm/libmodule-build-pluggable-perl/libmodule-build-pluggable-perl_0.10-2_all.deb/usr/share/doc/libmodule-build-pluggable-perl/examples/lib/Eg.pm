package Eg;
use strict;
use warnings;
use utf8;



1;
__END__

=head1 SYNOPSIS

    # Here is code

=head1 SEE ALSO

L<Acme::Hidek>
