package MooseX::Role::WithOverloading::Meta::Role::Application::ToClass;

our $VERSION = '0.17';

use Moose::Role;
use namespace::autoclean;

with 'MooseX::Role::WithOverloading::Meta::Role::Application';

1;
