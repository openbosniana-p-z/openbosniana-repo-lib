package #hide from CPAN
        My::Fuz;
use strict;
use warnings;
sub fuz {"My::Fuz::fuz"};
1;
