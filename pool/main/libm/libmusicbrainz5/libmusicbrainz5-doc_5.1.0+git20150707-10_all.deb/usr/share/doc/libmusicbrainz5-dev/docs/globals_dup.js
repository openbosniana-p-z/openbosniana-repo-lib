var globals_dup =
[
    [ "e", "globals.html", null ],
    [ "m", "globals_m.html", null ],
    [ "t", "globals_t.html", null ]
];