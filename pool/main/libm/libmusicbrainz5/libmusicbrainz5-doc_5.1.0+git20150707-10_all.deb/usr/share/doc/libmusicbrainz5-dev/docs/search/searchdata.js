var indexSectionsWithContent =
{
  0: "emt",
  1: "m",
  2: "m",
  3: "m",
  4: "t",
  5: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "enums",
  5: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Enumerations",
  5: "Enumerator"
};

