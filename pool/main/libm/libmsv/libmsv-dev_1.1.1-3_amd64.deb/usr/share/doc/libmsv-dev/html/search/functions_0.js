var searchData=
[
  ['msv_5fcheck_5fmsva',['msv_check_msva',['../msv_8h.html#a3196435704b1ab357bd26c215859ac15',1,'msv.h']]],
  ['msv_5fctxt_5fdestroy',['msv_ctxt_destroy',['../msv_8h.html#acd1b3908113ecd68ca58250acccad86e',1,'msv.h']]],
  ['msv_5fctxt_5finit',['msv_ctxt_init',['../msv_8h.html#a8b583db349c867833eed5a70544c7783',1,'msv.h']]],
  ['msv_5fdeprecated',['MSV_DEPRECATED',['../structmsv__response.html#af326952e47d6ec9bd2ac05baec09846c',1,'msv_response']]],
  ['msv_5fquery_5fagent',['msv_query_agent',['../msv_8h.html#ae8cabd74a59ad23a801ffc2d307d1b2b',1,'msv.h']]],
  ['msv_5fresponse_5fdestroy',['msv_response_destroy',['../msv_8h.html#ace1a44f4d79e29d89b54b778cb6580bc',1,'msv.h']]],
  ['msv_5fstrerror',['msv_strerror',['../msv_8h.html#a73920b0aa11fa82d039d232558a80b98',1,'msv.h']]]
];
