var searchData=
[
  ['libmsv_5ferror_5fbadarg',['LIBMSV_ERROR_BADARG',['../msv_8h.html#aeb59f414c08411f2b6b838a8b473fc9d',1,'msv.h']]],
  ['libmsv_5ferror_5fcurlcode',['LIBMSV_ERROR_CURLCODE',['../msv_8h.html#a13a31e303df899992fbf54cf44353ab1',1,'msv.h']]],
  ['libmsv_5ferror_5fcurlinit_5ffailed',['LIBMSV_ERROR_CURLINIT_FAILED',['../msv_8h.html#adcc3b78a7875eb0a9bd2e340ad774d48',1,'msv.h']]],
  ['libmsv_5ferror_5fincompatible_5fagent',['LIBMSV_ERROR_INCOMPATIBLE_AGENT',['../msv_8h.html#ac21e755c6c6a02fe19796a7f156be352',1,'msv.h']]],
  ['libmsv_5ferror_5finvalid',['LIBMSV_ERROR_INVALID',['../msv_8h.html#a94340b4fa162ee22a4a690127a7ab4ce',1,'msv.h']]],
  ['libmsv_5ferror_5fnoenvvar',['LIBMSV_ERROR_NOENVVAR',['../msv_8h.html#a5c50f4f2c312d59f6ccfcfd01f0d4ff7',1,'msv.h']]],
  ['libmsv_5ferror_5fnomem',['LIBMSV_ERROR_NOMEM',['../msv_8h.html#a186b7f7bbde2ff6204e5cc08d2d9da63',1,'msv.h']]],
  ['libmsv_5ferror_5fsuccess',['LIBMSV_ERROR_SUCCESS',['../msv_8h.html#a74a21438fd21459b53218a26ad3dcdbd',1,'msv.h']]],
  ['libmsv_5ferror_5funexpected_5fresponse',['LIBMSV_ERROR_UNEXPECTED_RESPONSE',['../msv_8h.html#ae494a7f34011e5371c6ed73ba4a4695a',1,'msv.h']]]
];
