var searchData=
[
  ['msv_5fquery',['msv_query',['../structmsv__query.html',1,'']]],
  ['msv_5fresponse',['msv_response',['../structmsv__response.html',1,'']]]
];
