package Monkey::Patch::Handle::Object;
BEGIN {
  $Monkey::Patch::Handle::Object::VERSION = '0.03';
}
use strict;
use warnings;

use base 'Monkey::Patch::Handle::Class';

sub should_call_code {
    my ($self, $invocant) = @_;
    no warnings 'numeric';
    return $self->{object} == $invocant;
}

1;

=head1 NAME

Monkey::Patch::Handle::Object - Handle for monkey-patching objects

=head1 DESCRIPTION

Monkey::Patch::Handle::Object provides the default Monkey::Patch::Handle
for monkey-patching a particular object.

You should never need to use this directly, so read L(Monkey::Patch)
instead.

=pod

=begin Pod::Coverage

.*

=end Pod::Coverage
