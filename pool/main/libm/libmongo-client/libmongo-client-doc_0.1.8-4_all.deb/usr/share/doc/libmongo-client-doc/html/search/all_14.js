var searchData=
[
  ['user',['user',['../structauth__credentials.html#ac0ef2391120c0d7593fe7559345ef97e',1,'auth_credentials']]]
];
