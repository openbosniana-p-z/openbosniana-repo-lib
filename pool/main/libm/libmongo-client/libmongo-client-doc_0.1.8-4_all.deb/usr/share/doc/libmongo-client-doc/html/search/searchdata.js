var indexSectionsWithContent =
{
  0: "_abcdfghijklmnopqrstuvw",
  1: "_amr",
  2: "bm",
  3: "abcdfghiklmnoprstuvw",
  4: "b",
  5: "bm",
  6: "abcmoprt",
  7: "abcijlqrtw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Enumerator",
  6: "Modules",
  7: "Pages"
};

