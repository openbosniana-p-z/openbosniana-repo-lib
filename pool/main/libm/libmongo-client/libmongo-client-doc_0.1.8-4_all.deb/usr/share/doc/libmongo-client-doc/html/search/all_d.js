var searchData=
[
  ['nmasters',['nmasters',['../struct__mongo__sync__pool.html#ac6d4ffc1ba3d37533f327dd610a06155',1,'_mongo_sync_pool']]],
  ['ns',['ns',['../struct__mongo__sync__cursor.html#a5e4c72fde99523826b8289345754aeb4',1,'_mongo_sync_cursor::ns()'],['../struct__mongo__sync__gridfs.html#a9335d945300b6a47e3ec80179f85f9f7',1,'_mongo_sync_gridfs::ns()']]],
  ['nslaves',['nslaves',['../struct__mongo__sync__pool.html#a74ee5b85bda14fdf6f17385351ec2546',1,'_mongo_sync_pool']]]
];
