var searchData=
[
  ['ph',['ph',['../struct__mongo__sync__cursor.html#abc532d1e55527d16d8779c445d488c99',1,'_mongo_sync_cursor']]],
  ['pool_5fid',['pool_id',['../struct__mongo__sync__pool__connection.html#a7dd9012a1d3f21aa4a9bfb9697c4a75b',1,'_mongo_sync_pool_connection']]],
  ['pos',['pos',['../struct__bson__cursor.html#a84551cea61126e4fbf8d05c537d745e6',1,'_bson_cursor']]],
  ['prefix',['prefix',['../struct__mongo__sync__gridfs.html#ac8dec9f9706065739758d121355e88da',1,'_mongo_sync_gridfs']]],
  ['primary',['primary',['../structreplica__set.html#a24f6268275edac8c9c1a63530cfdef83',1,'replica_set']]],
  ['pw',['pw',['../structauth__credentials.html#ab66b74a657981d1b8b1a74a74e897cb8',1,'auth_credentials']]]
];
