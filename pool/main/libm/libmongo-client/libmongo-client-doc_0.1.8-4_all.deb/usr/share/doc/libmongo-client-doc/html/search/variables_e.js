var searchData=
[
  ['reader',['reader',['../struct__mongo__sync__gridfs__stream.html#a928e4cb5769fe5a7faf711a162e50888',1,'_mongo_sync_gridfs_stream']]],
  ['recovery_5fcache',['recovery_cache',['../struct__mongo__sync__connection.html#a02b48783c9222d8b23f82939680f37e6',1,'_mongo_sync_connection']]],
  ['request_5fid',['request_id',['../struct__mongo__connection.html#aa49f60e3ed82e6fd43e4ad8c5c6dbe59',1,'_mongo_connection']]],
  ['resp_5fto',['resp_to',['../structmongo__packet__header.html#a4fcf69c47c3dd4e10d24dbea16a0a84b',1,'mongo_packet_header']]],
  ['results',['results',['../struct__mongo__sync__cursor.html#a81383f1adf6c39d289072031ec72887e',1,'_mongo_sync_cursor']]],
  ['returned',['returned',['../structmongo__reply__packet__header.html#a5a5129b4736cb99dd9894df44bc9b56b',1,'mongo_reply_packet_header']]],
  ['rs',['rs',['../struct__mongo__sync__conn__recovery__cache.html#ad2a670350040111d28bd8778f8f894f6',1,'_mongo_sync_conn_recovery_cache::rs()'],['../struct__mongo__sync__connection.html#a0ee3087c24cc92466dba4abc662997ba',1,'_mongo_sync_connection::rs()']]]
];
