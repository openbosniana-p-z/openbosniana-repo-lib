var searchData=
[
  ['libmongo_2dclient',['libmongo-client',['../index.html',1,'']]]
];
