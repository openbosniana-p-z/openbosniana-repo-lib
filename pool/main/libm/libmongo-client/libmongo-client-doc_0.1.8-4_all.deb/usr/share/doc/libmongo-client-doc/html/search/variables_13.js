var searchData=
[
  ['writer',['writer',['../struct__mongo__sync__gridfs__stream.html#a545bf0022b5464bc87c16bd85672f5b5',1,'_mongo_sync_gridfs_stream']]]
];
