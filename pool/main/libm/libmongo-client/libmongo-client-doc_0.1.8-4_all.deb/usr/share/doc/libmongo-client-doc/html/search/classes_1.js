var searchData=
[
  ['auth_5fcredentials',['auth_credentials',['../structauth__credentials.html',1,'']]]
];
