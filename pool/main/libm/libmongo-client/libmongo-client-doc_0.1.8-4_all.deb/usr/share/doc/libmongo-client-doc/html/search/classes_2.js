var searchData=
[
  ['mongo_5fpacket_5fheader',['mongo_packet_header',['../structmongo__packet__header.html',1,'']]],
  ['mongo_5freply_5fpacket_5fheader',['mongo_reply_packet_header',['../structmongo__reply__packet__header.html',1,'']]],
  ['mongo_5fsync_5fgridfs_5ffile_5fcommon',['mongo_sync_gridfs_file_common',['../structmongo__sync__gridfs__file__common.html',1,'']]]
];
