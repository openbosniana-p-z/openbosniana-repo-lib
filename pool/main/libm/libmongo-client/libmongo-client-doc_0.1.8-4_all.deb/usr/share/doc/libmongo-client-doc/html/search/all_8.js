var searchData=
[
  ['id',['id',['../structmongo__sync__gridfs__file__common.html#a9bb6776938af697044f0dff4c750ba4b',1,'mongo_sync_gridfs_file_common::id()'],['../structmongo__packet__header.html#aa5973932fffe09019c8792503b442435',1,'mongo_packet_header::id()']]],
  ['in_5fuse',['in_use',['../struct__mongo__sync__pool__connection.html#a9f9080977c7799dd79ed690886803812',1,'_mongo_sync_pool_connection']]],
  ['inserting_20documents_20into_20mongodb',['Inserting documents into MongoDB',['../tut_mongo_sync_insert.html',1,'tut_mongo_sync']]]
];
