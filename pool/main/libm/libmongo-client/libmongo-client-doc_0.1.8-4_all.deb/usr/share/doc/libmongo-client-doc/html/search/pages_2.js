var searchData=
[
  ['creating_20collections',['Creating collections',['../tut_mongo_sync_cmd_create.html',1,'tut_mongo_sync']]],
  ['creating_20indexes',['Creating indexes',['../tut_mongo_sync_cmd_index_create.html',1,'tut_mongo_sync']]],
  ['connecting_20to_20mongodb',['Connecting to MongoDB',['../tut_mongo_sync_connect.html',1,'tut_mongo_sync']]]
];
