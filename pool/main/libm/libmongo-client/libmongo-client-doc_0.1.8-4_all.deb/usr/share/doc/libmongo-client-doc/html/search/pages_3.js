var searchData=
[
  ['inserting_20documents_20into_20mongodb',['Inserting documents into MongoDB',['../tut_mongo_sync_insert.html',1,'tut_mongo_sync']]]
];
