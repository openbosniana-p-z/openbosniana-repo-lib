var searchData=
[
  ['gfs',['gfs',['../struct__mongo__sync__gridfs__chunked__file.html#ae278321b4a96b1a29386fc00bca279a4',1,'_mongo_sync_gridfs_chunked_file::gfs()'],['../struct__mongo__sync__gridfs__stream.html#a542e774dfbbb20f4535b255a4db85b3a',1,'_mongo_sync_gridfs_stream::gfs()']]]
];
