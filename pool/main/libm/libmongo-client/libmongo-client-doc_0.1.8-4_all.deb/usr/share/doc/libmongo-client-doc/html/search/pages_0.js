var searchData=
[
  ['a_20full_2dblown_20application',['A full-blown application',['../tut_hl_client.html',1,'tutorial']]]
];
