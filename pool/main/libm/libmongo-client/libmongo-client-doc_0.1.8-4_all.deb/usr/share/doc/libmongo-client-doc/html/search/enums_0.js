var searchData=
[
  ['bson_5fbinary_5fsubtype',['bson_binary_subtype',['../group__bson__types.html#gab69c9ec1c9cdabbb2db338e58a6e55fe',1,'bson.h']]],
  ['bson_5ftype',['bson_type',['../group__bson__types.html#gadac27a93ef69dbe56a6409c68395e5cb',1,'bson.h']]]
];
