var searchData=
[
  ['querying_20documents',['Querying documents',['../tut_mongo_sync_query.html',1,'tut_mongo_sync']]],
  ['querying_20documents_2c_20part_20two',['Querying documents, part two',['../tut_mongo_sync_query_complex.html',1,'tut_mongo_sync']]]
];
