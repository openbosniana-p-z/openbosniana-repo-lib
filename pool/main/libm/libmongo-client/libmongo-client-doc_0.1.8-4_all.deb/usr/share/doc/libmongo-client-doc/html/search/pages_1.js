var searchData=
[
  ['building_20bson_20objects',['Building BSON objects',['../tut_bson_build.html',1,'tut_bson']]]
];
