var searchData=
[
  ['type',['type',['../structmongo__sync__gridfs__file__common.html#a9dffcc25e0d4dfbee56b985bee35bdde',1,'mongo_sync_gridfs_file_common']]]
];
