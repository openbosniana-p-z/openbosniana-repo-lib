# HOW TO REQUEST CHANGES, FIXES, OR NEW FEATURES

The CPAN author does not lack for sites that offer ways to support
their modules. If you have found a bug or need an improvement, please
make the request at one of these two sites:

RT, CPAN's request tracker, is the oldest and most established. It
is probably best for reporting true bugs.

[RT for Math-Utils](http://rt.cpan.org/NoAuth/Bugs.html?Dist=Math-Utils)

This module is developed with github, and issues may be presented and
discussed there.

[Github link for Math-Utils](https://github.com/jgamble/Math-Utils)


