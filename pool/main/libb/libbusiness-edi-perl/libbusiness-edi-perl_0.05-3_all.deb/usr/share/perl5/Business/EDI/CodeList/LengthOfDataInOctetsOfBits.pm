package Business::EDI::CodeList::LengthOfDataInOctetsOfBits;

use base 'Business::EDI::CodeList';
my $VERSION     = 0.02;
sub list_number {return "0556";}
my $usage       = 'B';  # guessed value

# 0556 Length of data in octets of bits                                    []
# Desc: 
# Repr: 
my %code_hash = (

);
sub get_codes { return \%code_hash; }

1;
