package Business::EDI::CodeList::MessageImplementationGuidelineIdentification;

use base 'Business::EDI::CodeList';
my $VERSION     = 0.02;
sub list_number {return "0121";}
my $usage       = 'B';  # guessed value

# 0121 Message implementation guideline identification                                    []
# Desc: 
# Repr: 
my %code_hash = (

);
sub get_codes { return \%code_hash; }

1;
