# CONTRIBUTING

Send patches or pull requests to the maintainer.

Current maintainer is Ivan Kohler <ivan-business-creditcard@420.am>.


# HOMEPAGE

 [http://perl.business/creditcard](http://perl.business/creditcard)


# REPOSITORY

The code is available from our public git repository:

  git clone git://git.freeside.biz/Business-CreditCard.git

Or on the web:

  http://freeside.biz/gitweb/?p=Business-CreditCard.git
  Or:
  http://freeside.biz/gitlist/Business-CreditCard.git

