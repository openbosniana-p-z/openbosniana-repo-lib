Bio-Coordinate
===============

The Bio-Coordinate distribution.

This distribution is part of the [BioPerl](http://www.bioperl.org/) project.
