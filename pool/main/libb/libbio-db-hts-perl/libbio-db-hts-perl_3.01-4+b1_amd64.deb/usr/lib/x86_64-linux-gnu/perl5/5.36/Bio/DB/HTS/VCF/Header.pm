package Bio::DB::HTS::VCF::Header;

use Bio::DB::HTS; #load the XS

$Bio::DB::HTS::VCF::Header::VERSION = '3.01';

1;
