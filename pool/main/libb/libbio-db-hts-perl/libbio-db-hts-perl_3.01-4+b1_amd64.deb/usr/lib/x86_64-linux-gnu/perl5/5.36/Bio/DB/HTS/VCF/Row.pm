package Bio::DB::HTS::VCF::Row;

$Bio::DB::HTS::VCF::Row::VERSION = '3.01';

use Bio::DB::HTS;

1;
