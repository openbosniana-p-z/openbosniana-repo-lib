package Bio::MAGE::XMLUtils;

use strict;
use Bio::MAGE::XML::Reader;
use Bio::MAGE::XML::Writer;
use Bio::MAGE::XML::Handler;
use Bio::MAGE::XML::Handler::DocumentHandler;
use Bio::MAGE::XML::Handler::ContentHandler;

1;
