var searchData=
[
  ['eof_0',['eof',['../structbd__file__s.html#ae8454f86ea698f63818a0f56718b9620',1,'bd_file_s']]],
  ['event_1',['event',['../structBD__EVENT.html#a833af3d09419c6df353be1911c0ce245',1,'BD_EVENT']]]
];
