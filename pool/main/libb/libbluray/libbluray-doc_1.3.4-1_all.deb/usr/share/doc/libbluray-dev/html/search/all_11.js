var searchData=
[
  ['udf_5fvolume_5fid_0',['udf_volume_id',['../structBLURAY__DISC__INFO.html#a6b1e989050ec3e35c19a85438a4f0f81',1,'BLURAY_DISC_INFO']]],
  ['unlock_1',['unlock',['../structBD__ARGB__BUFFER.html#a0146af2e6a3183f8bd1d7c833848c699',1,'BD_ARGB_BUFFER']]]
];
