var searchData=
[
  ['cb_0',['Cb',['../structBD__PG__PALETTE__ENTRY.html#a6f0446f21ff8bbe16f6a989659366885',1,'BD_PG_PALETTE_ENTRY']]],
  ['chapter_5fcount_1',['chapter_count',['../structBLURAY__TITLE__INFO.html#a462d44c27fade8a054a2733edb22be48',1,'BLURAY_TITLE_INFO']]],
  ['chapters_2',['chapters',['../structBLURAY__TITLE__INFO.html#a9bfedac5933aceec07f6fd43698ddfcc',1,'BLURAY_TITLE_INFO']]],
  ['char_5fcode_3',['char_code',['../structBLURAY__STREAM__INFO.html#ac46d7c26ffd082d9a124bff75ca9e0fe',1,'BLURAY_STREAM_INFO']]],
  ['clip_5fcount_4',['clip_count',['../structBLURAY__TITLE__INFO.html#aba4c3d1791ae81b1cd94db2d646dbade',1,'BLURAY_TITLE_INFO']]],
  ['clip_5fid_5',['clip_id',['../structBLURAY__CLIP__INFO.html#a7cb76767e1ce9ef2fd78a60cecb66b0c',1,'BLURAY_CLIP_INFO']]],
  ['clip_5fref_6',['clip_ref',['../structBLURAY__TITLE__CHAPTER.html#a28a85a6791fc43f1123b80f3b7e1eaf7',1,'BLURAY_TITLE_CHAPTER::clip_ref()'],['../structBLURAY__TITLE__MARK.html#a5aa43efb2f091da36178354129137ebe',1,'BLURAY_TITLE_MARK::clip_ref()']]],
  ['clips_7',['clips',['../structBLURAY__TITLE__INFO.html#a3a73c07161f563fdf24362f2380d4f82',1,'BLURAY_TITLE_INFO']]],
  ['close_8',['close',['../structbd__file__s.html#a36aa00e4f64d327510c9897a857ed01b',1,'bd_file_s::close()'],['../structbd__dir__s.html#a1751c97f3d2026d363b80d4ee3d99b01',1,'bd_dir_s::close()']]],
  ['cmd_9',['cmd',['../structBD__OVERLAY.html#a090bc00faf3cc3e138b0a568d6562a76',1,'BD_OVERLAY::cmd()'],['../structBD__ARGB__OVERLAY.html#a4a2a30fc11e67cb5ba9813e3fc416279',1,'BD_ARGB_OVERLAY::cmd()']]],
  ['coding_5ftype_10',['coding_type',['../structBLURAY__STREAM__INFO.html#aed6fcc5b5004cbb729541496aa7ed68d',1,'BLURAY_STREAM_INFO']]],
  ['color_11',['color',['../structBD__PG__RLE__ELEM.html#aa6e9b642dae2dcf808a14f2097cbeb0e',1,'BD_PG_RLE_ELEM']]],
  ['content_5fexist_5f3d_12',['content_exist_3D',['../structBLURAY__DISC__INFO.html#a2982a18ef94746131523a3e818fd7171',1,'BLURAY_DISC_INFO']]],
  ['cr_13',['Cr',['../structBD__PG__PALETTE__ENTRY.html#ae295bf7b83ba9861d54649a2f4b08ad6',1,'BD_PG_PALETTE_ENTRY']]]
];
