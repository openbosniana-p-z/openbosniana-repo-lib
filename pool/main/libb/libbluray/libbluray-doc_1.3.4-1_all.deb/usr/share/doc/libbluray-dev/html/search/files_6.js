var searchData=
[
  ['player_5fsettings_2eh_0',['player_settings.h',['../player__settings_8h.html',1,'']]]
];
