var searchData=
[
  ['x_0',['x',['../structBD__OVERLAY.html#a0f6a84bc760706a0c0a49cbfae276e8d',1,'BD_OVERLAY::x()'],['../structBD__ARGB__OVERLAY.html#a94ab0b8baa2fe34fd017b9186f8e3f5c',1,'BD_ARGB_OVERLAY::x()']]],
  ['x0_1',['x0',['../structBD__ARGB__BUFFER.html#a708b588a21318203a41629f2f3e4e909',1,'BD_ARGB_BUFFER']]],
  ['x1_2',['x1',['../structBD__ARGB__BUFFER.html#ac0de146b385771b3218145b6e841287e',1,'BD_ARGB_BUFFER']]],
  ['xres_3',['xres',['../structMETA__THUMBNAIL.html#ae103bfaa71bb9f5c5d57f8e4340589b5',1,'META_THUMBNAIL']]]
];
