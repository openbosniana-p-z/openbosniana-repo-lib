var searchData=
[
  ['libbigwig_5fcurl_0',['LIBBIGWIG_CURL',['../bigWig_8h.html#ac2496b5d01c469f90f790b933f31d0d4',1,'bigWig.h']]],
  ['libbigwig_5fversion_1',['LIBBIGWIG_VERSION',['../bigWig_8h.html#afe870db159b3eed39c32be30ccc73c4e',1,'bigWig.h']]]
];
