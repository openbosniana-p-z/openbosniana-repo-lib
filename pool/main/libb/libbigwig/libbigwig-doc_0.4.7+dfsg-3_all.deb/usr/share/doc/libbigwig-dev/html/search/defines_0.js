var searchData=
[
  ['bigbed_5fmagic_0',['BIGBED_MAGIC',['../bigWig_8h.html#a17aeac12ade93f0b26a203be7beacc68',1,'bigWig.h']]],
  ['bigwig_5fmagic_1',['BIGWIG_MAGIC',['../bigWig_8h.html#abc55570005e3349503ee7f6d5267eb8a',1,'bigWig.h']]]
];
