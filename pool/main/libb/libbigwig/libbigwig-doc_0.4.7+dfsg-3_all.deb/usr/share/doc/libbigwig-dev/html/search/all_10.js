var searchData=
[
  ['tid_0',['tid',['../structbwWriteBuffer__t.html#a1e80409d671ddba8f507c5b7a388d27c',1,'bwWriteBuffer_t::tid()'],['../structbwOverlapIterator__t.html#aaa10d193fe93d568d8caeabf33f96521',1,'bwOverlapIterator_t::tid()'],['../structbwDataHeader__t.html#a44b09f0b98af0b93ec4348357ad51d98',1,'bwDataHeader_t::tid()']]],
  ['type_1',['type',['../structbigWigFile__t.html#a8b025cec8945b0ad1aef06113f17c463',1,'bigWigFile_t::type()'],['../structURL__t.html#a431adb9c33b3d8d43575799f6fdcd497',1,'URL_t::type()'],['../structbwDataHeader__t.html#a77294dce47a8154444baf1a1a1321af4',1,'bwDataHeader_t::type()']]]
];
