var searchData=
[
  ['average_0',['average',['../bigWig_8h.html#aa3e01d7486887aa111417b688bc1a22cae478d4d7f90177e87ed05369ad732b25',1,'bigWig.h']]]
];
