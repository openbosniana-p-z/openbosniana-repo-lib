var searchData=
[
  ['x_0',['x',['../structURL__t.html#ad6d70a2a93d3ad17331f3042eead1ce2',1,'URL_t::x()'],['../structbwRTreeNode__t.html#af9caccee1915cb22f50b0b794847317d',1,'bwRTreeNode_t::x()']]]
];
