var searchData=
[
  ['p_0',['p',['../structbwWriteBuffer__t.html#adbd1ed0f439084b2b6839ddc5609e793',1,'bwWriteBuffer_t']]]
];
