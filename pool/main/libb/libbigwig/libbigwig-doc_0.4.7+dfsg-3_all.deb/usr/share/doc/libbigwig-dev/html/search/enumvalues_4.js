var searchData=
[
  ['stdev_0',['stdev',['../bigWig_8h.html#aa3e01d7486887aa111417b688bc1a22cac7a4dba588d32e11eaa063e51c491387',1,'bigWig.h']]],
  ['sum_1',['sum',['../bigWig_8h.html#aa3e01d7486887aa111417b688bc1a22ca3693895373771b9806a9775d16d1198b',1,'bigWig.h']]]
];
