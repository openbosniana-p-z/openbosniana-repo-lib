var searchData=
[
  ['url_5ft_0',['URL_t',['../structURL__t.html',1,'']]]
];
