var structeconf__ext__value =
[
    [ "values", "structeconf__ext__value.html#a61e00ab2ad253bdce9202cc0178f5ac3", null ],
    [ "file", "structeconf__ext__value.html#ab84b8530958297f5bd1aee90b6e273af", null ],
    [ "line_number", "structeconf__ext__value.html#a7f9249f4979304c06b7a2b325addc389", null ],
    [ "comment_before_key", "structeconf__ext__value.html#a14fd4db69e6bdaf55c45b6b8f9db40dd", null ],
    [ "comment_after_value", "structeconf__ext__value.html#ae227ad2b89446c7407a384d07d04a012", null ]
];