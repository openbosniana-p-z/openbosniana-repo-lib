var structevhtp__request =
[
    [ "TAILQ_ENTRY", "structevhtp__request.html#a43747d10dbbde0c6d3c58bcf70907fd8", null ],
    [ "buffer_in", "structevhtp__request.html#a0e0db904e83ae328035a1aaa2d3bbe93", null ],
    [ "buffer_out", "structevhtp__request.html#a4cc8dff17e7a18b734c583e8eff00b6e", null ],
    [ "cb", "structevhtp__request.html#a2d865c6d1c25fb85990d301ccf00c8e8", null ],
    [ "cbarg", "structevhtp__request.html#a24df857a0bb615b35a464d0c6f9730d3", null ],
    [ "conn", "structevhtp__request.html#ab9d4c5543abd6ebf45a847373af34faf", null ],
    [ "flags", "structevhtp__request.html#ab63e9e81384fff108fb3aff294272fb1", null ],
    [ "headers_in", "structevhtp__request.html#a86570838240dc43d69d6b5e4f4068cd5", null ],
    [ "headers_out", "structevhtp__request.html#a5f7a6178770243d493099531dcca8a6d", null ],
    [ "hooks", "structevhtp__request.html#aae74c640e63b2e4de2b6a60f4afb6364", null ],
    [ "htp", "structevhtp__request.html#a9fedce3ebe990b1d5199cc817e01277f", null ],
    [ "method", "structevhtp__request.html#a3fac674014b5f054f667a6b8052332fd", null ],
    [ "proto", "structevhtp__request.html#ac1dfaa667d08c27b23fa3e78606593d8", null ],
    [ "status", "structevhtp__request.html#ab643f31279e9692ceafcf8620bc675c2", null ],
    [ "uri", "structevhtp__request.html#a3a477735dd83b621e786462680ebced4", null ]
];