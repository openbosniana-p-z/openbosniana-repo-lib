var structrefcount__ =
[
    [ "count", "structrefcount__.html#a67bcd65edfa1a3357760bb1cbb243f9a", null ],
    [ "data", "structrefcount__.html#af4d5c995520bd67e1000da5df168f32d", null ],
    [ "mux", "structrefcount__.html#a27bfe8daaeac5cf99a9e43b7bd8012ce", null ]
];