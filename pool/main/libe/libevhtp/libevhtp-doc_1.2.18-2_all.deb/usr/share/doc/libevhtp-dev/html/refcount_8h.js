var refcount_8h =
[
    [ "refcount_", "structrefcount__.html", "structrefcount__" ],
    [ "ref_barrier", "refcount_8h.html#aa2e888f5a81f9ca4f8b48e13831b47a1", null ],
    [ "ref_upcast", "refcount_8h.html#a2beadca9895cef8c4b6452dce75e3516", null ],
    [ "ref_dec", "refcount_8h.html#aed8979af1f3a1531b92240b3673708f3", null ],
    [ "ref_free", "refcount_8h.html#adcff5d95570aaec4d92c7aceb595a051", null ],
    [ "ref_inc", "refcount_8h.html#ad09b2177a52311d7eb1be59bd1e414a2", null ],
    [ "ref_init_functions", "refcount_8h.html#a29550c56199c71aedf2a2aa0a27f48de", null ],
    [ "ref_malloc", "refcount_8h.html#a51acfd98c61b655e0213785dde0cae50", null ],
    [ "REF_free", "refcount_8h.html#a0f38bc2e46b1e66ffec9c0f086f48fcf", null ],
    [ "REF_malloc", "refcount_8h.html#ab5a9e3657d886742de260e751e6faf98", null ],
    [ "REF_realloc", "refcount_8h.html#a529b0ee420620e04878f430e81c03972", null ]
];