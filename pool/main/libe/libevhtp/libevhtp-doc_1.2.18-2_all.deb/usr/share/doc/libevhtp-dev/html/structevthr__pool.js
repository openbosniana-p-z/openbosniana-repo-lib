var structevthr__pool =
[
    [ "nthreads", "structevthr__pool.html#a4772ba5370fc6fcb1aa686babc3bae91", null ],
    [ "threads", "structevthr__pool.html#af806d987babcd52532cfbaeabbc864b4", null ]
];