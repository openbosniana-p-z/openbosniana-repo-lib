var structevhtp__defaults =
[
    [ "cb", "structevhtp__defaults.html#a2a1ab1295f87ba2114b64cb1ff12097f", null ],
    [ "cbarg", "structevhtp__defaults.html#a497cdf50fab0e9191571db4af7da6065", null ],
    [ "post_accept", "structevhtp__defaults.html#ae8002080d1b2bb25329e8876546de04b", null ],
    [ "post_accept_cbarg", "structevhtp__defaults.html#a234ef97b2d613e6a0b14c52f45460a0e", null ],
    [ "pre_accept", "structevhtp__defaults.html#aee1c7b7e03e0b6a25c14cfe285e4f53d", null ],
    [ "pre_accept_cbarg", "structevhtp__defaults.html#afe3d7900b4e3a79ba1bf277eb73fa896", null ]
];