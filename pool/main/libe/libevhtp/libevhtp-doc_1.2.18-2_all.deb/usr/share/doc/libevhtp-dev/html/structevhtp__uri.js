var structevhtp__uri =
[
    [ "authority", "structevhtp__uri.html#acd1d11e0b273a95265567646a554618d", null ],
    [ "fragment", "structevhtp__uri.html#a5522cde1203010822c1d13bc3639f420", null ],
    [ "path", "structevhtp__uri.html#a735d57ee399cf11a94e571641d2274a2", null ],
    [ "query", "structevhtp__uri.html#ae63c4983c3bba82de76cea4d27f91c7a", null ],
    [ "query_raw", "structevhtp__uri.html#a8bead2e720eddb5ad528e84fe94c91a6", null ],
    [ "scheme", "structevhtp__uri.html#ac5fc9a076dd89459117d63938a26b725", null ]
];