var structevhtp__authority =
[
    [ "hostname", "structevhtp__authority.html#a5af6808164e66a6fe41fdd46b3b6b712", null ],
    [ "password", "structevhtp__authority.html#a11de57b3015b2c1c199693f35a93c98a", null ],
    [ "port", "structevhtp__authority.html#a37c0f7925f1771a0565d45fc25811dbb", null ],
    [ "username", "structevhtp__authority.html#aa4d4493f1ae62247956fd43ccf5b44b8", null ]
];