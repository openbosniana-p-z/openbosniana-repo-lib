var structevhtp__connection =
[
    [ "bev", "structevhtp__connection.html#ad66e0d3079620c8ac3b93a0664e09250", null ],
    [ "body_bytes_read", "structevhtp__connection.html#a93520db6d3a57b8a0f657d097124a351", null ],
    [ "evbase", "structevhtp__connection.html#ae2eb4a7800840e342512a02fa24bbda4", null ],
    [ "flags", "structevhtp__connection.html#a7c490d49a0190a9f843a744877854072", null ],
    [ "hooks", "structevhtp__connection.html#ab10532202f2187b34f4269d2a8c6f6b1", null ],
    [ "htp", "structevhtp__connection.html#a47578d6ea62ae6ba7273c46059d6f95c", null ],
    [ "max_body_size", "structevhtp__connection.html#a177558318b9146a701b0e394be600fc1", null ],
    [ "num_requests", "structevhtp__connection.html#a00feab299d26b62ae0c9a5af3a922459", null ],
    [ "parser", "structevhtp__connection.html#a74682b764ee9a0a29efaad5c2f7da13e", null ],
    [ "recv_timeo", "structevhtp__connection.html#a56df6edd782fa02880fbdca4f678a85b", null ],
    [ "request", "structevhtp__connection.html#a64637a41126c20514bbf0c64ff35d635", null ],
    [ "resume_ev", "structevhtp__connection.html#a48a9c51a57f340b305d37153e22b2fe0", null ],
    [ "saddr", "structevhtp__connection.html#a256de6340adb59658d2e6223ffbd494e", null ],
    [ "scratch_buf", "structevhtp__connection.html#ae9f958daf5b1bcf5584ee96faac9b934", null ],
    [ "send_timeo", "structevhtp__connection.html#a3200217e3d7e143e4caa1e474e288a8c", null ],
    [ "sock", "structevhtp__connection.html#a6e5e20ff7cdad18c10a673bd47f91a90", null ],
    [ "ssl", "structevhtp__connection.html#a50c8ae21f72433a14bc5f766ffcf5821", null ],
    [ "thread", "structevhtp__connection.html#a14147dc86234654dcdf1e45af997580b", null ],
    [ "type", "structevhtp__connection.html#a6070d90f249777eb0311ee45f295d98f", null ]
];