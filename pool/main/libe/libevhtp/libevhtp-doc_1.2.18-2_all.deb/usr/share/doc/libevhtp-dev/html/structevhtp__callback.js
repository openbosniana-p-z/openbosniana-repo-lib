var structevhtp__callback =
[
    [ "cb", "structevhtp__callback.html#ac5a82f74836157fad7d83ce6b21d80c5", null ],
    [ "cbarg", "structevhtp__callback.html#a401b26c08e1d3fbaea41ae7326abbad5", null ],
    [ "glob", "structevhtp__callback.html#ac3da924ef499ff1578f6b897d4ccd1e6", null ],
    [ "hooks", "structevhtp__callback.html#aab8e600677e79ea44ce359738e72ebc5", null ],
    [ "len", "structevhtp__callback.html#a3caa26567f34bdd4ef2f6a366c4d75d9", null ],
    [ "path", "structevhtp__callback.html#a1cebb2e00debfcbc73e0bac9621af211", null ],
    [ "regex", "structevhtp__callback.html#aa7685aea3282b104cb5515773f1bc134", null ],
    [ "type", "structevhtp__callback.html#a657e12dde0726fdbb28c3fe71a63eeba", null ],
    [ "val", "structevhtp__callback.html#a9821abb2a9f0940a13ed1b3b826faf16", null ]
];