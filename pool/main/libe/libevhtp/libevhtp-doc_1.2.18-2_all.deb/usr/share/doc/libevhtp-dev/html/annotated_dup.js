var annotated_dup =
[
    [ "evhtp_alias_t", "structevhtp__alias.html", "structevhtp__alias" ],
    [ "evhtp_authority_t", "structevhtp__authority.html", "structevhtp__authority" ],
    [ "evhtp_callback_t", "structevhtp__callback.html", "structevhtp__callback" ],
    [ "evhtp_connection_t", "structevhtp__connection.html", "structevhtp__connection" ],
    [ "evhtp_defaults_t", "structevhtp__defaults.html", "structevhtp__defaults" ],
    [ "evhtp_header_t", "structevhtp__kv.html", "structevhtp__kv" ],
    [ "evhtp_hooks_t", "structevhtp__hooks.html", "structevhtp__hooks" ],
    [ "evhtp_path_t", "structevhtp__path.html", "structevhtp__path" ],
    [ "evhtp_request_t", "structevhtp__request.html", "structevhtp__request" ],
    [ "evhtp_ssl_cfg_t", "structevhtp__ssl__cfg.html", "structevhtp__ssl__cfg" ],
    [ "evhtp_t", "structevhtp.html", "structevhtp" ],
    [ "evhtp_uri_t", "structevhtp__uri.html", "structevhtp__uri" ],
    [ "evthr", "structevthr.html", "structevthr" ],
    [ "evthr_cmd_t", "structevthr__cmd.html", "structevthr__cmd" ],
    [ "evthr_pool", "structevthr__pool.html", "structevthr__pool" ],
    [ "htparser", "structhtparser.html", "structhtparser" ],
    [ "refcount_", "structrefcount__.html", "structrefcount__" ]
];