var exif_gps_ifd_8h =
[
    [ "ExifGPSIfdTagInfo", "structExifGPSIfdTagInfo.html", "structExifGPSIfdTagInfo" ],
    [ "ExifGPSIfdTagInfo", "exif-gps-ifd_8h.html#ac2a758dfd15d01e67f076b3205f984a3", null ],
    [ "exif_get_gps_tag_info", "exif-gps-ifd_8h.html#a8942365f6de498cca0e81fce8cdf6e83", null ]
];