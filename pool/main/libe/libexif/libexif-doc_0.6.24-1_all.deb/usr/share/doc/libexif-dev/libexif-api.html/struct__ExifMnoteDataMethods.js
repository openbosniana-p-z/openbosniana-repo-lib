var struct__ExifMnoteDataMethods =
[
    [ "count", "struct__ExifMnoteDataMethods.html#a8739a9b6e64330cbc490d4605250cc6f", null ],
    [ "free", "struct__ExifMnoteDataMethods.html#ab4b3b981839b0c388aaa45b87d0f6487", null ],
    [ "get_description", "struct__ExifMnoteDataMethods.html#a07ff7bba6d8e52b079796ebeab7a87d2", null ],
    [ "get_id", "struct__ExifMnoteDataMethods.html#a803c811ab48b1469d9a6840421afbfde", null ],
    [ "get_name", "struct__ExifMnoteDataMethods.html#a3a0a6c1ff1335d637d875ee94e7b71e9", null ],
    [ "get_title", "struct__ExifMnoteDataMethods.html#a43ff41620091bf14f3bddc72840ecb46", null ],
    [ "get_value", "struct__ExifMnoteDataMethods.html#a5d3082b6db316a9dc864a82100fb17be", null ],
    [ "load", "struct__ExifMnoteDataMethods.html#a38e0f7c33f5d187fb7e9a87a6cf45dc3", null ],
    [ "save", "struct__ExifMnoteDataMethods.html#a8260d4fd1ee82a4f3f2ffaa6b7085e23", null ],
    [ "set_byte_order", "struct__ExifMnoteDataMethods.html#aa75536ba2316414de7cda31dae2935b1", null ],
    [ "set_offset", "struct__ExifMnoteDataMethods.html#a87674a3f4b100ee546aa131f786d2a47", null ]
];