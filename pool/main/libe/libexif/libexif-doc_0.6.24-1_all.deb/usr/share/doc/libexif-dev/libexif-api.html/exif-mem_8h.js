var exif_mem_8h =
[
    [ "ExifMem", "exif-mem_8h.html#aab8aacbc0ed6f11a1f022b7b1bf4750e", null ],
    [ "ExifMemAllocFunc", "exif-mem_8h.html#aeeb126cc625d1536938e9df564aa1b9a", null ],
    [ "ExifMemFreeFunc", "exif-mem_8h.html#a82bf96c57cc83eabdba1ad1ad0d69263", null ],
    [ "ExifMemReallocFunc", "exif-mem_8h.html#a4e7ef2c7d9c277d400ded020b1932e97", null ],
    [ "exif_mem_alloc", "exif-mem_8h.html#a00442916c2b7a2c0b43fad64f338a000", null ],
    [ "exif_mem_free", "exif-mem_8h.html#ab7ec7776593c6ffe5f49fec974f7cfe1", null ],
    [ "exif_mem_new", "exif-mem_8h.html#aace6f5e726c2225ae6d57a299e9e384f", null ],
    [ "exif_mem_new_default", "exif-mem_8h.html#acd2926c29b470c9d43f84567a84d5acb", null ],
    [ "exif_mem_realloc", "exif-mem_8h.html#a029f8f0346f778ac9caa56536fcf3c85", null ],
    [ "exif_mem_ref", "exif-mem_8h.html#acedafabd958c9846ea3f908135715dcf", null ],
    [ "exif_mem_unref", "exif-mem_8h.html#adabd1345e1172ce379658cecfd3f7d70", null ]
];