var structExifGPSIfdTagInfo =
[
    [ "components", "structExifGPSIfdTagInfo.html#a10fb5d3f12337dbf550e808a9dcb067c", null ],
    [ "default_size", "structExifGPSIfdTagInfo.html#ad55c211f1b421f410d20ecf4b3cf891e", null ],
    [ "default_value", "structExifGPSIfdTagInfo.html#ac9c586d76dab3fbe766530bf07949ad9", null ],
    [ "format", "structExifGPSIfdTagInfo.html#a2847f59aef0c694e78586fc710d6189b", null ],
    [ "tag", "structExifGPSIfdTagInfo.html#a75a56394453fd90fdb6e1f7fccc82818", null ]
];