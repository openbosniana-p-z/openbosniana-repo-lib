var struct__ExifContent =
[
    [ "count", "struct__ExifContent.html#a83e0ab89fd53da23fec28563450b7c02", null ],
    [ "entries", "struct__ExifContent.html#abfcd8677a7e44b7eaf5ce9c65e7a0ed0", null ],
    [ "parent", "struct__ExifContent.html#aae965558ea5c98783c4c2418364aabea", null ],
    [ "priv", "struct__ExifContent.html#a9a2a4c21095d7954b5f45600306be24b", null ]
];