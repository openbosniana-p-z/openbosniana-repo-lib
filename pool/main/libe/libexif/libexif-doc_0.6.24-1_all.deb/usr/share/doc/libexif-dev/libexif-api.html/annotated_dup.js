var annotated_dup =
[
    [ "_ExifContent", "struct__ExifContent.html", "struct__ExifContent" ],
    [ "_ExifData", "struct__ExifData.html", "struct__ExifData" ],
    [ "_ExifEntry", "struct__ExifEntry.html", "struct__ExifEntry" ],
    [ "_ExifMnoteData", "struct__ExifMnoteData.html", "struct__ExifMnoteData" ],
    [ "_ExifMnoteDataMethods", "struct__ExifMnoteDataMethods.html", "struct__ExifMnoteDataMethods" ],
    [ "ExifGPSIfdTagInfo", "structExifGPSIfdTagInfo.html", "structExifGPSIfdTagInfo" ],
    [ "ExifRational", "structExifRational.html", "structExifRational" ],
    [ "ExifSRational", "structExifSRational.html", "structExifSRational" ]
];