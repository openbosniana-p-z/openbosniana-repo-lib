var exif_gps_ifd_8c =
[
    [ "exif_get_gps_tag_info", "exif-gps-ifd_8c.html#a8942365f6de498cca0e81fce8cdf6e83", null ]
];