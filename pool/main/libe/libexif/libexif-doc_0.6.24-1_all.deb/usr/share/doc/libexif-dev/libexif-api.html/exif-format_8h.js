var exif_format_8h =
[
    [ "ExifFormat", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2", [
      [ "EXIF_FORMAT_BYTE", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2afdf39e6e5864897d50e52419fbe48356", null ],
      [ "EXIF_FORMAT_ASCII", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2a8cee3caa738d8bb85311678f0cb0e868", null ],
      [ "EXIF_FORMAT_SHORT", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2a5f22efb2ec9e3bd9e29faa87cd7b64e5", null ],
      [ "EXIF_FORMAT_LONG", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2a5611dcd2fcdcaf91f25412bece8485b6", null ],
      [ "EXIF_FORMAT_RATIONAL", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2a2712817194f241cb15f19e5a77d2bf42", null ],
      [ "EXIF_FORMAT_SBYTE", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2a9512e4980782a9f3638e83bc47dfe58c", null ],
      [ "EXIF_FORMAT_UNDEFINED", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2a5ce63b2dc5a1db046bcd130bb0eff2bc", null ],
      [ "EXIF_FORMAT_SSHORT", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2a85dbf2985c5d03f406746f0b0cf1cbbe", null ],
      [ "EXIF_FORMAT_SLONG", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2a1e5c296e5c3a2e39eeb87d0a26597f87", null ],
      [ "EXIF_FORMAT_SRATIONAL", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2a3c60fa6310f13ba77c677708ab41c29c", null ],
      [ "EXIF_FORMAT_FLOAT", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2ab8b22c7e2195872fa934308cf7b2f688", null ],
      [ "EXIF_FORMAT_DOUBLE", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2af89818d5f7b2f06f25baff4657565054", null ]
    ] ],
    [ "exif_format_get_name", "exif-format_8h.html#a59375a5939c716b826311c22571680f3", null ],
    [ "exif_format_get_size", "exif-format_8h.html#a924038efe0cd8ebade8f44619dd794f3", null ]
];