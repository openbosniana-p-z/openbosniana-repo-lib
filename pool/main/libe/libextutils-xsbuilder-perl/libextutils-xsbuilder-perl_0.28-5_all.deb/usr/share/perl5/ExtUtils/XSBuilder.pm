
package ExtUtils::XSBuilder ;
use strict ;
use vars qw{$VERSION} ;

$VERSION = '0.28' ;

1;


