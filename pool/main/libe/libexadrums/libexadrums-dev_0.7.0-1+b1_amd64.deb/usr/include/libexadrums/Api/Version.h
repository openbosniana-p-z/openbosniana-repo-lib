#ifndef LIBEXADRUMS_SOURCE_API_VERSION_H_
#define LIBEXADRUMS_SOURCE_API_VERSION_H_


namespace eXaDrumsApi
{

	inline constexpr auto LIBEXADRUMS_VERSION = "0.7.0";

}



#endif
