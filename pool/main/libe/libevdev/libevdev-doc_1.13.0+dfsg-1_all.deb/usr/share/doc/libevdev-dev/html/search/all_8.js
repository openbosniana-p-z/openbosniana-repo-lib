var searchData=
[
  ['statically_20linking_20libevdev_0',['Statically linking libevdev',['../static_linking.html',1,'']]],
  ['syn_5fdropped_20handling_1',['SYN_DROPPED handling',['../syn_dropped.html',1,'']]]
];
