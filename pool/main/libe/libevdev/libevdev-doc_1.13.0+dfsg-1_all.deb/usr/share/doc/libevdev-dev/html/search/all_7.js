var searchData=
[
  ['querying_20device_20capabilities_0',['Querying device capabilities',['../group__bits.html',1,'']]]
];
