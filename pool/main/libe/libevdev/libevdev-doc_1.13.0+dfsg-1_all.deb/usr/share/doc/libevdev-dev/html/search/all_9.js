var searchData=
[
  ['uinput_20device_20creation_0',['uinput device creation',['../group__uinput.html',1,'']]]
];
