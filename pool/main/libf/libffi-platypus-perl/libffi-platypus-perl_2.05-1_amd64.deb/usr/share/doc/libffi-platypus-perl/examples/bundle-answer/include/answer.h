#ifndef ANSWER_H
#define ANSWER_H

int answer(void);

#endif
