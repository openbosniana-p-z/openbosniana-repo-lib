%trans = (
    version => { old => '0.10', new => '0.11' },
    date    => { old => 'February 10 2017', new => 'October 26 2017' },
    copyright => { old => '2017', new => '2017' },
);

1;

