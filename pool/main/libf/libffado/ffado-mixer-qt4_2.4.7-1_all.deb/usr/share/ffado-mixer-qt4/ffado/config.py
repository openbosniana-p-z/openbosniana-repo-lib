# -*- coding: utf-8 -*-
REGISTER_URL = 'http://ffado.org/deviceregistration/register.php?action=register'
INI_FILE_PATH = "~/.ffado/registration.ini"

FFADO_CONFIG_DIR = "~/.ffado"

FFADO_VERSION="2.4.7-"

FFADO_DBUS_SERVER = 'org.ffado.Control'
FFADO_DBUS_BASEPATH = '/org/ffado/Control'

POLL_SLEEP_TIME_MSEC = 100 # 100ms

PYTHONDIR = "/usr/share/ffado-mixer-qt4/"
SHAREDIR = "/usr/share/libffado2/"

USER_CONFIG_FILE = "~/.ffado/configuration"
SYSTEM_CONFIG_FILE = "/usr/share/libffado2//configuration"

DEBUG = False

# If set true it will open all mixers
bypassdbus = False

UIDIR = PYTHONDIR
import os.path
if os.path.exists('support/mixer-qt4/ffado/mixer/globalmixer.ui'):
    UIDIR = "support/mixer-qt4"
if os.path.exists('ffado/mixer/globalmixer.ui'):
    UIDIR = "."

import os.path

# from PyQt4 import uic
from ffado.import_pyqt import *

def uicLoad(file, object):
    if not file.endswith(".ui"):
        file += ".ui"
    uic.loadUi(os.path.join(UIDIR,file), object)

# vim: et
