This directory contains some sample Perl scripts.

- pretty.pl

  Uses XML::Filter::Reindent and XML::Handler::Composer to 
  pretty print your XML file.
  These classes need some work so don't expect too much...
