This directory contains some sample Perl scripts.

- xql.pl

  This script will be installed in your perl/bin directory. It is a nice
  utility that allows you to grep XML files using XQL expressions on the
  command line. Run xql.pl without any arguments to see the USAGE message.

Run the other scripts as follows (after installing the perl modules in this 
distribution). They should print out errors, warnings and info messages
to STDERR.

	perl script.pl file.xml
