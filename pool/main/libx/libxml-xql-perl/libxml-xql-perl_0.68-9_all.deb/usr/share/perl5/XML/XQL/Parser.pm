####################################################################
#
#    This file was generated using Parse::Yapp version 1.21.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package XML::XQL::Parser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
use Parse::Yapp::Driver;



sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.21',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			"not" => 10,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'Conjunction' => 15,
			'Disjunction' => 16,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Intersection' => 20,
			'Invocation' => 21,
			'LValue' => 22,
			'Negation' => 24,
			'Path' => 25,
			'PathOp' => 26,
			'Query' => 27,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Sequence' => 30,
			'Subscript' => 31,
			'Union' => 32,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 1
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			"not" => 10,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'Conjunction' => 15,
			'Disjunction' => 16,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Intersection' => 20,
			'Invocation' => 21,
			'LValue' => 22,
			'Negation' => 24,
			'Path' => 25,
			'PathOp' => 26,
			'Query' => 36,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Sequence' => 30,
			'Subscript' => 31,
			'Union' => 32,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 2
		DEFAULT => -3
	},
	{#State 3
		DEFAULT => -64
	},
	{#State 4
		DEFAULT => -65
	},
	{#State 5
		ACTIONS => {
			"(" => -17,
			"*" => -17,
			"." => -17,
			".." => -17,
			"\@" => -17,
			'NCName' => -17,
			'XQLName_Paren' => -17
		},
		DEFAULT => -44
	},
	{#State 6
		DEFAULT => -18
	},
	{#State 7
		ACTIONS => {
			"*" => 2,
			'NCName' => 23
		},
		GOTOS => {
			'WildNCName' => 33,
			'WildQName' => 37
		}
	},
	{#State 8
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Invocation' => 21,
			'LValue' => 38,
			'Path' => 39,
			'PathOp' => 26,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 9
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Invocation' => 21,
			'LValue' => 40,
			'Path' => 39,
			'PathOp' => 26,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 10
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			"not" => 10,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Intersection' => 20,
			'Invocation' => 21,
			'LValue' => 22,
			'Negation' => 41,
			'Path' => 25,
			'PathOp' => 26,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'Union' => 32,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 11
		DEFAULT => -42
	},
	{#State 12
		DEFAULT => -68
	},
	{#State 13
		ACTIONS => {
			"/" => 42,
			"//" => 6
		},
		DEFAULT => -46,
		GOTOS => {
			'PathOp' => 43
		}
	},
	{#State 14
		ACTIONS => {
			"intersect" => 44
		},
		DEFAULT => -29
	},
	{#State 15
		ACTIONS => {
			"or" => 45
		},
		DEFAULT => -21
	},
	{#State 16
		ACTIONS => {
			'SeqOp' => 46
		},
		DEFAULT => -19
	},
	{#State 17
		DEFAULT => -67
	},
	{#State 18
		ACTIONS => {
			"[" => 47
		},
		DEFAULT => -51,
		GOTOS => {
			'Subscript_2' => 48
		}
	},
	{#State 19
		DEFAULT => -59
	},
	{#State 20
		ACTIONS => {
			'UnionOp' => 49
		},
		DEFAULT => -27
	},
	{#State 21
		DEFAULT => -66
	},
	{#State 22
		ACTIONS => {
			'COMPARE' => 50,
			'MATCH' => 52
		},
		GOTOS => {
			'ComparisonOp' => 51
		}
	},
	{#State 23
		DEFAULT => -2
	},
	{#State 24
		ACTIONS => {
			"and" => 53
		},
		DEFAULT => -23
	},
	{#State 25
		ACTIONS => {
			'COMPARE' => -37,
			'MATCH' => -37
		},
		DEFAULT => -33
	},
	{#State 26
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"\@" => 7,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AttributeName' => 12,
			'Bang' => 13,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Invocation' => 21,
			'RelativePath' => 54,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 27
		ACTIONS => {
			'' => 55
		}
	},
	{#State 28
		DEFAULT => -43
	},
	{#State 29
		DEFAULT => -62
	},
	{#State 30
		DEFAULT => -1
	},
	{#State 31
		ACTIONS => {
			"!" => 56
		},
		DEFAULT => -48
	},
	{#State 32
		DEFAULT => -25
	},
	{#State 33
		ACTIONS => {
			":" => 57
		},
		DEFAULT => -4
	},
	{#State 34
		DEFAULT => -10
	},
	{#State 35
		ACTIONS => {
			"(" => 1,
			")" => 58,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			"not" => 10,
			'INTEGER' => 60,
			'NCName' => 23,
			'NUMBER' => 62,
			'TEXT' => 64,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'Conjunction' => 15,
			'Disjunction' => 59,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Intersection' => 20,
			'Invocation' => 21,
			'Invocation_2' => 61,
			'LValue' => 22,
			'Negation' => 24,
			'Param' => 63,
			'Path' => 25,
			'PathOp' => 26,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'Union' => 32,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 36
		ACTIONS => {
			")" => 65
		}
	},
	{#State 37
		DEFAULT => -11
	},
	{#State 38
		ACTIONS => {
			'COMPARE' => 50,
			'MATCH' => 52
		},
		GOTOS => {
			'ComparisonOp' => 66
		}
	},
	{#State 39
		DEFAULT => -37
	},
	{#State 40
		ACTIONS => {
			'COMPARE' => 50,
			'MATCH' => 52
		},
		GOTOS => {
			'ComparisonOp' => 67
		}
	},
	{#State 41
		DEFAULT => -26
	},
	{#State 42
		DEFAULT => -17
	},
	{#State 43
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"\@" => 7,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AttributeName' => 12,
			'Bang' => 13,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Invocation' => 21,
			'RelativePath' => 68,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 44
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Intersection' => 69,
			'Invocation' => 21,
			'LValue' => 22,
			'Path' => 25,
			'PathOp' => 26,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 45
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			"not" => 10,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'Conjunction' => 15,
			'Disjunction' => 70,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Intersection' => 20,
			'Invocation' => 21,
			'LValue' => 22,
			'Negation' => 24,
			'Path' => 25,
			'PathOp' => 26,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'Union' => 32,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 46
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			"not" => 10,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'Conjunction' => 15,
			'Disjunction' => 16,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Intersection' => 20,
			'Invocation' => 21,
			'LValue' => 22,
			'Negation' => 24,
			'Path' => 25,
			'PathOp' => 26,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Sequence' => 71,
			'Subscript' => 31,
			'Union' => 32,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 47
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			"not" => 10,
			'INTEGER' => 72,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'Conjunction' => 15,
			'Disjunction' => 16,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'IndexArg' => 73,
			'IndexList' => 74,
			'Intersection' => 20,
			'Invocation' => 21,
			'LValue' => 22,
			'Negation' => 24,
			'Path' => 25,
			'PathOp' => 26,
			'Query' => 75,
			'Range' => 76,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Sequence' => 30,
			'Subquery' => 77,
			'Subscript' => 31,
			'Union' => 32,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 48
		DEFAULT => -50
	},
	{#State 49
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Intersection' => 20,
			'Invocation' => 21,
			'LValue' => 22,
			'Path' => 25,
			'PathOp' => 26,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'Union' => 78,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 50
		DEFAULT => -31
	},
	{#State 51
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			'INTEGER' => 79,
			'NCName' => 23,
			'NUMBER' => 80,
			'TEXT' => 83,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Invocation' => 21,
			'Path' => 81,
			'PathOp' => 26,
			'RValue' => 82,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 52
		DEFAULT => -32
	},
	{#State 53
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			"not" => 10,
			'NCName' => 23,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'Conjunction' => 84,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Intersection' => 20,
			'Invocation' => 21,
			'LValue' => 22,
			'Negation' => 24,
			'Path' => 25,
			'PathOp' => 26,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'Union' => 32,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 54
		DEFAULT => -45
	},
	{#State 55
		DEFAULT => 0
	},
	{#State 56
		ACTIONS => {
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'Invocation' => 85
		}
	},
	{#State 57
		ACTIONS => {
			"*" => 2,
			'NCName' => 23
		},
		GOTOS => {
			'WildNCName' => 86
		}
	},
	{#State 58
		DEFAULT => -13
	},
	{#State 59
		DEFAULT => -6
	},
	{#State 60
		DEFAULT => -7
	},
	{#State 61
		DEFAULT => -12
	},
	{#State 62
		DEFAULT => -8
	},
	{#State 63
		ACTIONS => {
			"," => 87
		},
		DEFAULT => -15,
		GOTOS => {
			'Invocation_3' => 88
		}
	},
	{#State 64
		DEFAULT => -9
	},
	{#State 65
		DEFAULT => -63
	},
	{#State 66
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			'INTEGER' => 79,
			'NCName' => 23,
			'NUMBER' => 80,
			'TEXT' => 83,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Invocation' => 21,
			'Path' => 81,
			'PathOp' => 26,
			'RValue' => 89,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 67
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			'INTEGER' => 79,
			'NCName' => 23,
			'NUMBER' => 80,
			'TEXT' => 83,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Invocation' => 21,
			'Path' => 81,
			'PathOp' => 26,
			'RValue' => 90,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 68
		DEFAULT => -47
	},
	{#State 69
		DEFAULT => -30
	},
	{#State 70
		DEFAULT => -22
	},
	{#State 71
		DEFAULT => -20
	},
	{#State 72
		ACTIONS => {
			"to" => 91
		},
		DEFAULT => -56
	},
	{#State 73
		ACTIONS => {
			"," => 92
		},
		DEFAULT => -54,
		GOTOS => {
			'IndexList_2' => 93
		}
	},
	{#State 74
		ACTIONS => {
			"]" => 94
		}
	},
	{#State 75
		DEFAULT => -61
	},
	{#State 76
		DEFAULT => -57
	},
	{#State 77
		ACTIONS => {
			"]" => 95
		}
	},
	{#State 78
		DEFAULT => -28
	},
	{#State 79
		DEFAULT => -39
	},
	{#State 80
		DEFAULT => -40
	},
	{#State 81
		DEFAULT => -38
	},
	{#State 82
		DEFAULT => -34
	},
	{#State 83
		DEFAULT => -41
	},
	{#State 84
		DEFAULT => -24
	},
	{#State 85
		DEFAULT => -49
	},
	{#State 86
		DEFAULT => -5
	},
	{#State 87
		ACTIONS => {
			"(" => 1,
			"*" => 2,
			"." => 3,
			".." => 4,
			"/" => 5,
			"//" => 6,
			"\@" => 7,
			"all" => 8,
			"any" => 9,
			"not" => 10,
			'INTEGER' => 60,
			'NCName' => 23,
			'NUMBER' => 62,
			'TEXT' => 64,
			'XQLName_Paren' => 35
		},
		GOTOS => {
			'AbsolutePath' => 11,
			'AttributeName' => 12,
			'Bang' => 13,
			'Comparison' => 14,
			'Conjunction' => 15,
			'Disjunction' => 59,
			'ElementName' => 17,
			'Filter' => 18,
			'Grouping' => 19,
			'Intersection' => 20,
			'Invocation' => 21,
			'LValue' => 22,
			'Negation' => 24,
			'Param' => 96,
			'Path' => 25,
			'PathOp' => 26,
			'RelativePath' => 28,
			'RelativeTerm' => 29,
			'Subscript' => 31,
			'Union' => 32,
			'WildNCName' => 33,
			'WildQName' => 34
		}
	},
	{#State 88
		ACTIONS => {
			")" => 97
		}
	},
	{#State 89
		DEFAULT => -36
	},
	{#State 90
		DEFAULT => -35
	},
	{#State 91
		ACTIONS => {
			'INTEGER' => 98
		}
	},
	{#State 92
		ACTIONS => {
			'INTEGER' => 72
		},
		GOTOS => {
			'IndexArg' => 99,
			'Range' => 76
		}
	},
	{#State 93
		DEFAULT => -53
	},
	{#State 94
		DEFAULT => -52
	},
	{#State 95
		DEFAULT => -60
	},
	{#State 96
		ACTIONS => {
			"," => 87
		},
		DEFAULT => -15,
		GOTOS => {
			'Invocation_3' => 100
		}
	},
	{#State 97
		DEFAULT => -14
	},
	{#State 98
		DEFAULT => -58
	},
	{#State 99
		ACTIONS => {
			"," => 92
		},
		DEFAULT => -54,
		GOTOS => {
			'IndexList_2' => 101
		}
	},
	{#State 100
		DEFAULT => -16
	},
	{#State 101
		DEFAULT => -55
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'Query', 1, undef
	],
	[#Rule 2
		 'WildNCName', 1, undef
	],
	[#Rule 3
		 'WildNCName', 1, undef
	],
	[#Rule 4
		 'WildQName', 1,
sub
#line 24 "Parser.yp"
{ [ Name => $_[1] ]; }
	],
	[#Rule 5
		 'WildQName', 3,
sub
#line 25 "Parser.yp"
{ 
			[ NameSpace => $_[1], Name => $_[2]]; }
	],
	[#Rule 6
		 'Param', 1, undef
	],
	[#Rule 7
		 'Param', 1,
sub
#line 30 "Parser.yp"
{ new XML::XQL::Number ($_[1]); }
	],
	[#Rule 8
		 'Param', 1,
sub
#line 31 "Parser.yp"
{ new XML::XQL::Number ($_[1]); }
	],
	[#Rule 9
		 'Param', 1,
sub
#line 32 "Parser.yp"
{ new XML::XQL::Text ($_[1]); }
	],
	[#Rule 10
		 'ElementName', 1,
sub
#line 35 "Parser.yp"
{ new XML::XQL::Element (@{$_[1]}); }
	],
	[#Rule 11
		 'AttributeName', 2,
sub
#line 38 "Parser.yp"
{ new XML::XQL::Attribute (@{$_[2]}); }
	],
	[#Rule 12
		 'Invocation', 2,
sub
#line 41 "Parser.yp"
{
			my ($func, $type) = $_[0]->{Query}->findFunctionOrMethod ($_[1], $_[2]);

			new XML::XQL::Invocation (Name => $_[1], 
						  Args => $_[2],
						  Func => $func,
						  Type => $type); }
	],
	[#Rule 13
		 'Invocation_2', 1,
sub
#line 50 "Parser.yp"
{ [] }
	],
	[#Rule 14
		 'Invocation_2', 3,
sub
#line 51 "Parser.yp"
{ unshift @{$_[2]}, $_[1]; $_[2]; }
	],
	[#Rule 15
		 'Invocation_3', 0,
sub
#line 54 "Parser.yp"
{ [] }
	],
	[#Rule 16
		 'Invocation_3', 3,
sub
#line 55 "Parser.yp"
{ unshift @{$_[3]}, $_[2]; $_[3]; }
	],
	[#Rule 17
		 'PathOp', 1, undef
	],
	[#Rule 18
		 'PathOp', 1, undef
	],
	[#Rule 19
		 'Sequence', 1, undef
	],
	[#Rule 20
		 'Sequence', 3,
sub
#line 62 "Parser.yp"
{
		    new XML::XQL::Sequence (Left => $_[1], Oper => $_[2], 
					    Right => $_[3]); }
	],
	[#Rule 21
		 'Disjunction', 1, undef
	],
	[#Rule 22
		 'Disjunction', 3,
sub
#line 68 "Parser.yp"
{ 
		    new XML::XQL::Or (Left => $_[1], Right => $_[3]); }
	],
	[#Rule 23
		 'Conjunction', 1, undef
	],
	[#Rule 24
		 'Conjunction', 3,
sub
#line 73 "Parser.yp"
{ 
		    new XML::XQL::And (Left => $_[1], Right => $_[3]); }
	],
	[#Rule 25
		 'Negation', 1, undef
	],
	[#Rule 26
		 'Negation', 2,
sub
#line 78 "Parser.yp"
{ new XML::XQL::Not (Left => $_[2]); }
	],
	[#Rule 27
		 'Union', 1, undef
	],
	[#Rule 28
		 'Union', 3,
sub
#line 82 "Parser.yp"
{ 
		    new XML::XQL::Union (Left => $_[1], Right => $_[3]); }
	],
	[#Rule 29
		 'Intersection', 1, undef
	],
	[#Rule 30
		 'Intersection', 3,
sub
#line 87 "Parser.yp"
{ 
		    new XML::XQL::Intersect (Left => $_[1], Right => $_[3]); }
	],
	[#Rule 31
		 'ComparisonOp', 1,
sub
#line 91 "Parser.yp"
{
		  [ $_[1], $_[0]->{Query}->findComparisonOperator ($_[1]) ]; }
	],
	[#Rule 32
		 'ComparisonOp', 1,
sub
#line 93 "Parser.yp"
{
		  [ $_[1], $_[0]->{Query}->findComparisonOperator ($_[1]) ]; }
	],
	[#Rule 33
		 'Comparison', 1, undef
	],
	[#Rule 34
		 'Comparison', 3,
sub
#line 98 "Parser.yp"
{
			new XML::XQL::Compare (All => 0, Left => $_[1], 
				Oper => $_[2]->[0], Func => $_[2]->[1], 
				Right => $_[3]); }
	],
	[#Rule 35
		 'Comparison', 4,
sub
#line 102 "Parser.yp"
{
			new XML::XQL::Compare (All => 0, Left => $_[2], 
				Oper => $_[3]->[0], Func => $_[3]->[1],
				Right => $_[4]); }
	],
	[#Rule 36
		 'Comparison', 4,
sub
#line 106 "Parser.yp"
{
			new XML::XQL::Compare (All => 1, Left => $_[2], 
				Oper => $_[3]->[0], Func => $_[3]->[1],
				Right => $_[4]); }
	],
	[#Rule 37
		 'LValue', 1, undef
	],
	[#Rule 38
		 'RValue', 1, undef
	],
	[#Rule 39
		 'RValue', 1,
sub
#line 116 "Parser.yp"
{ new XML::XQL::Number ($_[1]); }
	],
	[#Rule 40
		 'RValue', 1,
sub
#line 117 "Parser.yp"
{ new XML::XQL::Number ($_[1]); }
	],
	[#Rule 41
		 'RValue', 1,
sub
#line 118 "Parser.yp"
{ new XML::XQL::Text ($_[1]); }
	],
	[#Rule 42
		 'Path', 1, undef
	],
	[#Rule 43
		 'Path', 1, undef
	],
	[#Rule 44
		 'AbsolutePath', 1,
sub
#line 124 "Parser.yp"
{ new XML::Root; }
	],
	[#Rule 45
		 'AbsolutePath', 2,
sub
#line 125 "Parser.yp"
{ 
		    new XML::XQL::Path (PathOp => $_[1], Right => $_[2]); }
	],
	[#Rule 46
		 'RelativePath', 1, undef
	],
	[#Rule 47
		 'RelativePath', 3,
sub
#line 130 "Parser.yp"
{ 
		    new XML::XQL::Path (Left => $_[1], PathOp => $_[2], 
				        Right => $_[3]); }
	],
	[#Rule 48
		 'Bang', 1, undef
	],
	[#Rule 49
		 'Bang', 3,
sub
#line 136 "Parser.yp"
{
		    XML::XQL::parseError ("only methods (not functions) can be used after the Bang (near '!" . $_[3]->{Name} . "'")
			unless $_[3]->isMethod;

		    new XML::XQL::Bang (Left => $_[1], 
				        Right => $_[3]); }
	],
	[#Rule 50
		 'Subscript', 2,
sub
#line 144 "Parser.yp"
{ 
		    defined($_[2]) ? 
			new XML::XQL::Subscript (Left => $_[1], 
					    IndexList => $_[2]) : $_[1]; }
	],
	[#Rule 51
		 'Subscript_2', 0, undef
	],
	[#Rule 52
		 'Subscript_2', 3,
sub
#line 151 "Parser.yp"
{ $_[2]; }
	],
	[#Rule 53
		 'IndexList', 2,
sub
#line 156 "Parser.yp"
{ push (@{$_[1]}, @{$_[2]}); $_[1]; }
	],
	[#Rule 54
		 'IndexList_2', 0,
sub
#line 159 "Parser.yp"
{ [] }
	],
	[#Rule 55
		 'IndexList_2', 3,
sub
#line 160 "Parser.yp"
{ push (@{$_[2]}, @{$_[3]}); $_[2]; }
	],
	[#Rule 56
		 'IndexArg', 1,
sub
#line 163 "Parser.yp"
{ [ $_[1], $_[1] ]; }
	],
	[#Rule 57
		 'IndexArg', 1, undef
	],
	[#Rule 58
		 'Range', 3,
sub
#line 167 "Parser.yp"
{
		    # Syntactic Constraint 9:
		    # If both integers are positive or if both integers are 
		    # negative, the first integer must be less than or
          	    # equal to the second integer. 

		    XML::XQL::parseError (
			"$_[1] should be less than $_[3] in '$_[1] $_[2] $_[3]'")
				if ($_[1] > $_[3] && ($_[1] < 0) == ($_[3] < 0));
		    [ $_[1], $_[3] ]; }
	],
	[#Rule 59
		 'Filter', 1, undef
	],
	[#Rule 60
		 'Filter', 4,
sub
#line 180 "Parser.yp"
{ 
			new XML::XQL::Filter (Left => $_[1], Right => $_[3]); }
	],
	[#Rule 61
		 'Subquery', 1, undef
	],
	[#Rule 62
		 'Grouping', 1, undef
	],
	[#Rule 63
		 'Grouping', 3,
sub
#line 189 "Parser.yp"
{ $_[2]; }
	],
	[#Rule 64
		 'RelativeTerm', 1,
sub
#line 192 "Parser.yp"
{ new XML::XQL::Current; }
	],
	[#Rule 65
		 'RelativeTerm', 1,
sub
#line 193 "Parser.yp"
{ new XML::XQL::Parent; }
	],
	[#Rule 66
		 'RelativeTerm', 1, undef
	],
	[#Rule 67
		 'RelativeTerm', 1, undef
	],
	[#Rule 68
		 'RelativeTerm', 1, undef
	]
],
                                  @_);
    bless($self,$class);
}

#line 199 "Parser.yp"


1;
