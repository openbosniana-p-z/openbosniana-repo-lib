#!/usr/bin/perl
#-----------------------------------------------------------------------------#
# X11::GUITest ($Id: ScriptTemplate.pl 203 2011-05-15 02:03:11Z ctrondlp $)
# Notes: 
#-----------------------------------------------------------------------------#

## Pragmas/Directives/Diagnostics ##
use strict;
use warnings;

## Imports (use [MODULE] qw/[IMPORTLIST]/;) ##
use X11::GUITest qw/

/;

## Constants (sub [CONSTANT]() { [VALUE]; }) ##

## Variables (my [SIGIL][VARIABLE] = [INITIALVALUE];) ##

## Core ##
print "$0 : Script Start\n";


print "This script serves as a template.\n";


print "$0 : Script End (Success)\n";

## Subroutines ##
