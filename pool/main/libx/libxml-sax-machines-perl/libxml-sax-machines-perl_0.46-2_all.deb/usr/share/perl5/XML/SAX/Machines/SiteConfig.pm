package XML::SAX::Machines::SiteConfig;

#
# Which options are legal in ProcessorClassOptions.  This is provided here
# so you can extend the options if need be.  It's also a handy quick
# reference.  The master defaults are in DefaultConfig.pm.
#
$LegalProcessorClassOptions = {
#     ConstructWithOptionsHashes => "Use Foo->new( { Handler => $h } ) instead of Foo->new( Handler => $h )",
};
    

#
# SAX Processor specific configs.
#
# Per-processor options
# =====================
# 
# ConstructWithOptionsHashes (boolean)
#
#     tells XML::SAX::Machine to construct the processor like:
#
#        Foo->new(
#            { Handler => $h },
#        );
#
#    instead of
#
#        Foo->new( Handler => $h );
#

$ProcessorClassOptions = {
#     "XML::Filter::MyFilter" => {
#         ConstructWithOptionsHashes => 1,
#     },
};

1;
