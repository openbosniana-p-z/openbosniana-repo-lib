/* TODO: config file generated during cmake */
/* these flags are not what the target platorm actuall supports but what
 * features enabled during runtime probing for the optimal function
 */
#if defined(__x86_64__) || defined(__i386__)

#define XTRXDSP_HAS__SSE2__
//#define XTRXDSP_HAS__SSSE3__
//#define XTRXDSP_HAS__SSE4_1__
//#define XTRXDSP_HAS__SSE4_2__
#define XTRXDSP_HAS__AVX__
#define XTRXDSP_HAS__FMA__
//#define XTRXDSP_HAS__AVX2__

#endif
