Title: LIBXSMM
project: LIBXSMM
author: Intel Corporation
summary: Library targeting Intel Architecture for specialized matrix operations.
project_github: https://github.com/hfp/libxsmm
project_download: https://github.com/hfp/libxsmm/releases/latest
favicon: ../.theme/img/favicon.png
css: ../.theme/ford.css
output_dir: ../html
src_dir: ../include
search: true
page_dir: .

Library targeting Intel Architecture for specialized matrix operations: [libxsmm.readthedocs.io/](https://libxsmm.readthedocs.io/)
