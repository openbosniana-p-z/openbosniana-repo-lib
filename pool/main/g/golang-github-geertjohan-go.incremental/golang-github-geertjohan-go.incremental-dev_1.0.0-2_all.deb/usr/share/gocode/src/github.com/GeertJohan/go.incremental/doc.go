
// package incremental provides concurency-safe incremental numbers.
//
// This package was created by a simple piece of code located in the gen subdirectory. Please modify that command if you want to modify this package.
package incremental