# goini
INI file parser in go.

# See Also
For real apps, you can use [TOML](https://github.com/BurntSushi/toml) instead, which is a better INI format :-)
