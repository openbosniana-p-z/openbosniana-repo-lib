// Package version contains information about the library version.
package version
