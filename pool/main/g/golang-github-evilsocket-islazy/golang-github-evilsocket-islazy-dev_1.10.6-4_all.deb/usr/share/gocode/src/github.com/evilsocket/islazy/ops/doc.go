// Package ops contains helper operators.
package ops
