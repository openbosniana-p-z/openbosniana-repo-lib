// Package log provides access to log functions.
package log
