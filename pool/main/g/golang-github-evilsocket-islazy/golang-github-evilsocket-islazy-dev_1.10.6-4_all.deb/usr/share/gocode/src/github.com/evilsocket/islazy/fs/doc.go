// Package fs contains helper functions for file system access and enumeration.
package fs
