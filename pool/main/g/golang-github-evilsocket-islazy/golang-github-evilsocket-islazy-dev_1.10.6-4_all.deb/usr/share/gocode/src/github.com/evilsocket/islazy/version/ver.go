package version

const (
	// Version is the version of the library (semantic versioning applies).
	Version = "1.10.6"
)
