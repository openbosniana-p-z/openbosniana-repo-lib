// Package str contains utilities for string manipulation.
package str
