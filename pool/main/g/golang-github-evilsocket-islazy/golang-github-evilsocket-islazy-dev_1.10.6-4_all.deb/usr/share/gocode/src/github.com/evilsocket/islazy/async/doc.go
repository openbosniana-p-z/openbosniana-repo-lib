// Package async contains a set of helper objects for async tasks and job queues.
package async
