// Package plugin contains objects and functions to load and
// use javascript plugins in order to extend the functionalities
// of your projects.
package plugin
