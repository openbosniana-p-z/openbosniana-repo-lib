// Package data contains basic threadsafe data structures with
// filesystem persistance and configurable flushing policies.
package data
