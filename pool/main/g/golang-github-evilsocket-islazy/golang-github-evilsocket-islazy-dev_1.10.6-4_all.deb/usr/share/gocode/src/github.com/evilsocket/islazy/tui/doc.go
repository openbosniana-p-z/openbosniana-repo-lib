// Package tui contains a set of helper objects and functions for terminal
// based user interfaces.
package tui
