// Package backendutil provide utilities to implement SMTP backends.
package backendutil
