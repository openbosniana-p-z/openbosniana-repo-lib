// +build !debug

package chef

func debug(fmt string, args ...interface{}) {}
