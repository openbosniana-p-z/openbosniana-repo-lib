// Package authres parses and formats Authentication-Results
//
// Authentication-Results header fields are standardized in RFC 7601.
package authres
