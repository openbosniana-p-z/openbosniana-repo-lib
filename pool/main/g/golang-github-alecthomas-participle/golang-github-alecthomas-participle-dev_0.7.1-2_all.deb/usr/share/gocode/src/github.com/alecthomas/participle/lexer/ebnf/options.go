package ebnf

// Option for configuring the EBNF lexer.
type Option func(*ebnfLexerDefinition)
