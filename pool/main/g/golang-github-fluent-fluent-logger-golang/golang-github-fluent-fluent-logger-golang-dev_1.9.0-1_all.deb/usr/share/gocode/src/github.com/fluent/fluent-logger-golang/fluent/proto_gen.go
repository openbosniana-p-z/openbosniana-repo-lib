package fluent

// NOTE: THIS FILE WAS PRODUCED BY THE
// MSGP CODE GENERATION TOOL (github.com/tinylib/msgp)
// DO NOT EDIT

import (
	"github.com/tinylib/msgp/msgp"
)

// DecodeMsg implements msgp.Decodable
func (z *AckResp) DecodeMsg(dc *msgp.Reader) (err error) {
	var field []byte
	_ = field
	var zxvk uint32
	zxvk, err = dc.ReadMapHeader()
	if err != nil {
		return
	}
	for zxvk > 0 {
		zxvk--
		field, err = dc.ReadMapKeyPtr()
		if err != nil {
			return
		}
		switch msgp.UnsafeString(field) {
		case "ack":
			z.Ack, err = dc.ReadString()
			if err != nil {
				return
			}
		default:
			err = dc.Skip()
			if err != nil {
				return
			}
		}
	}
	return
}

// EncodeMsg implements msgp.Encodable
func (z AckResp) EncodeMsg(en *msgp.Writer) (err error) {
	// map header, size 1
	// write "ack"
	err = en.Append(0x81, 0xa3, 0x61, 0x63, 0x6b)
	if err != nil {
		return err
	}
	err = en.WriteString(z.Ack)
	if err != nil {
		return
	}
	return
}

// MarshalMsg implements msgp.Marshaler
func (z AckResp) MarshalMsg(b []byte) (o []byte, err error) {
	o = msgp.Require(b, z.Msgsize())
	// map header, size 1
	// string "ack"
	o = append(o, 0x81, 0xa3, 0x61, 0x63, 0x6b)
	o = msgp.AppendString(o, z.Ack)
	return
}

// UnmarshalMsg implements msgp.Unmarshaler
func (z *AckResp) UnmarshalMsg(bts []byte) (o []byte, err error) {
	var field []byte
	_ = field
	var zbzg uint32
	zbzg, bts, err = msgp.ReadMapHeaderBytes(bts)
	if err != nil {
		return
	}
	for zbzg > 0 {
		zbzg--
		field, bts, err = msgp.ReadMapKeyZC(bts)
		if err != nil {
			return
		}
		switch msgp.UnsafeString(field) {
		case "ack":
			z.Ack, bts, err = msgp.ReadStringBytes(bts)
			if err != nil {
				return
			}
		default:
			bts, err = msgp.Skip(bts)
			if err != nil {
				return
			}
		}
	}
	o = bts
	return
}

// Msgsize returns an upper bound estimate of the number of bytes occupied by the serialized message
func (z AckResp) Msgsize() (s int) {
	s = 1 + 4 + msgp.StringPrefixSize + len(z.Ack)
	return
}

// DecodeMsg implements msgp.Decodable
func (z *Entry) DecodeMsg(dc *msgp.Reader) (err error) {
	var zbai uint32
	zbai, err = dc.ReadArrayHeader()
	if err != nil {
		return
	}
	if zbai != 2 {
		err = msgp.ArrayError{Wanted: 2, Got: zbai}
		return
	}
	z.Time, err = dc.ReadInt64()
	if err != nil {
		return
	}
	z.Record, err = dc.ReadIntf()
	if err != nil {
		return
	}
	return
}

// EncodeMsg implements msgp.Encodable
func (z Entry) EncodeMsg(en *msgp.Writer) (err error) {
	// array header, size 2
	err = en.Append(0x92)
	if err != nil {
		return err
	}
	err = en.WriteInt64(z.Time)
	if err != nil {
		return
	}
	err = en.WriteIntf(z.Record)
	if err != nil {
		return
	}
	return
}

// MarshalMsg implements msgp.Marshaler
func (z Entry) MarshalMsg(b []byte) (o []byte, err error) {
	o = msgp.Require(b, z.Msgsize())
	// array header, size 2
	o = append(o, 0x92)
	o = msgp.AppendInt64(o, z.Time)
	o, err = msgp.AppendIntf(o, z.Record)
	if err != nil {
		return
	}
	return
}

// UnmarshalMsg implements msgp.Unmarshaler
func (z *Entry) UnmarshalMsg(bts []byte) (o []byte, err error) {
	var zcmr uint32
	zcmr, bts, err = msgp.ReadArrayHeaderBytes(bts)
	if err != nil {
		return
	}
	if zcmr != 2 {
		err = msgp.ArrayError{Wanted: 2, Got: zcmr}
		return
	}
	z.Time, bts, err = msgp.ReadInt64Bytes(bts)
	if err != nil {
		return
	}
	z.Record, bts, err = msgp.ReadIntfBytes(bts)
	if err != nil {
		return
	}
	o = bts
	return
}

// Msgsize returns an upper bound estimate of the number of bytes occupied by the serialized message
func (z Entry) Msgsize() (s int) {
	s = 1 + msgp.Int64Size + msgp.GuessSize(z.Record)
	return
}

// DecodeMsg implements msgp.Decodable
func (z *Forward) DecodeMsg(dc *msgp.Reader) (err error) {
	var zcua uint32
	zcua, err = dc.ReadArrayHeader()
	if err != nil {
		return
	}
	if zcua != 3 {
		err = msgp.ArrayError{Wanted: 3, Got: zcua}
		return
	}
	z.Tag, err = dc.ReadString()
	if err != nil {
		return
	}
	var zxhx uint32
	zxhx, err = dc.ReadArrayHeader()
	if err != nil {
		return
	}
	if cap(z.Entries) >= int(zxhx) {
		z.Entries = (z.Entries)[:zxhx]
	} else {
		z.Entries = make([]Entry, zxhx)
	}
	for zajw := range z.Entries {
		var zlqf uint32
		zlqf, err = dc.ReadArrayHeader()
		if err != nil {
			return
		}
		if zlqf != 2 {
			err = msgp.ArrayError{Wanted: 2, Got: zlqf}
			return
		}
		z.Entries[zajw].Time, err = dc.ReadInt64()
		if err != nil {
			return
		}
		z.Entries[zajw].Record, err = dc.ReadIntf()
		if err != nil {
			return
		}
	}
	var zdaf uint32
	zdaf, err = dc.ReadMapHeader()
	if err != nil {
		return
	}
	if z.Option == nil && zdaf > 0 {
		z.Option = make(map[string]string, zdaf)
	} else if len(z.Option) > 0 {
		for key, _ := range z.Option {
			delete(z.Option, key)
		}
	}
	for zdaf > 0 {
		zdaf--
		var zwht string
		var zhct string
		zwht, err = dc.ReadString()
		if err != nil {
			return
		}
		zhct, err = dc.ReadString()
		if err != nil {
			return
		}
		z.Option[zwht] = zhct
	}
	return
}

// EncodeMsg implements msgp.Encodable
func (z *Forward) EncodeMsg(en *msgp.Writer) (err error) {
	// array header, size 3
	err = en.Append(0x93)
	if err != nil {
		return err
	}
	err = en.WriteString(z.Tag)
	if err != nil {
		return
	}
	err = en.WriteArrayHeader(uint32(len(z.Entries)))
	if err != nil {
		return
	}
	for zajw := range z.Entries {
		// array header, size 2
		err = en.Append(0x92)
		if err != nil {
			return err
		}
		err = en.WriteInt64(z.Entries[zajw].Time)
		if err != nil {
			return
		}
		err = en.WriteIntf(z.Entries[zajw].Record)
		if err != nil {
			return
		}
	}
	err = en.WriteMapHeader(uint32(len(z.Option)))
	if err != nil {
		return
	}
	for zwht, zhct := range z.Option {
		err = en.WriteString(zwht)
		if err != nil {
			return
		}
		err = en.WriteString(zhct)
		if err != nil {
			return
		}
	}
	return
}

// MarshalMsg implements msgp.Marshaler
func (z *Forward) MarshalMsg(b []byte) (o []byte, err error) {
	o = msgp.Require(b, z.Msgsize())
	// array header, size 3
	o = append(o, 0x93)
	o = msgp.AppendString(o, z.Tag)
	o = msgp.AppendArrayHeader(o, uint32(len(z.Entries)))
	for zajw := range z.Entries {
		// array header, size 2
		o = append(o, 0x92)
		o = msgp.AppendInt64(o, z.Entries[zajw].Time)
		o, err = msgp.AppendIntf(o, z.Entries[zajw].Record)
		if err != nil {
			return
		}
	}
	o = msgp.AppendMapHeader(o, uint32(len(z.Option)))
	for zwht, zhct := range z.Option {
		o = msgp.AppendString(o, zwht)
		o = msgp.AppendString(o, zhct)
	}
	return
}

// UnmarshalMsg implements msgp.Unmarshaler
func (z *Forward) UnmarshalMsg(bts []byte) (o []byte, err error) {
	var zpks uint32
	zpks, bts, err = msgp.ReadArrayHeaderBytes(bts)
	if err != nil {
		return
	}
	if zpks != 3 {
		err = msgp.ArrayError{Wanted: 3, Got: zpks}
		return
	}
	z.Tag, bts, err = msgp.ReadStringBytes(bts)
	if err != nil {
		return
	}
	var zjfb uint32
	zjfb, bts, err = msgp.ReadArrayHeaderBytes(bts)
	if err != nil {
		return
	}
	if cap(z.Entries) >= int(zjfb) {
		z.Entries = (z.Entries)[:zjfb]
	} else {
		z.Entries = make([]Entry, zjfb)
	}
	for zajw := range z.Entries {
		var zcxo uint32
		zcxo, bts, err = msgp.ReadArrayHeaderBytes(bts)
		if err != nil {
			return
		}
		if zcxo != 2 {
			err = msgp.ArrayError{Wanted: 2, Got: zcxo}
			return
		}
		z.Entries[zajw].Time, bts, err = msgp.ReadInt64Bytes(bts)
		if err != nil {
			return
		}
		z.Entries[zajw].Record, bts, err = msgp.ReadIntfBytes(bts)
		if err != nil {
			return
		}
	}
	var zeff uint32
	zeff, bts, err = msgp.ReadMapHeaderBytes(bts)
	if err != nil {
		return
	}
	if z.Option == nil && zeff > 0 {
		z.Option = make(map[string]string, zeff)
	} else if len(z.Option) > 0 {
		for key, _ := range z.Option {
			delete(z.Option, key)
		}
	}
	for zeff > 0 {
		var zwht string
		var zhct string
		zeff--
		zwht, bts, err = msgp.ReadStringBytes(bts)
		if err != nil {
			return
		}
		zhct, bts, err = msgp.ReadStringBytes(bts)
		if err != nil {
			return
		}
		z.Option[zwht] = zhct
	}
	o = bts
	return
}

// Msgsize returns an upper bound estimate of the number of bytes occupied by the serialized message
func (z *Forward) Msgsize() (s int) {
	s = 1 + msgp.StringPrefixSize + len(z.Tag) + msgp.ArrayHeaderSize
	for zajw := range z.Entries {
		s += 1 + msgp.Int64Size + msgp.GuessSize(z.Entries[zajw].Record)
	}
	s += msgp.MapHeaderSize
	if z.Option != nil {
		for zwht, zhct := range z.Option {
			_ = zhct
			s += msgp.StringPrefixSize + len(zwht) + msgp.StringPrefixSize + len(zhct)
		}
	}
	return
}

// DecodeMsg implements msgp.Decodable
func (z *Message) DecodeMsg(dc *msgp.Reader) (err error) {
	var zdnj uint32
	zdnj, err = dc.ReadArrayHeader()
	if err != nil {
		return
	}
	if zdnj != 4 {
		err = msgp.ArrayError{Wanted: 4, Got: zdnj}
		return
	}
	z.Tag, err = dc.ReadString()
	if err != nil {
		return
	}
	z.Time, err = dc.ReadInt64()
	if err != nil {
		return
	}
	z.Record, err = dc.ReadIntf()
	if err != nil {
		return
	}
	var zobc uint32
	zobc, err = dc.ReadMapHeader()
	if err != nil {
		return
	}
	if z.Option == nil && zobc > 0 {
		z.Option = make(map[string]string, zobc)
	} else if len(z.Option) > 0 {
		for key, _ := range z.Option {
			delete(z.Option, key)
		}
	}
	for zobc > 0 {
		zobc--
		var zrsw string
		var zxpk string
		zrsw, err = dc.ReadString()
		if err != nil {
			return
		}
		zxpk, err = dc.ReadString()
		if err != nil {
			return
		}
		z.Option[zrsw] = zxpk
	}
	return
}

// EncodeMsg implements msgp.Encodable
func (z *Message) EncodeMsg(en *msgp.Writer) (err error) {
	// array header, size 4
	err = en.Append(0x94)
	if err != nil {
		return err
	}
	err = en.WriteString(z.Tag)
	if err != nil {
		return
	}
	err = en.WriteInt64(z.Time)
	if err != nil {
		return
	}
	err = en.WriteIntf(z.Record)
	if err != nil {
		return
	}
	err = en.WriteMapHeader(uint32(len(z.Option)))
	if err != nil {
		return
	}
	for zrsw, zxpk := range z.Option {
		err = en.WriteString(zrsw)
		if err != nil {
			return
		}
		err = en.WriteString(zxpk)
		if err != nil {
			return
		}
	}
	return
}

// MarshalMsg implements msgp.Marshaler
func (z *Message) MarshalMsg(b []byte) (o []byte, err error) {
	o = msgp.Require(b, z.Msgsize())
	// array header, size 4
	o = append(o, 0x94)
	o = msgp.AppendString(o, z.Tag)
	o = msgp.AppendInt64(o, z.Time)
	o, err = msgp.AppendIntf(o, z.Record)
	if err != nil {
		return
	}
	o = msgp.AppendMapHeader(o, uint32(len(z.Option)))
	for zrsw, zxpk := range z.Option {
		o = msgp.AppendString(o, zrsw)
		o = msgp.AppendString(o, zxpk)
	}
	return
}

// UnmarshalMsg implements msgp.Unmarshaler
func (z *Message) UnmarshalMsg(bts []byte) (o []byte, err error) {
	var zsnv uint32
	zsnv, bts, err = msgp.ReadArrayHeaderBytes(bts)
	if err != nil {
		return
	}
	if zsnv != 4 {
		err = msgp.ArrayError{Wanted: 4, Got: zsnv}
		return
	}
	z.Tag, bts, err = msgp.ReadStringBytes(bts)
	if err != nil {
		return
	}
	z.Time, bts, err = msgp.ReadInt64Bytes(bts)
	if err != nil {
		return
	}
	z.Record, bts, err = msgp.ReadIntfBytes(bts)
	if err != nil {
		return
	}
	var zkgt uint32
	zkgt, bts, err = msgp.ReadMapHeaderBytes(bts)
	if err != nil {
		return
	}
	if z.Option == nil && zkgt > 0 {
		z.Option = make(map[string]string, zkgt)
	} else if len(z.Option) > 0 {
		for key, _ := range z.Option {
			delete(z.Option, key)
		}
	}
	for zkgt > 0 {
		var zrsw string
		var zxpk string
		zkgt--
		zrsw, bts, err = msgp.ReadStringBytes(bts)
		if err != nil {
			return
		}
		zxpk, bts, err = msgp.ReadStringBytes(bts)
		if err != nil {
			return
		}
		z.Option[zrsw] = zxpk
	}
	o = bts
	return
}

// Msgsize returns an upper bound estimate of the number of bytes occupied by the serialized message
func (z *Message) Msgsize() (s int) {
	s = 1 + msgp.StringPrefixSize + len(z.Tag) + msgp.Int64Size + msgp.GuessSize(z.Record) + msgp.MapHeaderSize
	if z.Option != nil {
		for zrsw, zxpk := range z.Option {
			_ = zxpk
			s += msgp.StringPrefixSize + len(zrsw) + msgp.StringPrefixSize + len(zxpk)
		}
	}
	return
}

// DecodeMsg implements msgp.Decodable
func (z *MessageExt) DecodeMsg(dc *msgp.Reader) (err error) {
	var zqke uint32
	zqke, err = dc.ReadArrayHeader()
	if err != nil {
		return
	}
	if zqke != 4 {
		err = msgp.ArrayError{Wanted: 4, Got: zqke}
		return
	}
	z.Tag, err = dc.ReadString()
	if err != nil {
		return
	}
	err = dc.ReadExtension(&z.Time)
	if err != nil {
		return
	}
	z.Record, err = dc.ReadIntf()
	if err != nil {
		return
	}
	var zqyh uint32
	zqyh, err = dc.ReadMapHeader()
	if err != nil {
		return
	}
	if z.Option == nil && zqyh > 0 {
		z.Option = make(map[string]string, zqyh)
	} else if len(z.Option) > 0 {
		for key, _ := range z.Option {
			delete(z.Option, key)
		}
	}
	for zqyh > 0 {
		zqyh--
		var zema string
		var zpez string
		zema, err = dc.ReadString()
		if err != nil {
			return
		}
		zpez, err = dc.ReadString()
		if err != nil {
			return
		}
		z.Option[zema] = zpez
	}
	return
}

// EncodeMsg implements msgp.Encodable
func (z *MessageExt) EncodeMsg(en *msgp.Writer) (err error) {
	// array header, size 4
	err = en.Append(0x94)
	if err != nil {
		return err
	}
	err = en.WriteString(z.Tag)
	if err != nil {
		return
	}
	err = en.WriteExtension(&z.Time)
	if err != nil {
		return
	}
	err = en.WriteIntf(z.Record)
	if err != nil {
		return
	}
	err = en.WriteMapHeader(uint32(len(z.Option)))
	if err != nil {
		return
	}
	for zema, zpez := range z.Option {
		err = en.WriteString(zema)
		if err != nil {
			return
		}
		err = en.WriteString(zpez)
		if err != nil {
			return
		}
	}
	return
}

// MarshalMsg implements msgp.Marshaler
func (z *MessageExt) MarshalMsg(b []byte) (o []byte, err error) {
	o = msgp.Require(b, z.Msgsize())
	// array header, size 4
	o = append(o, 0x94)
	o = msgp.AppendString(o, z.Tag)
	o, err = msgp.AppendExtension(o, &z.Time)
	if err != nil {
		return
	}
	o, err = msgp.AppendIntf(o, z.Record)
	if err != nil {
		return
	}
	o = msgp.AppendMapHeader(o, uint32(len(z.Option)))
	for zema, zpez := range z.Option {
		o = msgp.AppendString(o, zema)
		o = msgp.AppendString(o, zpez)
	}
	return
}

// UnmarshalMsg implements msgp.Unmarshaler
func (z *MessageExt) UnmarshalMsg(bts []byte) (o []byte, err error) {
	var zyzr uint32
	zyzr, bts, err = msgp.ReadArrayHeaderBytes(bts)
	if err != nil {
		return
	}
	if zyzr != 4 {
		err = msgp.ArrayError{Wanted: 4, Got: zyzr}
		return
	}
	z.Tag, bts, err = msgp.ReadStringBytes(bts)
	if err != nil {
		return
	}
	bts, err = msgp.ReadExtensionBytes(bts, &z.Time)
	if err != nil {
		return
	}
	z.Record, bts, err = msgp.ReadIntfBytes(bts)
	if err != nil {
		return
	}
	var zywj uint32
	zywj, bts, err = msgp.ReadMapHeaderBytes(bts)
	if err != nil {
		return
	}
	if z.Option == nil && zywj > 0 {
		z.Option = make(map[string]string, zywj)
	} else if len(z.Option) > 0 {
		for key, _ := range z.Option {
			delete(z.Option, key)
		}
	}
	for zywj > 0 {
		var zema string
		var zpez string
		zywj--
		zema, bts, err = msgp.ReadStringBytes(bts)
		if err != nil {
			return
		}
		zpez, bts, err = msgp.ReadStringBytes(bts)
		if err != nil {
			return
		}
		z.Option[zema] = zpez
	}
	o = bts
	return
}

// Msgsize returns an upper bound estimate of the number of bytes occupied by the serialized message
func (z *MessageExt) Msgsize() (s int) {
	s = 1 + msgp.StringPrefixSize + len(z.Tag) + msgp.ExtensionPrefixSize + z.Time.Len() + msgp.GuessSize(z.Record) + msgp.MapHeaderSize
	if z.Option != nil {
		for zema, zpez := range z.Option {
			_ = zpez
			s += msgp.StringPrefixSize + len(zema) + msgp.StringPrefixSize + len(zpez)
		}
	}
	return
}
