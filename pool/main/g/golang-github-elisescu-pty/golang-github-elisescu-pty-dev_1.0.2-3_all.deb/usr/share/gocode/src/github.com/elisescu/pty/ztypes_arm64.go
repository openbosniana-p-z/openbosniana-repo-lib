// Created by cgo -godefs - DO NOT EDIT
// cgo -godefs types.go

// +build arm64

package pty

type (
	_C_int  int32
	_C_uint uint32
)
