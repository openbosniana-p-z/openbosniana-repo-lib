subset [![Build Status](https://secure.travis-ci.org/facebookgo/subset.png)](http://travis-ci.org/facebookgo/subset)
======

Check if a value is a subset of another, based on reflect/deepequals.go.
Documentation: http://godoc.org/github.com/facebookgo/subset
