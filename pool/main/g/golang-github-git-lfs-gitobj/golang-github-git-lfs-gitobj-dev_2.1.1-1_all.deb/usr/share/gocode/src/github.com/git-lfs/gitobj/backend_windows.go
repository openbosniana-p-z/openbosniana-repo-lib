// +build windows

package gitobj

const alternatesSeparator = ";"
