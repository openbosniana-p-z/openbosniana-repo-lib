// Package windowsbase contains helper functionality for accessing the
// "Known Folders" shell API functions on Windows systems.
//
// This package calls into Windows system DLLs, so it cannot be used on any
// other platform.
package windowsbase
