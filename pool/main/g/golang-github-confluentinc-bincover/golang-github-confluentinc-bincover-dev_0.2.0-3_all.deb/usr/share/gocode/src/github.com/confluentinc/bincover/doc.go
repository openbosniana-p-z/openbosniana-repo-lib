/*
Package bincover provides an easy way to measure code coverage of Golang binaries.
See examples/ to see how bincover is used to measure coverage of a simple Go application.
*/
package bincover
