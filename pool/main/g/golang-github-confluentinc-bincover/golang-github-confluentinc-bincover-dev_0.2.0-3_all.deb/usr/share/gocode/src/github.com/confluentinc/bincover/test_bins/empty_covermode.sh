#!/usr/bin/env bash
echo Hello world
echo START_BINCOVER_METADATA
echo "{\"cover_mode\":\"\",\"exit_code\":1}"
echo END_BINCOVER_METADATA
