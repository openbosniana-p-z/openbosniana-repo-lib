#!/usr/bin/env bash
echo Hello world
exit 1
