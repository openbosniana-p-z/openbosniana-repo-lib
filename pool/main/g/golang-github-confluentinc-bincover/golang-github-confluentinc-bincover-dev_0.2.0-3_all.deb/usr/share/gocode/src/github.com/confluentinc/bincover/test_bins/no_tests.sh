#!/usr/bin/env bash
echo testing: warning: no tests to run
