package zstd

// #cgo pkg-config: libzstd
import "C"
