package pktline

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}
