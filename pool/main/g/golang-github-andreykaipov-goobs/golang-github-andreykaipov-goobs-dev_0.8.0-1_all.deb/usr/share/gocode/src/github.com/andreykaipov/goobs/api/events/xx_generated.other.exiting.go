// This file has been automatically generated. Don't edit it.

package events

/*
Exiting represents the event body for the "Exiting" event.
Since v0.3.
*/
type Exiting struct {
	EventBasic
}
