// This file has been automatically generated. Don't edit it.

package events

/*
RecordingPaused represents the event body for the "RecordingPaused" event.
Since v4.7.0.
*/
type RecordingPaused struct {
	EventBasic
}
