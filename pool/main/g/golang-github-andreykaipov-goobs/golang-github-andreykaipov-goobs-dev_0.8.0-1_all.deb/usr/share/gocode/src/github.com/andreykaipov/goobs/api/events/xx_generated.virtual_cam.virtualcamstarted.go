// This file has been automatically generated. Don't edit it.

package events

/*
VirtualCamStarted represents the event body for the "VirtualCamStarted" event.
Since v4.9.1.
*/
type VirtualCamStarted struct {
	EventBasic
}
