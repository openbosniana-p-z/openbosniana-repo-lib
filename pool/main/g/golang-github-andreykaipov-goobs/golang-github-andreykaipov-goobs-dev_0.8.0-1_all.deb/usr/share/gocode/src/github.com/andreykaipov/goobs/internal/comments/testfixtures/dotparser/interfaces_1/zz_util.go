package testfixtures

// this file exists so this Go package doesn't error out.

type Interface interface {
	Wow() string
}
