// This file has been automatically generated. Don't edit it.

package replaybuffer

import requests "github.com/andreykaipov/goobs/api/requests"

// Client represents a client for 'replay buffer' requests.
type Client struct {
	*requests.Client
}
