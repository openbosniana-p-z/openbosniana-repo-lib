// This file has been automatically generated. Don't edit it.

package events

/*
ReplayStarted represents the event body for the "ReplayStarted" event.
Since v4.2.0.
*/
type ReplayStarted struct {
	EventBasic
}
