// This file has been automatically generated. Don't edit it.

package sceneitems

import requests "github.com/andreykaipov/goobs/api/requests"

// Client represents a client for 'scene items' requests.
type Client struct {
	*requests.Client
}
