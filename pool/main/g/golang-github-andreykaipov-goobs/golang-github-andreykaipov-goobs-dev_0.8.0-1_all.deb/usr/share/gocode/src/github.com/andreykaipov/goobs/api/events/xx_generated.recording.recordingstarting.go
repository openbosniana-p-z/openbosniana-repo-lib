// This file has been automatically generated. Don't edit it.

package events

/*
RecordingStarting represents the event body for the "RecordingStarting" event.
Since v0.3.
*/
type RecordingStarting struct {
	EventBasic
}
