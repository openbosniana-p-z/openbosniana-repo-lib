// This file has been automatically generated. Don't edit it.

package studiomode

import requests "github.com/andreykaipov/goobs/api/requests"

// Client represents a client for 'studio mode' requests.
type Client struct {
	*requests.Client
}
