// This file has been automatically generated. Don't edit it.

package events

/*
RecordingResumed represents the event body for the "RecordingResumed" event.
Since v4.7.0.
*/
type RecordingResumed struct {
	EventBasic
}
