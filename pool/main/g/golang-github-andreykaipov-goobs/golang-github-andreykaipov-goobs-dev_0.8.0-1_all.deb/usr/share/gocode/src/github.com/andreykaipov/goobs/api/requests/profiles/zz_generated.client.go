// This file has been automatically generated. Don't edit it.

package profiles

import requests "github.com/andreykaipov/goobs/api/requests"

// Client represents a client for 'profiles' requests.
type Client struct {
	*requests.Client
}
