package testfixtures

// this file exists so this Go package doesn't error out.

type EmbeddedDummy struct {
	a int
	b string
}
