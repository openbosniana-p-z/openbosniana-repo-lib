// This file has been automatically generated. Don't edit it.

package outputs

import requests "github.com/andreykaipov/goobs/api/requests"

// Client represents a client for 'outputs' requests.
type Client struct {
	*requests.Client
}
