// This file has been automatically generated. Don't edit it.

package events

/*
StreamStopped represents the event body for the "StreamStopped" event.
Since v0.3.
*/
type StreamStopped struct {
	EventBasic
}
