// This file has been automatically generated. Don't edit it.

package events

/*
VirtualCamStopped represents the event body for the "VirtualCamStopped" event.
Since v4.9.1.
*/
type VirtualCamStopped struct {
	EventBasic
}
