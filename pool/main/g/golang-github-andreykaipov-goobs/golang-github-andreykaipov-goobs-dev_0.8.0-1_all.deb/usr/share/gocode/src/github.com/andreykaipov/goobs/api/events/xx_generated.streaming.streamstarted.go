// This file has been automatically generated. Don't edit it.

package events

/*
StreamStarted represents the event body for the "StreamStarted" event.
Since v0.3.
*/
type StreamStarted struct {
	EventBasic
}
