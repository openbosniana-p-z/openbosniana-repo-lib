// This file has been automatically generated. Don't edit it.

package events

/*
ReplayStopped represents the event body for the "ReplayStopped" event.
Since v4.2.0.
*/
type ReplayStopped struct {
	EventBasic
}
