// This file has been automatically generated. Don't edit it.

package typedefs

// ScenesCollection represents the complex type for ScenesCollection.
type ScenesCollection struct {
	// Name of the scene collection
	ScName string `json:"sc-name,omitempty"`
}
