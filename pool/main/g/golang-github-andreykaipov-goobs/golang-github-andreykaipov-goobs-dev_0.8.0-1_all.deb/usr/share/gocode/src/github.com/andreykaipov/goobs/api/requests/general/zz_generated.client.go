// This file has been automatically generated. Don't edit it.

package general

import requests "github.com/andreykaipov/goobs/api/requests"

// Client represents a client for 'general' requests.
type Client struct {
	*requests.Client
}
