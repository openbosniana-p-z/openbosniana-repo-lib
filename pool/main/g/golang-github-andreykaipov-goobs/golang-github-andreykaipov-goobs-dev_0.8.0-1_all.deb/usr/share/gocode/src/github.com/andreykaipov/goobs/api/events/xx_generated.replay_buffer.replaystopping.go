// This file has been automatically generated. Don't edit it.

package events

/*
ReplayStopping represents the event body for the "ReplayStopping" event.
Since v4.2.0.
*/
type ReplayStopping struct {
	EventBasic
}
