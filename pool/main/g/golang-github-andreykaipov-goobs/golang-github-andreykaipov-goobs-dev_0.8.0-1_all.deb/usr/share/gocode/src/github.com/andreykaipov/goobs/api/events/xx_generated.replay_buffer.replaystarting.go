// This file has been automatically generated. Don't edit it.

package events

/*
ReplayStarting represents the event body for the "ReplayStarting" event.
Since v4.2.0.
*/
type ReplayStarting struct {
	EventBasic
}
