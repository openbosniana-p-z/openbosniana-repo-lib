// This file has been automatically generated. Don't edit it.

package scenes

import requests "github.com/andreykaipov/goobs/api/requests"

// Client represents a client for 'scenes' requests.
type Client struct {
	*requests.Client
}
