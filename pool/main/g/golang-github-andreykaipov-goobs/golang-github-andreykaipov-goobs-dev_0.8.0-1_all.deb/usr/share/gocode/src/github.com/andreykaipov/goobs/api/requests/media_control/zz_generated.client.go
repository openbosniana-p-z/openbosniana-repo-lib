// This file has been automatically generated. Don't edit it.

package mediacontrol

import requests "github.com/andreykaipov/goobs/api/requests"

// Client represents a client for 'media control' requests.
type Client struct {
	*requests.Client
}
