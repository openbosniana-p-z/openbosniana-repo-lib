ensure [![Build Status](https://secure.travis-ci.org/facebookgo/ensure.png)](http://travis-ci.org/facebookgo/ensure)
======

Documentation: https://godoc.org/github.com/facebookgo/ensure
