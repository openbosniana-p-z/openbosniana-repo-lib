package a

type Foo struct{}
