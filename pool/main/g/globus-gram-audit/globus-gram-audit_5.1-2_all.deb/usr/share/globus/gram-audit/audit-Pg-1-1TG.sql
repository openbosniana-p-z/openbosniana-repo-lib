ALTER TABLE gram_audit_table ADD COLUMN "gateway_user" VARCHAR(256);
