// Package recording allows writing and reading of bettercap's session recordings.
package recording
