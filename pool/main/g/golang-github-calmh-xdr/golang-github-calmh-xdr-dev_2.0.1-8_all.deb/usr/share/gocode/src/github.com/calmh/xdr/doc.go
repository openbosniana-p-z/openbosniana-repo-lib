// Copyright (C) 2014 Jakob Borg. All rights reserved. Use of this source code
// is governed by an MIT-style license that can be found in the LICENSE file.

// Package xdr implements an XDR (RFC 4506) marshaller/unmarshaller.
package xdr
