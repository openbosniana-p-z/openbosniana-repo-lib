git-review
==========

A git command for submitting branches to Gerrit

git-review is a tool that helps submitting Git branches to Gerrit for
review.

* Free software: Apache license
* Documentation: http://docs.opendev.org/opendev/git-review
* Source: https://opendev.org/opendev/git-review
* Bugs: https://storyboard.openstack.org/#!/project/opendev/git-review
