package stats

const (
	StatsDump    = "stats-dump"
	StatsRestore = "stats-restore"
)
