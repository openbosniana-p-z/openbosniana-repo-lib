package syscallx

// make us look more like package syscall, so mksyscall.pl output works
var _zero uintptr
