class GitlintError(Exception):
    """Based Exception class for all gitlint exceptions"""

    pass
