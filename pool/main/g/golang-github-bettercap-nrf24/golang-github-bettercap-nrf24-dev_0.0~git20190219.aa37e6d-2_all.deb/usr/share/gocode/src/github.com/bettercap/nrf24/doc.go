// Package nrf24 allows interaction with nRF24LU1+ based dongles and RFStorm firmware.
// Ref. https://github.com/BastilleResearch/nrf-research-firmware
package nrf24
