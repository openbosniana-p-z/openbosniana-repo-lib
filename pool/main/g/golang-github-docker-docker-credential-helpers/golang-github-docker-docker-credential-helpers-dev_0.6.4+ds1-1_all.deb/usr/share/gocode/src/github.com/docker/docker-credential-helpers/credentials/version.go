package credentials

// Version holds a string describing the current version
const Version = "0.6.4"
