stats [![Build Status](https://secure.travis-ci.org/facebookgo/stats.png)](https://travis-ci.org/facebookgo/stats)
=====

Documentation: https://godoc.org/github.com/facebookgo/stats
