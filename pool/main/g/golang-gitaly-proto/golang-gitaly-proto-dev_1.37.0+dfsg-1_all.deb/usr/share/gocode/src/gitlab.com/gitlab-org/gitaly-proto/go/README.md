# Auto-generated Go gRPC bindings for gitaly

This Go package is used both by the Gitaly server itself and by Go
Gitaly clients (such as gitlab-workhorse).
