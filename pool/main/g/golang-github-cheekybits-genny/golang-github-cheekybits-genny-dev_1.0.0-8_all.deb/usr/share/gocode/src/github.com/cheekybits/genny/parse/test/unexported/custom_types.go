package unexported

type myType struct{}
