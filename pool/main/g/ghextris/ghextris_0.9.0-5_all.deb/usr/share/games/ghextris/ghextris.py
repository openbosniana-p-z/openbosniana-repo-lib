#!/usr/bin/python3

# Gnome-hextris; a free rewrite of the xhextris game in Python for Gnome
# Copyright 2004 Mikko Rauhala <mjr@iki.fi>

#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

# This will be overwritten for the installed version:
SHAREDIR = "/usr/share/games/ghextris"

VERSION="0.9.0"

import os
import sys

import gi
import cairo
gi.require_version("Gtk","3.0")
from gi.repository import Gtk, Gio, GLib, GObject, Gdk

import gettext

import random

class Hextris:
    def __init__(self):
        self.pieceheight = 24
        self.piecewidth = 26
        self.piecenarrow = 14
#        self.piecewidth = 20
#        self.piecenarrow = 20
        self.rows = 23
        self.cols = 13 # Must be odd or weirdness ensues

        self.width = (((self.cols//2)+2)*self.piecewidth +
                      ((self.cols//2)+1) * self.piecenarrow) + 2
        self.height = (self.rows+1) * self.pieceheight + 2

        self.colors = ("blue", "yellow", "red", "orange", "green", "purple",
                       "cyan", "gray45", "magenta", "lightblue")
        self.colorsrgb = [(0.0, 0.0, 1.0), #blue
                          (1.0, 1.0, 0.0), #yellow
                          (1.0, 0.0, 0.0), #red
                          (1.0, 0.6470588235294118, 0.0), #orange
                          (0.0, 0.5019607843137255, 0.0), #green
                          (0.5019607843137255, 0.0, 0.5019607843137255), #purple
                          (0.0, 1.0, 1.0), #cyan
                          (0.45,0.45,0.45), #gray45
                          (1.0, 0.0, 1.0), #magenta
                          (0.6784313725490196, 0.8470588235294118, 0.9019607843137255)]; #lightblue
        self.grayrgb = (0.5019607843137255, 0.5019607843137255, 0.5019607843137255)
        self.deltax = (-1, -1, -1, 0, 0, 0, 0, 0, -1, -1)
        self.deltay = (-1, -1, -1, 0, 0, 0, 0, 0, -1, -1)
        self.pieces = (
            (((0,), (0, 0, 1), (0, 0, 1), (0, 0, 1), (0, 0, 1)),
             ((0,), (0, 0, 0, 1), (0, 1, 1), (1,)),
             ((0,), (1, 1), (0, 0, 1, 1)),
             ((0, 0, 1), (0, 0, 1), (0, 0, 1), (0, 0, 1)),
             ((0,), (0, 0, 0, 1, 1), (0, 1, 1)),
             ((0,), (0, 1), (0, 0, 1, 1), (0, 0, 0, 0, 1))),
            (((0,), (0, 0, 1), (0, 0, 1, 1), (0, 0, 0, 1)),
             ((0,), (0, 0, 0, 1), (0, 0, 1), (0, 1, 1)),
             ((0,), (0,), (1, 1, 1, 1)),
             ((0, 1), (0, 1), (0, 0, 1), (0, 0, 1)),
             ((0, 0, 0, 1), (0, 0, 1), (0, 1, 1)),
             ((0,), (0, 1, 0, 1), (0, 0, 1, 0, 1))),
            (((0,), (0, 0, 1), (0, 1, 1), (0, 1)),
             ((0,), (0, 1, 0, 1), (1, 0, 1, 0)),
             ((0, 1), (0, 0, 1), (0, 0, 1, 1)),
             ((0, 0, 0, 1), (0, 0, 0, 1), (0, 0, 1), (0, 0, 1)),
             ((0,), (0,), (0, 1, 1, 1, 1)),
             ((0,), (0, 1), (0, 0, 1), (0, 0, 1, 1))),
            (((0, 1, 0), (0, 1, 0), (1, 0, 1)),
             ((0,), (1, 1, 1), (0, 1, 0))),
            (((0, 1), (1,), (1, 1)),
             ((0, 1), (1, 0, 1), (1,)),
             ((0, 1), (1, 0, 1), (0, 0, 1)),
             ((0, 1), (0, 0, 1), (0, 1, 1)),
             ((0,), (0, 0, 1), (1, 1, 1)),
             ((0,), (1,), (1, 1, 1))),
            (((0,), (0, 1), (1, 1, 1)),
             ((0,), (1, 1), (1, 1, 0)),
             ((0, 1), (1, 1), (1,)),
             ((0, 1), (1, 1, 1)),
             ((0, 1), (0, 1, 1), (0, 0, 1)),
             ((0,), (0, 1, 1), (0, 1, 1))),
            (((0, 1), (0, 1), (0, 1, 1)),
             ((0,), (0, 1, 1), (1, 1)),
             ((0,), (1, 1), (1, 0, 1)),
             ((0, 1), (1, 1), (0, 1)),
             ((0, 1), (0, 1, 1), (1,)),
             ((0,), (1, 1, 1), (0, 0, 1))),
            (((0, 1), (0, 1), (1, 1)),
             ((0,), (1, 1, 1), (1,)),
             ((0, 1), (1, 1), (0, 0, 1)),
             ((0, 1), (0, 1, 1), (0, 1)),
             ((0,), (0, 1, 1), (1, 0, 1)),
             ((0,), (1, 1), (0, 1, 1))),
            (((0,), (0, 0, 1), (0, 0, 1), (0, 0, 1, 1)),
             ((0,), (0, 0, 0, 1), (0, 1, 1), (0, 1)),
             ((0,), (0, 1), (1, 0, 1, 1)),
             ((0, 1), (0, 0, 1), (0, 0, 1), (0, 0, 1)),
             ((0, 0, 0, 1), (0, 0, 0, 1), (0, 1, 1)),
             ((0,), (0, 1), (0, 0, 1, 1, 1))),
            (((0,), (0, 0, 1), (0, 0, 1), (0, 1, 1)),
             ((0,), (0, 0, 0, 1), (1, 1, 1)),
             ((0, 1), (0, 1), (0, 0, 1, 1)),
             ((0, 0, 0, 1), (0, 0, 1), (0, 0, 1), (0, 0, 1)),
             ((0,), (0, 0, 0, 1), (0, 1, 1, 0, 1)),
             ((0,), (0, 1), (0, 0, 1, 1), (0, 0, 0, 1)))
            )

        self.attitude = 0
        self.speed_orig = 400
        self.speed = 400
        self.speed_ratio = 0.99
        self.speed_reset = False
        self.paused = False
        self.lost = True
        self.score = 0
        self.hiscore = 0
        self.nextnum = -1

        self.running = False

        self.nextpiece = False

    def draw_hexagon(self ,context, xoffset, yoffset, color):
        pts = []
        pts.append ((self.piecewidth - self.piecenarrow)//2)
        pts.append (0)
        pts.append (self.piecewidth - pts[0])
        pts.append (0)
        pts.append (self.piecewidth)
        pts.append (self.pieceheight//2)
        pts.append (pts[2])
        pts.append (self.pieceheight)
        pts.append (pts[0])
        pts.append (pts[7])
        pts.append (0)
        pts.append (pts[5])
        pts.append (pts[0])
        pts.append (pts[1])

        for i in range(len(pts)//2):
            x = pts[i*2] + xoffset
            y = pts[i*2+1] + yoffset + 1
            if (i == 0):
                context.move_to(x,y)
            else:
                context.line_to(x,y)
        context.close_path()
        context.set_antialias(cairo.Antialias.NONE)
        context.set_source_rgb(*color)
        context.fill_preserve()
        context.set_source_rgb(0,0,0)
        context.set_line_width(1)
        context.stroke()

    def logicaltodisplay(self,x,y):
        resultx = (x+1)*((self.piecewidth+self.piecenarrow)//2)
        resulty = ((y * self.pieceheight) + (((x%2)-1) * self.pieceheight//2))
        return resultx,resulty

    def draw_board(self,context):
        for i in range(self.rows+1):
            for j in [0, 1]:
                self.draw_hexagon(context,
                                     j * (self.piecewidth*(self.cols//2+1) +
                                              self.piecenarrow*(self.cols//2+1)),
                                     i * self.pieceheight,
                                     self.grayrgb)
        for i in range(self.cols//2):
            self.draw_hexagon(context,
                                 (i+1) * (self.piecewidth +
                                              self.piecenarrow),
                                 self.rows * self.pieceheight,
                                 self.grayrgb)
        for i in range(self.cols//2+1):
            self.draw_hexagon(context,
                                 (i * (self.piecewidth + self.piecenarrow)+
                                      (self.piecewidth + self.piecenarrow)//2),
                                 ((self.rows*2-1) * self.pieceheight)//2,
                                 self.grayrgb)
    def init_field(self,n):
        self.field = []
        for i in range(self.rows):
            self.field.append([])
            for j in range(self.cols):
                self.field[i].append(n)

    def on_new_activate(self, action,parameter):
        self.canvas.queue_draw()
        self.speed = self.speed_orig
        self.score = 0
        self.attitude = 0
        self.lost = False
        self.paused = False

        self.update_appbar()

        self.init_field(0)

        self.nextnum = random.randint(0, 9)
        self.preview.queue_draw()
        self.next_piece()

        if self.running == False:
            GLib.timeout_add(self.speed, self.timer_handler)
            self.running = True
        else:
            self.speed_reset = True

        return True

    def on_about_activate(self, action,parameter):
        about = self.about
        about.set_property("name", "Ghextris")
        about.set_property("version", VERSION)
        about.connect('response',lambda dialog, data: dialog.hide())
        about.show()
        return True

    def on_pause_game_activate(self, action,parameter):
        if self.lost == True:
            return False
        if self.paused == True:
            self.paused = False
        else:
            self.paused = True
        return True

    ##different types of event seem to give us different
    #parameters, we ignore them anyway
    def on_quit_activate(self, *args):
        self.application.quit()

    def draw_field(self,context):
        for i in range(self.rows):
            for j in range(self.cols):
                x,y = self.logicaltodisplay(j,i)
                color = self.field[i][j]-1
                if (color >= 0):
                    self.draw_hexagon(context,
                                     x , y,
                                     self.colorsrgb[color])
        if self.running:
            for (j,i) in self.piece_to_logical_list(self.piecenum,self.attitude,self.piece_x,self.piece_y):
                x,y = self.logicaltodisplay(j,i)
                color = self.piecenum%(len(self.colors)+1)
                if (color >= 0):
                    self.draw_hexagon(context,
                                     x , y,
                                     self.colorsrgb[color])

    def drawpreview(self,area,context):
        if (self.nextnum >= 0):
            for (j,i) in self.piece_to_logical_list(self.nextnum,0,self.deltax[self.nextnum],self.deltay[self.nextnum]+(self.rows-3)//2):
                x,y = self.logicaltodisplay(j,i)
                color = self.nextnum%(len(self.colors)+1)
                if (color >= 0):
                    self.draw_hexagon(context,
                                     x , y,
                                     self.colorsrgb[color])


    def drawmain(self,area,context):
        self.draw_board(context)
        self.draw_field(context)

    def main(self,application):
        self.init_field(0)
        gettext.install("ghextris")
        self.glade = os.path.join(SHAREDIR, "ghextris.glade")

        wTree = Gtk.Builder()
        wTree.add_from_file(self.glade)

        win = wTree.get_object("GhextrisApp")
        self.about = wTree.get_object("about")

        self.application = application
        application.set_menubar(wTree.get_object("menubar"))
        new_action = Gio.SimpleAction.new("new",None)
        new_action.connect("activate",self.on_new_activate)
        application.add_action(new_action)
        new_action = Gio.SimpleAction.new("pause-game",None)
        new_action.connect("activate",self.on_pause_game_activate)
        application.add_action(new_action)
        new_action = Gio.SimpleAction.new("quit",None)
        new_action.connect("activate",self.on_quit_activate)
        application.add_action(new_action)
        new_action = Gio.SimpleAction.new("about",None)
        new_action.connect("activate",self.on_about_activate)
        application.add_action(new_action)


        self.canvas = wTree.get_object("canvas")
        preview = wTree.get_object("previewcanvas")
        self.appbar = wTree.get_object("appbar") #.get_children()[0]
        #self.appbar = appbar.get_children()[0]

        win.connect('destroy', self.on_quit_activate)
        win.set_application(application)

        self.canvas.set_size_request(self.width, self.height)
        self.canvas.connect("draw",self.drawmain)
        self.canvas.show()

        preview.set_size_request(self.piecewidth * 4, self.pieceheight * 5)
        preview.connect("draw",self.drawpreview)

        preview.show()
        self.preview = preview
        
        win.connect("key-press-event", self.key_handler)

        random.seed()

        self.update_appbar()

        win.show()

    def next_piece(self):
        self.piecenum = self.nextnum
        self.nextnum = random.randint(0, 9)
        self.preview.queue_draw()
        self.attitude = 0
        self.piece_x = (self.cols//2)-1 + self.deltax[self.piecenum]
        self.piece_y = -3 + self.deltax[self.piecenum]

    def timer_handler(self):
        self.canvas.queue_draw()
        if self.lost == True:
            self.running = False
            return False

        if self.paused == True:
            return True
        self.piece_y += 1
        
        if self.check_collisions() == True:
            self.piece_y -= 1
            self.update_field()
            if self.top_occupied() != True:
                self.next_piece()
            else:
                self.lost = True
                if self.hiscore < self.score:
                    self.hiscore = self.score
                self.update_appbar()
                self.running  = False
                return False

        if self.speed_reset == True:
            self.speed_reset = False
            GLib.timeout_add(int(self.speed), self.timer_handler)
            return False

        return True

    def update_appbar(self):
        self.appbar.set_text("%s: %d  |  %s: %d" % (_("Score"), self.score,
                                                    _("High score"),
                                                    self.hiscore))

    def key_handler(self, widget, event=None):
        self.canvas.queue_draw()
        if self.lost == True:
            return False
        if event.keyval == Gdk.KEY_p and self.lost == False:
            if self.paused == True:
                self.paused = False
            else:
                self.paused = True
            return True

        if self.paused == True:
            return False

        if event.keyval == Gdk.KEY_Up or event.keyval == Gdk.KEY_Down:
            if event.keyval == Gdk.KEY_Up:
                attitude_change = 1
            else:
                attitude_change = -1
            old_attitude = self.attitude
            self.attitude = ((self.attitude + attitude_change +
                              len(self.pieces[self.piecenum])) %
                             len(self.pieces[self.piecenum]))
            if self.check_collisions() == True:
                self.attitude = old_attitude
                return True

            return True

        if event.keyval == Gdk.KEY_Left or event.keyval == Gdk.KEY_Right:
            if event.keyval == Gdk.KEY_Left:
                deltax = -1
            else:
                deltax = 1
            self.piece_x += deltax

            deltay = 0
            if self.piece_x%2 == 0:
                deltay += self.pieceheight//2
            else:
                deltay -= self.pieceheight//2

            if self.check_collisions() == True:
                if deltay > 0:
                    self.piece_x -= deltax
                    return True
                self.piece_y += 1
                deltay += self.pieceheight
                if self.check_collisions() == True:
                    self.piece_x -= deltax
                    self.piece_y -= 1
                    return True

            return True

        if event.keyval == Gdk.KEY_space:
            orig_piece_y = self.piece_y
            while self.check_collisions() == False:
                self.piece_y += 1
            self.piece_y -= 1
            self.score += self.piece_y - orig_piece_y
            if self.score > self.hiscore:
                self.hiscore = self.score
            self.update_field()
            if self.top_occupied() != True:
                self.next_piece()
            else:
                self.lost = True
                if self.hiscore < self.score:
                    self.hiscore = self.score
                self.update_appbar()

            return True

        return False

    def check_collisions(self):
        for i in range(len(self.pieces[self.piecenum][self.attitude])):
            for j in range(len(self.pieces[self.piecenum][self.attitude][i])):
                if self.pieces[self.piecenum][self.attitude][i][j] != 0:
                    if j%2 == 0 and self.piece_x%2 == 1:
                        deltay = -1
                    else:
                        deltay = 0
                    if j + self.piece_x < 0 or j + self.piece_x >= self.cols:
                        return True
                    if ((i + self.piece_y + deltay > 0) and
                        (i + self.piece_y + deltay >= self.rows or
                         self.field[i + self.piece_y + deltay][j + self.piece_x] != 0)):
                        return True
        return False

    def piece_to_logical_list(self,piecenum,attitude,piece_x,piece_y):
        result = [];
        for i in range(len(self.pieces[piecenum][attitude])):
            for j in range(len(self.pieces[piecenum][attitude][i])):
                if self.pieces[piecenum][attitude][i][j] != 0:
                    if j%2 == 0 and piece_x%2 == 1:
                        deltay = -1
                    else:
                        deltay = 0
                    if i+piece_y+deltay >= 0:
                        y = i + piece_y + deltay
                        x = j + piece_x
                        result.append((x,y))
        return result


    def update_field(self):
        for i in range(len(self.pieces[self.piecenum][self.attitude])):
            for j in range(len(self.pieces[self.piecenum][self.attitude][i])):
                if self.pieces[self.piecenum][self.attitude][i][j] != 0:
                    if j%2 == 0 and self.piece_x%2 == 1:
                        deltay = -1
                    else:
                        deltay = 0
                    if i+self.piece_y+deltay >= 0:
                        self.field[i + self.piece_y + deltay][j + self.piece_x] = self.piecenum%(len(self.colors)+1)+1
        self.collapse_rows()

    def collapse_rows(self):
        row_points = 50
        for i in range(self.rows):
            row_full = True
            for j in range(self.cols):
                if self.field[i][j] == 0:
                    row_full = False
                    break

            if row_full == True:
                row_points *= 2
                self.speed *= self.speed_ratio
                self.speed_reset = True
                for j in range(i-1, -1, -1):
                    self.field[j+1] = self.field[j]
                self.field[0] = []
                for j in range(self.cols):
                    self.field[0].append(0)
        if row_points > 50:
            self.score += row_points
            if self.score > self.hiscore:
                self.hiscore = self.score
        self.update_appbar()
                
    def top_occupied(self):
        for i in range(self.cols):
            if self.field[0][i] != 0:
                return True
        return False

class HextrisApp(Gtk.Application):
    def __init__(self, *args, **kwargs):
        super().__init__(
            *args,
            application_id="org.example.myapp",
            #flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE,
            **kwargs
        )
        self.window = None


    def do_activate(self):
        h.main(self)

if __name__ == '__main__':
    app = HextrisApp()
    h = Hextris()
    app.run(sys.argv)

