package collections

type (
	Point struct {
		X, Y int
	}
)
