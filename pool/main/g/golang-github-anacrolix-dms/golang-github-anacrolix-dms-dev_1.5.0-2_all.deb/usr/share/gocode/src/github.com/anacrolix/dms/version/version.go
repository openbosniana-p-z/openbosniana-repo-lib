package version

const DmsVersion = "1.4"
