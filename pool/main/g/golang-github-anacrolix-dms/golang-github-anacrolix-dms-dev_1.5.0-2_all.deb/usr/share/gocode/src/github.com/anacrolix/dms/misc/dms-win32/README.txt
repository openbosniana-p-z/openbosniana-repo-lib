Double click the batch file "dms-gui".

Select a media directory to share, and enjoy from a DLNA/UPnP enabled device.

Try BubbleUPnP from an Android, or VLC's "Local Network>UPnP" interface.