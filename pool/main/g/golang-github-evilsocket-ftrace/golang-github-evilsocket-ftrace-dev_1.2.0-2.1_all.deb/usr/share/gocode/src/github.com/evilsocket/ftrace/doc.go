// Package ftrace utilizes the FTRACE kernel framework in order to trace system calls and kernel events from user space.
package ftrace
