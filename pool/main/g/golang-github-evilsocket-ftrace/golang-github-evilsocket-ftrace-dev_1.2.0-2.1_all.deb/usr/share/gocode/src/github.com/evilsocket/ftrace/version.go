package ftrace

// Version represents the version of this package.
const Version = "1.2.0"
