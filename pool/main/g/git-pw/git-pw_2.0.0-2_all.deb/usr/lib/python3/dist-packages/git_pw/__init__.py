"""
git-pw -- A tool for integrating Git with Patchwork, the web-based patch
tracking system.
"""

import pkg_resources

__version__ = pkg_resources.get_distribution('git-pw').version
