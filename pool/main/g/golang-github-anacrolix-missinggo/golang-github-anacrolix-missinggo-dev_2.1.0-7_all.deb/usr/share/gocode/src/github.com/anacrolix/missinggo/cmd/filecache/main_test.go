package main

import (
	"testing"
)

func TestFailedPutDeletesFile(t *testing.T) {
	// TODO
}
