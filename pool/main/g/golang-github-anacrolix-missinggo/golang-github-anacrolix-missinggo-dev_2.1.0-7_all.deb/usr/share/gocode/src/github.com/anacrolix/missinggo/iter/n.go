package iter

import "github.com/bradfitz/iter"

func N(n int) []struct{} {
	return iter.N(n)
}
