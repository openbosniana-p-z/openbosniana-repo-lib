package missinggo

import (
	"os"
)

const O_ACCMODE = os.O_RDONLY | os.O_WRONLY | os.O_RDWR
