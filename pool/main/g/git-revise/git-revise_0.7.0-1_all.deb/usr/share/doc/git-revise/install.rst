Installing
==========

:command:`git-revise` can be installed from PyPi_. Python 3.8 or higher is
required.

.. code-block:: bash

  $ pip install --user git-revise

.. _PyPi: https://pypi.org/project/git-revise/
