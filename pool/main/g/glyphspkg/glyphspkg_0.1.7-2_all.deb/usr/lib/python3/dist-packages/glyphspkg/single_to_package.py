from pathlib import Path
from typing import Optional


def single_to_package(
    input_path: Path, output_path: Optional[Path] = None
) -> Path:
    raise NotImplementedError
