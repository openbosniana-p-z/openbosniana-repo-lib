package URI::mongo;
use base 'URI::mongodb';
our $VERSION = '0.20';

1;
