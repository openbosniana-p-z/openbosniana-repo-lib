package URI::sqlite3;
use base 'URI::sqlite';
our $VERSION = '0.20';

1;
