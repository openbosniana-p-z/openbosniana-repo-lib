package URI::postgresxc;
use base 'URI::pg';
our $VERSION = '0.20';

1;
