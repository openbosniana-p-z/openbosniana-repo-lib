package URI::pgsql;
use base 'URI::pg';
our $VERSION = '0.20';

