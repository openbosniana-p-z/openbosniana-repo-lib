package URI::pgxc;
use base 'URI::pg';
our $VERSION = '0.20';

1;
