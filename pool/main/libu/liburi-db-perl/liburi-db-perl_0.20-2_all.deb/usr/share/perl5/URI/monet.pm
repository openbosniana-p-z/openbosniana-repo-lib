package URI::monet;
use base 'URI::monetdb';
our $VERSION = '0.20';

1;
