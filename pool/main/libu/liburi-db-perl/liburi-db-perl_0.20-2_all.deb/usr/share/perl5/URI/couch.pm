package URI::couch;
use base 'URI::couchdb';
our $VERSION = '0.20';

1;
