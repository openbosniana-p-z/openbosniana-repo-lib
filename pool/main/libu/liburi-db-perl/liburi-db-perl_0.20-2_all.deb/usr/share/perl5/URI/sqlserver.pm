package URI::sqlserver;
use base 'URI::mssql';
our $VERSION = '0.20';

1;
