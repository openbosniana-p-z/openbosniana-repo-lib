package URI::postgresql;
use base 'URI::pg';
our $VERSION = '0.20';

1;
