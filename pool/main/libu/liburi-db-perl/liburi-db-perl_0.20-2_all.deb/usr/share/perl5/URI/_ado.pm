package URI::_ado;
use base 'URI::_odbc';
our $VERSION = '0.20';

sub dbi_driver   { 'ADO' }
