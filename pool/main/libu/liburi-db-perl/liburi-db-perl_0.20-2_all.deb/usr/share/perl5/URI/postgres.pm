package URI::postgres;
use base 'URI::pg';
our $VERSION = '0.20';

