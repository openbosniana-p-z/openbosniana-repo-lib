package URI::yugabytedb;
use base 'URI::yugabyte';
our $VERSION = '0.20';

1;
