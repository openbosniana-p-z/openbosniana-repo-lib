package URI::maria;
use base 'URI::mysql';
our $VERSION = '0.20';

1;
