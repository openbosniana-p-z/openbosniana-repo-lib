package URI::snowflake;
use base 'URI::_odbc';
our $VERSION = '0.20';

sub default_port { 443 }

1;
