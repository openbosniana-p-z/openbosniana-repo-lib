package URI::cockroachdb;
use base 'URI::cockroach';
our $VERSION = '0.20';
