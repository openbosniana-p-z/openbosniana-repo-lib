var examples =
[
    [ "MetricManagerIncrementToday.cpp", "MetricManagerIncrementToday_8cpp-example.html", null ],
    [ "MetricManagerUpdateToday.cpp", "MetricManagerUpdateToday_8cpp-example.html", null ],
    [ "MetricManagerAdvanced.cpp", "MetricManagerAdvanced_8cpp-example.html", null ],
    [ "MetricManagerIncrementTodayCAPI.c", "MetricManagerIncrementTodayCAPI_8c-example.html", null ],
    [ "MetricManagerUpdateTodayCAPI.c", "MetricManagerUpdateTodayCAPI_8c-example.html", null ],
    [ "MetricManagerAdvancedCAPI.c", "MetricManagerAdvancedCAPI_8c-example.html", null ]
];