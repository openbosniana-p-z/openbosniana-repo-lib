var usermetricsinput_8h =
[
    [ "UserMetricsInputMetric", "usermetricsinput_8h.html#a1abb7e3afa51177792d0672b4e9769b9", null ],
    [ "UserMetricsInputMetricManager", "usermetricsinput_8h.html#a7352ed8164cb4dfee8f0ef9d27d3ebe1", null ],
    [ "UserMetricsInputMetricParameters", "usermetricsinput_8h.html#a34ed483df591648eb3f3118609eae6df", null ],
    [ "UserMetricsInputMetricUpdate", "usermetricsinput_8h.html#a83a29a00021c4e85a2bacd75ad9187e6", null ],
    [ "USERMETRICSINPUT_METRICTYPE", "usermetricsinput_8h.html#a78804a06f7ad26c86a309b2aa62f3438", [
      [ "METRIC_TYPE_USER", "usermetricsinput_8h.html#a78804a06f7ad26c86a309b2aa62f3438a18030d5c860e9af1669d98f5f7b8359a", null ],
      [ "METRIC_TYPE_SYSTEM", "usermetricsinput_8h.html#a78804a06f7ad26c86a309b2aa62f3438a24c1907a4ce32646905fe99a0ee34d3a", null ]
    ] ],
    [ "usermetricsinput_metric_increment", "usermetricsinput_8h.html#a5551501a7c1d28aa878cac0da47b7a79", null ],
    [ "usermetricsinput_metric_update", "usermetricsinput_8h.html#a67be82f953e7fd0cbf12356a77c65cfd", null ],
    [ "usermetricsinput_metric_update_today", "usermetricsinput_8h.html#ae4d9f012399c3d0c07af82e460095f55", null ],
    [ "usermetricsinput_metricmanager_add", "usermetricsinput_8h.html#a1634de4e0e5490b465e8c544074cb0e8", null ],
    [ "usermetricsinput_metricmanager_delete", "usermetricsinput_8h.html#a72fdb8f86e2b0f69b17b68309d733642", null ],
    [ "usermetricsinput_metricmanager_new", "usermetricsinput_8h.html#af59e1f9c50dcc73755a7b4b07b1aba37", null ],
    [ "usermetricsinput_metricparameters_delete", "usermetricsinput_8h.html#a1642acbf716986af38a30afbb0dbfb1a", null ],
    [ "usermetricsinput_metricparameters_new", "usermetricsinput_8h.html#af0f8d6a63b4dee377a84f47f21be7bd3", null ],
    [ "usermetricsinput_metricparameters_set_empty_data_string", "usermetricsinput_8h.html#aedf61b9f47b1de80db718059ffe86319", null ],
    [ "usermetricsinput_metricparameters_set_format_string", "usermetricsinput_8h.html#a07374ef2eef88fddd5bb1f5d6dcec28e", null ],
    [ "usermetricsinput_metricparameters_set_maximum", "usermetricsinput_8h.html#a6efa25032bfd2296e059204bf2f97f7d", null ],
    [ "usermetricsinput_metricparameters_set_minimum", "usermetricsinput_8h.html#a6ec179a480bdb94744ef5b65ab70b5b7", null ],
    [ "usermetricsinput_metricparameters_set_text_domain", "usermetricsinput_8h.html#ae7fdf9c5fe35a32f58d81876d020c052", null ],
    [ "usermetricsinput_metricparameters_set_type", "usermetricsinput_8h.html#a5ea1d60cd825748f5754946a7841e0e7", null ],
    [ "usermetricsinput_metricupdate_add_data", "usermetricsinput_8h.html#a74e2f80d61e621e4bd3a2b1a9df3c156", null ],
    [ "usermetricsinput_metricupdate_add_null", "usermetricsinput_8h.html#a2f70ceae693bca2698de184496cf4d56", null ],
    [ "usermetricsinput_metricupdate_delete", "usermetricsinput_8h.html#ada691afb67642066c997ceaff5f7273b", null ]
];