var annotated_dup =
[
    [ "UserMetricsInput", "namespaceUserMetricsInput.html", [
      [ "Metric", "classUserMetricsInput_1_1Metric.html", "classUserMetricsInput_1_1Metric" ],
      [ "MetricManager", "classUserMetricsInput_1_1MetricManager.html", "classUserMetricsInput_1_1MetricManager" ],
      [ "MetricParameters", "classUserMetricsInput_1_1MetricParameters.html", "classUserMetricsInput_1_1MetricParameters" ],
      [ "MetricUpdate", "classUserMetricsInput_1_1MetricUpdate.html", "classUserMetricsInput_1_1MetricUpdate" ]
    ] ],
    [ "UserMetricsOutput", "namespaceUserMetricsOutput.html", [
      [ "ColorTheme", "classUserMetricsOutput_1_1ColorTheme.html", "classUserMetricsOutput_1_1ColorTheme" ],
      [ "UserMetrics", "classUserMetricsOutput_1_1UserMetrics.html", "classUserMetricsOutput_1_1UserMetrics" ]
    ] ]
];