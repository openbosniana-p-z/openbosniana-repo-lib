var hierarchy =
[
    [ "UserMetricsInput::MetricParameters", "classUserMetricsInput_1_1MetricParameters.html", null ],
    [ "QObject", null, [
      [ "UserMetricsInput::Metric", "classUserMetricsInput_1_1Metric.html", null ],
      [ "UserMetricsInput::MetricManager", "classUserMetricsInput_1_1MetricManager.html", null ],
      [ "UserMetricsInput::MetricUpdate", "classUserMetricsInput_1_1MetricUpdate.html", null ],
      [ "UserMetricsOutput::ColorTheme", "classUserMetricsOutput_1_1ColorTheme.html", null ],
      [ "UserMetricsOutput::UserMetrics", "classUserMetricsOutput_1_1UserMetrics.html", null ]
    ] ]
];