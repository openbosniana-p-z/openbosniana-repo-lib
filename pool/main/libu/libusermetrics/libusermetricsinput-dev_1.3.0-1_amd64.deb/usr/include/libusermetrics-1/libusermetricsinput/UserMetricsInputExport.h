
#ifndef USERMETRICSINPUT_EXPORT_H
#define USERMETRICSINPUT_EXPORT_H

#ifdef USERMETRICSINPUT_STATIC_DEFINE
#  define USERMETRICSINPUT_EXPORT
#  define USERMETRICSINPUT_NO_EXPORT
#else
#  ifndef USERMETRICSINPUT_EXPORT
#    ifdef usermetricsinput_EXPORTS
        /* We are building this library */
#      define USERMETRICSINPUT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define USERMETRICSINPUT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef USERMETRICSINPUT_NO_EXPORT
#    define USERMETRICSINPUT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef USERMETRICSINPUT_DEPRECATED
#  define USERMETRICSINPUT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef USERMETRICSINPUT_DEPRECATED_EXPORT
#  define USERMETRICSINPUT_DEPRECATED_EXPORT USERMETRICSINPUT_EXPORT USERMETRICSINPUT_DEPRECATED
#endif

#ifndef USERMETRICSINPUT_DEPRECATED_NO_EXPORT
#  define USERMETRICSINPUT_DEPRECATED_NO_EXPORT USERMETRICSINPUT_NO_EXPORT USERMETRICSINPUT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef USERMETRICSINPUT_NO_DEPRECATED
#    define USERMETRICSINPUT_NO_DEPRECATED
#  endif
#endif

#endif /* USERMETRICSINPUT_EXPORT_H */
