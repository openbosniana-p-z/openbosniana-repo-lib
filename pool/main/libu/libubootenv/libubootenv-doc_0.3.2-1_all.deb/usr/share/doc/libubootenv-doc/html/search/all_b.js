var searchData=
[
  ['type_33',['type',['../structvar__entry.html#a649ff674ec446e6eb85d34338bce2016',1,'var_entry']]]
];
