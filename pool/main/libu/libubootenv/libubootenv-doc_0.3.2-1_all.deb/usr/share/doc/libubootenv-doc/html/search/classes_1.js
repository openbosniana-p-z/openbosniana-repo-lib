var searchData=
[
  ['var_5fentry_49',['var_entry',['../structvar__entry.html',1,'']]]
];
