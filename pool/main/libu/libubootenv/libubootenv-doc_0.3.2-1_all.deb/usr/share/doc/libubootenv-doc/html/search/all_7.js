var searchData=
[
  ['name_28',['name',['../structvar__entry.html#ac5c8d47aea6b492568d6d0ae7201a9b5',1,'var_entry']]]
];
