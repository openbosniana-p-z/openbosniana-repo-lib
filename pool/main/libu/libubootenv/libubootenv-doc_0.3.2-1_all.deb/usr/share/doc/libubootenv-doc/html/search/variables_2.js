var searchData=
[
  ['data_68',['data',['../structuboot__env__noredund.html#a26370939c78f2e4c8be2799ad421b4a3',1,'uboot_env_noredund::data()'],['../structuboot__env__redund.html#af711a4ba24e7243f18380ed7eb8167a4',1,'uboot_env_redund::data()']]],
  ['device_5ftype_69',['device_type',['../structuboot__flash__env.html#a36aaef5acf85377aca2ef71a13192db7',1,'uboot_flash_env']]],
  ['devname_70',['devname',['../structuboot__env__device.html#ac0cf4b2a64c38ffd9efa7e64eecce518',1,'uboot_env_device::devname()'],['../structuboot__flash__env.html#a749f886ed341a9bf014fe493d8603b66',1,'uboot_flash_env::devname()']]]
];
