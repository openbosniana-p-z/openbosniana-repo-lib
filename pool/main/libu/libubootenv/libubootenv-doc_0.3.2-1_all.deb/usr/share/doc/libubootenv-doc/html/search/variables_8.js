var searchData=
[
  ['offset_80',['offset',['../structuboot__env__device.html#a23afa3336da40e543e4d6cb5f97b2596',1,'uboot_env_device::offset()'],['../structuboot__flash__env.html#ab2cb0819013221d5922995b5e2006f32',1,'uboot_flash_env::offset()']]]
];
