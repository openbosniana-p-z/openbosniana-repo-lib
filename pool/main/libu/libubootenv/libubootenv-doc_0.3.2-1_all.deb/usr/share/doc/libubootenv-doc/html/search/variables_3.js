var searchData=
[
  ['envdevs_71',['envdevs',['../structuboot__ctx.html#a470384f2d07b60c914aa5a3a418cbb68',1,'uboot_ctx']]],
  ['envsectors_72',['envsectors',['../structuboot__env__device.html#adee8d6455f3f3e1718b1ff8bc86c93dd',1,'uboot_env_device::envsectors()'],['../structuboot__flash__env.html#a323d2f4e21ac719df1c84455e8e07b66',1,'uboot_flash_env::envsectors()']]],
  ['envsize_73',['envsize',['../structuboot__env__device.html#a338e8e9e7983ce40ecec9b19dedb6570',1,'uboot_env_device::envsize()'],['../structuboot__flash__env.html#aaca03c5b59b8780e0002816c1e0eb1b2',1,'uboot_flash_env::envsize()']]]
];
