var searchData=
[
  ['sectorsize_31',['sectorsize',['../structuboot__env__device.html#a476c8206cd75f158b0d3c57736479d5c',1,'uboot_env_device::sectorsize()'],['../structuboot__flash__env.html#abc23ee5dacf3ba7995be0077fa9f974b',1,'uboot_flash_env::sectorsize()']]],
  ['size_32',['size',['../structuboot__ctx.html#adb4ba99588684923254f699bb7b71696',1,'uboot_ctx']]]
];
