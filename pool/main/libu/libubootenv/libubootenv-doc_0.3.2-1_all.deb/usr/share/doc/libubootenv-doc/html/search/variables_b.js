var searchData=
[
  ['type_84',['type',['../structvar__entry.html#a649ff674ec446e6eb85d34338bce2016',1,'var_entry']]]
];
