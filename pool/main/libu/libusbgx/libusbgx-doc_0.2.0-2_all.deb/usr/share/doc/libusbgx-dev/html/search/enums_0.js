var searchData=
[
  ['usbg_5ferror_0',['usbg_error',['../group__libusbgx.html#ga53ff55df4793b365cb6bf2723053d018',1,'usbg.h']]],
  ['usbg_5ffunction_5ftype_1',['usbg_function_type',['../group__libusbgx.html#ga0cd65b6b5cfa50387cc9b0ea8bbcc832',1,'usbg.h']]],
  ['usbg_5fgadget_5fattr_2',['usbg_gadget_attr',['../group__libusbgx.html#gadfb1a7e1855f9d8072f57d6d51ce0402',1,'usbg.h']]],
  ['usbg_5fgadget_5fos_5fdesc_5fstrs_3',['usbg_gadget_os_desc_strs',['../group__libusbgx.html#ga61197026a63c0f9bc95f2c1d39308c59',1,'usbg.h']]]
];
