var searchData=
[
  ['usbg_5fbinding_0',['usbg_binding',['../structusbg__binding.html',1,'']]],
  ['usbg_5fconfig_1',['usbg_config',['../structusbg__config.html',1,'']]],
  ['usbg_5fconfig_5fattrs_2',['usbg_config_attrs',['../group__libusbgx.html#structusbg__config__attrs',1,'']]],
  ['usbg_5fconfig_5fstrs_3',['usbg_config_strs',['../group__libusbgx.html#structusbg__config__strs',1,'']]],
  ['usbg_5ffunction_4',['usbg_function',['../structusbg__function.html',1,'']]],
  ['usbg_5ffunction_5fos_5fdesc_5',['usbg_function_os_desc',['../group__libusbgx.html#structusbg__function__os__desc',1,'']]],
  ['usbg_5ffunction_5ftype_6',['usbg_function_type',['../structusbg__function__type.html',1,'']]],
  ['usbg_5fgadget_7',['usbg_gadget',['../structusbg__gadget.html',1,'']]],
  ['usbg_5fgadget_5fattrs_8',['usbg_gadget_attrs',['../group__libusbgx.html#structusbg__gadget__attrs',1,'']]],
  ['usbg_5fgadget_5fos_5fdescs_9',['usbg_gadget_os_descs',['../group__libusbgx.html#structusbg__gadget__os__descs',1,'']]],
  ['usbg_5fgadget_5fstrs_10',['usbg_gadget_strs',['../group__libusbgx.html#structusbg__gadget__strs',1,'']]],
  ['usbg_5fstate_11',['usbg_state',['../structusbg__state.html',1,'']]],
  ['usbg_5fudc_12',['usbg_udc',['../structusbg__udc.html',1,'']]]
];
