var searchData=
[
  ['usbg_5fbinding_0',['usbg_binding',['../group__libusbgx.html#ga0188874fe7f2298fac156f0955bfae31',1,'usbg.h']]],
  ['usbg_5fconfig_1',['usbg_config',['../group__libusbgx.html#gacca45ee5aa5be904d7704937c97fb362',1,'usbg.h']]],
  ['usbg_5ffunction_2',['usbg_function',['../group__libusbgx.html#ga8f70d36b5c538f5665bba7ed0c713260',1,'usbg.h']]],
  ['usbg_5fgadget_3',['usbg_gadget',['../group__libusbgx.html#ga1795af0f131494ddb81d900db9dfe342',1,'usbg.h']]],
  ['usbg_5fstate_4',['usbg_state',['../group__libusbgx.html#gaa8d96009600a77a7f0472342a99ad092',1,'usbg.h']]],
  ['usbg_5fudc_5',['usbg_udc',['../group__libusbgx.html#ga2fc033515f1a79e9b4e4c897cbb19fdd',1,'usbg.h']]]
];
