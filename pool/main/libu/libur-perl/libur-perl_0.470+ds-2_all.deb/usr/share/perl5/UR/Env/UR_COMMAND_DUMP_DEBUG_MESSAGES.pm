package UR::Env::UR_COMMAND_DUMP_DEBUG_MESSAGES;
use strict;
use warnings;
require UR;
our $VERSION = "0.47"; # UR $VERSION;
1;
