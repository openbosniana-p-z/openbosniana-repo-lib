package UR::Env::UR_DBI_MONITOR_EVERY_FETCH;
use strict;
use warnings;
require UR;
our $VERSION = "0.47"; # UR $VERSION;
1;
