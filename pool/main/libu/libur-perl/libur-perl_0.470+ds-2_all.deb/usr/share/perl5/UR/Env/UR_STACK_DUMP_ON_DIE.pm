package UR::Env::UR_STACK_DUMP_ON_DIE;
use strict;
use warnings;
require UR;
our $VERSION = "0.47"; # UR $VERSION;
1;
