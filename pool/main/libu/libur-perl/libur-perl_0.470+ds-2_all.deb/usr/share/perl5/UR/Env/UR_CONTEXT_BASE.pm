package UR::Env::UR_CONTEXT_BASE;
use strict;
use warnings;
require UR;
our $VERSION = "0.47"; # UR $VERSION;
1;
