package UR::Env::UR_NO_REQUIRE_USER_VERIFY;
use strict;
use warnings;
require UR;
our $VERSION = "0.47"; # UR $VERSION;
1;
