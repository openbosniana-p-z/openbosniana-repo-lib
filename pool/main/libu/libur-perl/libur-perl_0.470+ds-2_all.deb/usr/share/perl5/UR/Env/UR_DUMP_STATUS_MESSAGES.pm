package UR::Env::UR_DUMP_STATUS_MESSAGES;
use strict;
use warnings;
require UR;
our $VERSION = "0.47"; # UR $VERSION;
1;
