use strict;
use warnings;
use UR;
use Command;

package Command::Test::Tree1;

class Command::Test::Tree1 {
    is => 'Command',
    doc => 'more exciting operations are here'
};

1;

