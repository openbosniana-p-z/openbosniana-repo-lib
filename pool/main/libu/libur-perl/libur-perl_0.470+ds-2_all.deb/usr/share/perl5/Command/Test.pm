use strict;
use warnings;
use UR;
use Command;

package Command::Test;

class Command::Test{
    is => 'Command',
};

1;

