package UR::Env::UR_CONTEXT_ROOT;
use strict;
use warnings;
require UR;
our $VERSION = "0.47"; # UR $VERSION;
1;
