package UR::Env::UR_CONTEXT_CACHE_SIZE_LOWWATER;
use strict;
use warnings;
require UR;
our $VERSION = "0.47"; # UR $VERSION;
1;
