package UR::Env::UR_DBI_NO_COMMIT;
use strict;
use warnings;
require UR;
our $VERSION = "0.47"; # UR $VERSION;
1;
