// Geometric Tools, LLC
// Copyright (c) 1998-2014
// Distributed under the Boost Software License, Version 1.0.
// http://www.boost.org/LICENSE_1_0.txt
// http://www.geometrictools.com/License/Boost/LICENSE_1_0.txt
//
// File Version: 5.0.0 (2010/01/01)

#ifndef WM5IMAGICSPCH_H
#define WM5IMAGICSPCH_H

#ifdef WM5_USE_PRECOMPILED_HEADERS
#include "Wm5Imagics.h"
#endif

#endif
