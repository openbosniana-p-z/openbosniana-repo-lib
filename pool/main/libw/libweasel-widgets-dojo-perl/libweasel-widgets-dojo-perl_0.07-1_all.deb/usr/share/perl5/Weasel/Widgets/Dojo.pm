
package Weasel::Widgets::Dojo;

use strict;
use warnings;

our $VERSION = '0.07';

use Weasel::Widgets::Dojo::Option;
use Weasel::Widgets::Dojo::Select;

1;
