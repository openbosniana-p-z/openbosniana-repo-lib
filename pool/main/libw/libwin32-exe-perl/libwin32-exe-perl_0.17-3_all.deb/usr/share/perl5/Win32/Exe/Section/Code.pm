# Copyright 2004 by Audrey Tang <cpan@audreyt.org>

package Win32::Exe::Section::Code;

use strict;
use base 'Win32::Exe::Section';

1;
