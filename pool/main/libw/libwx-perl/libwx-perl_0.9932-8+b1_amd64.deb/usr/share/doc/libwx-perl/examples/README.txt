The examples in this directoy are very simple applications. Wx::Demo (available
on CPAN) shows a more complex application demonstrating most wxPerl controls and
features.
