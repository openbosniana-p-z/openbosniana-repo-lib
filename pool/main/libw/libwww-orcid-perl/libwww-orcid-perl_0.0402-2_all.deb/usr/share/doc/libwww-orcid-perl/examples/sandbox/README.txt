Install dependencies:

    cd examples/sandbox
    cpanm --installdeps .

Start the webapp:

    cd examples/sandbox
    plackup -I ../../lib/ app.pl

