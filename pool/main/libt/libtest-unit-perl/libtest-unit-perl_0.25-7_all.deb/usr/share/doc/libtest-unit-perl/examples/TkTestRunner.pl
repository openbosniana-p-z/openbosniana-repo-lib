#!/usr/bin/perl -w

use strict;

use Test::Unit::TkTestRunner;

Test::Unit::TkTestRunner::main(@ARGV);
