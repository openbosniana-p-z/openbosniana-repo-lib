use strict;
use warnings;

package Foo;
1;
