#ifndef ErroH
#define ErroH
#include <stdlib.h>
#include <stdio.h>
#define FatalError(x) {printf("%s\n", x); exit(0);}
#endif
