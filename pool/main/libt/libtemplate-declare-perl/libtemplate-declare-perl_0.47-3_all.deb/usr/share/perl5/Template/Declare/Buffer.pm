use warnings;
use strict;

package Template::Declare::Buffer;

sub new {
    die "Template::Declare::Buffer is deprecated!";
}

1;
__END__

=head1 NAME

Template::Declare::Buffer - deprecated

=head1 DESCRIPTION

This class is deprecated; buffers in Template::Declare are now managed by L<String::BufferStack>.

=begin comment

=head2 new

=end comment

=head1 SEE ALSO

L<Template::Declare>.

