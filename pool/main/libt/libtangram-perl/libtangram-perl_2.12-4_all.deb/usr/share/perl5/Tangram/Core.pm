use strict;

use Set::Object;

use Tangram qw(:core);

use vars qw(@ISA);
@ISA = qw(Tangram);

1;
