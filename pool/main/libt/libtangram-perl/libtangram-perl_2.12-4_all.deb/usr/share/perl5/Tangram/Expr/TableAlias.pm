
package Tangram::Expr::TableAlias;

my $top = 1_000;

sub new
{
	'l' . ++$top
}

1;
