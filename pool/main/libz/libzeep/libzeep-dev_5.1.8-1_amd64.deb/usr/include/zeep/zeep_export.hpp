
#ifndef ZEEP_EXPORT_H
#define ZEEP_EXPORT_H

#ifdef ZEEP_STATIC_DEFINE
#  define ZEEP_EXPORT
#  define ZEEP_NO_EXPORT
#else
#  ifndef ZEEP_EXPORT
#    ifdef zeep_EXPORTS
        /* We are building this library */
#      define ZEEP_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define ZEEP_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef ZEEP_NO_EXPORT
#    define ZEEP_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef ZEEP_DEPRECATED
#  define ZEEP_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ZEEP_DEPRECATED_EXPORT
#  define ZEEP_DEPRECATED_EXPORT ZEEP_EXPORT ZEEP_DEPRECATED
#endif

#ifndef ZEEP_DEPRECATED_NO_EXPORT
#  define ZEEP_DEPRECATED_NO_EXPORT ZEEP_NO_EXPORT ZEEP_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ZEEP_NO_DEPRECATED
#    define ZEEP_NO_DEPRECATED
#  endif
#endif

#endif /* ZEEP_EXPORT_H */
